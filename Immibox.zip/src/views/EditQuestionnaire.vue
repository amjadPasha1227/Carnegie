<template>
  <div class="vx-col w-full mb-base wizard-container">
    <vx-card>
      <div class="wizard-content-heading">
        <h2>Update Case Details</h2>
        <p>Please take a few moments to complete this short registration form</p>
      </div>
      <form-wizard color="rgba(var(--vs-primary), 1)" :title="null" :subtitle="null" finishButtonText="Submit"
        @on-complete="formSubmitted">
        <tab-content title="Case Details" :before-change="beforeTabSwitch">
          <!-- tab 1 content -->
          <form data-vv-scope="beneficiaryInfoform">
            <vs-col class="w-full p-0">
              <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal"
                icon="IP-information-button" active="true">
                {{[5,8].indexOf(petition.subTypeDetails.id) > -1}}
                NOTE: This questionnaire should be filled out completely and accurately. Kindly read the instructions
                carefully. All information is required, and if not applicable, please mention N/A.
              </vs-alert>
            </vs-col>
            <vs-col class="m-auto float-none demo-alignment beneficiary-info-btns pt-12 pb-6" vs-type="flex"
              vs-justify="space-between" vs-align="center" vs-lg="8" vs-sm="12">
              <vs-button class="btn male-btn" @click="setGender('male')" v-bind:class="{
                  isActivec: beneficiaryInfo.gender == 'male'
                }" icon-pack="IntakePortal" icon=" IP-femenine-1" type="border">Male</vs-button>
              <vs-button v-bind:class="{
                  isActivec: beneficiaryInfo.gender == 'female'
                }" class="btn female-btn" @click="setGender('female')" icon-pack="IntakePortal" icon=" IP-femenine-1"
                type="border">Female</vs-button>
              <vs-button v-bind:class="{
                  isActivec: beneficiaryInfo.gender == 'others'
                }" class="btn others-btn" @click="setGender('others')" icon-pack="feather" icon="icon-circle"
                type="border">Others</vs-button>
              <vs-input style="display:none" name="gender" type="hidden" data-vv-as="Gender" v-validate="'required'"
                v-model="beneficiaryInfo.gender" />
              <div class="mt-0 mr-0" style="width:100%;">
                <span class="text-danger text-sm"
                  v-show="errors.has('beneficiaryInfoform.gender')">{{ errors.first("beneficiaryInfoform.gender") }}</span>
              </div>
            </vs-col>

            <div class="divider"></div>
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col w-full">
                    <vx-input-group class="form-input-group">
                      <vs-input name="firstname" v-model="beneficiaryInfo.firstname" v-validate="''"
                        class="w-full" data-vv-as="First Name" label="First Name" />

                      <vs-input class="w-full" name="middleName" v-model="beneficiaryInfo.middleName"
                        data-vv-as="Middle Name" label="Middle Name" />

                      <vs-input class="w-full" name="lastName" v-model="beneficiaryInfo.lastName"
                         data-vv-as="Last Name" label="Last Name" />
                    </vx-input-group>
                    <div class="input-group-error">
                      <p class="w-1/3">
                        <span class="text-danger text-sm"
                          v-show="errors.has('beneficiaryInfoform.firstname')">{{ errors.first("beneficiaryInfoform.firstname") }}</span>
                      </p>
                      <p class="w-1/3">

                      </p>
                      <p class="w-1/3">
                        <span class="text-danger text-sm"
                          v-show="errors.has('beneficiaryInfoform.lastName')">{{ errors.first("beneficiaryInfoform.lastName") }}</span>
                      </p>
                    </div>
                  </div>
                  <!-- <div class="vx-col md:w-1/3  w-full">
                  <vs-input class="w-full" label="Middle Name" />
                </div>
                <div class="vx-col md:w-1/3  w-full">
                  <vs-input class="w-full" label="Last Name" />
                  </div>-->
                  <div class="vx-col w-full">
                    <vs-input name="email" v-model="beneficiaryInfo.email" v-validate="'required|email'" class="w-full"
                      data-vv-as="Email" label="Email" />

                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.email')">{{ errors.first("beneficiaryInfoform.email") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <label class="date-picker-label">Date of Birth</label>
                    <div class="main-placeholder right">
                      <datepicker  :typeable="true" name="dateOfBirth"
                      :open-date="new Date(openDate)"
                      :disabled-dates="{from: new Date(startEligibleDate)}" data-vv-as="Date of Birth"
                        v-model="beneficiaryInfo.dateOfBirth" v-validate="'required'" placeholder="MM/DD/YYYY">
                      </datepicker>
                      <span class="text-danger text-sm"
                        v-show="errors.has('beneficiaryInfoform.dateOfBirth')">{{ errors.first("beneficiaryInfoform.dateOfBirth") }}</span>
                    </div>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <vs-select v-validate="'required'" name="maritalStatus" v-model="beneficiaryInfo.maritalStatus"
                      class="w-full select-large" data-vv-as="Marital Status" label="Marital Status">
                      <vs-select-item :key="index" :value="item.id" :text="item.name"
                        v-for="(item,index) in marital_statuses" class="w-full" />
                    </vs-select>
                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.maritalStatus')">{{ errors.first("beneficiaryInfoform.maritalStatus") }}</span>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col md:w-1/2 w-full">

                    <div class="vs-component vs-con-input-label vs-input w-full vs-input-primary">
                      <label for="" class="vs-input--label">Phone Number</label>
                      <phone-mask-input v-model="beneficiaryInfo.cellPhoneNumber" autoDetectCountry
                        name="cellPhoneNumber" v-validate="'required|phoneNumber'" data-vv-as="Phone Number"
                        placeholder="+X(XXX)-XXX-XXXX" wrapperClass="vs-con-input"
                        inputClass="vs-inputx vs-input--input normal" label="Phone Number" />

                    </div>



                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.cellPhoneNumber')">{{ errors.first("beneficiaryInfoform.cellPhoneNumber") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">


                    <div class="vs-component vs-con-input-label vs-input w-full vs-input-primary">
                      <label for="" class="vs-input--label">Home Phone Number</label>
                      <phone-mask-input v-model="beneficiaryInfo.homePhoneNumber" autoDetectCountry
                        name="homePhoneNumber" v-validate="'phoneNumber'" data-vv-as="Home Phone Number"
                        placeholder="+X(XXX)-XXX-XXXX" wrapperClass="vs-con-input"
                        inputClass="vs-inputx vs-input--input normal" label="Home Phone Number" />

                    </div>




                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.homePhoneNumber')">{{ errors.first("beneficiaryInfoform.homePhoneNumber") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">


                    <div class="vs-component vs-con-input-label vs-input w-full vs-input-primary">
                      <label for="" class="vs-input--label">Work Phone Number</label>
                      <phone-mask-input v-model="beneficiaryInfo.workPhoneNumber" autoDetectCountry
                        name="workPhoneNumber" v-validate="'phoneNumber'" data-vv-as="Work Phone Number"
                        placeholder="+X(XXX)-XXX-XXXX" wrapperClass="vs-con-input"
                        inputClass="vs-inputx vs-input--input normal" label="Work Phone Number" />

                    </div>




                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.workPhoneNumber')">{{ errors.first("beneficiaryInfoform.workPhoneNumber") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">



                    <div class="vs-component vs-con-input-label vs-input w-full vs-input-primary">
                      <label for="" class="vs-input--label">Fax Number</label>
                      <phone-mask-input v-model="beneficiaryInfo.faxNumber" autoDetectCountry name="faxNumber"
                        v-validate="'phoneNumber'" data-vv-as="Fax Number" placeholder="+X(XXX)-XXX-XXXX"
                        wrapperClass="vs-con-input" inputClass="vs-inputx vs-input--input normal" label="Fax Numbe" />

                    </div>




                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.faxNumber')">{{ errors.first("beneficiaryInfoform.faxNumber") }}</span>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container w-full">
                <h3 class="small-header">Education</h3>
                <div class="vx-row">
                  <div class="vx-col md:w-1/2 w-full">
                    <vs-select v-validate="'required'" name="highestDegree"
                      v-model="beneficiaryInfo.education.highestDegree" class="w-full select-large"
                      data-vv-as="Highest Degree" label="Highest Degree">
                      <vs-select-item :key="index" :value="item.id" :text="item.name"
                        v-for="(item,index) in education_types" class="w-full" />
                    </vs-select>
                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.highestDegree')">{{ errors.first("beneficiaryInfoform.highestDegree") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <vs-input v-validate="'required'" class="w-full" name="majorFieldOfStudy"
                      v-model="beneficiaryInfo.education.majorFieldOfStudy" data-vv-as="Major Field of Study"
                      label="Major Field of Study" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.majorFieldOfStudy')">{{ errors.first("beneficiaryInfoform.majorFieldOfStudy") }}</span>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <h3 class="small-header">Address</h3>
                <div class="vx-row">
                  <div class="vx-col w-full">
                    <ul class="demo-alignment custom-radio" vs-type="flex" vs-align="center">
                      <li>
                        <vs-radio v-model="beneficiaryInfo.iAmFromUS" vs-value='true'>I am in the United States
                        </vs-radio>
                      </li>
                      <li>
                        <vs-radio v-model="beneficiaryInfo.iAmFromUS" vs-value='false'>I am not in the United States
                        </vs-radio>
                      </li>
                    </ul>
                  </div>
                 

                  <div class="vx-col md:w-1/2 w-full">
                    <vs-input name="address1" v-model="beneficiaryInfo.address.line1" class="w-full"
                      data-vv-as="Street Address" label="Street Address" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.address1')">{{ errors.first("beneficiaryInfoform.address1") }}</span>
                  </div>

                   <div class="vx-col md:w-1/2 w-full">
                    <vs-input  name="address2" v-model="beneficiaryInfo.address.line2"
                      class="w-full" data-vv-as="Apt, Suite" label="Apt, Suite" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.address2')">{{ errors.first("beneficiaryInfoform.address2") }}</span>
                  </div>

                  <div class="vx-col md:w-1/2 w-full">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">Country</label>
                      <multiselect name="country" v-validate="'required'"   v-model="bncountryModel"
                        @select="selectCountry" :show-labels="false" ref="bncountry" track-by="id" label="name" data-vv-as="Country"
                        placeholder="Select Country" :options="countries" :searchable="true" :allow-empty="false">
                      </multiselect>


                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.country')">{{ errors.first("beneficiaryInfoform.country") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">State</label>
                      <multiselect name="state" v-validate="'required'" v-model="stateModel"
                        :disabled="states.length == 0" @select="selectState" :show-labels="false" label="name"
                        track-by="id" data-vv-as="State" placeholder="Select State" :options="states" :searchable="true"
                        :allow-empty="false"></multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.state')">{{ errors.first("beneficiaryInfoform.state") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">City</label>
                      <multiselect name="city" v-validate="'required'" v-model="locationModel" @select="selectLocation"
                        :show-labels="false" :disabled="locations.length == 0" track-by="id" data-vv-as="City"
                        label="name" placeholder="Select City" :options="locations" :searchable="true"
                        :allow-empty="false"></multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.city')">{{ errors.first("beneficiaryInfoform.city") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <vs-input name="zipcode" v-model="beneficiaryInfo.address.zipcode"
                      v-validate="'numeric|required|zipcodev:bncountry'" class="w-full" data-vv-as="Zip Code"
                      label="Zip Code" />

                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.zipcode')">{{ errors.first("beneficiaryInfoform.zipcode") }}</span>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col w-full">
                    <div class="main-placeholder right info-right">
                      <vx-tooltip color="primary" text="Text Here">
                        <img src="@/assets/images/main/info-icon.svg" />
                      </vx-tooltip>

                      <div class="vs-component vs-con-input-label vs-input w-full ssnnumber vs-input-primary">
                        <label for="" class="vs-input--label">Social Security number (if applicable)</label>
                        <div class="vs-con-input">
                          <the-mask v-validate="'required|min:9|max:11'" v-model="beneficiaryInfo.SSN"
                            placeholder="123 - 45 - 6789"   name="ssn"  class="vs-inputx vs-input--input normal"
                            :mask="['### - ## - ####']" />

                          <span class="text-danger text-sm"
                                v-show="errors.has('beneficiaryInfoform.ssn')">{{ errors.first("beneficiaryInfoform.ssn") }}</span>


                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider" v-if="beneficiaryInfo.iAmFromUS == 'false'" ></div>
            <vs-col v-if="beneficiaryInfo.iAmFromUS == 'false'" class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col w-full" >
                    <label class="custom-label">
                      Consulate to Notify upon Approval of your petition (if outside the
                      USA)
                    </label>
                    <vs-textarea v-model="beneficiaryInfo.consulateNotifyAddress"  class="w-full" data-vv-as="Consulate to Notify upon Approval of your petition (if outside the
                      USA)" />
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            <vs-col class="m-auto float-none" vs-lg="8" vs-sm="12">
              <div class="alert-content-block">
                <p class="pt-2">Has an I-140 immigrant petition been filed on your behalf? Details</p>
               {{beneficiaryInfo.hasI140ImmPetitionFiled}}
                <vs-button v-bind:class="{
                  cactive: beneficiaryInfo.hasI140ImmPetitionFiled
                }" @click="beneficiaryInfo.hasI140ImmPetitionFiled = true" class="mr-5" color="success" type="border">
                  Yes</vs-button>
                <vs-button v-bind:class="{
                  cactive: !beneficiaryInfo.hasI140ImmPetitionFiled
                }" @click="beneficiaryInfo.hasI140ImmPetitionFiled = false" color="danger" type="border">No</vs-button>
                <div class="form-container mt-6" v-if="beneficiaryInfo.hasI140ImmPetitionFiled">
                  <div class="vx-row">
                    <div class="vx-col w-full">
                      <vs-textarea v-model="beneficiaryInfo.I140ImmPetitionFiledDetails" class="w-full" />
                    </div>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col w-full mt-6">
                    <p class="mb-0">All prior periods of stay in the U.S. over the last seven years</p>
                  </div>

                  <div class="vx-col w-full">

                    <div class="vx-row delete-row" v-for="(priorstay, index) in priorPeriodOfStayInUS" :key="priorstay.id">
                      <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label">Date Entered</label>
                        <div class="main-placeholder right">

                          <datepicker  :typeable="true" data-vv-as="Date Entered" :name="'enterDate'+index" 
                          :disabled-dates="{to: new Date(startBeneficiaryDateEntered), from: new Date()}" v-model="priorstay.enteredDate"
                            placeholder="MM/DD/YYYY"></datepicker>
                            <span class="text-danger text-sm"
                              v-show="errors.has('beneficiaryInfoform.enterDate'+index)">{{ errors.first('beneficiaryInfoform.enterDate'+index)}}</span>
                        </div>
                      </div>
                      <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label">Date Departed</label>
                        <div class="main-placeholder right">

                          <datepicker  :typeable="true" data-vv-as="Date Departed" :name="'departDate'+index"
                           v-validate="{required: priorstay.enteredDate != null && !priorstay.departedDate }"
                           :disabled="priorstay.enteredDate === null" :disabled-dates="{to: priorstay.enteredDate, from: new Date()}" v-model="priorstay.departedDate"
                            placeholder="MM/DD/YYYY"></datepicker>
                            <span class="text-danger text-sm"
                              v-show="errors.has('beneficiaryInfoform.departDate'+index)">{{ errors.first('beneficiaryInfoform.departDate'+index) }}</span>
                        </div>
                      </div>
                      <div class="vx-col md:w-1/3 w-full">
                        <vs-select v-model="priorstay.visaStatus" :disabled="priorstay.enteredDate === null"
                         :name="'selectVisaStatus'+index" v-validate="{required: priorstay.enteredDate != null && !priorstay.visaStatus }"
                        class="w-full select-large" data-vv-as="Visa Status"
                          label="Case Status">
                          <vs-select-item :key="index" :value="item.id" :text="item.name"
                            v-for="(item,index) in visastatuses" class="w-full" />
                        </vs-select>
                        <span class="text-danger text-sm" 
                          v-show="errors.has('beneficiaryInfoform.selectVisaStatus'+index)">{{ errors.first('beneficiaryInfoform.selectVisaStatus'+index)}}</span>
                      </div>
                      <div class="delete" v-if="priorPeriodOfStayInUS.length > 1">
                        <a @click="removepriorstay(index)">
                          <img src="@/assets/images/main/delete-row-img.svg">
                        </a>
                      </div>
                    </div>
                  </div>

                </div>
              </div>

            </vs-col>
            <vs-col class="m-auto float-none" vs-type="flex" vs-align="center" vs-lg="8" vs-sm="12">
              <a @click="addpriorstay" class="add-more ml-0" type="filled">
                <span>+</span> More
              </a>
            </vs-col>

          </form>
        </tab-content>
        <!-- tab 2 content -->
        
        <tab-content title="Dependents Info" v-if="[5,8].indexOf(petition.subTypeDetails.id) > -1 && beneficiaryInfo.maritalStatus!=1" :before-change="beforeDependents" >
          <form data-vv-scope="dependentsInfoform">

            <vs-col class="w-full p-0">
              <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal"
                icon="IP-information-button" active="true">
                <p>
                  Your spouse and children will need to apply for H-4 status (only if they are currently in the USA on a
                  valid status).
                </p>
                <p>
                  That their status must be extended through a separate application, and is not automatically extended
                  upon approval of the H-1B petition.
                </p>
              </vs-alert>
            </vs-col>

           <div  class="spousedetails" v-if="beneficiaryInfo.maritalStatus==2">

 <vs-col class="m-auto pt-6 float-none" vs-type="flex" vs-lg="8" vs-sm="12">
              <div class="alert-content-block">
                <p>H4 required for spouse?</p>
                <vs-button class="mr-5" v-bind:class="{
                  cactive: dependentsInfo.spouse.h4Required == true
                }" @click="dependentsInfo.spouse.h4Required = true" color="success" type="border">Yes</vs-button>
                <vs-button v-bind:class="{
                  cactive: dependentsInfo.spouse.h4Required == false
                }" @click="dependentsInfo.spouse.h4Required = false" color="danger" type="border">No</vs-button>
              </div>
            </vs-col>

            <div class="divider" v-if="dependentsInfo.spouse.h4Required && dependentsInfo.spouse.h4Required == true">
            </div>
            <vs-col v-if="dependentsInfo.spouse.h4Required && dependentsInfo.spouse.h4Required == true"
              class="m-auto float-none" vs-type="flex" vs-lg="8" vs-sm="12">
              <div class="alert-content-block">
                <p>H4 EAD required for spouse?</p>
                <vs-button v-bind:class="{
                  cactive: dependentsInfo.spouse.h4EADRequired == false
                }" @click="dependentsInfo.spouse.h4EADRequired = false" class="mr-5" color="success" type="border">Yes
                </vs-button>
                <vs-button v-bind:class="{
                  cactive: dependentsInfo.spouse.h4EADRequired == false
                }" @click="dependentsInfo.spouse.h4EADRequired = false" color="danger" type="border">No</vs-button>
              </div>
            </vs-col>
            <div class="divider"></div>
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col w-full">
                    <vx-input-group class="form-input-group">
                      <vs-input class="w-full" data-vv-as="First Name" name="firstname"
                        v-model="dependentsInfo.spouse.firstname" v-validate="'required'" label="First Name" />
                      <vs-input class="w-full" data-vv-as="Middle Name" name="middleName"
                        v-model="dependentsInfo.spouse.middlename"  label="Middle Name" />
                      <vs-input class="w-full" data-vv-as="Last Name" name="lastName"
                        v-model="dependentsInfo.spouse.lastName" v-validate="'required'" label="Last Name" />
                    </vx-input-group>

                    <div class="input-group-error">
                      <p class="w-1/3">
                        <span class="text-danger text-sm"
                          v-show="errors.has('dependentsInfoform.firstname')">{{ errors.first("dependentsInfoform.firstname") }}</span>
                      </p>
                      <p class="w-1/3">
                                         </p>
                      <p class="w-1/3">
                        <span class="text-danger text-sm"
                          v-show="errors.has('dependentsInfoform.lastName')">{{ errors.first("dependentsInfoform.lastName") }}</span>
                      </p>
                    </div>



                  </div>

                  <div class="vx-col md:w-1/2 w-full">
                    <label class="date-picker-label">Spouse’s Date of Birth</label>
                    <div class="main-placeholder right">
                      <datepicker  :typeable="true" name="dateofbirth" :open-date="new Date(openDate)" :disabled-dates="{from: new Date(startEligibleDate)}" v-validate="'required'"
                        v-model="dependentsInfo.spouse.dateOfBirth" data-vv-as="Spouse’s Date of Birth"
                        placeholder="MM/DD/YYYY"></datepicker>
                      <span class="text-danger text-sm"
                        v-show="errors.has('dependentsInfoform.dateofbirth')">{{ errors.first("dependentsInfoform.dateofbirth") }}</span>

                    </div>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">Country</label>
                      <multiselect  ref="spousecountry" name="country" v-validate="'required'" v-model="countrySelected"
                        @select="selectspouseCountry" :show-labels="false" track-by="id" label="name"
                        data-vv-as="Country" placeholder="Select Country" :options="countries" :searchable="true"
                        :allow-empty="false"></multiselect>
                    </div>
                    <span class="text-danger text-sm"
                      v-show="errors.has('dependentsInfoform.country')">{{ errors.first("dependentsInfoform.country") }}</span>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col lg:w-1/2 md:w-1/2 w-full">
                    <vs-input  data-vv-as="Spouse Passport Number"  name="spousepassport" v-model="dependentsInfo.spouse.passportNumber"  v-validate="'passport:spousecountry|max:12'"  class="w-full"
                      label="Spouse’s Passport No" />

                                            <span class="text-danger text-sm"
                        v-show="errors.has('dependentsInfoform.spousepassport')">{{ errors.first("dependentsInfoform.spousepassport") }}</span>
                  </div>

                  <div class="vx-col lg:w-1/2 md:w-1/2 w-full">
                    <label class="date-picker-label">Passport expiry date</label>
                    <div class="main-placeholder right">

                      <datepicker  :typeable="true" v-model="dependentsInfo.spouse.passportExpiryDate" data-vv-as="Passport expiry date"
                        placeholder="MM/DD/YYYY"></datepicker>
                    </div>
                  </div>


                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">

                  <div class="vx-col lg:w-1/2 md:w-1/2 w-full">
                    <vs-input v-model="dependentsInfo.spouse.I94" class="w-full"
                      label="Spouse’s I-94 (if in USA)" />
                  </div>
                  <div class="vx-col lg:w-1/2 md:w-1/2 w-full">
                    <label class="date-picker-label">Date visa issued</label>
                    <div class="main-placeholder right">

                      <datepicker  :typeable="true" v-model="dependentsInfo.spouse.visaIssuedDate" :disabled-dates="{from: new Date()}" data-vv-as="Date visa issued"
                        placeholder="MM/DD/YYYY"></datepicker>
                    </div>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col md:w-1/2 w-full">
                    <vs-select v-model="dependentsInfo.spouse.currentStatus" class="w-full select-large"
                      data-vv-as="Spouse’s current status (if in USA)" label="Spouse’s current status (if in USA)">
                      <vs-select-item :key="index" :value="item.id" :text="item.name"
                        v-for="(item,index) in visastatuses" class="w-full" />
                    </vs-select>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <label class="date-picker-label">When does spouse’s status expires</label>
                    <div class="main-placeholder right">

                      <datepicker  :typeable="true" data-vv-as="Spouse’s status expires" placeholder="MM/DD/YYYY"></datepicker>
                    </div>
                  </div>
                  <div class="vx-col md:w-1/2 w-full vs-con-input-label">
                  <label for="" class="vs-input--label">Social security (if in USA)</label>
                  <div class="vs-con-input">
                    <the-mask v-validate="'min:9|max:9'" v-model="dependentsInfo.spouse.SSN"
                      placeholder="123 - 45 - 6789" class="vs-inputx vs-input--input normal"
                      :mask="['### - ## - ####']" />
                  </div>
                    <!-- <the-mask v-validate="'min:9|max:9'" v-model="dependentsInfo.spouse.SSN"
                      placeholder="123 - 45 - 6789" class="vs-inputx vs-input--input normal"
                      :mask="['### - ## - ####']" /> -->

                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <label class="date-picker-label">Date of last arrival (if in USA)</label>
                    <div class="main-placeholder right">

                      <datepicker  :typeable="true" data-vv-as="Date of last arrival" :disabled-dates="{from: new Date()}" placeholder="MM/DD/YYYY"></datepicker>
                    </div>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container w-full">
                <div class="alert-content-block">
                  <vs-alert active="true" class="h-auto warning-alert mb-5" icon-pack="IntakePortal"
                    icon="IP-information-button">
                    Provide copies of the following spouse documents: Case, Form I-94, Form I-797, Marriage Certificate,
                    Birth Certificate.
                  </vs-alert>
                </div>
                <h3 class="small-header">
                  Documents
                  <span class="file-type">
                    (File Type: PDF, DOC, JPEG, PNG. Max
                    file size: 1MB)
                  </span>
                </h3>
                <div class="vx-row">
                  <div class="vx-col w-full">
                    <label class="custom-label">Visa</label>
                    <!-- check balu 1 -->
                    <file-upload v-model="dependentsInfo.spouse.documents.passportAndVisa"
                     class="file-upload-input" name="visadocs" data-vv-as="Visa" :multiple="true" :hideSelected="true"
                     accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                       @input="upload(dependentsInfo.spouse.documents.passportAndVisa)">
                      <img class="file-icon" src="@/assets/images/main/file-upload.svg"> 
                      Upload
                    </file-upload>
                    <span class="text-danger text-sm"
                      v-show="errors.has('visadocs')">{{ errors.first("visadocs") }}</span>
                    <ul class="uploaded-list">
                      <vs-chip @click="remove(item, dependentsInfo.spouse.documents.passportAndVisa)" v-for="(item, index) in dependentsInfo.spouse.documents.passportAndVisa" :key="index" closable> {{ item.name }} </vs-chip>
                    </ul>
                    
                  </div>
                  <div class="vx-col w-full">
                    <label class="custom-label flex">
                      Form I-94
                      <vx-tooltip color="primary" text="Text Here">
                        <img class="ml-1" src="@/assets/images/main/info-icon.svg" />
                      </vx-tooltip>
                    </label>
                    <!-- check balu 2 -->
                    <file-upload v-model="dependentsInfo.spouse.documents.formI94" class="file-upload-input"
                      accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                     name="formi94" data-vv-as="Form I-94" :multiple="true" :hideSelected="true"  @input="upload(dependentsInfo.spouse.documents.formI94)">
                     <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload
                    </file-upload>
                    <span class="text-danger text-sm"
                      v-show="errors.has('formi94')">{{ errors.first("formi94") }}</span>
                    <ul  class="uploaded-list">
                      <vs-chip @click="remove(item, dependentsInfo.spouse.documents.formI94)" v-for="(item, index) in dependentsInfo.spouse.documents.formI94" :key="index" closable> {{ item.name }} </vs-chip>
                    </ul>
                  </div>
                  <div class="vx-col w-full">
                    <label class="custom-label flex">
                      Form I-797
                      <vx-tooltip color="primary" text="Text Here">
                        <img class="ml-1" src="@/assets/images/main/info-icon.svg" />
                      </vx-tooltip>
                    </label>
                    <file-upload v-model="dependentsInfo.spouse.documents.formI797" class="file-upload-input" 
                    name="formi797" data-vv-as="Form I-797" :multiple="true" :hideSelected="true" 
                    accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                    @input="upload(dependentsInfo.spouse.documents.formI797)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload</file-upload>
                    <span class="text-danger text-sm"
                      v-show="errors.has('formi797')">{{ errors.first("formi797") }}</span>
                    <ul  class="uploaded-list">
                      <vs-chip @click="remove(item, dependentsInfo.spouse.documents.formI797)" v-for="(item, index) in dependentsInfo.spouse.documents.formI797" :key="index" closable> {{ item.name }} </vs-chip>
                    </ul>
                  </div>
                  <div class="vx-col w-full">
                    <label class="custom-label">Marriage Certificate</label>
                    <!-- check balu 4 -->
                    <file-upload v-model="dependentsInfo.spouse.documents.marriageCertificate" class="file-upload-input" 
                    name="marriageCertificate" data-vv-as="Marriage Certificate" :multiple="true" :hideSelected="true" 
                    accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                    @input="upload(dependentsInfo.spouse.documents.marriageCertificate)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload </file-upload>
                    <span class="text-danger text-sm"
                      v-show="errors.has('marriageCertificate')">{{ errors.first("marriageCertificate") }}</span>
                    <ul  class="uploaded-list">
                      <vs-chip @click="remove(item, dependentsInfo.spouse.documents.marriageCertificate)" v-for="(item, index) in dependentsInfo.spouse.documents.marriageCertificate" :key="index" closable> {{ item.name }} </vs-chip>
                    </ul>
                  </div>
                  <div class="vx-col w-full">
                    <label class="custom-label">Birth Certificate</label>
                    
                    <file-upload v-model="dependentsInfo.spouse.documents.birthCertificate" class="file-upload-input" name="birthCertificate" 
                    data-vv-as="Birth Certificate" :multiple="true" :hideSelected="true" 
                    accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                     @input="upload(dependentsInfo.spouse.documents.birthCertificate)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload </file-upload>
                    <span class="text-danger text-sm"
                      v-show="errors.has('birthCertificate')">{{ errors.first("birthCertificate") }}</span>
                    <ul  class="uploaded-list">
                      <vs-chip @click="remove(item, dependentsInfo.spouse.documents.birthCertificate)" v-for="(item, index) in dependentsInfo.spouse.documents.birthCertificate" :key="index" closable> {{ item.name }} </vs-chip>
                    </ul>
                  </div>
                </div>
              </div>
            </vs-col>
           </div>







            <div v-for="(children, index) in childrensarray" :key="children.id">
              <div class="divider divider-double"></div>
              <div class="delete-row delete-group" v-if="childrensarray.length > 1">
                <div class="delete">
                  <a @click="removechildren(index)">
                    <img src="@/assets/images/main/delete-row-img.svg">
                  </a>
                </div>
              </div>
              <vs-col class="m-auto float-none" vs-type="flex" vs-lg="8" vs-sm="12">
                <div class="alert-content-block">
                  <p>H4 required for children?</p>
                  <vs-button v-bind:class="{
                  cactive: children.h4Required == true
                }" @click="children.h4Required = true" class="mr-5" color="success" type="border">Yes</vs-button>
                  <vs-button v-bind:class="{
                  cactive: children.h4Required == false
                }" @click="children.h4Required = false" color="danger" type="border">No</vs-button>
                </div>
              </vs-col>
              <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8"
                vs-sm="12">
                <div class="form-container">
                  <div class="vx-row">
                    <div class="vx-col w-full">
                      <vx-input-group class="form-input-group">
                        <vs-input v-model="children.firstName" class="w-full" label="First Name" />
                        <vs-input v-model="children.middleName" class="w-full" label="Middle Name" />
                        <vs-input v-model="children.lastName" class="w-full" label="Last Name" />
                      </vx-input-group>
                      <div class="input-group-error">
                        <p class="w-1/3">
                        </p>
                        <p class="w-1/3">
                        </p>
                        <p class="w-1/3">
                        </p>
                      </div>
                    </div>

                    <div class="vx-col md:w-1/2 w-full">
                      <label class="date-picker-label">Child’s Date of Birth</label>
                      <div class="main-placeholder right">

                        <datepicker  :typeable="true" v-model="children.dateOfBirth" :disabled-dates="{from: new Date()}" data-vv-as="Date of Birth" placeholder="MM/DD/YYYY">
                        </datepicker>
                      </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full">
                      <div class="con-select w-full select-large">
                        <label for class="vs-select--label">Country</label>
                        <multiselect name="childcountry[]" :id="index" v-model="children.selectedcountryOfBirth" @select="selectchildCountry"
                          :show-labels="false" track-by="id" label="name" data-vv-as="Country"
                          placeholder="Select Country" :options="countries" :searchable="true" :allow-empty="false">
                        </multiselect>
                      </div>


                    </div>
                    <div class="vx-col md:w-1/2 w-full">
                      <vs-input v-model="children.passportNumber" class="w-full" label="Child’s Passport Number" />
                    </div>
                    <div class="vx-col md:w-1/2 w-full">
                      <label class="date-picker-label">Passport Expiry Date</label>

                      <div class="main-placeholder right">

                        <datepicker  :typeable="true" v-model="children.passportExpiryDate" placeholder="MM/DD/YYYY"></datepicker>
                      </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full">
                      <vs-input v-model="children.I94" class="w-full" label="Child’s I –94 (if in USA)" />
                    </div>
                    <div class="vx-col md:w-1/2 w-full">
                      <label class="date-picker-label">Date Case Issued</label>
                      <div class="main-placeholder right">

                        <datepicker  :typeable="true" v-model="children.visaIssuedDate" :disabled-dates="{from: new Date()}" data-vv-as="Date Visa Issued"
                          placeholder="MM/DD/YYYY"></datepicker>
                      </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full">

                      <vs-select v-model="children.currentStatus" class="w-full select-large" data-vv-as="Visa Status"
                        label="Child’s Current Status (if in USA)">
                        <vs-select-item :key="index" :value="item.id" :text="item.name"
                          v-for="(item,index) in visastatuses" class="w-full" />
                      </vs-select>


                    </div>
                    <div class="vx-col md:w-1/2 w-full">
                      <label class="date-picker-label">When does child’s status expires (if in USA)</label>
                      <div class="main-placeholder right">

                        <datepicker  :typeable="true" v-model="children.statusExpiryDate" data-vv-as="Status expires"
                          placeholder="MM/DD/YYYY"></datepicker>
                      </div>
                    </div>
                  </div>
                </div>
              </vs-col>
              <div class="divider"></div>
              <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8"
                vs-sm="12">
                <div class="form-container w-full">
                  <div class="alert-content-block">
                    <vs-alert active="true" class="h-auto warning-alert mb-5" icon-pack="IntakePortal"
                      icon="IP-information-button">
                      Provide copies of the following children documents: Case, Form I-94, Form I-797, Marriage
                      Certificate,
                      Birth Certificate.
                    </vs-alert>
                  </div>
                  <h3 class="small-header">
                    Child's Documents
                    <span class="file-type">
                      (File Type: PDF, DOC, JPEG, PNG. Max
                      file size: 1MB)
                    </span>
                  </h3>
                  <div class="vx-row">
                    <div class="vx-col w-full">
                      <label class="custom-label">Passport</label>
                      <file-upload v-model="children.documents.passportDocs" class="file-upload-input" :name="'childPassport'+index"
                       data-vv-as="Passport" :multiple="true" :hideSelected="true" 
                       accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                        @input="upload(children.documents.passportDocs)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload</file-upload>
                        <span class="text-danger text-sm"
                          v-show="errors.has('childPassport'+index)">{{ errors.first('childPassport'+index) }}</span>
                      <ul  class="uploaded-list">
                        <vs-chip v-for="(passport, passportValue) in children.documents.passportDocs" :key="passportValue" @click="remove(passport, children.documents.passportDocs)" :name="'passportRemoveSelected'+index" closable> {{ passport.name }} </vs-chip>
                      </ul>
                    </div>
                    <div class="vx-col w-full">
                      <label class="custom-label">Case</label>
                      <file-upload v-model="children.documents.visaDocs" class="file-upload-input" :name="'childVisa'+index" data-vv-as="Visa"
                      accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                       :multiple="true" :hideSelected="true" @input="upload(children.documents.visaDocs)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload </file-upload>
                      <span class="text-danger text-sm"
                        v-show="errors.has('childVisa'+index)">{{ errors.first('childVisa'+index) }}</span>
                      <ul  class="uploaded-list">
                        <vs-chip @click="remove(visa, children.documents.visaDocs)" :name="'visaRemoveSelected'+index" v-for="(visa, visaValue) in children.documents.visaDocs" :key="visaValue" closable> {{ visa.name }} </vs-chip>
                      </ul>
                    </div>
                    <div class="vx-col w-full">
                      <label class="custom-label flex">
                        Form I-94
                        <vx-tooltip color="primary" text="Text Here">
                          <img class="ml-1" src="@/assets/images/main/info-icon.svg" />
                        </vx-tooltip>
                      </label>
                      <file-upload v-model="children.documents.FormI94Docs" class="file-upload-input" :name="'childFormI94'+index"
                      accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                       data-vv-as="Form I-94" :multiple="true" :hideSelected="true" @input="upload(children.documents.FormI94Docs)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload</file-upload>
                       <span class="text-danger text-sm"
                        v-show="errors.has('childFormI94'+index)">{{ errors.first('childFormI94'+index) }}</span>
                      <ul  class="uploaded-list">
                        <vs-chip @click="remove(formI94, children.documents.FormI94Docs)" :name="'formI94RemoveSelected'+index" v-for="(formI94, formI94Value) in children.documents.FormI94Docs" :key="formI94Value" closable> {{ formI94.name }} </vs-chip>
                      </ul>
                    </div>
                    <div class="vx-col w-full">
                      <label class="custom-label">Birth Certificate</label>
                      <file-upload v-model="children.documents.birthCertificateDocs" class="file-upload-input" :name="'childBirthCertificate'+index"
                       data-vv-as="Birth Certificate" :multiple="true" :hideSelected="true"
                       accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                        @input="upload(children.documents.birthCertificateDocs)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload</file-upload>
                        <span class="text-danger text-sm"
                        v-show="errors.has('childBirthCertificate'+index)">{{ errors.first('childBirthCertificate'+index) }}</span>
                      <ul  class="uploaded-list">
                        <vs-chip @click="remove(birthCertificate, children.documents.birthCertificateDocs)" :name="'birthCertificateRemoveSelected'+index" v-for="(birthCertificate, birthCertificateValue) in children.documents.birthCertificateDocs" :key="birthCertificateValue" closable> {{ birthCertificate.name }} </vs-chip>
                      </ul>

                      <!-- <vs-upload text="Upload" class="file-upload" action="https://jsonplaceholder.typicode.com/posts/"
                        @on-success="successUpload" data-vv-as="Birth Certificate" /> -->
                    </div>
                  </div>
                </div>
              </vs-col>

            </div>
            <vs-col class="m-auto float-none" vs-type="flex" vs-align="center" vs-lg="8" vs-sm="12">
              <a @click="addchildren" class="add-more mt-5 ml-0" type="filled">
                <span>+</span> Add Child
              </a>
            </vs-col>





          </form>
        </tab-content>
        <!-- tab 3 content -->
        <tab-content title="Client Info" :before-change="beforeClient">
          <form data-vv-scope="clientInfoform">
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container mt-6">
                <div class="vx-row">
                  <div class="vx-col w-full">
                    <vs-input class="w-full" v-validate="'required'" name="clientname" v-model="clientInfo.name"
                      label="Name of the Client" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.clientname')">{{ errors.first("clientInfoform.clientname") }}</span>

                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <vs-input class="w-full" v-validate="'required'" name="position" v-model="clientInfo.position"
                      label="Position" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.position')">{{ errors.first("clientInfoform.position") }}</span>
                  </div>
                  <!-- <div class="vx-col md:w-1/2 w-full">
                  <vs-input class="w-full"
                   v-validate="'required'"  name="salaryOffered" v-model="clientInfo.salaryOffered"
                   data-vv-as="Salary Offered"
                  label="Salary Offered" />
                  <span
                class="text-danger text-sm"
                v-show="errors.has('clientInfoform.salaryOffered')"
              >{{ errors.first("clientInfoform.salaryOffered") }}</span>
                </div> -->

                  <div class="vx-col md:w-1/2 w-full">
                    <vx-input-group class="form-input-group">
                      <vs-input class="w-full" v-validate="'required'" name="salaryOffered"
                        v-model="clientInfo.salaryOffered" data-vv-as="Salary Offered" label="Salary Offered" />

                     <vs-select  @change="selectedsalaryOfferedType"  v-validate="'required'" name="salaryType" v-model="clientInfo.salaryFrequency"
                        class="w-full select-large" label="Salary Frequency adsadas">
                        <vs-select-item :key="index" :value="item.id" :text="item.name"
                          v-for="(item,index) in salaryOfferedType" class="w-full" />
                      </vs-select>




                    </vx-input-group>
                    <div class="input-group-error">
                      <p class="w-1/2">
                        <span class="text-danger text-sm"
                          v-show="errors.has('clientInfoform.salaryOffered')">{{ errors.first("clientInfoform.salaryOffered") }}</span>
                      </p>

                    </div>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            <vs-col class="m-auto float-none" vs-lg="8" vs-sm="12">
           
              <div class="form-container">
                <h3 class="small-header">Address</h3>
                <div class="vx-row">

                 <div class="vx-col md:w-1/2 w-full">
                    <vs-input v-validate="'required'" name="address1" v-model="clientInfo.address.line1" class="w-full"
                      data-vv-as="Street Address" label="Street Address" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.address1')">{{ errors.first("clientInfoform.address1") }}</span>
                  </div>

                  <div class="vx-col md:w-1/2 w-full">
                    <vs-input  name="address2" v-model="clientInfo.address.line2" class="w-full"
                      data-vv-as="Apt, Suite" label="Apt, Suite" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.address2')">{{ errors.first("clientInfoform.address2") }}</span>
                  </div>

                  
                  <div class="vx-col md:w-1/2 w-full">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">Country</label>
                      <multiselect name="clientcountry" v-validate="'required'" v-model="clientcountryModel"
                        @select="selectclientCountry" :show-labels="false" track-by="id" label="name"
                        data-vv-as="Country" placeholder="Select Country" :options="countries" :searchable="true"
                        :allow-empty="false"></multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.country')">{{ errors.first("clientInfoform.country") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">State</label>
                      <multiselect name="clientstate" v-validate="'required'" v-model="clientstateModel"
                        @select="selectclientState" :show-labels="false" track-by="id" label="name" data-vv-as="State"
                        placeholder="Select State" :options="clientstates" :searchable="true" :allow-empty="false">
                      </multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.state')">{{ errors.first("clientInfoform.state") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">City</label>
                      <multiselect name="clientcity" v-validate="'required'" v-model="clientlocationModel"
                        @select="selectclientLocation" :show-labels="false" track-by="id" label="name" data-vv-as="City"
                        placeholder="Select City" :options="clientlocations" :searchable="true" :allow-empty="false">
                      </multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.city')">{{ errors.first("clientInfoform.city") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <vs-input name="zipcode" v-model="clientInfo.address.zipcode"
                      v-validate="'numeric|required|min:5|max:6'" class="w-full" data-vv-as="Zip Code"
                      label="Zip Code" />

                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.zipcode')">{{ errors.first("clientInfoform.zipcode") }}</span>
                  </div>





                  <div class="vx-col md:w-1/2 w-full">

                  </div>
                </div>
              </div>
            </vs-col>
          </form>
        </tab-content>
        <!-- tab 4 content -->
        <tab-content title="Documents">
          <vs-col class="w-full p-0">
            <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">
              <p>Documents Needed</p>
              <ul  class="uploaded-list">
                <li>Resume</li>
                <li>10th / 12th Grade/Undergraduate/graduate degree(s) along with transcripts and any other certificates</li>
                <li>Experience letters</li>
                <li>INS Notices</li>
                <li>
                  Passport, along with Case and Form I-94 (clearly showing the dates of first and last entry into the
                  United States)
                </li>
                <li>3 Recent Pay Stubs and social security card and State professional license</li>
                <li>Both sides of your Form I –20, if currently on F-1 status, and EAD</li>
              </ul>
              <p>If you are currently in H-4 status, please provide copies of the following for your spouse:</p>
              <ul  class="uploaded-list">
                <li>Notice of Approval of H-1 status, along with visa, Form I-94, and 3 recent pay stubs</li>
                <li>Marriage Certificate</li>
              </ul>
            </vs-alert>
          </vs-col>

          <vs-col class="m-auto float-none pt-12" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8"
            vs-sm="12">
            <div class="form-container w-full">
              <h3 class="small-header">
                List of documents needs to be updated
                <span class="file-type">
                  (File Type: PDF,
                  DOC, JPEG, PNG. Max
                  file size: 1MB)
                </span>
              </h3>
              <div class="vx-row">
                <div class="vx-col w-full">
                  <label class="custom-label">Resume</label>
                  <file-upload v-model="documents.resume" class="file-upload-input"
                   name="resumeDocument" data-vv-as="Resume" :multiple="true" :hideSelected="true" 
                   accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                    @input="upload(documents.resume)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload</file-upload>
                    <span class="text-danger text-sm"
                      v-show="errors.has('resumeDocument')">{{ errors.first('resumeDocument') }}</span>
                  <ul  class="uploaded-list">
                    <vs-chip @click="remove(item, documents.resume)" v-for="(item, index) in documents.resume" :key="index" closable v-if="item.status"> {{ item.name }} </vs-chip>
                  </ul>
                  <!-- <vs-upload text="Upload" class="file-upload" action="https://jsonplaceholder.typicode.com/posts/"
                    @on-success="successUpload" data-vv-as="Resume" /> -->
                </div>
                <div class="vx-col w-full">
                  <label class="custom-label">
                    Education (10th / 12th Grade/Undergraduate/graduate degree(s) along with
                    transcripts and any other certificates)
                  </label>
                  <file-upload v-model="documents.education" class="file-upload-input" name="educationDocument" 
                  data-vv-as="Education (10th / 12th Grade/Undergraduate/graduate degree(s) along with
                    transcripts and any other certificates)" :multiple="true" :hideSelected="true" 
                    accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                     @input="upload(documents.education)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload </file-upload>
                     <span class="text-danger text-sm"
                      v-show="errors.has('educationDocument')">{{ errors.first('educationDocument') }}</span>
                  <ul  class="uploaded-list">
                    <vs-chip @click="remove(item, documents.education )" v-for="(item, index) in documents.education" :key="index" closable v-if="item.status"> {{ item.name }} </vs-chip>
                  </ul>
                  <!-- <vs-upload text="Upload" class="file-upload" action="https://jsonplaceholder.typicode.com/posts/"
                    @on-success="successUpload" data-vv-as="Education (10th / 12th Grade/Undergraduate/graduate degree(s) along with
                    transcripts and any other certificates)" /> -->
                </div>
                <div class="vx-col w-full">
                  <label class="custom-label">Experience Letters</label>
                  <file-upload v-model="documents.expLetters" class="file-upload-input" name="experienceDocument"
                   data-vv-as="Experience Letters" :multiple="true" :hideSelected="true" 
                   accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                   @input="upload(documents.expLetters)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload</file-upload>
                   <span class="text-danger text-sm"
                      v-show="errors.has('experienceDocument')">{{ errors.first('experienceDocument') }}</span>
                  <ul  class="uploaded-list">
                    <vs-chip @click="remove(item, documents.expLetters )" v-for="(item, index) in documents.expLetters" :key="index" closable  v-if="item.status==true" > {{ item.name }} </vs-chip>
                  </ul>
                  <!-- <vs-upload text="Upload" class="file-upload" action="https://jsonplaceholder.typicode.com/posts/"
                    @on-success="successUpload" data-vv-as="Experience Letters" /> -->
                </div>
                <div class="vx-col w-full">
                  <label class="custom-label">INS Notices</label>
                  <file-upload v-model="documents.INSNotices" class="file-upload-input" name="insNoticeDocument" data-vv-as="INS Notices"
                   :multiple="true" :hideSelected="true" accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                    @input="upload(documents.INSNotices)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload</file-upload>
                    <span class="text-danger text-sm"
                      v-show="errors.has('insNoticeDocument')">{{ errors.first('insNoticeDocument') }}</span>
                  <ul  class="uploaded-list">
                    <vs-chip @click="remove(item, documents.INSNotices )" v-for="(item, index) in documents.INSNotices" :key="index" closable  v-if="item.status==true"  > {{ item.name }} </vs-chip>
                  </ul>
                  <!-- <vs-upload text="Upload" class="file-upload" action="https://jsonplaceholder.typicode.com/posts/"
                    @on-success="successUpload" data-vv-as="INS Notices" /> -->
                </div>
                <div class="vx-col w-full">
                  <label class="custom-label">
                    Passport, along with Case and Form I-94 (clearly showing the dates of
                    first and last entry into the United States)
                  </label>
                  <file-upload v-model="documents.passportVisaI94" class="file-upload-input" name="passportVisaI94Document" 
                  data-vv-as="Passport, along with Visa and Form I-94 (clearly showing the dates of
                    first and last entry into the United States)" :multiple="true" :hideSelected="true" 
                    accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                     @input="upload(documents.passportVisaI94)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload </file-upload>
                     <span class="text-danger text-sm"
                      v-show="errors.has('passportVisaI94Document')">{{ errors.first('passportVisaI94Document') }}</span>
                  <ul  class="uploaded-list">
                    <vs-chip @click="remove(item, documents.passportVisaI94 )" v-for="(item, index) in documents.passportVisaI94" :key="index" closable  v-if="item.status==true" > {{ item.name }} </vs-chip>
                  </ul>
                </div>
                <div class="vx-col w-full">
                  <label class="custom-label">Form I –20 (if currently on F-1 status, and EAD)</label>
                  <file-upload v-model="documents.formI20" class="file-upload-input" name="formI20Document" data-vv-as="INS Notices" 
                  :multiple="true" :hideSelected="true" accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                   @input="upload(documents.formI20)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload </file-upload>
                   <span class="text-danger text-sm"
                      v-show="errors.has('formI20Document')">{{ errors.first('formI20Document') }}</span>
                  <ul  class="uploaded-list">
                    <vs-chip @click="remove(item, documents.formI20 )" v-for="(item, index) in documents.formI20" :key="index" closable  v-if="item.status"  > {{ item.name }} </vs-chip>
                  </ul>
                </div>
                <div class="vx-col w-full">
                  <label class="custom-label">Social security card and state professional license</label>
                  <file-upload v-model="documents.socialSecurityCardAndProfLicense" class="file-upload-input"
                  accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                   name="socialSecurityCardAndProfLicenseDocument" data-vv-as="INS Notices" :multiple="true" :hideSelected="true"
                    @input="upload(documents.socialSecurityCardAndProfLicense)"><img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload</file-upload>
                    <span class="text-danger text-sm"
                      v-show="errors.has('socialSecurityCardAndProfLicenseDocument')">{{ errors.first('socialSecurityCardAndProfLicenseDocument') }}</span>
                  <ul  class="uploaded-list">
                    <vs-chip @click="remove(item, documents.socialSecurityCardAndProfLicense )" v-for="(item, index) in documents.socialSecurityCardAndProfLicense" :key="index" closable  v-if="item.status"   > {{ item.name }} </vs-chip>
                  </ul>
                </div>
              </div>
            </div>
          </vs-col>
          <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </tab-content>
        <vs-popup class="holamundo success-popups" title="Your registration is complete."
          :active.sync="SuccessQuestionnaire">
          <figure>
            <img src="@/assets/images/main/icon-note.svg" alt="login" class="mx-auto" />
          </figure>
          <h2 class="title">Questionnaire submitted successfully!</h2>
          <p>It will be reviewed by the petitioner and appropriate actions will be taken soon.</p>
        </vs-popup>
      </form-wizard>
    </vx-card>
  </div>
</template>
<script>
  import { FormWizard, TabContent } from "vue-form-wizard";
  import "vue-form-wizard/dist/vue-form-wizard.min.css";
  import Datepicker from "vuejs-datepicker-inv";
  import moment from 'moment'
  import PhoneMaskInput from "vue-phone-mask-input";
  import JQuery from 'jquery';
  import { TheMask } from 'vue-the-mask';
  import FileUpload from "vue-upload-component/src";
  import _ from "lodash";
import Vue from 'vue'

  export default {
    // balu data
    data() {
      return {
        currentroute:this.$route.params.itemId,
        selectedcountryOfBirth:[],
        salaryOfferedType: [
          {
            id: 1,
            name: "Per Month"
          },
          {
            id: 2,
            name: "Per Year"
          }
        ],
        resumeDocs: [],
        educationDocs: [],
        experienceDocs: [],
        insNoticeDocs: [],
        passportVisaI94Docs: [],
        formI20Docs: [],
        socialSecurityCardAndProfLicenseDocs: [],
        childDocumentArray: [{
          childVisaDocs: [],
          childPassportDocs: [],
          childFormI94Docs: [],
          childBirthCertificateDocs: [],
        }],
        childVisaDocs: [],
        childPassportDocs: [],
        childFormI94Docs: [],
        childBirthCertificateDocs: [],
        visaDocuments: [],
        formI94Docs: [],
        formI797Docs: [],
        marriageCertificateDocs: [],
        birthCertificateDocs: [],
        openDate: new Date().setFullYear(new Date().getFullYear() - 18),
        startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
        SuccessQuestionnaire: false,
        formerrors: {
          msg: ""
        },
        petition: [],
        beneficiaryInfo: {
          gender: null,
          maritalStatus: null,
          education: {
            highestDegree: "",
            majorFieldOfStudy: ""
          },
          address: {},
          hasI140ImmPetitionfiltered: true
        },
        clientInfo: {
          address: {}
        },
        dependentsInfo: {
          spouse: {
            h4Required: true,
            aboardAddress: {

            },
            documents: {
              passportAndVisa: [],
              formI94: [],
              formI797: [],
              marriageCertificate: [],
              birthCertificate: []
            }
          },
          childrens: [{
            documents: {
              passport: [],
              visa: [],
              formI94: [],
              birthCertificate: []
            }
          }]
        },
        documents: {
          resume: [],
          education: [],
          expLetters: [],
          INSNotices: [],
          passportVisaI94: [],
          formI20: [],
          socialSecurityCardAndProfLicense: []
        },
        bncountryModel: [],
        clientInfo_salaryFrequency_Details:[],
        countries: [],
        states: [],
        clientstates: [],
        stateModel: [],
        locations: [],
        locationModel: [],
        marital_statuses: [],
        education_types: [],
        visastatuses: [],
        clientcountryModel: [],
        clientstateModel: [],
        clientlocationModel: [],
        clientlocations: [],
        spousecountryModel: [],
        chiildcountryModel: [],
        priorstay: {
          enteredDate: null,
          departedDate: null,
          visaStatus: null
        },
        priorPeriodOfStayInUS: [],
        childrensarray: [],
        children: [{
          "h4Required": true,
          "firstName": null,
          "middleName": null,
          "lastName": null,
          "dateOfBirth": null,
          "countryOfBirth": null,
          selectedcountryOfBirth:null,
          "passportNumber": null,
          "passportExpiryDate": null,
          "I94": null,
          "visaIssuedDate": null,
          "currentStatus": null,
          "statusExpiryDate": null,
          "documents": {
          }
        }],
        countrySelected: '',
        startBeneficiaryDateEntered: new Date().setFullYear(new Date().getFullYear() - 7),
      };
    },
    methods: {

      selectedsalaryOfferedType(option){
        //alert(this.clientInfo.salaryFrequency);

      },

      isDisabled(model) {
        if (model && model.length == 1) return false;
        return true;
      },
      acceptNumber() {
        var x = this.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
        this.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
      },
      selectLocation(option) {
        this.beneficiaryInfo.address.locationId = option.id;
      },
      selectclientLocation(option) {
        this.clientInfo.address.locationId = option.id;
      },
      selectclientState(option) {
        this.clientInfo.address.stateId = option.id;
        this.clientlocationModel = [];
        this.getclientLocation();
      },
      selectclientCountry(option) {
        this.clientInfo.address.countryId = option.id;
        this.getclientStates();

      },
      selectState(option) {
        this.beneficiaryInfo.address.stateId = option.id;
        this.locationModel = [];
        this.getLocation();
      },
      selectCountry(option) {
        this.beneficiaryInfo.address.countryId = option.id;
        this.getStates();
      },
      getclientStates() {
        this.$store
          .dispatch("getstates", this.clientInfo.address.countryId)
          .then(response => {
            this.clientstates = response;
          });
      },
      //get_salary_frequencies
      getSalary_frequencies() {
        this.$store
          .dispatch("get_salary_frequencies", this.clientInfo.address.countryId)
          .then(response => {
            this.salaryOfferedType = response;
          });
      },

      getStates() {
        this.$store
          .dispatch("getstates", this.beneficiaryInfo.address.countryId)
          .then(response => {
            this.states = response;
          });
      },
      getclientLocation() {
        var obj = {
          stateId: this.clientInfo.address.stateId,
          countryId: this.clientInfo.address.countryId
        };

        this.$store.dispatch("getlocations", obj).then(response => {
          this.clientlocations = response;
        });
      },
      getLocation() {
        var obj = {
          stateId: this.beneficiaryInfo.address.stateId,
          countryId: this.beneficiaryInfo.address.countryId
        };

        this.$store.dispatch("getlocations", obj).then(response => {
          this.locations = response;
        });
      },
      beforeTabSwitch() {
         return this.validateStep("beneficiaryInfoform");
        // return true;
      },
      beforeClient() {


       // return true;
         return this.validateStep("clientInfoform");
      },
      beforeDependents() {
      //  this.dependentsInfo.childrens = this.childrensarray;

        Object.assign(this.dependentsInfo.childrens,this.childrensarray)


         //return true;
         return this.validateStep("dependentsInfoform");
      },
      async validateStep(step) {
        const result = await this.$validator.validateAll(step).then(result => {
          return result;
        });
       // alert(result);
        if (result) {
          this.$validator.reset();
          window.scroll({
            top: 0,
            left: 0,
            behavior: 'smooth'
          })
        } else {
          const $ = JQuery

          const firstField = Object.keys(this.errors.collect())[0];
          const ele = $('[name=' + firstField + ']').parents('.vx-col');
          $('html, body').animate({ scrollTop: ele.offset().top }, 2000);
          // this assumes you have a conviention of ref and field name here I just add the
          // Input suffix to the field name as you can see in the template.
          //  this.$refs[`${firstField}Input`].scrollIntoView();
        }
        return result;
      },
      setGender(item) {
        this.beneficiaryInfo.gender = item;
      },
      successUpload() {



      },
      addpriorstay: function () {
        this.priorstay = {
          enteredDate: null,
          departedDate: null,
          visaStatus: null
        }
        this.priorPeriodOfStayInUS.push(this.priorstay);
      },
      removepriorstay: function (index) {
        Vue.delete(this.priorPeriodOfStayInUS, index)
      },
      addchildren: function () {
        this.children = {
          "h4Required": true,
          "firstName": null,
          "middleName": null,
          "lastName": null,
          "dateOfBirth": null,
          "countryOfBirth": null,
          "passportNumber": null,
          "passportExpiryDate": null,
          "I94": null,
          "visaIssuedDate": null,
          "currentStatus": null,
          "statusExpiryDate": null,
          "documents": {
            "passportDocs": [],
            "visaDocs": [],
            "FormI94Docs": [],
            "birthCertificateDocs": []
          }
        },
        this.childrensarray.push(this.children);
      },
      removechildren: function (index) {
        Vue.delete(this.childrensarray, index)
      },
      reloadthePage() {

          let routeTest = this.$route.params.itemId
          this.$router.push({ name: 'petition-details', params: { routeTest } }).catch(err => {})


      },
      formSubmitted() {

        var postpetition = {
          petitionId: this.$route.params.itemId,
          questionnaireFilled: true,
          userName: this.$store.state.user.name,
          typeName: this.petition.typeDetails.name,
          subTypeName: this.petition.subTypeDetails.name,
          action: "SUBMIT_QUESTIONNAIRE",
          currentDate: moment().format('YYYY-MM-DD'),
          beneficiaryInfo: this.beneficiaryInfo,
          dependentsInfo: this.dependentsInfo,
          clientInfo: this.clientInfo,
          documents: this.documents,
          questionnaireUpdate:true
        }
        postpetition.beneficiaryInfo.priorPeriodOfStayInUS = this.priorPeriodOfStayInUS;
        this.$store
          .dispatch("petitioner/petitionupdate", postpetition)

          .then(response => {

            if (response.error) {
              Object.assign(this.formerrors, {
                msg: response.error.message
              });
            } else {
              this.$vs.notify({
                title: "Success",
                
                position: "top-right",
                color: "primary",
                text: response.message
              });
              this.SuccessQuestionnaire = true;

              document.addEventListener('click', this.reloadthePage);
            }

            // this.petitioners = response.list;
          });



      },
      // balu functions
      upload(model) {
        let formData = new FormData();
        model = model.map(item => item = {
          name: item.name,
          file: item.file,
          url: "",
          mimetype: item.type,
          status:item.status===null || item.status===undefined?true:item.status,
          uploadedBy:this.checkProperty(this.getUserData,'userId'),
          uploadedByName:this.checkProperty(this.getUserData,'name'),
          uploadedByRoleId:this.getUserRoleId,
          uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
        })
        if(model.length > 0){
          model.forEach(doc=> {
            formData.append('files', doc.file);
            formData.append('secureType', 'private');
            this.$store.dispatch('uploadS3File', formData).then(response=> {
              response.data.result.forEach(urlGenerated=> {
                doc.url = urlGenerated;
              })
              delete doc.file;
            });
          })
        }
      },
      remove(item, type ) {
       // type.splice(type.indexOf(item), 1)
        //alert(item_index);
        item['status']=false;
       // type[item_index]['status'] =false;
        return false;
      },
      selectchildCountry(option,id){


      this.childrensarray[id].countryOfBirth = option.id;
      },
      selectspouseCountry(option) {
        this.dependentsInfo.spouse.countryOfBirth = option.id;
      }
    },
    
   beforeDestroy(){
              document.removeEventListener('click', this.reloadthePage);
   },
    mounted() {

  
      this.priorPeriodOfStayInUS = [
        {
          enteredDate: null,
          departedDate: null,
          visaStatus: null
        }
      ];
      this.childrensarray = [
        {
          "h4Required": true,
          "firstName": null,
          "middleName": null,
          "lastName": null,
          "dateOfBirth": null,
          "countryOfBirth": null,
          "passportNumber": null,
          "passportExpiryDate": null,
          "I94": null,
          "visaIssuedDate": null,
          "currentStatus": null,
          "statusExpiryDate": null,
          "documents": {
            "passportDocs": [],
            "visaDocs": [],
            "FormI94Docs": [],
            "birthCertificateDocs": []
          }
        }
      ];
      this.beneficiaryInfo.firstname = this.$store.state.user.name;
      this.beneficiaryInfo.email = this.$store.state.user.email;
      this.$store.dispatch("getmasterdata", "visa_status").then(response => {
        this.visastatuses = response;
      });
      this.$store.dispatch("getmasterdata", "marital_status").then(response => {
        this.marital_statuses = response;
      });

      this.$store.dispatch("getmasterdata", "education_types").then(response => {
        this.education_types = response;
      });
      this.$store.dispatch("getcountries").then(response => {
        this.countries = response;
      });
      this.$store.dispatch("getpetition", this.$route.params.itemId).then(response => {
        
        this.petition = response.data.result;

        this.beneficiaryInfo = this.petition.beneficiaryInfo;
        //alert(this.beneficiaryInfo.address.countryId);
        this.dependentsInfo =this.petition .dependentsInfo;
        this.clientInfo =this.petition .clientInfo;
        this.documents = this.petition .documents;

        this.selectCountry(this.beneficiaryInfo.address.countryDetails);
        this.selectState(this.beneficiaryInfo.address.stateDetails);
        this.bncountryModel = this.beneficiaryInfo.address.countryDetails
        this.stateModel = this.beneficiaryInfo.address.stateDetails
        this.locationModel =this.beneficiaryInfo.address.locationDetails;

        //selectclientLocation

        this.selectclientCountry(this.clientInfo.address.countryDetails);
        this.selectclientState(this.clientInfo.address.stateDetails);
        this.selectclientLocation(this.clientInfo.address.locationDetails);
        this.clientcountryModel = this.clientInfo.address.countryDetails
        this.clientstateModel = this.clientInfo.address.stateDetails
        this.clientlocationModel =this.clientInfo.address.locationDetails;

        this.clientInfo_salaryFrequency_Details = this.clientInfo.salaryFrequencyDetails;



        //salaryFrequency

//locationDetails
      });

      this.getSalary_frequencies();
    },
    components: {
      FormWizard,
      TabContent,
      Datepicker,
      PhoneMaskInput,
      TheMask,
      FileUpload
    }
  };
</script>
