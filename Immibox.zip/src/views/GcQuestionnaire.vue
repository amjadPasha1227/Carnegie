<template>
  <petitionform  />
</template>

<script>
import petitionform from "./forms/gcapplication.vue";

export default {
  components: {
    petitionform
  }
}
</script>