<template>
  <div>
    <div class="profile-container">
      <div class="profile-container-left">
        <div class="profile-top">
          <div class="profile-info">
            <div class="con-vs-avatar">
              <figure><img :src="checkProperty(getUserData, 'profilePicture')" @error="setDefaultPhoto($event)" />
              </figure>
              <file-upload v-model="profilePicture" :multiple="false" accept="image/*" name="profilePicture"
                @input="upload(profilePicture)">
                <vs-button radius color="warning" type="filled" icon-pack="IntakePortal">
                  <img @click="logoUploading = false" v-if="!logoUploading" src="@/assets/images/main/pencil.svg" />
                  <img v-if="logoUploading" src="@/assets/images/main/loader.gif">
                </vs-button>
              </file-upload>
            </div>
          </div>
          <div class="profile-info-bottom">
            <h3>
              {{ checkProperty(userDetails, "details", "name") }}
              <span>{{
                checkProperty(userDetails, "roleDetails", "name")
              }}</span>
            </h3>
            <button class="btn editprofile" style="cursor: pointer"
              @click="initProfileData(); editProfile = true; $modal.show('editProfilePopupModal')">
              Edit Profile
            </button>
          </div>
        </div>
        <div class="profile-bottom">
          <button class="btn change_password" @click="opensetPwd()">
            Change Password
          </button>
        </div>
      </div>
      <div class="profile-container-right">
        <div>
          <h3 class="small-header">General Information</h3>
          <div class="main-list-wrap">
            <div class="vx-row m-0 main-list-panel">
              <div class="vx-col lg:w-1/3 md:w-1/2 w-full p-0" v-if="checkProperty(userDetails, 'details', 'email')">
                <div class="main-list">
                  <p>
                    First Name<span>{{ checkProperty(userDetails, "details", "firstName") }}</span>
                  </p>
                </div>
              </div>
              <div class="vx-col lg:w-1/3 md:w-1/2 w-full p-0" v-if="checkProperty(userDetails, 'details', 'middleName')">
                <div class="main-list">
                  <p>
                    Middle Name<span>{{ checkProperty(userDetails, 'details', 'middleName') }}</span>
                  </p>
                </div>
              </div>
              <div class="vx-col lg:w-1/3 md:w-1/2 w-full p-0" v-if="checkProperty(userDetails, 'details', 'lastName')">
                <div class="main-list">
                  <p>
                    Last Name<span>{{ checkProperty(userDetails, 'details', 'lastName') }}</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="vx-row m-0 main-list-panel">
              <div class="vx-col lg:w-1/3 md:w-1/2 w-full p-0" v-if="checkProperty(userDetails, 'details', 'email')">
                <div class="main-list">
                  <p>
                    Email<span>{{
                      checkProperty(userDetails, "details", "email")
                    }}</span>
                  </p>
                </div>
              </div>
              <div class="vx-col lg:w-1/3 md:w-1/2 w-full p-0" v-if="checkProperty(userDetails, 'details', 'phone')">
                <div class="main-list">
                  <p>
                    Phone Number<span>{{
                      checkProperty(userDetails["details"], "phoneCountryCode", 'countryCallingCode'
                      ) ? checkProperty(userDetails["details"], "phoneCountryCode", 'countryCallingCode') + ' ' : ''
                    }}{{
  checkProperty(userDetails, "details", "phone")
}}</span>
                  </p>
                </div>
              </div>
              <div class="vx-col lg:w-1/3 md:w-1/2 w-full p-0" v-if="userDetails.createdOn">
                <div class="main-list">
                  <p>
                    Member Since<span>{{ userDetails.createdOn | formatDate }}</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
          <!-- <div v-if="checkProperty(userDetails.details ,'address') && checkProperty(userDetails.details ,'address' ,'countryId')" class="divider divider-double mt-0"></div> -->
          <!-- <h3 v-if="checkProperty(userDetails.details ,'address') && checkProperty(userDetails.details ,'address' ,'countryId')" class="small-header">Address</h3> -->
          <div
            v-if="checkProperty(userDetails.details, 'address') && checkProperty(userDetails.details, 'address', 'countryId')"
            class="main-list-wrap">
            <div class="vx-row m-0 main-list-panel">
              <div class="vx-col lg:w-1/3 md:w-1/2 w-full p-0">
                <div class="main-list">
                  <p>
                    Address
                    <span>{{ checkProperty(userDetails, 'details', 'address') | addressformat }}</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
          <template
            v-if="((checkProperty(userDetails, 'defaultCaseAssignConfig') && checkProperty(userDetails, 'defaultCaseAssignConfig', 'subTypeDetails')
              && checkProperty(userDetails['defaultCaseAssignConfig'], 'subTypeDetails', 'length') > 0) || checkProperty(userDetails, 'manageCapRegistration') == true) ">
            <h3 class="small-header">Case Types and Cap Registrations which can manage</h3>
            <div class="vx-row m-0 pt-4 main-list-panel">
              <ul class="uploaded-list note_uploads note_uploads-v2">
                <template v-if="checkProperty(userDetails, 'defaultCaseAssignConfig') && checkProperty(userDetails, 'defaultCaseAssignConfig', 'subTypeDetails')
                  && checkProperty(userDetails['defaultCaseAssignConfig'], 'subTypeDetails', 'length') > 0">
                  <template v-for="(item, index) in userDetails['defaultCaseAssignConfig']['subTypeDetails']">
                    <vs-chip>
                      {{ item.name }}
                    </vs-chip>
                  </template>
                </template>
                <template v-if="checkProperty(userDetails, 'manageCapRegistration') == true">
                  <vs-chip>
                    {{ "Cap Registrations" }}
                  </vs-chip>
                </template>
              </ul>
            </div>
          </template>

          <template v-if="getUserRoleId == 6">
            <h3 class="small-header">Licensing Authority States</h3>
            <div class="main-list-wrap">
              <div class="vx-row m-0 main-list-panel">
                <div class="vx-col lg:w-1/2 md:w-1/2 w-full p-0" v-for="( lstate, ind) in templicensingAuthorityStates"
                  :key="ind">
                  <div class="main-list Licensing_blocks">
                    <p>
                      <a>State</a> <span>{{ checkProperty(lstate, "stateDetails", "name") }}</span>
                    </p>
                    <p>
                      <a>Bar Number</a> <span>{{ checkProperty(lstate, "barNumber") }}</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </template>

        </div>
      </div>


    </div>
    <vs-popup class="holamundo main-popup" title="Change Password" :active.sync="SetPassword">
      <form>
        <div class="popup-accounts-content edit_password" v-if="SetPassword">
          <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">
              {{ formerrors.msg }}
            </vs-alert>
          </div>
          <div class="form-container">
            <div class="form_group">
              <!-- <i class="placeholder-icon IP-hide-1"></i> -->
              <label class="form_label">Current Password<em>*</em></label>
              <vs-input type="password" v-validate="'required'" data-vv-as="Current Password" name="currentPassword"
                v-model="currentPassword" class="w-full no-icon-border" />
              <span class="text-danger text-sm" v-show="errors.has('currentPassword')">{{ errors.first("currentPassword")
              }}<br /></span>
            </div>
            <div class="form_group">
              <!-- <i class="placeholder-icon IP-hide-1"></i> -->
              <label class="form_label">New Password<em>*</em></label>
              <vs-input type="password" v-validate="'required|min:6|max:15|strongpassword'" data-vv-as="New Password"
                v-model="newPassword" name="newPassword" class="w-full no-icon-border" />
              <span class="text-danger text-sm" v-show="errors.has('newPassword')">{{
                errors.first("newPassword")
              }}</span>
            </div>
          </div>
          <div class="popup-footer justify-between">
            <div class="password-count">
              <i class="icon IP-lock"></i> Password must contain 6 to 15 characters
            </div>
            <div class="d-flex">
              <vs-button color="dark" @click="SetPassword = false" class="cancel" type="filled">Cancel</vs-button>

              <vs-button class="save" type="filled" @click="changePassword">Update</vs-button>
            </div>
          </div>
        </div>
      </form>
    </vs-popup>

    <modal name="editProfilePopupModal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="750px" height="auto">
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">Edit Profile</h2>
          <span @click="editProfile = false; $modal.hide('editProfilePopupModal');">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form>
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">

                  <label for class="form_label">First Name<em>*</em></label>
                  <vs-input autocomplete="off" autocorrect="off" v-validate="'required'" name="firstName"
                    v-model="profileUpdateData.firstName" class="w-full" data-vv-as="First Name" />

                  <span class="text-danger text-sm" v-show="errors.has('firstName')">{{
                    errors.first("firstName")
                  }}</span>
                </div>
              </div>
              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">
                  <label class="form_label">Middle Name</label>
                  <vs-input name="middleName" v-model="profileUpdateData.middleName" class="w-full"
                    data-vv-as="Middle Name" />
                  <span class="text-danger text-sm" v-show="errors.has('middleName')">{{
                    errors.first("middleName")
                  }}</span>
                </div>
              </div>
              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">

                  <label for class="form_label">Last Name<em>*</em></label>
                  <vs-input name="lastName" v-model="profileUpdateData.lastName" class="w-full" v-validate="'required'"
                    data-vv-as="Last Name" />
                  <span class="text-danger text-sm" v-show="errors.has('lastName')">{{
                    errors.first("lastName")
                  }}</span>
                </div>
              </div>
              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group ph_number">
                  <label class="form_label">Phone Number<em>*</em></label>
                  <div class="vs-component">
                    <VuePhoneNumberInput icon-pack="feather" class="w-full no-icon-border" :no-example="false"
                      data-vv-as="Phone Number" v-validate="'required'" v-bind="vuePhone.props" name="companyfaxphone"
                      :default-country-code="
                        checkProperty(
                          profileUpdateData, 'phoneCountryCode',
                          'countryCode'
                        )
                      " placeholder="Company Fax Number" :no-country-selector="false" v-model="profileUpdateData.phone"
                      @update="updatePhone" :preferred-countries="['US', 'IN']" />
                    <span class="text-danger text-sm" v-show="!isPhoneValid && !errors.has('companyfaxphone')">*Invalid
                      phone number - Please enter a valid one</span>
                    <span class="text-danger text-sm" v-show="errors.has('companyfaxphone')">{{
                      errors.first("companyfaxphone")
                    }}</span>

                  </div>
                </div>
              </div>
            </div>   
           
            <!-- <div  class="vx-col w-full">
              <addressField 
                
                :fieldsArray="[]" :disableCountry="false" formscope="" :showaptType="true" :addFormContainerCls="false" :validationRequired="true" :countries="countries" 
                v-model="profileUpdateData.address" :tplsection="''"  :fieldName="'address'"  :cid="'beneficiaryInfoaddress'" />
            </div>       -->
          
            <div class="vx-row">
              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">

                  <label for class="form_label">Street Address<em>*</em></label>
                  <vs-input autocomplete="off" autocorrect="off" name="address1" v-model="profileUpdateData.address.line1"
                    class="w-full" data-vv-as="Street Address" v-validate="'required'" />

                  <span class="text-danger text-sm" v-show="errors.has('address1')">{{
                    errors.first("address1")
                  }}</span>
                </div>
              </div>

              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">

                  <label for class="form_label">Apt, Suite</label>
                  <vs-input name="address2" v-model="profileUpdateData.address.line2" class="w-full"
                    data-vv-as="Apt, Suite" />
                  
                </div>
              </div>

              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">
                  <label for class="form_label">Country<em>*</em></label>
                  <div class="con-select w-full">
                    <multiselect name="addresscountry" v-model="profileUpdateData.address.selectedCountry"
                      @input="changedCountry" :show-labels="false" track-by="id" label="name" v-validate="'required'"
                      data-vv-as="Country" placeholder="Select Country" :options="countries" :searchable="true"  :disabled=" loading"
                      :allow-empty="false" ref="bncountry"></multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('addresscountry')">{{
                    errors.first("addresscountry") }}</span>
                </div>
              </div>
              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">
                  <label for class="form_label">State<em v-if="states.length > 0">*</em></label>
                  <div class="con-select w-full">
                    <multiselect name="State" v-model="profileUpdateData.address.selectedState" @input="changedState"
                      :show-labels="false" track-by="id" label="name" v-validate="{ 'required': states.length > 0 }"
                      data-vv-as="State" placeholder="Select State" :options="states" :searchable="true"  :disabled=" loading || states.length == 0"
                      :allow-empty="false">
                    </multiselect>
                  </div>

                  <span class="text-danger text-sm" v-show="errors.has('State')">{{
                    errors.first("State")
                  }}</span>
                </div>
              </div>
              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">
                  <label for class="vs-select--label">City<em v-if="locations.length > 0">*</em></label>
                  <div class="con-select w-full">
                    <multiselect name="city" v-model="profileUpdateData.address.selectedCity" @input="changedCity"
                      :show-labels="false" track-by="id" label="name" v-validate="{ 'required': locations.length > 0 }"
                      data-vv-as="City" placeholder="Select City" :options="locations" :searchable="true" 
                      :disabled=" loading|| profileUpdateData.address.selectedState==null || profileUpdateData.address.selectedCountry==null "
                      :allow-empty="false">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('city')">{{
                    errors.first("city")
                  }}</span>
                </div>
              </div>
              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">
                  <label for class="form_label">Zip Code<em>*</em></label>
                  <vs-input name="zipcode" v-model="profileUpdateData.address.zipcode"
                    v-validate="'required|allowNumAndCharInZipcode:bncountry|zipcodev:bncountry'" class="w-full" data-vv-as="Zip Code"
                    @input="checkZipCodeFormat()"
                     />
                  <span class="text-danger text-sm" v-show="errors.has('zipcode')">{{
                    errors.first("zipcode")
                  }}</span>
                </div>
              </div>
            </div>

            <!-- oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');" -->
            <template v-if="getUserRoleId == 6">

              <template v-for="(state, index) in licensingAuthorityStates">
                <div :key="index" class="vx-row delete-row">

                  <div class="vx-col w-1/2">
                    <div class="form_group">
                      <div class="con-select w-full">
                        <label for class="vs-select--label">Licensing Authority<em>*</em></label>

                        <multiselect v-model="state.stateDetails" :options="allUsstates" :multiple="false"
                          :hideSelected="true" :close-on-select="false" :clear-on-select="true" :preserve-search="true"
                          :select-label="''" placeholder="Select Authority States " label="name" track-by="_id"
                          :preselect-first="false" v-validate="'required'" :name="'licensingAuthorityStates_' + index"
                          data-vv-as="Licensing Authority State" @input="filterStates">
                          <template slot="selection" slot-scope="{ values, isOpen }">
                            <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                              State(s) selected</span>
                            <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                          </template>
                        </multiselect>


                      </div>
                      <span class="text-danger text-sm" v-show="errors.has('licensingAuthorityStates_' + index)">{{
                        errors.first('licensingAuthorityStates_' + index) }}</span>
                    </div>
                  </div>

                  <div class="vx-col w-1/2 add_licensing">
                    <div class="form_group">
                      <label class="form_label">Bar Number<em>*</em></label>
                      <vs-input v-model="state.barNumber" :name="'barNumber' + index" v-validate="'required|max:15'"
                        class="w-full" data-vv-as="Bar Number"
                        oninput="this.value = this.value.replace(/[^a-z A-Z 0-9  ]/g, '');" />
                      <span class="text-danger text-sm" v-show="errors.has('barNumber' + index)">{{
                        errors.first("barNumber" + index) }}</span>
                    </div>
                    <div class="delete" v-if="licensingAuthorityStates.length > 1">
                      <a @click="removeAttornyState(index)"> <img src="@/assets/images/main/delete-row-img.svg" /></a>
                    </div>
                  </div>



                </div>


              </template>
              <div class="vx-row">

                <div class="vx-col w-1/3 ">
                  <a class="add-more d-inline-flex" @click="addAttornyState(index)"><span class="mr-2">+</span>Add
                    More</a>
                </div>
              </div>
            </template>

          </div>
          <div class="popup-footer">
            <vs-button color="dark" @click="editProfile = false; $modal.hide('editProfilePopupModal')" class="cancel"
              type="filled">Cancel</vs-button>
            <vs-button class="save" type="filled" @click="updateProfile">Update</vs-button>
          </div>
        </form>
      </div>
    </modal>




    <vs-popup class="Change_petition_wrap" v-bind:title="'Update Profile'" :active.sync="updateStatus">
      <div class="Change_petition">
        <div class="vx-col w-full marb10">
          <h3 class="text-center">{{ res_msg }}</h3>
        </div>
      </div>
      <div class="actions_footer">
        <button @click="updateStatus = false" class="btn cancel">Close</button>
      </div>
    </vs-popup>

  </div>
</template>

<script>
import addressField from "@/views/forms/fields/address.vue";
import { CheckCircleIcon } from "vue-feather-icons";
import FileUpload from "vue-upload-component/src";
import PhoneMaskInput from "vue-phone-mask-input";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
export default {
  provide() {
            return {
                parentValidator: this.$validator,
            };
        },
  methods: {
    addLocation(newTag=''){
      if(!newTag){
       return false;
      }
      this.loading = true;
      this.$store
        .dispatch("addLocations", {
          name: newTag,
          
          stateId: this.checkProperty(this.profileUpdateData['address'],'selectedState','id'),
        })
        .then((response) => {
          var tag = response;
          this.locations.push(response);
          thisprofileUpdateData.address.selectedCity = response;
          this.loading = false;
         
        })
        .catch((error) => {
          this.loading = false;
         
          
        });
    },
    checkZipCodeFormat(){
     
     //this.value = this.value.replace(/[^a-z A-Z 0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');
     if( this.profileUpdateData.address.selectedCountry && this.profileUpdateData.address.zipcode ){
         if(this.checkProperty(this.profileUpdateData.address.selectedCountry ,'allowNumAndCharInZipcode')==true){
           this.profileUpdateData.address.zipcode = this.profileUpdateData.address.zipcode.replace(/[^a-z A-Z 0-9]/g, '').replace(/(\..*)\./g, '$1');
         }else{
           this.profileUpdateData.address.zipcode = this.profileUpdateData.address.zipcode.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');
         }
     }

   },
    filterStates() {
      // this.allUsstates = response.list;
      //  this.allUsstatesTemp
      this.allUsstates = _.cloneDeep(this.allUsstatesTemp);

      let self = this;
      if (this.licensingAuthorityStates.length > 0) {
        let selectedStates = this.licensingAuthorityStates.map((item) => {

          return self.checkProperty(item, 'stateDetails', 'id')
        })

        this.allUsstates = _.filter(self.allUsstatesTemp, (state) => {
          return selectedStates.indexOf(state['id']) <= -1
        })



      }

    },
    addAttornyState() {

      this.licensingAuthorityStates.push(

        {
          stateDetails: null,
          barNumber: ''
        }
      )
    },
    removeAttornyState(index) {
      this.licensingAuthorityStates.splice(index, 1);
      this.filterStates();

    },



    opensetPwd() {
      Object.assign(this.formerrors, { msg: '' });
      this.currentPassword = ''
      this.newPassword = '';
      this.SetPassword = true;
      this.$validator.reset();
    },
    updatePhone(item) {
      this.isPhoneValid = true;
      if (item.isValid) {
        this.profileUpdateData.phoneCountryCode = {
          countryCode: item.countryCode,
          countryCallingCode: item.countryCallingCode,
        };
        this.profileUpdateData.phone = item.nationalNumber;
      } else {
        this.isPhoneValid = false;
      }
    },
    updateFax(item) {
      if (item.isValid) {
        this.profileUpdateData.faxCountryCode = {
          countryCode: item.countryCode,
          countryCallingCode: item.countryCallingCode,
        };
        this.profileUpdateData.fax = item.nationalNumber;
      }
    },
    changedCountry() {
      this.states = [];
      this.locations = [];
      this.profileUpdateData.address.selectedCity = null;
      let dataKey = "profileUpdateData";

      if (_.has(this[dataKey].address.selectedCountry, "id")) {
        this[dataKey].address.countryId =
          this[dataKey].address.selectedCountry["id"];

        this.masterData("states");
      }
      this.profileUpdateData.address.zipcode = '';
    },
    changedState() {
      let dataKey = "profileUpdateData";

      this.locations = [];
      if (_.has(this[dataKey].address.selectedState, "id")) {
        this[dataKey].address.stateId =
          this[dataKey].address.selectedState["id"];
        this.masterData("locations");
      }
    },
    //locationId
    changedCity() {
      let dataKey = "profileUpdateData";

      if (_.has(this[dataKey].address.selectedCity, "id")) {
        this[dataKey].address.locationId =
          this[dataKey].address.selectedCity["id"];
        this.masterData("locations");
      }
    },
    masterData(category = "countries") {
      let matcher = {};
      let postData = {
        matcher: matcher,
        page: 1,
        perpage: 1000,
        category: category,
      };

      let dataKey = "profileUpdateData";
      if (category == "states") {
        matcher = { countryId: this[dataKey].address.selectedCountry["id"] };
      }
      if (category == "locations") {
        matcher = { stateId: this[dataKey].address.selectedState["id"] };
      }
      postData["matcher"] = matcher;
      this.loading = true;
      this.$store
        .dispatch("getMasterData", postData)
        .then((res) => {
          //countries
          if (category == "countries") {
            this.countries = res["list"];

            //alert(JSON.stringify(this.countries))
          }
          if (category == "states") {
            this.states = res["list"];
            this[dataKey]["address"].selectedState = _.find(this.states, {
              id: this[dataKey]["address"]["stateId"],
            });
            this.changedState();
          }
          if (category == "locations") {
            this.locations = res["list"];
            this[dataKey]["address"].selectedCity = _.find(this.locations, {
              id: this[dataKey]["address"]["locationId"],
            });
          }
          this.loading = false;
        })
        .catch((err) => {
          this[category] = [];
          this.loading = false;
        });
    },
    initProfileData() {
      this.profileUpdateData = {
        userId: this.getUserData["userId"],
        name: "",
        phone: "",
        phoneCountryCode: { countryCode: "", countryCallingCode: "" },
        firstName: "",
        middleName: "",
        lastName: "",
        fax: "",
        faxCountryCode: { countryCode: "", countryCallingCode: "" },
        address: {
          line1: "",
          line2: "",
          locationId: null,
          stateId: null,
          countryId: null,
          zipcode: "",
          selectedCountry: null,
          selectedState: null,
          selectedCity: null,
        },
      };
      if (_.has(this.userDetails, "details")) {
        let details = this.userDetails["details"];
        //alert(JSON.stringify(details))
        if (this.checkProperty(details, "name"))
          this.profileUpdateData["name"] = details.name;

        if (this.checkProperty(details, "phone"))
          this.profileUpdateData["phone"] = details.phone;

        if (this.checkProperty(details, "phoneCountryCode"))
          this.profileUpdateData["phoneCountryCode"] = details.phoneCountryCode;

        if (this.checkProperty(details, "firstName"))
          this.profileUpdateData["firstName"] = details.firstName;

        if (this.checkProperty(details, "middleName"))
          this.profileUpdateData["middleName"] = details.middleName;

        if (this.checkProperty(details, "lastName"))
          this.profileUpdateData["lastName"] = details.lastName;

        if (this.checkProperty(details, "fax"))
          this.profileUpdateData["fax"] = details.fax;

        if (this.checkProperty(details, "faxCountryCode"))
          this.profileUpdateData["faxCountryCode"] = details.faxCountryCode;

        if (_.has(details, "address", "line1"))
          this.profileUpdateData["address"]["line1"] =
            details["address"]["line1"];

        if (_.has(details, "address", "line2"))
          this.profileUpdateData["address"]["line2"] =
            details["address"]["line2"];

        if (_.has(details, "address", "zipcode"))
          this.profileUpdateData["address"]["zipcode"] =
            details["address"]["zipcode"];

        if (_.has(details, "address", "locationId"))
          this.profileUpdateData["address"]["locationId"] =
            details["address"]["locationId"];

        if (_.has(details, "address", "stateId"))
          this.profileUpdateData["address"]["stateId"] = details["address"]["stateId"];

        if (_.has(details, "address", "countryId"))
          this.profileUpdateData["address"]["countryId"] = details["address"]["countryId"];
         

        // selectedCountry: null,
        //   selectedState: null,
        //   selectedCity: null,
        if (_.has(details, "address", "countryDetails"))
          this.profileUpdateData["address"]["selectedCountry"] = details["address"]["countryDetails"];
          this.masterData("states");
        if (_.has(details, "address", "stateDetails"))
          this.profileUpdateData["address"]["selectedState"] = details["address"]["stateDetails"];

        if (_.has(details, "address", "locationDetails"))
          this.profileUpdateData["address"]["selectedCity"] = details["address"]["locationDetails"];

      }
      let selectedItems = [];
      if (this.getUserRoleId == 6) {
        this.licensingAuthorityStates = [];
        if ((this.checkProperty(this.userDetails, "representingStates", 'length') > 0) && (this.checkProperty(this.userDetails, "representingStateList", 'length') > 0)) {
          _.forEach(this.userDetails['representingStates'], (item) => {
            let stateDetails = _.find(this.userDetails['representingStateList'], { "id": item['stateId'] });
            if (stateDetails) {
              item = Object.assign(item, { 'stateDetails': stateDetails });
              this.licensingAuthorityStates.push(item);

            }




          })

        }
        this.templicensingAuthorityStates = _.cloneDeep(this.licensingAuthorityStates);
        if (this.licensingAuthorityStates.length <= 0) {
          this.addAttornyState();

        }

      }
    },
    async updateProfile() {
      const result = await this.$validator.validateAll().then((result) => {
        return result;
      });

      if (result) {
        let postData = this.profileUpdateData;
        if (this.checkProperty(this.profileUpdateData, "firstName"))
          postData['name'] = this.profileUpdateData.firstName;

        if (this.checkProperty(this.profileUpdateData, "middleName"))
          postData["name"] = postData["name"] + " " + this.profileUpdateData.middleName;

        if (this.checkProperty(this.profileUpdateData, "lastName"))
          postData["name"] = postData["name"] + " " + this.profileUpdateData.lastName;
        if (this.licensingAuthorityStates.length > 0 && this.getUserRoleId == 6) {
          //representingStates
          let representingStateIds = this.licensingAuthorityStates.map((item) => {
            return { 'stateId': item.stateDetails.id, "barNumber": item.barNumber }
          })


          postData = Object.assign(postData, { "representingStates": representingStateIds })
        }

        this.$store.dispatch("updateProfile", postData).then((response) => {
          this.editProfile = false;
          this.$modal.hide('editProfilePopupModal');
          this.showToster({ message: response.message, isError: false })

          this.fetchUserDetails();
        });
      }
    },
    upload(model) {
      let formData = new FormData();
      if (model.length > 0) {
        this.logoUploading = true;
        model.forEach((doc) => {
          formData.append("files", doc.file);
          formData.append("secureType", "public");
          this.$store.dispatch("uploadS3File", formData).then((response) => {
            response.data.result.forEach((urlGenerated) => {
              let postData = {
                userId: this.userDetails._id,
                profilePicture: urlGenerated,
              };
              this.$store
                .dispatch("updateuserdetails", postData)
                .then((response) => {
                  this.userDetails.profilePicture = urlGenerated;
                  this.logoUploading = false;
                })
                .catch((error) => {
                  this.logoUploading = false;
                })
            });
          });
        });
      }
    },
    fetchUserDetails() {
      let postData = {
        userId: JSON.parse(localStorage.getItem("user")).userId,
      };
      this.$store.dispatch("getuserdetails", postData).then((response) => {
        this.userDetails = response;

        this.initProfileData();

        if (this.checkProperty(this.userDetails, "details", "address")) {
          let address =
            this.userDetails["details"].address.line1 +
            ", " +
            this.userDetails["details"].address.line2 +
            ", " +
            this.userDetails["details"].address.zipcode;
          this.userDetails = Object.assign(this.userDetails, {
            address: address,
          });
        }
      });
    },
    changePassword() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          let postData = {
            newPassword: this.newPassword,
            currentPassword: this.currentPassword,
            email: this.getUserData.email,
            roleId: this.getUserRoleId,
          };
          this.$store.dispatch("updatepassword", postData).then((response) => {
            if (response.error) {
              Object.assign(this.formerrors, {
                msg: response.error.message,
              });
            } else {
              this.showToster({ message: response.data.message, isError: false });
              // this.$vs.notify({ text: response.data.message, });
              this.SetPassword = false;
              this.formerrors.msg = null;
            }
          });
        }
      });
    },
  },
  data() {
    return {
      loading:false,
      templicensingAuthorityStates: [],
      allUsstates: [],
      allUsstatesTemp: [],
      licensingAuthorityStates: [

        {
          stateDetails: null,
          barNumber: ''
        }
      ],

      isPhoneValid: true,
      logoUploading: false,
      res_msg: '',
      countries: [],
      states: [],
      locations: [],
      date: null,
      SetPassword: false,
      userDetails: {},
      errorValue: "data not present",
      newPassword: "",
      currentPassword: "",
      profilePicture: [],
      formerrors: {
        msg: "",
      },
      vuePhone: {
        props: {
          translations: {
            phoneNumberLabel: "Phone Number"
          }
        }

      },
      editProfile: false,
      updateStatus: false,
      profileUpdateData: {
        userId: "",
        name: "",
        phone: "",
        phoneCountryCode: {
          countryCode: "",
          countryCallingCode: "",
        },
        firstName: "",
        middleName: "",
        lastName: "",
        fax: "",
        faxCountryCode: {
          countryCode: "",
          countryCallingCode: "",
        },
        address: {
          line1: "",
          line2: "",
          locationId: null,
          stateId: null,
          countryId: null,
          zipcode: "",
        },
      },
    };
  },
  watch: {
    SetPassword: {
      handler(val) {
        this.formerrors.msg = null;
      },
    },
  },
  components: {
    addressField,
    VuePhoneNumberInput,
    CheckCircleIcon,
    FileUpload,
    PhoneMaskInput,
  },
  mounted() {
    this.profileUpdateData['userId'] = this.getUserData['userId'];
    this.masterData("countries");
    this.fetchUserDetails();
    this.profilePicture = [];
    let item = {
      matcher: {
        countryId: 231
      },
      page: 1,
      perpage: 1000,
      category: "states",

    };
    this.$store.dispatch("getMasterData", item).then(response => {
      let list = response.list
      this.allUsstates = list;
      this.allUsstatesTemp = _.cloneDeep(this.allUsstates);
    });
  },
};
</script>
