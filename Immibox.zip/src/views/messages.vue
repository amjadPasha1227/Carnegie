<template>
  <div>
    <div class="content-header messages">
      <div class="content-header-left">
        <div class="search">
          <vs-input
            icon-pack="feather"
            icon="icon-search"
            :placeholder="searchPlaceHolder"
            class="is-label-placeholder"
            v-model.lazy="searchtxt"
            @input="searchCases"
          />
        </div>
        <div class="con-select selection_search" v-if="[50,51].indexOf(getUserRoleId)<=-1">
          <multiselect
            @input="filterByPetitioner()"
            v-model="petitionerIds"
            :options="customerList"
            :multiple="true" :hideSelected="true"
            :close-on-select="false"
            :clear-on-select="false"
            :preserve-search="true"
            placeholder="Select Customers"
            label="name"
            track-by="name"
            :preselect-first="false"
              @search-change="peritioners_search_fun"
          >
            
            <template slot="selection" slot-scope="{ values, isOpen }">
              <span
              class="multiselect__selectcustom"
              v-if="values.length && !isOpen"
              >{{ values.length }} Petitioners selected</span
              >
              <span
              class="multiselect__selectcustom"
              v-if="values.length && isOpen"
              ></span>
            </template> 
          </multiselect>
        </div>
        <div class="con-select selection_search">
          <multiselect
            @input="filterBytype()"
            v-model="messageFilters.typeIds"
            :options="visaTypes"
            :multiple="true" :hideSelected="true"
            :close-on-select="false"
            :clear-on-select="false"
            :preserve-search="true"
            placeholder="Select Case Type"
            label="name"
            track-by="name"
            :preselect-first="false"
          >
            
            <template slot="selection" slot-scope="{ values, isOpen }">
              <span
              class="multiselect__selectcustom"
              v-if="values.length && !isOpen"
              >{{ values.length }} Case Type</span
              >
              <span
              class="multiselect__selectcustom"
              v-if="values.length && isOpen"
              ></span>
            </template> 
          </multiselect>
        </div>
      </div>
      <div class="content-header-right messages_header" v-if="[50,51].indexOf(getUserRoleId)<=-1">
        <span class="create_label_btn" @click="openLabelPopup(true)"><em>+</em> Labels</span>
      </div>
    </div>
    <div class="inbox_sent_wrapper content-header">
      <div class="left_cnt" v-if="[50,51].indexOf(getUserRoleId)>-1">
        <button type="border" class="inbox_btn " :class="{'active':selectedMsgType == 'inbox'}" @click="selectedMsgType = 'inbox';getNotes()" >Inbox</button>
        <button type="border" class="sent_btn" :class="{'active':selectedMsgType == 'sent'}"  @click="selectedMsgType = 'sent';clearFields();getNotes()">Sent</button>
      </div>
      <div class="left_cnt" v-else>
        <div class="assigning_wraper ml-0">
          <vs-dropdown vs-custom-content vs-trigger-click class="cursor-pointer">
          <div class="add_lebel_drpdwn_wrapper">
            <span class="assigned_label">Filters</span><span class="assigned_list filters_list">{{returnVal}}</span>
          </div>
          <vs-dropdown-menu ref="filter_menu" color="#fff" class="vx-navbar-dropdown actions-dropdown profileDropdown add_lebel_drpdwn filter_drpdwn" >
            <div class="filter_drpdown_wrapper">
              <button type="border" class="inbox_btn mb-2" :class="{'active':selectedMsgType == 'inbox'}" @click="selectedMsgType = 'inbox'" >Inbox</button>
              <button type="border" class="sent_btn mb-2" :class="{'active':selectedMsgType == 'sent'}"  @click="selectedMsgType = 'sent';clearFields()">Sent</button>
              <template v-if="selectedMsgType == 'inbox'"> 
                <button type="border" class="normal_btn" :class="{'active':selectedCreatedByType == 'petitioner'}" @click="selectedCreatedByType = 'petitioner'">Petitioner</button>
                <button type="border" class="normal_btn" :class="{'active':selectedCreatedByType == 'internal'}" @click="selectedCreatedByType = 'internal'">Internal</button>
              </template>
              <div class="divider my-3"></div>
              <vs-button color="success" :disabled="loadingLabel" @click="applyFilter()" class="save ok" type="filled"><img src="@/assets/images/main/create_label.svg">OK</vs-button>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        </div>
      </div>
      <div class="right_cnt">
      <template v-if="selectedMsgType == 'inbox'">
        <button type="border" class="read_btn" :class="{'active':selectedReadType}" @click="getContentUpdate('read')">Read</button>
        <button type="border" class="unread_btn" :class="{'active':selectedUnReadType}" @click="getContentUpdate('unread')">Unread</button>

        <div class="assigning_wraper" @click="PrepopulateUsers()" v-if="[50,51].indexOf(getUserRoleId)<=-1"   >
          <vs-dropdown vs-custom-content vs-trigger-click class="cursor-pointer">
              <div class="add_lebel_drpdwn_wrapper">
                  <span class="assigned_label">Assigned To</span>
                  <template v-if="checkProperty(assignedUserName,'length')>0">
                      <span  class="assigned_list">{{assignedUserName[0]}}
                          <!-- <template v-if="checkProperty(assignedUserName,'length')>1" > ..</template> -->
                          <em v-if="checkProperty(assignedUserName,'length')>1">+{{checkProperty(assignedUserName,'length') - 1}}</em>
                      </span>
                  </template>
                  <template v-else>
                      <span class="assigned_list">--</span>
                  </template>
              </div>
              <vs-dropdown-menu color="#fff" class="vx-navbar-dropdown actions-dropdown profileDropdown add_lebel_drpdwn add_assign_drpdwn" >
              <span class="drpdwn_label">Assigned to</span>
              <div class="search">
                  <vs-input icon-pack="feather" icon="icon-search" @input="filterUser" v-model.lazy="assignee_search" placeholder="Search"
                  class="is-label-placeholder" />
              </div>
              <!-- v-if="checkProperty(assigneeList,'length')>0" -->
                  <VuePerfectScrollbar>
                      <ul style="min-width: 9rem" class="profileMenu"  >
                          <template v-for="item in assigneeList ">
                              <li>
                              <vs-checkbox v-model="item.assigneSelected"  @input="filterByAssign(item)">
                                  {{checkProperty(item,'name')}}
                              </vs-checkbox>
                              </li>
                          </template>
                      </ul>
                  </VuePerfectScrollbar>
              <!-- <template v-else>
                Loading
              </template> -->
              </vs-dropdown-menu>
          </vs-dropdown>
        </div>
      </template>
      <div class="new_label_as assigning_wraper" v-if="[50,51].indexOf(getUserRoleId)<=-1">
        <vs-dropdown vs-custom-content vs-trigger-click class="cursor-pointer add_new_label" >  
          <div class="add_lebel_drpdwn_wrapper">
            <span class="assigned_label">Labels </span>
            <template v-if="selectedLabelsList && checkProperty(selectedLabelsList,'length')>0">
              <span  class="assigned_list">{{checkProperty(selectedLabelsList[0],'name')}}
                  <!-- <template v-if="checkProperty(assignedUserName,'length')>1" > ..</template> -->
                  <em v-if="checkProperty(selectedLabelsList,'length')>1">+{{checkProperty(selectedLabelsList,'length') - 1}}</em>
              </span>
            </template>
            <template v-else>
                <span class="assigned_list">--</span>
            </template>
          </div>
          
          
          <!-- <div class="tooltip_cnt">
              <p>Add Label</p>
          </div> -->
        <vs-dropdown-menu color="#fff" class="vx-navbar-dropdown actions-dropdown profileDropdown add_lebel_drpdwn"  >
          <!-- <ul class="label_list">
            <template v-if="selectedLabelsList && checkProperty(selectedLabelsList,'length')>0"> 
                <template v-for="item in selectedLabelsList ">
                    <li :style="{'background-color':item['color']}">
                        {{checkProperty(item,'name')}} <em   @click="deleteLabel(item)">x</em>
                    </li>
                </template>
            </template>          
          </ul> -->
            <!-- <span class="drpdwn_label">Label as:</span> -->
            <div class="search">
            <vs-input icon-pack="feather" @input="getLabelsList" icon="icon-search" v-model.lazy="labelSearchText" placeholder="Search"
                class="is-label-placeholder" />
            </div>
            <VuePerfectScrollbar>
            <ul style="min-width: 9rem" class="profileMenu" >
                <template v-for="colr in labelsForFilter">
                    <li :style="{'background-color':colr['color']}">
                        <vs-checkbox v-model="colr.selectedColor" @input="manageLabel">
                            {{checkProperty(colr,'name')}}
                        </vs-checkbox>
                    </li>
                </template>
            </ul>
            </VuePerfectScrollbar>
        </vs-dropdown-menu>
        </vs-dropdown>
          <!-- <ul>
            <li class="label_new">Labels</li>
            <li class="p-0 add_li">
             <vs-dropdown vs-custom-content vs-trigger-click class="cursor-pointer add_new_label" >  
                  <span>+</span>
                  <div class="tooltip_cnt">
                      <p>Add Label</p>
                  </div>
              <vs-dropdown-menu color="#fff" class="vx-navbar-dropdown actions-dropdown profileDropdown add_lebel_drpdwn"  >
                <ul class="label_list">
                  <template v-if="selectedLabelsList && checkProperty(selectedLabelsList,'length')>0"> 
                      <template v-for="item in selectedLabelsList ">
                          <li :style="{'background-color':item['color']}">
                              {{checkProperty(item,'name')}} <em   @click="deleteLabel(item)">x</em>
                          </li>
                      </template>
                  </template>          
                </ul>
                  <span class="drpdwn_label">Label as:</span>
                  <div class="search">
                  <vs-input icon-pack="feather" @input="getLabelsList" icon="icon-search" v-model.lazy="labelSearchText" placeholder="Search"
                      class="is-label-placeholder" />
                  </div>
                  <VuePerfectScrollbar>
                  <ul style="min-width: 9rem" class="profileMenu" >
                      <template v-for="colr in labelsForFilter">
                          <li :style="{'background-color':colr['color']}">
                              <vs-checkbox v-model="colr.selectedColor" @input="manageLabel">
                                  {{checkProperty(colr,'name')}}
                              </vs-checkbox>
                          </li>
                      </template>
                  </ul>
                  </VuePerfectScrollbar>
              </vs-dropdown-menu>
              </vs-dropdown>  
            </li>
          </ul>
           <ul class="label_list">
            <template v-if="selectedLabelsList && checkProperty(selectedLabelsList,'length')>0"> 
                <template v-for="item in selectedLabelsList ">
                    <li :style="{'background-color':item['color']}">
                        {{checkProperty(item,'name')}} <em   @click="deleteLabel(item)">x</em>
                    </li>
                </template>
            </template>          
          </ul> -->
      </div>

      </div>
    </div>

    <NoDataFound ref="NoDataFoundRef" v-if="tickets.length <= 0" :numberOfItems="10"
      content="You haven't created/recevied any messages." :loading="isListLoading" heading="No Messages Found" type="support" />    
      <div class="accordian-table custom-table new_messages_table new_messages_table_v2">
        <template v-if="tickets.length>0">
          <vs-table :data="tickets" >
            <template v-if="tickets.length > 0" slot="thead">
              <vs-th> From </vs-th>
              <vs-th > Message 
                <div class="per_page_sec">
                  <label class="typo__label">Records per page</label>
                  <div class="vx-col  con-select pages_select">
                    <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
                      :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page" :preselect-first="true">
                    </multiselect>
                  </div>
                </div>
              </vs-th>
              <!-- <vs-th >
                <div class="per_page_sec">
                  <label class="typo__label">Records per page</label>
                  <div class="vx-col  con-select pages_select">
                    <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
                      :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page" :preselect-first="true">
                    </multiselect>
                </div>
                </div>
              </vs-th> -->
            </template>
            <template slot-scope="{ data }">
              <template v-for="mesage in data">
                <messageComponent @updateLabels="updateLabels" :selectedMsgType="selectedMsgType" @updateUserIds="updateUserIds" @openDetailsPage="openDetailsPage" 
                @goToDetailsPage="goToDetailsPage" @openCreateLabel="openCreateLabel" :labelsList="labelsList" :message="mesage" />
            </template>
            </template>
          </vs-table>
        </template>
        <div class="table_footer">

        <paginate v-if="tickets.length > 0" v-model="page" :page-count="totalpages" :page-range="3"
          :margin-pages="2" :click-handler="pageNate"
          prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
          next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
          :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'">
        </paginate>
       
        </div>
    </div>
<!-- <simpleColorPicker /> -->
    <!-- <NoDataFound
      ref="NoDataFoundRef"
      v-if="tickets.length <= 0"
      content="You haven't created/recevied any messages."
      :loading="isListLoading"
      heading="No Messages Found"
      type="support"
    /> -->

   

    <!-- new message section -->
    <div class="notes_section" v-if="tickets.length > 0 && false">
    <div class="notes_list_wrap messages_list_wrap" >
    <template>
        <div class="notes_list"  v-for="(ticket, tindex) in tickets" :key="tindex">
        <div class="notes_info" >
            <h6 @click="communicationlink(ticket)" v-html="checkProperty(ticket,'message')"></h6>
            <p class="created">
              <label v-if="checkProperty(ticket,'fromUserName')" @click="communicationlink(ticket)">
                            Created by<strong> {{checkProperty(ticket,'fromUserName')}} <em>({{checkProperty(ticket,'fromUserRoleName')}})</em></strong>
                        </label>
                        <label v-if="checkProperty(ticket, 'createdOn')" @click="communicationlink(ticket)"
                          >On
                          <strong v-if="checkProperty(ticket, 'createdOn')">
                            {{ ticket.createdOn | formatDateTime }}</strong>
                        </label>
                      </p>
            <template>
                <ul>
                    <li>
                        <label v-if="checkProperty(ticket,'petitionDetails','caseNo')" @click="communicationlink(ticket)">Case Type <p>{{checkProperty(ticket,'petitionDetails','typeName')}}<em @click="communicationlink(ticket)">({{checkProperty(ticket,'petitionDetails','subTypeName')}})</em></p></label>
                    </li> 
                    <li>
                        <label v-if="checkProperty(ticket,'petitionDetails','caseNo')" @click="communicationlink(ticket)">Case No <p>{{checkProperty(ticket,'petitionDetails','caseNo')}}</p> </label>
                        <!-- <span>{{checkProperty(ticket,'petitionDetails','typeName')}}<em @click="communicationlink(ticket)">({{checkProperty(ticket,'petitionDetails','subTypeName')}})</em></span> -->
                    </li>  
                    <!-- <li>
                        <label v-if="checkProperty(ticket,'fromUserName')" @click="communicationlink(ticket)">
                            Created by<p> {{checkProperty(ticket,'fromUserName')}}<em>({{checkProperty(ticket,'fromUserRoleName')}})</em></p>
                        </label>
                    </li>
                    <li>
                        
                    </li>                  -->
                    
                    <!-- <li v-for="(tickt, indexx) in ticket['toUserList']" :key="indexx"  @click="communicationlink(ticket)">
                        <label v-if="checkProperty(tickt,'name')">Tagged to <p>{{checkProperty(tickt,'name')}}<em>({{checkProperty(tickt,'roleName')}})</em></p> </label>
                    </li>   -->
                     <li v-if=" checkProperty(ticket ,'toUserIds') && checkProperty(ticket ,'toUserIds' ,'length')>0"
                  >
                    <label>Tagged to </label>
                    
                    <p
                      
                      v-on:click.stop.prevent="showTaggedDetails(true, ticket)"
                    >{{checkProperty(ticket ,'toUserIds' ,'length')}} 
                      
                      Members<img
                        src="@/assets/images/main/eye.png"
                        
                        width="15px"
                      />
                    </p>
                  </li>
                </ul>
            </template>
        </div>
        <!-- <div class="notes_status_sec ">
                <label v-if="checkProperty(ticket, 'createdOn')" @click="communicationlink(ticket)"
                  >Created On: 
                  <strong v-if="checkProperty(ticket, 'createdOn')">
                    {{ ticket.createdOn | formatDateTime }}</strong
                  >
                </label>
            </div> -->

        </div>
    </template>
    </div>
    <div class="table_footer pt-4" v-if="tickets.length > 0">
        <div class="vx-col con-select pages_select" v-if="tickets.length > 0">
          <label class="typo__label">Per Page</label>
          <multiselect
            @input="changeperPage()"
            v-model="perpage"
            :options="perPeges"
            :multiple="false"
            :close-on-select="true"
            :clear-on-select="false"
            :preserve-search="true"
            placeholder="Per Page"
            :preselect-first="true"
          >
          </multiselect>
        </div>

        <paginate
          v-if="tickets.length > 0"
          v-model="page"
          :page-count="totalpages"
          :page-range="3"
          :margin-pages="2"
          :click-handler="pageNate"
          prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
          next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next"
          :prev-text="'<i></i>'"
          :next-text="'<i></i>'"
          :container-class="'pagination vs-pagination--nav'"
          :page-class="'page-item'"
        ></paginate>
      </div>
    </div>

    <div class="workflow_view_wrap taskmanagement messages_side_popup" v-if="showMessageDetails" :class="{ listopen: showMessageDetails }">
        <div class="workflow_overlay"></div>
        <div class="workflow_view_cnt questionary_cnt">
          <div class="workflow_view_title pr-0">          
              <span @click="showMessageDetails = false;getNotes()"><x-icon size="1.5x" class="custom-class"></x-icon></span>
          </div>  
         <messageDetails @goToDetailsPage="goToDetailsPage" @updateUserIds="updateUserIds" :labelsList="labelsList"  @getNotes="getNotes"
         @openCreateLabel="openCreateLabel" @updateLabels="updateLabels" :selectMessage="selectedMessage" :details="seletedmessageDetails" />
        </div>
    </div>

    <modal 
     
     name="createLabelModal" 
     classes="v-modal-sec createLabelModal"
     :min-width="200"
     :min-height="200"
     :scrollable="true"
     :reset="true"
     width="500px"
     height="auto">
   <div class="v-modal">
      
       <div class="popup-header fromDetailsPage">
         <h2 class="popup-title">  Create Label</h2>
         <span @click="$modal.hide('createLabelModal');">
           <em class="material-icons">close</em>
         </span>
       </div>
       <form @submit.prevent data-vv-scope="newLabelform" >
       <div class="form-container" @click="formerrors.msg=''">
        <div class="vx-row">
           <div class="vx-col w-full">
             <div class="form_group">
               <label class="form_label">Please enter a new Label Name</label>
               <vs-input name="labelname" v-validate="'required'" class="w-full" data-vv-as="Label Name" v-model="labelName" />
               <span  class="text-danger text-sm" v-show="errors.has('newLabelform.labelname')" >{{ errors.first("newLabelform.labelname") }}</span >
             </div>
           </div>
        </div>
        <div class="vx-row">
          <simpleColorPicker v-model="selectColor" :formscope="'newLabelform'" :fieldName="'labelColor'" :cid="'labelColor'"
           :name="'labelColor'" :label="'Select the Label Color'" :required="true"/>
        </div>
        <div class="text-danger text-sm formerrors custom_margin" v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
       </div>
       <div class="popup-footer relative" style="padding: 0 25px 0 !important;">
        <span class="loader" v-if="loadingLabel" ><img src="@/assets/images/main/loader.gif" /></span>
        <!-- <vs-button color="dark" @click="$modal.hide('createLabelModal')" class="cancel" type="filled">Cancel
        </vs-button> -->
        <vs-button color="success" :disabled="loadingLabel" @click="createLabel"  class="save m-0" type="filled">Create</vs-button>
       </div>
     </form>
       
   
   </div>
   </modal>   


<vs-popup
      class="holamundo main-popup taggedlistmodal"
      :title="'Tagged Members'"
      v-if="taggedModal"
      :active.sync="taggedModal"
    >
      <div class="taggedlist">
      
        <ul>
          <template v-for="(member, index) in userDetails">
            <li :key="index">
              <figure>
                <img :src="checkProperty(member ,'profilePicture')"  @error="setDefaultPhoto($event)" />
              </figure>
              <figcaption>
                {{ checkProperty(member, "name")
                }}<span>{{ checkProperty(member, "roleName") }}</span>
              </figcaption>
             
            </li>
          </template>
        </ul>
        
      </div>
    </vs-popup>
    <labelCreatePopup v-if="createLabelPopup" @openLabelPopup="openLabelPopup" />
  </div>
</template>

<script>
import labelCreatePopup from "@/views/messages/labelCreatePopup.vue";
import messageDetails from "@/views/messages/messageDetails.vue";
import messageComponent from "@/views/messages/messageComponent.vue";
import DateRangePicker from "vue2-daterange-picker";
import Paginate from "vuejs-paginate";
import Datepicker from "vuejs-datepicker-inv";
import Multiselect from "vue-multiselect-inv";
import JQuery from "jquery";
import simpleColorPicker from "@/views/forms/fields/simpleColorPicker.vue";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import FileUpload from "vue-upload-component/src";
import moment from "moment";
import _ from "lodash";
import NoDataFound from "@/views/common/noData.vue";
import { MoreVerticalIcon } from "vue-feather-icons";
import selectField from "@/views/forms/fields/simpleselect.vue";
import { XIcon } from 'vue-feather-icons';
import messageAssign from "@/views/messages/messageAssign.vue";
import immitextfield from "@/views/forms/fields/simpleTextField.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
export default {
  provide() {
            return {
                parentValidator: this.$validator,
            };
        },
  components: {
    VuePerfectScrollbar,
    labelCreatePopup,
    messageDetails,
    XIcon,
    messageComponent,
    selectField,
    simpleColorPicker,
    Datepicker,
    DateRangePicker,
    Multiselect,
    Paginate,
    FileUpload,
    NoDataFound,
    MoreVerticalIcon,
    messageAssign,
    immitextfield,
    VuePerfectScrollbar
  },
  data: () => ({
    returnVal:'',
    searchPlaceHolder:'Search by Case No, Petitioner, Beneficiary, Employee, Message Text.',
    labelSearchText:'',
    selectedLabelsList:[],
    customerList:[],
    selectedMsgType:'inbox',
    selectedReadType:false,
    selectedUnReadType:false,
    createLabelPopup:false,
    debounce:null,
    peritioners_search_value:'',
    labelCreatedForMessage:null,
    callFromComponent:false,
    seletedmessageDetails:null,
    selectedMessage:null,
    showMessageDetails:false,
    labelsList:[],
    labelsForFilter:[],
    loadingLabel:false,
    labelName:'',
    selectColor:'',
    openAssignPopup:false,
    usersList:[
    {
            "_id": "62580705621cbad27e277687",
            "id": "62580705621cbad27e277687",
            "roleId": 11,
            "branchId": "6257fa6f621cbad27e2773a5",
            "userId": "62580705621cbad27e277687",
            "name": "Philips Cantona",
            "value": "Philips Cantona",
            "roleName": "LCA Manager"
        },
        {
            "_id": "6258079b621cbad27e27770e",
            "id": "6258079b621cbad27e27770e",
            "roleId": 11,
            "branchId": "6257fa6f621cbad27e2773a5",
            "userId": "6258079b621cbad27e27770e",
            "name": "Caldwell Ogley",
            "value": "Caldwell Ogley",
            "roleName": "LCA Manager"
        },
    ],
    callFromRefresh:false,
    selectedLabelIds:[],
    selectedAssigneeList:[],
    petitionerIds: [],
    petitionerList:[],
    isListLoading: false,
    taggedModal: false,
    noteTaggedToDetails:null,
    selectedNote:null,
     messageFilters: {
            caseNo: "",
            petitionIds: [],
            typeIds: [],
            subTypeIds: [],
            createdDateRange: []
        },
    filteredVisaType:null,
    //selectedVisaType:null,
    selected_subtypes:[],
    visaTypes:[],
    all_subtypes:[],
    uploading: false,
    
    formerrors: {
      msg: "",
    },
    tickets: [],
    sortKeys: {},
    sortKey: {},
    searchtxt: "",
    page: 1,
    perpage: 25,
    totalpages: 0,
    perPeges: [10, 25, 50, 75, 100],
    
    searchtxt: "",
    filter_searchtxt: "",

    buttoncol: true,
    currentuserRole: null,
    selected_createdDateRange: ["", ""],
    autoApply: "",
    roleId: 0,
    all_user_roles: [],
    users: [],
    selected_user: null,
    assignmrntPopUp: false,
    selected_role: "",

    ticket_comments: [],
    ticket: null,
    isValid: true,
    userDetails:null,
    assigneeList:[],
    assignee_search:'',
    assignedUserName:[],
    selectedCreatedByType:'petitioner',
    logedUserDetails:null,
  }),
  watch: {
    AddNewNote: function (value) {
      if (value) {
        this.$modal.show("newNoteModal");
      } else {
        this.$modal.hide("newNoteModal");
      }
    },
    searchtxt: function (value) {
      //this.getNotes();
    },
  },
  methods: {
    applyFilter(){
      this.$refs["filter_menu"].dropdownVisible = false;
      this.getNotes();
    },
    manageLabel(){
      let tempList = _.filter(this.labelsForFilter,(it) =>{
        return it['selectedColor'] == true
      });
      this.selectedLabelsList = tempList;
      this.selectedLabelIds = tempList;
      this.getNotes();
    },
    deleteLabel(val){
      let objVal = val   
      let filterList =  _.filter(this.selectedLabelsList,(itm)=>{
        return itm['id'] != objVal['id'];
      });
      this.selectedLabelsList = [];
      this.selectedLabelsList = filterList;
      this.selectedLabelIds = filterList;
      let list = _.cloneDeep(this.labelsForFilter)
      _.map(this.labelsForFilter,(obj)=>{
        if(obj['id'] == objVal['id'] ){
          obj['selectedColor'] = false;
        }
      });
      this.getNotes();
    },
    PrepopulateUsers(allExists = false){
      if(allExists){
        this.assignedUserName = ['All']
      }else{
        this.assignedUserName = [];
      let selectedList = _.filter(this.assigneeList,(item)=>{
        return item['assigneSelected'] == true;
      })
      if( selectedList && this.checkProperty(selectedList,'length')>0){
          let list = [];
          _.forEach(selectedList,(obj)=>{
              list.push(obj['name'])
          })
          this.assignedUserName = list;
      }
      }
    },
    filterUser(){
      clearTimeout(this.debounce)
      this.debounce = setTimeout(() => {
          this.showTaggedDetails(false)
      }, 900)
    },
    clearFields(){
      this.selectedReadType= false;
      this.selectedUnReadType = false;
      this.selectedAssigneeList = [];
      //this.selectedCreatedByType = ''
    },
    getContentUpdate(category){
     if(category == 'read'){
      if(this.selectedReadType){
        this.selectedReadType = false;
        this.selectedUnReadType = false;
        this.getNotes();
      }else{
        this.selectedReadType = true;
        this.selectedUnReadType = false;
        this.getNotes();
      }
     }
     if(category == 'unread'){
      if(this.selectedUnReadType){
        this.selectedUnReadType = false;
        this.selectedReadType = false;
        this.getNotes();
      }else{
        this.selectedUnReadType = true;
        this.selectedReadType = false;
        this.getNotes();
      }
      }
    },
    openLabelPopup(val){
      this.createLabelPopup = val;
      if(!val){
        this.getLabelsList();
      }
    },
    searchCases(){
      clearTimeout(this.debounce)
      this.debounce = setTimeout(() => {
        this.getNotes();
      }, 900)
      
    },
    openCreateLabel(val){
      this.labelCreatedForMessage = val;;
      this.callFromComponent = true;
      this.addNewLabel(true,true)
    },
    goToDetailsPage(val){
     
      let tr = val;
      this.$store.dispatch('setPetitionTab', 'set_Communication');
      if(this.checkProperty(tr,'petitionDetails') && this.checkProperty(tr,'petitionDetails','subType') == 15){
        setTimeout(()=>{
          this.goToPageDetails('/gc-employment-details/'+this.checkProperty( tr,'petitionId'));
        },5)
      }else{
        setTimeout(()=>{
          this.goToPageDetails('/petition-details/'+this.checkProperty( tr,'petitionId'));
        },5)
      }
      this.showMessageDetails = false;
      
    },
    openDetailsPage(val){
      this.selectedMessage = val;
      this.seletedmessageDetails = null;
      let payLoad={
              filters:{
                messageId:this.checkProperty(this.selectedMessage,'_id'),
                searchString:'',
                petitionIds: [],
                petitionerIds:[],
                typeIds: [],
                subTypeIds: [],
                createdDateRange: [],
              },
              page: 1,
              perpage: 100,
              sorting:{"path":"createdOn" ,"order":1},
            }
            let path = '/communication/list';
            this.$store.dispatch("getList", {'data':payLoad,'path':path}).then(response => {
                this.seletedmessageDetails = response.list;
                this.showMessageDetails = true;
            })
    },
    updateUserIds(val){
      let returnVal = val;
      _.map(this.tickets,(itemI)=>{
        if(itemI['_id'] == returnVal['messageId'] ){
          itemI['toUserIds'] = returnVal['userIds'];
          itemI['toUserList'] = returnVal['toUserList'];
        }
      }) 
      this.tickets = _.cloneDeep(this.tickets);
    }, 
    updateLabels(val){
      let returnVal = val;
      _.map(this.tickets,(itemI)=>{
        if(itemI['_id'] == returnVal['messageId'] ){
          itemI['labels'] = returnVal['labels']
        }
      })
      this.tickets = _.cloneDeep(this.tickets);
  
    },
    addNewLabel(action = false,callfromComp = false){
      this.selectColor = '';
      this.labelName = '';
      this.formerrors.msg ='';
      if(action){
        this.$modal.show('createLabelModal');
      }else{
        this.$modal.hide('createLabelModal');
      }
    },
    createLabel(){
      this.$validator.validateAll('newLabelform').then(result => {
        if(result){
          let payLoad={
            name: this.labelName,
            color: this.selectColor,
            tenantId: this.checkProperty(this.getUserData['tenantDetails'],'_id')
          }
          this.formerrors.msg = '';
          let path = '/message-label/create';
          this.loadingLabel = true;
          this.$store.dispatch("commonAction", { "data": payLoad, "path": path }).then((response)=>{
            this.showToster({message:response.message ,isError:false});
            if(this.callFromComponent && this.labelCreatedForMessage && this.checkProperty(this.labelCreatedForMessage,'_id')){
              let temp = {
                color:payLoad['color'],
                name:payLoad['name'],
                _id:response._id
              }
              _.map(this.tickets,(itemI)=>{
                if(itemI['_id'] == this.labelCreatedForMessage['_id'] ){
                  if(_.has(itemI,'labels') && this.checkProperty(itemI,'labels','length')>0){
                    itemI['labels'].push(temp)
                  }else{
                    itemI['labels'] = [];
                    itemI['labels'].push(temp)
                  }
                  if(itemI['labels'] && this.checkProperty(itemI['labels'],'length')>0){
                    let payload={
                        messageId:this.checkProperty(this.labelCreatedForMessage,'_id'),
                        labels:itemI['labels'],
                    }
                    let path='/communication/manage-labels'
                    this.$store.dispatch("commonAction", {'data':payload,'path':path}).then(response => { }).catch((err)=>{})
                  }
                }
              }) 
              this.tickets = _.cloneDeep(this.tickets)
            }
            this.loadingLabel = false;
            this.addNewLabel(false);
            this.getLabelsList();
          }).catch((err)=>{
            this.formerrors.msg =err;
            this.loadingLabel = false;
          })
        }
      })
    },
    getLabelsList(){
      let payLoad={
        matcher:{
          statusList:[],
          searchString:this.labelSearchText,
        },
        page:1,
        perpage:10000
      };
      let path='/message-label/list'
      this.$store.dispatch("getList", { "data": payLoad, "path": path }).then((response)=>{
        if(response.list){
          let list = response.list;
          let tempList = []
          let labelLit = [];
          _.forEach(list,(item)=>{
            if(!_.has(item,'id')){
              item['id'] = item['_id'];
              tempList.push(item);
              item = Object.assign(item,{'selectedColor':false});
              labelLit.push(item)
            }
          })
          if(this.checkProperty(tempList,'length')>0){
            this.labelsList = tempList;
            this.labelsForFilter = labelLit;
          }
         
        }
      }).catch((err)=>{
      
      })
    },
    showTaggedDetails(callFromMount = false, action = false, item) {
      let Payload= {
        "matcher": {
        "title": "",
        "searchString": this.assignee_search,
        "userIds": [],
        "statusIds": [],
        "petitionSubTypeIds": [],
        "petitionSearchString": "",
        "createdDateRange": []
      },
      "sorting": {
        "path": "createdOn",
        "order": 1
      },
      "page": 1,
      "perpage": 1000,
      "getMasterData": true
      }
      this.assigneeList =  [];
      this.$store.dispatch("getList", {"data":Payload ,"path":"/users/list"})
      .then(response => {
        if(this.checkProperty(response ,'list') && this.checkProperty(response ,'list','length')>0){
          let list = _.filter(response['list'],(itm)=>{
            return [51,50].indexOf(itm['roleId'])<=-1
          })
          let userId = this.checkProperty( this.getUserData ,"userId");
          if(list && this.checkProperty(list,'length')>0){
            let findObj = _.find(list, {'_id':userId});
            let allObj = {'name':'All','_id':'All','roleName':'All','roleId':'ALL','assigneSelected':false}
            if(findObj){
              findObj['name'] = 'Me'
              findObj['assigneSelected'] = false;
              let tempList =[];
              tempList.push(allObj);
              tempList.push(findObj);
               _.forEach(list,(itm)=>{
                if(itm['_id'] != userId){
                  itm = Object.assign(itm,{'assigneSelected':false});
                  tempList.push(itm)
                }
              })
              this.assigneeList =  tempList;
              if(callFromMount){
                allObj['assigneSelected'] = true
                this.selectedAssigneeList.push(allObj);
                if(this.logedUserDetails && this.checkProperty(this.logedUserDetails,'defaultCaseAssignConfig')
                  && this.checkProperty(this.logedUserDetails,'defaultCaseAssignConfig','subTypeDetails') && this.checkProperty(this.logedUserDetails['defaultCaseAssignConfig'],'subTypeDetails','length')>0){
                  let filted = [];
                  filted= _.map(this.logedUserDetails['defaultCaseAssignConfig']['subTypeDetails'], 'type');
                  let selff = this
                  if(filted && this.checkProperty(filted, 'length')>0){
                    let uniqueArray = Array.from(new Set(filted));
                    _.forEach(uniqueArray,(it)=>{
                      let finf = _.find(this.visaTypes,{'id':it});
                      selff.messageFilters.typeIds.push(finf)
                    })
                  }
                }
                this.PrepopulateUsers();
                this.getNotes(true);
              }else{
                this.selectedAssigneeList = [];
                this.PrepopulateUsers();
              }
            }else{
              this.assigneeList = list;
              if(callFromMount){
                this.getNotes(true);
              }
             
            }
          }else{
            this.assigneeList =  [];
            //this.getNotes(true);
          }
          
          //
        }else{
          this.getNotes(true);
        }
        
        //this.userDetails = response.list
      }).catch(()=>{
        this.getNotes(true);
      })
    },
     communicationlink(tr){
      
      this.$store.dispatch('setPetitionTab', 'set_Communication');
      setTimeout(()=>{
         this.goToPageDetails('/petition-details/'+this.checkProperty( tr,'petitionId'));
      },5)
     

  },
     changedVsaType(){
    let petitionSubType = this.messageFilters.typeIds.map((item)=>item.id)
        let item ={
          matcher:{
              petitionTypes: petitionSubType,
            },   

          page:1,
          perpage: 10000,
          category: "petition_sub_types",
          
        };
        if(this.checkProperty(petitionSubType , 'length')>0){
            let subTypeIds =  _.cloneDeep(this.messageFilters.subTypeIds);
            this.messageFilters.subTypeIds = _.filter(subTypeIds , (item)=>{
            return petitionSubType.indexOf(item['type']) >-1
            })
        }else{

            this.messageFilters.subTypeIds =[];

        }

        this.$store.dispatch("getMasterData",item ).then(response => { this.all_subtypes = response.list;  });
       
      
    },
     getVisaTypes(){
     let item ={
          matcher:{
              "searchString":'',
              getActiveList:true
             // "petitionType":

          },   
          page:this.page,
          perpage: this.perpage,
          category: "petition_types",
         "sorting": {
            "path": "name",
            "order": 1
            }
          
        };

        this.$store
          .dispatch("getMasterData",item )
          .then(response => {
            this.visaTypes = response.list;

             if(this.checkProperty(this.$route ,'query' ,'filter')){
                try{
                  let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                  var actual = JSON.parse(atob(filter));
                  let keys = Object.keys(actual);
                  if(this.checkProperty(keys ,'length') >0){


                    if(actual && (Object.keys(actual)).length>0 ){
                    _.forEach(actual ,(item ,key) => {
                        if(key=='matcher' ){
                          
                          if((Object.keys(item)).length>0 ){

                            if(_.has(item ,'typeIds') && this.checkProperty(item , 'typeIds' ,'length')>0 ){
                               
                              this.filteredVisaType = _.find(this.visaTypes ,{"id":item['typeIds'][0]})
                           
                             this.getvisa_subtypes();
                           
                            }

                            
                            
                          }
                        
                        }
                      
                        
                    
                    })
                  }
                    
                    
                  }

                }catch(e){
                  

                }
                  
              }


           
          });
   },
   peritioners_search_fun(searchValue) {
      this.peritioners_search_value = searchValue;
      clearTimeout(this.debounce)
      this.debounce = setTimeout(() => {
        this.getCustomersList();
      }, 800)
      
    },
   
    getCalssName(statusName = "") {
      return "note-" + statusName.toLowerCase();
    },

 
  

 
    

  
   
    pageNate(pageNum) {
      this.page = pageNum;
      this.getNotes();
    },

    set_filter: function () {
      //this.final_selected_statusids = [];

    //   if (this.selected_statusids.length > 0) {
    //     this.final_selected_statusids = [];
    //     for (let ind = 0; ind < this.selected_statusids.length; ind++) {
    //       let current_index = this.selected_statusids[ind];
    //       this.final_selected_statusids.push(current_index["id"]);
    //     }
    //   }

      this.searchtxt = this.filter_searchtxt;

      this.getNotes();
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    clear_filter: function () {
      this.searchtxt = "";
      this.selected_statusids = [];
      this.final_selected_statusids = [];

      this.date = "";
      this.date_range = [];
      this.selected_createdDateRange["startDate"] = "";
      this.selected_createdDateRange["endDate"] = "";
      this.filterTaggedToIds = [];
      this.filterAccessLevels = [];
      this.messageFilters.typeIds =[];
      this.messageFilters.subTypeIds =[]; 
      this.petitionerIds=[];

      this.filter_searchtxt = "";
      this.$refs["filter_menu"].dropdownVisible = false;
      this.getNotes();
    },
    filterByPetitioner(){
      this.getNotes()
    },
    filterBytype(){
      this.getNotes()
    },
    filterByLabel(){
      this.getNotes()
    },
    filterByAssign(val){
      let item = val;
      if(item && this.checkProperty(item,'assigneSelected') && this.checkProperty(item,'_id') != 'All'){
        this.assigneeList = _.map(this.assigneeList,(item)=>{
          if(item['_id'] == 'All'){
           item['assigneSelected'] = false
          };
          return item
        })
      }
      if(item && this.checkProperty(item,'assigneSelected') && this.checkProperty(item,'_id') == 'All'){
        this.assigneeList = _.map(this.assigneeList,(item)=>{
          if(item['_id'] != 'All'){
           item['assigneSelected'] = false
          };
          return item
        })
      }
      let selectedList = _.filter(this.assigneeList,(item)=>{
        return item['assigneSelected'] == true
      })
      this.selectedAssigneeList = _.cloneDeep(selectedList);
      if(this.checkProperty(this.selectedAssigneeList,'length')>0 && false){
        let fidObj = _.find(this.selectedAssigneeList,{_id:'All'});
        let tempList = _.cloneDeep(this.assigneeList)
        if(fidObj){
          _.forEach(tempList,(ite)=>{
            if(ite['_id'] != 'All' ){
              ite['assigneSelected']  = false;
            }
          })
          this.assignedUserName = ['All']
          this.assigneeList = [];
          setTimeout(()=>{
            this.assigneeList = _.cloneDeep(tempList)
          })
         
          this.selectedAssigneeList = [{'name':'All','_id':'All','roleName':'All','roleId':'ALL','assigneSelected':true}]
        }
      }
      this.getNotes();
      if(this.selectedAssigneeList && this.checkProperty(this.selectedAssigneeList,'length')>0){
        let fin = _.find(this.selectedAssigneeList,{_id:'All'});
        if(fin){
          this.PrepopulateUsers(true);
        }else{
          this.PrepopulateUsers(false);
        }
      }else{
        this.PrepopulateUsers(false);
      }
      
    },
    
    getNotes(callFromRefresh=false) {
      this.callFromRefresh =callFromRefresh;
      let obj = {
        filters: {
          searchString: this.searchtxt,
          petitionIds: [],
          petitionerIds:[],
          typeIds: [],
          subTypeIds: [],
          createdDateRange: [],
          labelIds:[],
          assignedToIds:[],
          msgListType:this.selectedMsgType,
          readList:[],
          newMessagesOnly:true,
          createdByType:this.selectedCreatedByType,
        },
        page: this.page,
        perpage: this.perpage,
      };
      if(this.selectedMsgType == 'sent'){
        this.selectedCreatedByType = '';
        obj["filters"]["createdByType"] = '';
      }
      if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        obj["filters"]["createdDateRange"] = [
          moment(this.selected_createdDateRange["startDate"]).format("YYYY-MM-DD"),
          moment(this.selected_createdDateRange["endDate"]).format("YYYY-MM-DD")
        ];
      }
      if([51,50].indexOf(this.getUserRoleId) >-1){
        this.selectedCreatedByType = '';
        obj["filters"]["createdByType"] = '';
      }

      obj["filters"]["typeIds"] = this.messageFilters.typeIds.map((item) => {
        return item["id"];
      });
      obj["filters"]["subTypeIds"] = this.messageFilters.subTypeIds.map((item) => {
        return item["id"];
      });
       obj["filters"]["petitionerIds"] = this.petitionerIds.map((item) => {
        return item["_id"];
      });
      if(this.checkProperty(this.selectedAssigneeList,'length')>0){
        let findOb = _.find(this.selectedAssigneeList,{'_id':'All'})
        if(findOb){
          obj["filters"]["assignedToIds"] = [];
        }else{
          obj["filters"]["assignedToIds"] = this.selectedAssigneeList.map((item) => {
            return item["_id"];
          });
        }
      }
      if(this.checkProperty(this.selectedLabelIds,'length')>0){
        obj["filters"]["labelIds"] = this.selectedLabelIds.map((item) => {
        return item["_id"];
      });
      }
      // selectedReadType selectedUnReadType
      if(this.selectedReadType){
        obj["filters"]["readList"] = [];
        obj["filters"]["readList"].push(true)
      }
      if(this.selectedUnReadType){
        obj["filters"]["readList"] = [];
        obj["filters"]["readList"].push(false)
      }
     
      
      this.isListLoading = true;
      
      this.updateLoading(true);
      this.tickets = [];
      //this.$store .dispatch("supportTicketsList", obj) 
      this.checkFilterLabel();
      this.$store
        .dispatch("getList", { data: obj, path: "/communication/list" })
        .then((response) => {
          let self = this;
          this.callFromRefresh =false;
          this.isListLoading = false;
          this.updateLoading(false);
          setTimeout(() => {
            this.updateLoading(false);
          }, 10);
          setTimeout(() => {
            this.isListLoading = false;
          }, 10);
          this.checkFilterLabel();
          let data = response.list;
          let toUsersList = [];
          if(response['toUserList'] && self.checkProperty(response, 'toUserList', 'length')>0){
            toUsersList = response['toUserList'];
          }
          let temp_list = [];
          _.forEach(data, (obj) => {
            obj["is_expend"] = false;
            obj["all_comments"] = [];
            obj["newComment"] = { ticketId: "", statusId: "", description: "", documents: [], today: moment().format("YYYY-MM-DD"),  };
            if(_.has(obj, 'toUserIds') &&  self.checkProperty(obj,'toUserIds', 'length')>0 && toUsersList && self.checkProperty(toUsersList, 'length')>0){
              obj['toUserList'] = [];
              _.forEach(obj['toUserIds'],(itd)=>{
                let findOb = _.find(toUsersList,{'_id':itd});
                if(findOb){
                  obj['toUserList'].push(findOb)
                }
              })
            }else{
              if(!_.has(obj, 'toUserList')){
                obj['toUserList'] = [];
              }
              
            }
            temp_list.push(obj);
          });
          this.tickets = temp_list;
          this.totalpages = Math.ceil(response.totalCount / this.perpage);
          setTimeout(() => {
            this.updateLoading(false);
          }, 10);
        })
        .catch((err) => {
          this.callFromRefresh =false;
          this.tickets = [];
          this.isListLoading = false;

          //alert(err);

          setTimeout(() => {
            this.updateLoading(false);
          }, 10);
        });
    },
    sortMe(sort_key = "") {
      if (sort_key != "") {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
        localStorage.setItem("tickets_sort_key", sort_key);
        localStorage.setItem("tickets_sort_value", this.sortKey[sort_key]);

        this.sortKey = {
          path: sort_key,
          order: parseInt(this.sortKeys[sort_key]),
        };
        this.getNotes();
      }
    },
    changeperPage() {
      this.page = 1;
      localStorage.setItem("petitions_perpage", this.perpage);
      this.getNotes();
    },
    getPeritioners() {

     
           
     //petitioner_list_for_tenant_users

       let item ={
          page:1,
          perpage: 10000,
          category: "petitioner_list_for_tenant_users",
          matcher:{
            "searchString":this.peritioners_search_value,
          
          },
          "sorting": {
            "path": "name",
            "order": 1
            }
                      
        };
        if([51].indexOf(this.getUserRoleId)>-1){
          item['category'] = "petitioner_list_for_beneficaries"
        }

  
        this.$store.dispatch("getMasterData", item).then(response => {
         
          this.petitionerList =response.list
        
        });
    },
    getCustomersList(){
      let payLoad={
        "matcher": {
            "searchString": this.peritioners_search_value
        },
        page:1,
        perpage:1000
      };
      this.customerList = []
      let path = '/companies/customer-list';
      this.$store.dispatch("getList", { data: payLoad, path: path }).then((response)=>{
        
        this.customerList = response
      })
    },
    checkFilterLabel(){
      this.returnVal ='';
      let returnVal = '';
      if(this.selectedMsgType == 'inbox'){
        if(this.selectedCreatedByType == 'petitioner'){
          returnVal = 'Inbox/Petitioner';
        }
        if(this.selectedCreatedByType == 'internal'){
          returnVal = 'Inbox/Internal';
        }
        if(this.selectedCreatedByType == ''){
          returnVal = 'Inbox';
        }
      }
      if(this.selectedMsgType == 'sent'){
        returnVal = 'Sent';
      }
      this.returnVal = returnVal
    },
    getUserCaseDetails(){
      let postData = { userId: "" };
        postData['userId'] = this.checkProperty(this.getUserData,'userId');
        this.$store.dispatch("commonAction", { "data": postData, "path": "/users/details" }).then((res)=>{
          this.logedUserDetails = res;
        })
    }

  },

  mounted() {  
    this.getVisaTypes();
    if([3,50,51,1,2].indexOf(this.getUserRoleId)<=-1){
      this.getUserCaseDetails(); 
    }
    if([50].indexOf(this.getUserRoleId)>-1){
      this.getNotes();
      this.searchPlaceHolder = 'Search by Case No, Beneficiary, Message Text.'
    }
    if([51].indexOf(this.getUserRoleId)>-1){
      this.getNotes();
      this.searchPlaceHolder = 'Search by Case No, Message Text.'
    }
    //this.checkFilterLabel()
    this.showTaggedDetails(true);
    this.getLabelsList();
    
    this.getCustomersList();
    this.getPeritioners();
   
  },
  computed:{
    
  }
};
</script>
