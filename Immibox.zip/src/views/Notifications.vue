<template>
  <div>
    <div class="content-header">
      <div class="content-header-left">
        <div class="search">
          <vs-input
            icon-pack="feather"
            icon="icon-search"
            placeholder="Search"
            class="is-label-placeholder"
            v-model.lazy="searchtxt"
          />
        </div>
      </div>
      <div class="content-header-right">
        <!--filter dropdown-->
        
        <vs-dropdown vs-custom-content vs-trigger-click>
          <vs-button
            color="primary"
            class="filter-btn"
            type="border"
            icon-pack="feather"
            icon="icon-chevron-down"
            icon-after
          >
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">
            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">
                                  
                  
                  

                 
                  <!--Created Date--->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker
                      :autoApply="autoApply"
                      :ranges="false"
                      v-model="selected_createdDateRange"
                    ></date-range-picker>
                  </div>
                </div>
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons"></div>
              <div class="right-buttons">
                <vs-button
                  color="success"
                  class="save"
                  type="filled"
                  v-on:click="set_filter()"
                >Apply</vs-button>
                <vs-button
                  color="dark"
                  class="cancel"
                  type="filled"
                  v-on:click="clear_filter($event)"
                >Clear</vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        <!-- end -->
      </div>
    </div>
    
    <div class="accordian-table custom-table no-wrap">
      <div >
        <vs-table :data="notifications" >
          <template slot="thead">
            <vs-th >Title</vs-th>
            <vs-th >Description</vs-th>
            <vs-th> <a @click="sortMe('createdOn')" v-bind:class="{'sort_ascending':sortKeys['createdOn']==1, 'sort_descending':sortKeys['createdOn']!=1}"  >Created</a></vs-th>
            <vs-th > Status</vs-th> 
          </template>
          <template slot-scope="{ data }">
            <vs-tr
              :data="notification"
              :key="notification.index"
              v-for="notification in data"
              class="vs-table--tr"
            >
              <vs-td> {{notification.title}}  </vs-td>
              <vs-td> {{notification.description}}</vs-td>

              <vs-td>  {{ notification.createdOn | formatDateTime }} </vs-td>
              
              <vs-td class="buttoncol">
                              
                <a  href="javascript:;" @click="conformDeleteNotification(notification['_id'])">Delete</a> 
                
              </vs-td>
             

            </vs-tr>
          </template>
        </vs-table>

         <div class="table_footer">
                    

<div class="vx-col  con-select pages_select" v-if="notifications.length > 0">
                    <label class="typo__label">Per Page</label>
                    <multiselect
                      @input="changeperPage()"
                      v-model="perpage"
                      :options="perPeges"
                      :multiple="false"
                      :close-on-select="true"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Per Page"
                     
                      :preselect-first="true"
                    >
                      
                    </multiselect>
                  </div>

        <paginate
          v-if="notifications.length > 0"
          v-model="page"
          :page-count="totalpages"
          :page-range="3"
          :margin-pages="2"
          :click-handler="pageNate"
          prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
          next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next"
          :prev-text="'<i></i>'"
          :next-text="'<i></i>'"
          :container-class="'pagination vs-pagination--nav'"
          :page-class="'page-item'"
        ></paginate>
         </div>
       
        
      </div>
    </div>
<vs-popup class="Change_petition_wrap" v-bind:title="notification_popuptitle" :active.sync="deleteAllConform">
      <div class="Change_petition">

        <div class="vx-col w-full marb10">
                <h3 class="text-center">  Do you want to continue ..? </h3>
        </div>
         
        
      </div> 
      <div class="actions_footer">
        <button @click="deleteAllConform=false" class="btn cancel">No</button>
        <button class="btn" @click="action_onnotification('removeAll')">  Yes</button>
      </div>
</vs-popup>
    
<vs-popup class="Change_petition_wrap" v-bind:title="notification_popuptitle" :active.sync="deleteStatus">
      <div class="Change_petition">

        <div class="vx-col w-full marb10">
                <h3 class="text-center">{{res_msg}} </h3>
        </div>
         
        
      </div> 
      <div class="actions_footer">
        <button @click="deleteStatus=false" class="btn cancel">Close</button>
        
      </div>
</vs-popup>
    
    
  </div>
</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
import Paginate from "vuejs-paginate";
import Datepicker from "vuejs-datepicker-inv";
import Multiselect from "vue-multiselect-inv";
import JQuery from "jquery";

import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
export default {
  components: {
    Datepicker,
    DateRangePicker,
    Multiselect,
    Paginate
  },
  data: () => ({
    selected_createdDateRange: ["", ""],
    autoApply: "",
    notifications:[],
    searchtxt:'',
    page: 1,
    perpage: 25,
    totalpages: 0,
    sortKeys:{},
    sortKey:{},
    perPeges: [10,25,50,75,100], // [  {name:10 ,perPage:10} , {name:25 ,perPage:25} ,{name:50 ,perPage:50},{name:100 ,perPage:100}],
   filter:{},
     delNotification:{"notifyId": '' , 'removeAll':false},
      deleteAllConform:false,
      notification_popuptitle:'Delete',
    deleteStatus:false,  
  }),
  watch: {
    searchtxt: function(value) {
      this.set_filter();
    }
  },
  methods: {

    action_onnotification(){
      
        let postData = this.delNotification;
                
         this.$store
         .dispatch("removeNonification", postData)
         .then(response => {
           this.deleteAllConform =false;
           this.delNotification = {"notifyId": '' , 'removeAll':false};
        //   alert(JSON.stringify(response));
           this.deleteStatus =true;
           this.res_msg = "Notification removed";
           this.getNotifications();
          
         });

         
      },

      conformDeleteNotification(notifyId=''){
       this.delNotification = {"notifyId": '' , 'removeAll':false};
       if(notifyId=="removeAll"){
             this.delNotification = {"removeAll":true};
             this.notification_popuptitle = "Delete All";
        }else{
             this.delNotification = {"notifyId": notifyId};
             this.notification_popuptitle = "Delete";
        }
       this.deleteAllConform =true;
     

    },
    
    pageNate(pageNum) {
      this.page = pageNum;
      this.getNotifications();
    },
    selectCreatedDateRange(option) {
      option.startDate = moment(option.startDate).format("YYYY-MM-DD");
      option.endDate = moment(option.endDate).format("YYYY-MM-DD");
      this.selected_createdDateRange = [option.startDate, option.endDate];
    },
    set_filter: function() {

       if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        this.filter["createdDateRange"] = [
          this.selected_createdDateRange["startDate"],
          this.selected_createdDateRange["endDate"]
        ];
      }
      if(this.searchtxt !=''){
        this.filter["searchString"] = this.searchtxt;
      }
     
      this.getNotifications();
     
    },
    clear_filter: function() {
      this.searchtxt = "";
    
      this.selected_createdDateRange["startDate"] = "";
      this.selected_createdDateRange["endDate"] = "";
      this.filter ={};

     
      this.getNotifications();
    },
    
    sortMe(sort_key=''){
      this.page =1;
      if(sort_key !=''){
          this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
          this.sortKey ={};
          this.sortKey[sort_key] = this.sortKeys[sort_key]

          localStorage.setItem('notifications_sort_key', sort_key);
          localStorage.setItem('notifications_sort_value', this.sortKey[sort_key]);
          this.getNotifications();
      }
          
      

    },
    changeperPage(){
     
      this.page = 1;
      localStorage.setItem('notifications_perpage', this.perpage);
      this.getNotifications();
     
      
    },
  
  getNotifications(){
     let poatData = { 
         "page": this.page, 
         "perpage": this.perpage,
         "matcher":this.filter,
         "sortKeys":this.sortKey
         };
      this.$store.dispatch("getGlobalnotifications",poatData).then((response) => {
      this.notifications = response.result.list;
      this.totalpages = Math.ceil(response.result.totalCount / this.perpage);
    });

    },
  },

  mounted() {
    this.username = this.$store.state.user.name;
    this.roleId = this.$store.state.user["roleId"][0];

    this.sortKeys = {
      
      "createdOn":1,
     

    },

    this.sortKey['createdOn'] =1;

    if(localStorage.getItem('notifications_sort_key') && localStorage.getItem('notifications_sort_value')  && localStorage.getItem('notifications_sort_value') >=-1 ){
       this.sortKey = {};

      this.sortKey[localStorage.getItem('notifications_sort_key')] = parseInt(localStorage.getItem('notifications_sort_value'));
      this.sortKeys[localStorage.getItem('notifications_sort_key')] = this.sortKey[localStorage.getItem('notifications_sort_key')];

      //alert();

    }
    if(localStorage.getItem('notifications_perpage')){
        this.perpage = parseInt(localStorage.getItem('notifications_perpage'));
    }

       
   
    this.currentuserRole = this.$store.state.user.loginRoleId;
    this.getNotifications();
   

   
  }
};
</script>
