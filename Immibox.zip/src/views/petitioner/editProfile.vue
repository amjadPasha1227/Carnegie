<template>
  <div class="form_page company_details_sec">
    <div class="form_page_cnt">
      <!-- <div class="page_info">
        <p><info-icon size="1.5x" class="custom-class"></info-icon>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      </div> -->
      <div class="form_section" v-if="formLoaded">

        <div class="form-container">
          <h3 class="small-header"> Company Details</h3>
          <div class="vx-row">
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Email</label>
                <vs-input autocomplete="off" autocorrect="off" :disabled="[3].indexOf(getUserRoleId) <= -1" name="Email"
                  v-model="updateCompanyData.email" class="w-full" data-vv-as="Email" />
                <span class="text-danger text-sm" v-if="errors.has('Email')">{{ errors.first("Email") }}</span>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Company Name</label>
                <vs-input autocomplete="off" autocorrect="off" :disabled="false" name="Name"
                  v-model="updateCompanyData.name" class="w-full" data-vv-as="Name" />
                <span class="text-danger text-sm" v-if="errors.has('Name')">{{ errors.first("Name") }}</span>
              </div>
            </div>
            <div  v-if="getUserRoleId!=50 || true" class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Company Short Code <em>*</em>
                  <div class="IB_tooltip">
                    <span>
                      <info-icon size="1.5x" class="custom-class"></info-icon>
                    </span>
                    <div class="tooltip_cnt">
                      <p>
                        Company Short Code will be used as a prefix while creating
                        cases.
                      </p>
                    </div>
                  </div>
                </label>
                <vs-input type="text"
                  oninput="this.value = this.value.replace(/[^a-z A-Z 0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                  v-model="updateCompanyData.idPrefix"
                  :disabled="checkProperty(companyDetails, 'registrationCompleted') == true && checkProperty(companyDetails, 'idPrefix') != ''"
                  class="w-full" name="company_short_code" ref="company_short_code" autocomplete="off" autocorrect="off"
                  autocapitalize="none" v-validate="'required|min:3|max:15'" data-vv-as="Company Short Code" />
                <span class="text-danger text-sm" v-if="errors.has('company_short_code')">{{
                  errors.first("company_short_code")
                }}</span>
              </div>
            </div>

            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">First Name<em>*</em></label>
                <vs-input autocomplete="off" autocorrect="off" name="adminFirstName"
                  v-model="updateCompanyData.adminFirstName" class="w-full" data-vv-as="First Name"
                  v-validate="'required'" />
                <span class="text-danger text-sm" v-if="errors.has('adminFirstName')">{{
                  errors.first("adminFirstName")
                }}</span>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Last Name<em>*</em></label>
                <vs-input autocomplete="off" autocorrect="off" name="adminLastName"
                  v-model="updateCompanyData.adminLastName" class="w-full" data-vv-as="Last Name"
                  v-validate="'required'" />
                <span class="text-danger text-sm" v-if="errors.has('adminLastName')">{{
                  errors.first("adminLastName")
                }}</span>
              </div>
            </div>
          </div>

          <div class="vx-row">
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group ph_number">
                <div class="vs-component">
                  <label for="" class="form_label">Phone Number<em>*</em></label>
                  <VuePhoneNumberInput autocomplete="off" autocorrect="off" icon-pack="feather"
                    class="w-full no-icon-border" :no-example="false" v-bind="vuePhone.props" name="Companyphone"
                    data-vv-as="Phone Number"
                    :default-country-code="checkProperty(updateCompanyData['phoneCountryCode'], 'countryCode')"
                    placeholder="Company Phone Number" :no-country-selector="false" v-model="updateCompanyData.phone"
                    v-validate="'required'" @update="updateCompanyPhone" :preferred-countries="['US', 'IN']"/>
                  <span class="text-danger text-sm" v-if="errors.has('Companyphone') && errors.has('Companyphone')">{{
                    errors.first("Companyphone")
                  }}</span>
                  <span class="text-danger text-sm" v-else-if="!isPhoneValid">*Invalid phone number - Please enter a
                    valid one</span>


                </div>
              </div>
            </div>
            <immiPhone :fieldsArray="[]" :display="true" :tplkey="''" @updatephoneCountryCode="updatehomePhoneCountryCode" :countrycode="updateCompanyData.homePhoneCountryCode.countryCode" cid="benhomePhoneNumber" formscope="" v-model="updateCompanyData.homePhone" :tplsection="'beneficiaryInfo'"  :fieldName="'homePhoneNumber'" label="Mobile Telephone Number" placeHolder="Mobile Telephone Number" />
           
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <div class="vs-component">
                  <label for="" class="form_label">Fax Number</label>

                  <VuePhoneNumberInput autocomplete="off" autocorrect="off" icon-pack="feather"
                    class="w-full no-icon-border" :no-example="false" v-bind="vuePhone1.props" name="companyfaxphone"
                    data-vv-as="Fax Number"
                    :default-country-code="checkProperty(updateCompanyData['faxCountryCode'], 'countryCode')"
                    placeholder="Company Fax Number" :no-country-selector="false" v-model="updateCompanyData.fax"
                    @update="updateCompanyFax" :preferred-countries="['US', 'IN']"/>


                  <span class="text-danger text-sm"
                    v-if="errors.has('companyfaxphone') && errors.has('companyfaxphone')">{{
                      errors.first("companyfaxphone")
                    }}</span>
                  <span class="text-danger text-sm" v-else-if="!isCompanyFaxValid">*Invalid Fax number - Please enter
                    a valid one</span>


                </div>
              </div>
            </div>
            <!-----Communication Settings---->


            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label for="" class="form_label">NAICS Code (as per Tax Return)<em>*</em>
                  <div class="IB_tooltip">
                    <span>
                      <info-icon size="1.5x" class="custom-class"></info-icon>
                    </span>
                    <div class="tooltip_cnt">
                      <p>The NAICS numbering system employs a five or six-digit code at the most detailed industry
                        level.</p>
                    </div>
                  </div>
                </label>
                <div class="vs-component">
                  <div class="vs-con-input">
                    <the-mask autocomplete="off" autocorrect="off" name="naicsCode"
                      v-model="updateCompanyData.naicsCode" class="vs-inputx vs-input--input full"
                      data-vv-as="NAICS Code" v-validate="'required|min:2|max:6'" placeholder="######"
                      :mask="['######']" />
                  </div>
                  <span class="text-danger text-sm" v-if="errors.has('naicsCode')">{{
                    errors.first("naicsCode")
                  }}</span>
                </div>
              </div>
            </div>

            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label for="" class="form_label">Federal Employer Identification Number
                  <div class="IB_tooltip">
                    <span>
                      <info-icon size="1.5x" class="custom-class"></info-icon>
                    </span>
                    <div class="tooltip_cnt">
                      <p>FEIN is Federal Employer Identification Number (EIN/FEIN) and a nine-digit number assigned by the IRS, normally available in the documents issued by IRS or in Tax Returns.</p>
                    </div>
                  </div>
                </label>
                <div class="vs-component">
                  <div class="vs-con-input">
                    <the-mask autocomplete="off" autocorrect="off" name="feiNumber"
                      v-model="updateCompanyData.feiNumber" class="vs-inputx vs-input--input full"
                      data-vv-as="Federal Employer Identification Number" placeholder="##-#######"
                      :mask="['##-#######']" />
                  </div>
                  <!-- <span class="text-danger text-sm" v-if="errors.has('feiNumber')">{{ errors.first("feiNumber")
                    }}</span> -->
                </div>
              </div>
            </div>
          </div>

          <div class="vx-col w-full" @click="value = []">
            <div class="documents_group case_documents p-0">
                <div class="vx-row delete-row">
                  <div class="vx-col  w-full pb-0">
                    <div class="form_group mb-6">
                      <label for="" class="form_label" v-if="checkProperty(getUserData, 'tenantDetails') && checkProperty(getUserData, 'tenantDetails', 'slug') == 'slg'">
                        FEIN Document or SS-4
                      </label>
                      <label for="" class="form_label" v-else>FEIN Document or Latest Tax Return Document
                      </label>


                      <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                        :accept="allDocEntity"
                        :name="'FEIN Documet'" :multiple="true" :hideSelected="true" @input="uploaddoc(value,'feinDocument')">
                        <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                        Upload
                        <span v-if="uploading" class="loader"><img src="@/assets/images/main/loader.gif" /></span>
                      </file-upload>
                      
                    <span class="text-danger text-sm" v-if="errors.has('FEIN Documet')">{{
                      errors.first("FEIN Documet")
                    }}</span>
                    <ul class="uploaded-list" v-if="checkProperty(updateCompanyData, 'feinDocs', 'length') > 0">
                      <vs-chip @click="removedocs(index,'feinDocument')" v-for="(item, index) in updateCompanyData.feinDocs" :key="index"
                        closable><img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(item)" /> {{ item.name }} </vs-chip>
                    </ul>
                    </div>
                  </div>
                </div>
            </div>
          </div>
          <div class="vx-col w-full" @click="value = []" v-if="checkProperty(configurationDetails,'ptnrAttorneySignByInternal')">
            <div class="documents_group case_documents p-0">
                <div class="vx-row delete-row">
                  <div class="vx-col  w-full pb-0">
                    <div class="form_group mb-6">
                      <label for="" class="form_label">Electronic Signature</label>

                      <template v-if="true" >
                        <customCropImage @input="updateCropData" :vvas="'Electronic Signature'"  :display="true" :cid="'ElectronicDocuments'"  :formscope="''" :fieldName="'ElectronicDocuments'" :required="true"/>
                       
                      </template>
                      <template v-else>
                        <file-upload v-model="value" class="file-upload-input"
                        :accept="'.jpg,.jpeg,.png'"
                          name="signDocs" data-vv-as="signDocs" :multiple="false" :hideSelected="true" @input="upload(value,'signDocument')">
                          <img class="file-icon " src="@/assets/images/main/upload-big-arrow.svg"> Upload
                          <span class="loader" v-if="elsUploading"><img src="@/assets/images/main/loader.gif" /></span>
                        </file-upload>
                        <span class="file-type mb-0 d-block text-center">(File Type: JPEG,PNG,JPG. Max file size: 1MB)</span>
                        
                        <img v-if="updateTenantData.signDocs" class="file-icon upload-favicon" :src="updateTenantData.signDocs" @click="remove('signDocs')" >

                        <span class="text-danger text-sm" v-if="errors.has('signDocs')">{{errors.first("signDocs") }}</span>
                      </template>

                         <ul class="uploaded-list" v-if="checkProperty(updateCompanyData, 'signDocs', 'length') > 0">
                          <vs-chip @click="remove(index,'signDocument')" v-for="(item, index) in updateCompanyData.signDocs" :key="index"
                            closable> <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(item)" />
                            {{ item.name }} </vs-chip>
                        </ul>
                    </div>
                  </div>
                </div>
            </div>
          </div>
          
   
         <h3 class="small-header">Representative/Authorized Signatory</h3>

          <div class="vx-row">
            <div class="vx-col md:w-1/3 w-full">
              <div class="form_group">
                <label for="" class="form_label">Position/Title<em>*</em></label>
                <vs-input placeholder="Director / Vice President / Partner" autocomplete="off" autocorrect="off"
                  name="title" v-model="updateCompanyData.authorizedSignatory.title" class="w-full"
                  data-vv-as="Position/Title" v-validate="'required'" />
                <span class="text-danger text-sm" v-if="errors.has('title')">{{ errors.first("title") }}</span>
              </div>
            </div>


            <div class="vx-col md:w-1/3 w-full">
              <div class="form_group">
                <label for="" class="form_label">First Name<em>*</em></label>
                <vs-input autocomplete="off" autocorrect="off" name="FirstName"
                  v-model="updateCompanyData.authorizedSignatory.firstName" class="w-full" data-vv-as="First Name"
                  v-validate="'required'" />
                <span class="text-danger text-sm" v-if="errors.has('FirstName')">{{ errors.first("FirstName") }}</span>
              </div>
            </div>
            <!-- <div class="vx-col md:w-1/3 w-full" > 
                        <vs-input  autocomplete="off" autocorrect="off"   name="middleName" v-model="updateCompanyData.authorizedSignatory.middleName" class="w-full"
                          data-vv-as="Middle Name" label="Middle Name" v-validate="'required'" />
                        <span class="text-danger text-sm"
                          v-if="errors.has('middleName')">{{ errors.first("middleName") }}</span>
                    </div> -->
            <div class="vx-col md:w-1/3 w-full">
              <div class="form_group">
                <label for="" class="form_label">Last Name<em>*</em></label>
                <vs-input autocomplete="off" autocorrect="off" name="lastName"
                  v-model="updateCompanyData.authorizedSignatory.lastName" class="w-full" data-vv-as="Last Name"
                  v-validate="'required'" />
                <span class="text-danger text-sm" v-if="errors.has('lastName')">{{ errors.first("lastName") }}</span>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label for="" class="form_label">Email<em>*</em></label>
                <vs-input autocomplete="off" autocorrect="off" name="fromEmail"
                  v-model="updateCompanyData.authorizedSignatory.email" class="w-full" data-vv-as="Email"
                  v-validate="'required|email'" />
                <span class="text-danger text-sm" v-if="errors.has('fromEmail')">{{ errors.first("fromEmail") }}</span>
              </div>
            </div>

            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group ph_number">
                <div class="vs-component">
                  <label for="" class="form_label">Phone Number<em>*</em></label>
                    <VuePhoneNumberInput autocomplete="off" autocorrect="off" icon-pack="feather"
                    class="w-full no-icon-border" :no-example="false" v-bind="vuePhone.props" v-validate="'required'"
                    name="authorizedSignatoryphone" data-vv-as="Phone Number"
                    :default-country-code="checkProperty(updateCompanyData['authorizedSignatory']['phoneCountryCode'], 'countryCode')"
                    placeholder="Company Fax Number" :no-country-selector="false"
                    v-model="updateCompanyData.authorizedSignatory.phone" @update="updateAuthorizedSignatoryPhone" 
                    :preferred-countries="['US', 'IN']"/>
                  <span class="text-danger text-sm"
                    v-if="!isValidAuthorizedSignatoryPhone && !errors.has('authorizedSignatoryphone')">*Invalid phone
                    number - Please enter a valid one</span>

                  <span class="text-danger text-sm" v-if="errors.has('authorizedSignatoryphone')">{{
                    errors.first("authorizedSignatoryphone")
                  }}</span>
                </div>
              </div>
            </div>
            <immiPhone :fieldsArray="[]" :display="true" :tplkey="''" @updatephoneCountryCode="updatehomePhoneCode" :countrycode="updateCompanyData['authorizedSignatory'].homePhoneCountryCode.countryCode" cid="benhomePhoneNumber" formscope="" v-model="updateCompanyData['authorizedSignatory'].homePhone" :tplsection="'beneficiaryInfo'"  :fieldName="'homePhoneNumber_homePhoneNumber'" label="Mobile Telephone Number" placeHolder="Mobile Telephone Number" />
            </div>
           
          <h3 class="small-header"> Address </h3>
          <div class="vx-row">
            <div class="vx-col  w-full">
              <addressFields v-if="countries.length > 0" :addFormContainerCls="false" :validationRequired="true"
                :showaptType="true" :countries="countries" v-model="updateCompanyData.address" :cid="'add'" 
                :showAPTCheckBox="false"/>
            </div>
            <template v-if="false">
              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">
                  <label for="" class="form_label">Street Address<em>*</em></label>
                  <vs-input autocomplete="off" autocorrect="off" name="address1"
                    v-model="updateCompanyData.address.line1" class="w-full" data-vv-as="Street Address"
                    v-validate="'required'" />
                  <span class="text-danger text-sm" v-if="errors.has('address1')">{{ errors.first("address1") }}</span>
                </div>
              </div>

              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">
                  <label class="form_label">Apt, Suite</label>
                  <vs-input name="address2" v-model="updateCompanyData.address.line2" class="w-full"
                    data-vv-as="Apt, Suite" />
                  <span class="text-danger text-sm" v-if="errors.has('address2')">{{ errors.first("address2") }}</span>
                </div>
              </div>

              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">

                  <div class="con-select w-full select-large">
                    <label for class="form_label">Country<em>*</em></label>
                    <multiselect name="spouseaddresscountry" v-model="updateCompanyData.address.selectedCountry"
                      @input="changedCountry" :show-labels="false" track-by="id" label="name" data-vv-as="Country"
                      placeholder="Select Country" :options="countries" :searchable="true" :allow-empty="false"
                      v-validate="'required'" ref="bncountry" :disabled="true"></multiselect>
                  </div>


                  <span class="text-danger text-sm" v-if="errors.has('spouseaddresscountry')">{{
                    errors.first("spouseaddresscountry")
                  }}</span>
                </div>
              </div>
              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for class="form_label">State<em v-if="checkProperty(states, 'length') > 0">*</em></label>
                    <multiselect name="State" v-model="updateCompanyData.address.selectedState" @input="changedState"
                      :show-labels="false" track-by="id" label="name" data-vv-as="State" placeholder="Select State"
                      :options="states" :searchable="true" :allow-empty="false"
                      v-validate="{ 'required': states.length > 0 }">
                    </multiselect>
                  </div>

                  <span class="text-danger text-sm" v-if="errors.has('State')">{{ errors.first("State") }}</span>
                </div>
              </div>
              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for class="form_label">City<em v-if="checkProperty(locations, 'length') > 0">*</em></label>
                    <multiselect name="city" v-model="updateCompanyData.address.selectedCity" @input="changedCity"
                      v-validate="{ 'required': locations.length > 0 }" :show-labels="false" track-by="id" label="name"
                      data-vv-as="City" placeholder="Select City" :options="locations" :searchable="true"
                      :allow-empty="false">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-if="errors.has('city')">{{ errors.first("city") }}</span>
                </div>
              </div>
              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">
                  <label for class="form_label">Zip Code<em>*</em></label>
                  <vs-input name="zipcode" v-model="updateCompanyData.address.zipcode"
                    v-validate="'numeric|required|zipcodev:bncountry'" class="w-full" data-vv-as="Zip Code"
                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');" />
                  <span class="text-danger text-sm" v-if="errors.has('zipcode')">{{ errors.first("zipcode") }}</span>
                </div>
              </div>
            </template>


          </div>

          <h3 class="small-header"> Business Information</h3>
          <div class="vx-row">

            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label for="" class="form_label">Type of Business</label>
                <vs-input autocomplete="off" autocorrect="off" name="typeOfBusiness"
                  v-model="updateCompanyData.typeOfBusiness" class="w-full" data-vv-as="Type of Business"
                  v-validate="'max:150'" />
                <span class="text-danger text-sm" v-if="errors.has('typeOfBusiness')">{{
                  errors.first("typeOfBusiness")
                }}</span>
              </div>
            </div>

            <div class="vx-col w-full" v-if="false" >
              <div class="form_group w-full mb-6">
                <label for class="form_label">Briefly describe the nature of your business<em>*</em></label>
                <ckeditor data-vv-as=" Nature of business" v-validate="'required'" name="natureOfBusiness"
                  :editor="editor" v-model="updateCompanyData.natureOfBusiness" :config="editorConfig"></ckeditor>



                <span class="text-danger text-sm" v-if="errors.has('natureOfBusiness')">{{
                  errors.first("natureOfBusiness")
                }}</span>

              </div>
            </div>
            <div class="vx-col w-full" >
              <quillTextEditor :wrapclass="'w-full'" v-model="updateCompanyData.natureOfBusiness" :label="'Briefly describe the nature of your business'"
              :fieldName="'natureOfBusiness'" :required="true" :cid="'natureOfBusiness'" :placeHolder="'Nature of business'" />
            </div>
            <!-- <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <div class="vs-component">
                  <label class="form_label">Date of business was established<em>*</em></label>
                  <datepicker :typeable="true" name="businessEstdDate" :disabled-dates='disabledDates'
                    v-validate="'required'" data-vv-as="Date of business was established"
                    v-model="updateCompanyData.businessEstdDate" placeholder="MM/DD/YYYY">
                  </datepicker>
                  <span class="text-danger text-sm" v-if="errors.has('businessEstdDate')">{{
                    errors.first("businessEstdDate") }}</span>
                </div>
              </div>
            </div> -->

            <datepickerField wrapclass="md:w-1/2" :display="true" :dateEnableTo="disabledDates"
              v-model="updateCompanyData.businessEstdDate" fieldName="businessEstdDate"
              label="Date of business was established" :validationRequired="true" />
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Total number of full-time employees<em>*</em></label>
                <vs-input autocomplete="off" autocorrect="off" name="totalFullTimeEmployees"
                  v-model="updateCompanyData.totalFullTimeEmployees" class="w-full"
                  data-vv-as="Total number of full-time employees" v-validate="'required'"
                  oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');" />
                <span class="text-danger text-sm" v-if="errors.has('totalFullTimeEmployees')">{{
                  errors.first("totalFullTimeEmployees")
                }}</span>
              </div>
            </div>

            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Estimated gross annual income<em>*</em></label>
                <vs-input autocomplete="off" autocorrect="off" name="estimatedGrossAnualIncome"
                  v-model="updateCompanyData.estimatedGrossAnualIncome" class="w-full"
                  data-vv-as="Estimated gross annual income" v-validate="'required'" />
                <span class="text-danger text-sm" v-if="errors.has('estimatedGrossAnualIncome')">{{
                  errors.first("estimatedGrossAnualIncome")
                }}</span>
              </div>
            </div>

            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Estimated net annual income</label>
                <vs-input autocomplete="off" autocorrect="off" name="estimatedNetAnualIncome"
                  v-model="updateCompanyData.estimatedNetAnualIncome" class="w-full"
                  data-vv-as="Estimated net annual income" />
                <span class="text-danger text-sm" v-if="errors.has('estimatedNetAnualIncome')">{{
                  errors.first("estimatedNetAnualIncome")
                }}</span>
              </div>
            </div>

            <div class="vx-col w-full pt-2">

              <div class="table_switch switch_inlinlbl">
                <vs-switch success v-model="updateCompanyData.are50orMoreEmployeesInUS"
                  @change="are50orMoreEmployeesInUSChanged()" :name="'are50orMoreEmployeesInUS'">
                  <template #off>
                    <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none"
                      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                      class="custom-class feather feather-x">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                  </template>
                  <template #on>
                    <check-icon size="1.5x" class="custom-class"></check-icon>
                  </template>
                </vs-switch>

                Do you have 50 or more employees in USA?
              </div>




            </div>

            <div class="vx-col w-full pt-4" v-if="updateCompanyData.are50orMoreEmployeesInUS">

              <div class="table_switch switch_inlinlbl">
                <vs-switch success v-model="updateCompanyData.areAbove50PercentH1BL1ALABStatus"
                  :name="'areAbove50PercentH1BL1ALABStatus'">
                  <template #off>
                    <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none"
                      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                      class="custom-class feather feather-x">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                  </template>
                  <template #on>
                    <check-icon size="1.5x" class="custom-class"></check-icon>
                  </template>
                </vs-switch>

                <!-- Are Above 50 Percent H1B L1 AL AB Status-->
                Does 50% or more employees on H1/L1A/L1B Nonimmigrant status?
              </div>



              <!-- <span class="text-danger text-sm"  v-if="errors.has('areAbove50PercentH1BL1ALABStatus')">{{ errors.first("areAbove50PercentH1BL1ALABStatus") }}</span> -->

            </div>


            <div class="vx-col w-full pt-2" v-if="updateCompanyData.areAbove50PercentH1BL1ALABStatus && false">
              <div class="vx-col w-full page_info mb-2">
                <p> An additional $4000 must be paid to the Department of Homeland Security towards Border Security Fee.
                </p>

              </div>
            </div>







          </div>
          <template v-if="checkProperty(configurationDetails,'acceptCompayDocsForPtnr')">
            <h3 class="small-header mt-6 pt-3">Documents</h3>


            <div class="vx-col w-full" @click="value = []">
              <div class="documents_group case_documents p-0">
                <div class="vx-row delete-row">
                  <div class="vx-col  w-full pb-0">
                    <div class="form_group">
                      <label for="" class="form_label" >
                          <span>Document identifying the EIN number (Form SS-4 issued by IRS)</span>
                          </label>
                          <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                            :accept="allDocEntity"
                            :name="'fein_Documet'" :multiple="true" :hideSelected="true" @input="uploaddoc(value,'fein')">
                            <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                            Upload
                            <span v-if="feinuploading" class="loader"><img src="@/assets/images/main/loader.gif" /></span>
                          </file-upload>
                        <span class="text-danger text-sm" v-if="errors.has('fein_Documet')">{{
                          errors.first("fein_Documet")
                        }}</span>


                        <ul class="uploaded-list" v-if="checkProperty(updateCompanyData['documents'], 'fein', 'length') > 0">
                          <vs-chip @click="removedocs(index,'fein')" v-for="(item, index) in updateCompanyData['documents'].fein" :key="index"
                            closable> {{ item.name }} </vs-chip>
                        </ul>
                    </div>
                  </div>
                </div>
              </div>
            
          </div>





            <div class="edit_comp_casedocs">
              <casedocumentslist :docslist="ptnrDocslist" :showTitle="false"  formscope="" :fieldsArray="[]" v-model="updateCompanyData.documents" :tplsection="'documents'"  :fieldName="''" ></casedocumentslist>
            </div>
          </template>
          <h3 class="small-header mt-6 pt-3">Settings</h3>

          <template>

            <div class="vx-col md:w-1/2 w-full additional_contacts" style="padding-top:0px;">
              <div class="form_group">
                <label for="" class="form_label">List of additional contacts to be notified<em></em>
                  <div class="IB_tooltip">
                    <span>
                      <info-icon size="1.5x" class="custom-class"></info-icon>
                    </span>
                    <div class="tooltip_cnt">
                      <p>List of additional contacts to be notified</p>
                    </div>
                  </div>
                </label>
              </div>
              <div class="form_group" :key="index" v-for="(commuEmails, index) in commuEmailslist">
                <div class="vs-con-input">
                  <vs-input v-validate="'email'" class="w-full add_email_cont" :name="'commuEmails' + index" icon-pack="feather"
                    placeholder="Email" data-vv-as="Email" icon-after v-model="commuEmails.email" />


                  <span class="text-danger text-sm" v-show="errors.has('commuEmails' + index)">{{
                    errors.first("commuEmails" + index)
                  }}</span>


                </div>
                <div class="delete" v-if="index != 0" @click="removeEmails(index)">
                  <a> <img src="@/assets/images/main/delete-row-img.svg" /></a>
                </div>


              </div>

              <div class="vx-row">
                <div class="vx-col w-1/3 ">
                  <a class="add-more d-inline-flex" @click="addEmails()"><span class="mr-2">+</span>Add More</a>
                </div>
              </div>





            </div>


            <template>
              <div class="vx-col md:w-1/2 w-full" v-if="getUserRoleId == 3 || getUserRoleId == 50">
                <div class="form_group">
                  <p class="tasks_brief">Receive tasks brief every
                    <vs-input class="textfiled" name="ClientId" icon-pack="feather" v-validate="'numeric'"
                      data-vv-as="Briefing Days" icon-after v-model="config.ptnrBriefDays" /> day(s).
                  </p>

                </div>
              </div>


              <div class="vx-col md:w-1/2 w-full" v-if="getUserRoleId == 3 || getUserRoleId == 50">
                <div class="form_group">
                  <p class="tasks_brief">Send beneficiary tasks brief every
                    <vs-input class="textfiled" name="ClientId" icon-pack="feather" v-validate="'numeric'"
                      data-vv-as="Briefing Days" icon-after v-model="config.bnfBriefDays" /> day(s).
                  </p>

                </div>
              </div>
              <template v-if="getUserRoleId == 3">
                <div class="vx-col md:w-1/2 w-full">
                  <div class="form_group">
                    <p class="tasks_brief">Remind petitioner to update information for every
                      <vs-input class="textfiled" name="ClientId" icon-pack="feather" v-validate="'numeric'"
                        data-vv-as="Briefing Days" icon-after v-model="config.remindPtnrInfoUpdateDays" /> day(s).
                    </p>

                  </div>
                </div>
                <div class="vx-col w-full">
                  <div class="form_group">
                    <p class="tasks_brief">Send reminder if PERM Application is not filed
                      <vs-switch class="edc_switch" v-model="config.enablePermFilingReminder">
                        <span slot="on">Yes</span>
                        <span slot="off">No</span>
                      </vs-switch>
                    </p>
                  </div>
                </div>
                <div class="vx-col w-full">
                  <div class="form_group">
                    <p class="tasks_brief">Send reminder if I-140 is not filed
                      <vs-switch class="edc_switch" v-model="config.enableI140Reminders">
                        <span slot="on">Yes</span>
                        <span slot="off">No</span>
                      </vs-switch>
                    </p>
                  </div>
                </div>

                <div class="vx-col w-full">
                  <div class="form_group">
                    <p class="tasks_brief">Send reminder to Petitioner if the Sponsorship Questionnaire is not responded
                      to DOL
                      <vs-switch class="edc_switch" v-model="config.enableSponQuestionnireReminder">
                        <span slot="on">Yes</span>
                        <span slot="off">No</span>
                      </vs-switch>
                    </p>
                  </div>
                </div>
              </template>
            </template>

          </template>




        </div>

        <div class="form-footer">

          <!--<button v-if="checkProperty(companyDetails ,'registrationCompleted')"  @click="completeTenantprofile=false"  class="cancel">Cancel</button>-->
          <button class="save" :disabled="formSubmited || uploading" @click="updateCompanyDetails()">
            <template v-if="[50].indexOf(getUserRoleId) > -1">
              {{ profileCompleted?'Update': 'Complete' }}
            </template>
            <template v-else>Update</template>

          </button>
        </div>

      </div>
    </div>
  </div>

</template>


<script>
import customCropImage from '@/views/forms/fields/customCropImage.vue'
import immiPhone from "@/views/forms/fields/phonenumber.vue";
import casedocumentslist from "@/views/common/casedocuments.vue";
import VxAutoSuggest from "@/components/vx-auto-suggest/VxAutoSuggest.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import draggable from "vuedraggable";
import DateRangePicker from "vue2-daterange-picker";
import moment from "moment";
import Datepicker from "vuejs-datepicker-inv";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import FileUpload from "vue-upload-component/src";
import * as _ from "lodash";
import { InfoIcon } from 'vue-feather-icons'
import { CheckIcon } from 'vue-feather-icons'
import JQuery from "jquery";
import { TheMask } from 'vue-the-mask';
//import addressFields from "@/views/common/addressForm.vue";
import addressFields from "@/views/forms/fields/address.vue";
import quillTextEditor from "@/views/forms/fields/quillTextEditor.vue";
import Vue from "vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
Vue.use(CKEditor);
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
  name: "the-navbar",
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  props: {
    navbarColor: {
      type: String,
      default: "#fff",
    },
  },
  data() {
    return {
     
      ptnrDocslist: [
        {
          required: false,
          key: 'articleOfIncorp',
          fieldName: 'articleOfIncorp',
          label: 'Articles of Incorporation'
        },
        {
          key: 'stateRegCert',
          fieldName: 'stateRegCert',
          required: false,
          label: 'State Registration Certificate'
        },
        // {
        //   key: 'fein',
        //   fieldName: 'fein',
        //   required: false,
        //   label: 'Document identifying the EIN number (Form SS-4 issued by IRS)'
        // },
        {
          key: 'goodStandCert',
          fieldName: 'goodStandCert',
          required: false,
          label: 'Good standing certificate'
        },
        {
          key: 'markMetOrWebsitePrints',
          fieldName: 'markMetOrWebsitePrints',
          required: false,
          label: 'Marketing materials/website printouts'
        },
        {
          key: 'orgCharts',
          fieldName: 'orgCharts',
          required: false,
          label: 'Organizational chart'
        },
        {
          key: 'latestTaxReturn',
          fieldName: 'latestTaxReturn',
          required: false,
          label: 'Last two years Federal income tax returns'
        },
        {
          key: 'latestWageReports',
          fieldName: 'latestWageReports',
          required: false,
          label: 'Copy of Last four quaterly wage reports'
        },
        {
          key: 'letterHeads',
          fieldName: 'letterHeads',
          required: false,
          noteInfo:true,
          label: 'Copy of Petitioner letterhead in word format',
          fileAcceptType:"MSWORD"
        },
      ],
      value: [],
      elsUploading:false,
    disable_uploadBtn: false,
      fieidocuments: [],
      uploading: false,
      feinuploading:false,
      loading: false,
      editor: ClassicEditor,
      editorConfig: {
        toolbar: ['heading','|','bold', 'italic', '|','link', 'undo',  'redo', ,"indent" ,"Outdent", 'NumberedList', 'BulletedList','blockQuote'],
      },
      disabledDates: {
        from: new Date(),


      },
      isPhoneValid: true,
      isCompanyFaxValid: true,
      isValidAuthorizedSignatoryPhone: true,
      profileCompleted: false,
      formLoaded: false,
      logoUploading: false,
      formSubmited: false,
      showIncompleteCheckListTxt: true,
      isloading: false,
      documents: [],
      countries: [],
      states: [],
      locations: [],
      formerrors: {
        msg: ""
      },
      vuePhone: {
        props: {
          translations: {
            phoneNumberLabel: "Phone Number"
          }
        }

      },
      vuePhone1: {
        props: {
          translations: {
            phoneNumberLabel: "Fax Number"
          }
        }

      },
      tenantDetails: null,
      updateTenantData: {
        "profComplted": "no",
        "tenantId": "",
        "name": "",
        "adminEmail": '',
        "adminFirstName": "",
        "adminLastName": "",
        "phone": "",
        "phoneCountryCode": { countryCode: '', countryCallingCode: '' },
        "logo": "",
        "favicon": "",
        "fromEmail": "",
        "contactEmail": "",
        "idPrefix": "",
        "slug": "",
        "assetPath": "",
        "address": {
          "line1": "",
          "line2": "",
          "countryId": '',
          "stateId": '',
          "locationId": '',
          "zipcode": "",
          countryDetails: null,
          stateDetails: null,
          locationDetails: null,
          aptType: '',
        }
      },
      completeTenantprofile: false,
      disabledDates: {
        from: new Date(),
      },
      navbarSearchAndPinList: this.$store.state.navbarSearchAndPinList,
      searchQuery: "",
      showFullSearch: false,
      pageTitle: "",
      unreadNotifications: [],
      settings: {
        maxScrollbarLength: 60,
        wheelSpeed: 0.6,
      },
      autoFocusSearch: false,
      showBookmarkPagesDropdown: false,
      SubmtRminder: false,
      reminder: {
        name: "",
        description: "",
        dueDate: new Date(),
      },
      autoApply: "",
      reminderCount: 0,
      disable_reminder_btn: false,
      delNotification: { "notifyId": '', 'removeAll': false },
      deleteAllConform: false,
      notification_popuptitle: 'Delete',
      companyDetails: null,
      companyId: null,

      updateCompanyData: {
        "companyId": "",
        "email": '',
        idPrefix: '',
        adminFirstName: '',
        adminLastName: '',
        "name": "",
        "phone": "",
        "phoneCountryCode": { countryCode: '', countryCallingCode: '' },
        "homePhone": "",
        "homePhoneCountryCode": { countryCode: '', countryCallingCode: '' },
        "fax": "",
        "faxCountryCode": { countryCode: '', countryCallingCode: '' },
        "irstaxId": "",
        "naicsCode": "",
        "feiNumber": '',
        "feinDocs": [],
        "signDocs":[],
        "address": {
          "line1": "",
          "line2": "",
          "locationId": 0,
          "stateId": 0,
          "countryId": 0,
          "zipcode": "",
          selectedCountry: { "_id": "61408c9ed01ea1248cdcf6b7", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" },
          countryDetails: { "_id": "61408c9ed01ea1248cdcf6b7", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" },
          stateDetails: null,
          locationDetails: null,
          aptType: '',

        },
        "authorizedSignatory": {
          "name": '',
          "firstName": "",
          "lastName": "",
          "title": "",
          "email": "",
          "phone": "",
          "phoneCountryCode": { countryCode: '', countryCallingCode: '' },
          "homePhone": "",
          "homePhoneCountryCode": { countryCode: '', countryCallingCode: '' },
        },
        documents: {
          articleOfIncorp: [],
          stateRegCert: [],
          fein: [],
          goodStandCert: [],
          markMetOrWebsitePrints: [],
          orgCharts: [],
          latestTaxReturn: [],
          latestWageReports: [],
          letterHeads: [],
        },
        typeOfBusiness: '',
        "natureOfBusiness": "",
        "businessEstdDate": "",
        "totalFullTimeEmployees": "",
        "are50orMoreEmployeesInUS": "no",
        "areAbove50PercentH1BL1ALABStatus": "no",
        "finalDeterminationFromDOL": "no",
        "estimatedNetAnualIncome": 2342.55,
        "estimatedGrossAnualIncome": 2342.55,
        "logo": "https://innvectra.rmtportal.com/logo.png",
        //"completeRegistration": true // it should be true only if it is petitioner
      },
      configSaving: false,
      commuEmailslist: [{ email: '' }],
      config: {
        'ptnrBriefDays': null,
        commuEmails: '',
        bnfBriefDays: null,
        enableI140Reminders: false,
        enablePermFilingReminder: false,
        enableSponQuestionnireReminder: false,
        remindPtnrInfoUpdateDays: null,

      },
      configurationDetails:null,
      configDetails: null,
      linkShareToEmailList: [],
    };
  },
  watch: {
    $route() {
      this.pageTitle = this.$route.meta.title;
      this.isTenantProfileCompleted;
      this.getPetitionerProfileCompaltion;
      this.formSubmited = false;

      if (this.showBookmarkPagesDropdown)
        this.showBookmarkPagesDropdown = false;

    },
  },
  mounted() {

    this.disabledDates = {
      from: new Date(),
      //to: c, // Disable all dates up to specific date

    },
    this.getGlobalConfigDetails();
      this.masterData("countries");
    this.profileCompleted = this.$store.state.common.profileCompleted;


    if (this.getUserRoleId == 50 && _.has(this.getUserData, 'companyId')) {
      this.updateCompanyData = Object.assign(this.updateCompanyData, { "companyId": this.getUserData['companyId'] })
      this.companyId = this.getUserData['companyId'];
      this.getCompanyDetails();

    } else if (this.checkProperty(this.$route, 'params', 'itemId') && this.checkPetProfileEditPermisions) {
      this.companyId = this.checkProperty(this.$route, 'params', 'itemId');

      this.updateCompanyData = Object.assign(this.updateCompanyData, { "companyId": this.companyId })
      // this.profileCompleted

      this.getCompanyDetails();




    }

    //this.$modal.show('updateTenantProfile-modal');
    setTimeout(() => {

      //  this.$store.dispatch("updateSidebarWidth", "default");
      //btnSidebarToggler
      //JQuery("#btnSidebarToggler").trigger("click")

    }, 500)


    this.changedState({ "_id": "61408c9ed01ea1248cdcf6b7", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" });


  },
  computed: {

    getPetitionerProfileCompaltion() {


      if (this.getUserRoleId == 50) {

        if (this.$store.getters['getPetitionerProfileCompaltion']) {

          return false;
        } else {

          return true
        }
      } else {
        return false;
      }
    },




  },
  methods: {
    updateCropData(data){
          //this.croppedImageData =data;
          this.updateCompanyData['signDocs'] =[];
          this.updateCompanyData['signDocs'].push(data) ;
        },
    updatehomePhoneCountryCode(data){
        this.updateCompanyData.homePhoneCountryCode =data;
    },
    updatehomePhoneCode(data){
      this.updateCompanyData['authorizedSignatory'].homePhoneCountryCode =data;
    },
    
    removeEmails(index) {
      this.commuEmailslist.splice(index, 1);

    },
    addEmails() {

      this.commuEmailslist.push(

        {
          email: ''
        }
      )
    },
    formatEmail(assignValue = false) {

      // linkShareToemailsText:'',
      // sharing:false,
      let emailList = [];
      if (_.has(this.config, 'commuEmails')) {
        emailList = this.config['commuEmails'].split(',');
      }

      this.linkShareToEmailList = [];
      let tempEmailList = [];
      if (this.checkProperty(emailList, 'length') > 0) {
        const validateEmail = (email) => {
          return String(email)
            .toLowerCase()
            .match(
              /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
            );
        };

        this.linkShareToEmailList = _.filter(emailList, (email) => {
          if (validateEmail(email)) {
            return true;
          } else {
            return false;
          }

        })
        if (assignValue) {
          this.linkShareToEmailList = _.uniq(this.linkShareToEmailList, true);
          this.config['commuEmails'] = this.linkShareToEmailList.join(',');
        }


        // alert(JSON.stringify(this.linkShareToEmailList));


      }

    },
    updateConfig() {
      this.formatEmail(true);


      let path = "/company/update-config"
      if (this.checkProperty(this.configDetails, "_id")) {
        path = "/company/update-config"
      }
      let self = this;
      let config = _.cloneDeep(self.config);
      config['ptnrBriefDays'] = parseInt(config.ptnrBriefDays);
      if (parseInt(config.ptnrBriefDays) <= 0) {
        config['ptnrBriefDays'] = null
      }
      if (parseInt(config.bnfBriefDays) <= 0) {
        config['bnfBriefDays'] = null
      }

      var _strin = [];
      if (self.commuEmailslist.length > 0) {

        self.commuEmailslist.forEach(function (item) {
          _strin.push(item.email)

        })
      }

      if (_strin.length > 0) {
        config['commuEmails'] = _strin.join(',')

      }






      this.configSaving = true;
      let postData = {
        "config": config
      }
      if (this.companyId) {
        postData = Object.assign(postData, { 'companyId': this.companyId })

      }
      this.$store.dispatch("commonAction", { data: postData, path: path })

        .then((response) => {
          this.configSaving = false;
          //    this.showToster({message:response.message,isError:false });
          // this.getGlobalConfigDetails();


        })
        .catch((error) => {
          this.configSaving = false;
          //this.showToster({message:error,isError:true });

        });




    },
    are50orMoreEmployeesInUSChanged() {
      if (!this.updateCompanyData.are50orMoreEmployeesInUS) {
        this.updateCompanyData.areAbove50PercentH1BL1ALABStatus = false;
      }
    },
    editMyDetails() {
      if (this.getUserRoleId == 3) {
        this.$store.dispatch("editTenantDetails")
          .then((res) => {
            
            this.isTenantProfileCompleted;
          });
      }

    },
    editCompanyDetails() {
      this.$store.dispatch("editCompanyDetails")
        .then((res) => {
          
          this.getPetitionerProfileCompaltion();

        });

    },
    updateCompanyPhone(item) {

      this.isPhoneValid = true;

      if (item.isValid) {

        this.updateCompanyData.phoneCountryCode = { countryCode: item.countryCode, countryCallingCode: item.countryCallingCode };
        this.updateCompanyData.phone = item.nationalNumber;

      } else {
        this.isPhoneValid = false;
      }
    },
    updateHomePhone(item) {
       this.isPhoneValid = true;
        if (item.isValid) {
          this.updateCompanyData.homePhoneCountryCode = { countryCode: item.countryCode, countryCallingCode: item.countryCallingCode };
          this.updateCompanyData.phone = item.nationalNumber;
        } else {
          this.isPhoneValid = false;
        }
      },
    updateCompanyFax(item) {
      this.isCompanyFaxValid = true;
      if (item.isValid) {
        this.updateCompanyData.faxCountryCode = { countryCode: item.countryCode, countryCallingCode: item.countryCallingCode };
        this.updateCompanyData.fax = item.nationalNumber;
      } else {

        this.isCompanyFaxValid = false;
      }
    },
    updateAuthorizedSignatoryPhone(item) {
      this.isValidAuthorizedSignatoryPhone = true;
      if (item.isValid) {
        this.updateCompanyData['authorizedSignatory'].phoneCountryCode = { countryCode: item.countryCode, countryCallingCode: item.countryCallingCode };
        this.updateCompanyData['authorizedSignatory'].phone = item.nationalNumber;
      } else {
        this.isValidAuthorizedSignatoryPhone = false;
      }
    },
    getCompanyDetails(isRedirect = false) {
      let self = this;
      this.isPhoneValid = true;
      this.isCompanyFaxValid = true;
      this.isValidAuthorizedSignatoryPhone = true;
      let postData = { "companyId": self.companyId };
      this.$store.dispatch("getCompanyDetails", postData)
        .then(res => {
          let response = res
          if(_.has(response,'authorizedSignatory') && (!_.has(response['authorizedSignatory'],'homePhoneCountryCode')||
          !this.checkProperty(response['authorizedSignatory'],'homePhoneCountryCode'))){
            response['authorizedSignatory']['homePhoneCountryCode'] = { countryCode: '', countryCallingCode: '' },
            response['authorizedSignatory']['homePhone'] = ''
          }
          if(_.has(response,'homePhoneCountryCode') || !this.checkProperty(response,'homePhoneCountryCode')){
            response['homePhoneCountryCode'] = { countryCode: '', countryCallingCode: '' },
            response['homePhone'] = ''
          }
          let companyData = response;
          this.companyDetails = response;
          //config
          if (this.checkProperty(this.companyDetails, 'config')) {
            this.config = this.companyDetails['config'];


            // enableI140Reminders:false,
            // enablePermFilingReminder:false,
            //   enableSponQuestionnireReminder:false,

            if (!_.has(this.config, 'enableI140Reminders')) {
              this.config = Object.assign(this.config, { "enableI140Reminders": false });
            }
            if (!_.has(this.config, 'enablePermFilingReminder')) {
              this.config = Object.assign(this.config, { "enablePermFilingReminder": false });
            }
            if (!_.has(this.config, 'enableSponQuestionnireReminder')) {
              this.config = Object.assign(this.config, { "enableSponQuestionnireReminder": false });
            }
            if (!_.has(this.config, 'remindPtnrInfoUpdateDays')) {
              this.config = Object.assign(this.config, { "remindPtnrInfoUpdateDays": null });
            }

            this.config = _.cloneDeep(this.config);


            if (this.config.commuEmails != '') {
              this.commuEmailslist = [];
              var _eitems = [];
              if (this.config && _.has(this.config, 'commuEmails')) {
                _eitems = this.config.commuEmails.split(',')
              }
              _.forEach(_eitems, (value, key) => {
                this.commuEmailslist.push({ email: value })
              })

            }
            this.formatEmail(true);

          }
          this.getPetitionerProfileCompaltion;
          this.formLoaded = true;
          //now update updateCompanyData verable for update company data.
          _.forEach(companyData, (value, key) => {
            // alert("key=="+key +"   VALUE=="+value);
            if (key == 'address') {
              let address = { line1: "", line2: "", countryId: '', selectedCountry: null, "countryDetails": null, stateId: '', "stateDetails": null, selectedState: null, locationId: '', "locationDetails": null, selectedCity: null, zipcode: '', 'aptType': '' };

              if (!_.has(companyData['address'], 'aptType')) {
                companyData['address']['aptType'] = "APT"
              }
              _.forEach(companyData['address'], (adval, adkey) => {

                address[adkey] = adval;

                // if(adkey=='stateDetails'){
                //   this.updateCompanyData.address.selectedState =adval;
                //   address['selectedState'] =adval;
                //   this.changedState()

                // }
                // if(adkey=='locationDetails'){
                //   this.updateCompanyData.address.selectedCity =adval;
                //   address['selectedCity'] =adval;
                //   this.changedState()

                // }

              })

              if (!_.has(address, 'aptType')) {
                address = Object.assign(address, { 'aptType': 'APT' })
              }




              this.updateCompanyData['address'] = _.cloneDeep(address);
              this.updateCompanyData = _.cloneDeep(this.updateCompanyData);

              if (this.countries.length >= 0) {
                this.updateCompanyData['address']['selectedCountry'] = _.find(this.countries, { "id": 231 })
                this.updateCompanyData['address']['countryId'] = 231
                this.updateCompanyData = _.cloneDeep(this.updateCompanyData);

                // this.changedCountry();
              }



            } else if (key == 'authorizedSignatory') {



              _.forEach(companyData['authorizedSignatory'], (authval, authkey) => {

                if (_.has(this.updateCompanyData['authorizedSignatory'], authkey)) {
                  this.updateCompanyData.authorizedSignatory[authkey] = authval;
                  //alert(this.updateCompanyData['authorizedSignatory'][authkey]);
                }

              })


            } else if (_.has(this.updateCompanyData, key)) {
              this.updateCompanyData[key] = value;
              if (key == "are50orMoreEmployeesInUS") {
                if (value.toLowerCase() == "yes") {
                  this.updateCompanyData['are50orMoreEmployeesInUS'] = true;
                } else {
                  this.updateCompanyData['are50orMoreEmployeesInUS'] = false;
                }

              }
              if (key == "finalDeterminationFromDOL") {
                if (value.toLowerCase() == "yes") {
                  this.updateCompanyData['finalDeterminationFromDOL'] = true;
                } else {
                  this.updateCompanyData['finalDeterminationFromDOL'] = false;
                }

              }
              if (key == "areAbove50PercentH1BL1ALABStatus") {
                if (value.toLowerCase() == "yes") {
                  this.updateCompanyData['areAbove50PercentH1BL1ALABStatus'] = true;
                } else {
                  this.updateCompanyData['areAbove50PercentH1BL1ALABStatus'] = false;
                }

              }

            }
           

            let tempupdateCompanyData = _.cloneDeep(this.updateCompanyData);
            this.updateCompanyData = tempupdateCompanyData;



          })
          this.$validator.reset();
          setTimeout(() => {
            this.isPhoneValid = true;
            this.isCompanyFaxValid = true;
            this.isValidAuthorizedSignatoryPhone = true;
            if (!companyData['registrationCompleted'] && [50].indexOf(this.getUserRoleId) > -1) {
              this.getDetailsFromOtherTenant();
            }


            if (isRedirect) {
              this.$router.push('/dashboard')

            }


          }, 100);



        })
        .catch(error => {

          
        })


    },

    scrollWIndow() {
      const $ = JQuery;

      $("html, body").animate(
        {
          scrollTop: $(".text-danger").first().offset().top,
        },
        2000
      );

      //  const firstField = Object.keys(this.errors.collect())[0];
      // const ele = $('[name=' + firstField + ']').parents('.vx-col');
      //  $('html, body').animate({ scrollTop: ele.offset().top }, 2000);
    },
    updateCompanyDetails() {
      //alert(JSON.stringify(this.updateTenantData))
      this.formatEmail(true);
      this.$validator.validateAll().then(result => {
        this.updateConfig();
        if (result && this.isValidAuthorizedSignatoryPhone) {
          let postData = _.cloneDeep(this.updateCompanyData);

          postData = Object.assign(postData, { completeRegistration: true })

          // if(this.value){
          //     postData = Object.assign(postData ,{"fienDocs":this.value})
          //  }

          if (this.updateCompanyData.are50orMoreEmployeesInUS) {
            postData = Object.assign(postData, { "are50orMoreEmployeesInUS": 'Yes' })
          } else {
            postData = Object.assign(postData, { "are50orMoreEmployeesInUS": 'No' })
          }

          if (this.updateCompanyData.areAbove50PercentH1BL1ALABStatus) {
            postData = Object.assign(postData, { "areAbove50PercentH1BL1ALABStatus": 'Yes' })
          } else {
            postData = Object.assign(postData, { "areAbove50PercentH1BL1ALABStatus": 'No' })

          }
          if (this.updateCompanyData.finalDeterminationFromDOL) {
            postData = Object.assign(postData, { "finalDeterminationFromDOL": 'Yes' })
          } else {
            postData = Object.assign(postData, { "finalDeterminationFromDOL": 'No' })
          }
         
         
          this.formSubmited = true;
          this.$store.dispatch("commonAction", { "data": postData, "path": "/company/update" })
            .then(response => {

              localStorage.setItem('petProfilecompleted', 'true');
              this.showToster({ message: response.message, isError: false });
              if ([50].indexOf(this.getUserRoleId) > -1) {
                this.completeTenantprofile = false;
                this.getCompanyDetails(true);

                this.getPetitionerProfileCompaltion;
                this.formSubmited = false;
                // this.$router.push('/dashboard')
              } else {
                this.$router.push('/petitioners')
              }



              //  if(!this.profileCompleted){


              //}

            })
            .catch(error => {
              this.formSubmited = false;
              this.showToster({ message: error, isError: true });
            })
        } else {
          this.scrollWIndow();
        }
      });


    },

    removeText() {
      this.$store.dispatch("removeText");

    },
    getTenantDetails() {
      let postData = {
        tenantId: this.getUserData['tenantDetails']['_id']
      }
      this.$store.dispatch("get_tenant_details", postData)
        .then(response => {
          this.tenantDetails = response;
          this.initTenantProfileData();
          this.isTenantProfileCompleted;


        })
        .catch(error => {
          this.showToster({ message: error, isError: true });
        })

    },
    updatePhone(item) {


      if (item.isValid) {

        this.updateTenantData.phoneCountryCode = { countryCode: item.countryCode, countryCallingCode: item.countryCallingCode };
        this.updateTenantData.phone = item.nationalNumber;

      }
    },
    initTenantProfileData() {
      if (this.getUserRoleId == 3 && this.tenantDetails) {
        let tempupdateTenantData = this.updateTenantData;
        let tenantDetails = this.tenantDetails

        this.tenantDetails = Object.assign(this.tenantDetails, { "address": { countryId: 231 } })

        this.updateCompanyData.address.selectedCountry = { "_id": "61408c9ed01ea1248cdcf6b7", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" };

        let address = { line1: "", line2: "", countryId: '', selectedCountry: null, stateId: '', selectedState: null, locationId: '', selectedCity: null, zipcode: '' };

        //	"name": "",
        // "adminEmail":'',

        if ((_.has(this.tenantDetails, 'name')) && tenantDetails.name.trim()) {
          tempupdateTenantData['name'] = this.tenantDetails.name.trim()

        }
        if ((_.has(this.tenantDetails, 'adminEmail')) && tenantDetails.adminEmail.trim()) {
          tempupdateTenantData['adminEmail'] = this.tenantDetails.adminEmail.trim()

        }
        if ((_.has(this.tenantDetails, 'adminFirstName')) && tenantDetails.adminFirstName.trim()) {
          tempupdateTenantData['adminFirstName'] = this.tenantDetails.adminFirstName.trim()

        }
        if ((_.has(this.tenantDetails, 'adminLastName')) && tenantDetails.adminLastName.trim()) {
          tempupdateTenantData['adminLastName'] = this.tenantDetails.adminLastName.trim()

        }
        if ((_.has(this.tenantDetails, 'phone')) && tenantDetails.phone) {
          tempupdateTenantData['phone'] = this.tenantDetails.phone;

        }
        if ((_.has(this.tenantDetails, 'phoneCountryCode')) && tenantDetails.phoneCountryCode) {
          tempupdateTenantData['phoneCountryCode'] = this.tenantDetails.phoneCountryCode;

        }

        if ((_.has(this.tenantDetails, 'logo')) && tenantDetails.phone) {
          tempupdateTenantData['logo'] = this.tenantDetails.logo;

        }
        if ((_.has(this.tenantDetails, 'favicon')) && tenantDetails.favicon) {
          tempupdateTenantData['favicon'] = this.tenantDetails.favicon;

        }
        if ((_.has(this.tenantDetails, 'fromEmail')) && tenantDetails.fromEmail) {
          tempupdateTenantData['fromEmail'] = this.tenantDetails.fromEmail;

        }
        if ((_.has(this.tenantDetails, 'contactEmail')) && tenantDetails.contactEmail) {
          tempupdateTenantData['contactEmail'] = this.tenantDetails.contactEmail;

        }
        if ((_.has(this.tenantDetails, 'contactEmail')) && tenantDetails.contactEmail) {
          tempupdateTenantData['contactEmail'] = this.tenantDetails.contactEmail;

        }
        if ((_.has(this.tenantDetails, 'slug')) && tenantDetails.slug) {
          tempupdateTenantData['slug'] = this.tenantDetails.slug;

        }
        if ((_.has(this.tenantDetails, 'idPrefix')) && tenantDetails.idPrefix) {
          tempupdateTenantData['idPrefix'] = this.tenantDetails.idPrefix;

        }
        if ((_.has(this.tenantDetails, 'idPrefix')) && tenantDetails.idPrefix) {
          tempupdateTenantData['idPrefix'] = this.tenantDetails.idPrefix;

        }


        if (_.has(this.tenantDetails, 'address')) {


          tempupdateTenantData['address'] = address;
          if (_.has(this.tenantDetails['address'], "line1")) {
            tempupdateTenantData['address']["line1"] = tenantDetails['address']['line1'];
          }
          if (_.has(this.tenantDetails['address'], "line2")) {
            tempupdateTenantData['address']["line2"] = tenantDetails['address']['line2'];
          }


          this.tenantDetails["address"]['countryId'] = 231;
          this.updateCompanyData.address.selectedCountry = { "_id": "61408c9ed01ea1248cdcf6b7", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" };
          tempupdateTenantData["address"]["countryId"] = 231; //tenantDetails["address"]["countryId"];
          if (this.countries.length >= 0) {
            tempupdateTenantData["address"]["selectedCountry"] = _.find(
              this.countries,
              { id: tempupdateTenantData["address"]["countryId"] }
            );

          }
          this.changedCountry(this.updateCompanyData.address.selectedCountry);

          if (_.has(this.tenantDetails['address'], "stateId")) {
            tempupdateTenantData['address']["stateId"] = tenantDetails['address']['stateId'];
          }
          if (_.has(this.tenantDetails['address'], "locationId")) {
            tempupdateTenantData['address']["locationId"] = tenantDetails['address']['locationId'];
          }
          if (_.has(this.tenantDetails['address'], "zipcode")) {
            tempupdateTenantData['address']["zipcode"] = tenantDetails['address']['zipcode'];
          }

        } else {
          tempupdateTenantData['address'] = address;
        }


        if ((_.has(this.tenantDetails, '_id')) && tenantDetails._id) {
          tempupdateTenantData['tenantId'] = this.tenantDetails._id;

        }

        tempupdateTenantData = Object.assign(tempupdateTenantData, { 'profComplted': 'no' })
        if (_.has(this.tenantDetails, 'profComplted')) {
          tempupdateTenantData['profComplted'] = tenantDetails['profComplted'];

        }

        this.updateTenantData = tempupdateTenantData;



        if (

          /*
           ( !(_.has(this.updateTenantData ,'adminFirstName')) || !this.updateTenantData.adminFirstName.trim())
           || ( !(_.has(this.updateTenantData ,'adminLastName')) || !this.updateTenantData.adminLastName.trim())
           ||  ( !(_.has(this.updateTenantData ,'phone')) || !this.updateTenantData.phone)
           ||  ( !(_.has(this.updateTenantData ,'logo')) || !this.updateTenantData.logo.trim())
           ||  ( !(_.has(this.updateTenantData ,'favicon')) || !this.updateTenantData.favicon.trim())
           ||  ( !(_.has(this.updateTenantData ,'fromEmail')) || !this.updateTenantData.fromEmail.trim())
           ||  ( !(_.has(this.updateTenantData ,'contactEmail')) || !this.updateTenantData.contactEmail.trim())
           ||
           */
          (!(_.has(this.tenantDetails, 'profComplted')) || !tenantDetails.profComplted.trim() || tenantDetails.profComplted.toLowerCase() != "yes")
          //||  ( !(_.has(this.updateTenantData ,'slug')) || !this.updateTenantData.slug.trim())
          //||  ( !(_.has(this.updateTenantData ,'idPrefix')) || !this.updateTenantData.idPrefix.trim())
          /*
          ||  ( !(_.has(this.updateTenantData ,'address')) || !this.updateTenantData.address)
          ||  ( !(_.has(this.updateTenantData['address'] ,'line1')) || !this.updateTenantData['address'].line1)
          ||  ( !(_.has(this.updateTenantData['address'] ,'line2')) || !this.updateTenantData['address'].line2)
          ||  ( !(_.has(this.updateTenantData['address'] ,'countryId')) || !this.updateTenantData['address'].countryId)
          ||  ( !(_.has(this.updateTenantData['address'] ,'stateId')) || !this.updateTenantData['address'].stateId)
          ||  ( !(_.has(this.updateTenantData['address'] ,'locationId')) || !this.updateTenantData['address'].locationId)
          ||  ( !(_.has(this.updateTenantData['address'] ,'zipcode')) || !this.updateTenantData['address'].zipcode)
          */

        ) {
          this.completeTenantprofile = true;
        }



      }
      this.$validator.reset();
    },
    updateTenantProfile() {
      //alert(JSON.stringify(this.updateTenantData))
      this.$validator.validateAll().then(result => {
        if (result) {
          let postData = _.cloneDeep(this.updateTenantData);

          if (this.updateTenantData.profComplted != 'Yes') {
            // this.updateTenantData.profComplted ="Yes";
            postData = Object.assign(postData, { "assetPath": postData['slug'].trim(), "profComplted": 'Yes', "profCompleted": "Yes" })

          }
          this.formSubmited = true;
          //alert();
          //return false;
          this.$store.dispatch("updateTenantProfile", postData)
            .then(response => {
              this.showToster({ message: response.message, isError: false });
              this.completeTenantprofile = false;
              this.getTenantDetails();
              this.isTenantProfileCompleted;
              this.formSubmited = false;
            })
            .catch(error => {
              this.formSubmited = false;
              this.showToster({ message: error, isError: true });
            })
        }
      });
    },
    uploaddoc(docs,category='') {
      let value = _.cloneDeep(docs);
      this.value = [];
      value = docs.map(item => item = {
        name: item.name,
        file: item.file,
        url: "",
        mimetype: item.type,
        status: item.status === null || item.status === undefined ? true : item.status
      })
      let tempFiles = [];
      
      if (value.length > 0) {
        let count = 0
        if(category == 'feinDocument'){
          this.uploading = true;
        }
        if(category == 'fein'){
          this.feinuploading = true;
        }
        // if(category == 'signDocument'){
        //   this.loading = true;
        // }
        
        value.forEach(doc => {
          let formData = new FormData();
          formData.append('files', doc.file);
          formData.append('secureType', 'private');
          formData.append("getDetails", true);
          this.$store.dispatch('uploadS3File', formData).then(response => {
            count = count + 1;
            response.data.result.forEach(urlGenerated => {

              // doc.url = urlGenerated;
              if(category == 'feinDocument'){
              if (!_.has(this.updateCompanyData, 'feinDocs')) {
                this.updateCompanyData = Object.assign(this.updateCompanyData, { "feinDocs": [] })
              }
              this.updateCompanyData['feinDocs'].push(urlGenerated)
              if(_.has(this.configurationDetails,'acceptCompayDocsForPtnr') && this.checkProperty(this.configurationDetails,'acceptCompayDocsForPtnr')){
                this.updateCompanyData['documents']['fein'].push(urlGenerated) 
              }
              //this.updateCompanyData['documents']['fein'].push(urlGenerated) 

            }
            if(category == 'fein'){
              this.updateCompanyData['documents']['fein'].push(urlGenerated) 
              this.updateCompanyData['feinDocs'].push(urlGenerated)
            }
            if(category == 'signDocument'){

              this.updateCompanyData['signDocs'].push(urlGenerated) 
            }
            })
            delete doc.file;
            
            //updateCompanyData.feinDocs

            //close filesUploading 
            if (count >= value.length) {
              
            if(category == 'feinDocument'){
              this.uploading = false;
            }
            this.feinuploading = false;
            // if(category == 'signDocument'){
            //   this.loading = false;
            // }

            }

          });
        })
      }
    },
    removedocs(filindex,category='') {
      if(category == 'feinDocument'){
        this.updateCompanyData.feinDocs.splice(filindex, 1);
      }
      // if(category == 'signDocument'){
      //   this.updateCompanyData.signDocs.splice(filindex, 1);
      // }

      if(category == 'fein'){
        this.updateCompanyData['documents'].fein.splice(filindex, 1);
      }
      
      
    },
    upload(files, type = "favicon") {
      let self = this;
      let model = _.cloneDeep(files);
      
      this.documents = [];
      this.loading = true;
      let formData = new FormData();
      let temp_count = 0;
      let mapper = model.map(
        item =>
        (item = {
          name: item.name,
          file: item.file ? item.file : null,
          path: item.url ? item.url : "",
          url: item.url ? item.url : "",
          extn: item.name.split('.').pop(),
          mimetype: item.type ? item.type : item.mimetype,
          uploadedBy:this.checkProperty(this.getUserData,'userId'),
          uploadedByName:this.checkProperty(this.getUserData,'name'),
          uploadedByRoleId:this.getUserRoleId,
          uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
        })
      );
      let allFiles = [];
      if(type=='signDocument'){
        let imageMymTypes =['image/bmp','image/jpeg','image/x-png','image/png'];
        mapper.forEach((doc, index) => {
          if(imageMymTypes.indexOf(doc.mimetype) >-1){
            allFiles.push(doc);
          }
        })
        mapper = _.cloneDeep(allFiles);

        
      }
      if (mapper.length > 0) {
        if(type=='signDocument'){
            this.elsUploading = true;
        }
        this.isloading = true;
        this.logoUploading = true;
        
        mapper.forEach((doc, index) => {
          formData.append('files', doc.file);
          formData.append('secureType', 'public');
          this.$store.dispatch("uploadS3File", formData).then(response => {
            temp_count++;
            // alert(type) updateCompanyData
            response.data.result.forEach(urlGenerated => {
              doc.path = urlGenerated.path;
              if(self.checkProperty( urlGenerated,'extn')){
                  doc.extn = urlGenerated['extn']
              }
              delete doc.file;
              delete doc.document;
              if(type=='signDocument'){
                self.updateCompanyData['signDocs']=[];
                doc.path =urlGenerated;
                delete doc.file;
                
              }
              this.updateCompanyData['signDocs'].push(doc) 
                self.elsUploading = false;
              if (this.getUserRoleId == 50) {
                if (type == "logo") {
                  this.updateCompanyData = Object.assign(this.updateCompanyData, { "logo": urlGenerated })
                } else {
                  // alert(type+" ----- ")
                  this.updateCompanyData = Object.assign(this.updateCompanyData, { "favicon": urlGenerated })
                }

              } else {

                if (type == "logo") {
                  this.updateTenantData = Object.assign(this.updateTenantData, { "logo": urlGenerated })
                } else {
                  // alert(type+" ----- ")
                  this.updateTenantData = Object.assign(this.updateTenantData, { "favicon": urlGenerated })
                }

              }
              if (temp_count >= mapper.length) {
                this.documents = [];

              }
              doc.url = urlGenerated;
              delete doc.file;
              mapper[index] = doc;

            });
            this.logoUploading = false;
          });
        });
        model.splice(0, mapper.length, ...mapper);
      }
      else{
        if(type=='signDocument'){
            this.showToster({  message: "Upload only image files",  isError: true,  });
        }
      }
    },
    remove(item,type='') {
      if(type == 'signDocument'){
        this.updateCompanyData.signDocs.splice(item, 1);
      }
      if (this.getUserRoleId == 50) {

        this.updateCompanyData[item] = ''
      } else {
        this.updateTenantData[item] = '';
      }

    },
    changedCountry() {
      this.states = [];
      this.locations = [];
      let dataKey = "updateCompanyData";
      if (this.getUserRoleId == 50) {
        dataKey = "updateCompanyData";
      }
      if (_.has(this[dataKey].address.selectedCountry, "id")) {
        this[dataKey].address.countryId = this[dataKey].address.selectedCountry['id'];

        this.masterData('states');
      }

    },
    changedState() {
      let dataKey = "updateCompanyData";
      if (this.getUserRoleId == 50) {
        dataKey = "updateCompanyData";
      }

      this.locations = [];
      if (_.has(this[dataKey].address.selectedState, "id")) {
        this[dataKey].address.stateId = this[dataKey].address.selectedState['id'];
        this.masterData('locations');
      }
    },
    //locationId
    changedCity() {
      let dataKey = "updateCompanyData";
      if (this.getUserRoleId == 50) {
        dataKey = "updateCompanyData";
      }

      if (_.has(this[dataKey].address.selectedCity, "id")) {
        this[dataKey].address.locationId = this[dataKey].address.selectedCity['id'];
        //  this.masterData('locations');
      }

    },
    masterData(category = "countries") {

      /*
     countries:[]
     states:[],
     locations:[],
      */
      let matcher = {};
      let postData = {
        matcher: matcher,
        page: 1,
        perpage: 1000,
        category: category,

      };


      let dataKey = "updateCompanyData";
      let detailsDataKey = "tenantDetails";

      if (this.getUserRoleId == 50) {
        dataKey = "updateCompanyData";
        detailsDataKey = "companyDetails";
      }

      if (category == "states") {

        matcher = { "countryId": this[dataKey].address.selectedCountry['id'] }
      }
      if (category == "locations") {

        matcher = { "stateId": this[dataKey].address.selectedState['id'] }

      }
      postData['matcher'] = matcher;

      this.$store.dispatch("getMasterData", postData)
        .then((res) => {
          //countries


          if (category == "countries") {

            this.countries = res['list'];
            this.updateCompanyData.address.selectedCountry = { "_id": "61408c9ed01ea1248cdcf6b7", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" };
            this.changedCountry();
            //alert(JSON.stringify(this.countries))
          }
          if (category == "states") {


            this.states = res['list'];

            if (this.checkProperty(this[detailsDataKey], 'address', 'stateId') && _.has(this[detailsDataKey]['address'], "stateId")) {
              this[dataKey]['address'].selectedState = _.find(this.states, { "id": this[detailsDataKey]['address']['stateId'] });
              this.changedState();
            }


          }
          if (category == "locations") {

            this.locations = res['list'];
            if (this.checkProperty(this[detailsDataKey], 'address', 'locationId') && _.has(this[detailsDataKey]['address'], "locationId")) {
              this[dataKey]['address'].selectedCity = _.find(this.locations, { "id": this[detailsDataKey]['address']['locationId'] });
            }

          }
        })
        .catch((err) => {
          
          this[category] = [];

        })

    },
    getDetailsFromOtherTenant() {
      let _self = this
      this.$store.dispatch("commonAction", { "data": {}, "path": "/company/details-from-other-tenant" })
        .then(response => {
          if (response) {

            let companyData = response;
            _.forEach(companyData, (value, key) => {
              // alert("key=="+key +"   VALUE=="+value);
              if (key == 'address') {
                let address = { line1: "", line2: "", countryId: '', selectedCountry: null, stateId: '', selectedState: null, locationId: '', selectedCity: null, zipcode: '' };

                _.forEach(companyData['address'], (adval, adkey) => {
                  if (_.has(address, adkey)) {
                    address[adkey] = adval;
                  }

                })

                this.companyDetails = Object.assign(this.companyDetails, { "address": address })
                this.updateCompanyData['address'] = address;
                this.updateCompanyData = _.cloneDeep(this.updateCompanyData);

                if (this.countries.length >= 0) {
                  this.updateCompanyData['address']['selectedCountry'] = _.find(this.countries, { "id": 231 })
                  this.updateCompanyData = _.cloneDeep(this.updateCompanyData);
                  this.changedCountry();
                }



              } else if (key == 'authorizedSignatory') {



                _.forEach(companyData['authorizedSignatory'], (authval, authkey) => {

                  if (_.has(this.updateCompanyData['authorizedSignatory'], authkey)) {
                    this.updateCompanyData.authorizedSignatory[authkey] = authval;
                    //alert(this.updateCompanyData['authorizedSignatory'][authkey]);
                  }

                })


              } else if (_.has(this.updateCompanyData, key)) {
                this.updateCompanyData[key] = value;
                if (key == "are50orMoreEmployeesInUS") {
                  if (value.toLowerCase() == "yes") {
                    this.updateCompanyData['are50orMoreEmployeesInUS'] = true;
                  } else {
                    this.updateCompanyData['are50orMoreEmployeesInUS'] = false;
                  }

                }
                if (key == "finalDeterminationFromDOL") {
                  if (value.toLowerCase() == "yes") {
                    this.updateCompanyData['finalDeterminationFromDOL'] = true;
                  } else {
                    this.updateCompanyData['finalDeterminationFromDOL'] = false;
                  }

                }
                if (key == "areAbove50PercentH1BL1ALABStatus") {
                  if (value.toLowerCase() == "yes") {
                    this.updateCompanyData['areAbove50PercentH1BL1ALABStatus'] = true;
                  } else {
                    this.updateCompanyData['areAbove50PercentH1BL1ALABStatus'] = false;
                  }

                }

              }

            })
          }
          this.$validator.reset();

        })
    },
    getGlobalConfigDetails(){
      let postData ={}
      this.configurationDetails =null
      this.$store.dispatch("commonAction", {data:postData,path:'global-config/details'})
      .then((response) =>{ 
        if(this.checkProperty(response ,"config"  )){
          this.configurationDetails = response['config'];
        }
      })
    },
  },
  directives: {
  },
  components: {
    quillTextEditor,
    customCropImage,
    immiPhone,
    casedocumentslist,
    datepickerField,
    addressFields,
    VuePhoneNumberInput,
    FileUpload,
    VxAutoSuggest,
    VuePerfectScrollbar,
    draggable,
    DateRangePicker,
    moment,
    Datepicker,
    InfoIcon,
    CheckIcon,
    TheMask
  },
};
</script>