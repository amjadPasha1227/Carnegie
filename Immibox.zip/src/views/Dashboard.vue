<template>
<div>
    <div class="dashboard-wrapper">
        <div class="dashboard-content">
            <h1>Dashboard </h1>
            <p class="login-name">Welcome {{username}}, your tasks in a brief!</p>

            <div class="dashboard-cards"> 

                <div v-if="( roleId !=7  && roleId != 11 )  " class="vx-row">

                    <div class="vx-col w-full lg:w-1/2">
                        <vx-card class="normal-card petitions-cards">
                            <div class="petitions-cards-header">
                                <vs-list>
                                    <vs-list-item title="Total Cases">
                                        <template slot="avatar">
                                            <img src="@/assets/images/main/total-petitions.svg">
                                        </template>
                                        <h3>{{petitionsCount.totalCount}}</h3>
                                    </vs-list-item>
                                </vs-list>
                            </div>
                            <div class="petitions-cards-footer">
                                <ul>
                                    <li>
                                        <router-link :to="{ name: 'petitions'}">
                                            <p>Petitions<span>{{petitionsCount.petitionCount}}</span></p>
                                        </router-link>
                                    </li>
                                    <li v-if="petitionsCount.rfeCount > 0">
                                        <router-link :to="{ name: 'rfe'}">
                                            <p>RFE<span>{{petitionsCount.rfeCount}}</span></p>
                                        </router-link>
                                    </li>
                                    <li v-if="petitionsCount.rfeCount == 0">
                                        <p>RFE<span>{{petitionsCount.rfeCount}}</span></p>
                                    </li>
                                </ul>
                            </div>
                        </vx-card>
                    </div>

                    <div class="vx-col w-full lg:w-1/2" v-if="( roleId !=6)">
                        <vx-card class="normal-card petitions-cards petitioners-card">
                            <router-link :to="{ name: 'petitioners'}">

                                <div class="petitions-cards-header">
                                    <vs-list>
                                        <vs-list-item title="Petitioners">
                                            <template slot="avatar">
                                                <img src="@/assets/images/main/petitioners.svg">
                                            </template>
                                            <h3>{{petitionersCount.totalCount}}</h3>
                                        </vs-list-item>
                                    </vs-list>
                                </div>
                                <div class="petitions-cards-footer">
                                    <ul>
                                        <li>
                                            <p>Approve<span>{{petitionersCount.approvedCount}}</span></p>
                                        </li>
                                        <li>
                                            <p>Pending<span>{{petitionersCount.pendingCount}}</span></p>
                                        </li>
                                    </ul>
                                </div>
                            </router-link>
                        </vx-card>
                    </div>

                    <div class="vx-col w-full lg:w-1/2" v-if="( roleId ==6)">
                        <vx-card class="normal-card petitions-cards petitioners-card">
                            <router-link :to="{ name: 'beneficiaries'}">
                                <div class="petitions-cards-header">
                                
                                    <vs-list>
                                        <vs-list-item title="Beneficiary ">
                                            <template slot="avatar">
                                                <img src="@/assets/images/main/petitioners.svg">
                                            </template>
                                            <h3>{{beneficiaryStats.total}}</h3>
                                        </vs-list-item>
                                    </vs-list>
                            
                                </div>
                                <div class="petitions-cards-footer">
                                    <ul>
                                        <li>
                                            <p>Active<span>{{beneficiaryStats.active}}</span></p>
                                        </li>
                                        <li>
                                            <p>Inactive<span>{{beneficiaryStats.inactive}}</span></p>
                                        </li>
                                    </ul>
                                </div>
                            </router-link>
                        </vx-card>
                    </div>
                </div>
                <div class="vx-row">

                    <div class="vx-col w-full" v-if="my_tasks.length>0">
                        <vx-card class="normal-card my-task-card">
                            <div class="mytask-listheader">
                                <h2>My Tasks</h2>
                                <router-link :to="{ name: 'mytasks'}">

                                    <a class="viewall">View All <i class="material-icons">
                                            arrow_forward
                                        </i></a>
                                </router-link>
                            </div>

                            <ul v-if="my_tasks.length>0">
                                <li v-bind:key="my_task" v-for="my_task in my_tasks.slice(0,3)">
                                    <div class="my-task-card-content">

                                        <div class="my-task-card-content-right">
                                            <div class="my-task-id">{{my_task.data.description}}
                                                <span>
                                                    <div class="date">{{my_task.createdOn | formatDateTime}}</div>
                                                </span>
                                               
                                            </div>

                                            <template v-if="my_task.data.category =='APPROVE_TENANT_ADMIN'">
                                                <router-link v-bind:to="'/customer-details/'+my_task.data.tenantId">
                                                    <button class="btn go-btn">Go</button>
                                                </router-link>
                                            </template>
                                            <template v-if="my_task.data.category =='APPROVE_PETITIONER'">
                                                <router-link v-bind:to="'/petitioner-details/'+my_task.data.companyId">
                                                    <button class="btn go-btn">Go</button>
                                                </router-link>
                                            </template>

                                            <template v-if="my_task.data.category=='GC_BENEFICIARY_FILL_QUESTIONNAIRE'">
                                                <router-link v-bind:to="'/gcquestionnaire/'+my_task.data.petitionId">
                                                    <button class="btn go-btn">Go</button>
                                                </router-link>
                                            </template>
                                            <template v-if="my_task.data.category!='GC_BENEFICIARY_FILL_QUESTIONNAIRE' && my_task.data.category!='APPROVE_TENANT_ADMIN' && my_task.data.category!='APPROVE_PETITIONER'">
                                                       <template v-if="my_task.data.navigationKey=='QUESTIONNAIRE_FORM'">
                                                    <router-link v-bind:to="((my_task.data.navigationKey=='COMPANY_DETAILS' || my_task.data.navigationKey=='USER_DETAILS')?'/petitioner-details/'+my_task.data.companyId:'/questionnaire/'+my_task.data.petitionId)">
                                                        <button class="btn go-btn">Go</button>
                                                    </router-link>
                                                </template>
                                                <template v-if="my_task.data.navigationKey!='LCA_DETAILS' && my_task.data.navigationKey!='QUESTIONNAIRE_FORM'">
                                                    <router-link v-bind:to="((my_task.data.navigationKey=='COMPANY_DETAILS' || my_task.data.navigationKey=='USER_DETAILS')?'/petitioner-details/'+my_task.data.companyId:'/petition-details/'+my_task.data.petitionId)">
                                                        <button class="btn go-btn">Go</button>
                                                    </router-link>
                                                </template>
                                                <template v-if="my_task.data.navigationKey=='LCA_DETAILS'">

                                                    <router-link v-bind:to="((my_task.data.navigationKey=='COMPANY_DETAILS' || my_task.data.navigationKey=='USER_DETAILS')?'/petitioner-details/'+my_task.data.companyId:'/lca-details/'+my_task.data.lcaId)">
                                                        <button class="btn go-btn">Go</button>
                                                    </router-link>
                                                </template>

                                            </template>

                                        </div>
                                    </div>
                                </li>

                            </ul>
                        </vx-card>
                    </div>
                </div>

                <div v-if="( roleId != 10 && roleId != 11  && new_petitions.length)" class="vx-row">

                    <div class="vx-col w-full" v-bind:class="{ 'l': roleId==7,'lg:w-1/2': roleId!=7}" v-if="new_petitions.length >0">

                        <vx-card class="normal-card petition-list-cards">
                            <div class="petitions-cards-list">
                                <div class="petitions-cards-listleft w-full border-none">
                                    <div class="petitions-cards-listheader">
                                        <h2 v-if="roleId == 7">My Cases</h2>
                                        <h2 v-else>New Cases</h2>

                                        <router-link to="/cases" class="viewall">View All <i class="material-icons">
                                                arrow_forward
                                            </i></router-link>
                                    </div>
                                    <div class="petitions-cards-list">

                                        <vs-list class="reverse-list">

                                            <template v-for="(petition,index) in new_petitions">
                                                <router-link :key="index" v-bind:to="{ name: 'petition-details', params: { itemId: petition._id } }">
                                                    <vs-list-item :key="petition" v-bind:title="roleId == 7?'Petitioner: '+petition['petitionerDetails'].name:petition.userDetails.name" v-bind:subtitle="petition.caseNo">

                                                        <template slot="avatar">
                                                            <vs-avatar />
                                                        </template>

                                                        <span class="status_active">{{petition.statusDetails.name}}</span>
                                                          
                                                    </vs-list-item>

                                                </router-link>

                                            </template>
                                        </vs-list>

                                    </div>
                                </div>
                            </div>
                        </vx-card>

                    </div>

                    <div class="vx-col w-full  lg:w-1/2" v-if="(  roleId !=7 && rfe_petitions && rfe_petitions.length > 0 )">

                        <vx-card class="normal-card petition-list-cards">
                            <div class="petitions-cards-list">
                                <div class="petitions-cards-listleft w-full border-none">
                                    <div class="petitions-cards-listheader">
                                        <h2>RFE Cases</h2>
                                        <router-link to="/rfe" class="viewall">View All <i class="material-icons">
                                                arrow_forward
                                            </i></router-link>
                                    </div>
                                    <div class="petitions-cards-list">
                                        <vs-list class="reverse-list">
                                        <template  v-for="(rfe_petition ,inx ) in  rfe_petitions.slice(0, 5)" >
                                            <router-link :key="inx+1000000" v-bind:to="{ name: 'rfepetition-details', params: { itemId: rfe_petition._id } }">

                                                <vs-list-item v-bind:title="rfe_petition.userDetails.name" v-bind:subtitle="rfe_petition.caseNo"
                                            
                                                >
                                                
                                                <div  >
                                                    <template slot="avatar">
                                                        <vs-avatar />
                                                    </template>
                                                    <button class="btn day-left" v-if="rfe_petition.pendingDays >0">{{rfe_petition.pendingDays}} days left</button>
                                                </div>
                                                </vs-list-item>
                                            </router-link>
                                        </template>

                                        </vs-list>

                                    </div>
                                </div>
                            </div>
                        </vx-card>

                    </div>

                    <div class="vx-col w-full lg:w-1/2" v-if="new_petitioners.length>0 && ( roleId !=7 && roleId !=10  )">
                        <vx-card class="normal-card petition-list-cards">
                            <div class="petitions-cards-list">
                                <div class="petitions-cards-listleft w-full border-none">
                                    <div class="petitions-cards-listheader">
                                        <h2>New Petitioners</h2>
                                        <router-link to="/petitioners" class="viewall">View All <i class="material-icons">
                                                arrow_forward
                                            </i></router-link>
                                    </div>
                                    <div class="petitions-cards-list">
                                        <vs-list class="reverse-list">
                                            <router-link :key="new_petitioner" v-for="new_petitioner in  new_petitioners.slice(0, 5)" v-bind:to="{ name: 'petitionerdetails', params: { itemId: new_petitioner._id } }">
                                                <vs-list-item  v-bind:title="new_petitioner.createdOn | formatDateTime" v-bind:subtitle="new_petitioner.name">
                                                    <template slot="avatar">
                                                        <vs-avatar />
                                                    </template>
                                                    <span v-bind:class="[(new_petitioner.statusDetails.id == 1) ? 'status_created':'',(new_petitioner.statusDetails.id == 2) ? 'status_approved':'', (new_petitioner.statusDetails.id == 3) ? 'status_pending':'',(new_petitioner.statusDetails.id == 4) ? 'status_rejected':'' ,(new_petitioner.statusDetails.id == 5) ? 'status_closed':'']">{{new_petitioner.statusDetails.name}}</span>
                                                </vs-list-item>
                                            </router-link>

                                        </vs-list>

                                    </div>
                                </div>
                            </div>
                        </vx-card>
                    </div>
                    <div class="vx-col w-full lg:w-1/2" v-if="lca_requests.length>0 && [11].indexOf(getUserRoleId)>-1">
                        <vx-card class="normal-card petition-list-cards">
                            <div class="petitions-cards-list"> 
                                <div class="petitions-cards-listleft w-full border-none">
                                    <div class="petitions-cards-listheader">
                                        <h2>LCA Requests</h2>
                                        <router-link to="/lcalist" class="viewall">View All <i class="material-icons">
                                                arrow_forward
                                            </i></router-link>
                                    </div>
                                    <div class="petitions-cards-list">
                                        <vs-list>
                                            <router-link :key="ind+10000" v-for="(lca_request ,ind) in  lca_requests.slice(0, 5)" v-bind:to="{ name: 'lca-details', params: { itemId: lca_request._id } }">
                                         
                                            <vs-list-item  v-bind:title="lca_request.companyDetails?lca_request.companyDetails.name:''" v-bind:subtitle="lca_request.caseNo">
                                                <template slot="avatar">
                                                    <vs-avatar />
                                                </template>
                                                <span v-if="lca_request.statusDetails" v-bind:class="[(lca_request.statusDetails.id == 1) ? 'status_created':'',(lca_request.statusDetails.id == 2) ? 'status_inProcess':'', (lca_request.statusDetails.id == 3) ? 'status_certified':'',(lca_request.statusDetails.id == 4) ? 'status_deniel':'' ,(lca_request.statusDetails.id == 4) ? 'status_submited':'']">{{lca_request.statusDetails.name}} </span>
                                            </vs-list-item>
                                            </router-link>

                                        </vs-list>

                                    </div>
                                </div>
                            </div>
                        </vx-card>
                    </div>

                </div>

            </div>
        </div>
        <div class="recent-activities">
            <div class="recent-activities-header">
                <h2>Recent Activities</h2>
                <vs-button v-on:click="refresh" radius color="success" icon-pack="feather" icon="icon-rotate-cw"></vs-button>
            </div>

            <VuePerfectScrollbar class="scroll-area">
                <div class="recent-activities-content">
                    <ul v-if="recent_activitys.length > 0">
                        <template v-for="recent_activity in recent_activitys">
                            <li :key="recent_activity._id">
                                <h4>{{recent_activity.title}}</h4>
                                <p>{{recent_activity.description}}</p>
                                <span>{{recent_activity.createdOn | timeago }} </span>
                            </li>
                        </template>

                    </ul>
                </div>

            </VuePerfectScrollbar>

        </div>
    </div>
</div>
</template>

<script>
import VueApexCharts from 'vue-apexcharts'
import Vue from 'vue'
import VuePerfectScrollbar from "vue-perfect-scrollbar";

Vue.use(VueApexCharts)

Vue.component('apexchart', VueApexCharts)

export default {
    components: {
        VuePerfectScrollbar
    },
    data: function () {
        return {
            username: '',
            activities: [],
            options: {},
            series: [50, 102, 155, 141, 117],
            dashboard_data: {},
            lca_requests: [],
            new_petitioners: [],
            new_petitions: [],
            petitionersCount: {},
            beneficiaryStats: {},

            petitionsCount: {},
            rfe_petitions: [],

            //recent activity data
            recent_activitys: [],
            my_tasks: [],
            roleId: 0,

        }
    },
    mounted() {
        this.username = this.$store.state.user.name;
        this.roleId = this.$store.state.user['roleId'][0];
       
        this.petitionsCount = {
            petitionCount: 0,
            rfeCount: 0,
            totalCount: 0
        };
        this.petitionersCount = {
            approvedCount: 0,
            pendingCount: 0,
            totalCount: 0
        };
        this.beneficiaryStats = {
            "total": 0,
            "active": 0,
            "inactive": 0
        };

        this.get_dashboardData();
        this.get_recentActivitys();
        this.get_mytasks();
        this.getactivities();

    },
    methods: {
        
        get_dashboardData: function () {
            this.$store.dispatch("get_dashboard_data", {}).then(response => {
                this.dashboard_data = response;
                this.lca_requests = this.dashboard_data['lca_requests'] ? this.dashboard_data['lca_requests'] : [];

                this.petitionsCount = this.dashboard_data['petitionsCount'] ? this.dashboard_data['petitionsCount'] : {
                    petitionCount: 0,
                    rfeCount: 0,
                    totalCount: 0
                };
                this.petitionersCount = this.dashboard_data['petitionersCount'] ? this.dashboard_data['petitionersCount'] : {
                    approvedCount: 0,
                    pendingCount: 0,
                    totalCount: 0
                };
                this.beneficiaryStats = this.dashboard_data['beneficiaryStats'] ? this.dashboard_data['beneficiaryStats'] : {
                    "total": 0,
                    "active": 0,
                    "inactive": 0
                };

                this.new_petitioners = this.dashboard_data['new_petitioners'] ? this.dashboard_data['new_petitioners'] : [];
                this.new_petitions = this.dashboard_data['new_petitions'] ? this.dashboard_data['new_petitions'] : [];
                this.rfe_petitions = this.dashboard_data['rfe_petitions'] ? this.dashboard_data['rfe_petitions'] : [];
            });
        },
        get_recentActivitys: function () {
            this.$store.dispatch("get_recent_activitys", {}).then(response => {
                this.recent_activitys = response.list;
                
            });
        },
        getactivities: function () {
            this.$store.dispatch("getactivities").then(response => {
                this.activities = response;
            });
        },
        get_mytasks: function () {
            this.$store.dispatch("get_my_tasks", {}).then(response => {

                this.my_tasks = response.list.map((element) => {
                    //"navigationKey":

                    element["data"]['navigation_link'] = "#";
                    if (element["data"]["navigationKey"] == "USER_DETAILS")
                        // element["data"]['navigation_link'] ="#/petitioner-details/"+element["data"]['companyId'];

                        if (element["data"]["navigationKey"] == "COMPANY_DETAILS")
                            element["data"]['navigation_link'] = "/petitioner-details/" + element["data"]['companyId'];

                    if (element["data"]["navigationKey"] == "PETITION_DETAILS")
                        element["data"]['navigation_link'] = "/petition-details/" + element["data"]['petitionId'];

                    if (element["data"]["navigationKey"] == "LCA_DETAILS")
                        element["data"]['navigation_link'] = "/lca-details/" + element["data"]['lcaId'];

                    if (element["data"]["description"].includes("questionnaire ")) element["data"]['navigation_link'] = "/questionnaire/" + element["data"]['petitionId'];

                    return element;

                });
                
                //this.my_tasks = a//response.list;

            });
        },
        refresh() {
           // alert("REFERESH");
            this.get_recentActivitys();
        },
    }
};
</script>
