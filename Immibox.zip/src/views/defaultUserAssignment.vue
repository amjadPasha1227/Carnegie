<template>
    <div class="settings_right userassignmentsec" >
        <div class="form_section pad20 pt-0">
            <div class="form-container">
                
                    <div class="card-panels pb-3">
                        <vs-card>
                            <div slot="header">
                                <div class="d-flex">
                                    <h3>Default User Assignment</h3>
                                </div>
                            </div>
                            <div class="select-branch documents__list" v-if="isCompany">
                                <div class="documents__title">
                                    <span>Select Branch</span>
                                </div>
                                <selectField :display="true" :wrapclass="'md:w-1/2'" :required="false" @input="updateBranch()"  cid="selectedBranch"   :optionslist="branchList" v-model="selectedBranch"  fieldName="selectedBranch" placeHolder="Select Branch"/>
                            </div>
                            <template v-for="(item, indexx ) in userRolelist ">
                                <div class="documents__list">
                                    <div class="documents__title">
                                        <span>{{item.name}}</span>
                                    </div>
                                    <div class="documents__actions">
                                        <selectField :display="true" :wrapclass="'md:w-1/1'" :required="false"  cid="selectedUser"   :optionslist="item.usersList" v-model="item.selectedUser"  fieldName="selectedUser" placeHolder="Select User"   /> 
                                    </div>
                                </div>
                            </template>
                        </vs-card>
                    </div>
            </div>
            <div class="form-footer relative">
                <figure  class="loader" v-if="formSaving"> <img src="@/assets/images/main/loader.gif" />  </figure>
                <button  v-if="(checkProperty(defaultUsersDetailsList,'_id'))" class="save" @click="updateForm()"><span>Update</span></button>
                <button v-else class="save" @click="saveForm()"><span >
                    
                    
                    Save
                </span></button>
               
                
            </div>
        </div>
        
    </div>
    </template>
    <script>
    import selectField from "@/views/forms/fields/simpleselect.vue";
    import Paginate from "vuejs-paginate";
    import _ from "lodash";
    export default {
        provide() {
          return {
              parentValidator: this.$validator,
          };
      },
        components:{
            Paginate,
            selectField
        },
        props:{
            branchId:'',
            isCompany:{
                type:Boolean,
                default:false
            },
            companyId:'',
            branchDetailss:'',
        },
        data: () => ({
            formSaving:false,
            defaultUsersDetailsList:null,
            branchList:[],
            branchDetails:null,
            final_selected_statusids:[],
            searchtxt:'',
            selected_createdDateRange: ["", ""],
            page: 1,
            perpage: 25,
            totalpages: 0,
            sortKeys: {},
            sortKey: {},
            userRolelist:[],
            final_selected_states: [],
            final_selected_locations:[],
            final_selected_locations:[],
            date_range: [],
            users:[],
            disableRoleId:[1,2,3],
            selectedBranch:null
           
        }),
        methods: {
            updateBranch(){
                this.getUserRoleList()
                this.getDefaultUserDetails()
            },
            getBranchList(){
                let postData ={
                    "filters":{"title":"","createdDateRange":[],"statusList":[],"activeList":[]},
                    "page":1,
                    "perpage":250000,
                    getMasterData:true,
                    "sorting":{"path":"createdOn","order":1}};
                    this.$store.dispatch("getList" ,{ "data":postData,"path":"/branch/list"})
                    .then((res)=>{
                        let list = res.list;
                        _.forEach(list,(item)=>{
                            item =Object.assign(item,{ 'id':item['_id']});
                        })
                        this.branchList =_.cloneDeep(list);
                        if(this.branchList){
                            this.selectedBranch = this.branchList[0]
                            this.updateBranch()
                            // alert(JSON.stringify(this.branchList[0]))
                        }
                        
                    })
                    .catch((err)=>{
                    this.branchList =[] ;
                    })
            },
            processData(){
                if(this.defaultUsersDetailsList && this.checkProperty(this.defaultUsersDetailsList,'defaultCaseUserConfig','length')>0){
                    let defaultUserAssignment = this.defaultUsersDetailsList['defaultCaseUserConfig']
                    this.userRolelist.map((item)=>{
                        let roleId =item['id'];
                        let dbUserData = _.find(defaultUserAssignment ,{"roleId":roleId} );
                        if(dbUserData && _.has(dbUserData ,'userId')){
                            let user = _.find(item['usersList'] , { "_id": dbUserData['userId'] });
                            if(user){
                                item['selectedUser'] =user;
                            }
                        }
                    })
                }   
            },
            getBranchDetails(){
                let payload ={
                    branchId:'',
                }
                payload['branchId'] = this.branchId
                this.$store.dispatch("commonAction",{data:payload ,path:'/branch/details'} ).then(response => {
                    
                    this.branchDetails = response;
                    this.processData();
                }).catch((err)=>{
                })
            },
            saveForm(){
                let payload={
                    "entityType": "branch",
                    branchId:this.branchId,
                    defaultCaseUserConfig:[]
                };
                if(this.isCompany){
                    payload['entityType'] = 'company';
                    payload['branchId'] = this.checkProperty( this.selectedBranch ,'_id' )
                    payload['companyId'] = this.companyId
                }
                //payload['branchId'] = this.branchId
                if(this.checkProperty(this.userRolelist, 'length')>0){    
                    _.forEach(this.userRolelist, (item)=>{
                        if(item['selectedUser'] && _.has(item['selectedUser'], '_id') &&  _.has(item['selectedUser'], 'roleId')){
                        let obj = {
                            userId: "",
                            roleId: null
                        }
                            obj['userId'] = item['selectedUser']['_id']
                            obj['roleId'] = item['selectedUser']['roleId']
                            payload['defaultCaseUserConfig'].push(obj)
                        }
                        
                    });
                }
                this.formSaving =true;
                this.$store.dispatch("commonAction",{data:payload ,path:'/case-default-users/create'} ).then(response => {
                    this.showToster({message:response.message,isError:false});
                    this.getDefaultUserDetails()
                    
                    this.formSaving =false;
                }).catch((err)=>{
                    this.showToster({message:err,isError:true});
                    
                    this.formSaving =false;
                })
    
        },
        getDefaultUserDetails(){
            this.defaultUsersDetailsList = []
            let payload={
                branchId:this.branchId,
            };
            if(this.isCompany){
                payload['branchId'] = this.checkProperty( this.selectedBranch ,'_id' )
                payload['companyId'] = this.companyId
            }
            // else{
            //     payload['branchId'] = this.branchId
            // }
            this.$store.dispatch("commonAction",{data:payload ,path:'/case-default-users/details'} ).then(response => {
            this.defaultUsersDetailsList = response
                
            }).catch((err)=>{
                
            })
            if(this.defaultUsersDetailsList){
                this.processData()
            }
        },
        updateForm(){
            let payload={
                    "entityType": "branch",
                    branchId:this.branchId,
                    defaultCaseUserConfig:[],
                    "configId": "",
                };
                if(this.checkProperty(this.defaultUsersDetailsList,'_id')){
                    payload['configId'] = this.checkProperty(this.defaultUsersDetailsList,'_id')
                }
                if(this.isCompany){
                    payload['entityType'] = 'company';
                    payload['branchId'] = this.checkProperty( this.selectedBranch ,'_id' )
                    payload['companyId'] = this.companyId
                }
                if(this.checkProperty(this.userRolelist, 'length')>0){    
                    _.forEach(this.userRolelist, (item)=>{
                        if(item['selectedUser'] && _.has(item['selectedUser'], '_id') &&  _.has(item['selectedUser'], 'roleId')){
                        let obj = {
                            userId: "",
                            roleId: null
                        }
                            obj['userId'] = item['selectedUser']['_id']
                            obj['roleId'] = item['selectedUser']['roleId']
                            payload['defaultCaseUserConfig'].push(obj)
                        }
                        
                    });
                }
                this.formSaving =true;
                this.$store.dispatch("commonAction",{data:payload ,path:'/case-default-users/update'} ).then(response => {
                    this.showToster({message:response.message,isError:false});
                    this.getDefaultUserDetails()
                    
                    this.formSaving =false;
                }).catch((err)=>{
                    this.showToster({message:err,isError:true});
                    
                    this.formSaving =false;
                })
        },
            getUsersList() {
                let userRoleId=  this.userRolelist.map((item)=>item.id);
                let matcher = {
                roleIds:userRoleId,
                title: this.searchtxt,
                searchString: this.searchtxt,
                statusIds: this.final_selected_statusids,
                stateIds: this.final_selected_states,
                locationIds: this.final_selected_locations,
                createdDateRange: this.date_range,
                page: this.page,
                perpage: 10000000,
                branchIds: [],
                };
                if (
                this.selected_createdDateRange["startDate"] &&
                this.selected_createdDateRange["startDate"] != "" &&
                this.selected_createdDateRange["endDate"] != "" &&
                this.selected_createdDateRange["endDate"]
                ) {
                matcher["createdDateRange"] = [
                this.selected_createdDateRange["startDate"],
                this.selected_createdDateRange["endDate"]
                ];
             }
              if(this.branchId){
                matcher['branchIds'].push(this.branchId)
               
              }
              if(this.isCompany){
                matcher['branchIds'].push(this.checkProperty(this.selectedBranch,'_id'))
              }
          
                let query = {};
                query['page'] = this.page;
                query['perpage'] = this.perpage;
                query['matcher'] = matcher;
                query['sorting'] = this.sortKey;
                this.$store
              .dispatch("getList",{data:query ,path:'/users/list'} )
              .then(response => {
                 this.updateLoading(false);
                this.masterUsers = response.list;
                this.userRolelist.map((item)=>{
                    let userList = _.filter(response.list ,{"roleId":item.id});
                    userList = userList.map((user)=>{
                        user['id'] = user['_id'];
                        if(_.has(user ,'name' ) && _.has(user ,'email' )){
                            user['name'] = user['name']+" ("+user['email']+")";
                        }
                        return user
                    });
                    item['usersList'] = userList;                          
                }); 
                this.processData();      
                }).catch((err)=>{
                 this.updateLoading(false);
                 this.masterUsers = []
                
               })
            },
            getUserRoleList() {
            this.updateLoading(true);
            let matcher = {
                searchString: this.searchtxt,
                statusIds: this.final_selected_statusids,
                createdDateRange: [],
            };
            if (
                this.selected_createdDateRange["startDate"] &&
                this.selected_createdDateRange["startDate"] != "" &&
                this.selected_createdDateRange["endDate"] != "" &&
                this.selected_createdDateRange["endDate"]
            ) {
                matcher["createdDateRange"] = [
                this.selected_createdDateRange["startDate"],
                this.selected_createdDateRange["endDate"],
                ];
            }
            let query = {};
            query["page"] = this.page;
            query["perpage"] = this.perpage;
            query["matcher"] = matcher;
            query["category"] = "user_roles";
            query["sorting"] = this.sortKey;
            this.$store
                .dispatch("getMasterData", query)
                .then((response) => {
                    this.userRolelist = [];
                    let roleList = response.list;
                    if(this.checkProperty(response, 'list') && this.checkProperty(response, 'list', 'length')>0){
                        _.forEach(roleList, (item)=>{                       
                            item = Object.assign(item ,{'usersList':[]});
                            item['usersList'] = [];
                            item['selectedUser'] = [];
                            if([7,8].indexOf(item.id)>-1){
                                this.userRolelist.push(item);
                            }
                        })                   
                    }
                this.updateLoading(false);
                this.totalpages = Math.ceil(response.totalCount / this.perpage);
                this.getUsersList();
                })
                .catch(() => {
                this.userRolelist = [];
                this.updateLoading(false);
                });
            },
        },
        mounted() {
            if(this.isCompany){
                this.getBranchList()
            }
            else{
                this.getDefaultUserDetails()
                this.getUserRoleList() 
            }
            
        }
    }
    </script>