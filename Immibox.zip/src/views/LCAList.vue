
<template>
  <div class="settings_right">
    <div class="content-header">
      <div class="content-header-left">
        <div class="search">
          <vs-input icon-pack="feather" icon="icon-search" placeholder="Search" class="is-label-placeholder"
            v-model.lazy="searchString" />
        </div>
        <div class="con-select selection_search selection_search-v2"
          v-if="[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50].indexOf(getUserRoleId) > -1 && getTenantTypeId != 2">
          <multiselect @input="changedStatusSearch()" v-model="selected_statusId" :options="all_statuses" :multiple="true"
            :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
            placeholder="Select Status" label="name" track-by="name" :preselect-first="false"
            @search-change="peritioners_search_fun">
            <template slot="selection" slot-scope="{ values, isOpen }">
              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Status(s)
                Selected</span>
              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
            </template>

          </multiselect>
        </div>
        <div class="con-select selection_search selection_search-v2"
          v-if="[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14].indexOf(getUserRoleId) > -1 && getTenantTypeId != 2">
          <multiselect @input="changedPeritionersSearch()" v-model="petitionerIds" :options="petitionerList"
            :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false"
            :preserve-search="true" placeholder="Select Petitioners" label="name" track-by="name" :preselect-first="false"
            @search-change="peritioners_search_fun">
            <template slot="selection" slot-scope="{ values, isOpen }">
              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Petitioner(s)
                Selected</span>
              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
            </template>

          </multiselect>
        </div>
        <div class="con-select selection_search selection_search-v2" v-if="[50].indexOf(getUserRoleId) > -1">
          <multiselect @input="changedBeneficiariesSearch()" v-model="beneficiaryIds" :options="beneficiariesList"
            :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false"
            :preserve-search="true" placeholder="Select Beneficiaries" label="name" track-by="name"
            :preselect-first="false" @search-change="beneficiariesSearch">
            <template slot="selection" slot-scope="{ values, isOpen }">
              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Beneficiaries
                Selected</span>
              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
            </template>

          </multiselect>
        </div>

      </div>
      <div class="content-header-right">
         <!--Sorting dropdown-->
         <div class="sorting_sec">
            <div class="sort_icon">
              <img src="@/assets/images/icons/sort.png" />
              <span v-if="addCls" class="loader"><img src="@/assets/images/main/loader.gif"></span>
            </div>
            <div class="soring_cnt" :class="{'hide': addCls}">
              <ul>
                <li @click="changeSorting(item)" :class="{'active': checkProperty(sortKey,'path' ) ==checkProperty(item,'path' ) , 'sort_ascending': checkProperty(sortKey,'path' ) ==checkProperty(item,'path' ) && item['order']==1 , 'sort_descending': checkProperty(sortKey,'path' ) ==checkProperty(item,'path' ) && item['order'] !=1 }" v-for="( item ,index) in sortingList">
                  <em></em>{{ item['displayName'] }}
                </li>
              </ul>
            </div>
          </div>

        <!--filter dropdown-->
        <vs-dropdown vs-custom-content vs-trigger-click>
          <vs-button color="primary" class="filter-btn" type="border" icon-pack="feather" icon="icon-chevron-down"
            icon-after>
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">
          <!-- <div class="applied-filter">
                <h4>Applied Filters</h4>
                <div>
                    <vs-chip @click="remove(chip)" v-for="(chip, index) in chips" :key="index" closable> {{ chip }} </vs-chip>
                </div>
                                                    </div>-->
          <!-- <div class="filters-status">
                <div class="left-buttons">
                    <vs-button color="success" class="clearall" type="filled">Clear All <i class="material-icons">
                    refresh
                    </i>
                    </vs-button>
                </div>
                <div class="right-buttons">
                    <vs-button color="success" class="save" type="filled">Save</vs-button>
                    <vs-button color="dark" class="cancel" type="filled">Cancel</vs-button>
                </div>
                                                    </div>-->
            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Status</label>
                    <multiselect v-model="filterStatusIds" :options="all_statuses" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Status" label="name" track-by="name" :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Status selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <div
                    v-if="[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14].indexOf(getUserRoleId) > -1 && getTenantTypeId != 2"
                    class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Petitioners</label>
                    <multiselect v-model="filterPetitionerIds" :options="petitionerList" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Petitioners" label="name" track-by="name" :preselect-first="false"
                      @search-change="peritioners_search_fun">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Petitioners selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <div v-if="[50].indexOf(getUserRoleId) > -1 && getTenantTypeId != 2"
                    class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Beneficiaries</label>
                    <multiselect v-model="filterBeneficiaryIds" :options="beneficiariesList" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Beneficiaries" label="name" track-by="name" :preselect-first="false"
                      @search-change="beneficiariesSearch">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Beneficiaries selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Country</label>
                    <multiselect @input="selectCountry(selected_countryId)" v-model="selected_countryId"
                      :options="all_countries" :multiple="false" :close-on-select="false" :clear-on-select="false"
                      :preserve-search="true" placeholder="Select Country" label="name" track-by="name"
                      :preselect-first="false">
                      <template slot="selection" slot-scope="{ values,  isOpen }"><span class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>

                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">States</label>
                    <multiselect @input="selectState(selected_stateId)" v-model="selected_stateId" :options="all_states"
                      :multiple="false" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select State" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values,  isOpen }"><span class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>

                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Locations</label>
                    <multiselect v-model="selected_locationId" :options="all_locations" :multiple="false"
                      :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Location" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values,  isOpen }"><span class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>

                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Posted Date</label>
                    <date-range-picker :autoApply="autoApply" :ranges="false"
                      @update="selectCreatedDateRange(selected_createdDateRang)" v-model="selected_createdDateRang">
                    </date-range-picker>
                  </div>

                <!-- <div class="vx-col md:w-1/3 w-full">
                        <vs-select v-model="city" class="w-full select-large" label="Posted By">
                        <vs-select-item :key="index" :value="item.value" :text="item.text"
                            v-for="(item,index) in cityOptions" class="w-full" />
                        </vs-select>
                                                          </div>-->

                <!-- <div class="vx-col md:w-1/3 w-full">
                        <vs-select v-model="city" class="w-full select-large" label="Submitted By">
                        <vs-select-item :key="index" :value="item.value" :text="item.text"
                            v-for="(item,index) in cityOptions" class="w-full" />
                        </vs-select>
                    </div>
                    <div class="vx-col md:w-1/3 w-full">
                        <vs-input class="w-full" label="Posted Date" />
                    </div>
                    <div class="vx-col md:w-1/3 w-full">
                        <vs-input class="w-full" label="Submitted Date" />
                    </div>
                    <div class="vx-col md:w-1/3 w-full">
                        <div class="custom-label">Pay Rate/HR($)</div>
                        <vs-slider step=10 v-model="value11"/>
                    </div>
                    <div class="vx-col md:w-1/3 w-full">
                        <div class="custom-label">Pay Rate/HR($)</div>
                        <vs-slider ticks step=25 v-model="value22"/>
                    </div>
                    <div class="vx-col md:w-1/3 w-full">
                        <vs-input class="w-full" label="Interview Status" />
                                                          </div>-->
                </div>
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons">
              <!-- <vs-button color="success" class="clearall" type="filled">Clear All <i class="material-icons">
                    refresh
                    </i>
                                                        </vs-button> -->
              </div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="setFilter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clearFilters($event)">Clear</vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        <vs-button color="primary" type="border" class="light-blue-btn" @click="addNewLCA(true, null)"
          v-if="lCACreatePermisions">
          New LCA <span>
            <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
          </span></vs-button>



        <!-- end -->
      </div>
    </div>
    <div class="accordian-table custom-table">

      <NoDataFound ref="NoDataFoundRef" :loading="!contentLoaded" v-if="lcaList.length == 0" content=""
        :heading="callFromSerch ? 'No Results Found' : 'No LCA Found'" type='LCA' />

      <div v-if="lcaList.length">
        <!----//createdOn", updatedOn, createdByName, caseNo, statusName-->
        <vs-table :data="lcaList">
          <template v-if="lcaList.length > 0" slot="thead">
            <vs-th>
              <div>
                <a @click="sortMe('caseNo')"
                  v-bind:class="{ 'sort_ascending': sortKeys['caseNo'] == 1, 'sort_descending': sortKeys['caseNo'] != 1 }">
                  LCA No
                </a>
              </div>
            </vs-th>
            <vs-th v-if="false">
              Client Name

            </vs-th>
            <vs-th v-if=" [50].indexOf(getUserRoleId) <= -1  &&  getTenantTypeId !=2">
              Petitioner Name

            </vs-th>
            <vs-th >
              Beneficiary Name

            </vs-th>
            <vs-th>
              Case(s)

            </vs-th>
            <vs-th>


              Requested Date

            </vs-th>
            <vs-th>
              <a @click="sortMe('updatedOn')"
                v-bind:class="{ 'sort_ascending': sortKeys['updatedOn'] == 1, 'sort_descending': sortKeys['updatedOn'] != 1 }">
                Last Updated</a>
            </vs-th>
            <vs-th>
              <a @click="sortMe('statusName')"
                v-bind:class="{ 'sort_ascending': sortKeys['statusName'] == 1, 'sort_descending': sortKeys['statusName'] != 1 }">
                Status
              </a>
            </vs-th>
            <vs-th class="actions">Actions
            </vs-th>
          </template>
          <template slot-scope="{ data }">
            <vs-tr :data="tr" :key="indextr" v-for="(tr, indextr) in data" class="vs-table--tr">
              <vs-td>
                <div class="cursor-pointer" @click="goToCaseDetaillPage(tr)">

                  <!-- {{ checkProperty(tr, 'petitionDetails', 'caseNo') }} -->
                  {{ checkProperty(tr, 'caseNo') }}
                </div>


              </vs-td>

              <vs-td v-if="false">
                <div class="cursor-pointer" @click="goToCaseDetaillPage(tr)">
                  {{ data[indextr].clientName }}
                </div>
              </vs-td>
              <vs-td v-if="[50].indexOf(getUserRoleId) <= -1  &&  getTenantTypeId !=2 ">
                <div class="cursor-pointer" @click="goToCaseDetaillPage(tr)">
                  {{ checkProperty(tr, 'petitionerDetails','name') }}
                </div>
              </vs-td>
              <!-- <vs-td >
                <div class="cursor-pointer" @click="goToCaseDetaillPage(tr)">
                  {{ checkProperty(tr, 'beneficiaryDetails','name') }}
                </div>
              </vs-td> -->
              <vs-td >
                 
                  <template v-if="checkProperty(tr ,'benificiaryNameList' ,'length') >0 ">
                    {{tr.benificiaryNameList[0] }}
                  </template>

                  <div class="menu_dropdown flexible_actions email_list right ml-2" v-if="checkProperty(tr ,'benificiaryNameList' ,'length') >1">
                        <em class="more_count ">
                          +{{ tr['benificiaryNameList'].length-1 }}
                        </em>
                        <div class="menu_list_wrap" v-if="checkProperty(tr ,'benificiaryNameList' ,'length') >1">
                          <ul class="">
                            <VuePerfectScrollbar ref="mainSidebarPs" class="scroll-area--main-sidebar"
                              :settings="settings" @ps-scroll-y="psSectionScroll">
                              <template v-for="( name ,eind ) in tr['benificiaryNameList']">
                                <li v-if="eind>0" :key="eind">{{ name }}</li>
                              </template>
                                
                            </VuePerfectScrollbar>

                          </ul>

                        </div>
                      </div>
                </vs-td>
              

              <vs-td>
                <!-- <div class="cursor-pointer subtypes__list" @click="goToCaseDetaillPage(tr)"> -->
                <div class="cursor-pointer subtypes__list">
                  <ul>
                    <li @click="navigateToCaseDetails(checkProperty(tr, 'petitionList') && checkProperty(tr, 'petitionList', 'length') > 0 ? checkProperty(tr, 'petitionList')[0]
                      : '')">
                      {{ (checkProperty(tr, 'petitionList') && checkProperty(tr, 'petitionList', 'length') > 0) ?
                        checkProperty(tr, 'petitionList')[0]['caseNo']
                        : ''
                      }}</li>
                    <li v-if="checkProperty(tr, 'petitionList', 'length') > 1">
                      <div class="menu_dropdown flexible_actions right ml-2">
                        <em class="more_count ">
                          +{{ (checkProperty(tr, 'petitionList', 'length')) - 1 }}
                        </em>
                        <div class="menu_list_wrap">
                          <ul class="">
                            <VuePerfectScrollbar ref="mainSidebarPs" class="scroll-area--main-sidebar"
                              :settings="settings" @ps-scroll-y="psSectionScroll">
                              <template v-for="(user, indx ) in tr['petitionList']">

                                <li :key="indx" v-if="indx > 0" @click="navigateToCaseDetails(user)"> {{
                                  checkProperty(user
                                    , 'caseNo') }}</li>
                              </template>
                            </VuePerfectScrollbar>

                          </ul>

                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
              </vs-td>

              <vs-td class="td_label">
                <div class="cursor-pointer" @click="goToCaseDetaillPage(tr)">
                  {{ checkProperty(tr, 'createdOn') | formatDate }}
                </div>
              </vs-td>
              <vs-td>
                <div class="cursor-pointer" @click="goToCaseDetaillPage(tr)">
                  <template v-if="checkProperty(tr, 'updatedOn')">
                    {{ checkProperty(tr, 'updatedOn') | formatDate }}
                  </template>
                  <template v-else-if="checkProperty(tr, 'createdOn')">
                    {{ checkProperty(tr, 'createdOn') | formatDate }}
                  </template>
                </div>
              </vs-td>
              <vs-td>
                <span class="cursor-pointer" @click="goToCaseDetaillPage(tr)" v-bind:class="{
                  'lca_created': checkProperty(tr, 'statusDetails', 'id') == 1,
                  'lca_filed': checkProperty(tr, 'statusDetails', 'id') == 2,
                  'lca_certified': checkProperty(tr, 'statusDetails', 'id') == 3,
                  'lca_denied': checkProperty(tr, 'statusDetails', 'id') == 4,
                  'lca_request_for_withdrawal': checkProperty(tr, 'statusDetails', 'id') == 5,
                  'lca_withdrawn': checkProperty(tr, 'statusDetails', 'id') == 6,
                  'lca_expired': checkProperty(tr, 'statusDetails', 'id') == 7,
                  'lca_rfe': checkProperty(tr, 'statusDetails', 'id') == 8,
                  'status_draft': checkProperty(tr, 'statusDetails', 'id') == 99,
                }">{{ tr.statusDetails.name }}</span>

              </vs-td>
              <vs-td>

                <vs-dropdown
                  v-if="lCACreatePermisions && (checkProperty(tr.statusDetails, 'id') && [4, 7].indexOf(tr.statusDetails['id']) <= -1)"
                  class="msg_dropdown_icon" :vs-trigger-click="true">
                  <a class="a-icon" href.prevent>
                    <more-vertical-icon size="1.5x" class="custom-class cursor"></more-vertical-icon>
                  </a>

                  <vs-dropdown-menu class="loginx msg_dropdown">



                    <vs-dropdown-item v-if="[1, 2, 3].indexOf(tr.statusDetails['id']) > -1">
                      <a href.prevent style="cursor:pionter;padding:3px 10px" @click="openLinkWithLCAPopup(tr)"><span>Link
                          with Case</span></a>
                    </vs-dropdown-item>
                    <vs-dropdown-item v-if="[1, 2, 3, 5, 6, 8].indexOf(tr.statusDetails['id']) > -1">
                      <a href.prevent style="cursor:pionter;padding:3px 10px"
                        @click="getLCADetails(tr, false, 6)"><span>Update Status</span></a>
                    </vs-dropdown-item>
                    <vs-dropdown-item v-if="[1, 2,3, 8,99].indexOf(tr.statusDetails['id']) > -1 && checkIsEditable(tr)">
                      <a href.prevent style="cursor:pionter;padding:3px 10px"
                        @click="addNewLCA(false, tr)"><span>Edit</span></a>
                    </vs-dropdown-item>



                  </vs-dropdown-menu>

                </vs-dropdown>
                <a v-else class="a-icon" href.prevent><more-vertical-icon size="1.5x"
                    class="custom-class disbleMenu"></more-vertical-icon></a>

              </vs-td>

            </vs-tr>

          </template>

        </vs-table>
        <div class="table_footer">

          <div class="vx-col  con-select pages_select" v-if="totalpages > 0">
            <label class="typo__label">Per Page</label>
            <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
              :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
              :preselect-first="true">
            </multiselect>
            <span class="totla_list_count" v-if="totalCount"> Total <em>{{totalCount}}</em></span>
          </div>

          <paginate v-if="totalpages > 1" v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2"
            :click-handler="pageNate" prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
            next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
            :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'">
          </paginate>
        </div>

      </div>
    </div>

    <div v-if="createLCA" class="custom_modal_sec documents__modal custom_modal-v2" :class="{ modalopen: createLCA }">
      <div class="custom_modal_overlay"></div>
      <div class="custom_modal_cnt">
        <div class="modal_title">
          <h2 v-if="isLCAEdit">Edit LCA </h2>
          <h2 v-else>New LCA </h2>
          <span class="close" @click="createLCA = false; selectedLCA = null;reloadLCAList()"><x-icon size="1.5x"></x-icon></span>
        </div>
        <RequestLCA v-bind:petitionDetails="null" v-bind:workFlowDetails="null" @updatepetition="reloadLCAList"
          @editLca="false" :isFromLCAList="true" @lcaRequestCancel="createLCA = false;" />

      </div>
    </div>

    <updateLCA v-if="showLCAUpdatePopup" @updatepetition="reloadLCAList" :petitionDetails="null" :lcaDetails="selectedLCA"
      @hideMe="showLCAUpdatePopup = false" :isFromLCAList="true" />


    <ManageLCALink v-if="showLinkwithLCAPopup" @updatepetition="reloadLCAList" :petitionDetails="null"
      :lcaDetails="selectedLCA" @hideMe="showLinkwithLCAPopup = false" :isFromLCAList="true" :popUpTitle="'Link LCA'"
      :ACTIVITYCODE="'LINK_LCA'" :lcaId="selectedLCA._id" />



  </div>
</template>
<script>
import DateRangePicker from "vue2-daterange-picker";
import Multiselect from "vue-multiselect-inv";
import Paginate from "vuejs-paginate";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import moment from "moment";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import { XIcon, MoreVerticalIcon } from 'vue-feather-icons'
import NoDataFound from "@/views/common/noData.vue";
import RequestLCA from "./RequestLCA";
import updateLCA from "@/views/actionpopups/updateLCA.vue";
import LCADetails from "./LCADetails";
import VueDocPreview from "vue-doc-preview";
import docmentType from "@/views/common/docType.vue";
import pdfReader from "../views/common/pdfReader.vue";
import ManageLCALink from "./actionpopups/manageLCALink.vue";
import JQuery from "jquery";
export default {
  components: {
    VuePerfectScrollbar,
    DateRangePicker,
    Multiselect,
    Paginate,
    NoDataFound,
    XIcon,
    RequestLCA,
    MoreVerticalIcon,
    updateLCA,
    LCADetails,
    ManageLCALink
  },
  methods: {
    changeSorting(item){
      
     
       
         
          if(_.has(this.$route,'name')){
            this.addCls = true;   
            item['order'] = item['order']==1?-1:1;
          localStorage.setItem(this.$route['name'] ,JSON.stringify(item));
          this.sortKey = item;
          this.sortKeys[item['path']] = item['order'];
          _.forEach(this.sortKeys, (sortVal, sortKey)=>{
            if(sortKey == item['path'] ){ 
              this.sortKeys[sortKey] = this.sortKey['order'];
            }else{
            //  this.sortKeys[sortKey]= this.sortKey['order']==1?-1:1
            }

            
          });
          this.getLcaList();

          }
    },
    psSectionScroll(){},
    searchMe(){
    let self =this;
    clearTimeout(this.debounce)
      this.debounce = setTimeout(() => {
        self.getLcaList(true);
      }, 900)

     //self.getGlobalSearch(true);

    
      },
    goToCaseDetaillPage(data) {

      if (this.checkProperty(data, '_id') && this.checkProperty(data, 'statusId') != 99) {
        let routedId = this.checkProperty(data, '_id')
        // let path = "/lca-inventory-details/" + routedId;
        // if (this.encodedString != '') {
        //   path = path + "?filter=" + this.encodedString;
        // }
        this.$router.push({ path: `/lca-inventory-details/${routedId}` ,query: {'filter':this.encodedString} }).catch(err => {})

        //this.$router.push(path);
      }else{
        
        if(this.checkProperty(data, 'statusId') == 99){
          this.addNewLCA(false, data)
        }
        
      }


    },
    navigateToCaseDetails(item) {
      let routedId = item['_id'];
      this.$router.push({ path: `/petition-details/${routedId}` }).catch(err => { })
    },

    checkTypeDetails(data) {

      if (_.has(data, 'petitionDetails') && _.has(data['petitionDetails'], 'subTypeDetails')) {
        return true;
      } else {
        return false;
      }

    },

    sortMe(sort_key = '') {

      //   this.sortKeys = {
      //   'caseNo':1,
      //   'beneficiaryDetails.name':1,
      //   "typeDetails.name":1,
      //   "petitionerDetails.name":1,
      //   "updatedOn":1,
      //   "communicationDetailslength":1

      // }

      if (sort_key != '') {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1
        this.sortKey = {};
        this.sortKey = { "path": sort_key, "order": this.sortKeys[sort_key] }


        localStorage.setItem('lca_sort_key', sort_key);
        localStorage.setItem('lca_sort_value', this.sortKeys[sort_key]);
        this.getLcaList();
      }



    },

    petitionlink(tr) {
      this.$router.push({ path: `/lca-details/${tr._id}` }).catch(err => { })

    },
    setQueryString(obj) {
      const string = JSON.stringify(obj) // convert Object to a String
      this.encodedString = btoa(string) // Base64 encode the String

      // var actual = JSON.parse(atob(encodedString))
    },
    getLcaList(callFromSerch = false, filterObj = null) {

      this.encodedString = '';
      // contentLoaded:false, 
      this.callFromSerch = callFromSerch;
      if (this.callFromSerch) {
        this.lcaList = [];

      }
      this.contentLoaded = false;
      let selectedStatuses = this.selected_statusId.map(item => item.id)
      let obj = {
        page: this.page,
        perpage: this.perpage,
        sorting: this.sortKey,
        matcher: {
          searchString: this.searchString,
          petitionerIds: [],
          statusIds: selectedStatuses,
          typeIds: this.selected_typeId,
          countryIds: (this.selected_countryId !== "") ? [this.selected_countryId.id] : [],
          stateIds: (this.selected_stateId !== "") ? [this.selected_stateId.id] : [],
          locationIds: (this.selected_locationId !== "") ? [this.selected_locationId.id] : [],
          createdDateRange: this.selected_createdDateRange
        }
      };
      if (this.petitionerIds && this.petitionerIds.length > 0) {
        obj['matcher']['petitionerIds'] = this.petitionerIds.map((item) => { return item['_id'] })

      }
      if (this.beneficiaryIds && this.beneficiaryIds.length > 0) {
        obj['matcher']['beneficiaryIds'] = this.beneficiaryIds.map((item) => { return item['_id'] })
      }

      if (filterObj && (Object.keys(filterObj)).length > 0 && false) {
        _.forEach(filterObj, (item, key) => {
          if (key == 'matcher') {
            if ((Object.keys(item)).length > 0) {
              obj['matcher'] = item
            }

          }

          if (key == 'page' && item > 0) {
            obj['page'] = parseInt(item)
            this.page = parseInt(item)
          }
          if (key == 'perpage' && item > 0) {
            obj['perpage'] = parseInt(item)

            this.perpage = parseInt(item)
          }
          if (key == 'sorting') {
            if ((Object.keys(item)).length > 0) {
              obj['sorting'] = item
            }

          }
        })
      }
      let tempObj={
        selected_countryId:this.selected_countryId,
        selected_stateId:this.selected_stateId,
        selected_locationId:this.selected_locationId,
        petitionerIds:this.petitionerIds,
        filterPetitionerIds:this.filterPetitionerIds,
        selected_statusId:this.selected_statusId,
        filterStatusIds : this.filterStatusIds,
        searchString:this.searchString,
        selected_createdDateRange:this.selected_createdDateRange,
        page: this.page,
        perpage: this.perpage,
        sortKey: this.sortKey,
      };

      this.setQueryString(tempObj);
      this.updateLoading(true);
      this.$store.dispatch("fetchlcalist", obj).then(response => {
        this.addCls = false;   
        this.updateLoading(false);
        let list = response.data.result.list;
        // if(this.checkProperty(this.lcaList,'length')>0){
        //   if(checkProperty(this.lcaList[0], 'petitionList', 'length')>0){
        //     this.lcaList[0]['petitionList'].push(this.lcaList[0]['petitionList'][0])
        //   }
        // }
        if(list && this.checkProperty(list,'length')>0){
          _.forEach(list,(item)=>{
            if(_.has(item,'benificiaryName') && this.checkProperty(item, 'benificiaryName')){
              let tempWord = item['benificiaryName'].split(',')
              if(tempWord){
                Object.assign(item,{'benificiaryNameList':tempWord})
              }
            }
          })
        }
        this.lcaList = _.cloneDeep(list)
        this.totalCount = this.checkProperty(response.data, 'result', 'totalCount')
        this.totalpages = Math.ceil(response.data.result.totalCount / this.perpage);
        this.contentLoaded = true;

        
        const $ = JQuery;
        $("html, body").animate({ scrollTop: 0 }, 100);

      }).catch(() => {
        this.addCls = false;   
        this.lcaList = [];
        this.updateLoading(false);
      })
    },
    filterQueryPreSelect(callFromMounted=false){
      if(this.checkProperty(this.$route ,'query' ,'filter')){
        try{
          let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
          var actual = JSON.parse(atob(filter));
          let keys = Object.keys(actual);
          if(this.checkProperty(keys ,'length') >0 ){
            if(_.has(actual ,'page') && this.checkProperty(actual ,'page')){                                     
              this.page = this.checkProperty(actual ,'page');
            }
            if(_.has(actual ,'perpage') && this.checkProperty(actual ,'perpage')){                                     
              this.perpage = this.checkProperty(actual ,'perpage');
            }
            if(_.has(actual ,'sortKey') && this.checkProperty(actual ,'sortKey')){      
              if(this.sortKeys){
                this.sortKeys[actual['sortKey']['path']] = actual['sortKey']['order']
              }                                  
              this.sortKey = this.checkProperty(actual ,'sortKey');
            }
            if(_.has(actual ,'selected_countryId') && this.checkProperty(actual ,'selected_countryId')){                                     
              this.selected_countryId = this.checkProperty(actual ,'selected_countryId');
              this.selectCountry();
            }
            if(_.has(actual ,'selected_stateId') && this.checkProperty(actual ,'selected_stateId')){                                     
              this.selected_stateId = this.checkProperty(actual ,'selected_stateId');
              this.selectState();
            }
            if(_.has(actual ,'selected_locationId') && this.checkProperty(actual ,'selected_locationId')){                                     
              this.selected_locationId = this.checkProperty(actual ,'selected_locationId');
            }
            if(_.has(actual ,'filterPetitionerIds') && this.checkProperty(actual ,'filterPetitionerIds') && this.checkProperty(actual ,'filterPetitionerIds', 'length')>0){                                     
              this.filterPetitionerIds = this.checkProperty(actual ,'filterPetitionerIds');
            }
            if(_.has(actual ,'petitionerIds') && this.checkProperty(actual ,'petitionerIds') && this.checkProperty(actual ,'petitionerIds', 'length')>0){                                     
              this.petitionerIds = this.checkProperty(actual ,'petitionerIds');
            }
            if(_.has(actual ,'selected_createdDateRange') && this.checkProperty(actual ,'selected_createdDateRange') && this.checkProperty(actual ,'selected_createdDateRange', 'length')>0 &&
            actual['selected_createdDateRange'][0]  && actual['selected_createdDateRange'][1]){                                  
              let dte = {
                startDate:actual['selected_createdDateRange'][0],
                endDate:actual['selected_createdDateRange'][1]
              };
              this.selected_createdDateRang = dte;
              this.selectCreatedDateRange(dte)
            }
            if(_.has(actual ,'searchString') && this.checkProperty(actual ,'searchString') ){                                     
              this.searchString = this.checkProperty(actual ,'searchString');
            }
            if(_.has(actual ,'selected_statusId') && this.checkProperty(actual ,'selected_statusId') && this.checkProperty(actual ,'selected_statusId', 'length')>0){                                     
              this.selected_statusId = this.checkProperty(actual ,'selected_statusId');
            }
            if(_.has(actual ,'filterStatusIds') && this.checkProperty(actual ,'filterStatusIds') && this.checkProperty(actual ,'filterStatusIds', 'length')>0){                                     
              this.filterStatusIds = this.checkProperty(actual ,'filterStatusIds');
            }
            this.setFilter();
          }else{
            this.setFilter();
          }
        }catch(e){
          this.setFilter();
          
        }   
      }
      else{
        this.setFilter();
        
      } 
    },

    getInventoryStatus() {
      this.$store
        .dispatch("getmasterdata", "lca_inventory_status")
        .then(response => {
          
          this.all_statuses = response;

          
        });
    },
    getAllCountries() {
      this.$store.dispatch("getcountries").then(response => {
        this.all_countries = response;
        
      });
    },
    getAllStates() {
      this.$store
        .dispatch("getstates", this.selected_countryId.id)
        .then(response => {
          this.all_states = response;
          
        });
    },
    getAllLocations() {
      this.query = {
        countryId: this.selected_countryId.id,
        stateId: this.selected_stateId.id //3922
      };

      this.$store.dispatch("getlocations", this.query).then(response => {
        this.all_locations = response;
        
      });
    },
    selectLocation(option) {
      this.selected_locationId = option.id;
    },
    selectState(option) {

      this.getAllLocations();
    },
    selectCountry(option) {
      this.getAllStates();
    },
    selectStatusIds(option) {
      this.selected_statusId = option;
    },
    selectTypeIds(option) {
      this.selected_typeId = option;
    },
    selectCreatedDateRange(option) {
      // console.log(JSON.stringify(option))
      option.startDate = moment(option.startDate).format("YYYY-MM-DD");
      option.endDate = moment(option.endDate).format("YYYY-MM-DD");
      this.selected_createdDateRange = [option.startDate, option.endDate];
      
    },
    changeState() {
      
      this.selected_countryId = this.selected_countryId.id
      this.getAllStates();
    },
    changeLocation() {
      this.selected_stateId = this.selected_stateId.id;
      this.getAllLocations();
    },
    setFilter() {
      // this.selected_statusId = this.selected_statusId.map(item=> item.id)
      this.petitionerIds = this.filterPetitionerIds
      this.beneficiaryIds = this.filterBeneficiaryIds
      this.selected_statusId = this.filterStatusIds
      this.getLcaList(true);
      this.$refs["filter_menu"].dropdownVisible = false;
     
    },
    clearFilters() {
      this.searchString = "";
      this.selected_statusId = [];
      this.selected_typeId = [];
      this.selected_countryId = "";
      this.selected_stateId = "";
      this.selected_locationId = "";
      this.selected_createdDateRange = [];
      this.selected_createdDateRang = [];
      this.petitionerIds = [];

      this.getLcaList();
      this.$refs["filter_menu"].dropdownVisible = false;
      this.$router.push({ query: {} })
    },
    syncFilters() {

      this.filterPetitionerIds = this.petitionerIds
      this.filterStatusIds = this.selected_statusId
      this.filterBeneficiaryIds = this.beneficiaryIds
      //  this.$refs["filter_menu"].dropdownVisible = false;
    },
    pageNate(pageNum) {
      this.page = pageNum;
      this.getLcaList(true);
    },

    peritioners_search_fun(searchValue) {
      this.peritioners_search_value = searchValue;
      this.getPeritioners();
    },
    getPeritioners() {
      //petitioner_list_for_tenant_users
      let item = {
        page: 1,
        perpage: 10000,
        category: "petitioner_list_for_tenant_users",
        matcher: {
          "searchString": this.peritioners_search_value,

        },
        "sorting": {
          "path": "name",
          "order": 1
        }

      };
      if ([51].indexOf(this.getUserRoleId) > -1) {
        item['category'] = "petitioner_list_for_beneficaries"
      }
      this.$store.dispatch("getMasterData", item).then(response => {
        this.petitionerList = response.list
      });
    },
    addNewLCA(newLCA = true, item = null) {
      if (newLCA) {
        this.$store.dispatch("setPetitionData", { petitionDetails: null, lcaDetails: null, workFlowDetails: null, });
        this.isLCAEdit = false
        this.createLCA = true
      } else {
        this.isLCAEdit = true
        this.getLCADetails(item, true)
      }
    },
    changedPeritionersSearch() {
      this.filterPetitionerIds = this.petitionerIds
      // this.final_selected_peritioners = [];
      // if (this.selected_peritioners.length > 0) {
      //   for (let i = 0; i < this.selected_peritioners.length; i++) {
      //     this.final_selected_peritioners.push(
      //       this.selected_peritioners[i]["_id"]
      //     );
      //   }
      // }

      // this.get_peritioners_beneficiaries();
      this.setFilter();
    },
    changedStatusSearch() {
      this.filterStatusIds = this.selected_statusId
      // this.final_selected_peritioners = [];
      // if (this.selected_peritioners.length > 0) {
      //   for (let i = 0; i < this.selected_peritioners.length; i++) {
      //     this.final_selected_peritioners.push(
      //       this.selected_peritioners[i]["_id"]
      //     );
      //   }
      // }

      // this.get_peritioners_beneficiaries();
      this.setFilter();
    },
    changeperPage() {
      this.page = 1;
      localStorage.setItem('lcas_perpage', this.perpage);
      this.getLcaList(true);
    },
    openLCAUpdatePopup(statusId) {
      // this.selectedLCA = item;   
      setTimeout(() => {
        this.showLCAUpdatePopup = true;
      }, 100);

    },
    reloadLCAList() {
      this.createLCA = false;
      this.showLCAUpdatePopup = false,
        this.page = 1;
      this.getLcaList(true);
    },

    getLCADetails(item, editLCA = false, statusId = 1) {
      this.$vs.loading();
      //this.selectedLCA = item;
      //let self=this
      this.$store.dispatch("fetchLcaDetails", item._id)
        .then((response) => {

          this.selectedLCA = response.data.result;
          if (editLCA) {

            // if (this.checkProperty(this.selectedLCA, 'petitionDetails', '_id')) {
            //   this.getPetition(this.checkProperty(this.selectedLCA, 'petitionDetails', '_id'))
            // } else {
            this.$vs.loading.close();
            this.$store.dispatch("setPetitionData", { petitionDetails: null, lcaDetails: this.selectedLCA, workFlowDetails: null, });
            setTimeout(() => {
              this.createLCA = true
            }, 100);
            //  }

          } else {
            this.$vs.loading.close();
            if (statusId == 0) {
              this.showLCADetailsPopup = true
            } else {
              //  this.selectedLCA['updateStatusId'] = statusId
              // this.selectedLCA['statusId'] = statusId
              this.openLCAUpdatePopup(statusId)
            }
          }
        })
        .catch((error) => {
          this.$vs.loading.close();
          this.showToster({ message: error, isError: true });

        });
    },
    beneficiariesSearch(searchValue) {
      this.beneficiariesSearchValue = searchValue;
      this.getBeneficiaries();
    },
    getBeneficiaries() {
      //petitioner_list_for_tenant_users
      let item = {
        page: 1,
        perpage: 10000,
        category: "beneficary_list_for_petitioners",
        matcher: {
          "searchString": this.beneficiariesSearchValue,
          "getMasterDataOnly": true,
        },
        "sorting": {
          "path": "name",
          "order": 1
        }

      };

      this.$store.dispatch("getMasterData", item).then(response => {
        this.beneficiariesList = response.list
      });
    },
    changedBeneficiariesSearch() {
      this.filterBeneficiaryIds = this.beneficiaryIds
      this.setFilter();
    },
    openLinkWithLCAPopup(item) {
      this.selectedLCA = item;
      this.showLinkwithLCAPopup = true
    },
    getPetition(petitionId) {
      this.$store.dispatch("getpetition", petitionId).then((response) => {
        if (response.data) {
          let petition = response.data.result;
          if (this.checkProperty(petition, "workflowId")) {
            let workFlowId = petition.workflowId;
            if (workFlowId) {
              let payLoad = {
                path: "/workflow/details",
                data: { workflowId: workFlowId },
              };
              this.$store
                .dispatch("commonAction", payLoad)
                .then((res) => {
                  this.$vs.loading.close();
                  let workFlowDetails = res;
                  this.$store.dispatch("setPetitionData", {
                    petitionDetails: petition,
                    lcaDetails: this.selectedLCA,
                    workFlowDetails: workFlowDetails,
                  });
                  setTimeout(() => {
                    this.createLCA = true
                  }, 100);
                })
                .catch((error) => {
                  this.$vs.loading.close();
                });
            }
          }

        }
      });
    },


  },
  watch: {
    searchString: function (value) {
      this.searchMe();
    }
  },
  data: () => ({
    addCls:false, 
    settings: { 
            swipeEasing: true,
        },
    debounce:null,
    encodedString: '',
    contentLoaded: false,
    callFromSerch: false,
    searchString: "",
    petitionerIds: [],
    filterPetitionerIds: [],
    petitionerList: [],
    peritioners_search_value: "",
    all_statuses: [],
    all_types: [],
    all_countries: [],
    all_states: [],
    all_locations: [],
    selected_statusId: [],
    filterStatusIds: [],
    selected_typeId: [],
    selected_countryId: "",
    selected_stateId: "",
    selected_locationId: "",
    selected_createdDateRange: [],
    selected_createdDateRang: [],
    page: 1,
    perpage: 10,
    lcaList: [],
    query: {},
    autoApply: "",
    totalpages: 0,
    totalCount:0,
    sortKeys: {},
    sortKey:{"path":'updatedOn',"order":-1},
    
    sortingList:[
      //  {path:'caseNo',order:-1 ,"displayName":"Case Number"},
   //    {path:'createdByName',order:-1 ,"displayName":"Created By Name"},
   //    {path:'typeName',order:-1 ,"displayName":"Case Type"},
    //   {path:'subTypeName',order:-1,"displayName":"Case Sub Type"},
    //   {path:'statusName',order:-1,"displayName":"Case Status"},
       {path:'createdOn',order:-1,"displayName":"Created Date"},
       {path:'updatedOn',order:-1,"displayName":"Updated Date"},
  //     {path:'clientName',order:-1,"displayName":"Client Name"},
    //   {path:'beneficiaryName',order:-1,"displayName":"Beneficiary Name"},
        
   ],
    createLCA: false,
    perPeges: [10, 25, 50, 75, 100],
    selectedLCA: null,
    showLCAUpdatePopup: false,
    isLCAEdit: false,
    beneficiariesList: [],
    beneficiaryIds: [],
    filterBeneficiaryIds: [],
    beneficiariesSearchValue: '',
    showLCADetailsPopup: false,
    selectedFile: null,
    showLinkwithLCAPopup: false,
  }),
  mounted() {


    if (this.$route.params && this.$route.params.openCreatePopup) {
      // this.selectedBeneficiary =null 
      // this. selectedPetitioner=null
      var _s = this;
      setTimeout(function () {
        _s.addNewLCA(true, null)
      }, 600)
    }

    //createdOn", updatedOn, createdByName, caseNo, statusName
    this.sortKeys = {
      'caseNo': 1,
      'createdByName': 1,
      "statusName": 1,
      "updatedOn": -11,
      createdOn: -1


    },

      
      this.sortKey= {"path":'updatedOn',"order":-1};
      if(_.has(this.$route,'name')){
      let localSorting = localStorage.getItem(this.$route['name']);
      if(localSorting){
        localSorting = JSON.parse(localSorting);
        if(this.checkProperty(localSorting, "path") && [1,-1].indexOf(this.checkProperty(localSorting, "order")) ){
          this.sortKey = localSorting;
          _.forEach(this.sortKeys, (sortVal, sortKey)=>{
            if(sortKey == localSorting['path'] ){ 
              this.sortKeys[sortKey] = localSorting['order']
            }else{
              this.sortKeys[sortKey]= localSorting['order']==1?-1:1
            }

            
          });
        }


      }


    }

   
    if (localStorage.getItem('lca_perpage')) {
      this.perpage = parseInt(localStorage.getItem('lca_perpage'));
    }


    // if (this.checkProperty(this.$route, 'query', 'filter')) {
    //   try {
    //     let filter = this.$route['query']['filter']; this.checkProperty(this.$route, 'query', 'filter')
    //     var actual = JSON.parse(atob(filter));
    //     let keys = Object.keys(actual);
    //     if (this.checkProperty(keys, 'length') > 0) {

    //       this.getLcaList(false, actual);

    //     } else {
    //       this.getLcaList();
    //     }

    //   } catch (e) {
    //     this.getLcaList();

    //   }


    // } else {

    //   this.getLcaList();

    // }



    this.getAllCountries();
    this.getInventoryStatus();
    this.getPeritioners();
    this.getBeneficiaries();
    this.filterQueryPreSelect(true);
  },
  computed: {
    checkIsEditable(){
      return (item)=>{

        let returnVal =true;
        if([50].indexOf(this.getUserRoleId)>-1 && this.checkProperty(item,'petitionList', 'length') >0){
          
          //completedActivities
          let submitToLawFirmCases = _.filter(item['petitionList'],(petition)=>{
            let rVal =false;
            if(_.has(petition,'completedActivities') && this.checkProperty(petition,'completedActivities','length') >0){
             if(petition['completedActivities'].indexOf('SUBMIT_TO_LAW_FIRM')>-1){
              rVal =true;
             }

              
            }
            return rVal;


          }); 
          if( !submitToLawFirmCases || this.checkProperty(submitToLawFirmCases,'length') <=0){
            returnVal =false;
          }

        }
        return returnVal;

      }
    },
    lCACreatePermisions() {
      let returnValue = false;
      //tenantDetails
      if (this.checkProperty(this.getUserData, 'tenantDetails', 'permissions')) {

        if (this.checkProperty(this.getUserData['tenantDetails']['permissions'], 'LCA_CREATE', 'length') > 0) {
          let userData = _.cloneDeep(this.getUserData);
          if (userData && this.checkProperty(userData, 'tenantDetails', 'permissions') && userData['tenantDetails']['permissions']['LCA_CREATE'].indexOf(this.getUserRoleId) > -1) {
            returnValue = true
          }


        }

      }
      return returnValue
    },
  }
};
</script>