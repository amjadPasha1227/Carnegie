<template>
  <div>
    
       <div class="notes_section" >
      <div class="notes_details_page">
        <div class="notes_details_sec">
          <div class="notes_title">
              <h3>Details</h3>
              <div class="notes_title_right">
                <p >Last Updated 
                <b v-if="checkProperty(ticket ,'updatedOn')">{{checkProperty(ticket ,'updatedOn')  | formatDateTime}}</b>
                <b v-else>{{checkProperty(ticket ,'createdOn') | formatDateTime}}</b>
                
                </p>
               
                <span v-if="checkProperty(ticket,'statusDetails','name')" class="notes_status" :class="{[getCalssName(checkProperty(ticket,'statusDetails','name'))]:true}">{{checkProperty(ticket,"statusDetails","name") }}</span>
                <em class="edit" v-if=" ( checkProperty(ticket,'createdBy') == checkProperty(getUserData,'userId')) &&checkProperty(ticket,'statusDetails','id') !=2  " @click="editMe()"><img src="@/assets/images/main/edit_icon.svg"></em>
              </div>
          </div>
          <div class="notes_details_cnt">
            <div class="notes_list">
              <div class="notes_info w-100">
                <div class="d-flex notes-info-date">
                <h4>{{ticket['title']}}</h4>
                <p> Created On <b >{{checkProperty(ticket ,'createdOn') | formatDateTime}}</b></p>
                </div>
                <p v-html="ticket['description']"></p>
                <ul>
                  <li>
                    <label>Created By </label>
                    <p>{{checkProperty(ticket , 'createdByName')}}
                     <template  v-if="checkProperty(ticket ,'createdByRoleName')">({{checkProperty(ticket ,'createdByRoleName') }})</template>
                     
                     </p> 
                  </li>
                  <li>
                    <label>
                       <img v-if="checkProperty(ticket ,'accessLevelId') ==1" src="@/assets/images/main/lock.svg" />
                      <img v-else src="@/assets/images/main/public.svg">
                      {{checkProperty(ticket , 'accessLevelDetails' , 'name')}}</label> 
                  </li>
                  <li @click="goToCaseDetails(ticket)" class="cursor" v-if="checkProperty(ticket ,'petitionDetails', 'caseNo') " >
                    <label>Case  </label>
                    <p>
                      <template v-if="checkProperty(ticket['petitionDetails'], 'typeDetails' , 'name') || checkProperty(ticket['petitionDetails'], 'subTypeDetails' , 'name')">
                      <div class="IB_tooltip premium_tooltip notes_details"   >
                        <p>{{ checkProperty(ticket['petitionDetails'], "caseNo") }}</p>
                        <div class="tooltip_cnt">
                        <p>{{ checkProperty(ticket['petitionDetails'], 'typeDetails' , "name")  }}   <em>{{ checkProperty(ticket['petitionDetails'], 'subTypeDetails' , "name") }}</em></p>
                      </div>
                     </div>
                    </template>
                     <template v-else>
                      {{ checkProperty(ticket['petitionDetails'], "caseNo") }}
                     </template>


                    </p>
    

                  </li>
                   
                </ul>
              </div> 
            </div>
           

            <div class="notes_list" v-if="checkProperty(ticket ,'documents','length')>0">
              <div class="documents_list">
                <h4>Documents</h4>
                <ul>
                  <template v-for="(tattachment, atIndex) in ticket['documents']"  >
                
                    <template v-if="checkFileFormat(tattachment['mimetype']) =='video_mime_types'">
                    <li :key="atIndex" @click="download_or_view(tattachment)"  v-tooltip.top-center="checkProperty(tattachment ,'name') " > 
                    <figure>
                    <img src="@/assets/images/main/film.png" />
                    <span class="download_icon"></span>  
                    </figure> 
                    <!-- <p>{{checkProperty(tattachment ,"name")}}</p> -->

                    </li>

                    </template>
                    <template v-else-if="checkFileFormat(tattachment['mimetype']) =='pdf'">
                    <li :key="atIndex" @click="download_or_view(tattachment)"  v-tooltip.top-center="checkProperty(tattachment ,'name') "> 
                    <figure>
                    <img src="@/assets/images/main/pdf.svg" />
                    <span class="download_icon"></span>  
                    </figure>  

                    </li>

                    </template>
                    <template v-else-if="checkFileFormat(tattachment['mimetype']) =='msDoc'">
                    <li :key="atIndex" @click="download_or_view(tattachment)" v-tooltip.top-center="checkProperty(tattachment ,'name') "> 
                    <figure>
                    <img src="@/assets/images/main/doc.svg" />
                    <span class="download_icon"></span>  
                    </figure>  

                    </li>

                    </template>
                    <template v-else-if="checkFileFormat(tattachment['mimetype']) =='msXl'">
                    <li :key="atIndex" @click="download_or_view(tattachment)" v-tooltip.top-center="checkProperty(tattachment ,'name') " > 
                    <figure>
                    <img src="@/assets/images/main/xls.svg" />
                    <span class="download_icon"></span>  
                    </figure> 
                    <p>{{checkProperty(tattachment ,"name")}}</p>

                    </li>

                    </template>
                    <template v-else-if="checkFileFormat(tattachment['mimetype']) =='msPpt'">
                    <li :key="atIndex" @click="download_or_view(tattachment)" v-tooltip.top-center="checkProperty(tattachment ,'name') " > 
                    <figure>
                    <img src="@/assets/images/main/ppt.svg" />
                    <span class="download_icon"></span>  
                    </figure> 


                    </li>

                    </template>
                    <template v-else-if="checkFileFormat(tattachment['mimetype']) =='zip'">
                    <li :key="atIndex" @click="download_or_view(tattachment)"  v-tooltip.top-center="checkProperty(tattachment ,'name') "> 
                    <figure>
                    <img src="@/assets/images/main/zip-file-format.png" />
                    <span class="download_icon"></span>  
                    </figure> 


                    </li>

                    </template>
                    <template v-else-if="checkFileFormat(tattachment['mimetype']) =='image'">
                    <li :key="atIndex" @click="download_or_view(tattachment)"  v-tooltip.top-center="checkProperty(tattachment ,'name') "> 
                    <figure>
                    <img src="@/assets/images/main/image.svg" />
                    <span class="download_icon"></span>  
                    </figure> 


                    </li>

                    </template>
                    <template v-else>
                    <li :key="atIndex" @click="download_or_view(tattachment)" v-tooltip.top-center="checkProperty(tattachment ,'name') "> 
                    <figure>
                    <img src="@/assets/images/main/commonfiles.png" />
                    <span class="download_icon"></span>  
                    </figure> 
                    </li>

                    </template>
                  </template>
                 
                   
                </ul>
              </div> 
            </div>


            <div class="taggedlist border_top_0" v-if="checkProperty(ticket ,'taggedToDetails','length')>0 && checkProperty(ticket , 'accessLevelId')==3">
              <h4>Tagged To</h4>
              <ul>
                <li  v-for="(member ,index) in ticket['taggedToDetails'] " :key="index">
                   <figure><img :src="checkProperty(member ,'profilePicture')"  @error="setDefaultPhoto($event)"></figure>
                  <figcaption>{{member['name']}}<span>{{member['roleName']}}</span></figcaption>                   
                </li>
               
              </ul>
            </div>
          </div>
        </div>
        <div class="notes_comments">
          <div class="comments_sec">
            <div class="d-flex justify-between align-center mb-3">
              <h4>Comments<span>{{checkProperty(ticket ,'comments','length')}}</span></h4>
              <div class="relative comments_status">
                <multiselect
                      v-model="nweStatus.statusId"
                      :options="tempStatusids"
                      :multiple="false"  
                      :close-on-select="true"
                      :clear-on-select="false"
                      :preserve-search="true"
                       :select-label="''"
                      placeholder="Select Status"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                      :allow-empty="false"
                       v-validate="'required'"
                      data-vv-as="Note Status"
                        name="Status"
                       :disabled="[2].indexOf(checkProperty(ticket,'statusDetails','id'))>-1 || ( checkProperty(ticket,'createdBy') != checkProperty(getUserData,'userId')) " 
                     
                      
                   
                    >  
                </multiselect>
                <!-- :disabled="[4,5].indexOf(ticket['statusDetails']['id'])>-1"  -->
               <span class="text-danger status" v-show="errors.has('commentForm.Status')"  >{{ errors.first("commentForm.Status") }}</span >
              </div>
            </div>
             <form data-vv-scope="commentForm" @submit.prevent>
            <div class="comments_cnt">
            
              <textarea rows="2"   type="text" placeholder="Enter Comments *" v-model="nweStatus.comment" v-validate="'required'"  data-vv-as="Comment"  name="comment"  ></textarea>
              <span class="text-danger comments" v-show="errors.has('commentForm.comment')"  >{{ errors.first("commentForm.comment") }}</span  >
                  
              
                   
                   
            </div>
            </form>  
            <button  :disabled="creatingNewNote " class="primary-btn"   @click=" updateNoteStatus()">Submit</button>
          </div>
          <div class="comments_list_wrap" >
            <VuePerfectScrollbar
              ref="mainSidebarPs"
              class="scroll-area--nofications-dropdown p-0"
              @ps-scroll-y="scroll"
            >
              <div >
                <div class="comments" v-for="(comment ,index) in comments"  :key="index">
                  <div class="comments_profile">
                    <figure><img :src="checkProperty(comment ,'createdByProfilePictue')"  @error="setDefaultPhoto($event)"></figure>
                    <figcaption>{{comment.createdByName}}<span>({{checkProperty(comment,'createdByRoleName')}})</span></figcaption>
                  </div>
                  <div class="comments_info">
                    <div class="message">
                      <p>{{comment.comment}}</p>
                      <span class="notes_status" :class="getCalssName(checkProperty(comment,'statusName'))" >{{comment['statusName']}}</span>
                    </div>
                    <label>{{comment.createdOn | formatDateTime }}</label>
                  </div>
                </div>
              
              </div>
            </VuePerfectScrollbar>
          </div>
        </div>
      </div>



      
    </div>

    <modal 
     
      name="newNoteModal" 
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="600px"
      height="auto">
    <div class="v-modal" @click="taggedUserchText=''">
       
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">  {{editTicket?'Edit Note':'Create Note'}}</h2>
          <span @click="$modal.hide('newNoteModal');">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form @submit.prevent>
        <div class="form-container">
          <div class="vx-row">
        
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Title<em>*</em></label>
                <vs-input
                  v-model="newNote.title"
                  name="title"
                  v-validate="'required'"
                  class="w-full"
                  data-vv-as="Title"
                />
                <span
                  class="text-danger text-sm"
                  v-show="errors.has('title')"
                  >{{ errors.first("title") }}</span
                >
              </div>
            </div>
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Description<em>*</em></label>
                <!-- <vs-textarea
                  class="w-full"
                  v-model="newNote.description"
                  v-validate="'required'"
                   data-vv-as="Description"
                  name="description"
                /> -->
                <ckeditor  class="w-full"
                  v-model="newNote.description"
                  v-validate="'required'"
                   data-vv-as="Description"
                  name="description" :editor="editor" :config="editorConfig"></ckeditor>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('description')"
                  >{{ errors.first("description") }}</span
                >
              </div>
            </div>

           
           </div>
           <!--
           <div class="vx-row">
            <div class="vx-col w-100" :class="{'w-50':checkProperty(newNote ,'accessLevelId' ,'id')==3,'w-100':checkProperty(newNote ,'accessLevelId' ,'id')!=3}"  >
              <div class="form_group">
                <label class="form_label">Access Level<em>*</em></label>
                  <div class="con-select w-full">
                 
                    <multiselect
                       name="accessLevelId"
                      v-model="newNote.accessLevelId"
                      :options="accessLevelList"
                      :multiple="false"
                      :close-on-select="true"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Access Level"
                      label="name"
                      track-by="id"
                      :preselect-first="false"
                       data-vv-as="Access Level"
                      v-validate="'required'"
                       :disabled="[4,5].indexOf(checkProperty(this.newNote ,'statusId'))>-1"
                    
                    > 
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Tenant(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                
                    <span   class="text-danger text-sm" v-show="errors.has('accessLevelId')"  >{{ errors.first("accessLevelId") }}</span
                >
                  </div>
              </div>
            </div>
            
          </div>
          -->
          <div class="vx-row">
             <div class="vx-col w-full">
                <div class="access_section">
                  <label class="form_label">Access Level</label>
                  <ul class="custom-radio">
                  <template v-for="(lavel ,index) in accessLevelList">

                      <li :key="index" @click="changedAccessLavel()">
                        <vs-radio v-model="newNote.accessLevelId" vs-name="radios1" :vs-value="lavel">{{lavel.name}}</vs-radio>
                      </li>
                  
                  </template>
                    
                  </ul>
                  
                  <template v-if="checkProperty(newNote ,'accessLevelId' ,'id')==3">
                    <div class="form_group mt-4">
                    
                    <div class="w-full con-select">
                     <label class="typo__label">Tagged To<em>*</em></label>
                      <multiselect
                        name="noteUserTo"
                        v-model="newNote.taggedTo"
                        :options="taggedUsersList"
                        :multiple="true"
                        :hideSelected="true"
                        :close-on-select="false"
                        :clear-on-select="false"
                        :preserve-search="true"
                        placeholder="Tagged To"
                        label="name"
                        track-by="name"
                        :preselect-first="false"
                        v-validate="'required'"
                      >
                        <template
                          slot="selection"
                          slot-scope="{ values, isOpen }"
                        >
                          <span
                            class="multiselect__selectcustom"
                            v-if="values.length && !isOpen"
                            >Selected {{ values.length }} User(s)</span
                          >
                          <span
                            class="multiselect__selectcustom"
                            v-if="values.length && isOpen"
                          ></span>
                        </template>
                      </multiselect>
                    </div>  
                     <span class="text-danger text-sm" 
                    v-show="errors.has('noteUserTo')" >
                    <em>*</em> Tagged To is required
                    </span>                 
                  </div>                  
                  </template>
                </div>
              </div>
          </div>
           <div class="vx-col w-full" @click="value = []">
               <div class="form_group file_group">
                  <div class="vs-component marb10">  
                    <label class="form_label">Documents</label>   
                    <file-upload v-model="value" class="file-upload-input upload_file justify-center" 
                     :accept="allDocEntity"
                :name="'Documents'" :multiple="true" :hideSelected="true" 
                    @input="upload(value)">
                        <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                        Upload 
                    </file-upload>
                     <span v-if="uploading" class="loader"><img src="@/assets/images/main/loader.gif"></span>   
                  </div>
               
             
              <ul class="uploaded-list">
                <template v-for="(item, index) in newNote.documents">
                  <vs-chip
                    @click="remove(item, newNote.documents, index)"
                    :key="index"
                    closable
                   
                  >
                
                    {{ item.name }}
                  </vs-chip>
                </template>
              </ul>
            </div>
            </div>

          <div
            class="text-danger text-sm formerrors"
            v-show="formerrors.msg"
            @click="formerrors.msg = ''"
          >
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ formerrors.msg }}</vs-alert
            >
          </div>
        </div>
        <div class="popup-footer">
          <vs-button
           
            color="dark"
            @click="
              AddNewNote = false;
              editTicket=false;
              resetNewNote();
              
            "
            class="cancel"
            type="filled"
            >Cancel</vs-button
          >
             
             

             <vs-button
              :disabled="creatingNewNote"
             v-if="editTicket"
            color="success"
            class="save"
            @click="noteUpdate()"
            type="filled"
            >Update</vs-button
          >
             
          <vs-button
           :disabled="creatingNewNote"
             v-else
            color="success"
            class="save"
            @click="newNoteCreate()"
            type="filled"
            >Save</vs-button
          >
        </div>
      </form>
        
    
    </div>
    </modal>   

    <vs-popup
      class="holamundo main-popup taggedlistmodal"
      :title="'Tagged Members'"
      v-if="Taggedmodal"
      :active.sync="Taggedmodal"
    >
       <div class="taggedlist">
         <ul>
            <li>
              <figure><img src="@/assets/images/main/profile-image.png"></figure>
              <figcaption>Peter Hawkins<span>Paralegal</span></figcaption>
              <em  class="remove"><img src="@/assets/images/main/delete-row-img.svg"></em>
            </li>
            <li>
              <figure><img src="@/assets/images/main/profile-image.png"></figure>
              <figcaption>Peter Hawkins<span>Paralegal</span></figcaption>
              <em  class="remove"><img src="@/assets/images/main/delete-row-img.svg"></em>
            </li>
            <li>
              <figure><img src="@/assets/images/main/profile-image.png"></figure>
              <figcaption>Peter Hawkins<span>Paralegal</span></figcaption>
              <em class="remove"><img src="@/assets/images/main/delete-row-img.svg"></em>
            </li>
          </ul>
       </div>
    </vs-popup>
    <!----- updateStatusPopup :false,
    nweStatus:{

        "noteId": '',
		"statusId": '',
		"statusName": "",
		"comment": "" 

     }-->

     <vs-popup
      class="holamundo main-popup"
      title="Update Status"
      v-if="updateStatusPopup"
      :active.sync="updateStatusPopup"
    >
      <form>
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-100"   >
              <div class="form_group">
                <label class="form_label">Status<em>*</em></label>
                  <div class="con-select w-full">
                 
                    <multiselect
                       name="Status"
                      v-model="nweStatus.statusId"
                      :options="tempStatusids"
                      :multiple="false"
                      :close-on-select="true"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Ticket Type"
                      label="name"
                      track-by="id"
                      :preselect-first="false"
                       data-vv-as="Note Status"
                      v-validate="'required'"
                       
                    
                    > 
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Status(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                
                    <span   class="text-danger text-sm" v-show="errors.has('Status')"  >{{ errors.first("Status") }}</span
                >
                  </div>
              </div>
            </div>
            
          </div>
          <div class="vx-row">
           
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Comment<em>*</em></label>
                <!-- <vs-textarea
                  class="w-full"
                  v-model="nweStatus.comment"
                  v-validate="'required'"
                   data-vv-as="Description"
                  name="description"
                /> -->
                <ckeditor class="w-full"
                  v-model="nweStatus.comment"
                  v-validate="'required'"
                   data-vv-as="Description"
                  name="description"  :editor="editor" :config="editorConfig"></ckeditor>
                <span
                  class="text-danger text-sm"
                  v-show="errors.has('description')"
                  >{{ errors.first("description") }}</span
                >
              </div>
            </div>

            
          </div>

          <div
            class="text-danger text-sm formerrors"
            v-show="formerrors.msg"
            @click="formerrors.msg = ''"
          >
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ formerrors.msg }}</vs-alert
            >
          </div>
        </div>
        <div class="popup-footer">
          <vs-button
           
            color="dark"
            @click="
            updateStatusPopup=false,
              AddNewNote = false;
              editTicket=false;
             
            "
            class="cancel"
            type="filled"
            >Cancel</vs-button
          >
             
             

            
             
          <vs-button
           :disabled="creatingNewNote"
            
            color="success"
            class="save"
            @click=" updateNoteStatus()"
            type="filled"
            >Save</vs-button
          >
        </div>
      </form>
    </vs-popup>

    <vs-popup class="document_modal" :title="checkProperty(selectedFile,'name')" :active.sync="docPrivew">
      <h2></h2>
      <div class="">
        <img
          :class="{
            pdf_view_download: docType == 'pdf',
            office_view_download: docType == 'office',
            image_view_download: docType == 'image',
          }"
          class="download-button"
          @click="downloads3file(selectedFile)"
          src="@/assets/images/download.svg"
        />
        <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
        <template v-if="docType == 'office'">
          <VueDocPreview :value="docValue" type="office" />
        </template>
        <template v-else-if="docType == 'image'">
          <img :src="docValue" />
        </template>
        <template v-else-if="docType == 'pdf'">
          <div class="pdf">
            <object
              :data="docValue"
              type="application/pdf"
              width="1000"
              height="600"
              v-if="docPrivew"
            >
              alt : <a :href="docValue">PDF</a>
            </object>
          </div>
        </template>
      </div>
    </vs-popup>

    
  </div>
</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
import Paginate from "vuejs-paginate";
import Datepicker from "vuejs-datepicker-inv";
import Multiselect from "vue-multiselect-inv";
import JQuery from "jquery";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import VueDocPreview from "vue-doc-preview";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import FileUpload from "vue-upload-component/src";
import moment from "moment";
import _ from "lodash";
import NoDataFound from "@/views/common/noData.vue";
import { MoreVerticalIcon } from 'vue-feather-icons'
import Vue from 'vue'
import VTooltip from 'v-tooltip'
Vue.use(VTooltip);
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
  components: {
    Datepicker, 
    DateRangePicker,
    Multiselect,
    Paginate,
    FileUpload,
    NoDataFound,
    MoreVerticalIcon,
    VuePerfectScrollbar,
    VueDocPreview
  },
  data: () => ({
    category:'',
    editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },

    selectedFile:null,
    docPrivew: false,
    docValue: "",
    docType: "",
    tempTaggedToDetails:[],
     isValid:true,
    taggedUserchText:'',
    creatingNewNote:false,
    isListLoading:false,
    filterTaggedToIds:[],
    filterAccessLevels:[],
    accessLevelList:[],
    uploading:false,
    value: [],
    AddNewNote: false,
    editTicket:false,
    Taggedmodal:false,
    
    newNote: {
      accessLevelId:null,
      priorityId:null,
      title: "",
      description: "",
      documents: [],
      today: moment().format("YYYY-MM-DD"),
    },
    formerrors: {
      msg: "",
    },
    tickets: [],
    sortKeys: {},
    sortKey: {},
    searchtxt: "",
    page: 1,
    perpage: 25,
    commentPage: 1,
    commentPerpage: 25,
    commentCountTotalPages:0,
    totalpages: 0,
    perPeges: [10, 25, 50, 75, 100],
    all_statusids: [],
    tempStatusids:[],
    selected_statusids: [],
    final_selected_statusids: [],
    searchtxt: "",
    filter_searchtxt: "",

    buttoncol: true,
    currentuserRole: null,
    selected_createdDateRange: ["", ""],
    autoApply: "",
    roleId: 0,
    all_user_roles: [],
    users: [],
    selected_user: null,
    assignmrntPopUp: false,
    selected_role: "",

    ticket_comments: [],
    ticket: null,
    selectedNoteId: "",
    selected_ticket_tindex: null,
    CommentPayload: {
      ticketId: "",
      statusId: "",
      description: "",
      documents: [],
      today: moment().format("YYYY-MM-DD"),
     
    },
     taggedUsersList:[] ,
     updateStatusPopup :false,
    nweStatus:{

        "noteId": '',
		"statusId": '',
		"statusName": "",
		"comment": "" 

     },
     comments:[]
  }),
  watch: {
    searchtxt: function (value) {
      this.getNotes();
    },
     AddNewNote: function (value) {
     if(value){
       this.$modal.show('newNoteModal');
     }else{
       this.$modal.hide('newNoteModal');
     }
    },
  },
  methods: {
    goToCaseDetails(note){
     // this.$router.push({ name: 'gc-employment-details', params: { itemId: response._id } }).catch(err => { })
     //this.$router.push({ name: 'petition-details', params: { itemId:Id } ,query: {'filter':this.encodedString} }).catch(err => {})
     let filter ='';
    if (this.checkProperty(this.$router.currentRoute ,"query"  ,"filter") ){
       filter = this.$router.currentRoute['query']['filter'];
       
     }
     if(this.checkProperty(note ,'petitionDetails' ,'_id') ){
      if('external-case'==this.category){
        //alert();
        this.$router.push({ path: `/external-case-details/${note['petitionDetails']['_id']}` ,query: {'filter':filter} })

      }else{
        if(this.checkProperty(note ,'petitionDetails' ,'subType') ==15){
          this.$router.push({ name: 'gc-employment-details', params: {'tabname':'notes', itemId: note['petitionDetails']['_id'] },query: {"filter":filter }   }).catch(err => { })
        }
        if(this.checkProperty(note ,'petitionDetails' ,'subType') !=15){
          this.$router.push({ name: 'petition-details', params: { 'tabname':'notes', itemId:note['petitionDetails']['_id'] } ,query: {"filter":filter} }).catch(err => {})
        }
      }

     }
    },
    download_or_view(value) {
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }

      this.selectedFile = value;
      this.docValue = "";
      this.docPrivew = false;
      this.docType = false;
      this.docType = this.findmsDoctype(value);

      if (this.docType == "office" || this.docType == "image") {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
        };
        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;

          if (this.docType == "office") {
            this.docValue = encodeURIComponent(response.data.result.data);
          }
          this.docPrivew = true;
        });
      } else {
        this.downloads3file(value);
      }
    },
     scroll(e) {
    
      const { target } = e;
      if (
        Math.ceil(target.scrollTop) >=
        target.scrollHeight - target.offsetHeight
      ) {
        //this.getComments();
        //this code will run when the user scrolls to the bottom of this div so
        //you could do an api call here to implement lazy loading
        //this.countTotalPages

        if (this.commentPage < this.commentCountTotalPages) {
          this.commentPage = this.commentPage + 1;
          this.getComments();
        }
      }
    },
    getCalssName(statusName=''){

      return "note-"+statusName.toLowerCase();
    },

     changedAccessLavel(){
      if(this.checkProperty(this.newNote ,'accessLevelId' ,'id') !=3){
       
          this.newNote.taggedTo =[];

      }
      if(this.checkProperty(this.newNote ,'accessLevelId' ,'id') ==3){
         this.newNote.taggedTo = this.tempTaggedToDetails
      }
      this.$validator.reset();
    
      },
    removeUser(user){

      this.newNote.taggedTo = _.filter( this.newNote.taggedTo ,(item)=>{
          return item['_id'] !=user['_id']
      });
      this.taggedUsersList = this.taggedUsersList ;

    },
    selectUser(user){
      // this.newNote.taggedTo
      if(!this.checkUserIsselected(user['_id'] ,this.newNote.taggedTo)){

        this.newNote.taggedTo.push(user);
      }
    },
   
    checkUserIsselected(userId=null ,object){
      let isSelectedUser = _.find(object  ,{"_id":userId} );
      if(isSelectedUser){
        return true
      }else{
        return false;
      }
      
    },
    editMe(){
      this.tempTaggedToDetails =[];
      let self = this;
      this.AddNewNote =true;
      this.editTicket =true;
       this.$modal.show('newNoteModal');
       this.isValid =true;
       let ticket = _.cloneDeep(this.ticket);
          this.newNote = {
            statusId: this.checkProperty(ticket ,'statusId'), 
            noteId:this.selectedNoteId,
            taggedTo:this.checkProperty(ticket ,'taggedToDetails'),
            accessLevelId: this.checkProperty(ticket ,'accessLevelDetails') ,
            title:  ticket['title'],
            description: ticket['description'],
            documents: ticket['documents']?ticket['documents']:[],
            today: moment().format("YYYY-MM-DD"),
          };

          // accessLevelList newNote.accessLevelId
      
          if(self.checkProperty(self.newNote.accessLevelId  ,"id") ){
              self.newNote.accessLevelId = _.find(self.accessLevelList ,{'id':self.newNote.accessLevelId['id'] });


          }
          self.tempTaggedToDetails = _.cloneDeep(self.checkProperty(self.newNote ,'taggedTo'));
    },       // /notes/get-tagged-users
    gettaggedUsersList(){
      let self =this;
      let postData = {
       
          filters: {
          title:self.taggedUserchText
      
        },
        page:1,
        perpage: 1000,
        category: 'priority',
       
      }

      let url ="/notes/get-tagged-users";
      if(this.checkProperty(this.ticket ,'petitionDetails' ,'_id'   )){

        postData = Object.assign(postData ,{petitionId:''} )
        postData['petitionId'] = this.ticket.petitionDetails['_id']

        url ="/petition/assigned-user-list"; 
        if([3].indexOf(this.checkProperty(this.ticket ,'petitionDetails','type' )) >-1 &&  [15].indexOf(this.checkProperty(this.ticket ,'petitionDetails','subType' )) >-1){
        url = "/perm/assigned-user-list"; 
        }


      }
      if(this.checkProperty(this.$route ,'query' ,'filter')){
        let filter =this.$route['query']['filter'];
        let actualFilter = JSON.parse(atob(filter));
        if(_.has(actualFilter,'category') && this.checkProperty(actualFilter,'category') == 'external-case'){
          postData = {};
          postData['petitionId'] = this.ticket.petitionDetails['_id'];
          url ="/notes/assigned-user-list";
        }
      }

     
       this.taggedUsersList =[];
      this.$store.dispatch("getList" ,{ "data":postData,"path":url})
      .then((response) => {

      if(_.has(postData ,'petitionId')){
        this.taggedUsersList = response['list'];
      }else{
        this.taggedUsersList = response;
      }
         
          
          _.forEach(this.taggedUsersList ,(item) => {
              if(_.has(item,"roleName")){
                    item['name'] =  item['name']+" ("+ item['roleName']+")"
              }
              //
          })
        });

    },
    
   
     upload(model ,type = "") {

            var _current = this;
           // this.$vs.loading();
           
            let efiles = [];
            efiles = _.filter(model, (e) => { return (e.url !=null && e.url !='') });
            let nfiles = _.filter(model, (e) => { return (e.url ==null || e.url ==undefined )});

            let mapper = nfiles.map(
                (item) =>
                (item = {
                    name: item.name,
                    file: item.file ? item.file : null,
                    url: item.url ? item.url : "",
                    path: item.path ? item.path : "",
                    status: item.status === false || item.status === true ?
                        item.status : true,
                    mimetype: item.type ? item.type : item.mimetype,
                    type:item.type ? item.type : item.mimetype,
                })
            );
            let tempFiles =[];
            if (mapper.length > 0) {
              this.uploading =true;
                let count=0;
                mapper.forEach((doc, index) => {
                   let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    formData.append("getDetails", true);
                    count++
                   
                    this.$store.dispatch("uploadS3File", formData).then((response) => {
                        response.data.result.forEach((urlGenerated) => {
                             
                              //  this.CommentPayload.documents.push(urlGenerated)
                                if( _.has(urlGenerated ,'name') && tempFiles.indexOf(urlGenerated['name']) <=-1){
                                  tempFiles.push(urlGenerated['name']);    
                                  this.newNote.documents.push(urlGenerated);
                                }
                             doc['mimetype']  =   urlGenerated['mimetype']
                             doc['type']  =   urlGenerated['mimetype']
                            doc.url = urlGenerated;
                            doc.path = urlGenerated;
                            delete doc.file;
                            mapper[index] = doc;
                        });
                    if (index >= mapper.length - 1) {
                      this.uploading =false;
                       // _current.$vs.loading.close();
                    }
                    });
                
                });
               if(efiles.length > 0) efiles.push(...mapper)
                //this.CommentPayload["documents"] = efiles
              
            }
        },
    remove(item, data, filindex) {
      data.splice(filindex, 1);
    },
    get_statusids() {
      this.$store
        .dispatch("getmasterdata", "notes_status")
        .then((response) => {
          
          this.all_statusids = response;
          this.tempStatusids =response;
        });
    },
    getNotes() {
      //  "title": "INTK-TK",
      //             "statusIds": [1, 2, 4],
      //             "assignedToIds": ["5de4a68f3f265070080ad945"],
      //             "createdByIds": ["5de4f0957573e61e381688ea"],

      let obj = {
        filters: {
          title: this.searchtxt,
          statusIds: this.final_selected_statusids,
          taggedToIds:[],
          accessLevelIds: [],
          createdByIds: [],
          dateRange: [],
        },
        page: this.page,
        perpage: this.perpage,
        sorting: this.sortKey,
      };

      if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        obj["filters"]["dateRange"] = [
          this.selected_createdDateRange["startDate"],
          this.selected_createdDateRange["endDate"],
        ];
      }

     obj['filters']['taggedToIds']= this.filterTaggedToIds.map((item)=>{ return item['_id'] });
     obj['filters']['accessLevelIds']= this.filterAccessLevels.map((item)=>{ return item['id'] });
     
      this.isListLoading =true;
      
      this.updateLoading(true);
      //this.$store .dispatch("supportTicketsList", obj)
      this.$store.dispatch("getList" ,{ "data":obj,"path":"/notes/list"})
        .then((response) => {
            this.isListLoading =false;
            this.updateLoading(false);
          let data = response.list;
         
          let temp_list = [];
          _.forEach(data, (obj) => {
            obj["is_expend"] = false;
            obj["all_comments"] = [];
            obj["newComment"] =  { "ticketId": "", "statusId": "", "description": "", "documents": [], "today": moment().format("YYYY-MM-DD") }
            temp_list.push(obj);
          });
          this.tickets = temp_list;
          this.totalpages = Math.ceil(response.totalCount / this.perpage);
           setTimeout(() =>{
                this.updateLoading(false);

           },10)
        })
        .catch((err) => {
              this.tickets = [];
           this.isListLoading =false;
           
          //alert(err);
         
           setTimeout(() =>{
                this.updateLoading(false);

           },10)
          
        });
    },
    sortMe(sort_key = "") {
      if (sort_key != "") {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
        localStorage.setItem("tickets_sort_key", sort_key);
        localStorage.setItem("tickets_sort_value", this.sortKey[sort_key]);

        this.sortKey ={"path":sort_key ,"order":parseInt(this.sortKeys[sort_key])};
        this.getNotes();
      }
    },
    changeperPage() {
      this.page = 1;
      localStorage.setItem("petitions_perpage", this.perpage);
      this.getNotes();
    },
    resetNewNote() {
     
      this.creatingNewNote =false;
       this.uploading =false;
      this.formerrors.msg ='';
       this.editTicket=false,
      this.AddBeneficiary = false;
      this.newNote = {
        ticketType:null,
        taggedTo:[],
        title: "",
        description: "",
        documents: [],
        today: moment().format("YYYY-MM-DD"),
      };
    },
    newNoteCreate() {
      Object.assign(this.formerrors, {
                  msg: '',
                });
         this.$validator.validateAll().then(result => {

          
        
        if (result) {
           let postData = _.cloneDeep(this.newNote);
          postData = Object.assign(postData,{ accessLevelId:this.newNote['accessLevelId']['id']})
          if(this.checkProperty(postData , 'accessLevelId') ==3 && postData['taggedTo'].length>0){

                postData['taggedTo'] = postData['taggedTo'].map((item)=>item['_id'])
          }else{
               postData['taggedTo'] =[];
          }
       
               this.creatingNewNote  = true;
                this.$store.dispatch("commonAction", {"data":postData ,"path":"notes/create"})
                  .then((response) => {
                    this.creatingNewNote  = false;
                    this.AddNewNote = false;
                      this.editTicket =false;
                      this.showToster({message:response.message,isError:false });
                    
                    this.getNotes();
                  })
                  .catch((err) => {
                    this.creatingNewNote  = false;
                    this.formerrors.msg = err;
                    
                  });
          }
         });
    },
    noteUpdate() {
       ///notes/update
          this.$validator.validateAll().then(result => {
           

            if(this.checkProperty(this.newNote , 'accessLevelId' ,'id') ==3){
             if( this.newNote['taggedTo'].length<=0){
               this.isValid =false;
               result =false

             } }

            if(result){


              let postData = _.cloneDeep(this.newNote);
          postData = Object.assign(postData,{ accessLevelId:this.newNote['accessLevelId']['id']})
          if(this.checkProperty(postData , 'accessLevelId') ==3 && postData['taggedTo'].length>0){

                postData['taggedTo'] = postData['taggedTo'].map((item)=>item['_id'])
          }
          postData['categoryId'] = this.checkProperty(this.ticket ,'categoryId');
          
       this.creatingNewNote =true;
       this.$store.dispatch("commonAction", {"data":postData ,"path":"notes/update"})
        .then((response) => {
           this.creatingNewNote =false;
          this.AddNewNote = false;
          this.editTicket =false;
          this.showToster({message:response.message,isError:false });
          this.loadTicket();
          this.getComments();
        })
        .catch((err) => {
           this.creatingNewNote =false;
          //alert(JSON.stringify(err));
          this.formerrors.msg = err;
          
        });
            }   
             
             
             
             
             })

        
    
     
    },

   
    reloadTicket(id, tindex) {
    
      this.selectedNoteId = id;
      this.$router.push("/note-details/"+this.selectedNoteId);
    },

    loadTicket() {
      this.uploading =false;
      let self =this;
      this.resetNewNote();
      
      this.loaded = false;
      //this.$store.dispatch("supportTickesDetails", { ticketId: this.selectedNoteId })
      let postData = {"noteId":self.selectedNoteId}
      if(this.checkProperty(this.$route ,'query' ,'filter')){
        let filter =this.$route['query']['filter'];
        let actualFilter = JSON.parse(atob(filter));
        if(_.has(actualFilter,'category') && this.checkProperty(actualFilter,'category') == 'external-case'){
          postData = Object.assign(postData ,{ getExternalNotes:true});
        }
      }
      this.$store.dispatch("commonAction", {"data":postData ,"path":"notes/details"})
        .then((response) => {
         this.ticket = response;
        // this.editTicket =true;

          this.AddBeneficiary = false;
          this.nweStatus.statusId =this.checkProperty(this.ticket ,'statusDetails');
         this.openUpdateStatusPopup();
         this.gettaggedUsersList();

         
        });
    },

openUpdateStatusPopup(){
   let self = this;
   // this.updateStatusPopup =true;
    this.nweStatus = {

        "noteId": self.selectedNoteId,
		"statusId": '',
		"statusName": "",
		"comment": "" 

     };
     this.$validator.reset();
     this.tempStatusids = this.all_statusids;

     //remove create status from tempStatusids;
    //  this.tempStatusids = _.filter(this.all_statusids ,(item)=>{

    //      return item.id !=1

    //  })
     if([4,5].indexOf(self.ticket['statusDetails']['id'])>-1 ){
      // this.tempStatusids =[];
     }

     let currentStatus = _.find(this.all_statusids ,{"id":self.ticket['statusDetails']['id']});
     this.nweStatus['statusId'] = currentStatus;

     this.$validator.reset('commentForm');
      this.$validator.reset();

},
 updateNoteStatus() {
       ///notes/update
    
         
      this.$validator.validateAll('commentForm').then((result)=>{
       
          if(result){
              let postData =_.cloneDeep(this.nweStatus)
         postData['statusId'] = this.nweStatus['statusId']['id']
         postData['statusName'] = this.nweStatus['statusId']['name']
         
        this.creatingNewNote =true;
        this.$store.dispatch("commonAction", {"data":postData ,"path":"notes/update-status"})
            .then((response) => {
                this.updateStatusPopup =false;
            this.creatingNewNote =false;
            this.AddNewNote = false;
            this.editTicket =false;
            this.showToster({message:response.message,isError:false });
            this.getComments();
            this.loadTicket();
            this.openUpdateStatusPopup();
             this.$validator.reset();
             
            })
            .catch((err) => {
            this.creatingNewNote =false;
            //alert(JSON.stringify(err));
            this.formerrors.msg = err;
            
            });

          }

      })




    },
    
    
  getComments(){
    let self =this;
      this.comments = [];
      //this.$store.dispatch("supportTickesDetails", { ticketId: this.selectedNoteId })
      let postData = {"noteId":self.selectedNoteId}
      this.$store.dispatch("commonAction", {"data":postData ,"path":"notes/comment-list"})
        .then((response) => {
         this.comments = response;
      
         
        });

  }
    

    
  },

  mounted() {
    if(this.checkProperty(this.$route ,'query' ,'filter')){
                    try{
                      let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                      var actual = JSON.parse(atob(filter));
                      let keys = Object.keys(actual);
                      
                      if(this.checkProperty(keys ,'length') >0){

                        if(actual && (Object.keys(actual)).length>0 ){
                        _.forEach(actual ,(item ,key) => {
                          
                          if(key='category'){
                             this.category = item;
                          }
                        })
                      }
                    }
                  }catch(err){

                  }
                }
    
    this.$store.dispatch("getmasterdata", "user_roles").then((response) => {
      this.all_user_roles = response;
    });
    this.accessLevelList = [{
    "_id" : "623ac50283c322166c6bdba4",
    "id" : 1,
    "name" : "Confidential",
    "tenantId" : null,
    "__v" : 0
},
{
    "_id" : "623ac50283c322166c6bdba5",
    "id" : 2,
    "name" : "Public",
    "tenantId" : null,
    "__v" : 0
},{
    "_id" : "623ac50283c322166c6bdba6",
    "id" : 3,
    "name" : "Custom",
    "tenantId" : null,
    "__v" : 0
} 


   ]
    this.$store.dispatch("getmasterdata", "notes_access_level").then((response) => {
     this.accessLevelList = response;
      
    });
    

    this.get_statusids();
    this.username = this.$store.state.user.name;
    this.roleId = this.$store.state.user["roleId"][0];
    this.currentuserRole = this.$store.state.user.loginRoleId;
   if (this.$route.params && this.$route.params.itemId) {
      this.selectedNoteId = this.$route.params.itemId;
   }
   this.loadTicket();
   
   this.getComments();
   
  
  },
};
</script>
