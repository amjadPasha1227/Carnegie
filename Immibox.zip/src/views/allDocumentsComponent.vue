<template>
    <div>


    
        <div class="forms_accordian forms_accordian-v2 hidedropdown marb10" >
            <div>
                <vs-list-item class="cards-list-heading"> 
                    <h2 v-if="callFromCaseDocs" >{{ docsLabel | formatdoctype }}</h2>
                    <h2 v-else >{{ docsLabel }}</h2>

                   
                    <div class="d-flex" v-if="!callFromCaseDocs ">
                        <label v-if=" !USCISDownLoads && checkNoNotifyUserIds && docUserType != 'Downloads'" class="download-all mr-3" @click="openUploadPopup();uploadMainDocuments=[];uploadOriginalDocument=[]">
                            Upload
                            <img src="@/assets/images/main/upload.svg" />
                        </label>
                        <label v-if="documentsList && false" class="download-all" @click="openDownloadPopup()">
                            Download
                            <img src="@/assets/images/main/download.svg" />
                        </label>
                    </div>
                </vs-list-item>
            </div>
            <vs-collapse accordion class="forms-letters-accordian">
                <template v-for="(item, indell) in documentsList" >
                   
                    <template v-for="(forms, indexxx) in item" v-if="item && checkProperty(item,'length')>0">
                        <div class="no-accordian" :key="indexxx" v-if="checkProperty(forms,'path')">
                            
                            <vs-collapse-item>
                                <div slot="header" class="ss">
                                    <vs-list-item class="documents_accordian">
                                    </vs-list-item>
                                </div>
                                <template>
                                    <div class="list_title">
                                        <div class="documents_accordian_tile">
                                            <docType :item="forms" />
                                            <span
                                            @click="fetchSignedUrl(forms);"
                                            ><em class="fl_scanned_docs" :title="forms.name">{{ forms.name }}</em><small>{{getformated(forms)}}</small></span>
                                        </div>
                                        <div class="d-flex align-center">
                                            <div class="vertical-menu">
                                                <span class="menu-icon">
                                                    <i class="material-icons">more_vert</i>
                                                </span>
                                                <ul>
                                                    <!-- <li v-if="checkNoNotifyUserIds" @click="selDoc(forms.mainParentId, forms)">
                                                        Upload
                                                    </li> -->
                                                    <li @click="fetchSignedUrl(forms, false, true)">
                                                        View
                                                    </li>
                                                    <li @click="downloads3file(forms)">
                                                        Download
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </template>
                            </vs-collapse-item>
                        </div>
                    </template>
                </template>
               
                <NoDataFound :loading="false" ref="NoDataFoundRef"  v-if="checkValue({'dataVal':documentsList})" content=""  heading="No Documents Found." type='documents' />
            </vs-collapse>
        </div>
        <template v-if="false">
        <modal
            :name="'fileuploadComPopup'+docUserType"
            classes="v-modal-sec"
            :min-width="200"
            :min-height="200"
            :scrollable="true"
            :reset="true"
            width="600px"
            height="auto"
            >
            <div class="v-modal">
                <div class="popup-header fromDetailsPage">
                <h2 class="popup-title">Upload Documents</h2>
                <span @click="$modal.hide('fileuploadComPopup'+docUserType)">
                    <em class="material-icons">close</em>
                </span>
                </div>
                <form  @submit.prevent >
                    <div class="form-container">
                        <div class="vx-row">
                            <div class="vx-col w-full">
                                <div class="uploadsec_wrap ff">
                                    <div class="w-full">
                                        <div  @click="uploadMainDocuments=[]">
                                            <file-upload v-model="uploadMainDocuments"
                                            :accept="allDocEntity" 
                                            class="file-upload-input mb-0" style="height:50px; padding:0px;" :name="'documents'+docUserType" :multiple="true" :hideSelected="true" v-validate="'required'" label="Scanned Documents" data-vv-as="Scanned Documents"  @input="uploadToS3MainDocuments(0,uploadMainDocuments)">
                                                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                                Upload
                                            </file-upload>
                                            <span class="file-type mb-0">(File Type: PDF, DOC. Max file size: 1MB)</span>
                                            <!-- <span class="text-danger text-sm" v-show="errors.has('pdocuments')">{{ errors.first('documents'+index) }}</span> -->
                                        </div>
                                        <VuePerfectScrollbar class="scrollbardoc">
                                            <div class="uploded-files_wrap mt-3" >
                                                <div class="w-full" v-for="(fil, fileindex) in uploadOriginalDocument" :key="fileindex">
                                                
                                                    <div class="uploded-files">
                                                        <vx-input-group class="form-input-group">
                                                            <vs-input v-on:keyup="filameChenged(fileindex)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="fil['name']" data-vv-as="File Name" />
                                                            <span class="text-danger text-sm" v-show="errors.has('fName'+fileindex)">{{ errors.first('fName'+fileindex) }}</span>

                                                            <div class="delete" style="z-index:999" @click="remove(fil, uploadOriginalDocument ,fileindex)">
                                                                <img src="@/assets/images/main/cross.svg" />
                                                            </div>
                                                        </vx-input-group>
                                                    </div>
                                                </div>
                                            </div>
                                        </VuePerfectScrollbar>
                                    </div>
                                </div>
                                <div class="text-danger text-sm formerrors mt-2" v-show="formerrors.msg" @click="formerrors.msg=''">
                                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius mb-0" icon-pack="IntakePortal"
                                    icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="popup-footer relative">
                        <button @click="$modal.hide('fileuploadComPopup'+docUserType); fuploder=false" class="btn cancel">Cancel</button>
                        <button class="btn save"  @click="updateFormsAndDocuments()">
                            <figure v-if="fuploder" class="loader"><img src="@/assets/images/main/loader.gif" /></figure> Submit
                        </button>
                    </div>
                </form>
                </div>
        </modal>
    </template>
       
    </div>
</template>
<script>

import NoDataFound from "@/views/common/noData.vue";
import moment from "moment";
import FileUpload from "vue-upload-component/src";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import docType from "@/views/common/docType.vue";
import { runInThisContext } from "vm";
export default {
    components:{
        FileUpload,
        docType,
        VuePerfectScrollbar,
        NoDataFound,
       // downloadAllCaseDocuments
    },
    data: () => ({
        processedDocs:[],
       
        disable_version_update:false,
        disable_reversion_uploadBtn:false,
        formsAndLettersList:[],
        totalpages:0,
        page:1,
        perpage:25,
        openItem:true,
        downloading:false,
        downloadFiles:false,
        version_documentUploaded: [],
        documentData: [{ type: "Forms, Letters and Others", documentUploaded: [] }],
        disable_revesion_uploadBtn:false,
        version_documrentUploaded:[],
        selectedDoc:null,
        reverseScan_fileuploadPopup:false,
        showPreviousVersions:false,
        previousExisted:false,
        disable_uploadBtn: false,
        fuploder: false,
        uploadOriginalDocument:[],
        uploadMainDocuments:[],
        formerrors:{
            msg:''
        },
        fileuploadComPopup: false,
        parentId:'',formLetterType:'Form',
        documentId: "",
        }),
    props:{
        USCISDownLoads:{
            type: Boolean,
            default: false,
        },
        recentDownLoads:{
            type: Boolean,
            default: false,
        },
        uploadFormsAndLetters:{
            type: Boolean,
            default: false,
        },
        callFromGroupDocs:{
            type: Boolean,
            default: false,
        },
        callFromCaseDocs:{
            type: Boolean,
            default: false,
        },
        documentsList:{
            type: [Object,Array],
            default: [],
        },
        petition: {
            type: Object,
            default: null,
        },
        loadedFromPreview:{
            type: Boolean,
            default: false,
        },
        docUserType:{
            type: String,
            default: '',
        },
        docsLabel:{
            type: String,
            default: '',
        },
        docCategory:{
            type: String,
            default: '',
        },
        childId:{
            type: String,
            default: '',
        },
        depLabel:{
            type: String,
            default: '',

        },
        depType:{
            type: String,
            default: '',

        },
    },
    mounted(){
        this.init()
    },
    methods:{
        openDownloadPopup(){
            this.$emit('openDownloadPopup' ,'');
        },
        remove(item, type) {
            type.splice(type.indexOf(item), 1);
            return false;
        },
        init(){
                this.processedDocs = [];
                let _self =this;
                if(this.documentsList){
                    let catDocuments =Object.entries(this.documentsList);
                    let documentsArray = [];
                    _.forEach(catDocuments,(item)=>{
                        let obj = {}
                        if(item){
                            let category =_.cloneDeep(item[0]);
                            if(item[1].length>0){
                                let documents =_.cloneDeep(item[1]);
                                let filteredDocs =[]
                                _.forEach(documents,(docs)=>{
                                    if(!_.has(docs,'status') || (_.has(docs,'status') && this.checkProperty(docs,'status'))){
                                        Object.assign(docs,{'category':this.docUserType,'saved':false})
                                        filteredDocs.push(docs)
                                    }
                                })
                                if(filteredDocs){
                                    Object.assign(obj,{'category':category,'documents':filteredDocs})
                                }
                            }
                        }
                        if(obj && this.checkProperty(obj,'documents') && this.checkProperty(obj,'documents','length')>0){
                            documentsArray.push(obj)
                        }
                    })
                    if(documentsArray){
                        this.processedDocs  =_.cloneDeep(documentsArray);
                    }
                }
        },
        updateFormsAndDocuments() {
            Object.assign( this.formerrors ,{ msg:''})
            if (this.disable_uploadBtn) {
                return false;
            }
            let postData = {
                petitionId: this.checkProperty(this.petition, '_id'),
                docType:this.docCategory,
                documents:[],
                depLabel:this.depLabel,
                docUserType:this.docUserType
            }

           if(this.uploadOriginalDocument.length>0){

                this.uploadOriginalDocument.forEach((doc)=>{
                    let document = doc.document
                    document = Object.assign(document ,{ name:doc.name});
                    if(this.childId && this.docCategory == 'childrens' ){
                        document = Object.assign(document ,{ 'childId':childId});
                    }
                    postData['documents'].push(document);
                })
            this.fuploder = true;
            this.disable_uploadBtn = true;
            let count = 0;
            this.$store.dispatch("commonAction", { "data": postData,"path":"/petition/upload-case-docs"}).then(response => {  //fileuploadComPopup
                         this.fileuploadComPopup = false;
                         this.$modal.hide('fileuploadComPopup'+this.docUserType)
                         this.showToster({message:response.message ,isError:false })
                         this.fuploder = false;
                         this.disable_uploadBtn = false;
                         this.fileuploadComPopup = false;
                         this.$modal.hide('fileuploadComPopup'+this.docUserType)
                        setTimeout(()=>{                           
                            this.$emit("updatepetition" ,'All Documents');                            
                        } ,100);
                    })
                    .catch((error) => {
                        Object.assign(this.formerrors ,{'msg':error})
                        this.fuploder = false;
                        this.disable_uploadBtn = false;
                    });
       
            }else{
                    Object.assign( this.formerrors ,{ msg:'Upload atleast one document'})

            }
        },

        downloadfile(){
            
        },
        getformated(item) {
          
            if(this.checkProperty(item,'generated') == true || this.checkProperty(item,'generated') == 'true' ){
               
               
                if (item.createdOn) {
                    let msg = "Generated On " + moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a")
                    if(this.recentDownLoads){
                        msg = "Downloaded On " + moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a")
                    }
                    
                    if(item.createdByName){
                       
                        if(this.recentDownLoads){
                            msg=  msg+" - Downloaded By "+item.createdByName
                        }else{
                            msg=  msg+" - Generated By "+item.createdByName
                        }
                    }else if( item.uploadedByName){
                        if(this.recentDownLoads){
                            msg=  msg+" - Downloaded By "+item.uploadedByName
                        }else{
                            msg= msg+" - Generated By "+item.uploadedByName
                        }
                       
                    }
                return msg//( "Uploaded On  " + moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a") +" - Uploaded By " + item.createdByName );
            } else if (item.uploadedOn) {
                let msg = "Generated On   " + moment(item.uploadedOn).format("MMM DD, YYYY hh:mm:ss a")
            
                if(this.recentDownLoads){
                    msg = "Downloaded On " + moment(item.uploadedOn).format("MMM DD, YYYY hh:mm:ss a")
                }
                    if(item.createdByName){
                        if(this.recentDownLoads){
                            msg=  msg+" - Downloaded By "+item.createdByName
                        }else{
                            msg=  msg+" - Generated By "+item.createdByName
                        }
                    }else if( item.uploadedByName){
                        if(this.recentDownLoads){
                            msg=  msg+" - Downloaded By "+item.uploadedByName
                        }else{
                            msg= msg+" - Generated By "+item.uploadedByName
                        }
                    }
                    return msg;
            } else if(item.uploadedByName){
               
               
               return "Uploaded By "+item.uploadedByName
               
            }else {
                return '';
            }

           
            }else{
               
                if (item.createdOn) {
                    let msg = "Uploaded On  " + moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a")
                    if(this.recentDownLoads){
                       msg = "Downloaded On " + moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a")
                   }
                   
                    if(item.createdByName){
                        if(this.recentDownLoads){
                            msg=  msg+" - Downloaded By "+item.createdByName
                        }else{
                            msg=  msg+" - Uploaded By "+item.createdByName
                        }
                    }else if( item.uploadedByName){
                        if(this.recentDownLoads){
                            msg=  msg+" - Downloaded By "+item.uploadedByName
                        }else{
                            msg=  msg+" - Uploaded By "+item.uploadedByName
                        }
                    }
                return msg//( "Uploaded On  " + moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a") +" - Uploaded By " + item.createdByName );
            } else if (item.uploadedOn) {
               let msg = "Uploaded On  " + moment(item.uploadedOn).format("MMM DD, YYYY hh:mm:ss a")

               if(this.recentDownLoads){
                       msg = "Downloaded On " + moment(item.uploadedOn).format("MMM DD, YYYY hh:mm:ss a")
                   }
                //alert(item.createdByName + "item.uploadedByName "+item.uploadedByName)
                    if(item.createdByName){
                        if(this.recentDownLoads){
                            msg=  msg+" - Downloaded By "+item.createdByName
                        }else{
                            msg=  msg+" - Uploaded By "+item.createdByName
                        }
                    }else if( item.uploadedByName){
                        if(this.recentDownLoads){
                            msg=  msg+" - Downloaded By "+item.uploadedByName
                        }else{
                            msg=  msg+" - Uploaded By "+item.uploadedByName
                        }
                    }
                    return msg;
            } else  if(item.uploadedByName){
               
               
               return "Uploaded By "+item.uploadedByName
               
            }else {
                return '';
            }
            }
        },
        openUploadPopup(){
            if(this.uploadFormsAndLetters){
                let data ={"depType":'' ,"docUserType":"" ,"depLabel":'',"docCategory":''};
                data['depType'] = this.depType
                data['depLabel'] = this.depLabel
                data['docUserType'] = this.docUserType
                data['docCategory'] = this.docCategory
                
                 //this.docUserType
                this.$emit('openUploadPopup',data)
            }else{
                this.$emit('openUploadPopup',this.docUserType)
            }
           
            //this.$modal.show('fileuploadComPopup'+this.docUserType)
        },
       
        uploadToS3MainDocuments(index,docs){
            let self = this
             docs = docs.map(
                item =>
                (item = {
                    name: item.name,
                    file: item.file,
                    document: "",
                    path:'',
                    mimetype: item.type
                })
            );
            if (docs.length > 0) {
                let filIndex = 0;
                docs.forEach(doc => {
                  this.fuploder = true;
                this.disable_uploadBtn = true;
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                     formData.append("getDetails", true);
                    // alert(1)
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                         filIndex++;
                         if (filIndex >= self.uploadMainDocuments.length) {
                            self.fuploder = false;
                            self.disable_uploadBtn = false;
                        }
                        response.data.result.forEach(urlGenerated => {
                    
                            doc.document = urlGenerated;
                            doc.path = urlGenerated;
                            //this.uploadMainDocuments.push(doc);
                            self.uploadOriginalDocument.push(doc);
                            
                            self.uploadOriginalDocument = _.cloneDeep(self.uploadOriginalDocument)
                            //alert(JSON.stringify(self.uploadOriginalDocument));
                        });
                       
                    });
                
                    
                });
            }

        },
        doUpload(id, documents, typeId = "") {
            this.documentId = id;

            let formData = new FormData();
            documents = documents.map(
                item =>
                (item = {
                    typeId: typeId,
                    name: item.name,
                    file: item.file,
                    path: "",
                    mimetype: item.type
                })
            );
            this.disable_reversion_uploadBtn = false;
            this.rfuploder = false;
            if (documents.length > 0) {
                this.rfuploder = true;
                this.disable_reversion_uploadBtn = true;
                let findx = 0;
                this.version_documentUploaded.forEach(doc => {
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                     formData.append("getDetails", true);
                    
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                        response.data.result.forEach(urlGenerated => {
                            doc.path = urlGenerated['path'];
                            doc.mimetype =urlGenerated['mimetype'];
                            doc.extn =urlGenerated['extn'];
                            this.reversionFile = doc;
                            this.disable_reversion_uploadBtn = false;
                            this.rfuploder = false;
                        });
                    });
                    findx++;
                });
            }
        }, 
        fetchSignedUrl(value,download = false, viewmode = false) {
          value.download = download;
            value.viewmode = viewmode;
            this.$emit('download_or_view' ,value);
        },
    },
    computed:{
        checkValue(){
            return (data)=>{
              let returnVal = false
                if(data && _.has(data,'dataVal') && this.checkProperty(data,'dataVal') ){
                    let catDocuments =Object.entries(data['dataVal']);
                    if(catDocuments){
                        _.forEach(catDocuments,(item)=>{
                            if(item){
                                let category  =_.cloneDeep(item[0]);
                                if(this.checkProperty(data['dataVal'],category) && this.checkProperty(data['dataVal'],category,'length')>0 ){
                                    returnVal =  false;
                                }else{
                                    returnVal =  true;
                                }
                            }
                        })
                    }

                }else{
                    returnVal =  true;
                }
                if(returnVal){
                    setTimeout(()=>{
                        this.updateLoading(false)
                    },10);
                    
                }
                return returnVal
                
            }

            
        },
        checkNoNotifyUserIds(){
      let returnValue =true;
      if(_.has(this.petition, 'noNotifyUserIds')  ){
        if(this.petition['noNotifyUserIds'].length>0){
          if(this.petition['noNotifyUserIds'].indexOf(this.getUserData['userId']) >-1){
            returnValue = false;
          }

        }

      }
      return returnValue;
    },
    }

}
</script>