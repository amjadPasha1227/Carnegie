<template>
  <div class="added-widgets">
    <div id="heightChange" class="mytask-widgets" :class="{'small' : (selectedHeight == 'small'), 'medium' : (selectedHeight == 'medium'),'large' : (selectedHeight == 'large') }">
  
     <!-- <div class="header">
        <div class="title">
          <h4>My Tasks</h4>
        </div>
        <div class="widget-filters">
          <button class="filter_btn active"><em>To-Do</em><span>2</span></button>
          <button class="filter_btn"><em>Cases</em><span>21</span></button>
          <button class="filter_btn"><em>Tasks</em></button>
          <button class="filter_btn"><em>Updates</em></button>
        </div>
        <div class="actions">
     
          <ul>
            <li><figure><img src="@/assets/images/main/calendar.svg" alt="calendar-img" width="14" height="14" style="opacity: 0.6;"></figure></li>
            <li  @click="popupFilter=true"><figure><img src="@/assets/images/funnel.svg" alt="filter-img" width="14" height="14"></figure></li>
            <li class="has-dropdown"><figure><more-horizontal-icon size="1.5x" class="custom-class" style="opacity: 0.6;"></more-horizontal-icon></figure>
              <div class="height-dropdown">
                
                <ul class="subdropdown">
                  <li><a><figure><img src="@/assets/images/duplication.png" alt="duplicate-img" width="15"></figure>Duplicate</a></li>
                  <li><a class="text-danger"><figure><img src="@/assets/images/delete.png" alt="trash-img" width="15"></figure>Delete</a></li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
      </div>-->
      
      <widgetHeader @reloadWidgetData="getWigetsData" @togleExpend="togleExpend" ref="widgetheader" :viewType="viewType"  @changeViewType="changeViewType"  :selecetedTab="tabName" @changeTab="changeTab" :rowExistingColumnsLength="rowExistingColumnsLength" :availableEmptyColumns="availableEmptyColumns" @deleteColumn="deleteColumn" @duplicateColumn="duplicateColumn" @openAddFilterDialog="openAddFilterDialog" :columnId="columnId" :rowId="rowId" :widgetData="widgetData" />
    
      <VuePerfectScrollbar	
            ref="mainSidebarPs"	
            class="scroll-area--main-sidebar"	
            :settings="settings"	
            @ps-scroll-y="psSectionScroll"	
          >
          
         
          <div class="widget-content">
            <!----CASE_SIGN_STATS-->
            <dashBoardMessagesList v-if="['MESSAGES'].indexOf(checkProperty(widgetData ,'code' ))>-1 && checkProperty(widgetsItems ,'data','length')>0"   :widgetData="widgetData"
                          :lableData="lableData"
                          :templateClass="templateClass"
                          :all_statusids="all_statusids"
                          :itemTemplate="itemTemplate"
                          @reloadWals="wallList"
                          :userRolelist="userRolelist"
                          :tickets="widgetsItems['data']"
                          ref="wallItem"
                          @rloadActionWidjet="rloadActionWidjet"
                          @toggleCalssToRow="toggleCalssToRow" />
            <template v-else-if="['CASE_SIGN_STATS'].indexOf(checkProperty(widgetData ,'code' ))>-1  && checkProperty(widgetsItems ,'length')>0 ">
              
               <caseSignatureStats  :widgetsItems="widgetsItems"  :wallsLoaded="true" :widgetData="widgetData"/>
              </template>
             <template v-else-if="checkProperty(widgetsItems ,'data' ,'length')>0 && !isListLoading">
              <template v-if="['ACTION','UPDATES'].indexOf(checkProperty(widgetData ,'code' ))>-1">
           
              <actionsListItem
                         v-if="true" 
                         :widgetData="widgetData"
                          :lableData="lableData"
                          :templateClass="templateClass"
                          :all_statusids="all_statusids"
                          :itemTemplate="itemTemplate"
                          @reloadWals="wallList"
                          :userRolelist="userRolelist"
                          :list="widgetsItems['data']"
                          ref="wallItem"
                          @rloadActionWidjet="rloadActionWidjet"
                          @toggleCalssToRow="toggleCalssToRow"
                        />
                      


                      <div v-else class="widget-task-list" v-for="(wallItem, ind) in widgetsItems['data']" :key="ind">
   
                          <div class="task-details"  >
                            <!----  <h4>Case Submitted dfsdfdsf</h4>-->
                              <p><a @click="item=wallItem;goToDetaillPage()">{{checkProperty( wallItem ,"title" )}}</a></p> 
                              <div class="discription">
                                <p><a @click="item=wallItem;goToDetaillPage()">{{checkProperty( wallItem ,"description" )}}</a></p>           
                              </div>
                            
                              
                              <div class="documents" v-if="checkProperty( wallItem , 'data','documents')">
                                <template v-for="(fItem, findex) in checkProperty( wallItem , 'data','documents')" >
                                  <span :key="findex" v-tooltip.top-center="checkProperty(fItem ,'name')"   v-on:click.stop.prevent="downloads3file(fItem)"  class="note pointer cursor">
                                    <docType  :item="fItem" />
                                    
                                  </span>
                                </template>
                              </div>
                          </div>
                          <div class="task-status " v-if="checkProperty(wallItem ,'type') =='todo'" >
                                  
                                  <ul>
                                  

                                      <li v-if="(['ASSIGN_CUSTOM_CASE_NO'].indexOf(checkProperty( wallItem ,'data' , 'category'))>-1)" v-on:click.stop.prevent="item=wallItem;fetchPetitionDetails(wallItem,openSetCaseCodePopup ,'openSetCaseCodePopup')"> <button  class="assignCaseNumber_btn" ><span><img src="@/assets/images/icons/actions/assignCaseNumber_btn.svg" /></span><em>Assign Case Number</em></button></li>
                                      <li v-if="(assignmentActivityes.indexOf(checkProperty( wallItem ,'data' , 'category'))>-1)" v-on:click.stop.prevent="item=wallItem;fetchPetitionDetails(wallItem,openPopup ,'openPopup')"> <button  class="assign_btn" ><span><img src="@/assets/images/icons/actions/assign_btn.svg" /></span><em>Assign</em></button></li>
                                      <li :addClas="addClass()" v-if="((checkProperty( wallItem ,'data' , 'category')== 'CASE_APPROVED' && checkProperty( wallItem ,'status')))" v-on:click.stop.prevent="item=wallItem;fetchPetitionDetails(wallItem,openapproveCasePopup ,'openapproveCasePopup')" > <button  class="approveCase_btn" ><span><img src="@/assets/images/icons/actions/approveCase_btn.svg" /></span><em>Approve Case</em></button></li>
                                      <li :addClas="addClass()" v-if="(checkProperty( wallItem ,'data' , 'category')== 'APPROVED_BY_DOC_MANAGER' && checkProperty( wallItem ,'status'))" v-on:click.stop.prevent="item=wallItem;fetchPetitionDetails(wallItem,openApproveOrRejectDocs,'openApproveOrRejectDocs')" > <button  class="approveDocuments_btn"><span><img src="@/assets/images/icons/actions/approveDocuments_btn.svg" /></span><em>Approve Documents</em></button></li>
                                      <li :addClas="addClass()" v-if="( checkProperty( wallItem ,'data' , 'category')== 'REQUEST_PETITIONER_SIGN' && checkProperty( wallItem ,'status'))" v-on:click.stop.prevent="item=wallItem;fetchPetitionDetails(wallItem,showPetitionersign)" ><button  class="sendForSigning_btn" ><span><img src="@/assets/images/icons/actions/sendForSigning_btn.svg" /></span><em>Send for Signing</em></button></li>
                                      <li :addClas="addClass()" v-if="(checkProperty( wallItem ,'data' , 'category')== 'SUBMIT_TO_USCIS' && checkProperty( wallItem ,'status'))" v-on:click.stop.prevent="item=wallItem;item=wallItem;fetchPetitionDetails(wallItem,getscannedCopiesList)"  > <button  class="submitToUSCIS_btn" ><span><img src="@/assets/images/icons/actions/submitToUSCIS_btn.svg" /></span><em>Submit to USCIS</em></button></li>
                                      <li :addClas="addClass()" v-if="((['UPDATE_USCIS_RECEIPT_NUMBER' ,'COURIER_TRACKING'].indexOf(checkProperty( wallItem ,'data' , 'category'))>-1 && checkProperty( wallItem ,'status')))" v-on:click.stop.prevent="item=wallItem;fetchPetitionDetails(wallItem,updateTrackingDetails)" > <button  class="caseFiled_btn" ><span><img src="@/assets/images/icons/actions/caseFiled_btn.svg" /></span><em>Case Filed</em></button></li>
                                      <li :addClas="addClass()" v-if="(['UPDATE_USCIS_RESPONSE'].indexOf(checkProperty( wallItem ,'data' , 'category'))>-1 && checkProperty( wallItem ,'status'))" v-on:click.stop.prevent="item=wallItem;fetchPetitionDetails(wallItem,updateUSCISstatus ,'updateUSCISstatus')"  ><button  class="updateUSCISStatus_btn" ><span><img src="@/assets/images/icons/actions/updateUSCISStatus_btn.svg" /></span><em>Update USCIS Status</em></button></li>





                                      <template v-if="(checkProperty( wallItem ,'data' , 'category')== 'TASK_CREATE' ) && wallItem">
                                        <li :addClas="addClass()" :disabled="accepting" @click="openAcceptForm(true ,'TASK_ACCEPT' ,wallItem) ;error=''" v-if="  (isAssignedUser(wallItem) && (!checkisAccepted(wallItem) && !checkisRejected(wallItem)))" ><button class="accept_btn" ><span><img src="@/assets/images/icons/actions/accept_btn.svg" /></span><em>Accept</em></button></li>
                                        <li :addClas="addClass()" :disabled="accepting" @click="openAcceptForm(true ,'TASK_REJECT' ,wallItem);error=''"  v-if=" (isAssignedUser(wallItem) && (!checkisAccepted(wallItem) && !checkisRejected(wallItem)))" ><button class="reject_btn" ><span><img src="@/assets/images/icons/actions/reject_btn.svg" /></span><em>Reject</em></button></li>
                                      </template>


                                      <template v-if="(checkProperty( wallItem ,'data' , 'category')== 'TENANT_CREATED' && checkProperty( wallItem ,'status'))">

                                      <li  :addClas="addClass()" v-on:click.stop.prevent="item=wallItem;openTenantApprovepopup(2,'Approve')" ><button class="approve_btn"><span><img src="@/assets/images/icons/actions/approve_btn.svg" /></span><em>Approve</em></button></li>
                                      <li :addClas="addClass()" v-on:click.stop.prevent="item=wallItem;openTenantApprovepopup(3,'Reject')" ><button class="reject_btn"><span><img src="@/assets/images/icons/actions/reject_btn.svg" /></span><em>Reject</em></button></li>
                                      </template>
                                      <template v-if="(['COMPANY_CREATED'].indexOf(checkProperty( wallItem ,'data' , 'category'))>-1 && checkProperty( wallItem ,'status'))" >

                                      <template v-if="checkProperty(petitioner , 'statusDetails' , 'id')<=1">

                                          <li :addClas="addClass()" v-on:click.stop.prevent="item=wallItem;openApprovepopup(2,'Approve')"><button class="approve_btn"><span><img src="@/assets/images/icons/actions/approve_btn.svg" /></span><em>Approve</em></button></li>
                                          <li :addClas="addClass()" v-on:click.stop.prevent="item=wallItem;openApprovepopup(3,'Hold')"><button class="hold_btn"><span><img src="@/assets/images/icons/actions/hold_btn.svg" /></span><em>Hold</em></button></li>
                                          <li :addClas="addClass()" v-on:click.stop.prevent="item=wallItem;openApprovepopup(4 ,'Reject')"><button class="reject_btn"><span><img src="@/assets/images/icons/actions/reject_btn.svg" /></span><em>Reject</em></button></li>

                                      </template>

                                      </template>
                                  </ul>
                                            
                              <p  v-if="checkProperty( wallItem,'createdOn')" class="task-timing"> {{ checkProperty( wallItem,'createdOn') | timeago}}</p>
                          </div>
                      </div> 
  
              
              </template>
               
              <!----CHART PENDING_CASE_STATS-->
              <template v-else-if="['PENDING_CASE_STATS'].indexOf(checkProperty(widgetData ,'code' ))>-1">
              <PendingCaseStats  :widgetsItems="widgetsItems"  :wallsLoaded="true" :widgetData="widgetData"/>
              </template>              
              <template v-else-if="['CURRENT_STATUS_OF_CASE'].indexOf(checkProperty(widgetData ,'code' ))>-1">
                 <currentStatusOfCase  :widgetsItems="widgetsItems"  :widgetData="widgetData"/>
              </template>
              <template v-else-if="['CASE_STATS_BY_STATUS'].indexOf(checkProperty(widgetData ,'code' ))>-1">
                 <caseStatsByStatus  :widgetsItems="widgetsItems"  :widgetData="widgetData"/>
              </template>
              
              <!----CHART PENDING_CASE_STATS END-->

              <!-----CHART AND LIST-->

              <template v-else-if="['CASE_BY_STATUS'].indexOf(checkProperty(widgetData ,'code' ))>-1">
                 <caseByStatusItem  :widgetsItems="widgetsItems"  :widgetData="widgetData" :viewType='viewType'/>
              </template>
              <template v-else-if="['INVOICE'].indexOf(checkProperty(widgetData ,'code' ))>-1">
                 <invoiceListItem  :widgetsItems="widgetsItems"  :widgetData="widgetData" :viewType='viewType'/>
              </template>
              <template v-else-if="['LCA'].indexOf(checkProperty(widgetData ,'code' ))>-1">
                 <lcaListItem  :widgetsItems="widgetsItems"  :widgetData="widgetData" :viewType='viewType'/>
              </template>
              <!-----CHART AND LIST END-->

               <template v-else>
               <div class="branch-list"  v-if="checkProperty(casebranchList ,'length') >0 && ['CASE_STATS_BY_BRANCH'].indexOf(checkProperty(widgetData ,'code' ))>-1" >
                 <ul class="tabbuttons">
                  <li  v-for="(br ,brind) in casebranchList"  @click="branchSelected(br['branchId'])" :key="brind"  :class="{'active':selectedBranch==br['branchId']}"
                    
                    >{{checkProperty(br ,'branchName')}}
                    <!----v-on:click.stop.prevent="navigateToDetails(br ,'BRANCH_CASES' ,'branchIds' )" -->
                    
                    </li>
                     
                 </ul>
               </div>
              

                <template v-for="(item ,itmIndex) in widgetsItems['data']" >
                    <div :key="itmIndex">
                  
                  <clientItem  v-if="['CLIENT'].indexOf(checkProperty(widgetData ,'code' ))>-1"  :itemData="item" :widgetData="widgetData" />
                  <beneficiaryItem v-else-if="['BENEFICIARY'].indexOf(checkProperty(widgetData ,'code' ))>-1" :itemData="item" :widgetData="widgetData" />  
                  <supportItem v-else-if="['SUPPORT_TICKET'].indexOf(checkProperty(widgetData ,'code' ))>-1" :itemData="item" :widgetData="widgetData" />  
                  <taskListitem v-else-if="['TASK'].indexOf(checkProperty(widgetData ,'code' ))>-1" :itemData="item" :widgetData="widgetData" />
                  <caseStatsByBranch  v-else-if="['CASE_STATS_BY_BRANCH'].indexOf(checkProperty(widgetData ,'code' ))>-1" :itemData="item" :widgetData="widgetData" />

                  
                   
                    
                    <div v-else class="widget-task-list" >
                      <NoDataFound  ref="NoDataFoundRef"  :loading="false"  heading="No Data"  type="support"  />
                    </div>
                    </div>
                  
                </template>
               
               </template>

                
              </template>
              <template v-else>

               <NoDataFound  ref="NoDataFoundRef"  :loading="isListLoading"  heading="No Data"  type="support"  />
                
              </template>

              <template v-if="false">
              <div class="widget-task-list">
                <!-- <div class="task-thumbnail">
                    <figure><img src="@/assets/images/check-mark.png"></figure>
                </div> -->
                <div class="task-details">
                  <h4>NO ITEM FOUND</h4>
                  <p>for Case #H1B-NECS-2022-10165 of BulBul Apps.</p>
                  <ul>
                    <li>BulBul Apps <span>(Petitioner)</span></li>
                    <li>Thomas V Allen, <span>(Admin)</span></li>
                  </ul>
                </div>
                <div class="task-status">
                  <!-- <a href="#" class="upload-btn">Upload</a> -->
                  <ul>
                    <li>
                      <a href="#" class="user-request-btn"></a>
                    </li>
                    <li>
                      <a href="#" class="approve-btn task">Approve</a>
                      
                    </li>
                  </ul>
                  <p class="task-timing">5 hours ago</p>
                </div>
              </div>
              <div class="widget-task-list">
                <!-- <div class="task-thumbnail">
                    <figure><img src="@/assets/images/check-mark.png"></figure>
                </div> -->
                <div class="task-details">
                  <h4>Questionnaire submitted</h4>
                  <p>for Case #H1B-NECS-2022-10165 by Beneficiary ThomasV Allen.</p>
                  <ul>
                    <li>BulBul Apps <span>(Petitioner)</span></li>
                    <li>Thomas V Allen, <span>(Admin)</span></li>
                  </ul>
                </div>
                <div class="task-status">
                  <p class="task-timing">5 hours ago</p>
                </div>
              </div>
              <div class="widget-task-list">
                <!-- <div class="task-thumbnail">
                    <figure><img src="@/assets/images/check-mark.png"></figure>
                </div> -->
                <div class="task-details">
                  <h4>Questionnaire submitted</h4>
                  <p>for Case #H1B-NECS-2022-10165 by Beneficiary ThomasV Allen.</p>
                  <ul>
                    <li>BulBul Apps <span>(Petitioner)</span></li>
                    <li>Thomas V Allen, <span>(Admin)</span></li>
                  </ul>
                </div>
                <div class="task-status">
                  <p class="task-timing">5 hours ago</p>
                </div>
              </div>
              </template>
      </div>
      </VuePerfectScrollbar>      
    </div>



  </div>
</template>
 
 
<script>
import dashBoardMessagesList from "./dashBoardMessagesList.vue"
 import VuePerfectScrollbar from "vue-perfect-scrollbar";
 import Multiselect from "vue-multiselect-inv";
 import { MoreHorizontalIcon } from 'vue-feather-icons'
 import NoDataFound from "@/views/common/noData.vue";
import widgetHeader from "./widgetHeader.vue";

import caseByStatusItem from "./caseByStatusItem.vue"
import clientItem from "./clientItem.vue"
import beneficiaryItem from "./beneficiaryItem.vue"
import supportItem from "./supportItem.vue"
import taskListitem from "./taskListitem.vue"
import lcaListItem from "./lcaListItem.vue"
import invoiceListItem from "./invoiceListItem.vue"
import actionsListItem from "./actionsListItem.vue";
import caseStatsByBranch from "./caseStatsByBranch.vue";
import PendingCaseStats from "./PendingCaseStats.vue"
import currentStatusOfCase from "./currentStatusOfCase.vue"
import caseSignatureStats from "./caseSignatureStats.vue"
import caseStatsByStatus from "./caseStatsByStatus.vue"



import Datepicker from "vuejs-datepicker-inv";
import FileUpload from "vue-upload-component/src";
import Avatar from 'vue-avatar'
import moment from 'moment'
import { EyeIcon } from 'vue-feather-icons'
import Vue from 'vue'
  import _ from "lodash";
import VTooltip from 'v-tooltip'
import JQuery from "jquery";
Vue.use(VTooltip)
import docType from "@/views/common/docType.vue"





  export default {
    components: {
      dashBoardMessagesList,
      widgetHeader,
      NoDataFound,
      VuePerfectScrollbar,
      Multiselect,
      MoreHorizontalIcon,
      caseByStatusItem,
      clientItem,
      beneficiaryItem,
      supportItem,
      taskListitem,
      lcaListItem,
      invoiceListItem,
      actionsListItem,
      caseStatsByBranch,
      PendingCaseStats,
      currentStatusOfCase,
      caseSignatureStats,
      caseStatsByStatus,
       Avatar,
        FileUpload,
        Datepicker,
        EyeIcon,
        docType
      
    },
    data: function () {
      return {

        viewType:'LIST',
         tabName :'TODO',
         lableData: [],
         templateClass: "box",
         all_statusids:[],
         itemTemplate: [],
         userRolelist:[],
        allCaseTypes:[],
        caseStatusList:[],

        isListLoading:true,
        widgetsItems:null,
         settings: { 
        swipeEasing: false,
      },
        popupFilter:false,
        value: null,
        options: [],
        primary:'',   
        selectedHeight:'small',
        duplicating:false,
        
        selectedBranch:'',
        tempwidgetsItems:[],
        casebranchList:[],
        getStats:false, //9618127950

        /*ACTION DATA*/
        
  openTaskRejectPopUp:false,
  accepting:false,
   error:'',
   payloadAccept: {
		"taskId": "",
		"action": "",
		"comment": ""
	},
   notifyPetitioner:false,
   emailDocsForSign:false,
   isotopGrid:null,
   isInvaliedFileName:false,
    documentTypes:["Original" ,"Electronic" ],
    jaquery: null,
    settingCaseNumber:false,
    setCode:false,
    newCaseCode:'',
    confCaseCode:'',

   item:null,
   isAddcls:false,
    documentsViewPopup:false,
    skipedActivityList:[],
    workFlowDetails:null,
   assignMentUsersList:{
      "ASSIGN_SUPERVISOR":"SUPERVISOR_LIST",
      "ASSIGN_PARALEGAL":"PARALEGAL_LIST",
      "ASSIGN_DOCUMENTATION_MANAGER":"DOCUMENTATION_MANAGER_LIST",
      "ASSIGN_DOCUMENTATION_EXECUTIVE":"DOCUMENTATION_EXECUTIVE_LIST",
      "ASSIGN_ATTORNEY":"ATTORNEY_LIST",
      },
      petitionToDoList:[],
      assignmentActivityes:[],
       showPopup:false,
        selectedUser:null,
        usersList:[],
        formErrors: "",
        comments:'',
        loading:false,
        petitionDetails:null,
        skipedActivity:false,
        approveCasePopup:false,
        lcaDetails:null,
        approveOrRejectDocs:false,

        //tenant Relate Todo
        tenantTodoList:['TENANT_CREATED' ],
        tenantDetails:null,
        tntActionText:'',
        popuptntTxt:'',
        selectedtenantStatus:0,
        approveTenantConformpopUp:false,

        //Request for signin
        requestsignPopup:false,
        formsAndLettersList:[],
        checkFormsandLatters:false,
        requestsignCommentError:false,

        //Submit to Uscis
        scannedCopies:[],
        submiTouscisPopup:false,

        //Courier Tracking
        updateTrackingPopup:false,
        tracking: {documents:[],receiptNumber:null,receiptName:null},
        trackingdoc: [],
        filesAreuploading:false,
        courierList:[],

       //update USCIS Status
       updateUSCISstatusPopup:false,
       uscisstatuslist: [
      {
        value: "USCIS_APPROVED",
        text: "Case Approved",
      },
      {
        value: "USCIS_RECEIVED_RFE",
        text: "RFE Received",
      },
      {
        value: "USCIS_DENIED",
        text: "Case Denied",
      },
      {
        value: "USCIS_WITHDRAWN",
        text: "Case Withdrawn",
      },
    ],
    casestatus:null,
     issuedDate: null,
    receivedDate: null,
    dueCate: null,
    dueDate:null,
    openDate: new Date().setFullYear(new Date().getFullYear()),
    startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
    uscisdocument:[],

    //COMPANY_CREATED
    petitioner:null,
    actionText:"",
    popupbtnTxt:'',
    selectedStatus:null,
    approveConformpopUp:false,
    //all_statusids:[]
/*ACTIONS DATA END*/


      };
    },
    props: {
      listForDashboard:null, 
       availableEmptyColumns:0,
      rowExistingColumnsLength:0,
      
        columnId:'',
        rowId:'',
    widgetData:null ,
     wedgetHights:{
       
        "1X":'small',
        "1.5":"medium",
        "2X":"large"
      } 
   },
    methods:{
      toggleCalssToRow(data){
        this.$emit("toggleCalssToRow",data);

      },
      togleExpend(data){
        this.$emit('togleExpend' ,data)
      },
      rloadActionWidjet(code){
       
        this.$emit('rloadActionWidjet' ,code);
      },
      changeViewType(){
        
        this.getStats =false;
        if( this.viewType=='LIST'){
            this.viewType='CHART'; 
             this.getStats =true;
        }else{
          this.viewType='LIST'
        }
        if(this.checkProperty(this.widgetData , "_id") && ['LIST' ,'CHART'].indexOf(this.viewType) >-1){
          let data ={ wedgetId:"",viewType:"LIST" };
           data['wedgetId'] =this.checkProperty(this.widgetData , "_id");
           data['viewType'] =this.viewType;
           

           this.$store.commit('setDashBoardWIdgetsListOrChart' ,data);
        }
       
        
        this.getWigetsData();
       
        
      },
       
       changeTab(tab){
        this.tabName =tab;
      
        this.$emit('changeTab' ,tab);
      
         this.getWigetsData();
       },
      wallList(){

      },
       deleteColumn(data){

         let tempData = {
            "rowId": "",
		      	"columnId": "",
            "widgetData":null
          }

        if(this.checkProperty(data ,'rowId' ) && this.checkProperty(data ,'columnId' )){
            tempData['rowId'] =   this.checkProperty(data ,'rowId' );
            tempData['columnId'] =   this.checkProperty(data ,'columnId' );
             tempData['widgetData'] =   this.checkProperty(data ,'widgetData' );

        }else  if(this.columnId && this.rowId ){
         
            tempData['rowId'] =   this.rowId;
            tempData['columnId'] =   this.columnId;
             tempData['widgetData'] =   this.widgetData;
            this.duplicating =true;
           

        }
       
        this.$emit("deleteColumn" ,tempData);

      },
       openAddFilterDialog(data){
       
            if(this.columnId && this.rowId ){
             
          let tempData = {
            "rowId": "",
		      	"columnId": "",
             "widgetData":null,
             'selecetedTab':''
          }
            tempData['rowId'] =   this.rowId;
            tempData['columnId'] =   this.columnId;
            tempData['widgetData'] =   this.widgetData;
            if(this.checkProperty(data ,'selecetedTab')){
                tempData['selecetedTab'] = this.checkProperty(data ,'selecetedTab');
            }

          
            this.duplicating =true;
            
            this.$emit("openAddFilterDialog" ,tempData);

        }

        },
       duplicateColumn(data){
       
         let tempData = {
            "rowId": "",
		      	"columnId": "",
          }

        if(this.checkProperty(data ,'rowId' ) && this.checkProperty(data ,'columnId' )){
            tempData['rowId'] =   this.checkProperty(data ,'rowId' );
            tempData['columnId'] =   this.checkProperty(data ,'columnId' );

        }else  if(this.columnId && this.rowId ){
         
            tempData['rowId'] =   this.rowId;
            tempData['columnId'] =   this.columnId;
            this.duplicating =true;
           

        }
         this.$emit("duplicateColumn" ,tempData);
      },
       setHeighet(height='small'){
        
        this.selectedHeight=height
      },
      psSectionScroll(event){

      },
       branchSelected(branchId =''){

        this.selectedBranch =branchId;
        this.widgetsItems =_.cloneDeep(this.tempwidgetsItems );
        if(this.selectedBranch !=''){
           this.widgetsItems['data'] =[];
           let  data = _.filter(this.tempwidgetsItems['data'] ,{"branchId":this.selectedBranch});
           this.widgetsItems['data']  = data;

            

        }

       },
    getWigetsData(){
      let self =this;
      this.isListLoading =true;
      this.widgetsItems =null;
      let path ="dashboard/get-widget-data";
      let postData ={
        getStats:false,
        categoryList:[],
        filters:{},
        perpage:10
      };
      if([ 'INVOICE', 'CASE_BY_STATUS' ,'LCA'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1 && this.getStats){

       
       postData['getStats'] =this.getStats;


      }

      postData['categoryList'].push(this.checkProperty(this.widgetData ,"code"));
      postData['perpage'] = this.checkProperty(this.widgetData ,"perpage");
      if(this.checkProperty(this.widgetData ,"sorting" ,'path') && this.checkProperty(this.widgetData ,"sorting" ,'order')){
        postData = Object.assign(postData,{"sorting":this.widgetData['sorting']});
      }

   

      if(this.checkProperty(this.widgetData ,"filters" ) ){
       // postData['filters'] = this.checkProperty(this.widgetData ,"filters"); //this.tabName
       
              
        if(['ACTION','UPDATES' ,'DEADLINE'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1){

          if(['UPDATES'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1){

            _.forEach(this.widgetData['filters'] ,(val ,key)=>{

              if(key=='dueDateRange'){
                postData['filters'][key] =val
              }
              if(key=='createdDateRange'){
                postData['filters'][key] =val
              }
              //['countryIds' ,'stateIds' ,'typeIds' ,'petitionTypeIds']
              if(['countryIds' ,'stateIds'].indexOf(key)>-1){
                // postData['filters'][key]
                if(_.has(val ,'id')){
                  postData['filters'][key] =[val['id']]
                }

              }else{

                  let arrayListIds = _.filter(val ,(item)=>{
                    return _.has(item ,'name') && _.has(item ,'id')
                })
                if(arrayListIds && this.checkProperty(arrayListIds ,'length')>0){
                    postData['filters'][key] = arrayListIds.map((item)=>item.id);
                }else{
                    postData['filters'][key] =val;

                }
              }


            })
        
             
        }  else if(this.checkProperty(this.widgetData,'filters' ,this.tabName )){

          
            _.forEach(this.widgetData['filters'][this.tabName] ,(val ,key)=>{

              if(key=='dueDateRange'){
                 postData['filters'][key] =val
              }
              if(key=='createdDateRange'){
                 postData['filters'][key] =val
              }
             //['countryIds' ,'stateIds' ,'typeIds' ,'petitionTypeIds']
            if(['countryIds' ,'stateIds'].indexOf(key)>-1){
              // postData['filters'][key]
              if(_.has(val ,'id')){
                postData['filters'][key] =[val['id']]
              }

            }else{
          
            let arrayListIds = _.filter(val ,(item)=>{
              return _.has(item ,'name') && _.has(item ,'id')
            })
            if(arrayListIds && this.checkProperty(arrayListIds ,'length')>0){
              postData['filters'][key] = arrayListIds.map((item)=>item.id);
            }else{
              postData['filters'][key] =val;

            }
          }


             })
        }

          if(this.tabName == 'UPDATES' || ['UPDATES'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1 ){
            postData['filters']['types'] = ['activity'];
            postData['filters']["entityTypeList"] = [];

          }

          if(['TODO' ].indexOf(this.tabName)>-1){
            postData['filters']['types'] = ['todo'];
            postData['filters']["entityTypeList"] = [];

          }
          if(['CASES'].indexOf(this.tabName)>-1){
             postData['filters']['types'] = ['todo'];
             postData['filters']["entityTypeList"] = ["petition"];
            
          }
          if(['TASK'].indexOf(this.tabName)>-1){
            postData['filters']['types'] = ['todo'];
            postData['filters']["entityTypeList"] = [ "task"];
          }


         
     

        }else{

        
        _.forEach(this.widgetData['filters'] ,(val ,key)=>{

            if(key=='dueDateRange'){
                postData['filters'][key] =val
            }
            if(key=='createdDateRange'){
                postData['filters'][key] =val
            }

          //['countryIds' ,'stateIds' ,'typeIds' ,'petitionTypeIds']
          if(['countryIds' ,'stateIds' ].indexOf(key)>-1){
            // postData['filters'][key]
            if(_.has(val ,'id')){
              postData['filters'][key] =[val['id']]
            }

          }else{
        
           let arrayListIds = _.filter(val ,(item)=>{
            return _.has(item ,'name') && _.has(item ,'id')
           })
           if(arrayListIds && this.checkProperty(arrayListIds ,'length')>0){
            postData['filters'][key] = arrayListIds.map((item)=>item.id);
           }else{
            postData['filters'][key] =val;

           }
        }


         })
       
        }

      }
    
    if(['ACTION' ,'UPDATES' ].indexOf(this.checkProperty(this.widgetData,'code' ))>-1){
      if(this.tabName == 'UPDATES' || ['UPDATES' ].indexOf(this.checkProperty(this.widgetData,'code' ))>-1 ){
            postData['filters']['types'] = ['activity'];
            postData['filters']["entityTypeList"] = [];

          }

          if(['TODO' ].indexOf(this.tabName)>-1){
            postData['filters']['types'] = ['todo'];
            postData['filters']["entityTypeList"] = [];

          }
          if(['CASES'].indexOf(this.tabName)>-1){
             postData['filters']['types'] = ['todo'];
             postData['filters']["entityTypeList"] = ["petition"];
            
          }
          if(['TASK'].indexOf(this.tabName)>-1){
            postData['filters']['types'] = ['todo'];
            postData['filters']["entityTypeList"] = [ "task"];
          }
     }

      this.casebranchList =[];
       this.tempwidgetsItems =[];
       
       if(['UPDATES' ].indexOf(this.checkProperty(this.widgetData,'code' ))>-1){
        postData['filters']['userRoleType'] = 'petitioner';

        if([3,4].indexOf(this.getUserRoleId)>-1 && this.getTenantTypeId ==2){
          postData['filters']['userRoleType'] = 'internal_user';
        }
        
        if([50].indexOf(this.getUserRoleId)>-1){
          postData['filters']['userRoleType'] = 'beneficiary';
        }else if([51].indexOf(this.getUserRoleId)>-1){
          postData['filters']['userRoleType'] = 'beneficiary';
        }else{
          postData['filters']['userRoleType'] = this.tabName;
          if(['internal_user' ,'petitioner','beneficiary' ,'all'].indexOf(this.tabName)>-1){
           // alert(this.tabName)
           if(this.tabName === 'petitioner' && [3,4].indexOf(this.getUserRoleId)>-1 && this.getTenantTypeId ==2){
              postData['filters']['userRoleType'] = 'internal_user';
              this.tabName ='internal_user';
           }
            
          }
          

        }

       }
       //alert(postData['filters']['userRoleType'])
       if(this.checkProperty(this.widgetData ,"code") =='CASE_SIGN_STATS'){
        postData['filters']['caseType'] = 'h1b';
        if(this.checkProperty(this.widgetData ,'filters' ,'caseType')){
          if(this.checkProperty(this.widgetData['filters'],'caseType' ,'id')){
            postData['filters']['caseType'] = this.widgetData['filters']['caseType']['id'];
          }

        }
          this.widgetData['filters']['caseType'] = postData['filters']['caseType'];
          let widgetData =  _.cloneDeep(this.widgetData);
          this.widgetData =null;
          this.widgetData =  _.cloneDeep(widgetData);
        
       }
       this.updateLoading(true); 
       this.$store.dispatch("commonAction" ,{data:postData,'path':path})
       .then((rx) =>{
         if(this.checkProperty(this.widgetData ,"code") =='MESSAGES'){
          this.widgetsItems = rx['MESSAGES']
          let data = this.widgetsItems['data'];
          let toUsersList = [];
          if(this.widgetsItems['toUserList'] && this.checkProperty(this.widgetsItems, 'toUserList', 'length')>0){
            toUsersList = this.widgetsItems['toUserList'];
          }
           let temp_list = [];
          _.forEach(data, (obj) => {
            obj["is_expend"] = false;
            obj["all_comments"] = [];
            obj["newComment"] = { ticketId: "", statusId: "", description: "", documents: [], today: moment().format("YYYY-MM-DD"),  };
            if(_.has(obj, 'toUserIds') &&  self.checkProperty(obj,'toUserIds', 'length')>0 && toUsersList && self.checkProperty(toUsersList, 'length')>0){
              obj['toUserList'] = [];
              _.forEach(obj['toUserIds'],(itd)=>{
                let findOb = _.find(toUsersList,{'_id':itd});
                if(findOb){
                  obj['toUserList'].push(findOb)
                }
              })
            }else{
              if(!_.has(obj, 'toUserList')){
                obj['toUserList'] = [];
              }
              
            }
            temp_list.push(obj);
            });
         
          this.widgetsItems['data'] = temp_list;


         }else if(this.checkProperty(this.widgetData ,"code") =='CASE_SIGN_STATS'){
            let widgetsItems = rx[this.checkProperty(this.widgetData ,"code")];
            this.widgetsItems =[];
            if(this.checkProperty(widgetsItems ,'data','length')>0){
              _.forEach(widgetsItems['mData'] ,(item)=>{

                item =Object.assign(item ,{'statusName':'' ,'statusId':'' ,"typeIds":[],"subTypeIds":[]  ,"caseType":''} )
                item['statusId'] =item['id']
                item['statusName'] =item['name']
                
                if(this.checkProperty(widgetsItems , 'subTypeIds' ,'length') >0 ){
                  item['subTypeIds'] =widgetsItems['subTypeIds'];
                }
                if(this.checkProperty(widgetsItems , 'typeIds' ,'length') >0 ){
                  item['typeIds'] =widgetsItems['typeIds'];
                }
                if(this.checkProperty(widgetsItems , 'caseType')){
                  item['caseType'] =widgetsItems['caseType'];
                }
                
                if(this.checkProperty(item , 'count') >0){
                  this.widgetsItems.push(item);
                } 
               
                //item['subTypeIds'] =widgetsItems['subTypeIds']
                

                //  if(this.checkProperty(widgetsItems ,'mData','length')>0 && this.checkProperty(item ,'statusId') >0){
                   
                  //  let mData = _.find(widgetsItems['mData'] ,{"id":item['statusId']});
                  //  if(mData && this.checkProperty(mData ,'name')){
                  //   item['statusName'] =mData['name'];
                                        
  
                   
                                     
                  //       if(this.checkProperty(mData ,'statusIds' ,'length') >0){
                  //         item['statusIds'] = mData['statusIds'];
                  //       }
                  //       if(this.checkProperty(widgetsItems ,'caseType')){
                  //         item['caseType'] = widgetsItems['caseType'];
                  //       }
                        
                                         
                  //       this.widgetsItems.push(item);
                      
                      
  
  
                  //  }
                   
  
                  // }
              });
              
              
             
  
            }

          }else{
            this.widgetsItems = rx[this.checkProperty(this.widgetData ,"code")];
          }
      
      

      if(['CASE_STATS_BY_BRANCH'].indexOf(this.checkProperty(this.widgetData ,"code"))>-1 ){
         this.tempwidgetsItems =_.cloneDeep(this.widgetsItems);
      
      //  this.widgetsItems['data'];
     

        _.forEach(this.widgetsItems['data'] ,(item)=>{
 
          let isExists = _.find(this.casebranchList ,{'branchId':item['branchId']});
        
          if(!isExists){
            if(this.selectedBranch==''){
              this.selectedBranch = item['branchId'];
            }
            this.casebranchList.push({"branchId":item['branchId'] ,"branchName":item['branchName']});

          }
            


        })
        
      
         this.casebranchList =  this.casebranchList
         this.branchSelected(this.selectedBranch)
       

       // widgetsItems['data']




      }
      this.isListLoading =false;
      setTimeout(()=>{
          this.updateLoading(false); 
          setTimeout(()=>{ this.isListLoading = false;  this.updateLoading(false);  } ,10)
          this.$refs['widgetheader'].init();   
         
      } ,10)
       

      })
      .catch((err) =>{

        
         this.isListLoading =false;
        setTimeout(()=>{
              this.updateLoading(false); 
              setTimeout(()=>{ this.isListLoading = false;  this.updateLoading(false);  } ,10)   
          } ,10)
         
       
       })

       //widgetheader
      
    },
/* Actions Methods */

    checkisRejected(ticket){
      let returnVal =false;
      if(
        
       (this.checkProperty(ticket['data'] ,'rejectedByIds' ,'length')>0 && ticket['data']['rejectedByIds'].indexOf(this.checkProperty( this.getUserData,'userId'))>-1  )
      ){
        returnVal =true;
      }


      return returnVal;
    },

    checkisAccepted(ticket){
      let returnVal =false;
      if(
        (  this.checkProperty(ticket['data'] ,'acceptedByIds' ,'length')>0 && ticket['data']['acceptedByIds'].indexOf(this.checkProperty( this.getUserData,'userId'))>-1  )
      
      ){
        returnVal =true;
      }


      return returnVal;
    },

    isAssignedUser(ticket){
      if( this.checkProperty( ticket['data'] ,'assignedTo' ,'length') >0 && ticket['data']['assignedTo'].indexOf(this.checkProperty( this.getUserData,'userId'))>-1 ){
        return true
      }else{
        return false
      }
    },


     openAcceptForm(action =false ,actionType=''  ,task=null){
     let actionCode = this.checkProperty(this.widgetData ,'code' );
      
      this.$emit('openAcceptForm' ,{action:action ,actionType:actionType  ,item:task ,actionColumnId:this.columnId,actionRowId:this.rowId ,actionCode:actionCode})

    },
    openApprovepopup(status=2 ,txt=''){
        let actionCode = this.checkProperty(this.widgetData ,'code' );
        this.$emit('openApprovepopup' , {status:status ,txt:txt ,item:this.item ,actionColumnId:this.columnId,actionRowId:this.rowId ,actionCode:actionCode})


      }, 

  
    checkSendAttachments(action=''){
      setTimeout(() =>{
            if(this.notifyPetitioner && action=='notifyPetitioner'){
          //  this.emailDocsForSign =false;
         
            }
            
            if(this.emailDocsForSign && action=='emailDocsForSign'){
              this.notifyPetitioner =true;
            }

      } ,10)
      
    },
    initIsotop(resetIsotop=false){
      
      setTimeout(() => {
          

             // Force grid to relayout
             if(resetIsotop && this.isotopGrid && false){
                this.isotopGrid.isotope('layout');
               // alert()

             }else{
               this.isotopGrid=  jQuery(".db_grid").isotope({
              layoutMode: "packery",
              itemSelector: ".grid_element",
              masonry: {
                horizontalOrder: true,
              },
            });
            if (jQuery(".db_grid").height() <= 50) {
              jQuery(".db_grid").height("auto");
              var _h = jQuery(".db_grid").innerHeight();
              jQuery(".db_grid").height(_h);
            }

             }
          

          
            // this.$vs.loading.close();
          }, 100);
    },
    
      getPetitionerRoleName(item){

        if(this.checkProperty(this.userRolelist ,'length')>0){
          //userRolelist
          let petitioner = _.find( this.userRolelist ,{"id": 50});
          if(this.checkProperty(petitioner ,'name')){

            return petitioner['name'];
          }else{
            return "Petitioner";

          }

        }else{
          return "Petitioner";
        }
      },
      addReviewrsRolesList(){

        let reviewrsRolesList =[]
          
          let tempData = _.cloneDeep(this.usersList);
          let tempUnuqueItems =[]
          _.forEach(tempData ,(object)=>{
            if(tempUnuqueItems.indexOf(object['roleName']) <=-1){
              tempUnuqueItems.push(object['roleName']);
              reviewrsRolesList.push(object); 

            }

          })
          return reviewrsRolesList;
  
        
      },

     /*** Computed ***/

     openSetCaseCodePopup(){
         
         this.formerrors = null;
         this.newCaseCode = this.checkProperty( this.item,'data' ,'caseNo');
         this.confCaseCode = '';
         this.settingCaseNumber =false
         this.$validator.reset('newCaseNumberForm')
         this.setCode = true;
      },
       SetCaseCodeAction() {
        
       
      this.$validator.validateAll('newCaseNumberForm').then((result) => {
        
        if (result) {
           
           let self =this;
          let postData = {
            caseNo: self.newCaseCode.trim(),
            //currentPassword: self.confCaseCode,
             petitionId: self.petitionDetails['_id'],
             subTypeName:self.checkProperty(self.petitionDetails,'subTypeDetails','name'),
             typeName:self.checkProperty(self.petitionDetails,'typeDetails','name'),
         
          };
          let patth = "/petition/assign-custom-caseno";
          if(self.checkProperty(self.petitionDetails,'subTypeDetails','id') ==15){
            patth = "/perm/assign-custom-caseno";
          }
         
           this.settingCaseNumber =true
            this.$store.dispatch("commonAction", {"data":postData ,"path":patth})
              .then(response => {
                   this.showToster({message:response.message,isError:false });
                   this.newCaseCode ='';
                  this.confCaseCode ='';
                  this.$validator.reset('newCaseNumberForm');
                  this.setCode = false;
                   this.settingCaseNumber =false
                    this.reloadWallList();
                  
              }).catch((err)=>{
                 this.settingCaseNumber =false
                 this.formerrors =err
               // this.showToster({message:err,isError:true });
              });
        }
      });
     },

    getlableName(){
      let self =this;
     let code = self.checkProperty( this.item ,"data" , "category");
       let returnValue = "Submit to Reviewer";

      let labels = [
        {"code":"ASSIGN_SUPERVISOR" ,"label":"Assign Supervisor"},
        {"code":"ASSIGN_PARALEGAL" ,"label":"Assign Paralegal"},
        {"code":"ASSIGN_DOCUMENTATION_MANAGER" ,"label":"Assign Document Manager"},
        {"code":"ASSIGN_DOCUMENTATION_EXECUTIVE" ,"label":"Assign Document Executive"},
       {"code":"ASSIGN_ATTORNEY" ,"label":"Assign Attorney"},
      ];

      let assignLabel = _.find(labels , {"code":code} );
     
      if(assignLabel && this.checkProperty(assignLabel ,'label' )){

        returnValue = assignLabel['label'];

      }  else if(this.lableData.length>0 && code){
        let msgObject = _.find(this.lableData , {"code":code});
        if( msgObject && _.has(msgObject , 'actionLable')){
            returnValue = msgObject['actionLable'];
        }

      }

      return returnValue;

    },
    getBorderColor(){
     let returnValue =``;
        if(this.checkProperty(this.item ,"data" ,"config")){
          let config = this.item['data']['config'];
          if( this.checkProperty( config ,'bgColor' ,"length")>1 ){
             let color1 = config['bgColor'][0]
             let color2 = config['bgColor'][1]
            returnValue =`1px solid ${color2}`;
          }
        }
        return returnValue;
    },
    getGredieantColor(wallItem){
      let angle =118
        let color1 = '#EFF7FF'
        let color2 = '#DEEAF6'
      let returnValue =`linear-gradient(${angle}deg, ${color1} 0%, ${color2}  100%)`;
      if(this.checkProperty(wallItem ,"data" ,"config")){
        let config = wallItem['data']['config'];
        if( this.checkProperty( config ,'bgColor' ,"length")>0 ){
          //  returnValue =config['bgColor'][0];
        // return 'linear-gradient(118deg, '+config['bgColor'][0]+' 0%,'+ config['bgColor'][1]+' 100%);'
         angle =118
         color1 = config['bgColor'][0]
         color2 = config['bgColor'][1]
         returnValue= `linear-gradient(${angle}deg, ${color1} 0%, ${color2}  100%)`;
        }
      }
      return  returnValue;
    },
    addClass(){
      this.isAddcls =true;
    },
     openDocumentsPopup(){
       this.documentsViewPopup =true;
     },
     fetchWorkflowDetails(callBack=null){
    
   
    this.workFlowDetails = null;
    let category =  this.checkProperty( this.item ,"data" , "category")
            
    if(this.checkProperty( this.petitionDetails ,'workflowId') && _.has(this.assignMentUsersList ,category)){
      let payLoad = {"path":"/workflow/details",data:{'workflowId':this.checkProperty( this.petitionDetails ,'workflowId')}};
      this.$store.dispatch("commonAction" ,payLoad)
      .then((res)=>{
        this.workFlowDetails = res;
        this.findSkipedActivityList();
          this.$vs.loading.close();
       
        
        let currentActivityList = this.assignMentUsersList[category];
       
        if( this.workFlowDetails &&  _.has(this.workFlowDetails ,'config') ){
           let usersListObject = _.find(this.workFlowDetails['config'] ,{"code":currentActivityList});
          this.usersList =[];
          let postData ={
              "matcher":{
              "roleIds": [],
              "branchId":"",
              },
              
              "page": 1,	
              "perpage":100000000,
              
              };

          let companyIdRoles =[50 ,51];
          let branchIdRoles =[4, 5, 6, 7, 8, 9, 10, 11 ,12];
          _.forEach(usersListObject['editors'],(editor)=>{
          
          
          postData.matcher.roleIds.push(editor.roleId);
          if(companyIdRoles.indexOf(editor.roleId)>-1 && this.checkProperty(this.petitionDetails ,'companyDetails' ,'_id')){
              postData = Object.assign(postData ,{"companyId":this.checkProperty(this.petitionDetails ,'companyDetails' ,'_id') })
          }

          if(branchIdRoles.indexOf(editor.roleId)>-1 && this.checkProperty(this.petitionDetails ,'branchId')){
              postData['matcher']['branchId'] = this.checkProperty(this.petitionDetails ,'branchId');
          }
          

          });
          //alert(JSON.stringify(postData));

          this.$store.dispatch("getList",{data:postData ,path:'/petition/assign-user-list'} ).then(response => {
          //alert(JSON.stringify(response.list));
              let lst = []
              
              _.forEach(response.list ,(item)=>{
                  if(_.has(item ,'name') && _.has(item ,'roleName') && ( item._id !=this.getUserData['userId'])){
                      item.name = item.name+" ("+item.roleName+")";
                      lst.push(item);
                  }
              
              });
              this.usersList = lst;
              if(callBack){
              callBack();
              }
            
          });
              
        }
        
       
             
      })
      .catch((error)=>{
       
           this.workFlowDetails = null;
             this.$vs.loading.close();
                  
        
      })

    }else{
        this.$vs.loading.close();
    }

    },
     findSkipedActivityList(){
      
      this.skipedActivityList =[];
       this.skipedActivity =false;
      let workFlowDetails =  this.workFlowDetails;
    if(workFlowDetails && this.petitionDetails && this.checkProperty(this.petitionDetails , 'nextWorkflowActivity') && _.has(workFlowDetails ,"config")){
        
         let config  = workFlowDetails['config'];
       let petitionCurrentActivityIndex = _.findIndex(config ,{"code": this.petitionDetails['nextWorkflowActivity'] });
       let completedActivityList = this.petitionDetails['completedActivities'];
      
       if(petitionCurrentActivityIndex>-1 && completedActivityList.length>0  && (completedActivityList.indexOf("SUBMIT_TO_USCIS")<=-1 ) ){
      
        _.forEach(config ,(activityItem ,index)=>{
          if(index<petitionCurrentActivityIndex){
            
            if(completedActivityList.indexOf(activityItem['code'])<=-1   && _.has(this.assignMentUsersList ,activityItem['code'])){
              
            
             if(completedActivityList.indexOf("CASE_APPROVED") >-1){

                if([ 'ASSIGN_DOCUMENTATION_MANAGER','ASSIGN_DOCUMENTATION_EXECUTIVE'].indexOf(activityItem['code']) >-1){

                     this.skipedActivityList.push(activityItem['code']);
                     this.skipedActivity =true;

                }

              }else{
                this.skipedActivityList.push(activityItem['code']);
                this.skipedActivity =true;

              }
              
              
            
            
            }

          }


        })
       }
            
    }
   

    },
      reloadWallList(){

           setTimeout(() => {
                   this.loading =false;
                  // this.$emit("rloadActionWidjet");
                 
                  this.getWigetsData()
                   
                } ,100)

      },
      goToDetaillPage(){
        //alert(this.checkProperty(this.item ,'data' ,'navigationKey'))
          //alert( this.checkProperty(this.item ,'data' ,'navigationKey'))
          let category = this.checkProperty( this.item ,"data" , "category");

           if( this.checkProperty(this.item ,'data' ,'navigationKey')  == "TASK_DETAILS"){

               let taskId = this.checkProperty(this.item ,"data", "taskId");
                let path =  {'path':"/tasks-list" ,"query":{}};
               if(taskId) {
                 path["query"]['id'] =taskId
                 this.$router.push(path);

               }
                


          }

          if( this.checkProperty(this.item ,'data' ,'navigationKey')  == "TENANT_DETAILS"){

               let tenantId = this.checkProperty(this.item ,"data", "tenantId");
               if(tenantId) this.$router.push("/customer-details/"+tenantId);


          }
          if((this.checkProperty(this.item ,'data' ,'navigationKey')=='LCA_DETAILS') ){
              let petitionId = this.checkProperty( this.item ,"data" , "petitionId");
              if(petitionId){
                 
                   this.$store.dispatch("setPetitionTab" , 'set_LCA');
                  this.findDetailsPage(petitionId);
                 
                

              }
                 

          }else if(this.petitionToDoList.indexOf(category)>-1  ||  this.checkProperty(this.item ,'data' ,'navigationKey') =='PETITION_DETAILS'   ){
              let petitionId = this.checkProperty( this.item ,"data" , "petitionId");
              if(petitionId){
               
                 this.findDetailsPage(petitionId);
               
                

              }
                 

            }else if( this.tenantTodoList.indexOf(category)>-1 || ['TENANT_STATUS_UPDATE'].indexOf(category)>-1){

               let tenantId = this.checkProperty(this.item ,"data", "tenantId");
               if(tenantId)
                  this.$router.push("/customer-details/"+tenantId);
          }else if( this.checkProperty(this.item ,'data' ,'navigationKey')=='USER_DETAILS'){

              this.$router.push("/users");
          }
          else if( this.checkProperty(this.item ,'data' ,'navigationKey')=='COMPANY_DETAILS'){
           
              let companyId = this.checkProperty(this.item ,"data", "companyId")
              if(companyId)
                 this.$router.push("/petitioner-details/"+companyId);
          }else if( ['TICKET_DETAILS'].indexOf(this.checkProperty(this.item ,'data' ,'navigationKey'))>-1){
           
              let ticketId = this.checkProperty(this.item ,"data", "ticketId");
              if(ticketId)
                 this.$router.push("/ticket-details/"+ticketId);
          }
          
      },
      fetchPetitionDetails(wallItem,callBack ,funName=''){
           this.item = wallItem
          let category =  this.checkProperty( this.item ,"data" , "category")
        
          if( this.petitionToDoList.indexOf(category)>-1 ||  this.checkProperty(this.item ,'data' ,'navigationKey') =='PETITION_DETAILS'){
         
           this.$vs.loading();
               let petitionId = this.checkProperty( this.item ,"data" , "petitionId");
            this.$store.dispatch("getpetition", petitionId).then(response => {
               
                if (response.data) {


                  
                    this.petitionDetails = response.data.result;
                     if(funName=="openApproveOrRejectDocs"){
                       callBack()
                    }
                     if(funName=="openapproveCasePopup"){
                       callBack()
                    }
                    //updateUSCISstatus
                    if(funName=="updateUSCISstatus"){
                       callBack()
                    }
                    if(funName =='openSetCaseCodePopup'){
                      this.openSetCaseCodePopup();
                       this.$vs.loading.close();
                      return false
                    }
                    
                    if(_.has(this.assignMentUsersList ,category)){
                      this.fetchWorkflowDetails(callBack);
                    }else if(category=='REQUEST_PETITIONER_SIGN' || category == 'SUBMIT_TO_USCIS'){
                       this.getFormsAndLetters(callBack);
                         this.$vs.loading.close();
                    }else  if((['UPDATE_USCIS_RECEIPT_NUMBER' ,'COURIER_TRACKING'].indexOf(this.checkProperty( this.item ,'data' , 'category'))>-1 && this.checkProperty( this.item ,'status'))){
                       
                      this.getCourierList(callBack);
                    }else{
                         this.$vs.loading.close();
                    }
                   
                  
               }else{
                   this.$vs.loading.close();

               }
            })
            
          }else if( this.tenantTodoList.indexOf(category)>-1){
           
            this.getTenantDetails();

          }else if( ['COMPANY_CREATED'].indexOf(category)>-1){
            this.getpetetioner();

          }
         
      },
      submitAction(action=''){
          this.$validator.validateAll("assignmentForm").then((result) => {
            if (result) {
              let postData = {
               petitionId: this.petitionDetails['_id'],
                comment: this.comments,
                  "userId": this.checkProperty(this.selectedUser ,"_id"),
                  "userName": this.checkProperty(this.selectedUser ,"name"),
                  "roleId":  this.checkProperty(this.selectedUser ,"roleId"),
                  "assignRoleName":  this.checkProperty(this.selectedUser ,"roleName"),
                  subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
                  typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),
                   "action":this.checkProperty( this.item ,"data" , "category"), //"ASSIGN_SUPERVISOR", // "ASSIGN_PARALEGAL" / "ASSIGN_DOCUMENTATION_MANAGER" / "ASSIGN_DOCUMENTATION_EXECUTIVE" / "ASSIGN_ATTORNEY"
                 // "lastUserName": "Paralegal", // is Required when replacing a paralegal(action == "REPLACE_PARALEGAL"),
                //  "submitted": true // Required only when submitting to any roleSupervisor
                 isSkippedAction:this.skipedActivity?true:false

              };
              
              
             
               this.loading =true;
               this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/assign-a-role"})
              .then(response => {
                this.showPopup =false;
             
                this.showToster({message:response.message,isError:false });
                this.skipedActivity =false;
                this.reloadWallList();

                
                
                
                                
              })
              .catch((error)=>{
                
                this.formErrors =error;
                this.loading =false;
              })
              
       
       

              
            }
          });
      

      },
      openPopup(){
     
         this.formErrors = '';
        this.comments ='';
      
       // if(this.usersList.length>0){
          this.formErrors ="";
          this.comments ='';
          this.showPopup =true;
          this.selectedUser =null;
          this.loading =false;
          if(this.checkProperty(this.petitionDetails ,'typeDetails' ,'name') && this.checkProperty(this.petitionDetails ,'subTypeDetails' ,'name')){
            this.comments = "Case "+this.petitionDetails.typeDetails.name+", "+this.petitionDetails.subTypeDetails.name+"  is being assigned for further actions";

          }
           
        // }else{
        //   this.showToster({message:'Reviewers not found.',isError:true });
         
        // }
          

    

       
      this.$validator.reset();
      
      
     

    },
    selectUesr(item){
      this.selectedUser = item;
     
    },

    //CASE APPROVE Section
      openapproveCasePopup(){
         
          if (this.checkProperty(this.petitionDetails ,'lcaId')!= null && this.checkProperty(this.petitionDetails ,'lcaId')!= '') {
               this.$vs.loading();
                    this.$store
                        .dispatch("fetchLcaDetails", this.petitionDetails.lcaId)
                        .then(response => {
                              this.$vs.loading.close();
                            this.lcaDetails = response.data.result;
                            let getLcaDetails = _.cloneDeep(this.lcaDetails);
                             if( getLcaDetails && _.has(getLcaDetails ,"statusId") ){
                                    if( [2,3].indexOf(getLcaDetails['statusId'])<=-1 ){
                                        this.showToster({message:"LCA should be either Filed or Certified in order to approve the case." ,isError: true});
                                        setTimeout(() => {
                                                this.loading =false;
                                                    this.goToDetaillPage();
                                                
                                                } ,100)
                                        
                                        return false;
                                    }else{
                                        this.showPopup =false;
                                        this.formErrors = '';
                                        this.comments ='';
                                        this.loading =false,
                                        this.approveCasePopup =true;
                                        this.$validator.reset();

                                    }
                             }


                        }).catch((err)=>{
                             this.$vs.loading.close();
                             this.showToster({message:err ,isError: true});
                            setTimeout(() => {
                                    this.loading =false;
                                        this.fetchPetitionDetails(this.item);
                                    
                                    } ,100)
                        })
          }else{
               this.showPopup =false;
                this.formErrors = '';
                this.comments ='';
                this.loading =false,
                this.approveCasePopup =true;
                this.$validator.reset();

          }                
      
       


     },
    caseApproveCaseAction(){
       this.formErrors ='';
         let postData = {
             petitionId: this.petitionDetails['_id'],
            comment: this.comments,
            action:'CASE_APPROVED', // "SUBMIT_TO_LAW_FIRM", // "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "SUBMIT_TO_USCIS" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED" 
            today: moment().format('YYYY-MM-DD'), // Required on Status changes to "Received RFE"
           subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
           typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),

         };
         
         this.$validator.validateAll("approvecase").then((result) => {
           
            if (result) {
               this.loading =true;
               this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/manage-approval-process"})
              .then(response => {
                
                 this.showToster({message:response.message,isError:false });
                 this.showPopup =false;
                 this.approveCasePopup =false;
                  this.loading =false;
                  this.reloadWallList();
                
                
                                
              })
              .catch((error)=>{
                 this.loading =false;
                this.formErrors =error;
              })
       
       

              
            }
          });
           

       
     

    },

//Approve reject Documents
     openApproveOrRejectDocs(){
     
     this.formErrors = '';
        this.comments ='';
         this.loading =false;
         this.approveOrRejectDocs = true;
     this.$validator.reset();
  },
  approveOrRejectDocsAction(action=""){
    this.formErrors ="";
     this.$validator.validateAll("approveOrRejectDocsForm").then(result => {
      if(result && ['APPROVED_BY_DOC_MANAGER', 'REJECT_BY_DOC_MANAGER'].lastIndexOf(action)>-1){
        var postData = {
              petitionId:this.checkProperty(this.petitionDetails,'_id'),
              typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),
              subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
              comment:this.comments, // Required on APPROVED_BY_DOC_MANAGER and REJECT_BY_DOC_MANAGER
              action: action,//"UPLOAD_BY_DOC_EXECUTIVE",//APPROVED_BY_DOC_MANAGER, REJECT_BY_DOC_MANAGER
              today: moment().format("YYYY-MM-DD")
        }

        this.loading =true;
        this.$store.dispatch("commonAction", {"data":postData ,"path":"/petition/manage-offshore-document-upload"})
              .then((response) => {
              
             
              this.approveOrRejectDocs = false;
              this.showToster({message:response.message,isError:false })
               this.reloadWallList();
              
                            
              })
              .catch((error) => {
              
                this.formErrors = error;
                this.loading = false;
                
              
              })
       }
            
         
     })
   
  },

  //tenant related ToDo 
  getTenantDetails(){
    let tenantId = this.checkProperty(this.item ,"data", "tenantId")
          let postData = {tenantId:tenantId};
            this.$vs.loading();
           this.$store.dispatch("commonAction", {"data":postData ,"path":"/tenant/details"})
           .then((response) => {
               this.tenantDetails =response;
               this.$vs.loading.close();
           })
           .catch((err) =>{
               this.$vs.loading.close();
                this.tenantDetails =null;
               this.showToster({message:err,isError:true });

           })



  },
  openTenantApprovepopup(status=2 ,txt='', event){
  
        this.getTenantDetails()
        this.tntActionText = "Do you want to "+txt+" ?",
        this.popuptntTxt = txt;
        this.selectedtenantStatus = status;
        this.approveTenantConformpopUp =true;
        this.formErrors = '';
        this.comments ='';
         this.loading =false;

  },
  changetenantStatus( ){
        let post_data = {"tenantId":this.tenantDetails['_id'], "statusId":this.selectedtenantStatus }
      
      let action ="changetenantStatus"
       if(this.selectedtenantStatus ==4){
        action = "deleteTenant"
       }
       if( this.comments.trim() =='' && [3,4,5].indexOf(this.selectedtenantStatus)>-1 ){
         return true;

       }
       if([3,4,5].indexOf(this.selectedtenantStatus)>-1){
        post_data = Object.assign(post_data,{"comment":this.comments}) ;
       }
       //alert(action)
       this.$store.dispatch(action, post_data)
          .then(response => {
            this.showToster({message:response.message,isError:false});
            this.approveTenantConformpopUp =false;
            this.reloadWallList();


          }).catch((err)=>{
            this.formErrors = err;
            this.showToster({message:err,isError:true});
          
        });
 },

 //Request for signin documents

  getFormsAndLetters(callBack=null){
    this.formsAndLettersList = [];
    let finalList =[];
      let postData ={petitionId:this.petitionDetails._id ,'page':1 ,'perpage':10000 };
    this.$store.dispatch("getList" ,
    {
      data:postData,
    //path:"/petition/filled-forms-and-letters-list"
      path:"/filled-forms-and-letters/list"
    })
    .then(response => {
  //  this.formsAndLettersList = response.list;

    
      let lst = [];
    
    _.forEach(response.list ,(mainItem)=>{
        mainItem = Object.assign(mainItem,{"reverse_document_versions":[] ,"mainParentId":'',showMe:true ,"selectedForSigning":false});
        if(mainItem.parentId){
            mainItem['mainParentId'] = mainItem['parentId']
        }else{
            mainItem['mainParentId'] = mainItem['_id']
        }

        lst.push(mainItem);
          

    });

    let subList=[];
    
    //reverse_document_versions
    _.forEach(lst ,(mainItem)=>{

                        
        
        _.forEach(lst ,(subItem)=>{
            if( mainItem.parentId && (mainItem.parentId == subItem['parentId'] ||  mainItem.parentId == subItem['_id']   ) &&  mainItem['_id'] != subItem['_id']){
                      
                      subItem['showMe'] =false;
                      if(subList.indexOf(subItem['_id']<=-1)){
                          mainItem['reverse_document_versions'].push(subItem);
                          subList.push(subItem['_id']);

                      }
                    
                    // mainItem['showMe'] =true;
            }

        })
        
    if(mainItem.showMe){
          finalList.push(mainItem);
    }
        

    })
    


    this.formsAndLettersList =  finalList;
    if(callBack){
      callBack();
    }
  })

  },

  selectFormsandLatters(index ,forms){
  if( !this.formsAndLettersList[index]['selectedForSigning'] ){
    
    forms['selectedForSigning'] =true;
    this.formsAndLettersList[index]['selectedForSigning'] = true
  }else{
      forms['selectedForSigning'] =false;
    this.formsAndLetters[index]['selectedForSigning'] = false;
  }



  // alert(this.petition.formsAndLetters[index]['selectedForSigning']);

  },
  submitpetitionrequest() {

  this.$validator.validateAll().then((result) => {
      this.requestsignCommentError =false;
    if(this.comments =='' || this.comments.trim() =='' ){
        this.requestsignCommentError =true;
      
    }
    
    
    if (result) {
        var postdata = {
            petitionId: this.petitionDetails._id,
            comment: this.comments,
            subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
            typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),
            "formsAndLetters":[],
             "notifyPetitioner":false,
                "emailDocsForSign":false,  
        };
        _.forEach(this.formsAndLettersList ,(item)=>{
          if(item['selectedForSigning']){
            postdata['formsAndLetters'].push(item['_id']);
          }

        })

         postdata['notifyPetitioner'] = this.notifyPetitioner
         postdata['emailDocsForSign'] = this.emailDocsForSign
    
        if(postdata['formsAndLetters'].length >0) {
          this.loading =true;
          this.$store.dispatch("requestforsign", postdata).then((response) => {
            
            this.requestsignCommentError =false;
              this.showToster({ message: response.message, isError: false });
            this.requestsignPopup = false;
            this.reloadWallList();
            
          }) .catch((error) => {
              this.formErrors = error;
              this.showToster({ message: error, isError: true });
              this.requestsignCommentError =true;
              this.loading =false;
          });

        }else{
            this.formErrors ='';
            this.loading =false;
           this.checkFormsandLatters=true;
        }
        
    }
  });
        
    },
    
  showPetitionersign() {

      this.formErrors ="";
      this.comments ='';
      this.loading =false;
      this.notifyPetitioner =true;
      this.emailDocsForSign =false;
      this.requestsignCommentError = false;
    
      this.$validator.reset();
  let formsAndLettersActiveList = _.filter(this.formsAndLettersList ,{ "statusId":2})
  if(this.formsAndLettersList.length>0 && formsAndLettersActiveList.length>0){
      this.requestsignPopup = true;
    

  }else{
    this.showToster({ message: "Required at least one forms and letters documents to send for signature.", isError: true });
    setTimeout(() => {
      this.goToDetaillPage();
    },100)
    
    
  }
        
    }, 

  //Submit to uscis  
  getscannedCopiesList(){
           this.formErrors ='';
             this.loading =false;
             this.comments ='';
          this.scannedCopies =[];
            let finalList =[];
          let postData ={petitionId:this.petitionDetails['_id'] ,'page':1 ,'perpage':100000};
        this.$store.dispatch("getList" ,{data:postData,path:"/petition/scanned-copies-list"})
        .then(response => {
            
        let lst = [];
        
        _.forEach(response.list ,(mainItem)=>{
            mainItem = Object.assign(mainItem,{"reverse_document_versions":[] ,"mainParentId":'',showMe:true ,selectedForDownload:false});
            if(mainItem.parentId){
                mainItem['mainParentId'] = mainItem['parentId']
            }else{
                mainItem['mainParentId'] = mainItem['_id']
            }

            lst.push(mainItem);
              

        });

        let subList=[];
        
        //reverse_document_versions
        _.forEach(lst ,(mainItem)=>{

                            
            
            _.forEach(lst ,(subItem)=>{
                if( mainItem.parentId && (mainItem.parentId == subItem['parentId'] ||  mainItem.parentId == subItem['_id']   ) &&  mainItem['_id'] != subItem['_id']){
                          
                          subItem['showMe'] =false;
                          if(subList.indexOf(subItem['_id']<=-1)){
                              mainItem['reverse_document_versions'].push(subItem);
                              subList.push(subItem['_id']);

                          }
                        
                        // mainItem['showMe'] =true;
                }

            })
            
        if(mainItem.showMe){
              finalList.push(mainItem);
        }
        

          
          

        })
        

        
        this.scannedCopies =  finalList;
        if(this.scannedCopies.length > 0){
          this.submiTouscisPopup = true;
           this.$validator.reset();

        }else{
            this.submiTouscisPopup = true;
           // this.showToster({message:"Scanned Documents are not uploaded" ,isError:true});
          
             // this.goToDetaillPage();
        
          

        }
        
        
        
        }).catch((err)=>{
            this.submiTouscisPopup = true; 
              this.scannedCopies =[];
          //  this.showToster({message:"Scanned Documents are not uploaded" ,isError:true});
            //  this.goToDetaillPage();
        
            
        })

        
        

  },

  submitToUscisAction(){
        this.formErrors ='';
         let postData = {
             petitionId: this.petitionDetails['_id'],
            comment: this.comments,
            action:'SUBMIT_TO_USCIS', // "SUBMIT_TO_LAW_FIRM", // "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "SUBMIT_TO_USCIS" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED" 
            today: moment().format('YYYY-MM-DD'), // Required on Status changes to "Received RFE"
           subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
           typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),

         };
        
         this.$validator.validateAll("activityfoform").then((result) => {
            if (result) {
               this.loading =true;
               this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/manage-approval-process"})
              .then(response => {
                 this.loading =false;
                 this.showToster({message:response.message,isError:false });
                 this.submiTouscisPopup =false;
                 this.reloadWallList()
                
                
                                
              })
              .catch((error)=>{
                this.loading =false;
                this.formErrors =error;
              })
       
       

              
            }
          });
           

       

    },

    //Courier Tracking
    updateTrackingDetails() {
        // this.$vs.loading();
         this.$vs.loading.close();
        this.updateTrackingPopup = false;
        this.formErrors ='';
        this.loading =false;
        this.filesAreuploading =false;
        this.tracking.trackingId ='';

        this.tracking.documents = [];
        this.uscisdocument = [];
        this.trackingdoc = [];
        
          if(!(_.has(this.petitionDetails , 'courierTrackingCategory')) || (  _.has(this.petitionDetails , 'courierTrackingCategory') && !this.petitionDetails['courierTrackingCategory'] )){
          //petition.courierTrackingCategory
          //this.tracking['courier'] =null;
          // this.tracking['trackingId'] ='';
        }

        if(["COURIER_TRACKING" , 'UPDATE_USCIS_RECEIPT_NUMBER'].indexOf(this.petitionDetails.nextWorkflowActivity)>-1){
          this.updateTrackingPopup = true;
        }
       //  this.$vs.loading.close();
        
          
    }, 
    changedCourier() {
    if(_.has(this.tracking ,'courier') && (_.has(this.tracking['courier'] ,'code')) ){

    this.tracking = Object.assign(this.tracking ,{'courierCode':this.tracking["courier"]["code"] });

    }
    if(_.has(this.tracking ,'courier') && (_.has(this.tracking['courier'] ,'track_url')) ){

    this.tracking = Object.assign(this.tracking ,{"trackingUrl":this.tracking["courier"]["track_url"]  });

    }

          
        // this.tracking.trackingUrl = this.tracking["courier"]["code"];
        // this.tracking.courierCode = this.tracking["courier"]["code"];
    },
    updateTracking() {

    //this.petition.nextWorkflowActivity
          this.formErrors ='';
        this.loading =false;
        this.$validator.validateAll("trackingform").then((result) => {
            if (result) {
                this.tracking.petitionId = this.petitionDetails._id;
                this.tracking.action =
                    this.petitionDetails.courierTrackingCategory != "UPDATE_TRACKING_NUMBER" ?
                    "UPDATE_TRACKING_NUMBER" :
                    "UPDATE_USCIS_RECEIPT_NUMBER";
                
                this.tracking.action =this.petitionDetails.nextWorkflowActivity;
              
                if(this.trackingdoc && this.trackingdoc.length>0){
                    this.tracking = Object.assign(this.tracking,{"documents":this.trackingdoc});
                }
                

                  let tracking = _.cloneDeep(this.tracking);
                if(_.has(tracking , "courier")){

                    let courier = _.cloneDeep(tracking['courier'] );
                    if((_.has(courier  , "name"))){
                      tracking = Object.assign( tracking , { 'courier':courier['name'] });
                    }
                    if((_.has(courier  , "code"))){
                      tracking = Object.assign( tracking , { 'courierCode':courier['code'] });
                    }
                }

              this.loading =true;
           
                this.$store
                    .dispatch("updateTrackingDetails", tracking)
                    .then((response) => {
                        
                          this.formErrors ='';
                        this.showToster({ message: response.message, isError: false });
                          this.loading =false;
                        this.updateTrackingPopup = false;
                        this.reloadWallList();
                        
                    })
                    .catch((error)=>{
                        this.formErrors =error;
                      this.loading =false;
                      //this.showToster({ message: error, isError: true });

                    });

            }

        })

    },
     getCourierList(callBack=null) {
      let postdata = {};

      this.$store.dispatch("getCourierList", postdata).then((response) => {
       // alert(JSON.stringify(response))
        
        //this.courierList = response;
      });
      //tracking/list
       this.$store.dispatch("getList",{data:postdata ,path:'/tracking/courierlist'} ).then(response => {
        if(this.checkProperty(response , "list")){
          this.courierList = response.list;
        }
          if(callBack){
          callBack();
          }
        
        
      });

    },
    selectedDocuments(index, fls) {
      let docs = _.cloneDeep(fls)

      docs = docs.map(
          (item) =>
          (item = {
              name: item.name,
              file: item.file,
              url: "",
              path: "",
              mimetype: item.type,
              documentType:item.documentType?item.documentType:null
          })
      );
      
      if (docs.length > 0) {
          var self = this;
          this.filesAreuploading = true;
          let count =0;
          docs.forEach(function (doc) {
              let formData = new FormData();
              formData.append("files", doc.file);
              formData.append("secureType", "private");
              self.$store.dispatch("uploadS3File", formData).then((response) => {
                count = count+1;
                  if (response.data && response.data.result) {
                      response.data.result.forEach((urlGenerated) => {
                          doc.url = urlGenerated;
                            doc.path = urlGenerated;
                          delete doc.file;
                          self.tracking.documents = docs;
                          self.uscisdocument = docs;
                          self.trackingdoc = docs;
                          
                          
                              
                            if(parseInt(count)>=docs.length){
                              self.filesAreuploading = false;
                            

                          }
                      });
                      if(count>=docs.length){
                        self.filesAreuploading = false;

                      }
                      
                  }
                  
              });
          });
      }
    },
     remove(item, type) {
        type.splice(type.indexOf(item), 1);
        return false;
    },
    fileNameChenged(fl) {
            let fname = fl["name"];
            fname = fname.trim();
            this.isInvaliedFileName = false;
            if (!fname) {
                this.isInvaliedFileName = true;
            }
        },

    ///updateUSCISstatus

    updateUSCISstatus(){

       this.casestatus =null;
       this.uscisdocument =[];
      this.dueDate =null;
      this.receivedDate =null;
	    this.issuedDate =null;

       this.filesAreuploading =false;
            
            this.comments='';
            this.formErrors='';
            this.loading =false;
            this.updateUSCISstatusPopup = false;

            //UPDATE_USCIS_RESPONSE
        if(["UPDATE_USCIS_RESPONSE" ,].indexOf(this.petitionDetails.nextWorkflowActivity)>-1){
        this.updateUSCISstatusPopup = true;
        }

    },
    petitionApproval() {
            //alert(this.approveRejecInstructions);
            this.formErrors='';
            this.loading =false;
            let self =this;
            this.$validator.validateAll("uscisstatus").then((result) => {
                if (result) {
                  
	                
                    // this.approveRejec_Instructions="* Instructions is required"

                    let payload_data = {
                        petitionId: this.petitionDetails._id,
                        comment: this.comments,
                        action: this.casestatus.value,
                         "today": moment().format("YYYY-MM-DD"),
                         "typeName":this.petitionDetails.typeDetails.name,
                         "subTypeName":this.petitionDetails.subTypeDetails.name
                    };

                    let rfepayload = {
                        petitionId: this.petitionDetails._id,
                        comment: this.comments,
                        description: this.comments,
                        action: this.casestatus.value, //'UPDATE_USCIS_RESPONSE'
                         "today": moment().format("YYYY-MM-DD"),
                          "typeName":this.petitionDetails.typeDetails.name,
                         "subTypeName":this.petitionDetails.subTypeDetails.name
                    };
                    // "action": "QUESTIONNIRE_APPROVED" // "QUESTIONNIRE_REJECTED" / "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "READY_FOR_FILING" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED"

                    if (this.casestatus.value == "USCIS_RECEIVED_RFE") {
                        payload_data["today"] = moment().format("YYYY-MM-DD");
                        payload_data["typeName"] = this.petitionDetails.typeDetails.name;
                        payload_data["subTypeName"] = this.petitionDetails.subTypeDetails.name;

                        rfepayload["today"] = moment().format("YYYY-MM-DD");
                        rfepayload["typeName"] = this.petitionDetails.typeDetails.name;
                        rfepayload["subTypeName"] = this.petitionDetails.subTypeDetails.name;

                        rfepayload["issuedDate"] = moment(this.issuedDate).format(
                            "YYYY-MM-DD"
                        );
                        rfepayload["receivedDate"] = moment(this.receivedDate).format(
                            "YYYY-MM-DD"
                        );
                        rfepayload["dueDate"] = moment(this.dueDate).format("YYYY-MM-DD");
                      
                    }
                      rfepayload["documents"] = this.uscisdocument;
                    this.loading =true;
                    this.filesAreuploading =false;
                    rfepayload["today"] = moment().format("YYYY-MM-DD");
                    //alert(JSON.stringify(rfepayload)); 
                    this.$store
                        .dispatch("manageApproval_process", rfepayload)
                        .then((response) => {
                            if (self.casestatus.value == "USCIS_RECEIVED_RFE") {
                                self.$store.dispatch("fileRFE", rfepayload).then((response) => {
                                   
                                    //this.showMessages(response.message);
                                    self.showToster({ message:response.message , isError: false})
                                    self.updateUSCISstatusPopup = false;

                                     this.reloadWallList()
                                });
                            } else {
                             
                               
                               // this.showMessages(response.message);
                                  self.showToster({ message:response.message , isError: false})
                                self.updateUSCISstatusPopup = false;
                                 this.reloadWallList()
                            }
                              this.loading =false;
                        })
                        .catch((error) => {
                           this.loading =false;
                           this.filesAreuploading =false;
                           this.formErrors =error;
                          this.showToster({ message: error, isError: true });
                        });
                }else{
                 // this.showToster({ message:"Invalid data" , isError: true});
                }
            });
        },

   // petetioner
    getpetetioner(  approveConformpopUp =false) {
            let companyId = this.checkProperty(this.item ,"data", "companyId")
            this.$vs.loading();
            this.$store
                .dispatch("petitioner/getpetetioner", {
                    companyId: companyId
                })
                .then(response => {
                  this.approveConformpopUp =approveConformpopUp;
                   this.$vs.loading.close();   
                    this.petitioner = response;
                    this.petitioner['petitionerId'] = response['userId'];
                }).catch((err)=>{

                 this.$vs.loading.close();   
                });
   
    },
    
       
      getCompanyStatusList(){
        this.all_statusids =[];
         let postdata ={
        page:1,
        perpage: 1000,
        category: "company_status",
       
      };
        this.$store.dispatch("getMasterData" ,postdata)
        .then((res)=>{
          this.all_statusids = res['list'];
          this.all_statusids = _.filter(this.all_statusids ,(item)=>{
            return [1,2,3,4].indexOf(item['id'])>-1;

           })

        })
        .catch(()=>{

        })


      },  

      findDetailsPage(petitionId=''){

         

        if(petitionId){
          if([51].indexOf(this.getUserRoleId) >-1){
            if((
              (this.assignmentActivityes.indexOf(this.checkProperty( this.item ,'data' , 'category'))>-1)
             //|| (this.petitionToDoList.indexOf(this.checkProperty( this.item ,'data' , 'category')) >-1 && this.checkProperty( this.item ,'status' ))
             || (this.checkProperty( this.item ,'data' , 'category')== 'CASE_APPROVED' && this.checkProperty( this.item ,'status'))
             || (this.checkProperty( this.item ,"data" , "category")== "REQUEST_PETITIONER_SIGN" && this.checkProperty( this.item ,"status"))
             || (this.checkProperty( this.item ,'data' , 'category')== 'APPROVED_BY_DOC_MANAGER' && this.checkProperty( this.item ,'status'))
             || (this.checkProperty( this.item ,'data' , 'category')== 'SUBMIT_TO_USCIS' && this.checkProperty( this.item ,'status'))
             || (['UPDATE_USCIS_RECEIPT_NUMBER' ,'COURIER_TRACKING'].indexOf(this.checkProperty( this.item ,'data' , 'category'))>-1 && this.checkProperty( this.item ,'status'))
             || (['UPDATE_USCIS_RESPONSE'].indexOf(this.checkProperty( this.item ,'data' , 'category'))>-1 && this.checkProperty( this.item ,'status'))
            )){

              this.$router.push("/petition-details/"+petitionId);

            }else{
                this.$router.push("/questionnaire/"+petitionId);
            }
          
          }else{
            this.$router.push("/petition-details/"+petitionId);
          }
        }

      }
    

/*Action Methods End*/

  },
   mounted() {

    //  this.$store.dispatch("commonAction" ,{data:{} ,path:"/masterdata/list-for-dashboard"}).then((res)=>{
      


    //     this.allCaseTypes = this.checkProperty( res,'petitionTypeList');
    //     this.caseStatusList = this.checkProperty( res,'petitionStatusList');
    //     this.userRolelist = this.checkProperty( res,'userRoleList');
    //     this.all_statusids = this.checkProperty( res,'companyStatusList');
    //     this.all_statusids = _.filter(this.all_statusids, (item) => {
    //         return [1, 2, 3, 4].indexOf(item["id"]) > -1;
    //     });
        

    // }).catch((error)=>{
    // }) 

    
    this.viewType='LIST';
    this.getStats =false;
    setTimeout(() =>{
      
     if( [ 'INVOICE', 'CASE_BY_STATUS' ,'LCA'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1 && this.checkProperty(this.$store.state ,'dashBoardWIdgetsListOrChart')){
        let findObj = _.find(this.$store.state['dashBoardWIdgetsListOrChart'] ,{"wedgetId":this.widgetData['_id']});
        if(this.checkProperty(findObj  ,'viewType' ) =='CHART'){
          this.viewType='CHART';
          this.getStats =true;
        }
           
       } 
       

      if(this.checkProperty(this.widgetData,'tabName' )){
        this.tabName = this.checkProperty(this.widgetData,'tabName' );
       if(['UPDATES'].indexOf(this.checkProperty(this.widgetData ,'code' ))>-1){
        
          this.tabName ='petitioner';

          if([3,4].indexOf(this.getUserRoleId)>-1 && this.getTenantTypeId ==2){
             
              this.tabName ='internal_user';
           }else  if([50].indexOf(this.getUserRoleId)>-1){
            this.tabName ='beneficiary';
          } else if([51].indexOf(this.getUserRoleId)>-1){
            this.tabName ='beneficiary';
          }
       } 
      
      }

     if(this.listForDashboard){
      this.allCaseTypes = this.checkProperty( this.listForDashboard,'petitionTypeList');
        this.caseStatusList = this.checkProperty( this.listForDashboard,'petitionStatusList');
        this.userRolelist = this.checkProperty( this.listForDashboard,'userRoleList');
        this.all_statusids = this.checkProperty( this.listForDashboard,'companyStatusList');
        this.all_statusids = _.filter(this.all_statusids, (item) => {
            return [1, 2, 3, 4].indexOf(item["id"]) > -1;
        });

     }


      if(this.checkProperty(this.widgetData ,"code") ){
         if(this.checkProperty(this.wedgetHights , this.checkProperty(this.widgetData ,'height'))){
           this.setHeighet(this.wedgetHights[this.widgetData['height'] ]);
        }
        this.getWigetsData();
      }

    })

   }

  

  
  
  
};
</script>
