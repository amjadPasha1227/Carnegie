<template>
  <div class="added-widgets w-full">
    <div class="deadline-widgets" >
     
     <div class="header">


        <div class="title">
          <h4>Actions </h4>
        </div>
        <VuePerfectScrollbar  ref="mainSidebarPs"	
        class="scroll-area--main-sidebar"	
        :settings="settings"	
        
      >
        <div class="widget-filters" >
          <button class="filter_btn active"  ><em>To-Do</em><span >0</span></button>
          <button class="filter_btn"    ><em>Cases</em><span > 0</span></button>
          <button class="filter_btn"  ><em>Tasks</em></button>
          
        </div>
        </VuePerfectScrollbar>
         <div class="actions">
          <ul>
             <li v-if="false" >
              <template  >
                <figure><img src="@/assets/images/list.png" alt="List" width="24" ></figure>
              
              </template>
               <template v-if="false" >
                <figure><img src="@/assets/images/chart.png" alt="calendar-img" width="24" ></figure>
               </template>
              
              
             </li>
            <li ><figure><img src="@/assets/images/funnel.svg" alt="calendar-img" width="14" height="14"></figure></li>
            <li class="has-dropdown"><figure><more-horizontal-icon size="1.5x" class="custom-class" style="opacity: 0.6;"></more-horizontal-icon></figure>
            <div class="height-dropdown">
                 
                <ul class="subdropdown">
               
                  <li   ><a><figure><img src="@/assets/images/duplication.png" alt="duplicate-img" width="15"></figure>Duplicate</a></li>
                  <li><a class="text-danger"><figure><img src="@/assets/images/delete.png" alt="trash-img" width="15"></figure>Delete</a></li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
        </div>
      <VuePerfectScrollbar	
        ref="mainSidebarPs"	
        class="scroll-area--main-sidebar"	
        :settings="settings"	
        @ps-scroll-y="psSectionScroll"	
      >
       <div class="widget-content">
         <NoDataFound
            ref="NoDataFoundRef"
            :loading="isListLoading"
            heading="No Data"
            type="support"
            />
        </div>

         
           
      </VuePerfectScrollbar>
    </div>
    
     
  
  </div>
</template>
 
 
<script>
 import VuePerfectScrollbar from "vue-perfect-scrollbar";
 import Multiselect from "vue-multiselect-inv";
 import { MoreHorizontalIcon } from 'vue-feather-icons'
import NoDataFound from "@/views/common/noData.vue";
import moment from "moment";

  export default {
    components: {
      NoDataFound,
      VuePerfectScrollbar,
      Multiselect,
      MoreHorizontalIcon,
     // widgetHeader
    },
    data: function () {
      return {
      groupedlist:[],  
      todayCaseList: [],
      tomorrowCaseList : [],
      missedDeadLineCaseList : [],

        popupFilter:false,
        value: null,
        options: [],
        primary:'', 


        selectedHeight:'small',
         isListLoading:true,
        widgetsItems:null,
        settings: { 
          swipeEasing: false,
        },
        duplicating:false,
        widGetCode:'DEADLINE'
        
        
      };
     
    },
    props: { 
      availableEmptyColumns:0,
      rowExistingColumnsLength:0,
      columnId:'',
      rowId:'',
    widgetData:null,
     wedgetHights:{
       
        "1X":'small',
        "1.5":"medium",
        "2X":"large"
      },
      tabName:'CASES',
      selectedBranch:null,
      dueDatekey:'deadlineDate'

   },
    methods:{

      changeTab(tab){
        
      
         
       },


      
      deleteColumn(data){
       
       

      },
      openAddFilterDialog(data){

      

      },
    
      
     
   

   
  },
   mounted() {

     this.updateLoading(true); 

    

  

  
  
  
   }

  }
</script>
