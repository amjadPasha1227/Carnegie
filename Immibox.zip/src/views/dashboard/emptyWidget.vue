<template>
  <div class="db-widget-block">
    <!-----@click="addNewColumnToRow()"-->
 
    <div class="db-empty-widget" @click="addNewColumnToRow()" >
     
      
          
              <figure v-if="checkProperty(widgetData ,'code') =='ACTION'"><img src="@/assets/images/db-widgets/actions-img.svg"></figure>
              <figure v-else-if="checkProperty(widgetData ,'code') =='DEADLINE'"><img src="@/assets/images/db-widgets/deadlines-img.svg"></figure>
             <figure v-else-if="checkProperty(widgetData ,'code') =='CASE_BY_STATUS'"><img src="@/assets/images/db-widgets/myCases-img.svg"></figure>
             <figure v-else-if="checkProperty(widgetData ,'code') =='CASE_STATS_BY_BRANCH'"><img src="@/assets/images/db-widgets/branchData-img.svg"></figure>
              <figure v-else-if="checkProperty(widgetData ,'code') =='CLIENT'"><img src="@/assets/images/db-widgets/customers-img.svg"></figure>

             <figure v-else-if="checkProperty(widgetData ,'code') =='BENEFICIARY'"><img src="@/assets/images/db-widgets/Beneficiaries-img.svg"></figure>
             <figure v-else-if="checkProperty(widgetData ,'code') =='LCA'"><img src="@/assets/images/db-widgets/LCA's-img.svg"></figure>
             <figure v-else-if="checkProperty(widgetData ,'code') =='INVOICE'"><img src="@/assets/images/db-widgets/invoices-img.svg"></figure>
             <figure v-else-if="checkProperty(widgetData ,'code') =='SUPPORT_TICKET'"><img src="@/assets/images/db-widgets/supportTickets-img.svg"></figure>
             <figure v-else-if="checkProperty(widgetData ,'code') =='PENDING_CASE_STATS'"><img src="@/assets/images/db-widgets/pendingCasesStats-img.svg"></figure>
             <figure v-else-if="checkProperty(widgetData ,'code') =='CURRENT_STATUS_OF_CASE'"><img src="@/assets/images/db-widgets/currentStatusofCases-img.svg"></figure>
             <figure v-else-if="checkProperty(widgetData ,'code') =='TASK'"><img src="@/assets/images/db-widgets/myTasks-img.svg"></figure>
            <figure v-else ><img src="@/assets/images/pages/empty_widget.svg"></figure>      
           
           <!---<figure ><img src="@/assets/images/db-widgets/missedDeadline-img.svg"></figure>
          <figure ><img src="@/assets/images/db-widgets/updates-img-img.svg"></figure>
          --> 
          
         
          <h2>{{checkProperty(widgetData ,'name' )}}</h2>
           <p >{{checkProperty(widgetData ,'description' )}}
           <a v-if="loadedFromEmpty && rowId" class="TCU" >add a new widget. </a>
           </p>
      
     
     <!---<slot name="footer"></slot>-->
     
    </div>
  
  </div>
</template>
 
 
<script>
 

 
 
export default {
  props: { 
    widgetData:null,
    rowId: '',
    loadedFromEmpty:false  
  },
  components: {
 
  },
  data: function () {
    return {
      widgetsItems:[],
       
    };
  },
  methods:{

    addNewColumnToRow(){
      this.$emit("addNewColumnToRow" ,this.rowId);

    }
    
  },
   mounted() {
   
   

   }

  

  
  
  
};
</script>
