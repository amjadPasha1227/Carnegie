<template>
  <div>
    <!----
      v-bind:style="{ background: getBackGroundColor(wallItem)  }"
    :style="{background: `rgba(var(--vs-${getBackGroundColor(wallItem)}),.15)`}"
    
    -->
    <template v-for="(wallItem, ind) in list">
  <div :category="checkProperty( wallItem ,'data' , 'category') " :class="{'updates-widget':checkProperty(widgetData ,'code')=='UPDATES'}"  class="widget-task-list"  :key="ind">
     
      <div class="task-details"  >
        <!----  <h4>Case Submitted dfsdfdsf</h4>-->
       
          <p><a @click="item=wallItem;goToDetaillPage()">{{checkProperty( wallItem ,"title" )}}</a></p> 
          <div class="discription">
            <p><a @click="item=wallItem;goToDetaillPage()">{{checkProperty( wallItem ,"description" )}}</a></p>
            <template v-if="( checkProperty(wallItem ,'type') =='activity' || checkProperty(wallItem ,'type') =='todo' || checkProperty(widgetData ,'code')=='UPDATES')&& checkProperty( wallItem ,'createdByName' )">
              <p>
                <small>
                 {{ checkProperty(wallItem ,'type') =='activity'?'Updated By':'Created By' }} <strong>{{ wallItem['createdByName'] }}</strong><template v-if="checkProperty( wallItem ,'createdByRoleName' )"> ({{checkProperty( wallItem ,'createdByRoleName' )}})</template>
                 </small>
              </p>
            </template> 

          </div>
          <!-- <div class="documents" v-if="checkProperty( wallItem , 'data','documents')">
            <template v-for="(fItem, findex) in checkProperty( wallItem , 'data','documents')">
              <span :key="findex" v-tooltip.top-center="fItem.name"   v-on:click.stop.prevent="downloads3file(fItem)"  class="note pointer">
                <docType  :item="fItem" />
              </span>
            </template>
          </div> -->
          
          <div class="documents" v-if="checkProperty( wallItem , 'data','documents')">
            <template v-for="(fItem, findex) in checkProperty( wallItem , 'data','documents')" >
              <span :key="findex" v-tooltip.top-center="checkProperty(fItem ,'name')"   v-on:click.stop.prevent="downloads3file(fItem)"  class="note pointer cursor">
                <docType  :item="fItem" />
                
              </span>
            </template>
          </div>
      </div>
      <div class="task-status " v-if=" (checkProperty(wallItem ,'type') =='todo' || checkProperty(widgetData ,'code')=='UPDATES') "  >
              
              <ul v-if=" checkProperty(wallItem ,'type') =='todo'" :wallItemAction="checkProperty( wallItem ,'action')"  :wallItemDataCategory="checkProperty( wallItem ,'data' , 'category') " :action="checkProperty( wallItem ,'action' )">
                <template v-if="checkProperty( wallItem ,'data' , 'navigationKey') !='CAP_DETAILS'">
                <!--
                  <li>
                  <a href="#" class="approve-btn"></a>
                  </li>
                  <li>
                  <a href="#" class="close-btn"></a>
                  </li>
                  <li>
                  <a href="#" class="upload-btn"></a>
                  </li>
                  --> 
                  <li v-if="(['ASSIGN_CUSTOM_CASE_NO'].indexOf(checkProperty( wallItem ,'data' , 'category'))>-1)" v-on:click.stop.prevent="item=wallItem;fetchPetitionDetails(wallItem,openSetCaseCodePopup ,'openSetCaseCodePopup')"> <button  class="assignCaseNumber_btn" ><span><img src="@/assets/images/icons/actions/assignCaseNumber_btn.svg" /></span><em>Assign Case Number</em></button></li>
                  <li v-if="(assignmentActivityes.indexOf(checkProperty( wallItem ,'data' , 'category'))>-1)" v-on:click.stop.prevent="item=wallItem;fetchPetitionDetails(wallItem,openPopup ,'openPopup')"> <button  class="assign_btn assign-test" ><span><img src="@/assets/images/icons/actions/assign_btn.svg" /></span><em>Assign</em></button></li>
                  <li :addClas="addClass()" v-if="((checkProperty( wallItem ,'data' , 'category')== 'CASE_APPROVED' && checkProperty( wallItem ,'status')))" v-on:click.stop.prevent="item=wallItem;fetchPetitionDetails(wallItem,openapproveCasePopup ,'openapproveCasePopup')" > <button  class="approveCase_btn" ><span><img src="@/assets/images/icons/actions/approveCase_btn.svg" /></span>
                    <em class="PR" v-if="checkProperty( wallItem ,'data','type')==3 && [16,17].indexOf(checkProperty(wallItem ,'data','subType')>-1)">
                      Paralegal Review
                    </em>
                    <em class="CR" v-else>Complete Review</em></button>
                  </li>
                  <li :addClas="addClass()" v-if="(checkProperty( wallItem ,'data' , 'category')== 'APPROVED_BY_DOC_MANAGER' && checkProperty( wallItem ,'status'))" v-on:click.stop.prevent="item=wallItem;fetchPetitionDetails(wallItem,openApproveOrRejectDocs,'openApproveOrRejectDocs')" > <button  class="approveDocuments_btn"><span><img src="@/assets/images/icons/actions/approveDocuments_btn.svg" /></span><em>Approve Documents</em></button></li>
                  
                  
                  
                   
                  

                   <li  v-if="wallItem['action']=='UPLOAD_SCANNED_COPY'" :addClas="addClass()"  v-on:click.stop.prevent="selectedRfeAction='UPLOAD_SIGNED_DOCUMENTS';item=wallItem;item=wallItem;fetchPetitionDetails(wallItem,rfeActions,'rfeActions')" ><button  class="upload_btn" >
                    <span><img src="@/assets/images/icons/actions/upload_btn.svg" /></span>
                    <em class="USD">Upload Signed Documents</em>
                   </button>
                  </li>
                   
                  <li  v-if="['SUPERVISOR_FORMS_REVIEW','REQUEST_PETITIONER_SIGN'].indexOf(wallItem['action'])>-1" :addClas="addClass()"  v-on:click.stop.prevent="item=wallItem;item=wallItem;fetchPetitionDetails(wallItem,showPetitionersign)" ><button  class="sendForSigning_btn" ><span><img src="@/assets/images/icons/actions/sendForSigning_btn.svg" /></span>
                    <template v-if="wallItem['action'] =='SUPERVISOR_FORMS_REVIEW'">
                      <em class="SR" >Supervisory Review</em>
                  </template>
                    <template v-else>
                    <em Class="SS" v-if="getTenantTypeId==2" >Send for Signing</em>
                    <em Class="SS" v-else>Send for Petitioner Signature</em>
                  </template>
                   </button>
                  </li>
  
                  
  
                  <li :addClas="addClass()" v-if="(checkProperty( wallItem ,'action' )== 'SUBMIT_TO_USCIS' && checkProperty( wallItem ,'status'))" v-on:click.stop.prevent="item=wallItem;item=wallItem;fetchPetitionDetails(wallItem,getscannedCopiesList ,'getscannedCopiesList')"  > <button  class="submitToUSCIS_btn" ><span><img src="@/assets/images/icons/actions/submitToUSCIS_btn.svg" /></span><em>Submit to USCIS</em></button></li>
                  <li :addClas="addClass()" v-if="((['UPDATE_USCIS_RECEIPT_NUMBER' ,'COURIER_TRACKING'].indexOf(checkProperty( wallItem ,'data' , 'category'))>-1 && checkProperty( wallItem ,'status')))" v-on:click.stop.prevent="item=wallItem;fetchPetitionDetails(wallItem,updateTrackingDetails)" > <button  class="caseFiled_btn" ><span><img src="@/assets/images/icons/actions/caseFiled_btn.svg" /></span><em>Case Filed</em></button></li>
                  <li :addClas="addClass()" v-if="(['UPDATE_USCIS_RESPONSE'].indexOf(checkProperty( wallItem ,'data' , 'category'))>-1 && checkProperty( wallItem ,'status'))" v-on:click.stop.prevent="item=wallItem;fetchPetitionDetails(wallItem,updateUSCISstatus ,'updateUSCISstatus')"  ><button  class="updateUSCISStatus_btn" ><span><img src="@/assets/images/icons/actions/updateUSCISStatus_btn.svg" /></span>
                    <em class="US_doc" v-if="checkProperty( wallItem ,'data','autoUscisStatusUpdate')==true">
                      Upload USCIS Documents
                  </em>
                  <em class="US_status" v-else>
                      Update USCIS Status 
                  </em>
                </button>
                </li>

                <!-----RFE ACTIONS-->
                <template>
                <!----- rfePraperResDocs:false,//RFE_PREPARE_RESPONSE_DOCS
                        rfeCaseApproved:false,//RFE_CASE_APPROVED
                        rfeReqPetSign:false, //RFE_REQUEST_PETITIONER_SIGN
                        rfeSubmitToUsis:false,  //SUBMIT_TO_USCIS 
                        rfecourierTeacking:false,//RFE_COURIER_TRACKING
                        rfeUpdateUscIsReceiptNumber:false,//RFE_UPDATE_USCIS_RECEIPT_NUMBER 
                        rfeUpdateUSCISstatusPopup:false,// RFE_UPDATE_USCIS_RESPONSE
                ---->
                
                <li  v-if="['RFE_PREPARE_RESPONSE_DOCS'].indexOf(checkProperty( wallItem ,'data' , 'category'))>-1" :addClas="addClass()"  v-on:click.stop.prevent="selectedRfeAction='RFE_PREPARE_RESPONSE_DOCS';item=wallItem;item=wallItem;fetchPetitionDetails(wallItem,rfeActions,'rfeActions')" ><button  class="sendForSigning_btn" ><span><img src="@/assets/images/icons/actions/sendForSigning_btn.svg" /></span>
                    
                    <em Class="rfe-res-docs" >Prepare RFE Response Documents</em>
                    
                   </button>
                  </li>

                <li  v-if="[50].indexOf(getUserRoleId)<=-1 && ['RFE_REQUEST_PETITIONER_SIGN'].indexOf(checkProperty( wallItem ,'data' , 'category'))>-1" :addClas="addClass()"  v-on:click.stop.prevent="selectedRfeAction='RFE_REQUEST_PETITIONER_SIGN';item=wallItem;item=wallItem;fetchPetitionDetails(wallItem,rfeActions,'rfeActions')" ><button  class="sendForSigning_btn" ><span><img src="@/assets/images/icons/actions/sendForSigning_btn.svg" /></span>
                  
                   
                    <em Class="SS" v-if="getTenantTypeId==2" >Send for Signing</em>
                    <em Class="send-for-pet-sign" v-else>Send for Petitioner Signature</em>
                    
                   </button>
                  </li>

                  <li :addClas="addClass()" v-if="((checkProperty( wallItem ,'data' , 'category')== 'RFE_CASE_APPROVED' && checkProperty( wallItem ,'status')))" v-on:click.stop.prevent="selectedRfeAction='RFE_CASE_APPROVED';item=wallItem;fetchPetitionDetails(wallItem,rfeActions ,'rfeActions')" > <button  class="approveCase_btn" ><span><img src="@/assets/images/icons/actions/approveCase_btn.svg" /></span>
                    <em class="CR" >Complete Review</em></button>
                    
                  </li>

                  <li :addClas="addClass()" v-if="(checkProperty( wallItem ,'action' )== 'RFE_SUBMIT_TO_USCIS' && checkProperty( wallItem ,'status'))" v-on:click.stop.prevent="selectedRfeAction='RFE_SUBMIT_TO_USCIS';item=wallItem;item=wallItem;fetchPetitionDetails(wallItem,rfeActions ,'rfeActions')"  > <button  class="submitToUSCIS_btn" ><span><img src="@/assets/images/icons/actions/submitToUSCIS_btn.svg" /></span><em>Submit to USCIS</em></button></li>
                  <li :addClas="addClass()" v-if="((['RFE_UPDATE_USCIS_RECEIPT_NUMBER' ,'RFE_COURIER_TRACKING'].indexOf(checkProperty( wallItem ,'data' , 'category'))>-1 && checkProperty( wallItem ,'status')))" v-on:click.stop.prevent="selectedRfeAction=checkProperty( wallItem ,'data' , 'category');item=wallItem;fetchPetitionDetails(wallItem,rfeActions,'rfeActions')" > <button  class="caseFiled_btn" ><span><img src="@/assets/images/icons/actions/caseFiled_btn.svg" /></span><em>Case Filed</em></button></li>
                  <li :addClas="addClass()" v-if="(['RFE_UPDATE_USCIS_RESPONSE'].indexOf(checkProperty( wallItem ,'data' , 'category'))>-1 && checkProperty( wallItem ,'status'))" v-on:click.stop.prevent="selectedRfeAction='RFE_UPDATE_USCIS_RESPONSE';item=wallItem;fetchPetitionDetails(wallItem,rfeActions ,'rfeActions')"  ><button  class="updateUSCISStatus_btn" ><span><img src="@/assets/images/icons/actions/updateUSCISStatus_btn.svg" /></span>
                     <em class="US_status" >
                        Update USCIS Status 
                    </em>
                </button>
                </li>
                </template>
  
  
  
  
  
                  <template v-if="(checkProperty( wallItem ,'data' , 'category')== 'TASK_CREATE' ) && wallItem">
                    <li :addClas="addClass()" :disabled="accepting" @click="openAcceptForm(true ,'TASK_ACCEPT' ,wallItem) ;error=''" v-if="  (isAssignedUser(wallItem) && (!checkisAccepted(wallItem) && !checkisRejected(wallItem)))" ><button class="accept_btn" ><span><img src="@/assets/images/icons/actions/accept_btn.svg" /></span><em>Accept</em></button></li>
                    <li :addClas="addClass()" :disabled="accepting" @click="openAcceptForm(true ,'TASK_REJECT' ,wallItem);error=''"  v-if=" (isAssignedUser(wallItem) && (!checkisAccepted(wallItem) && !checkisRejected(wallItem)))" ><button class="reject_btn" ><span><img src="@/assets/images/icons/actions/reject_btn.svg" /></span><em>Reject</em></button></li>
                  </template>
  
  
                  <template v-if="(checkProperty( wallItem ,'data' , 'category')== 'TENANT_CREATED' && checkProperty( wallItem ,'status'))">
  
                  <li  :addClas="addClass()" v-on:click.stop.prevent="item=wallItem;openTenantApprovepopup(2,'Approve')" ><button class="approve_btn"><span><img src="@/assets/images/icons/actions/approve_btn.svg" /></span><em>Approve</em></button></li>
                  <li :addClas="addClass()" v-on:click.stop.prevent="item=wallItem;openTenantApprovepopup(3,'Reject')" ><button class="reject_btn"><span><img src="@/assets/images/icons/actions/reject_btn.svg" /></span><em>Reject</em></button></li>
                  </template>
                  <template v-if="(['COMPANY_CREATED'].indexOf(checkProperty( wallItem ,'data' , 'category'))>-1 && checkProperty( wallItem ,'status'))" >
  
                  <template v-if="checkProperty(petitioner , 'statusDetails' , 'id')<=1">
  
                      <li :addClas="addClass()" v-on:click.stop.prevent="item=wallItem;openApprovepopup(2,'Approve')"><button class="approve_btn"><span><img src="@/assets/images/icons/actions/approve_btn.svg" /></span><em>Approve</em></button></li>
                      <li :addClas="addClass()" v-on:click.stop.prevent="item=wallItem;openApprovepopup(3,'Hold')"><button class="hold_btn"><span><img src="@/assets/images/icons/actions/hold_btn.svg" /></span><em>Hold</em></button></li>
                      <li :addClas="addClass()" v-on:click.stop.prevent="item=wallItem;openApprovepopup(4 ,'Reject')"><button class="reject_btn"><span><img src="@/assets/images/icons/actions/reject_btn.svg" /></span><em>Reject</em></button></li>
  
                  </template>
  
                  </template>
                </template>
                  <li v-if="checkProperty(wallItem ,'type') =='todo'" class="delete_wall_btn" @click="conformDeleteWall(wallItem)">Delete</li>
              </ul>

          <p :title="wallItem.createdOn | formatDateTime"  v-if="checkProperty(widgetData ,'code')=='UPDATES' && checkProperty( wallItem,'createdOn')" class="task-timing">{{ checkProperty( wallItem,'createdOn') | timeago}}</p>               
          <p  :title="wallItem.createdOn | formatDateTime"  v-else-if="checkProperty( wallItem,'createdOn')" class="task-timing">{{ checkProperty( wallItem,'createdOn') | timeago}}</p>
      </div>
  </div> 
</template>
  
   <vs-popup class="holamundo main-popup" title="Assign Case Number" :active.sync="setCode">
        <form data-vv-scope="newCaseNumberForm">
        <div class="popup-accounts-content edit_password" v-if="setCode">       
         
          <div class="form-container padb20"  @click="formerrors=''">
            <div class="form_group" >
              <!-- <i class="placeholder-icon IP-hide-1"></i> -->
              <label class="form_label">Case Number<em>*</em></label>
              <vs-input
                type="text" 
                v-validate="'required|min:4|max:30'"
                oninput="this.value = this.value.replace(/[^a-z A-Z 0-9 -_]/g, '');"
                data-vv-as="Case Number"
                name="caseNumber"               
                v-model="newCaseCode"
                placeholder="Case Number"
                class="w-full no-icon-border"
                ref="caseCode"
              />
              <span class="text-danger text-sm" v-show="errors.has('newCaseNumberForm.caseNumber')" >{{ errors.first("newCaseNumberForm.caseNumber") }}<br
            /></span>
            </div>
            <!---
            
            <div class="form_group">
              
              <label class="form_label">Conform Case Number<em>*</em></label>
              <vs-input
                type="text" 
                v-validate="'required|checkConformCaseNum:caseCode'"
                data-vv-as="Conform Case Number"
                 placeholder="Conform Number"
                v-model="confCaseCode"
                name="newCaseCode"
                class="w-full no-icon-border"
              />
               <span class="text-danger text-sm" v-show="errors.has('newCaseNumberForm.newCaseCode')">{{
              errors.first("newCaseNumberForm.newCaseCode")
            }}</span>
            </div>
            -->
            
         
  
           <div class="text-danger text-sm formerrors" v-show="formerrors">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
            >
              {{ formerrors }} 
            </vs-alert>
          </div>
           </div> 
          <div class="popup-footer relative"> 
            <!-- <div class="password-count">
            <i class="icon IP-lock"></i> Password must contain 6 to 15 characters
          </div> -->
          <div class="d-flex">
          <vs-button color="dark" @click="setCode=false ,settingCaseNumber=false" class="cancel" type="filled">Cancel</vs-button>
        
              <vs-button class="save" type="filled" @click="SetCaseCodeAction" :disabled="settingCaseNumber">
               <figure v-if="settingCaseNumber" class="loader"><img src="@/assets/images/main/loader.gif" /></figure>
              Assign</vs-button> 
          </div>
          </div>
        </div> 
        </form>
         </vs-popup>
  
  
  
        <template  v-if="(assignmentActivityes.indexOf(checkProperty( item ,'data' , 'category'))>-1)">
         <assignActivity v-if="showPopup"  @hideMe="showPopup=false" @updatepetition="showPopup=false;reloadWallList()" :petitionDetails="petitionDetails" :popUpTitle="getlableName()" :ACTIVITYCODE="checkProperty( item ,'data' , 'category')" />
        </template>
        <!----Petition Submit to Reviewer---->
        <!----
          <vs-popup :active.sync="showPopup"
          v-if="(assignmentActivityes.indexOf(checkProperty( item ,'data' , 'category'))>-1)"
          class="holamundo main-popup"
          :title="getlableName()"
          
        >
          <form data-vv-scope="assignmentForm" class="relative">
      
            <div class="popup_info" v-if="usersList.length>0" >
              <span><eye-icon size="1.5x" class="custom-class"></eye-icon></span>
              <div class="info_list">
                <ul v-if="usersList.length>0">
                <template v-for="(usr ,usrIndx) in addReviewrsRolesList()">
                 <li :key="usrIndx">{{usr['roleName']}}</li>
                </template>
                  
                </ul> 
              </div>
            </div>
            <div class="form-container" @click="formErrors=''">
              <div class="vx-row">
                <div class="vx-col w-full">
                  <div class="form_group">
                    <label for class="form_label mb-0">User<em>*</em></label>
                    <div class="con-select w-full select-large">
                      <multiselect
                        name="users"
                        v-model="selectedUser"
                        :close-on-select="true"
                        v-validate="'required'"
                        :multiple="false"
                        :show-labels="false"
                        @input="selectUesr"
                        label="name"
                        data-vv-as="User"
                        placeholder="Select User"
                        :options="usersList"
                        :searchable="true"
                        :allow-empty="false"
                    >
                    <template slot="selection" slot-scope="{ values, isOpen }">
                                                        <span
                                                        class="multiselect__selectcustom"
                                                        v-if="values.length && !isOpen"
                                                        >{{ values.length }} selected</span
                                                        >
                                                        <span
                                                        class="multiselect__selectcustom"
                                                        v-if="values.length && isOpen"
                                                        ></span>
                                                    </template>
                      </multiselect>
                    </div>
                  </div>
  
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('assignmentForm.users')"
                  >{{ errors.first("assignmentForm.users") }}</span>
                </div>
                
                <div class="vx-col w-full">
                  <div class="form_group mb-4">
                  <label class="form_label">Comments</label>
                  
                  <ckeditor   data-vv-as="Comments"
                    v-validate="'required'"
                    v-model="comments"
                    name="comments" 
                    class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>
  
  
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('assignmentForm.comments')"
                  >{{ errors.first("assignmentForm.comments") }}</span>
                </div>
                </div>
              </div>
              <div class="text-danger text-sm formerrors" v-show="formErrors">
              
                <vs-alert
                  color="warning"
                  class="warning-alert reg-warning-alert no-border-radius"
                  icon-pack="IntakePortal"
                  icon="IP-information-button"
                  active="true"
                >{{ formErrors }}</vs-alert>
                
              </div>
            </div>
            
            
           
            <div class="popup-footer">
             <span class="loader" v-if="loading" ><img src="@/assets/images/main/loader.gif"></span>
             <vs-button
            
                color="success"
                v-on:click.stop.prevent="showPopup =false ;"
                class="btn cancel"
                type="filled"
              >Cancel </vs-button>
              <vs-button
              :disabled="loading"
                color="success"
                v-on:click.stop.prevent="submitAction()"
                class="save"
                type="filled"
              >Assign </vs-button>
            </div>
          </form>
        </vs-popup>
      -->
     
  
     <!----Case Approve
      <template v-if="checkProperty( wallItem ,'data','type')==3 &&  checkProperty( wallItem ,'data','subType')==16">
                      Paralegal Review
                    </template>
                    <template v-else>
                      Approve Case
                    </template>
      ---->
        <vs-popup  :active.sync="approveCasePopup"
  
        class="holamundo main-popup"
        :title="(checkProperty( item ,'data','type')==3 &&  [16,17].indexOf(checkProperty(item ,'data','subType')>-1))?'Paralegal Review':'Complete Review'" 
       
      >
  
        <form data-vv-scope="approvecase">
  
          <div class="form-container" >
            <div class="vx-row">
              
              <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Comments</label>
                <!-- <vs-textarea
                  data-vv-as="Note"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments"
                
                  class="w-full"
                /> -->
                <ckeditor data-vv-as="Note"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments"
                
                  class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>
  
                <span
                  class="text-danger text-sm"
                  v-show="errors.has('approvecase.comments')"
                >{{ errors.first("approvecase.comments") }}</span>
              </div>
              </div>
            </div>
            <div class="text-danger text-sm formerrors" v-show="formErrors">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >{{ formErrors }}</vs-alert>
            </div>
          </div>
          <div class="popup-footer">
            <span class="loader" v-if="loading" ><img src="@/assets/images/main/loader.gif"></span>
            <vs-button
            
                color="success"
                v-on:click.stop.prevent="approveCasePopup =false "
                class="btn cancel"
                type="filled"
              >Cancel </vs-button>
            <vs-button
                :disabled="comments =='' || comments.trim() =='' || loading" 
              color="success"
              v-on:click.stop.prevent="caseApproveCaseAction()"
              class="save"
              type="filled"
            >
          
            <template v-if="checkProperty( item ,'data','type')==3 &&  checkProperty( item ,'data','subType')==16">
                      Review
                    </template>
                    <template v-else>
                      Complete Review 
                    </template>
          </vs-button>
          </div>
        </form>
              
        </vs-popup>
  
        <!--- Approve or rejet Documents-->
         <vs-popup  :active.sync="approveOrRejectDocs"
       
          class="holamundo main-popup"
          title=" Approve or reject documents"
         
        >
        
          <form data-vv-scope="approveOrRejectDocsForm">
        
            <div class="form-container" >
              <div class="vx-row">
               
                <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Comments</label>
                  <!-- <vs-textarea
                  data-vv-as="Note"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments"
                
                  class="w-full"
                  /> -->
                  <ckeditor data-vv-as="Note"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments"
                
                  class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>
  
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('approveOrRejectDocsForm.comments')"
                  >{{ errors.first("approveOrRejectDocsForm.comments") }}</span>
                </div>
                </div>
              </div>
              <div class="text-danger text-sm formerrors" v-show="formErrors">
                <vs-alert
                  color="warning"
                  class="warning-alert reg-warning-alert no-border-radius"
                  icon-pack="IntakePortal"
                  icon="IP-information-button"
                  active="true"
                >{{ formErrors }}</vs-alert>
              </div>
            </div>
            <div class="popup-footer">
             <span class="loader" v-if="loading" ><img src="@/assets/images/main/loader.gif"></span>
             <vs-button
            
                color="dark"
                v-on:click.stop.prevent="approveOrRejectDocs =false "
                class="btn cancel"
                type="filled"
              >Cancel </vs-button>
  
              <vs-button
                 :disabled="comments =='' || comments.trim() =='' || loading" 
                color="success"
                v-on:click.stop.prevent="approveOrRejectDocsAction('REJECT_BY_DOC_MANAGER')"
                class="save"
                type="filled"
              >Reject</vs-button>
              <vs-button
                 :disabled="comments =='' || comments.trim() =='' || loading" 
                color="success"
                v-on:click.stop.prevent="approveOrRejectDocsAction('APPROVED_BY_DOC_MANAGER')"
                class="save"
                type="filled"
              >Approve</vs-button>
            </div>
          </form>
               
        </vs-popup>
  
        <!----Tenant Approve Or Reject --->
        <vs-popup class="holamundo main-popup" :title="popuptntTxt+' Customer'" :active.sync="approveTenantConformpopUp">
        <div class="form-container">
          
          <div class="vx-row" v-if="[2].indexOf(selectedtenantStatus)>-1" >
            <div class="vx-col w-full">
            <p>{{tntActionText}}</p>
              
            </div>
                      
          </div>
  
          <!--------------If reject take comment------->
         
            <div v-if="[3,4,5].indexOf(selectedtenantStatus)>-1" class="vx-row mar0 ">
              <label class="custom-label mb-0 mt-0">Write a comment</label>
              <!-- <vs-textarea v-model="comments"  class="w-full" /> -->
              <ckeditor  v-model="comments"  class="w-full" :editor="editor" :config="editorConfig"></ckeditor>
  
           
            </div>
  
            <div class="text-danger text-sm formerrors" v-show="formErrors">
                <vs-alert
                  color="warning"
                  class="warning-alert reg-warning-alert no-border-radius"
                  icon-pack="IntakePortal"
                  icon="IP-information-button"
                  active="true"
                >{{ formErrors }}</vs-alert>
              </div>
         
        </div>
        <div class="popup-footer">
          <vs-button color="dark" class="cancel" type="filled" v-on:click.stop.prevent="approveTenantConformpopUp=false;selectedtenantStatus=0;comments=''">Cancel</vs-button>
          <vs-button color="success" class="save" :disabled="[3,4,5].indexOf(selectedtenantStatus)>-1  && comments==''" type="filled" v-on:click.stop.prevent="changetenantStatus()">{{popuptntTxt}}</vs-button>
        </div>
      </vs-popup>
  
      <!--Request for sign in--->
      <sendForSign v-if="(requestsignPopup && formsAndLettersList.length >=0)"

      :petitionDetails="petitionDetails"
      @hideMe="requestsignPopup = false"
      @updatepetition="requestsignPopup=false;reloadWallList()"
      

       :formsAndLetters="formsAndLettersList"
       :rolesList="[]" 
     
      :ACTIVITYCODE="checkProperty(item,'action')"
    />
       
        <!--- Submit to uscis  --->
        
        <assignActivity v-if="submiTouscisPopup"  @hideMe="submiTouscisPopup=false" @updatepetition="submiTouscisPopup=false;reloadWallList()" :petitionDetails="petitionDetails" :popUpTitle="'Submit to USCIS'" :ACTIVITYCODE="'SUBMIT_TO_USCIS'" />
   

        
  
    <!---Courier Tracking---->
    <updateTrackingModel v-if="updateTrackingPopup"  @hideMe="updateTrackingPopup=false" @updatepetition="updateTrackingPopup=false;reloadWallList()" :petitionDetails="petitionDetails"  :ACTIVITYCODE="checkProperty(item,'action')" />
   
        <!----Update USCIS---->
        <assignActivity v-if="openAssignMentPopUp"  @hideMe="openAssignMentPopUp=false" @updatepetition="openAssignMentPopUp=false;reloadWallList()" :petitionDetails="petitionDetails" :popUpTitle="'Supervisory Review'" :ACTIVITYCODE="'SUPERVISOR_FORMS_REVIEW'" />
   
        
        <!---Prtitioner Approve---->
        <vs-popup class="holamundo main-popup" :title="popupbtnTxt+' Company'" :active.sync="approveConformpopUp">
        <div class="form-container">
          
          <div class="vx-row">
            <div class="vx-col w-full">
            <p>{{actionText}}</p>
              
            </div>
            
          </div>
            <div class="text-danger text-sm formerrors" v-if="formErrors!=''">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formErrors }}</vs-alert>
            </div>
         
        </div>
        <div class="popup-footer">
         <span class="loader" v-if="loading"><img src="@/assets/images/main/loader.gif"></span>
          <vs-button color="dark" class="cancel" type="filled" v-on:click.stop.prevent="approveConformpopUp=false">Cancel</vs-button>
          <vs-button color="success" :disabled="loading" class="save" type="filled" v-on:click.stop.prevent="changetPetitionerstatus()">{{popupbtnTxt}}</vs-button>
        </div>
      </vs-popup>
      <!------- documentsViewPopup --->
       <vs-popup class="holamundo main-popup" :title="'Documents View'" :active.sync="documentsViewPopup">
        <div class="form-container">
          
          <div class="vx-row">
            <div class="vx-col w-full">
              <template v-for="(item, index) in checkProperty( item , 'data','documents')">
                
                <span :key="index" :title="item.name"  v-on:click.stop.prevent="downloads3file(item)"  class="note"><img src="@/assets/images/main/note_icon.png"></span> 
              </template>
              
            </div>
            
          </div>
          
         
        </div>
        <div class="popup-footer">
        
          <vs-button color="dark" class="cancel" type="filled" v-on:click.stop.prevent="documentsViewPopup=false">Cancel</vs-button>
        
        </div>
      </vs-popup>
  
     
  
  
        <vs-popup class="holamundo main-popup" :title="'Reject Task'" :active.sync="openTaskRejectPopUp">
          <form @submit.prevent data-vv-scope="acceptingForm">
          <div class="form-container">
              
          <div class="vx-row"  @click="error=''">
  
            
            <div class="vx-col w-full">
          <div class="form_group">
            <label class="form_label">Write a Comment</label>
            <!-- <vs-textarea
              data-vv-as="Comment"
              v-validate="'required'"
              v-model="payloadAccept.comment"
              name="comments"
            
              class="w-full"
            /> -->
            <ckeditor data-vv-as="Comment"
              v-validate="'required'"
              v-model="payloadAccept.comment"
              name="comments"
            
              class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>
  
  
            <span
              class="text-danger text-sm"
              v-show="errors.has('acceptingForm.comments')"
            >Comments are required</span>
          </div>
          </div>
  
  
            
          </div>
          <div v-show="error">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ error }}</vs-alert>
          </div>
  
          
    
          </div>
          </form>
          <div class="popup-footer relative" >
  
          <span class="loader" v-if="accepting" ><img src="@/assets/images/main/loader.gif"></span>
            
            <vs-button color="dark" :disabled="accepting" @click="openTaskRejectPopUp =false" class="cancel" type="filled">Cancel</vs-button>
            <vs-button  color="success" :disabled="accepting"  @click="acceptTaskAction('TASK_REJECT')" class="save" type="filled">Reject </vs-button>
  
          <!----
            <vs-button  color="success" :disabled="accepting "  @click="acceptTaskAction('TASK_ACCEPT')" class="save" type="filled">Accept </vs-button>
            -->
          </div>
      </vs-popup>
      <vs-popup class="holamundo main-popup  confirm_modal"  title="Submit to USCIS" :active.sync="showInvoiceError">
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full text-center">
          <p>{{ preparePermInvoiceError }} </p>
                      
          </div>
          
        </div>
        

        <!------this.$refs["actionsPopup"].openPermJobDescActionsModal('JOB_DESC_SUGGESSION');
          this.$refs["actionsPopup"].openJobDescription('JOB_DESC_SUGGESSION'); suggestJobDesc-->

       
       
      </div>
      <div class="popup-footer relative">
          <vs-button color="dark" @click="showInvoiceError=false;preparePermInvoiceError=''"    class="cancel" type="filled">Cancel</vs-button>
          <vs-button  color="success" @click="showInvoiceError=false;preparePermInvoiceError='';goToDetaillPage()"  class="save"  type="filled"> Ok</vs-button>
        
        </div>
</vs-popup>

<vs-popup class="holamundo main-popup" :title="popuptntTxt+' Delete Todo'" :active.sync="deleteWallConformpopUp">
        <div class="form-container">
          
          <div class="vx-row"  >
            <div class="vx-col w-full">
              <p>Are you sure of delete this Todo?</p>
              
            </div>
                      
          </div>
  
           
            <div class="text-danger text-sm formerrors" v-show="formErrors">
                <vs-alert
                  color="warning"
                  class="warning-alert reg-warning-alert no-border-radius"
                  icon-pack="IntakePortal"
                  icon="IP-information-button"
                  active="true"
                >{{ formErrors }}</vs-alert>
              </div>
         
        </div>
        <div class="popup-footer relative">
           <span class="loader" v-if="loading" ><img src="@/assets/images/main/loader.gif"/></span>
          <vs-button color="dark" class="cancel" type="filled" v-on:click.stop.prevent="deleteWallConformpopUp=false;">Cancel</vs-button>
          <vs-button color="success" class="save" :disabled="loading" type="filled" v-on:click.stop.prevent="deleteWall()">Delete</vs-button>
        </div>
</vs-popup>



<vs-popup class="holamundo main-popup  confirm_modal"  title="Case Number" :active.sync="assignCaseNumberConformation">
      <div class="form-container">
        <div class="vx-row">
          <div class="vx-col w-full text-center">
          
          <vs-alert class="primary-alert mb-1" style="height: auto;">
            Case Number still not updated. Do you want to proceed with same Case Number?.
          </vs-alert>
          
            
          </div>
          
        </div>

              
       
      </div>
      <div class="popup-footer relative">
        <figure v-if="settingCaseNumber" class="loader"> <img src="@/assets/images/main/loader.gif" />
              </figure>
        
          <vs-button color="dark" @click="assignCaseNumberConformation=false;assignCaseNumberConformation=false;assignCaseNumberConformation=false;"   class="cancel" type="filled">Cancel</vs-button>
          <vs-button  color="success"  @click="updateCaseNumber()" class="save"  type="filled"> Yes</vs-button>
        
        </div>
 </vs-popup>
 <updateUSCISstatusPopupModal @hideMe="updateUSCISstatusPopup=false" @updatepetition="updateUSCISstatusPopup=false;reloadWallList()" v-if="updateUSCISstatusPopup" :ACTIVITYCODE="'UPDATE_USCIS_RESPONSE'" :petitionDetails="petitionDetails" />
       
  <template v-if="petitionDetails && checkProperty(petitionDetails,'completedActivities','length')>0 &&checkProperty(petitionDetails,'nextWorkflowActivity','length')>0 ">

    <!---
      petitionDetails && checkProperty(petitionDetails,'completedActivities','length')>0 &&checkProperty(petitionDetails,'nextWorkflowActivity','length')>0 

    rfePraperResDocs:false,//RFE_PREPARE_RESPONSE_DOCS
    rfeCaseApproved:false,//RFE_CASE_APPROVED
    rfeReqPetSign:false,//RFE_REQUEST_PETITIONER_SIGN
    rfeSubmitToUsis:false,  //SUBMIT_TO_USCIS 
    rfecourierTeacking:false,//RFE_COURIER_TRACKING
    rfeUpdateUscIsReceiptNumber:false,//RFE_UPDATE_USCIS_RECEIPT_NUMBER 
    rfeUpdateUSCISstatusPopup:false,// RFE_UPDATE_USCIS_RESPONSE
    ---->
    
   

  
   

  </template>
  <actionsPopup  @updatepetition="reloadWallList()" :workFlowDetails="workFlowDetails" :formsAndLetters="[]" :lcaDetails="{}" ref="dashBoardActionsPopup" :petitionDetails="petitionDetails" />

 
  </div>                 
  
  </template>
  
  <script>
  
  import actionsPopup from "@/views/common/actionsPopup.vue";
  import updateUSCISstatusPopupModal from "@/views/actionpopups/updateUSCISstatus.vue"
  import assignActivity from "@/views/actionpopups/assignActivity.vue"
  //SUPERVISOR_FORMS_REVIEW 2412 
  import updateTrackingModel from "@/views/actionpopups/updateTracking.vue"
  import submitSignedDocument from "@/views/actionpopups/submitSignedDocument.vue";
  import sendForSign from "@/views/actionpopups/sendForSign.vue";
  
  import Datepicker from "vuejs-datepicker-inv";
  import FileUpload from "vue-upload-component/src";
  import Avatar from 'vue-avatar'
  import moment from 'moment'
  import { EyeIcon } from 'vue-feather-icons'
  import Vue from 'vue'
    import _ from "lodash";
  import VTooltip from 'v-tooltip'
  import JQuery from "jquery";
  Vue.use(VTooltip)
  import docType from "@/views/common/docType.vue"
  
  Vue.use( CKEditor );
  import CKEditor from '@ckeditor/ckeditor5-vue2';
  import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { formatDate } from "tough-cookie";
  var _isotope;
  export default {
          components: {
            actionsPopup,
            
            
            sendForSign,
            submitSignedDocument,
            updateUSCISstatusPopupModal,
            assignActivity,
            updateTrackingModel,
          Avatar,
          FileUpload,
          Datepicker,
          EyeIcon,
          docType
      },
      
    props: {
      widgetData:null,
      list:{
        type: Array,
        default:new Array(),
      },
      lableData:{
        type: Array,
        default:new Array(),
      },
      userRolelist:{
        type: Array,
        default:new Array(),
      },
      templateClass:{
          type:String,
          default:'box'
      },  
      all_statusids: {
        type: Array,
        default:new Array(),
      },
      
       itemTemplate:{
           type: Array,
        default:new Array(),
  
      },
      
       
    },
    methods:{
      rfeActions(){
        /*
         <!---
      petitionDetails && checkProperty(petitionDetails,'completedActivities','length')>0 &&checkProperty(petitionDetails,'nextWorkflowActivity','length')>0 

    rfePraperResDocs:false,//RFE_PREPARE_RESPONSE_DOCS
    rfeCaseApproved:false,//RFE_CASE_APPROVED
    rfeReqPetSign:false, //RFE_REQUEST_PETITIONER_SIGN
    rfeSubmitToUsis:false,  //SUBMIT_TO_USCIS 
    rfecourierTeacking:false,//RFE_COURIER_TRACKING
    rfeUpdateUscIsReceiptNumber:false,//RFE_UPDATE_USCIS_RECEIPT_NUMBER 
    rfeUpdateUSCISstatusPopup:false,// RFE_UPDATE_USCIS_RESPONSE
    ---->
        */
       this.rfePraperResDocs =false;
       this.rfeCaseApproved =false;
       this.rfeReqPetSign = false;
       this.rfeSubmitToUsis =false;
       this.rfecourierTeacking =false;
       this.rfeUpdateUscIsReceiptNumber =false;
       this.rfeUpdateUSCISstatusPopup =false;
       this.toggleCalssToRow(false);

       if(this.selectedRfeAction=='RFE_REQUEST_PETITIONER_SIGN'){
         
         if(this.checkProperty(this.petitionDetails,'caseDocs') && this.checkProperty(this.petitionDetails['caseDocs'],'rfeResDocs','length') >0 ){
               
               //this.$refs["actionsPopup"].openReferesponsePopUp(menuItem.code);
               this.toggleCalssToRow(true);
               this.rfeReqPetSign = true;
               try{
                this.$refs['dashBoardActionsPopup'].openReferesponsePopUp('RFE_REQUEST_PETITIONER_SIGN');
               }catch(e){
                console.log(e);

               }

             }else{
             // 'Upload atleast one document' RFE_REQUEST_PETITIONER_SIGN
             //this.$refs["actionsPopup"].openReferesponsePopUp(menuItem.code);
             this.showToster({ message:'Upload atleast one RFE Response document' , isError: true})
             }

            // alert(this.rfeReqPetSign);

       }
     
       if(this.selectedRfeAction=='UPLOAD_SIGNED_DOCUMENTS'){
        this.signedDocumentModal = true
        this.toggleCalssToRow(true);
        this.$refs['dashBoardActionsPopup'].openSignedDocumentModel('UPLOAD_SIGNED_DOCUMENTS');

       }
     
        if(this.selectedRfeAction=='RFE_PREPARE_RESPONSE_DOCS'){
          this.toggleCalssToRow(true);
          this.rfePraperResDocs =true;
          try{
                this.$refs['dashBoardActionsPopup'].openRefePrepareResDocsPopUp('RFE_PREPARE_RESPONSE_DOCS');;
               }catch(e){
                console.log(e);

               }
         

        }
        if(this.selectedRfeAction=='RFE_CASE_APPROVED'){ 
          this.toggleCalssToRow(true);
          this.rfeCaseApproved =true;
          try{
                this.$refs['dashBoardActionsPopup'].openassignActivityPopup([],'Complete Review','Complete Review','RFE_CASE_APPROVED');
               }catch(e){
                console.log(e);

               }
          

        }
        
        
        if(this.selectedRfeAction=='RFE_SUBMIT_TO_USCIS'){
          //RFE_SUBMIT_TO_USCIS
          
          this.toggleCalssToRow(true);
          this.rfeSubmitToUsis =true;
            try{
              this.$refs["dashBoardActionsPopup"].openassignActivityPopup([],'Submit to USCIS','Submit to USCIS','RFE_SUBMIT_TO_USCIS');
              
            }catch(e){
              console.log(e);

            }

        }
        if(this.selectedRfeAction=='RFE_COURIER_TRACKING'){
          this.toggleCalssToRow(true);
          this.rfecourierTeacking =true;
          try{
                this.$refs['dashBoardActionsPopup'].openTrackingModel("RFE_COURIER_TRACKING");
               }catch(e){
                console.log(e);

               }

        }
        if(this.selectedRfeAction=='RFE_UPDATE_USCIS_RECEIPT_NUMBER'){
          this.toggleCalssToRow(true);
          this.rfeUpdateUscIsReceiptNumber = true;
          try{
                this.$refs['dashBoardActionsPopup'].openTrackingModel("RFE_UPDATE_USCIS_RECEIPT_NUMBER");
               }catch(e){
                console.log(e);

               }
          
        }
        if(this.selectedRfeAction=='RFE_UPDATE_USCIS_RESPONSE'){
          this.toggleCalssToRow(true);
          this.rfeUpdateUSCISstatusPopup =true;
            try{
              this.$refs['dashBoardActionsPopup'].openuscisresponse('RFE_UPDATE_USCIS_RESPONSE');
            }catch(e){
              console.log(e);

            }

        }
       
        this.$vs.loading.close();
      },
      openPopup(){
          
          this.formErrors = '';
         this.comments ='';
       
        // if(this.usersList.length>0){
           this.formErrors ="";
           this.comments ='';
          
           this.selectedUser =null;
           this.loading =false;
           if(this.checkProperty(this.petitionDetails ,'typeDetails' ,'name') && this.checkProperty(this.petitionDetails ,'subTypeDetails' ,'name')){
             this.comments = "Case "+this.petitionDetails.typeDetails.name+", "+this.petitionDetails.subTypeDetails.name+"  is being assigned for further actions";
 
           }

           if(this.checkProperty( this.petitionDetails,'allowCustomCaseNo')==true){
            
             if( this.petitionDetails['completedActivities'].indexOf('ASSIGN_CUSTOM_CASE_NO')>-1){
               this.showPopup =true;
             }else{
            //  alert(this.checkActivityRoles('ASSIGN_SUPERVISOR'))
              //alert(this.checkActivityRoles('MANAGER_LIST'));
              if(this.checkActivityRoles('MANAGER_LIST') || this.checkActivityRoles('ASSIGN_SUPERVISOR')){
                
                this.openAssignCnoPop(true ,'showPopup');
              }else{
                this.showToster({message:'New Case Number must be assigned to complete this action.',isError:true });
              }
             // this.openAssignCnoPop(true ,'showPopup');
               
               // 
               // setTimeout(()=>{
               //   this.goToDetaillPage();
               // });
             }

           }else{
             this.showPopup =true;
           }

           
          
            
         // }else{
         //   this.showToster({message:'Reviewers not found.',isError:true });
          
         // }
           
 
     
 
        
       this.$validator.reset();
       
       
      
 
      },

      updateCaseNumber(){
      
      let self = this;
      let postData = {
        caseNo: self.petitionDetails.caseNo.trim(),
        petitionId: self.petitionDetails["_id"],
        subTypeName: self.checkProperty(
          self.petitionDetails,
          "subTypeDetails",
          "name"
        ),
        typeName: self.checkProperty(
          self.petitionDetails,
          "typeDetails",
          "name"
        ),
      };
      this.settingCaseNumber = true;
      let path ="/petition/assign-custom-caseno";
      if([3].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id' )) >-1 &&  [15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1){
              path ="/perm/assign-custom-caseno";
          }
      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: path,
        })
        .then((response) => {
          self.showToster({ message: response.message, isError: false });
          self.assignCaseNumberConformation = false;
          self.settingCaseNumber = false;
          setTimeout(()=>{
        
          if(self.managePop  && _.has(self,self.managePop)){
            self[self.managePop] =true;
          }
         // self.reloadWallList();
        });
        
  
  

        })
        .catch((err) => {
          this.settingCaseNumber = false;
          this.showToster({ message: err, isError: true });
        });
    
      },
      openAssignCnoPop(action=false ,managePop=''){
        this.settingCaseNumber =false;
        this.assignCaseNumberConformation = action;
        this.managePop =managePop;
        

      },
      toggleCalssToRow(action=false){
       let dt = { 'rowId':'', "addClass":false,"columnId":'' };
      

            if(action){
              dt['addClass'] = action;
            }
            if( this.checkProperty(this.widgetData,'rowId')){
            dt['rowId'] = this.widgetData['rowId'];
           }
           if( this.checkProperty(this.widgetData,'columnId')){
            dt['columnId'] = this.widgetData['columnId'];
           }
          

        this.$emit("toggleCalssToRow",dt);

      },
      uploadSignedDocuments(){
        this.signedDocumentModal =true;
        
      },
     
      conformDeleteWall(item){
        this.loading =false;
        this.deleteWallConformpopUp =true;
        this.item = item;
      },
      deleteWall(){
       let  postData ={"wallId":''};
       postData['wallId'] =this.item['_id'];
       let path ="/walls/close-todo"
          this.loading =true;
          this.$store.dispatch("commonAction", {"data":postData ,"path":path})
        .then(response => {
          this.showPopup =false;
          this.openAtornyPopup =false;
          this.showToster({message:response.message,isError:false });
          this.loading =false;
          this.deleteWallConformpopUp =false;
          this.reloadWallList();               
          
          
                          
        }).catch((error)=>{
          this.showToster({message:error,isError:true });
          //this.formErrors =error;
          this.loading =false;
        })
      },
      getBackGroundColor(item){
        let returnVal ='';
        if(item && this.checkProperty(item ,'data' ,'config') && this.checkProperty(item['data'] ,'config' ,'bgColor') && this.checkProperty(item['data']['config'] ,'bgColor' ,'length')>0 && this.checkProperty(this.widgetData ,'code')=='UPDATES'){
          returnVal =item['data']['config']['bgColor'][0]
        }
        return returnVal;

      },
  
      checkisRejected(ticket){
        let returnVal =false;
        if(
          
         (this.checkProperty(ticket['data'] ,'rejectedByIds' ,'length')>0 && ticket['data']['rejectedByIds'].indexOf(this.checkProperty( this.getUserData,'userId'))>-1  )
        ){
          returnVal =true;
        }
  
  
        return returnVal;
      },
  
      checkisAccepted(ticket){
        let returnVal =false;
        if(
          (  this.checkProperty(ticket['data'] ,'acceptedByIds' ,'length')>0 && ticket['data']['acceptedByIds'].indexOf(this.checkProperty( this.getUserData,'userId'))>-1  )
        
        ){
          returnVal =true;
        }
  
  
        return returnVal;
      },
  
      isAssignedUser(ticket){
        if( this.checkProperty( ticket['data'] ,'assignedTo' ,'length') >0 && ticket['data']['assignedTo'].indexOf(this.checkProperty( this.getUserData,'userId'))>-1 ){
          return true
        }else{
          return false
        }
      },
  
  
       openAcceptForm(action =false ,actionType=''  ,task=null){
     
      this.error =  '';
      this.payloadAccept= {
        "taskId": "",
        "action": "TASK_ACCEPT" ,//'TASK_REJECT',
        "comment": ""
      }
      this.accepting =false;
      if(task){
        this.item =task;
      }
     
      if(action   ){
        if(actionType =='TASK_ACCEPT'){
           this.acceptTaskAction('TASK_ACCEPT')
        }else{
          if(actionType =='TASK_REJECT'){
            this.openTaskRejectPopUp =true;
            //this.$modal.show('taskAcceptModal');
          }
        }
       
       
      }else{
         this.openTaskRejectPopUp =false;
      //  this.$modal.hide('taskAcceptModal');
        
      }
      this.$validator.reset();
  
    },
  
    acceptTaskAction(actionType=''){
       this.$validator.validateAll('acceptingForm').then((result)=>{
      
          if(result || actionType=='TASK_ACCEPT'){
             let seletedTask = _.cloneDeep(this.item);
           
              this.error = '';
              this.accepting =true;
                this.payloadAccept['taskId'] =this.checkProperty(seletedTask , 'data' ,'taskId');
                if(actionType){
                  this.payloadAccept['action'] = actionType
                } 
                let payLoad = _.cloneDeep(this.payloadAccept);
                this.$store.dispatch("commonAction", {"data": payLoad ,"path":"/tasks/manage"})
                  .then((response) => {   
                    this.accepting =false; 
                     this.openAcceptForm(false)
                      this.showToster({message:response.message,isError:false }); 
                      this.reloadWallList();
                                      
                  })
                  .catch((error) => {
                    this.error =error
                      this.accepting =false;  
                  })
           }
           
           })
  
  
    },
      checkSendAttachments(action=''){
        setTimeout(() =>{
              if(this.notifyPetitioner && action=='notifyPetitioner'){
            //  this.emailDocsForSign =false;
           
              }
              
              if(this.emailDocsForSign && action=='emailDocsForSign'){
                this.notifyPetitioner =true;
              }
  
        } ,10)
        
      },
      initIsotop(resetIsotop=false){
        
        setTimeout(() => {
            
  
               // Force grid to relayout
               if(resetIsotop && this.isotopGrid && false){
                  this.isotopGrid.isotope('layout');
                 // alert()
  
               }else{
                 this.isotopGrid=  jQuery(".db_grid").isotope({
                layoutMode: "packery",
                itemSelector: ".grid_element",
                masonry: {
                  horizontalOrder: true,
                },
              });
              if (jQuery(".db_grid").height() <= 50) {
                jQuery(".db_grid").height("auto");
                var _h = jQuery(".db_grid").innerHeight();
                jQuery(".db_grid").height(_h);
              }
  
               }
            
  
            
              // this.$vs.loading.close();
            }, 100);
      },
       /*** Computed ***/
       /*
        isAssignmentActivity(){
  
          //(assignmentActivityes.indexOf(checkProperty( item ,'data' , 'category'))>-1)
  
          return (this.assignmentActivityes.indexOf(this.checkProperty( this.item ,'data' , 'category'))>-1)?true:false;
  
        },
        isCustomeCode(){
           return (['ASSIGN_CUSTOM_CASE_NO'].indexOf(this.checkProperty( this.item ,'data' , 'category'))>-1)?true:false;
  
        },
        checkCaseApprove(){
  
            let returnVal = false;
        
        //(checkProperty( item ,'data' , 'category')== 'CASE_APPROVED' && checkProperty( item ,'status'))
          let category =  this.checkProperty( this.item ,"data" , "category")
            if(this.item.status && category =="CASE_APPROVED"){
                returnVal = true;
            }
            return returnVal;
  
        },
        
        checkApproveDoc(){
  
            let returnVal = false;
        
          //(checkProperty( item ,'data' , 'category')== 'APPROVED_BY_DOC_MANAGER' && checkProperty( item ,'status'))
          let category =  this.checkProperty( this.item ,"data" , "category")
            if(this.item.status && category =="APPROVED_BY_DOC_MANAGER"){
                returnVal = true;
            }
            return returnVal;
  
        },
        
         //REQUEST_PETITIONER_SIGN
        checkRequestForSignin(){
  
            let returnVal = false;
        
       //checkProperty( item ,'data' , 'category')== 'REQUEST_PETITIONER_SIGN' && checkProperty( item ,'status')
          
          let category =  this.checkProperty( this.item ,"data" , "category")
            if(this.item.status && category =="REQUEST_PETITIONER_SIGN"){
                returnVal = true;
            }
            return returnVal;
  
        },
        //SUBMIT_TO_USCIS
        checkSubmitToUSCIS(){
  
            let returnVal = false;
       // checkProperty( item ,'data' , 'category')== 'SUBMIT_TO_USCIS' && checkProperty( item ,'status')
          
          let category =  this.checkProperty( this.item ,"data" , "category")
            if(this.item.status && category =="SUBMIT_TO_USCIS"){
                returnVal = true;
            }
            return returnVal;
  
        },
        checkTenantCreated(){
  
            let returnVal = false;
        
          //(checkProperty( item ,'data' , 'category')== 'TENANT_CREATED' && checkProperty( item ,'status'))
          let category =  this.checkProperty( this.item ,"data" , "category")
            if(this.item.status && category =="TENANT_CREATED"){
                returnVal = true;
            }
            return returnVal;
  
        },
        //COURIER_TRACKING
        checkCourierTrackingTodo(){
  
            let returnVal = false;
        
          //(['UPDATE_USCIS_RECEIPT_NUMBER' ,'COURIER_TRACKING'].indexOf(checkProperty( item ,'data' , 'category'))>-1 && checkProperty( item ,'status'))
          let category =  this.checkProperty( this.item ,"data" , "category")
            if(this.item.status && (category =="COURIER_TRACKING" || category=='UPDATE_USCIS_RECEIPT_NUMBER' )){
                returnVal = true;
            }
            return returnVal;
  
        },
        //
        checkUpdateUscisResponseTodo(){
  
            let returnVal = false;
        
          //(['UPDATE_USCIS_RESPONSE'].indexOf(checkProperty( item ,'data' , 'category'))>-1 && checkProperty( item ,'status'))
          let category =  this.checkProperty( this.item ,"data" , "category")
            if(this.item.status && (category =="UPDATE_USCIS_RESPONSE"  )){
                returnVal = true;
            }
            return returnVal;
  
        },
       checkNewCompanyCreated(){
  
            let returnVal = false;
        
          //(['COMPANY_CREATED'].indexOf(checkProperty( item ,'data' , 'category'))>-1 && checkProperty( item ,'status'))
          let category =  this.checkProperty( this.item ,"data" , "category")
            if(this.item.status && (category =="COMPANY_CREATED"  )){
                returnVal = true;
            }
            return returnVal;
  
        },
        checkActionIsRequited(){
            let returnVal = false;
        
           // checke petitoon Todos
          // (petitionToDoList.indexOf(checkProperty( item ,'data' , 'category')) >-1 && checkProperty( item ,'status' ))
          let category =  this.checkProperty( this.item ,"data" , "category")
            if(this.item.status && this.petitionToDoList.indexOf(category) >-1){
                returnVal = true;
            }
            return returnVal;
        },
        */
        getPetitionerRoleName(item){
  
          if(this.checkProperty(this.userRolelist ,'length')>0){
            //userRolelist
            let petitioner = _.find( this.userRolelist ,{"id": 50});
            if(this.checkProperty(petitioner ,'name')){
  
              return petitioner['name'];
            }else{
              return "Petitioner";
  
            }
  
          }else{
            return "Petitioner";
          }
        },
        addReviewrsRolesList(){
  
          let reviewrsRolesList =[]
            
            let tempData = _.cloneDeep(this.usersList);
            let tempUnuqueItems =[]
            _.forEach(tempData ,(object)=>{
              if(tempUnuqueItems.indexOf(object['roleName']) <=-1){
                tempUnuqueItems.push(object['roleName']);
                reviewrsRolesList.push(object); 
  
              }
  
            })
            return reviewrsRolesList;
    
          
        },
  
       /*** Computed ***/
  
       openSetCaseCodePopup(){
           
           this.formerrors = null;
           this.newCaseCode = this.checkProperty( this.item,'data' ,'caseNo');
           this.confCaseCode = '';
           this.settingCaseNumber =false
           this.$validator.reset('newCaseNumberForm')
           this.setCode = true;
        },
         SetCaseCodeAction() {
         
        this.$validator.validateAll('newCaseNumberForm').then((result) => {
          
          if (result) {
             
             let self =this;
            let postData = {
              caseNo: self.newCaseCode.trim(),
              //currentPassword: self.confCaseCode,
               petitionId: self.petitionDetails['_id'],
               subTypeName:self.checkProperty(self.petitionDetails,'subTypeDetails','name'),
               typeName:self.checkProperty(self.petitionDetails,'typeDetails','name'),
           
            };
           
  
            let path = "/petition/assign-custom-caseno";
            if(self.checkProperty(self.petitionDetails,'subTypeDetails','id') ==15){
              path = "/perm/assign-custom-caseno";
            }
           
             this.settingCaseNumber =true
              this.$store.dispatch("commonAction", {"data":postData ,"path":path})
                .then(response => {
                     this.showToster({message:response.message,isError:false });
                     this.newCaseCode ='';
                    this.confCaseCode ='';
                    this.$validator.reset('newCaseNumberForm');
                    this.setCode = false;
                     this.settingCaseNumber =false
                      this.reloadWallList();
                    
                }).catch((err)=>{
                   this.settingCaseNumber =false
                   this.formerrors =err
                 // this.showToster({message:err,isError:true });
                });
          }
        });
       },
  
      getlableName(){
        let self =this;
       let code = self.checkProperty( this.item ,"data" , "category");
         let returnValue = "Submit to Reviewer";
  
        let labels = [
          {"code":"ASSIGN_SUPERVISOR" ,"label":"Assign Supervisor"},
          {"code":"ASSIGN_PARALEGAL" ,"label":"Assign Paralegal"},
          {"code":"ASSIGN_DOCUMENTATION_MANAGER" ,"label":"Assign Document Manager"},
          {"code":"ASSIGN_DOCUMENTATION_EXECUTIVE" ,"label":"Assign Document Executive"},
         {"code":"ASSIGN_ATTORNEY" ,"label":"Assign Attorney"},
        ];
  
        let assignLabel = _.find(labels , {"code":code} );
       
        if(assignLabel && this.checkProperty(assignLabel ,'label' )){
  
          returnValue = assignLabel['label'];
  
        }  else if(this.lableData.length>0 && code){
          let msgObject = _.find(this.lableData , {"code":code});
          if( msgObject && _.has(msgObject , 'actionLable')){
              returnValue = msgObject['actionLable'];
          }
  
        }
  
        return returnValue;
  
      },
      getBorderColor(){
       let returnValue =``;
          if(this.checkProperty(this.item ,"data" ,"config")){
            let config = this.item['data']['config'];
            if( this.checkProperty( config ,'bgColor' ,"length")>1 ){
               let color1 = config['bgColor'][0]
               let color2 = config['bgColor'][1]
              returnValue =`1px solid ${color2}`;
            }
          }
          return returnValue;
      },
      getGredieantColor(wallItem){
        let angle =118
          let color1 = '#EFF7FF'
          let color2 = '#DEEAF6'
        let returnValue =`linear-gradient(${angle}deg, ${color1} 0%, ${color2}  100%)`;
        if(this.checkProperty(wallItem ,"data" ,"config")){
          let config = wallItem['data']['config'];
          if( this.checkProperty( config ,'bgColor' ,"length")>0 ){
            //  returnValue =config['bgColor'][0];
          // return 'linear-gradient(118deg, '+config['bgColor'][0]+' 0%,'+ config['bgColor'][1]+' 100%);'
           angle =118
           color1 = config['bgColor'][0]
           color2 = config['bgColor'][1]
           returnValue= `linear-gradient(${angle}deg, ${color1} 0%, ${color2}  100%)`;
          }
        }
        return  returnValue;
      },
      addClass(){
        this.isAddcls =true;
      },
       openDocumentsPopup(){
         this.documentsViewPopup =true;
       },
       fetchWorkflowDetails(callBack=null,funName=''){
      
        
      this.workFlowDetails = null;
      let category =  this.checkProperty( this.item ,"data" , "category")
              
      if((this.checkProperty( this.petitionDetails ,'workflowId') && _.has(this.assignMentUsersList ,category) ) || funName=='rfeActions' ){
        let payLoad = {"path":"/workflow/details",data:{'workflowId':this.checkProperty( this.petitionDetails ,'workflowId')}};
        this.$store.dispatch("commonAction" ,payLoad)
        .then((res)=>{
          this.workFlowDetails = res;
          if(funName=='rfeActions'){
            
            this.rfeActions();
            return true;
          }
         
          this.findSkipedActivityList();
            this.$vs.loading.close();
         
          
          let currentActivityList = this.assignMentUsersList[category];
                 
          if( this.workFlowDetails &&  _.has(this.workFlowDetails ,'config') ){
             let usersListObject = _.find(this.workFlowDetails['config'] ,{"code":currentActivityList});
            this.usersList =[];
            let postData ={
                petitionId:'',
                "entityType": "case", // perm
                action:'',
                "matcher":{
                "roleIds": [],
                "branchId":"",
                },
                
                "page": 1,	
                "perpage":100000000,
                
                };
  
            let companyIdRoles =[50 ,51];
            let branchIdRoles =[4, 5, 6, 7, 8, 9, 10, 11 ,12];
            _.forEach(usersListObject['editors'],(editor)=>{
            
            
            postData.matcher.roleIds.push(editor.roleId);
            if(companyIdRoles.indexOf(editor.roleId)>-1 && this.checkProperty(this.petitionDetails ,'companyDetails' ,'_id')){
                postData = Object.assign(postData ,{"companyId":this.checkProperty(this.petitionDetails ,'companyDetails' ,'_id') })
            }
  
            if(branchIdRoles.indexOf(editor.roleId)>-1 && this.checkProperty(this.petitionDetails ,'branchId')){
                postData['matcher']['branchId'] = this.checkProperty(this.petitionDetails ,'branchId');
            }
            
  
            });
            //alert(JSON.stringify(postData));
            let path ='/petition/assign-user-list';
            if(this.checkProperty(this.petitionDetails,'subTypeDetails','id') ==15){
              path = "/perm/assign-user-list";
              postData['entityType'] = 'perm';
  
            }
            path = "/petition-common/get-users-for-assign";
            postData['petitionId'] = this.petitionDetails['_id'];
            postData['action'] = currentActivityList;
           // alert(path)
  
            this.$store.dispatch("getList",{data:postData ,path:path} ).then(response => {
            //alert(JSON.stringify(response.list));
                let lst = []
                if(response){
                _.forEach(response ,(item)=>{
                    if(_.has(item ,'name') && _.has(item ,'roleName') && ( item._id !=this.getUserData['userId'])){
                        item.name = item.name+" ("+item.roleName+")";
                        lst.push(item);
                    }
                
                });
              }
                this.usersList = lst;
                if(callBack){
                callBack();
                }
              
            });
                
          }
          
         
               
        })
        .catch((error)=>{
            
             this.workFlowDetails = null;
               this.$vs.loading.close();
                    
          
        })
  
      }else{
          this.$vs.loading.close();
      }
  
      },
       findSkipedActivityList(){
        
        this.skipedActivityList =[];
         this.skipedActivity =false;
        let workFlowDetails =  this.workFlowDetails;
      if(workFlowDetails && this.petitionDetails && this.checkProperty(this.petitionDetails , 'nextWorkflowActivity') && _.has(workFlowDetails ,"config")){
          
           let config  = workFlowDetails['config'];
         let petitionCurrentActivityIndex = _.findIndex(config ,{"code": this.petitionDetails['nextWorkflowActivity'] });
         let completedActivityList = this.petitionDetails['completedActivities'];
        
         if(petitionCurrentActivityIndex>-1 && completedActivityList.length>0  && (completedActivityList.indexOf("SUBMIT_TO_USCIS")<=-1 ) ){
        
          _.forEach(config ,(activityItem ,index)=>{
            if(index<petitionCurrentActivityIndex){
              
              if(completedActivityList.indexOf(activityItem['code'])<=-1   && _.has(this.assignMentUsersList ,activityItem['code'])){
                
              
               if(completedActivityList.indexOf("CASE_APPROVED") >-1){
  
                  if([ 'ASSIGN_DOCUMENTATION_MANAGER','ASSIGN_DOCUMENTATION_EXECUTIVE'].indexOf(activityItem['code']) >-1){
  
                       this.skipedActivityList.push(activityItem['code']);
                       this.skipedActivity =true;
  
                  }
  
                }else{
                  this.skipedActivityList.push(activityItem['code']);
                  this.skipedActivity =true;
  
                }
                
                
              
              
              }
  
            }
  
  
          })
         }
              
      }
     
  
      },
        reloadWallList(){
        this.rfePraperResDocs =false;
       this.rfeCaseApproved =false;
       this.rfeReqPetSign = false;
       this.signedDocumentModal =false;
       this.rfeSubmitToUsis =false;
       this.rfecourierTeacking =false;
       this.rfeUpdateUscIsReceiptNumber =false;
       this.rfeUpdateUSCISstatusPopup =false;
  
             setTimeout(() => {
                     this.loading =false;
                     this.$emit('rloadActionWidjet' ,'ACTION');
                     
                  } ,100)
  
        },
        goToDetaillPage(){
          //alert(this.checkProperty(this.item ,'data' ,'navigationKey'))
            //alert( this.checkProperty(this.item ,'data' ,'navigationKey'))
            let category = this.checkProperty( this.item ,"data" , "category");
  
             if( this.checkProperty(this.item ,'data' ,'navigationKey')  == "TASK_DETAILS"){
  
                 let taskId = this.checkProperty(this.item ,"data", "taskId");
                 
                  let path =  {'path':"/tasks-list" ,"query":{}};
                 if(taskId) {
                   path["query"]['id'] =taskId
                   this.$router.push(path);
  
                 }
                  
  
  
            }else if( this.checkProperty(this.item ,'data' ,'navigationKey')  == "CAP_DETAILS"){
              let caseId = this.checkProperty(this.item ,'data' ,'petitionId');
              if(caseId) {
                this.$router.push({ path: `/cap-registration-details/${caseId}` ,query: {'filter':''} })
              }
              
            }else if( this.checkProperty(this.item ,'data' ,'navigationKey')  == "TENANT_DETAILS"){
  
                 let tenantId = this.checkProperty(this.item ,"data", "tenantId");
                 if(tenantId) this.$router.push("/customer-details/"+tenantId);
  
  
            }else  if((this.checkProperty(this.item ,'data' ,'navigationKey')=='LCA_DETAILS') ){
              
                let lcaId = this.checkProperty( this.item ,'data',"lcaId" );
                if(lcaId){
                    this.$router.push("/lca-inventory-details/"+lcaId);
                    //this.$store.dispatch("setPetitionTab" , 'set_LCA');
                    //this.findDetailsPage(petitionId);
                }else if(this.checkProperty( this.item ,'data',"petitionId" )){
                  let petitionId =  this.checkProperty( this.item ,'data',"petitionId" );
                  this.$store.dispatch("setPetitionTab" , 'set_LCA');
                  this.findDetailsPage(petitionId);

                }
                //petitionId
                   
  
            }else if(this.petitionToDoList.indexOf(category)>-1  ||  this.checkProperty(this.item ,'data' ,'navigationKey') =='PETITION_DETAILS' || this.checkProperty(this.item ,'data' ,'navigationKey') =='PERM_DETAILS'   ){
              
              this.navigateToDetails(this.item ,'CASE_DETAILS' ,'');
                   
  
            }else if( this.tenantTodoList.indexOf(category)>-1 || ['TENANT_STATUS_UPDATE'].indexOf(category)>-1){
  
                 let tenantId = this.checkProperty(this.item ,"data", "tenantId");
                 if(tenantId)
                    this.$router.push("/customer-details/"+tenantId);
            }else if( this.checkProperty(this.item ,'data' ,'navigationKey')=='USER_DETAILS'){
  
                this.$router.push("/users");
            }
            else if( this.checkProperty(this.item ,'data' ,'navigationKey')=='COMPANY_DETAILS'){
             
                let companyId = this.checkProperty(this.item ,"data", "companyId")
                if(companyId)
                   this.$router.push("/petitioner-details/"+companyId);
            }else if( ['TICKET_DETAILS'].indexOf(this.checkProperty(this.item ,'data' ,'navigationKey'))>-1){
             
                let ticketId = this.checkProperty(this.item ,"data", "ticketId");
                if(ticketId)
                   this.$router.push("/ticket-details/"+ticketId);
            }
            
        },
        fetchPetitionDetails(wallItem,callBack ,funName=''){
          this.toggleCalssToRow(false);
          this.rfePraperResDocs =false;
          this.rfeCaseApproved =false;
          this.rfeReqPetSign = false;
          this.rfeSubmitToUsis =false;
          this.rfecourierTeacking =false;
          this.rfeUpdateUscIsReceiptNumber =false;
          this.rfeUpdateUSCISstatusPopup =false;

             this.item = wallItem
            let category =  this.checkProperty( this.item ,"data" , "category")
  
            if( this.petitionToDoList.indexOf(category)>-1 ||  this.checkProperty(this.item ,'data' ,'navigationKey') =='PETITION_DETAILS'||  this.checkProperty(this.item ,'data' ,'navigationKey') =='PERM_DETAILS'){
           
             this.$vs.loading();  
                 let petitionId = this.checkProperty( this.item ,"data" , "petitionId");
                 let isPerm = (this.checkProperty( this.item ,"entityType") == "perm")?true:false;
                 var dispatch = "getpetition";
                 if(isPerm){
                  dispatch = "getpermpetition";
                 }
              this.$store.dispatch(dispatch, petitionId).then(response => {
                 
                  if (response.data) {
  
                    
                    
                      this.petitionDetails = response.data.result;
                      if(funName=='rfeActions'){
                        //alert(funName);
                        this.fetchWorkflowDetails(callBack,funName);
                        //callBack();
                        return false
                      }else if(funName=="openApproveOrRejectDocs"){
                         callBack()
                      }else if(funName=="openapproveCasePopup"){
                         callBack()
                      }else if(funName=="updateUSCISstatus"){
                         //updateUSCISstatus
                       // alert(this.item['action']);
                        if(this.item && this.item['action'] =='SUBMIT_TO_USCIS'){
                          this.updateUSCISstatus(true);
                        }else{
                          this.updateUSCISstatus();
                        }
                        
                         //callBack()
                      }else if(funName =='openSetCaseCodePopup'){
                        this.openSetCaseCodePopup();
                         this.$vs.loading.close();
                        return false
                      }
                      
                      
                      if(_.has(this.assignMentUsersList ,category) || funName =='openPopup' ){
                      
                        this.fetchWorkflowDetails(callBack);
                      }else if(category=='REQUEST_PETITIONER_SIGN' || category == 'SUBMIT_TO_USCIS'){
                        
                         this.getFormsAndLetters(callBack);
                         if(this.item['action'] !='SUPERVISOR_FORMS_REVIEW'){
                          this.$vs.loading.close();
                         }
                          
                      }else  if((['UPDATE_USCIS_RECEIPT_NUMBER' ,'COURIER_TRACKING'].indexOf(this.checkProperty( this.item ,'data' , 'category'))>-1 && this.checkProperty( this.item ,'status'))){
                         
                        this.getCourierList(callBack);
                      }else{
                        
                           this.$vs.loading.close();
                      }
                     
                    
                 }else{
                     this.$vs.loading.close();
  
                 }
              })
              
            }else if( this.tenantTodoList.indexOf(category)>-1){
             
              this.getTenantDetails();
  
            }else if( ['COMPANY_CREATED'].indexOf(category)>-1){
              this.getpetetioner();
  
            }
           
        },
        submitAction(action=''){
            this.$validator.validateAll("assignmentForm").then((result) => {
              if (result) {
                let postData = {
                 petitionId: this.petitionDetails['_id'],
                  comment: this.comments,
                    "userId": this.checkProperty(this.selectedUser ,"_id"),
                    "userName": this.checkProperty(this.selectedUser ,"name"),
                    "roleId":  this.checkProperty(this.selectedUser ,"roleId"),
                    "assignRoleName":  this.checkProperty(this.selectedUser ,"roleName"),
                    subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
                    typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),
                     "action":this.checkProperty( this.item ,"data" , "category"), //"ASSIGN_SUPERVISOR", // "ASSIGN_PARALEGAL" / "ASSIGN_DOCUMENTATION_MANAGER" / "ASSIGN_DOCUMENTATION_EXECUTIVE" / "ASSIGN_ATTORNEY"
                   // "lastUserName": "Paralegal", // is Required when replacing a paralegal(action == "REPLACE_PARALEGAL"),
                  //  "submitted": true // Required only when submitting to any roleSupervisor
                   isSkippedAction:this.skipedActivity?true:false
  
                };
  
                let path = "/petition/assign-a-role";
                if(this.checkProperty(this.item , 'data','navigationKey') =='PERM_DETAILS'){
                  path = "/perm/assign-a-role";
                }
                
                
               
                 this.loading =true;
                 this.$store
                .dispatch("commonAction", {"data":postData ,"path":path})
                .then(response => {
                  this.showPopup =false;
               
                  this.showToster({message:response.message,isError:false });
                  this.skipedActivity =false;
                  this.reloadWallList();
  
                  
                  
                  
                                  
                })
                .catch((error)=>{
                  
                  this.formErrors =error;
                  this.loading =false;
                })
                
         
         
  
                
              }
            });
        
  
        },
        
      selectUesr(item){
        this.selectedUser = item;
       
      },
  
      //CASE APPROVE Section
        openapproveCasePopup(){
           
            if (this.checkProperty(this.petitionDetails ,'lcaId')!= null && this.checkProperty(this.petitionDetails ,'lcaId')!= '') {
                 this.$vs.loading();
                      this.$store
                          .dispatch("fetchLcaDetails", this.petitionDetails.lcaId)
                          .then(response => {
                                this.$vs.loading.close();
                              this.lcaDetails = response.data.result;
                              let getLcaDetails = _.cloneDeep(this.lcaDetails);
                               if( getLcaDetails && _.has(getLcaDetails ,"statusId") ){
                                      if( [2,3].indexOf(getLcaDetails['statusId'])<=-1 ){
                                          this.showToster({message:"LCA should be either Filed or Certified in order to approve the case." ,isError: true});
                                          setTimeout(() => {
                                                  this.loading =false;
                                                      this.goToDetaillPage();
                                                  
                                                  } ,100)
                                          
                                          return false;
                                      }else{
                                          this.showPopup =false;
                                          this.formErrors = '';
                                          this.comments ='';
                                          this.loading =false,
                                          this.approveCasePopup =true;
                                          this.$validator.reset();
  
                                      }
                               }
  
  
                          }).catch((err)=>{
                               this.$vs.loading.close();
                               this.showToster({message:err ,isError: true});
                              setTimeout(() => {
                                      this.loading =false;
                                          this.fetchPetitionDetails(this.item);
                                      
                                      } ,100)
                          })
            }else{
                 this.showPopup =false;
                  this.formErrors = '';
                  this.comments ='';
                  this.loading =false,
                  this.approveCasePopup =true;
                  this.$validator.reset();
  
            }                
        
         
  
  
       },
      caseApproveCaseAction(){
         this.formErrors ='';
           let postData = {
               petitionId: this.petitionDetails['_id'],
              comment: this.comments,
              action:'CASE_APPROVED', // "SUBMIT_TO_LAW_FIRM", // "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "SUBMIT_TO_USCIS" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED" 
              today: moment().format('YYYY-MM-DD'), // Required on Status changes to "Received RFE"
             subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
             typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),
  
           };
           
           this.$validator.validateAll("approvecase").then((result) => {
             
              if (result) {
                let path ="/petition/manage-approval-process";
                if(this.checkProperty(this.petitionDetails,'subTypeDetails','id') ==15){
                  path = "/perm/manage-approval-process";
                }
                 this.loading =true;
                 this.$store
                .dispatch("commonAction", {"data":postData ,"path":path})
                .then(response => {
                  
                   this.showToster({message:response.message,isError:false });
                   this.showPopup =false;
                   this.approveCasePopup =false;
                    this.loading =false;
                    this.reloadWallList();
                  
                  
                                  
                })
                .catch((error)=>{
                   this.loading =false;
                  this.formErrors =error;
                })
         
         
  
                
              }
            });
             
  
         
       
  
      },
  
  //Approve reject Documents
       openApproveOrRejectDocs(){
       
       this.formErrors = '';
          this.comments ='';
           this.loading =false;
           this.approveOrRejectDocs = true;
       this.$validator.reset();
    },
    approveOrRejectDocsAction(action=""){
      this.formErrors ="";
       this.$validator.validateAll("approveOrRejectDocsForm").then(result => {
        if(result && ['APPROVED_BY_DOC_MANAGER', 'REJECT_BY_DOC_MANAGER'].lastIndexOf(action)>-1){
          var postData = {
                petitionId:this.checkProperty(this.petitionDetails,'_id'),
                typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),
                subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
                comment:this.comments, // Required on APPROVED_BY_DOC_MANAGER and REJECT_BY_DOC_MANAGER
                action: action,//"UPLOAD_BY_DOC_EXECUTIVE",//APPROVED_BY_DOC_MANAGER, REJECT_BY_DOC_MANAGER
                today: moment().format("YYYY-MM-DD")
          }
  
          this.loading =true;
          this.$store.dispatch("commonAction", {"data":postData ,"path":"/petition/manage-offshore-document-upload"})
                .then((response) => {
                
               
                this.approveOrRejectDocs = false;
                this.showToster({message:response.message,isError:false })
                 this.reloadWallList();
                
                              
                })
                .catch((error) => {
                
                  this.formErrors = error;
                  this.loading = false;
                  
                
                })
         }
              
           
       })
     
    },
  
    //tenant related ToDo 
    getTenantDetails(){
      let tenantId = this.checkProperty(this.item ,"data", "tenantId")
            let postData = {tenantId:tenantId};
              this.$vs.loading();
             this.$store.dispatch("commonAction", {"data":postData ,"path":"/tenant/details"})
             .then((response) => {
                 this.tenantDetails =response;
                 this.$vs.loading.close();
             })
             .catch((err) =>{
                 this.$vs.loading.close();
                  this.tenantDetails =null;
                 this.showToster({message:err,isError:true });
  
             })
  
  
  
    },
    openTenantApprovepopup(status=2 ,txt='', event){
    
          this.getTenantDetails()
          this.tntActionText = "Do you want to "+txt+" ?",
          this.popuptntTxt = txt;
          this.selectedtenantStatus = status;
          this.approveTenantConformpopUp =true;
          this.formErrors = '';
          this.comments ='';
           this.loading =false;
  
    },
    changetenantStatus( ){
          let post_data = {"tenantId":this.tenantDetails['_id'], "statusId":this.selectedtenantStatus }
        
        let action ="changetenantStatus"
         if(this.selectedtenantStatus ==4){
          action = "deleteTenant"
         }
         if( this.comments.trim() =='' && [3,4,5].indexOf(this.selectedtenantStatus)>-1 ){
           return true;
  
         }
         if([3,4,5].indexOf(this.selectedtenantStatus)>-1){
          post_data = Object.assign(post_data,{"comment":this.comments}) ;
         }
         //alert(action)
         this.$store.dispatch(action, post_data)
            .then(response => {
              this.showToster({message:response.message,isError:false});
              this.approveTenantConformpopUp =false;
              this.reloadWallList();
  
  
            }).catch((err)=>{
              this.formErrors = err;
              this.showToster({message:err,isError:true});
            
          });
   },
  
   //Request for signin documents
  
    getFormsAndLetters(callBack=null){
      this.formsAndLettersList = [];
      let finalList =[];
        let postData ={petitionId:this.petitionDetails._id ,'page':1 ,'perpage':10000 };
      this.$store.dispatch("getList" ,
      {data:postData,
       // path:"/petition/filled-forms-and-letters-list"
        path:"/filled-forms-and-letters/list"
      })
      .then(response => {
    //  this.formsAndLettersList = response.list;
  
      
        let lst = [];
      
      _.forEach(response.list ,(mainItem)=>{
          mainItem = Object.assign(mainItem,{"reverse_document_versions":[] ,"mainParentId":'',showMe:true ,"selectedForSigning":false});
          if(mainItem.parentId){
              mainItem['mainParentId'] = mainItem['parentId']
          }else{
              mainItem['mainParentId'] = mainItem['_id']
          }
  
          lst.push(mainItem);
            
  
      });
  
      let subList=[];
      
      //reverse_document_versions
      _.forEach(lst ,(mainItem)=>{
  
                          
          
          _.forEach(lst ,(subItem)=>{
              if( mainItem.parentId && (mainItem.parentId == subItem['parentId'] ||  mainItem.parentId == subItem['_id']   ) &&  mainItem['_id'] != subItem['_id']){
                        
                        subItem['showMe'] =false;
                        if(subList.indexOf(subItem['_id']<=-1)){
                            mainItem['reverse_document_versions'].push(subItem);
                            subList.push(subItem['_id']);
  
                        }
                      
                      // mainItem['showMe'] =true;
              }
  
          })
          
      if(mainItem.showMe){
            finalList.push(mainItem);
      }
          
  
      })
      
  
  
      this.formsAndLettersList =  finalList;
      if(callBack){
        callBack();
      }
    })
  
    },
  
    selectFormsandLatters(index ,forms){
      if( !this.formsAndLettersList[index]['selectedForSigning'] ){
        forms['selectedForSigning'] =true;
        this.formsAndLettersList[index]['selectedForSigning'] = true
      }else{
          forms['selectedForSigning'] =false;
        this.formsAndLetters[index]['selectedForSigning'] = false;
      }
  
  
  
    // alert(this.petition.formsAndLetters[index]['selectedForSigning']);
  
    },
    submitpetitionrequest() {
  
    this.$validator.validateAll().then((result) => {
        this.requestsignCommentError =false;
      if(this.comments =='' || this.comments.trim() =='' ){
          this.requestsignCommentError =true;
        
      }
      
      
      if (result) {
          var postdata = {
              petitionId: this.petitionDetails._id,
              comment: this.comments,
              subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
              typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),
              "formsAndLetters":[],
               "notifyPetitioner":false,
                  "emailDocsForSign":false,  
          };
          _.forEach(this.formsAndLettersList ,(item)=>{
            if(item['selectedForSigning']){
              postdata['formsAndLetters'].push(item['_id']);
            }
  
          })
  
           postdata['notifyPetitioner'] = this.notifyPetitioner
           postdata['emailDocsForSign'] = this.emailDocsForSign
      
          if(postdata['formsAndLetters'].length >0) {
            this.loading =true;
            this.$store.dispatch("requestforsign", postdata).then((response) => {
              
              this.requestsignCommentError =false;
                this.showToster({ message: response.message, isError: false });
              this.requestsignPopup = false;
              this.reloadWallList();
              
            }) .catch((error) => {
                this.formErrors = error;
                this.showToster({ message: error, isError: true });
                this.requestsignCommentError =true;
                this.loading =false;
            });
  
          }else{
              this.formErrors ='';
              this.loading =false;
             this.checkFormsandLatters=true;
          }
          
      }
    });
          
      },
  
      getscannedCopiess(isThisFromActionMenu=false){
      
          
        this.$vs.loading();      
    let finalList =[];
    if(this.checkProperty(this.petitionDetails ,'_id' )){    
      let postData ={petitionId:this.petitionDetails._id ,'page':1 ,'perpage':100000};
      this.$store.dispatch("getList" ,{data:postData,path:"/petition/scanned-copies-list"})
      .then(response => {
       
       this.$vs.loading.close();
       
      if(_.has(response , 'list')){
      let scannedCopiesList = response['list'];
      this.$vs.loading.close();
      if(isThisFromActionMenu){
        if( this.checkProperty(scannedCopiesList , 'length') >0){
        this.openAssignMentPopUp =true;
        }else{
          this.showToster({message:"Scanned Documents are required",isError:true });
          //this.$store.dispatch("setPetitionTab", 'Scanned Documents');
        
        }
  
      }
      
  
        
  
      }
  
  
  
      })
      .catch((err)=>{
        this.$vs.loading.close();
  
      })
    }
  }, 
      
    showPetitionersign() {
      //SUPERVISOR_FORMS_REVIEW
      
      this.openAssignMentPopUp =false;
      
      if(_.has(this.item,'action') && this.item['action'] =='SUPERVISOR_FORMS_REVIEW'){
       
       
        this.getscannedCopiess(true);
        
        return false;
  
      }else{
       
  
        this.formErrors ="";
        this.comments ='';
        this.loading =false;
        this.notifyPetitioner =true;
        this.emailDocsForSign =false;
        this.requestsignCommentError = false;
      
        this.$validator.reset();
   let fliterQ={ "statusId":2 }
    if(this.checkProperty(this.petitionDetails ,'maritalStatus') ==2){
      fliterQ={ "statusId":2 ,"docUserType":'Beneficiary'};
    }
    let formsAndLettersActiveList = _.filter(this.formsAndLettersList ,fliterQ)
    if(this.formsAndLettersList.length>0 && formsAndLettersActiveList.length>0){
        this.requestsignPopup = true;
      
  
    }else{
      this.showToster({ message: "Required at least one beneficiary forms and letters documents to send for signature.", isError: true });
      setTimeout(() => {
        this.goToDetaillPage();
      },100)
      
      
    }
  }
          
      }, 
  
    //Submit to uscis  
    getscannedCopiesList(){
             this.formErrors ='';
               this.loading =false;
               this.comments ='';
            this.scannedCopies =[];
              let finalList =[];
            let postData ={petitionId:this.petitionDetails['_id'] ,'page':1 ,'perpage':100000};
          this.$store.dispatch("getList" ,{data:postData,path:"/petition/scanned-copies-list"})
          .then(response => {
              
          let lst = [];
          
          _.forEach(response.list ,(mainItem)=>{
              mainItem = Object.assign(mainItem,{"reverse_document_versions":[] ,"mainParentId":'',showMe:true ,selectedForDownload:false});
              if(mainItem.parentId){
                  mainItem['mainParentId'] = mainItem['parentId']
              }else{
                  mainItem['mainParentId'] = mainItem['_id']
              }
  
              lst.push(mainItem);
                
  
          });
  
          let subList=[];
          
          //reverse_document_versions
          _.forEach(lst ,(mainItem)=>{
  
                              
              
              _.forEach(lst ,(subItem)=>{
                  if( mainItem.parentId && (mainItem.parentId == subItem['parentId'] ||  mainItem.parentId == subItem['_id']   ) &&  mainItem['_id'] != subItem['_id']){
                            
                            subItem['showMe'] =false;
                            if(subList.indexOf(subItem['_id']<=-1)){
                                mainItem['reverse_document_versions'].push(subItem);
                                subList.push(subItem['_id']);
  
                            }
                          
                          // mainItem['showMe'] =true;
                  }
  
              })
              
          if(mainItem.showMe){
                finalList.push(mainItem);
          }
          
  
            
            
  
          })
          
  
          
          this.scannedCopies =  finalList;
          const petitionerItems = this.scannedCopies.filter(item =>  item.docUserType === 'Petitioner');
          const beneficiaryItems = this.scannedCopies.filter(item =>  item.docUserType === 'Beneficiary');
          if (this.scannedCopies.length > 0 && petitionerItems.length<=0 && this.checkProperty(this.petitionDetails,'petitionerId') && [3].indexOf(this.getUserRoleId)<=-1){
            this.showToster({message:"Required at least one Petitioner scanned document to submit to USCIS." ,isError:true});
            this.goToDetaillPage();    
          }
          else if(this.scannedCopies.length > 0 && (beneficiaryItems.length > 0 || petitionerItems.length > 0)){
            this.submiTouscisPopup = true;
             this.$validator.reset();
  
          }
          else{
           
              this.submiTouscisPopup = false;
             this.showToster({message:"Scanned Documents are required" ,isError:true});
            
             this.goToDetaillPage();
          
            
  
          }
          
          
          
          }).catch((err)=>{
            this.submiTouscisPopup = false;
            this.showToster({message:"Scanned Documents are required" ,isError:true});
            this.goToDetaillPage();
          
          
              
          })
  
          
          
  
    },
  
    submitToUscisAction(){
          this.formErrors ='';
           let postData = {
               petitionId: this.petitionDetails['_id'],
              comment: this.comments,
              action:'SUBMIT_TO_USCIS', // "SUBMIT_TO_LAW_FIRM", // "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "SUBMIT_TO_USCIS" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED" 
              today: moment().format('YYYY-MM-DD'), // Required on Status changes to "Received RFE"
             subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
             typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),
  
           };
          
           this.$validator.validateAll("activityfoform").then((result) => {
              if (result) {
                 this.loading =true;
                 this.$store
                .dispatch("commonAction", {"data":postData ,"path":"/petition/manage-approval-process"})
                .then(response => {
                   this.loading =false;
                   this.showToster({message:response.message,isError:false });
                   this.submiTouscisPopup =false;
                   this.reloadWallList()
                  
                  
                                  
                })
                .catch((error)=>{
                  this.loading =false;
                  this.formErrors =error;
                })
         
         
  
                
              }
            });
             
  
         
  
      },
  
      //Courier Tracking
      updateTrackingDetails() {
          // this.$vs.loading();
           this.$vs.loading.close();
          this.updateTrackingPopup = false;
          this.formErrors ='';
          this.loading =false;
          this.filesAreuploading =false;
          this.tracking.trackingId ='';
  
          this.tracking.documents = [];
          this.uscisdocument = [];
          this.trackingdoc = [];
          
            if(!(_.has(this.petitionDetails , 'courierTrackingCategory')) || (  _.has(this.petitionDetails , 'courierTrackingCategory') && !this.petitionDetails['courierTrackingCategory'] )){
            //petition.courierTrackingCategory
            //this.tracking['courier'] =null;
            // this.tracking['trackingId'] ='';
          }
  
          if(this.petitionDetails.nextWorkflowActivity.indexOf("COURIER_TRACKING")>-1 || this.petitionDetails.nextWorkflowActivity.indexOf("UPDATE_USCIS_RECEIPT_NUMBER")>-1){
            this.updateTrackingPopup = true;
          }
         //  this.$vs.loading.close();
          
            
      }, 
      changedCourier() {
      if(_.has(this.tracking ,'courier') && (_.has(this.tracking['courier'] ,'code')) ){
  
      this.tracking = Object.assign(this.tracking ,{'courierCode':this.tracking["courier"]["code"] });
  
      }
      if(_.has(this.tracking ,'courier') && (_.has(this.tracking['courier'] ,'track_url')) ){
  
      this.tracking = Object.assign(this.tracking ,{"trackingUrl":this.tracking["courier"]["track_url"]  });
  
      }
  
            
          // this.tracking.trackingUrl = this.tracking["courier"]["code"];
          // this.tracking.courierCode = this.tracking["courier"]["code"];
      },
      updateTracking() {
  
      //this.petition.nextWorkflowActivity
            this.formErrors ='';
          this.loading =false;
          this.$validator.validateAll("trackingform").then((result) => {
              if (result) {
                  this.tracking.petitionId = this.petitionDetails._id;
                  this.tracking.action =
                      this.petitionDetails.courierTrackingCategory != "UPDATE_TRACKING_NUMBER" ?
                      "UPDATE_TRACKING_NUMBER" :
                      "UPDATE_USCIS_RECEIPT_NUMBER";
                  
                  this.tracking.action =this.petitionDetails.nextWorkflowActivity;
                
                  if(this.trackingdoc && this.trackingdoc.length>0){
                      this.tracking = Object.assign(this.tracking,{"documents":this.trackingdoc});
                  }
                  
  
                    let tracking = _.cloneDeep(this.tracking);
                  if(_.has(tracking , "courier")){
  
                      let courier = _.cloneDeep(tracking['courier'] );
                      if((_.has(courier  , "name"))){
                        tracking = Object.assign( tracking , { 'courier':courier['name'] });
                      }
                      if((_.has(courier  , "code"))){
                        tracking = Object.assign( tracking , { 'courierCode':courier['code'] });
                      }
                  }
  
                this.loading =true;
             
                  this.$store
                      .dispatch("updateTrackingDetails", tracking)
                      .then((response) => {
                          
                            this.formErrors ='';
                          this.showToster({ message: response.message, isError: false });
                            this.loading =false;
                          this.updateTrackingPopup = false;
                          this.reloadWallList();
                          
                      })
                      .catch((error)=>{
                          this.formErrors =error;
                        this.loading =false;
                        //this.showToster({ message: error, isError: true });
  
                      });
  
              }
  
          })
  
      },
       getCourierList(callBack=null) {
        let postdata = {};
  
        this.$store.dispatch("getCourierList", postdata).then((response) => {
         // alert(JSON.stringify(response))
          
          //this.courierList = response;
        });
        //tracking/list
         this.$store.dispatch("getList",{data:postdata ,path:'/tracking/courierlist'} ).then(response => {
          if(this.checkProperty(response , "list")){
            this.courierList = response.list;
          }
            if(callBack){
            callBack();
            }
          
          
        });
  
      },
      selectedDocuments(index, fls) {
        let docs = _.cloneDeep(fls)
  
        docs = docs.map(
            (item) =>
            (item = {
                name: item.name,
                file: item.file,
                url: "",
                path: "",
                mimetype: item.type,
                documentType:item.documentType?item.documentType:null
            })
        );
        
        if (docs.length > 0) {
            var self = this;
            this.filesAreuploading = true;
            let count =0;
            docs.forEach(function (doc) {
                let formData = new FormData();
                formData.append("files", doc.file);
                formData.append("secureType", "private");
                self.$store.dispatch("uploadS3File", formData).then((response) => {
                  count = count+1;
                    if (response.data && response.data.result) {
                        response.data.result.forEach((urlGenerated) => {
                            doc.url = urlGenerated;
                              doc.path = urlGenerated;
                            delete doc.file;
                            self.tracking.documents = docs;
                            self.uscisdocument = docs;
                            self.trackingdoc = docs;
                            
                            
                                
                              if(parseInt(count)>=docs.length){
                                self.filesAreuploading = false;
                              
  
                            }
                        });
                        if(count>=docs.length){
                          self.filesAreuploading = false;
  
                        }
                        
                    }
                    
                });
            });
        }
      },
       remove(item, type) {
          type.splice(type.indexOf(item), 1);
          return false;
      },
      fileNameChenged(fl) {
              let fname = fl["name"];
              fname = fname.trim();
              this.isInvaliedFileName = false;
              if (!fname) {
                  this.isInvaliedFileName = true;
              }
          },

        checkCaseInvoice(){
          this.preparePermInvoiceError ="";
          this.showInvoiceError =false;

        let  path ="/petition/check-invoice-status";
        let postData ={
        "petitionId":null
        };

        if( this.checkProperty(this.petitionDetails,'typeDetails','id')==3 && this.checkProperty(this.petitionDetails,'subTypeDetails','id')==15){
        path ="/perm/check-invoice-status";
        } 

        postData['petitionId'] =this.petitionDetails['_id'];
        //enableFilingFee fileAfterInvoice fileAfterPayment

        this.$vs.loading();

        this.$store.dispatch("commonAction", {data:postData,path:path})
        .then((response) => { 

          this.updateUSCISstatusPopup = true;
         this.$vs.loading.close();


        }).catch((error) => { 

        
        this.preparePermInvoiceError=error;
        this.showInvoiceError =true;
        this.$vs.loading.close();


        });

        },
  
      ///updateUSCISstatus
  
      updateUSCISstatus(checkInvoice=false){
  
         this.casestatus =null;
         this.uscisdocument =[];
        this.dueDate =null;
        this.receivedDate =null;
        this.issuedDate =null;
        this.disabledStatus =false;
         this.filesAreuploading =false;
              
              this.comments='';
              this.formErrors='';
              this.loading =false;
              this.updateUSCISstatusPopup = false;
  
              //UPDATE_USCIS_RESPONSE uploadUscisDocs
          if(this.petitionDetails.nextWorkflowActivity.indexOf('UPDATE_USCIS_RESPONSE')>-1  || (this.checkProperty( this.petitionDetails ,'autoUscisStatusUpdate')==true && this.checkProperty( this.petitionDetails ,'uploadUscisDocs')==false)){
  
            if(this.petitionDetails && _.has(this.petitionDetails ,'currentActivity') && _.find(this.uscisstatuslist ,{"value":this.petitionDetails['currentActivity']}) ){
             this.casestatus = _.find(this.uscisstatuslist ,{"value":this.petitionDetails['currentActivity']});
             this.disabledStatus =true;
             
             if(_.has( this.petitionDetails,'rfeNotice') && (_.has( this.petitionDetails['rfeNotice'],'receivedDate'))){
                this.receivedDate = this.petitionDetails['rfeNotice']['receivedDate'];
             }
          }
          
          }
          if(checkInvoice){
            this.checkCaseInvoice();
          }else{
            this.updateUSCISstatusPopup = true;
          }
          
          
  
      },
      petitionApproval() {
              //alert(this.approveRejecInstructions);
              this.formErrors='';
              this.loading =false;
              let self =this;
              this.$validator.validateAll("uscisstatus").then((result) => {
                  if (result) {
                    
                    
                      // this.approveRejec_Instructions="* Instructions is required"
  
                      let payload_data = {
                          petitionId: this.petitionDetails._id,
                          comment: this.comments,
                          action: this.casestatus.value,
                           "today": moment().format("YYYY-MM-DD"),
                           "typeName":this.petitionDetails.typeDetails.name,
                           "subTypeName":this.petitionDetails.subTypeDetails.name
                      };
  
                      let rfepayload = {
                          petitionId: this.petitionDetails._id,
                          comment: this.comments,
                          description: this.comments,
                          action: this.casestatus.value, //'UPDATE_USCIS_RESPONSE'
                           "today": moment().format("YYYY-MM-DD"),
                            "typeName":this.petitionDetails.typeDetails.name,
                           "subTypeName":this.petitionDetails.subTypeDetails.name
                      };
                      // "action": "QUESTIONNIRE_APPROVED" // "QUESTIONNIRE_REJECTED" / "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "READY_FOR_FILING" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED"
  
                      if (this.casestatus.value == "USCIS_RECEIVED_RFE") {
                          payload_data["today"] = moment().format("YYYY-MM-DD");
                          payload_data["typeName"] = this.petitionDetails.typeDetails.name;
                          payload_data["subTypeName"] = this.petitionDetails.subTypeDetails.name;
  
                          rfepayload["today"] = moment().format("YYYY-MM-DD");
                          rfepayload["typeName"] = this.petitionDetails.typeDetails.name;
                          rfepayload["subTypeName"] = this.petitionDetails.subTypeDetails.name;
  
                          rfepayload["issuedDate"] = moment(this.issuedDate).format(
                              "YYYY-MM-DD"
                          );
                          rfepayload["receivedDate"] = moment(this.receivedDate).format(
                              "YYYY-MM-DD"
                          );
                          rfepayload["dueDate"] = moment(this.dueDate).format("YYYY-MM-DD");
                        
                      }
                        rfepayload["documents"] = this.uscisdocument;
                      this.loading =true;
                      this.filesAreuploading =false;
                      rfepayload["today"] = moment().format("YYYY-MM-DD");
                      //alert(JSON.stringify(rfepayload)); 
                      this.$store
                          .dispatch("manageApproval_process", rfepayload)
                          .then((response) => {
                              if (self.casestatus.value == "USCIS_RECEIVED_RFE") {
                                  self.$store.dispatch("fileRFE", rfepayload).then((response) => {
                                     
                                      //this.showMessages(response.message);
                                      self.showToster({ message:response.message , isError: false})
                                      self.updateUSCISstatusPopup = false;
  
                                       this.reloadWallList()
                                  });
                              } else {
                               
                                 
                                 // this.showMessages(response.message);
                                    self.showToster({ message:response.message , isError: false})
                                  self.updateUSCISstatusPopup = false;
                                   this.reloadWallList()
                              }
                                this.loading =false;
                          })
                          .catch((error) => {
                             this.loading =false;
                             this.filesAreuploading =false;
                             this.formErrors =error;
                            this.showToster({ message: error, isError: true });
                          });
                  }else{
                   // this.showToster({ message:"Invalid data" , isError: true});
                  }
              });
          },
  
     // petetioner
      getpetetioner(  approveConformpopUp =false) {
              let companyId = this.checkProperty(this.item ,"data", "companyId")
              this.$vs.loading();
              this.$store
                  .dispatch("petitioner/getpetetioner", {
                      companyId: companyId
                  })
                  .then(response => {
                    this.approveConformpopUp =approveConformpopUp;
                     this.$vs.loading.close();   
                      this.petitioner = response;
                      this.petitioner['petitionerId'] = response['userId'];
                  }).catch((err)=>{
  
                   this.$vs.loading.close();   
                  });
     
      },
      openApprovepopup(status=2 ,txt=''){
          this.actionText = "Do you want to "+txt+" ?",
          this.popupbtnTxt = txt;
          this.selectedStatus = status;
          this.approveConformpopUp =false;
            this.getpetetioner(true);
  
        }, 
        changetPetitionerstatus( ){
          let post_data = {"companyId":this.petitioner['_id'], "statusId":this.selectedStatus };
          let sts = _.find(this.all_statusids ,{"id":this.selectedStatus});
          if(sts && _.has(sts,"name")){
            post_data['statusName'] = sts['name']
  
          }
          //alert(JSON.stringify(post_data));
  
          //post_data = Object.assign(post_data,{"petitionerId":this.selectedpetitioner['_id'] ,"statusId":this.selectedStatus})
           this.loading = true;
           this.formErrors ='';
            this.$store.dispatch("commonAction", {data:post_data ,"path":"/company/update-status"}).then((res) => {
                this.approveConformpopUp =false;
                this.loading =false;
                this.showToster({message:res.message,isError:false });
                this.reloadWallList();
                 
  
              }).catch((error) => {
                  this.loading =false;
                  this.formErrors = error;
                  this.showToster({message:error,isError:true });
                 
  
              });
  
        }, 
        getCompanyStatusList(){
          this.all_statusids =[];
           let postdata ={
          page:1,
          perpage: 1000,
          category: "company_status",
         
        };
          this.$store.dispatch("getMasterData" ,postdata)
          .then((res)=>{
            this.all_statusids = res['list'];
            this.all_statusids = _.filter(this.all_statusids ,(item)=>{
              return [1,2,3,4].indexOf(item['id'])>-1;
  
             })
  
          })
          .catch(()=>{
  
          })
  
  
        },  
  
        findDetailsPage(petitionId=''){
  
           
  
          if(petitionId){
            if([51].indexOf(this.getUserRoleId) >-1){
              if((
                (this.assignmentActivityes.indexOf(this.checkProperty( this.item ,'data' , 'category'))>-1)
               //|| (this.petitionToDoList.indexOf(this.checkProperty( this.item ,'data' , 'category')) >-1 && this.checkProperty( this.item ,'status' ))
               || (this.checkProperty( this.item ,'data' , 'category')== 'CASE_APPROVED' && this.checkProperty( this.item ,'status'))
               || (this.checkProperty( this.item ,"data" , "category")== "REQUEST_PETITIONER_SIGN" && this.checkProperty( this.item ,"status"))
               || (this.checkProperty( this.item ,'data' , 'category')== 'APPROVED_BY_DOC_MANAGER' && this.checkProperty( this.item ,'status'))
               || (this.checkProperty( this.item ,'data' , 'category')== 'SUBMIT_TO_USCIS' && this.checkProperty( this.item ,'status'))
               || (['UPDATE_USCIS_RECEIPT_NUMBER' ,'COURIER_TRACKING'].indexOf(this.checkProperty( this.item ,'data' , 'category'))>-1 && this.checkProperty( this.item ,'status'))
               || (['UPDATE_USCIS_RESPONSE'].indexOf(this.checkProperty( this.item ,'data' , 'category'))>-1 && this.checkProperty( this.item ,'status'))
             
               || (
                [
                'CREATE_JOB_DESC' ,'REQUEST_JOB_DESC_REVIEW' ,
               'JOB_DESC_SUGGESSION' ,'APPROVE_JOB_DESC','FINALIZE_JOB_DESC',
               'UPDATE_PWD_RESPONSE','COLLECT_ADV_EVIDENCE','PREPARE_PERM_APPLICATION',
               'REQUEST_PERM_DRAFT_REVIEW','PERM_DRAFT_SUGGESSION',
               'APPROVE_PERM_APPLICATION','EFILE_PREM_APPLICATION','UPDATE_DOL_RESPONSE','EFILE_PWD'
              ].indexOf(this.checkProperty( this.item ,'data' , 'category'))>-1 && this.checkProperty( this.item ,'status'))
               
               || (['UPDATE_DOL_RESPONSE'].indexOf(this.checkProperty( this.item ,'data' , 'category'))>-1 && this.checkProperty( this.item ,'status'))
  
              )){
                
                if([3].indexOf(this.checkProperty( this.item ,'data' , 'type'))>-1 ){
                  
                  this.$router.push("/gc-employment-details/"+petitionId);
                }else{
                  this.$router.push("/petition-details/"+petitionId);
  
                }
  
               
              }else{
                if([3].indexOf(this.checkProperty( this.item ,'data' , 'type'))>-1 && [15].indexOf(this.checkProperty( this.item ,'data' , 'subType'))>-1 ){
                  this.$router.push("/perm-questionnaire/"+petitionId);
  
                }else{
                  this.$router.push("/questionnaire/"+petitionId);
                }
                  
              }
            
            }else{
              if([3].indexOf(this.checkProperty( this.item ,'data' , 'type'))>-1 && [15].indexOf(this.checkProperty( this.item ,'data' , 'subType'))>-1 ){
               if(this.checkProperty( this.item ,'data' , 'category') == 'FILING_FEE'){
                this.$router.push({ name: 'gc-employment-details', params: { itemId:petitionId,tabname:'Fees/Invoices' } }).catch(err => {})
               }
               else{
                this.$router.push("/gc-employment-details/"+petitionId);
               }              
              }else{
                  this.$router.push("/petition-details/"+petitionId);
  
              }
            }
          }
  
        }
      
     
  
    },
   data: () => ({
    selectedRfeAction:'',
    rfePraperResDocs:false,//RFE_PREPARE_RESPONSE_DOCS
    rfeCaseApproved:false,//RFE_CASE_APPROVED
    rfeReqPetSign:false,//RFE_REQUEST_PETITIONER_SIGN
    rfeSubmitToUsis:false,  //SUBMIT_TO_USCIS 
    rfecourierTeacking:false,//RFE_COURIER_TRACKING
    rfeUpdateUscIsReceiptNumber:false,//RFE_UPDATE_USCIS_RECEIPT_NUMBER 
    rfeUpdateUSCISstatusPopup:false,// RFE_UPDATE_USCIS_RESPONSE

    settingCaseNumber:false,
    assignCaseNumberConformation:false,
    managePop:'',
    signedDocumentModal:false,
    deleteWallConformpopUp:false,
    preparePermInvoiceError:'',
    showInvoiceError:false,
    editor: ClassicEditor,
   editorConfig: {
       toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
   },
    openTaskRejectPopUp:false,
    accepting:false,
     error:'',
     payloadAccept: {
      "taskId": "",
      "action": "",
      "comment": ""
    },
     notifyPetitioner:false,
     emailDocsForSign:false,
     isotopGrid:null,
     isInvaliedFileName:false,
      documentTypes:["Original" ,"Electronic" ],
      jaquery: null,
      settingCaseNumber:false,
      setCode:false,
      newCaseCode:'',
      confCaseCode:'',
  
     item:null,
     isAddcls:false,
      documentsViewPopup:false,
      skipedActivityList:[],
      workFlowDetails:null,
     assignMentUsersList:{
        "ASSIGN_SUPERVISOR":"SUPERVISOR_LIST",
        "ASSIGN_PARALEGAL":"PARALEGAL_LIST",
        "ASSIGN_DOCUMENTATION_MANAGER":"DOCUMENTATION_MANAGER_LIST",
        "ASSIGN_DOCUMENTATION_EXECUTIVE":"DOCUMENTATION_EXECUTIVE_LIST",
        "ASSIGN_ATTORNEY":"ATTORNEY_LIST",
        },
        petitionToDoList:[],
        assignmentActivityes:[],
         showPopup:false,
          selectedUser:null,
          usersList:[],
          formErrors: "",
          comments:'',
          loading:false,
          petitionDetails:null,
          skipedActivity:false,
          approveCasePopup:false,
          lcaDetails:null,
          approveOrRejectDocs:false,
  
          //tenant Relate Todo
          tenantTodoList:['TENANT_CREATED' ],
          tenantDetails:null,
          tntActionText:'',
          popuptntTxt:'',
          selectedtenantStatus:0,
          approveTenantConformpopUp:false,
  
          //Request for signin
          requestsignPopup:false,
          formsAndLettersList:[],
          checkFormsandLatters:false,
          requestsignCommentError:false,
  
          //Submit to Uscis
          scannedCopies:[],
          submiTouscisPopup:false,
  
          //Courier Tracking
          updateTrackingPopup:false,
          tracking: {documents:[],receiptNumber:null,receiptName:null},
          trackingdoc: [],
          filesAreuploading:false,
          courierList:[],
  
         //update USCIS Status
         updateUSCISstatusPopup:false,
         openAssignMentPopUp:false,
         disabledStatus:false,
         uscisstatuslist: [
        {
          value: "USCIS_APPROVED",
          text: "Case Approved",
        },
        {
          value: "USCIS_RECEIVED_RFE",
          text: "RFE Received",
        },
        {
          value: "USCIS_DENIED",
          text: "Case Denied",
        },
        {
          value: "USCIS_WITHDRAWN",
          text: "Case Withdrawn",
        },
      ],
      casestatus:null,
       issuedDate: null,
      receivedDate: null,
      dueCate: null,
      dueDate:null,
      openDate: new Date().setFullYear(new Date().getFullYear()),
      startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
      uscisdocument:[],
  
      //COMPANY_CREATED
      petitioner:null,
      actionText:"",
      popupbtnTxt:'',
      selectedStatus:null,
      approveConformpopUp:false,
      //all_statusids:[]
     
    }),
    mounted(){
        this.jaquery = JQuery;
  
        this.isAddcls =false;
        this.petitionToDoList = ["CREATE_PETITION" ,'SUBMIT_BY_BENEFICIARY','LCA_REQUEST' ,'SUBMIT_TO_LAW_FIRM' ,'ASSIGN_SUPERVISOR' ,"ASSIGN_PARALEGAL" ,"ASSIGN_DOCUMENTATION_MANAGER","ASSIGN_DOCUMENTATION_EXECUTIVE" ,"ASSIGN_ATTORNEY" ,"REQUEST_DOC_EXECUTIVE_TO_UPLOAD","UPLOAD_BY_DOC_EXECUTIVE" ,"CASE_APPROVED"]
        this.assignmentActivityes = ['ASSIGN_SUPERVISOR' ,"ASSIGN_PARALEGAL" ,"ASSIGN_DOCUMENTATION_MANAGER","ASSIGN_DOCUMENTATION_EXECUTIVE" ,"ASSIGN_ATTORNEY"]
        this.tenantTodoList = ['TENANT_CREATED' ];
        //this.getCompanyStatusList();
        this.assignMentUsersList = {
        "ASSIGN_SUPERVISOR":"SUPERVISOR_LIST",
        "ASSIGN_PARALEGAL":"PARALEGAL_LIST",
        "ASSIGN_DOCUMENTATION_MANAGER":"DOCUMENTATION_MANAGER_LIST",
        "ASSIGN_DOCUMENTATION_EXECUTIVE":"DOCUMENTATION_EXECUTIVE_LIST",
        "ASSIGN_ATTORNEY":"ATTORNEY_LIST",
        };
        this.initIsotop();
        
         
   } ,
    computed:{
      

      checkNoNotifyUserIds(){
      let returnValue =true;
      if(_.has(this.petitionDetails, 'noNotifyUserIds')  ){
        if(this.petitionDetails['noNotifyUserIds'].length>0){
          if(this.petitionDetails['noNotifyUserIds'].indexOf(this.getUserData['userId']) >-1){
            returnValue = false;
          }

        }

      }
      return returnValue;
      },
    checkActivityRoles(){
      let returnValue =false;
      return (code='')=>{
        if(this.workFlowDetails && _.has(this.workFlowDetails ,'config')){
          //alert(code);
          let activity = _.find(this.workFlowDetails['config'] ,{'code':code});
          if(activity && _.has(activity ,'editors') && activity['editors'].length>0){
            let editors =_.map(activity.editors, 'roleId');
            if(editors.indexOf(this.getUserRoleId) >-1){
              returnValue =true;
            }
          }



        }
        
        return returnValue;

      }
    }
       
      
    },
    watch:{
      /*
       this.rfePraperResDocs =false;
       this.rfeCaseApproved =false;
       this.rfeReqPetSign = false;
       this.rfeSubmitToUsis =false;
       this.rfecourierTeacking =false;
       this.rfeUpdateUscIsReceiptNumber =false;
       this.rfeUpdateUSCISstatusPopup =false;
      */
      rfePraperResDocs:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
        rfeCaseApproved:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
      rfeReqPetSign:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
        rfeSubmitToUsis:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
        rfecourierTeacking:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
        rfeUpdateUscIsReceiptNumber:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
        rfeUpdateUSCISstatusPopup:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    setCode:function(value){
       if(value){
        this.toggleCalssToRow(true);
       }else{
        this.toggleCalssToRow(false);
       }
    },
    showPopup:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    approveCasePopup:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    approveOrRejectDocs:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    approveTenantConformpopUp:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    requestsignPopup:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    submiTouscisPopup:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    signedDocumentModal:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    updateTrackingPopup:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    updateUSCISstatusPopup:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    openAssignMentPopUp:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    approveConformpopUp:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    documentsViewPopup:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    openTaskRejectPopUp:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    showInvoiceError:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },
    deleteWallConformpopUp:function(value){
          if(value){
            this.toggleCalssToRow(true);
          }else{
            this.toggleCalssToRow(false);
          }
        },


    
    
   }
  };
  </script>
  
  <style>
  .tooltip.vue-tooltip-theme  {min-width: auto;}
  .tooltip.vue-tooltip-theme .tooltip-inner {color:#000 !important; min-width:auto !important;}
  </style>