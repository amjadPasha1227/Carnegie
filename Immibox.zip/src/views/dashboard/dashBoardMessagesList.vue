<template>
    <div class="dashboard-msg-list">
      <div class="accordian-table custom-table new_messages_table new_messages_table_v2">
       <template v-if="tickets.length>0">
          <vs-table :data="tickets" >
            <template v-if="tickets.length > 0" slot="thead">
              <vs-th> From </vs-th>
              <vs-th > Message </vs-th>
              
              
            </template>
            <template slot-scope="{ data }">
              <template v-for="mesage in data">
                <messageComponent
                :loadedFromDashBoard="true"
                @updateLabels="updateLabels"
                 @updateUserIds="updateUserIds"
                  @openDetailsPage="openDetailsPage" 
                @goToDetailsPage="goToDetailsPage"
                 @openCreateLabel="openCreateLabel"
                  :labelsList="labelsList"
                   :message="mesage" />
            </template>
            </template>
          </vs-table>
        </template>
      </div>
        <labelCreatePopup :loadedFromDashBoard="true"  v-if="createLabelPopup" @openLabelPopup="openLabelPopup" />
        
        <div class="dashboard-msg-details workflow_view_wrap taskmanagement messages_side_popup" v-if="showMessageDetails" :class="{ listopen: showMessageDetails }">
        <div class="workflow_overlay"></div>
        <div class="workflow_view_cnt questionary_cnt">
          <div class="workflow_view_title pr-0">          
              <span @click="showMessageDetails = false;getNotes()"><x-icon size="1.5x" class="custom-class"></x-icon></span>
          </div>  
         <messageDetails :loadedFromDashBoard="true" @goToDetailsPage="goToDetailsPage" @updateUserIds="updateUserIds" :labelsList="labelsList"  @getNotes="getNotes"
         @openCreateLabel="openCreateLabel" @updateLabels="updateLabels" :selectMessage="selectedMessage" :details="seletedmessageDetails" />
        </div>
         </div>
    </div>
    
</template>
<script>


import labelCreatePopup from "@/views/messages/labelCreatePopup.vue";
import messageDetails from "@/views/messages/messageDetails.vue";
import messageComponent from "@/views/messages/messageComponent.vue";
import DateRangePicker from "vue2-daterange-picker";
import Paginate from "vuejs-paginate";
import Datepicker from "vuejs-datepicker-inv";
import Multiselect from "vue-multiselect-inv";
import JQuery from "jquery";
import simpleColorPicker from "@/views/forms/fields/simpleColorPicker.vue";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import FileUpload from "vue-upload-component/src";
import moment from "moment";
import _ from "lodash";
import NoDataFound from "@/views/common/noData.vue";
import { MoreVerticalIcon } from "vue-feather-icons";
import selectField from "@/views/forms/fields/simpleselect.vue";
import { XIcon } from 'vue-feather-icons';
import messageAssign from "@/views/messages/messageAssign.vue";
import immitextfield from "@/views/forms/fields/simpleTextField.vue";
export default {
    provide() {
            return {
                parentValidator: this.$validator,
            };
        },
  components: {
    labelCreatePopup,
    messageDetails,
    XIcon,
    messageComponent,
    selectField,
    simpleColorPicker,
    Datepicker,
    DateRangePicker,
    Multiselect,
    Paginate,
    FileUpload,
    NoDataFound,
    MoreVerticalIcon,
    messageAssign,
    immitextfield
  },
  data: () => ({
    selectedMsgType:'inbox',
    createLabelPopup:false,
    debounce:null,
    peritioners_search_value:'',
    labelCreatedForMessage:null,
    callFromComponent:false,
    seletedmessageDetails:null,
    selectedMessage:null,
    showMessageDetails:false,
    labelsList:[],
    loadingLabel:false,
    labelName:'',
    selectColor:'',
    openAssignPopup:false,
    usersList:[
    {
            "_id": "62580705621cbad27e277687",
            "id": "62580705621cbad27e277687",
            "roleId": 11,
            "branchId": "6257fa6f621cbad27e2773a5",
            "userId": "62580705621cbad27e277687",
            "name": "Philips Cantona",
            "value": "Philips Cantona",
            "roleName": "LCA Manager"
        },
        {
            "_id": "6258079b621cbad27e27770e",
            "id": "6258079b621cbad27e27770e",
            "roleId": 11,
            "branchId": "6257fa6f621cbad27e2773a5",
            "userId": "6258079b621cbad27e27770e",
            "name": "Caldwell Ogley",
            "value": "Caldwell Ogley",
            "roleName": "LCA Manager"
        },
    ],
    callFromRefresh:false,
    selectedLabelIds:[],
    selectedAssigneeList:[],
    petitionerIds: [],
    petitionerList:[],
    isListLoading: false,
    taggedModal: false,
    noteTaggedToDetails:null,
    selectedNote:null,
     messageFilters: {
            caseNo: "",
            petitionIds: [],
            typeIds: [],
            subTypeIds: [],
            createdDateRange: []
        },
    filteredVisaType:null,
    //selectedVisaType:null,
    selected_subtypes:[],
    visaTypes:[],
    all_subtypes:[],
    uploading: false,
    
    formerrors: {
      msg: "",
    },
    //tickets: [],
    sortKeys: {},
    sortKey: {},
    searchtxt: "",
    page: 1,
    perpage: 25,
    totalpages: 0,
    perPeges: [10, 25, 50, 75, 100],
    
    searchtxt: "",
    filter_searchtxt: "",

    buttoncol: true,
    currentuserRole: null,
    selected_createdDateRange: ["", ""],
    autoApply: "",
    roleId: 0,
    all_user_roles: [],
    users: [],
    selected_user: null,
    assignmrntPopUp: false,
    selected_role: "",

    ticket_comments: [],
    ticket: null,
    isValid: true,
    userDetails:null,
    assigneeList:[],
  }),
  watch: {
    showMessageDetails: function (value) {
      const $ = JQuery;
      if (value) {
        $('body').addClass('opened-msg-details');
      } else {
        $('body').removeClass('opened-msg-details');
      }
    },
    AddNewNote: function (value) {
      if (value) {
        this.$modal.show("newNoteModal");
      } else {
        this.$modal.hide("newNoteModal");
      }
    },
    searchtxt: function (value) {
      //this.getNotes();
    },
  },
  methods: {
    openLabelPopup(val){
      this.createLabelPopup = val;
      if(!val){
        this.getLabelsList();
      }
    },
    searchCases(){
      clearTimeout(this.debounce)
      this.debounce = setTimeout(() => {
        this.getNotes()
      }, 900)
      
    },
    openCreateLabel(val){
      this.labelCreatedForMessage = val;;
      this.callFromComponent = true;
      this.addNewLabel(true,true)
    },
    goToDetailsPage(val){
     
      let tr = val;
      this.$store.dispatch('setPetitionTab', 'set_Communication');
      if(this.checkProperty(tr,'petitionDetails') && this.checkProperty(tr,'petitionDetails','subType') == 15){
        setTimeout(()=>{
          this.goToPageDetails('/gc-employment-details/'+this.checkProperty( tr,'petitionId'));
        },5)
      }else{
        setTimeout(()=>{
          this.goToPageDetails('/petition-details/'+this.checkProperty( tr,'petitionId'));
        },5)
      }
      this.showMessageDetails = false;
      
    },
    openDetailsPage(val){
      this.selectedMessage = val;
      this.seletedmessageDetails = null;
      let payLoad={
              filters:{
                messageId:this.checkProperty(this.selectedMessage,'_id'),
                searchString:'',
                petitionIds: [],
                petitionerIds:[],
                typeIds: [],
                subTypeIds: [],
                createdDateRange: [],
              },
              page: 1,
              perpage: 100,
              sorting:{"path":"createdOn" ,"order":1},
            }
            let path = '/communication/list';
            this.$store.dispatch("getList", {'data':payLoad,'path':path}).then(response => {
                this.seletedmessageDetails = response.list;
                this.showMessageDetails = true;
            })
    },
    updateUserIds(val){
      let returnVal = val;
      _.map(this.tickets,(itemI)=>{
        if(itemI['_id'] == returnVal['messageId'] ){
          itemI['toUserIds'] = returnVal['userIds'];
          itemI['toUserList'] = returnVal['toUserList'];
        }
      }) 
      this.tickets = _.cloneDeep(this.tickets);
    }, 
    updateLabels(val){
      let returnVal = val;
      _.map(this.tickets,(itemI)=>{
        if(itemI['_id'] == returnVal['messageId'] ){
          itemI['labels'] = returnVal['labels']
        }
      })
      this.tickets = _.cloneDeep(this.tickets);
  
    },
    addNewLabel(action = false,callfromComp = false){
      this.selectColor = '';
      this.labelName = '';
      this.formerrors.msg ='';
      if(action){
        this.$modal.show('createLabelModal');
      }else{
        this.$modal.hide('createLabelModal');
      }
    },
    createLabel(){
      this.$validator.validateAll('newLabelform').then(result => {
        if(result){
          let payLoad={
            name: this.labelName,
            color: this.selectColor,
            tenantId: this.checkProperty(this.getUserData['tenantDetails'],'_id')
          }
          this.formerrors.msg = '';
          let path = '/message-label/create';
          this.loadingLabel = true;
          this.$store.dispatch("commonAction", { "data": payLoad, "path": path }).then((response)=>{
            this.showToster({message:response.message ,isError:false});
            if(this.callFromComponent && this.labelCreatedForMessage && this.checkProperty(this.labelCreatedForMessage,'_id')){
              let temp = {
                color:payLoad['color'],
                name:payLoad['name'],
                _id:response._id
              }
              _.map(this.tickets,(itemI)=>{
                if(itemI['_id'] == this.labelCreatedForMessage['_id'] ){
                  if(_.has(itemI,'labels') && this.checkProperty(itemI,'labels','length')>0){
                    itemI['labels'].push(temp)
                  }else{
                    itemI['labels'] = [];
                    itemI['labels'].push(temp)
                  }
                  if(itemI['labels'] && this.checkProperty(itemI['labels'],'length')>0){
                    let payload={
                        messageId:this.checkProperty(this.labelCreatedForMessage,'_id'),
                        labels:itemI['labels'],
                    }
                    let path='/communication/manage-labels'
                    this.$store.dispatch("commonAction", {'data':payload,'path':path}).then(response => { }).catch((err)=>{})
                  }
                }
              }) 
              this.tickets = _.cloneDeep(this.tickets)
            }
            this.loadingLabel = false;
            this.addNewLabel(false);
            this.getLabelsList();
          }).catch((err)=>{
            this.formerrors.msg =err;
            this.loadingLabel = false;
          })
        }
      })
    },
    getLabelsList(){
      let payLoad={
        matcher:{
          statusList:[],
          searchString:''
        },
        page:1,
        perpage:10000
      };
      let path='/message-label/list'
      this.$store.dispatch("getList", { "data": payLoad, "path": path }).then((response)=>{
        if(response.list){
          let list = response.list;
          let tempList = []
          _.forEach(list,(item)=>{
            if(!_.has(item,'id')){
              item['id'] = item['_id'];
              tempList.push(item)
            }
          })
          if(this.checkProperty(tempList,'length')>0){
            this.labelsList = tempList
          }
        }
      }).catch((err)=>{

      })
    },
    showTaggedDetails(action = false, item) {
      let Payload= {
        "matcher": {
        "title": "",
        "searchString": "",
        "userIds": [],
        "statusIds": [],
        "petitionSubTypeIds": [],
        "petitionSearchString": "",
        "createdDateRange": []
      },
      "sorting": {
        "path": "createdOn",
        "order": 1
      },
      "page": 1,
      "perpage": 1000,
      "getMasterData": true
      }
      // if(this.checkProperty(selectedItemm,'toUserIds')){
      //   Payload['matcher']['userIds'] = this.checkProperty(selectedItemm,'toUserIds')
      // }

      this.$store.dispatch("getList", {"data":Payload ,"path":"/users/list"})
      .then(response => {
        if(this.checkProperty(response ,'list') && this.checkProperty(response ,'list','length')>0){
          let list = _.filter(response['list'],(itm)=>{
            return [51,50].indexOf(itm['roleId'] <=-1)
          })
          this.assigneeList =  list
        }
        
        this.userDetails = response.list
      })
    },
     communicationlink(tr){
      
      this.$store.dispatch('setPetitionTab', 'set_Communication');
      setTimeout(()=>{
         this.goToPageDetails('/petition-details/'+this.checkProperty( tr,'petitionId'));
      },5)
     

  },
     changedVsaType(){
    let petitionSubType = this.messageFilters.typeIds.map((item)=>item.id)
        let item ={
          matcher:{
              petitionTypes: petitionSubType,
            },   

          page:1,
          perpage: 10000,
          category: "petition_sub_types",
          
        };
        if(this.checkProperty(petitionSubType , 'length')>0){
            let subTypeIds =  _.cloneDeep(this.messageFilters.subTypeIds);
            this.messageFilters.subTypeIds = _.filter(subTypeIds , (item)=>{
            return petitionSubType.indexOf(item['type']) >-1
            })
        }else{

            this.messageFilters.subTypeIds =[];

        }

        this.$store.dispatch("getMasterData",item ).then(response => { this.all_subtypes = response.list;  });
       
      
    },
     getVisaTypes(){
     let item ={
          matcher:{
              "searchString":'',
              getWorkFlowConfig:true
             // "petitionType":

          },   
          page:this.page,
          perpage: this.perpage,
          category: "petition_types",
         "sorting": {
            "path": "name",
            "order": 1
            }
          
        };

        this.$store
          .dispatch("getMasterData",item )
          .then(response => {
            this.visaTypes = response.list;

             if(this.checkProperty(this.$route ,'query' ,'filter')){
                try{
                  let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                  var actual = JSON.parse(atob(filter));
                  let keys = Object.keys(actual);
                  if(this.checkProperty(keys ,'length') >0){


                    if(actual && (Object.keys(actual)).length>0 ){
                    _.forEach(actual ,(item ,key) => {
                        if(key=='matcher' ){
                          
                          if((Object.keys(item)).length>0 ){

                            if(_.has(item ,'typeIds') && this.checkProperty(item , 'typeIds' ,'length')>0 ){
                               
                              this.filteredVisaType = _.find(this.visaTypes ,{"id":item['typeIds'][0]})
                           
                             this.getvisa_subtypes();
                           
                            }

                            
                            
                          }
                        
                        }
                      
                        
                    
                    })
                  }
                    
                    
                  }

                }catch(e){
                  

                }
                  
              }


           
          });
   },
   peritioners_search_fun(searchValue) {
      this.peritioners_search_value = searchValue;
      this.getPeritioners();
    },
   
    getCalssName(statusName = "") {
      return "note-" + statusName.toLowerCase();
    },

 
  

 
    

  
   
    pageNate(pageNum) {
      this.page = pageNum;
      this.getNotes();
    },

    set_filter: function () {
      //this.final_selected_statusids = [];

    //   if (this.selected_statusids.length > 0) {
    //     this.final_selected_statusids = [];
    //     for (let ind = 0; ind < this.selected_statusids.length; ind++) {
    //       let current_index = this.selected_statusids[ind];
    //       this.final_selected_statusids.push(current_index["id"]);
    //     }
    //   }

      this.searchtxt = this.filter_searchtxt;

      this.getNotes();
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    clear_filter: function () {
      this.searchtxt = "";
      this.selected_statusids = [];
      this.final_selected_statusids = [];

      this.date = "";
      this.date_range = [];
      this.selected_createdDateRange["startDate"] = "";
      this.selected_createdDateRange["endDate"] = "";
      this.filterTaggedToIds = [];
      this.filterAccessLevels = [];
      this.messageFilters.typeIds =[];
      this.messageFilters.subTypeIds =[]; 
      this.petitionerIds=[];

      this.filter_searchtxt = "";
      this.$refs["filter_menu"].dropdownVisible = false;
      this.getNotes();
    },
    filterByPetitioner(){
      this.getNotes()
    },
    filterByLabel(){
      this.getNotes()
    },
    filterByAssign(){
      this.getNotes()
    },
    
    getNotes(callFromRefresh=false) {
      return false;
      this.callFromRefresh =callFromRefresh;
      let obj = {
        filters: {
          searchString: this.searchtxt,
          petitionIds: [],
          petitionerIds:[],
          typeIds: [],
          subTypeIds: [],
          createdDateRange: [],
          labelIds:[],
          assignedToIds:[],
          msgListType:this.selectedMsgType,
        },
        page: this.page,
        perpage: this.perpage,
      };

      if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        obj["filters"]["createdDateRange"] = [
          moment(this.selected_createdDateRange["startDate"]).format("YYYY-MM-DD"),
          moment(this.selected_createdDateRange["endDate"]).format("YYYY-MM-DD")
        ];
      }

      obj["filters"]["typeIds"] = this.messageFilters.typeIds.map((item) => {
        return item["id"];
      });
      obj["filters"]["subTypeIds"] = this.messageFilters.subTypeIds.map((item) => {
        return item["id"];
      });
       obj["filters"]["petitionerIds"] = this.petitionerIds.map((item) => {
        return item["_id"];
      });
      if(this.checkProperty(this.selectedAssigneeList,'length')>0){
        obj["filters"]["assignedToIds"] = this.selectedAssigneeList.map((item) => {
        return item["_id"];
      });
      }
      if(this.checkProperty(this.selectedLabelIds,'length')>0){
        obj["filters"]["labelIds"] = this.selectedLabelIds.map((item) => {
        return item["_id"];
      });
      }
     
      
      this.isListLoading = true;
      
      this.updateLoading(true);
      this.tickets = [];
      //this.$store .dispatch("supportTicketsList", obj) 
      this.$store
        .dispatch("getList", { data: obj, path: "/communication/list" })
        .then((response) => {
          let self = this;
          this.callFromRefresh =false;
          this.isListLoading = false;
          this.updateLoading(false);
          setTimeout(() => {
            this.updateLoading(false);
          }, 10);
          setTimeout(() => {
            this.isListLoading = false;
          }, 10);
          let data = response.list;
          let toUsersList = [];
          if(response['toUserList'] && self.checkProperty(response, 'toUserList', 'length')>0){
            toUsersList = response['toUserList'];
          }
          let temp_list = [];
          _.forEach(data, (obj) => {
            obj["is_expend"] = false;
            obj["all_comments"] = [];
            obj["newComment"] = { ticketId: "", statusId: "", description: "", documents: [], today: moment().format("YYYY-MM-DD"),  };
            if(_.has(obj, 'toUserIds') &&  self.checkProperty(obj,'toUserIds', 'length')>0 && toUsersList && self.checkProperty(toUsersList, 'length')>0){
              obj['toUserList'] = [];
              _.forEach(obj['toUserIds'],(itd)=>{
                let findOb = _.find(toUsersList,{'_id':itd});
                if(findOb){
                  obj['toUserList'].push(findOb)
                }
              })
            }else{
              if(!_.has(obj, 'toUserList')){
                obj['toUserList'] = [];
              }
              
            }
            temp_list.push(obj);
          });
          this.tickets = temp_list;
          this.totalpages = Math.ceil(response.totalCount / this.perpage);
          setTimeout(() => {
            this.updateLoading(false);
          }, 10);
        })
        .catch((err) => {
          this.callFromRefresh =false;
          this.tickets = [];
          this.isListLoading = false;

          //alert(err);

          setTimeout(() => {
            this.updateLoading(false);
          }, 10);
        });
    },
    sortMe(sort_key = "") {
      if (sort_key != "") {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
        localStorage.setItem("tickets_sort_key", sort_key);
        localStorage.setItem("tickets_sort_value", this.sortKey[sort_key]);

        this.sortKey = {
          path: sort_key,
          order: parseInt(this.sortKeys[sort_key]),
        };
        this.getNotes();
      }
    },
    changeperPage() {
      this.page = 1;
      localStorage.setItem("petitions_perpage", this.perpage);
      this.getNotes();
    },
    getPeritioners() {

     
           
     //petitioner_list_for_tenant_users

       let item ={
          page:1,
          perpage: 10000,
          category: "petitioner_list_for_tenant_users",
          matcher:{
            "searchString":this.peritioners_search_value,
          
          },
          "sorting": {
            "path": "name",
            "order": 1
            }
                      
        };
        if([51].indexOf(this.getUserRoleId)>-1){
          item['category'] = "petitioner_list_for_beneficaries"
        }

  
        this.$store.dispatch("getMasterData", item).then(response => {
         
          this.petitionerList =response.list
        
        });
    },
  
  

  
  

  },

  mounted() {   
    this.getLabelsList();
    this. getVisaTypes();
    this.getNotes();
    this.getPeritioners();
    this.showTaggedDetails();
  },

    props: {
      tickets:{
        type: Array,
         default:new Array()
    },
    widgetData:null,
    list:{
    type: Array,
    default:new Array(),
    },
    lableData:{
    type: Array,
    default:new Array(),
    },
    userRolelist:{
    type: Array,
    default:new Array(),
    },
    templateClass:{
        type:String,
        default:'box'
    },  
    all_statusids: {
    type: Array,
    default:new Array(),
    },

    itemTemplate:{
        type: Array,
    default:new Array(),

    },

    
    }
}
</script>