<template>
<div> 
    <template v-if="[1 ,2].indexOf(getUserRoleId)<=-1">
  <div class="db-page" id="rowListListPage" >
    <div class="db-header">
      <div class="db-greeting">
        <h4>Hi, {{checkProperty(getUserData ,"name")}}!</h4>
        <p>	Overdue {{ OverdueCaseCount }} Cases | {{OverdueTaskCount}} Tasks     -     Due Today {{dueTodayCaseCount}} Cases | {{dueTodayTaskCount}} Tasks     - 
           <router-link :to="'/deadlines'">All Deadlines</router-link>
   </p>
      </div>
      <div class="db-actions">
      
         <a class="edit_widget" @click="$store.commit('togleDashBoardRow')">
          <template v-if="checkIsEditRow"><img src="@/assets/images/main/unlock.svg" alt="duplicate-img" height="20"></template>
          <template v-else><img src="@/assets/images/main/lock.svg" alt="duplicate-img" height="20"></template>
          Edit Layout</a>
        <a class="add_widget cursor" @click="selectedRowId=''; openAddwidget(true) ;rowExistingColumns=[]">Add Widget</a>
      </div>
    </div>
    
   <template v-if="!showPageLoading">
    <draggable :list="layOutRowList" @end="setRowColumns(row)"  >
      <transition-group
        tag="div"                
        type="transition"
        name="flip-list"
        class="rowList"
      > 
      <template>
        <template v-for="(row ,index ) in layOutRowList" >
        <div  v-if="checkProperty(row ,'showMe') !=false" :key="index"  class="db-widget-row" v-bind:class="{'edit-enable':checkIsEditRow,'action-pop-opened':checkProperty( row,'addRowClass')==true}" :id="'row_'+row['_id']" :order="row['order']">
            <!-- :class="{[row.columnLayout]:true}"  columns-->
            
            <draggable :list="row.columns"  @end="setRowColumns(row)" >
              <transition-group 
                type="transition"
                name="flip-list"
                class="db_columns_wrap"                
                :class="{
                  'singlegrid':row.columnLayout=='singlegrid',
                  'doubelgrid1':row.columnLayout=='doubelgrid1',
                  'doubelgrid2':row.columnLayout=='doubelgrid2',
                  'doubelgrid3':row.columnLayout=='doubelgrid3',

                  'triplegrid1':row.columnLayout=='triplegrid1',
                  'triplegrid2':row.columnLayout=='triplegrid2',
                  'triplegrid3':row.columnLayout=='triplegrid3',
                  'triplegrid4':row.columnLayout=='triplegrid4',
                 

                 'small' : row.height == 'small',
                 'medium' : row.height == 'medium',
                 'large' : row.height == 'large'
                  }"
              >


            <template v-for="(column ,conIndx ) in row.columns" >
              {{ widgetExpended }}
                <div  :key="conIndx" class="db-widget-column"  :class="{'widget-expended':widgetExpended==column['_id']}"  :id="'column_'+row['_id']+'_'+column['_id']"  v-if="checkProperty(column ,'widgets' ,'length')>0" >

               <template v-for="(widget ,widgetIndx ) in column.widgets" >
                <div  :key="widgetIndx"   v-if="checkProperty(widget,'showMe')">
             <!--
                {{row.emptyColumns}}
                addNewWidget =={{ row['addNewWidget']}}  availableColumnSlots=== {{ row['availableColumnSlots']}}
              -->
                <!--<emptyWidget  @deleteColumn="deleteColumn"   @duplicateColumn="duplicateColumn" @openAddFilterDialog="openAddFilterDialog"   :rowId="row['_id']"  :columnId="column['_id']" :rowExistingColumnsLength="row['columns'].length"  :availableEmptyColumns="row['emptyColumns'].length" :widgetData="widget"></emptyWidget>-->
                <!---<emptyWidget  @deleteColumn="deleteColumn"   @duplicateColumn="duplicateColumn" @openAddFilterDialog="openAddFilterDialog"   :rowId="row['_id']"  :columnId="column['_id']" :rowExistingColumnsLength="row['columns'].length"  :availableEmptyColumns="row['emptyColumns'].length":widgetData="widget"></emptyWidget>-->
                <!-- <widget1  @deleteColumn="deleteColumn"  @duplicateColumn="duplicateColumn" @openAddFilterDialog="openAddFilterDialog"    :rowId="row['_id']"  :columnId="column['_id']" :rowExistingColumnsLength="row['columns'].length"  :availableEmptyColumns="row['emptyColumns'].length":widgetData="widget"></widget1>-->
                <!---- <widget2  @deleteColumn="deleteColumn"   @duplicateColumn="duplicateColumn" @openAddFilterDialog="openAddFilterDialog"     :rowId="row['_id']" :columnId="column['_id']" :rowExistingColumnsLength="row['columns'].length"  :availableEmptyColumns="row['emptyColumns'].length" :widgetData="widget"></widget2>-->
                <!-- <widget3  @deleteColumn="deleteColumn"   @duplicateColumn="duplicateColumn" @openAddFilterDialog="openAddFilterDialog"    :rowId="row['_id']" :columnId="column['_id']" :rowExistingColumnsLength="row['columns'].length"  :availableEmptyColumns="row['emptyColumns'].length" :widgetData="widget"></widget3>-->
                              
                  <deadlines @togleExpend="togleExpend" :listForDashboard="listForDashboard" :tabName="tabName" @changeTab="changeTab" @deleteColumn="deleteColumn" @duplicateColumn="duplicateColumn" @openAddFilterDialog="openAddFilterDialog" :rowId="row['_id']" :columnId="column['_id']" :rowExistingColumnsLength="row['columns'].length"  :availableEmptyColumns="row['emptyColumns'].length" v-if="['DEADLINE'].indexOf(checkProperty(widget ,'code'))>-1" :widgetData="widget"></deadlines>
                  <widget1
                  @toggleCalssToRow="toggleCalssToRow"
                   :ref="'widget'+row['_id']+'_'+column['_id']"
                   @openAcceptForm="openAcceptForm"
                   @openApprovepopup="openApprovepopup"
                   @rloadActionWidjet="rloadActionWidjet"
                   @togleExpend="togleExpend"
                   :listForDashboard="listForDashboard" @changeTab="changeTab" 
                    @deleteColumn="deleteColumn" 
                    @duplicateColumn="duplicateColumn"
                     @openAddFilterDialog="openAddFilterDialog"
                       :rowId="row['_id']"
                        :columnId="column['_id']"
                         :rowExistingColumnsLength="row['columns'].length"
                          :availableEmptyColumns="row['emptyColumns'].length" 

                           v-else :widgetData="widget" 
                           ></widget1>
               
               
                </div>
                </template>
                                 
                </div>
                </template>
                <!------Empty Widegets-->
              <template v-if="row['addNewWidget']">
                <div  v-for="(column ,conIndx ) in row.emptyColumns" :key="conIndx" class="db-widget-column"   >
                <emptyWidget    :rowId="row['_id']" :loadedFromEmpty="true" @addNewColumnToRow="addNewColumnToRow"  ></emptyWidget>
                
                </div> 
                </template>
                              
              </transition-group>
            </draggable>    
            <div class="action-btns">
              <ul>
                <li><em><move-icon size="1.5x" class="custom-class"></move-icon></em> 
                </li>
                <li>
                  <em><settings-icon size="1.5x" class="custom-class"></settings-icon></em>
                  <div class="settings-dropdown">
                    <vs-tabs v-model="row.tab">
                      <vs-tab label="one">
                        <div class="con-tab-ejemplo">
                          <div class="column-wrapper column-1-layout">                            
                            <div class="layout layout-1" :class="{'active':row.columnLayout=='singlegrid'}"  @click="setRowColumns(row ,'singlegrid')">
                              <div class="col"></div>
                            </div>
                          </div>
                        </div>
                      </vs-tab>
                    
                      <vs-tab label="two">
                        <div class="con-tab-ejemplo">
                          <div class="column-wrapper column-2-layout">                            
                            <div class="layout layout-1" :class="{'active':row.columnLayout=='doubelgrid1'}" @click="setRowColumns(row ,'doubelgrid1')">
                              <div class="col"></div>
                              <div class="col"></div>
                            </div>
                            <div class="layout layout-2" :class="{'active':row.columnLayout=='doubelgrid2'}"  @click="setRowColumns(row ,'doubelgrid2') ">
                              <div class="col"></div>
                              <div class="col"></div>
                            </div>
                            <div class="layout layout-3"  :class="{'active':row.columnLayout=='doubelgrid3'}"   @click="setRowColumns(row ,'doubelgrid3') ">
                              <div class="col"></div>
                              <div class="col"></div>
                            </div>
                          </div>
                        </div>
                      </vs-tab>
                      <vs-tab label="three" >
                        <div class="con-tab-ejemplo">
                          <div class="column-wrapper column-3-layout">
                            <div class="layout layout-1"  :class="{'active':row.columnLayout=='triplegrid1'}"   @click="setRowColumns(row ,'triplegrid1') " >
                              <div class="col"></div>
                              <div class="col"></div>
                              <div class="col"></div>
                            </div>
                            <div class="layout layout-2"  :class="{'active':row.columnLayout=='triplegrid2'}"  @click="setRowColumns(row ,'triplegrid2') ">
                              <div class="col"></div>
                              <div class="col"></div>
                              <div class="col"></div>
                            </div>
                            <div class="layout layout-3" :class="{'active':row.columnLayout=='triplegrid3'}" @click="setRowColumns(row ,'triplegrid3') ">
                              <div class="col"></div>
                              <div class="col"></div>
                              <div class="col"></div>
                            </div>
                            <div class="layout layout-4"  :class="{'active':row.columnLayout=='triplegrid4'}"  @click="setRowColumns(row ,'triplegrid4') ">
                              <div class="col"></div>
                              <div class="col"></div>
                              <div class="col"></div>
                            </div>
                          </div>
                        </div>
                      </vs-tab> 
                    </vs-tabs>
                     
                     
                  </div>
                </li>
                <li class="has-dropdown">
                  <em><more-horizontal-icon size="1.5x" class="custom-class"></more-horizontal-icon></em>
                  <div class="height-dropdown">
                    <div class="height-section">
                      <span>Height</span>
                      <ul>
                        <li class="cursor"  :class="{'active':row['height']=='small'}" @click="setRowHeighet(row ,'small'); ">1x</li>
                        <li class="cursor" :class="{'active':row['height']=='medium'}" @click="setRowHeighet(row ,'medium');">1.5</li>
                        <li class="cursor"  :class="{'active':row['height']=='large'}" @click="setRowHeighet(row,'large');">2x</li>
                      </ul>
                    </div>
                    <ul class="subdropdown">
                      <li  class="cursor" @click="duplicateRow(row ,true)"><a><figure><img src="@/assets/images/duplication.png" alt="duplicate-img" width="15"></figure>Duplicate</a></li>
                      <li class="cursor" v-if="checkProperty(layOutRowList ,'length')>1" @click="deleteRow(index ,true)"><a class="text-danger"><figure><img src="@/assets/images/delete.png" alt="trash-img" width="15"></figure>Delete </a></li>
                    </ul>
                  </div>
                </li>
               
              </ul>
            </div>
        </div>
      </template>
      </template>
        
      </transition-group>
    </draggable>
   </template>

    <template v-else>
      <div id="loading-bg">
        
        <div class="loading" style="background-image: url('favicon.svg');background-repeat: no-repeat; background-position: 14px 8px;">
          <div class="effect-1 effects"></div>
          <div class="effect-2 effects"></div>
          <div class="effect-3 effects"></div>
          
        </div>
    </div>

  </template>
  </div>
    

   <vs-popup class="holamundo widget_modal "   title="" :active.sync="popupActivo">
      <div class="widget-header">
        <div class="widget-title">
          <h4>Add Widget </h4>
        </div>
        <div class="widget-search">
           <vs-input icon-pack="feather" icon="icon-search" @keyup="searchForwidgetsCodes()" v-model="widgetsSearchText" placeholder="Search..."
            class="is-label-placeholder" />
        </div>
      </div>
      <VuePerfectScrollbar	
            ref="mainSidebarPs"	
            class="scroll-area--main-sidebar"	
            :settings="settings"	
            
          >

          
           
      <div class="widget-list" >
     
    
        <ul v-if="checkProperty(widgetAllCodes ,'length')>0">
        <template v-for="( widget , windex) in widgetAllCodes" >
          <li  v-if="selectedRowId" :key="windex" :class="{'selected':widget.selected}" @click="selectWidject(widget)" >
            <emptyWidget :widgetData="widget"> </emptyWidget>
          </li>
          <li v-else :key="windex" :class="{'selected':widget.selected}" @click="addNewRowAction(widget)" >
            <emptyWidget :widgetData="widget"> </emptyWidget>
          </li>
        </template>
           <!---- <li>
            <emptyWidget></emptyWidget>
          </li>
          <li>
            <emptyWidget></emptyWidget>
          </li>
          <li>
            <emptyWidget></emptyWidget>
          </li>
          <li>
            <emptyWidget></emptyWidget>
          </li>
          <li>
            <emptyWidget></emptyWidget>
          </li>--->
        </ul>
        <template v-else>
         <NoDataFound  ref="NoDataFoundRef"  :loading="false"  heading="No Data"  type="support"  />
        </template>
      </div>
      </VuePerfectScrollbar>
    </vs-popup> 

    <modal
      name="filterModal"
      classes="v-modal-sec filter_modal_sec"
      :min-width="400"
      :min-height="200"
      :scrollable="true"
      :reset="true"
     width="770px"
    :max-width="850"
      height="auto"
    >
     <div class="v-modal filter_modal" >
        <div class="popup-header fromDetailsPage">
          
          <span @click="selectdWidgetData=null;$modal.hide('filterModal')" class="fliter-close-icon" >
            <em class="material-icons">close</em>
          </span>
        </div>

        <div class="filter-header" style="text-transform: capitalize !important">
        <!----<a href="#"><img src="@/assets/images/left-arrow.png" width="12" alt="left-arrow"></a>
        -->
        <div class="filter-title">
          <h4> 
            <template v-if="checkIsEditRow">
           <template v-if=" checkProperty(selectdWidgetData ,'widgetData' ,'title' )">{{checkProperty(selectdWidgetData ,'widgetData' ,'title' ) | capitalizeCode}}</template> Settings 
          </template>
           <template v-else>Filters</template>
          
          </h4>
        </div>
      </div>

      <div class="filter-content" v-if="false">
        <form>
        <div class="form-container">
        <div class="input-filters">
          <div class="vx-row">
            <div class="vx-col w-1/2">
              <div class="w-full">

                    <label for="" class="form_label">Label</label>
                    <div class="vs-con-input">
                      <input type="text" class="filter-input">
                    </div>
              </div>
            </div>
            <div class="vx-col w-1/2">
              <div class="w-full">
                    <label for="" class="form_label">Label</label>
                    <div class="vs-con-input">
                      <input type="text" class="filter-input">
                    </div>
              </div>
            </div>
          </div>
          <div class="vx-row">
            <div class="vx-col w-1/2">
              <div class="w-full">
                    <label for="" class="form_label">Label</label>
                    <multiselect v-model="value" :options="options"></multiselect>
              </div>
            </div>
            <div class="vx-col w-1/2">
              <div class="w-full">
                    <label for="" class="form_label">Label</label>
                    <div>
                      <ul class="custom-radio">
                        <li>
                          <vs-radio v-model="primary">Primary</vs-radio>
                        </li>
                        <li>
                          <vs-radio v-model="primary">Primary</vs-radio>
                        </li>
                      </ul>
                    </div>
              </div>
            </div>
          </div>
        </div>
        <div class="input-actions">
          <p>Show tasks that are in multiple Lists more than once</p>
          <div class="switch">                  
            <vs-switch>
              <span slot="on"></span>
              <span slot="off"></span>
            </vs-switch>
          </div>
        </div>
        <div class="input-actions">
          <p>Include subtasks</p>
          <div class="switch">                  
            <vs-switch>
              <span slot="on"></span>
              <span slot="off"></span>
            </vs-switch>
          </div>
        </div>
        <div class="input-actions add-btn-section">
          <a href="#" class="add-widget-btn">Add Widget</a>
        </div>
        </div>
        </form>
      </div>
      
      <widgetFilter   :tabName="tabName" v-if="selectdWidgetData" :widgetData="selectdWidgetData"  @updatedFilter="updatedFilter"  />

      </div>
      </modal>

       <vs-popup class="holamundo main-popup"  title="Delete Row" :active.sync="approveConformRowDelete">
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full">
          <p>Are you sure of delete this Row?</p>
            
          </div>
          
        </div>

         
       
      </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel" type="filled" @click="approveConformRowDelete=false;selectedForRowDelete=-1">Cancel </vs-button>
        <vs-button color="success" class="save" type="filled" @click="deleteRow(selectedForRowDelete ,false)">Delete</vs-button>
      </div>
      </vs-popup>

       <vs-popup class="holamundo main-popup"  title="Duplicate Row" :active.sync="approveConformDuplicateRow">
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full">
          <p>Are you sure of Duplicate this?</p>
            
          </div>
          
        </div>

         
       
      </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel"  :disabled="editLayOutConfig" type="filled" @click="editLayOutConfig=false;approveConformDuplicateRow=false;seletedRowForDuplicate=null">Cancel </vs-button>
        <vs-button color="success" :disabled="editLayOutConfig" class="save" type="filled" @click="duplicateRow(seletedRowForDuplicate ,false)">Duplicate</vs-button>
      </div>
      </vs-popup>



       <vs-popup class="holamundo main-popup"  title="Duplicate" :active.sync="duplicateColumnConform">
        <div class="form-container">
          
          <div class="vx-row">
            <div class="vx-col w-full">
            <p>Are you sure of Duplicate this ?</p>
              
            </div>
            
          </div>

          
        
        </div>
        <div class="popup-footer">
          <vs-button color="dark" class="cancel" type="filled" @click="duplicateColumnConform=false;">Cancel </vs-button>
          <vs-button  color="success" class="save" type="filled" :disabled="editLayOutConfig" @click="duplicateColumnAction()">Delete</vs-button>
        </div>
       </vs-popup>

         <vs-popup class="holamundo main-popup"  title="Delete Column" :active.sync="deleteColumnConform">
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full">
          <p>Are you sure of delete this ?</p>
            
          </div>
          
        </div>

         
       
      </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel" type="filled" @click="deleteColumnConform=false;">Cancel </vs-button>
        <vs-button color="success" class="save" type="filled" :disabled="editLayOutConfig" @click="deleteColumnAction()">Delete</vs-button>
      </div>
    </vs-popup>

    </template>
    <template v-else>
        <dashBoard />
    </template>




    <!----------------------Task Actions -->

     <vs-popup class="holamundo main-popup" :title="'Reject Task'" :active.sync="openTaskRejectPopUp">
        <form @submit.prevent data-vv-scope="acceptingForm">
        <div class="form-container">
            
        <div class="vx-row"  @click="error=''">

          
          <div class="vx-col w-full">
        <div class="form_group">
          <label class="form_label">Write a Comment</label>
          <!-- <vs-textarea
            data-vv-as="Comment"
            v-validate="'required'"
            v-model="payloadAccept.comment"
            name="comments"
          
            class="w-full"
          /> -->
          <ckeditor data-vv-as="Comment"
            v-validate="'required'"
            v-model="payloadAccept.comment"
            name="comments"
          
            class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>


          <span
            class="text-danger text-sm"
            v-show="errors.has('acceptingForm.comments')"
          >Comments are required</span>
        </div>
        </div>


          
        </div>
        <div v-show="error">
          <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
            icon="IP-information-button" active="true">{{ error }}</vs-alert>
        </div>

        
  
        </div>
        </form>
        <div class="popup-footer relative" >

        <span class="loader" v-if="taskAccepting" ><img src="@/assets/images/main/loader.gif"></span>
          
          <vs-button color="dark" :disabled="taskAccepting" @click="openTaskRejectPopUp =false" class="cancel" type="filled">Cancel</vs-button>
          <vs-button  color="success" :disabled="taskAccepting"  @click="acceptTaskAction('TASK_REJECT')" class="save" type="filled">Reject </vs-button>

        <!----
          <vs-button  color="success" :disabled="taskAccepting "  @click="acceptTaskAction('TASK_ACCEPT')" class="save" type="filled">Accept </vs-button>
          -->
        </div>
    </vs-popup>

     <!---Prtitioner Approve---->
     
      <vs-popup class="holamundo main-popup" :title="popupbtnTxt+' Company'" :active.sync="approveConformpopUp">
      <div class="form-container" @click="formErrors=''">
        
        <div class="vx-row">
          <div class="vx-col w-full">
          <p>{{actionText}}</p>
            
          </div>
          
        </div>
          <div class="text-danger text-sm formerrors" v-if="formErrors!=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formErrors }}</vs-alert>
          </div>
       
      </div>
      <div class="popup-footer">
       <span class="loader" v-if="loading"><img src="@/assets/images/main/loader.gif"></span>
        <vs-button color="dark" class="cancel" type="filled" @click="approveConformpopUp=false">Cancel</vs-button>
        <vs-button color="success" :disabled="loading" class="save" type="filled" @click="changetPetitionerstatus()">{{popupbtnTxt}}</vs-button>
      </div>
    </vs-popup>


   
</div>
</template>
 
 
<script>

  import NoDataFound from "@/views/common/noData.vue";
 import Multiselect from "vue-multiselect-inv";
import emptyWidget from "@/views/dashboard/emptyWidget.vue";
import widget1 from "@/views/dashboard/widget1.vue";
//import widget2 from "@/views/dashboard/widget2.vue";
//import widget3 from "@/views/dashboard/widget3.vue";
import deadlines from "@/views/dashboard/deadlines.vue";
import draggable from "vuedraggable";
import { MoreHorizontalIcon } from 'vue-feather-icons' 
import { SettingsIcon } from 'vue-feather-icons'
import { MoveIcon } from 'vue-feather-icons'
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import { _ } from 'core-js'
import JQuery from "jquery";
import widgetFilter from "./widgetFilter.vue";
import dashboardNoData from "./dashboardNoData.vue";
import dashBoard from '@/views/DashboardLatest.vue'
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import moment from "moment";
export default {
 
  components: {
    NoDataFound,
    widgetFilter,
    Multiselect,
    emptyWidget,
    widget1,
    //widget2,
  //  widget3,
    deadlines,
    draggable,
    MoreHorizontalIcon,
    SettingsIcon,
    MoveIcon,
    VuePerfectScrollbar,
    dashboardNoData,
    dashBoard
  },
  data: function () {
    return {
      OverdueCaseCount: 0,
      OverdueTaskCount: 0,
      dueTodayCaseCount: 0,
      dueTodayTaskCount: 0,
      deadlineStats: null,
      widgetExpended:'',
      editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
      listForDashboard:null,
      duplicateColumnConform:false,
       deleteColumnConform:false,
       deletedColumnData:null,
      allWidjectsFilters:[],
      tabName:'TODO',
     selectdWidgetData:null,
    
      rowExistingColumns:[],
      selectedWidgets:null,
      selectedRowId:'',
      selectedColumnId:'',
      primary:false,
      value:null,
      options:[],
      widgetsSearchText:'',
      widgetAllCodes:[],
      tempWidgetAllCodes:[],
      maxColumnsInRow:3,
       wedgetHights:{
       
        "1X":'small',
        "1.5":"medium",
        "2X":"large"
       
      },
      widgetsConfigDetaiis:null,
      searchtxt:'',
      layOutRowList:[],
      editLayOutConfig:false,
      editWidgetConfig:false,
      rowData:[],
       newWedgetData:[],
      popupActivo:false,
      sectionsList: [],
      sortModel: [],
      emptyColumnData:{
        
			"rowId": "",
			"columnId": "",
			"title": "Tasks",
			"code": "TASK",
			"filters": {
				"statusIds": [],
				"createdDateRange": []
			},
			"sorting": {
				"path": "createdOn",
				"order": -1
			},
			"perpage": 5
		

      },
      
      sections: {
        section1: {
          title: "section1",
          order: 1,
        },
        section2: {
          title: "section2",
          order: 2,
        },
        // section3: {
        //   title: "section3",
        //   order: 3,
        // },
      },
      settings: { 
        swipeEasing: true,
      },
      widgets: [
        // {
        //   section: "section1",
        // },
        {   
          section: "section1",
        },
        {
          section: "section1",
        },
        {
          section: "section2",
        },
        {
          section: "section2",
        },
        // {
        //   section: "section3",
        // },
      ],
      selectedForRowDelete:-1,
      approveConformRowDelete:false,
      approveConformDuplicateRow:false,
      seletedRowForDuplicate:null,
      showPageLoading:true,

      /*ACTION DATA*/
      taskAccepting:false,

      openTaskRejectPopUp:false,
      payloadAccept: {
        "taskId": "",
        "action": "TASK_ACCEPT" ,//'TASK_REJECT',
        "comment": ""
      },
     error:'',
     actionColumnId:null,
     actionRowId:null,
     actionCode:null,


     //Approve Pet
     approveConformpopUp:false,
     petitioner:null,
      actionText:'',
      popupbtnTxt:'',
      selectedStatus:null,
      loading:false,
      formErrors:'',
      
      /*ACTION DATA*/
       
    };
  },
  
  computed: {
    
    sectionWidgets() {
      return Object.keys(this.sections).reduce((acc, sectionId) => {
        acc[sectionId] = this.getWidgetsBySection(sectionId).map(
          (widget) => widget.title
        );
        return acc;
      }, {});
    },
},

 methods: {
  toggleCalssToRow(data){
    let self =this;
  const $ = JQuery;
      $("[id^='row_']").each( (i, el)=> {
        
        let roId = el.id.substr(4);
       
        $('#'+el.id).removeClass('action-pop-opened');
        if(roId == data['rowId']){

          if( this.checkProperty(data  ,'addClass') ==true){
            $('#row_'+roId).addClass('action-pop-opened');
          }

        }

      });

      //:id="'column_'+row['_id']+'_'+column['_id']"
      $("[id^='column_']").each( (i, el)=> {

        $('#'+el.id).removeClass('has-popup');
          if(self.checkProperty(data,"rowId") && self.checkProperty(data,"columnId")){
            
            if( self.checkProperty(data  ,'addClass') ==true && 'column_'+data['rowId']+'_'+data['columnId'] == el.id ){
              $('#'+el.id).addClass('has-popup');
            }

          }

      })

     
    
     
      
    
       

      },
  togleExpend(data){
    const $ = JQuery;
    
    $('body').removeClass('widget-expended')
    if(_.has( data ,'columnId') && this.widgetExpended !=data['columnId'] ){
      this.widgetExpended =data['columnId'];
      $('body').addClass('widget-expended')
    }else{
      this.widgetExpended ='';
    }
    
    
  },
  rloadActionWidjet(code){
   
    this.actionCode =code;
    this.updateWidgetData();
  },
updateWidgetData(){
   
     if((this.actionColumnId && this.actionRowId) || this.actionCode ){
      try{

      // let refs = 'widget'+this.actionRowId+'_'+this.actionColumnId;
      //  this.$refs['widget'+this.actionRowId+'_'+this.actionColumnId].getWigetsData();
        //row.columns
       //column.widgets
      
        _.forEach(this.layOutRowList , (row)=>{

          if(row['_id'] ==this.actionRowId || this.actionCode ){
            if(this.checkProperty(row , 'columns' ,'length')>0){
              _.forEach(row['columns'] , (column)=>{
                if((column['_id'] == this.actionColumnId || this.actionCode) && this.checkProperty(column , 'widgets' ,'length')>0 ){
                   _.forEach(column.widgets , (widget)=>{
                      if(this.actionColumnId == this.checkProperty(widget , 'columnId') || this.checkProperty(widget , 'code')==this.actionCode ){
                        widget['showMe'] =false;
                        setTimeout(()=>{
                          widget['showMe'] =true;
                        })

                      }

                   })

                }

              })

            }

          }

        });
        this.actionCode =null;
        this.actionColumnId =null;
        this.actionRowId =null;
       
      
      }catch(e){
        
       this.actionCode =null;
       this.actionColumnId =null;
        this.actionRowId =null;
      }

     }
   
},
  scrollDownRows(){
 
   setTimeout(()=>{
       const $ = JQuery;
       let id = "rowList"
       const element = $(`#${id}`);
        element.animate({
        scrollTop: element.prop("scrollHeight")
        }, 10);
      
      

      
      
     
    })
    

  },
  reloadRow(rowId){
   
   _.forEach(this.layOutRowList ,(row)=>{
     if(row['_id'] == rowId){
       row['showMe'] = false;
       row['showMe'] = false;
       setTimeout(()=>{
        row['showMe'] = true;
       })
       
     }

   })

  },
  changeTab(tab){
    this.tabName=tab;
   
    
  },
  addNewRowAction(item){

    this.selectedWidgets =null ; //[]
    let existingRowIds =[];
      _.forEach(this.widgetAllCodes ,(wedj)=>{

        wedj['selected'] =false;
        if(item['_id'] ==wedj['_id']){
            wedj['selected'] =true;
            wedj['selected'] =true;
            this.selectedWidgets = _.cloneDeep(wedj);
        }

      });
      let rowOrders ={};
      let newRowData = {
				
				"noOfColumns": 3,
				"columnLayout": "triplegrid1",
				"heightInPx": 600,
				"height": "medium",
				"order": 1,
				"columns": [
          {
             "order": 0
          },
          {
            "order": 1
          },
          {
            "order": 1
          }
				]
			

      };


     $("[id^='row_']").each( (i, el)=> { let _id = el.id.substr(4);  rowOrders[_id] = i+1;  });
     this.rowData =[];

     _.forEach(this.layOutRowList ,(row)=>{
          existingRowIds.push(row['_id']);
      
        let columnOrders ={};
        if(this.checkProperty(rowOrders ,row['_id'])){
          if(rowOrders[row['_id']] >0){

            row['order'] =  rowOrders[row['_id']]; 
            
          }
         
       
      
          $("[id^='column_"+row['_id']+"']").each( (i, el)=> {
        //   alert(el.id.substr(4))
              let ids =  el.id.substr(7);
              let idsArrays = ids.split('_');
            
              if(this.checkProperty(idsArrays ,'length')>1){
                let _id =idsArrays[1];
                columnOrders[_id] = i+1;

              }
          
          });
        }
         if(row['order']>newRowData['order']){
            newRowData['order'] = row['order']+1;
          }
        let rowItem = {
          "_id": "",
            "noOfColumns": 2,
            "columnLayout": "doubelgrid1",
            "heightInPx": 600,
            "height": "2X",
            "order": 1,
            "columns":[]

        }

       let noOfColumns =1;
      if(['doubelgrid1','doubelgrid2' ,'doubelgrid3'].indexOf(row.columnLayout)>-1){
        noOfColumns =2;
      }
    
      if(['triplegrid1','triplegrid2' ,'triplegrid3' ,'triplegrid4'].indexOf(row.columnLayout)>-1){
        noOfColumns =3;
      }
      row['noOfColumns'] = noOfColumns;
      rowItem['noOfColumns'] = noOfColumns;
      let isValuesExists =0;
      _.forEach(rowItem ,( val,key)=>{
        if(this.checkProperty(row ,key)){
          if(key =="noOfColumns"){
            row[key] = noOfColumns;
            isValuesExists =isValuesExists+1

          }else if(key=='columns'){
            let lastColumnOrderId =3
            if(this.checkProperty(row ,'columns' ,'length')>0){
              _.forEach(row['columns'] ,(column)=>{
                isValuesExists =isValuesExists+1
                let columnData ={
                  "_id":'',
                  "order":0
                };

                columnData['_id'] = this.checkProperty(column ,'_id');
                columnData['order'] = this.checkProperty(column ,'order');
                if( this.checkProperty(columnOrders ,column['_id']) >-1 ){
                  columnData['order'] = columnOrders[column['_id']];
                }
                rowItem[key].push(columnData)

              });

            }
            if(row['_id'] == this.selectedRowId){

              rowItem[key].push( {"order":3})

            }

          }else{
              rowItem[key] = row[key];
              isValuesExists =isValuesExists+1

          }

          

          
          

        }

      });
        if(isValuesExists>1){
            this.rowData.push(rowItem);
        }
        

      })
 
      
     
      this.editLayOutConfig =true;
      let path ="/dashboard/update-layout-config";
        let postData ={
          "config":[]
       }
      this.rowData.push(newRowData);
       postData['config'] = this.rowData;
       this.$store.dispatch("commonAction" ,{data:postData,'path':path})
      .then((rx) =>{
        if(this.checkProperty(rx ,"config" ,'length' )>0 ){

           let newlyAddRow = _.find(rx['config'] , (rItem)=>{
              return existingRowIds.indexOf(rItem['_id'])<=-1

            })
            
           
            if(newlyAddRow && _.has(newlyAddRow , '_id') && this.checkProperty(newlyAddRow ,'columns' ,'length')>0){
             let columnId = newlyAddRow['columns'][0]['_id'];
            this.selectedRowId = newlyAddRow['_id'];
            

             let newWidgetItem=     {
                    "rowId": "",
                    "columnId": "",
                    "name":"",
                    "title": "Case Stats by Status",
                    "code": "",
                    "filters": {
                    
                    },
                    "sorting": {
                         "path": "createdOn",
                        "order": -1
                    },
                    "perpage": 5
                    }
                   
                    newWidgetItem['rowId'] =  this.selectedRowId;
                    newWidgetItem['columnId'] =  columnId
                    newWidgetItem['title'] = this.checkProperty( this.selectedWidgets,'name');
                    newWidgetItem['name'] = this.checkProperty( this.selectedWidgets,'name');
                    newWidgetItem['code'] = this.checkProperty( this.selectedWidgets ,'code');
                   if(this.checkProperty( this.selectedWidgets ,'filters')){
                       newWidgetItem['filters'] = this.checkProperty( this.selectedWidgets ,'filters');
                       if(this.checkProperty( this.selectedWidgets ,'code') =="MESSAGES"){
                        //alert("ld dskhsdf")

                        let ueserData = this.getUserData;
                        if(ueserData && _.has( ueserData ,'userId')){
                          let userId = ueserData['userId'];
                          if(this.checkProperty(newWidgetItem['filters'] ,"assignedToIds")){
                            if(this.checkProperty(newWidgetItem['filters'] ,"assignedToIds" ,"length")<=0){
                              newWidgetItem['filters']['assignedToIds'] =[];
                              newWidgetItem['filters']['assignedToIds'].push(userId);
                            }
                            

                          }else{
                            newWidgetItem['filters']['assignedToIds'] =[];
                            newWidgetItem['filters']['assignedToIds'].push(userId);
                            

                          }



                        }

                       }
                    }
                    if(this.checkProperty( this.selectedWidgets ,'pagination')){
                       newWidgetItem['pagination'] = this.checkProperty( this.selectedWidgets ,'pagination');
                    }

                      if(this.checkProperty( this.selectedWidgets ,'tabSorting')){
                       newWidgetItem['tabSorting'] = this.checkProperty( this.selectedWidgets ,'tabSorting');
                    }

                     if(this.checkProperty( this.selectedWidgets ,'sorting')){
                       newWidgetItem['sorting'] = this.checkProperty( this.selectedWidgets ,'sorting');
                    }
                     if(this.checkProperty( this.selectedWidgets ,'sortingList')){
                       newWidgetItem['sortingList'] = this.checkProperty( this.selectedWidgets ,'sortingList');
                    }
                    if(this.checkProperty( this.selectedWidgets ,'sortingOrder')){
                      newWidgetItem['sortingOrder'] = this.checkProperty( this.selectedWidgets ,'sortingOrder');
                    }
                    this.newWedgetData =[];
                   
                    this.newWedgetData.push(newWidgetItem); 
                    
                    this.saveUpdateWidget();

                    this.scrollDownRows();
                    
                  
              


            }else{

            }


        }else{

        }

      }).catch((err) =>{

          this.rowData = [];
          this.editLayOutConfig =false;
         this.showToster({message:err,isError:true }); 

      })

  },
  
  
  addNewColumnToRowAction() { 
      this.selectedColumnId = '';
      //save column in existing  row
      if(this.selectedRowId !=''){

       
    let rowOrders ={};
     $("[id^='row_']").each( (i, el)=> { let _id = el.id.substr(4);  rowOrders[_id] = i+1;  });
     this.rowData =[];
     _.forEach(this.layOutRowList ,(row)=>{

      
        let columnOrders ={};
        if(this.checkProperty(rowOrders ,row['_id'])){
          if(rowOrders[row['_id']] >0){

            row['order'] =  rowOrders[row['_id']]; 
            
          }

      

        
      
          $("[id^='column_"+row['_id']+"']").each( (i, el)=> {
        //   alert(el.id.substr(4))
              let ids =  el.id.substr(7);
              let idsArrays = ids.split('_');
            
              if(this.checkProperty(idsArrays ,'length')>1){
                let _id =idsArrays[1];
                columnOrders[_id] = i+1;

              }
          
          });
        }
        let rowItem = {
          "_id": "",
            "noOfColumns": 2,
            "columnLayout": "doubelgrid1",
            "heightInPx": 600,
            "height": "2X",
            "order": 1,
            "columns":[]

        }

       let noOfColumns =1;
      if(['doubelgrid1','doubelgrid2' ,'doubelgrid3'].indexOf(row.columnLayout)>-1){
        noOfColumns =2;
      }
    
      if(['triplegrid1','triplegrid2' ,'triplegrid3' ,'triplegrid4'].indexOf(row.columnLayout)>-1){
        noOfColumns =3;
      }
      row['noOfColumns'] = noOfColumns;
      rowItem['noOfColumns'] = noOfColumns;
      let isValuesExists =0;
      _.forEach(rowItem ,( val,key)=>{
        if(this.checkProperty(row ,key)){
          if(key =="noOfColumns"){
            row[key] = noOfColumns;
            isValuesExists =isValuesExists+1

          }else if(key=='columns'){
            let lastColumnOrderId =3
            if(this.checkProperty(row ,'columns' ,'length')>0){
              _.forEach(row['columns'] ,(column)=>{
                isValuesExists =isValuesExists+1
                let columnData ={
                  "_id":'',
                  "order":0
                };

                columnData['_id'] = this.checkProperty(column ,'_id');
                columnData['order'] = this.checkProperty(column ,'order');
                if( this.checkProperty(columnOrders ,column['_id']) >-1 ){
                  columnData['order'] = columnOrders[column['_id']];
                }
                rowItem[key].push(columnData)

              });

            }
            if(row['_id'] == this.selectedRowId){

              rowItem[key].push( {"order":3})

            }

          }else{
              rowItem[key] = row[key];
              isValuesExists =isValuesExists+1

          }

          

          
          

        }

      });
        if(isValuesExists>1){
            this.rowData.push(rowItem);
        }
        

      })
 
      this.editLayOutConfig =true;
      let path ="/dashboard/update-layout-config";
        let postData ={
          "config":[]
       }
       postData['config'] = this.rowData;
       this.$store.dispatch("commonAction" ,{data:postData,'path':path})
      .then((rx) =>{

       // alert(JSON.stringify(rx));
        //rowExistingColumns
      
       // this.showToster({message:rx.message,isError:false }); 
        
         this.rowData = [];
         this.editWidgetConfig =false;
         this.newWedgetData =[];
        
         
         if(this.checkProperty(rx ,"config" ,'length' )>0 && this.checkProperty(this.selectedWidgets,"_id")){

          let selectedRow = _.find(rx['config'] ,{ "_id":this.selectedRowId  });
          if(selectedRow && this.checkProperty(selectedRow ,"columns" ,'length' )>0){

            let newlyAddColumn = _.find(selectedRow['columns'] , (coulm)=>{
              return this.rowExistingColumns.indexOf(coulm['_id'])<=-1

            })
           
            if(newlyAddColumn && this.checkProperty(newlyAddColumn ,"_id")){

                 let newWidgetItem=     {
                    "rowId": "",
                    "columnId": "",
                    "name":"",
                    "title": "Case Stats by Status",
                    "code": "",
                    "filters": {
                    
                    },
                    "sorting": {
                         "path": "createdOn",
                        "order": -1
                    },
                    "perpage": 5
                    }
                    newWidgetItem['rowId'] =  this.selectedRowId;
                    newWidgetItem['columnId'] =  newlyAddColumn['_id']
                    newWidgetItem['title'] = this.checkProperty( this.selectedWidgets,'name');
                    newWidgetItem['name'] = this.checkProperty( this.selectedWidgets,'name');
                    newWidgetItem['code'] = this.checkProperty( this.selectedWidgets ,'code');

                    if(this.checkProperty( this.selectedWidgets ,'filters')){
                       newWidgetItem['filters'] = this.checkProperty( this.selectedWidgets ,'filters');
                    }
                    if(this.checkProperty( this.selectedWidgets ,'pagination')){
                       newWidgetItem['pagination'] = this.checkProperty( this.selectedWidgets ,'pagination');
                    }
                     if(this.checkProperty( this.selectedWidgets ,'sorting')){
                       newWidgetItem['sorting'] = this.checkProperty( this.selectedWidgets ,'sorting');
                    }
                     if(this.checkProperty( this.selectedWidgets ,'sortingList')){
                       newWidgetItem['sortingList'] = this.checkProperty( this.selectedWidgets ,'sortingList');
                    }
                    if(this.checkProperty( this.selectedWidgets ,'sortingOrder')){
                      newWidgetItem['sortingOrder'] = this.checkProperty( this.selectedWidgets ,'sortingOrder');
                    }
                    
                    
                   
                    this.newWedgetData =[];
                   
                    this.newWedgetData.push(newWidgetItem); 
                    this.saveUpdateWidget();

            }else{
              this.getLayoutConfigList()
            }
           

          }else{
            this.getLayoutConfigList()

          }
          
           


         }else{
          this.getLayoutConfigList()
          
         }
        
       
         // 
        

      })
      .catch((err) =>{
          this.rowData = [];
          this.editLayOutConfig =false;
         this.showToster({message:err,isError:true }); 
       
       })
  
  
      }

  },

  selectWidject(item){
    // if( item['selected']){
    //    item['selected'] = false;
    // }else{
    //    item['selected']= true;

    // }
     this.selectedWidgets =null ; //[]
    _.forEach(this.widgetAllCodes ,(wedj)=>{

      wedj['selected'] =false;
      if(item['_id'] ==wedj['_id']){
          wedj['selected'] =true;
          item['selected'] =true;
          this.selectedWidgets = _.cloneDeep(item);
      }

    });

    //widgetAllCodes
   // let selectedWidgets = _.filter(this.widgetAllCodes ,{"selected":true});
   // this.selectedWidgets = _.cloneDeep(selectedWidgets);
   
    if(!this.editLayOutConfig){
      this.addNewColumnToRowAction();
    }

  }, 

  openAddwidget(action=false) {
    let list = _.cloneDeep(this.tempWidgetAllCodes );
    let tempList =[];
     _.forEach(list ,(item)=>{
              item  =Object.assign(item ,{ "selected": false})
              tempList.push(item);
          })
          this.widgetAllCodes = tempList;
          this.tempWidgetAllCodes = _.cloneDeep(this.widgetAllCodes );
          this.popupActivo=action; 
          this.selectedWidgets = [];
          this.editLayOutConfig =false;
  },
  getWidegetsCodesData(){
     let query =  {
          category: "dashboard_widget", //user_status
           page:1,
           perpage: 1000,
        };

        this.$store.dispatch("getMasterData", query).then(response => {
      
          let tempList =[];
          _.forEach(response.list ,(item)=>{
            let codeItem = _.find(this.allWidjectsFilters ,{"code": item['code']});
            if(codeItem && this.checkProperty(codeItem ,'filters' )&& Object.keys(codeItem['filters']).length>0){
              item['filters'] =codeItem['filters']
            }
              item  =Object.assign(item ,{ "selected": false})
              tempList.push(item);
          })
          this.widgetAllCodes = tempList;
          this.tempWidgetAllCodes = _.cloneDeep(this.widgetAllCodes );
         
        
         
        });

  },
  searchForwidgetsCodes(){
     this.widgetAllCodes = _.cloneDeep(this.tempWidgetAllCodes );
     this.widgetsSearchText = this.widgetsSearchText.trim();
     if(this.widgetsSearchText !=''){



       this.widgetAllCodes = _.filter(this.widgetAllCodes , (item)=>{
        let str = _.clone(this.widgetsSearchText);
       str = str.toLowerCase()
       return item['name'].toLowerCase().includes(str) || item['description'].toLowerCase().includes(str) || item['code'].toLowerCase().includes(str)
       })

     }
     if(this.checkProperty(this.widgetAllCodes ,'length')<=0){
      setTimeout(()=>{
              this.updateLoading(false); 
             
          } ,10);
  }
    

  },
  duplicateRow(row ,showConform=false) {

//seletedRowForDuplicate

    if(!this.editLayOutConfig){
      if(showConform){
        this.seletedRowForDuplicate = _.cloneDeep(row);
        this.approveConformDuplicateRow =true;
      }else{
         this.selectedRowId =this.seletedRowForDuplicate['_id'];
         this.duplicateRowAction();

      }
     

    }
    

  },
  duplicateRowAction(){
     let postData ={
      rowId:''
     };

     let path = "/dashboard/duplicate-row";
      postData['rowId'] = this.selectedRowId;
      this.editLayOutConfig =true;
       this.$store.dispatch("commonAction" ,{data:postData,'path':path})
      .then((rx) =>{
         // alert(JSON.stringify(rx))



          if(this.checkProperty(rx ,'row' ,"columns") && this.checkProperty(rx ,'widgets' ,"length")>0 ){
            let tempRow = _.cloneDeep(rx['row']);
            tempRow  =Object.assign(tempRow, {'widgets':rx['widgets']});

          _.forEach([tempRow] ,(row)=>{
            if(this.checkProperty(row ,"columns" ,"length") > 0 && (this.checkProperty(row  ,"widgets" ,"length")>0)){
              _.forEach(row['columns'] ,(column)=>{

                let columnWidgets =_.filter(row['widgets'] ,{"columnId":column['_id']});

                column['widgets'] =columnWidgets.map((item)=>{
                  item.showMe =true;
                  return item;
                });
                 column['showMe'] =true;
                if( this.checkProperty(columnWidgets ,"length")<=0){
                    column['showMe'] =false;
                }
               
                

              })
              let rowSupportColumns =1
              if((['doubelgrid1','doubelgrid2' ,'doubelgrid3'].indexOf(row.columnLayout)>-1 )){
                rowSupportColumns =2
              }else if(['triplegrid1','triplegrid2' ,'triplegrid3' ,'triplegrid4'].indexOf(row.columnLayout)>-1 ){
                rowSupportColumns =3;
              }


              row['addNewWidget'] =false;
              row['availableColumnSlots'] = rowSupportColumns -row['widgets'].length;
              row['emptyColumns'] =[];
              if( row['availableColumnSlots']>0){
                for(let i=0;i<row['availableColumnSlots'];i++){
                  row['emptyColumns'].push(this.emptyColumnData)
                }
                row['addNewWidget'] =true;
                 
                 


              }
              

            }

           if(this.checkProperty( row  ,"widgets" ,"length")>0 ){
            
            let tab =0;
            let noOfColumns =1
            if(['doubelgrid1','doubelgrid2' ,'doubelgrid3'].indexOf(row.columnLayout)>-1){
              tab =1;
              noOfColumns =2;
            }
           
            if(['triplegrid1','triplegrid2' ,'triplegrid3' ,'triplegrid4'].indexOf(row.columnLayout)>-1){
              tab =2;
              noOfColumns =3;
            }
 
 
           
              row['columns'] =   _.orderBy(row['columns'], ['order'], ['asc']);
              row = Object.assign(row ,{"tab":tab ,"noOfColumns":noOfColumns});
              this.layOutRowList.push(row)

            }


          });

            
          }
         this.editLayOutConfig =false;
         this.approveConformDuplicateRow =false;
         this.seletedRowForDuplicate =null;
        
          this.showToster({message:rx.message,isError:false }); 
          this.selectedRowId = '';
         

      })
      .catch((err) =>{
        
          this.editLayOutConfig =false;
         this.showToster({message:err,isError:true }); 
         this.selectedRowId = '';
       
       })

  },

  deleteRow(index =-1 ,showConformBox =false){


   
    if(index>-1){
      if(!showConformBox){
        this.layOutRowList.splice(index ,1);
        this.editLayOutConfig =true;

       this.setRowColumns(null ,'' , true ,true);
        this.selectedForRowDelete =-1;
        this.approveConformRowDelete =false;

      }else{
        this.selectedForRowDelete =index;
        this.approveConformRowDelete =true;


      }
      

    }

  },

  setRowColumns(row ,cls='' ,reload=false ,callfromDeleteRow=false){
  const $ = JQuery;
  this.selectedRowId = this.checkProperty(row ,'_id');
   
  if(cls!='' && row){
    row['addNewWidget'] = false;
   row['emptyColumns'] =[];
     row.columnLayout =cls;
     let existingColumns = this.checkProperty(row ,'widgets','length');
    
     let emptyAvailableColumns =0;
     if(existingColumns >0 && existingColumns<3){

        let rowSupportColumns =1
        if((['doubelgrid1','doubelgrid2' ,'doubelgrid3'].indexOf(row.columnLayout)>-1 )){
          rowSupportColumns =2
        }else if(['triplegrid1','triplegrid2' ,'triplegrid3' ,'triplegrid4'].indexOf(row.columnLayout)>-1 ){
          rowSupportColumns =3;
        }
         emptyAvailableColumns =rowSupportColumns-existingColumns;
        
        
          for(let i=0;i<emptyAvailableColumns;i++){
                  row['emptyColumns'].push(this.emptyColumnData);
          }
           row['addNewWidget'] = true;
       

         
     }
   
    
    //alert(emptyAvailableColumns);

  }
  this.editLayOutConfig =false;
  this.rowData =[];
  
   
  
  

  setTimeout(()=>{
    let rowOrders ={};
     $("[id^='row_']").each( (i, el)=> {
  //   alert(el.id.substr(4))
       let _id = el.id.substr(4);
       rowOrders[_id] = i+1;
    
     });
     this.rowData =[];
     _.forEach(this.layOutRowList ,(row)=>{
      
       let columnOrders ={};
      if(this.checkProperty(rowOrders ,row['_id'])){
        if(rowOrders[row['_id']] >0){

          row['order'] =  rowOrders[row['_id']]; 
          
        }

     

      
    
        $("[id^='column_"+row['_id']+"']").each( (i, el)=> {
      //   alert(el.id.substr(4))
            let ids =  el.id.substr(7);
            let idsArrays = ids.split('_');
          
            if(this.checkProperty(idsArrays ,'length')>1){
              let _id =idsArrays[1];
              columnOrders[_id] = i+1;

            }
        
        });
      }
      let rowItem = {
         "_id": "",
          "noOfColumns": 2,
          "columnLayout": "doubelgrid1",
          "heightInPx": 600,
          "height": "2X",
          "order": 1,
          "columns":[]

      }

    let noOfColumns =1;
      if(['doubelgrid1','doubelgrid2' ,'doubelgrid3'].indexOf(row.columnLayout)>-1){
        noOfColumns =2;
      }
    
      if(['triplegrid1','triplegrid2' ,'triplegrid3' ,'triplegrid4'].indexOf(row.columnLayout)>-1){
        noOfColumns =3;
      }
      row['noOfColumns'] = noOfColumns;
      rowItem['noOfColumns'] = noOfColumns;
      let isValuesExists =0;
      _.forEach(rowItem ,( val,key)=>{
        if(this.checkProperty(row ,key)){
          if(key =="noOfColumns"){
            row[key] = noOfColumns;
            isValuesExists =isValuesExists+1

          }else if(key=='columns'){
            if(this.checkProperty(row ,'columns' ,'length')>0){
              _.forEach(row['columns'] ,(column)=>{
                isValuesExists =isValuesExists+1
                let columnData ={
                  "_id":'',
                  "order":0
                };

                columnData['_id'] = this.checkProperty(column ,'_id');
                columnData['order'] = this.checkProperty(column ,'order');
                if( this.checkProperty(columnOrders ,column['_id']) >-1 ){
                  columnData['order'] = columnOrders[column['_id']];
                }

                rowItem[key].push(columnData)

              });

            }

          }else{
              rowItem[key] = row[key];
              isValuesExists =isValuesExists+1

          }

          

          
          

        }

      });
      if(isValuesExists>1){
          this.rowData.push(rowItem);
      }

      })
 
   this.editLayOutConfig =true;
  
   this.saveUpdateLayOut(reload ,callfromDeleteRow);

  } ,100)
 
  },

 saveUpdateLayOut(reloadList=false ,callfromDeleteRow=false){

    let path = "/dashboard/save-layout-config";
    if(this.editLayOutConfig){
      path ="/dashboard/update-layout-config";
    }
   
    if(this.checkProperty(this.rowData ,'length')>0){
       let postData ={
          "config":[]
       }
       postData['config'] = this.rowData;
       this.$store.dispatch("commonAction" ,{data:postData,'path':path})
      .then((rx) =>{
       
        this.selectedRowId ='';
        this.duplicateColumnConform =false;
        this.deleteColumnConform =false;
        this.editLayOutConfig =false;
        this.rowData = [];
        
         if(callfromDeleteRow){

            this.mountFunction();
          }else{
           
            if(reloadList){
            
              this.showToster({message:rx.message,isError:false }); 
              this.getLayoutConfigList()
            }else if(this.selectedRowId !=''){
              let rowId =_.cloneDeep(this.selectedRowId);
              this.reloadRow(rowId);

            }
            
            

          }

      })
      .catch((err) =>{
          this.rowData = [];
          this.editLayOutConfig =false;
          
         this.showToster({message:err,isError:true }); 
       
       })

    }
   

  },

//Columns Functionality
addNewColumnToRow(rowId=''){
  
  this.selectedRowId =rowId;
  this.rowExistingColumns =[];
  if(rowId){
    let selectedRow = _.find(this.layOutRowList , {"_id":rowId});
    if(this.checkProperty(selectedRow , "columns" ,'length') >0){
      this.rowExistingColumns = selectedRow['columns'].map((item)=>{ return item['_id'];  });
    }
    this.openAddwidget(true);

  }
  
 
},


deleteColumn(data){
  this.deletedColumnData = data;
  this.deleteColumnConform =true;
  
},



deleteColumnAction(){
  if(this.checkProperty(this.deletedColumnData ,'rowId')  && this.checkProperty(this.deletedColumnData ,'columnId')){
    const $ = JQuery;
    this.editLayOutConfig =false;
    this.rowData =[];
   let data = _.cloneDeep(this.deletedColumnData);
   
  
  

  setTimeout(()=>{
    let rowOrders ={};
     $("[id^='row_']").each( (i, el)=> { let _id = el.id.substr(4);  rowOrders[_id] = i+1; });
     this.rowData =[];
     _.forEach(this.layOutRowList ,(row)=>{
      
       let columnOrders ={};
      if(this.checkProperty(rowOrders ,row['_id'])){
          if(rowOrders[row['_id']] >0){

            row['order'] =  rowOrders[row['_id']]; 
            
          }

          $("[id^='column_"+row['_id']+"']").each( (i, el)=> {
          //   alert(el.id.substr(4))
                let ids =  el.id.substr(7);
                let idsArrays = ids.split('_');
              
                if(this.checkProperty(idsArrays ,'length')>1){
                  let _id =idsArrays[1];
                  columnOrders[_id] = i+1;

                }
            
            });
        }
      let rowItem = {
         "_id": "",
          "noOfColumns": 2,
          "columnLayout": "doubelgrid1",
          "heightInPx": 600,
          "height": "2X",
          "order": 1,
          "columns":[]

      }

    let noOfColumns =1;
      if(['doubelgrid1','doubelgrid2' ,'doubelgrid3'].indexOf(row.columnLayout)>-1){
        noOfColumns =2;
      }
    
      if(['triplegrid1','triplegrid2' ,'triplegrid3' ,'triplegrid4'].indexOf(row.columnLayout)>-1){
        noOfColumns =3;
      }
      row['noOfColumns'] = noOfColumns;
      rowItem['noOfColumns'] = noOfColumns;
      let isValuesExists =0;
      _.forEach(rowItem ,( val,key)=>{
        if(this.checkProperty(row ,key)){
          if(key =="noOfColumns"){
            row[key] = noOfColumns;
            isValuesExists =isValuesExists+1

          }else if(key=='columns'){
            if(this.checkProperty(row ,'columns' ,'length')>0){
              _.forEach(row['columns'] ,(column)=>{
                if(data['columnId'] !=  column['_id'] ){

                
                isValuesExists =isValuesExists+1
                let columnData ={
                  "_id":'',
                  "order":0
                };

                columnData['_id'] = this.checkProperty(column ,'_id');
                columnData['order'] = this.checkProperty(column ,'order');
                if( this.checkProperty(columnOrders ,column['_id']) >-1 ){
                  columnData['order'] = columnOrders[column['_id']];
                }
                rowItem[key].push(columnData)
              }

              });

            }

          }else{
              rowItem[key] = row[key];
              isValuesExists =isValuesExists+1

          }

          

          
          

        }

      });
      if(isValuesExists>1){
          this.rowData.push(rowItem);
      }

      })
 
   this.editLayOutConfig =true;
  this.saveUpdateLayOut(true);
  //this.deleteColumnConform =false

  } ,100)
  }

},
openAddFilterDialog(data){
  this.selectdWidgetData =null;
 this.selectdWidgetData =_.cloneDeep(data);

if(this.checkProperty(data ,'selecetedTab')){
     this.tabName = this.checkProperty(data ,'selecetedTab');
}
 
 if(this.checkProperty(data['widgetData'] ,'code') =="DEADLINE" && ["TASK", "CASES"].indexOf(this.tabName) <=-1){
    this.tabName = "CASES";
 }

  this.$modal.show('filterModal');
},
updatedFilter(updateWidgetData){
  
   _.forEach(this.layOutRowList ,(row)=>{
//row.columns
    if(row['_id'] ==this.checkProperty(updateWidgetData ,"rowId") && this.checkProperty(row ,"columns" ,'length')>0  ){

 _.forEach(row.columns,(column)=>{
      _.forEach(column['widgets'],(widget)=>{
        if(widget['_id'] == this.checkProperty(updateWidgetData ,"widgetId")){
       
          _.forEach(updateWidgetData ,(val ,key)=>{
           // if(_.has(widget ,key)){
              widget[key] = val;
         //   }

          });
          widget['showMe']=false;
          setTimeout(()=>{
              widget['showMe']=true;
          })
        
        }

      })
    })


    }

   });

   this.$modal.hide('filterModal');
   this.selectdWidgetData =null;
  


},

duplicateColumn(data){
  if(this.checkProperty(data ,"rowId" ) && this.checkProperty(data ,"columnId" ) && !this.editLayOutConfig ){
    this.selectedRowId =data['rowId'],
    this.selectedColumnId =data['columnId'];
    this.duplicateColumnConform=true;
   
    //this.duplicateColumnAction();

  }else{
    // alert(JSON.stringify(data)+" duplicate Column");
  }

   

  //update selected row with new column , and get columnid then save widget
  //
 // 
},

duplicateColumnAction(){
  let path = "/dashboard/duplicate-column";
  let postData = {
      "rowId": "",
      "columnId": ""

  };
  postData['rowId'] = this.selectedRowId;
   postData['columnId'] = this.selectedColumnId;
  this.editLayOutConfig =true;
  this.$store.dispatch("commonAction" ,{data:postData,'path':path})
      .then((rx) =>{
      if(this.checkProperty( rx ,'column' ,'_id') && this.checkProperty( rx ,'widgets' ,'length')>0 ){
        let nweWidgets = rx['widgets'];
        let newColumn = rx['column'];
        

       

        _.forEach(this.layOutRowList ,(row)=>{

            if(row['_id'] ==postData['rowId'] && this.checkProperty(nweWidgets  ,'length' ) >0 ){
             
              
              row['columns'].push(newColumn);
              row['widgets'].push(nweWidgets[0]);

              _.forEach(row['columns'] ,(column)=>{

                let columnWidgets =_.filter(row['widgets'] ,{"columnId":column['_id']});

                column['widgets'] =columnWidgets.map((item)=>{
                  item.showMe =true;
                  return item;
                });
                 column['showMe'] =true;
                if( this.checkProperty(columnWidgets ,"length")<=0){
                    column['showMe'] =false;
                }
               
                

              })
              let rowSupportColumns =1
              if((['doubelgrid1','doubelgrid2' ,'doubelgrid3'].indexOf(row.columnLayout)>-1 )){
                rowSupportColumns =2
              }else if(['triplegrid1','triplegrid2' ,'triplegrid3' ,'triplegrid4'].indexOf(row.columnLayout)>-1 ){
                rowSupportColumns =3;
              }


              row['addNewWidget'] =false;
              row['availableColumnSlots'] = rowSupportColumns -row['widgets'].length;
              row['emptyColumns'] =[];
              if( row['availableColumnSlots']>0){
                for(let i=0;i<row['availableColumnSlots'];i++){
                  row['emptyColumns'].push(this.emptyColumnData)
                }
                row['addNewWidget'] =true;
                 
                 


              }
              

            }

           if(this.checkProperty( row  ,"widgets" ,"length")>0 ){
            
            let tab =0;
            let noOfColumns =1
            if(['doubelgrid1','doubelgrid2' ,'doubelgrid3'].indexOf(row.columnLayout)>-1){
              tab =1;
              noOfColumns =2;
            }
           
            if(['triplegrid1','triplegrid2' ,'triplegrid3' ,'triplegrid4'].indexOf(row.columnLayout)>-1){
              tab =2;
              noOfColumns =3;
            }
 
 
           
              row['columns'] =   _.orderBy(row['columns'], ['order'], ['asc']);
              row['tab'] =tab
              row['noOfColumns'] =noOfColumns
             

            }


          });         
        


      }

        
          this.editLayOutConfig =false;
          this.duplicateColumnConform=false
          this.selectedRowId = '';
          this.selectedColumnId = '';
          this.showToster({message:rx.message,isError:false }); 
         })
     .catch((err) =>{
      
      this.showToster({message:err,isError:true }); 
      this.selectedRowId ='';
      this.selectedColumnId ='';
       this.editLayOutConfig =false;

     })    

},
  


  setRowHeighet(row ,height='small'){
    if(_.has(row ,'height')){
      row.height = height;
      this.setRowColumns(row); 

    }
          
   
  },


   saveUpdateWidget(){

    let path = "/dashboard/save-widget-config";
    if(this.editWidgetConfig){
      path ="/dashboard/update-widget-config";
    }
    let postData ={
      items:[]
    }
     postData['items'] = _.cloneDeep(this.newWedgetData);
    this.$store.dispatch("commonAction" ,{data:postData,'path':path})
      .then((rx) =>{
      
        this.showToster({message:rx.message,isError:false });
        this.editWidgetConfig = false;
        this.editLayOutConfig =false;
        this.selectedWidgets =[];
        this.rowExistingColumns =[];
        this.selectedRowId ='';
        this.openAddwidget(false);
        this.getLayoutConfigList()

      })
      .catch((err) =>{
         this.showToster({message:err,isError:true }); 
          this.editWidgetConfig = false;
          this.editLayOutConfig =false;
           this.openAddwidget(false);
       
       })

  },

changedColumnOrder(rowId=''){
 
  let columnOrders ={};
   if(rowId !=''){
    $("[id^='column_"+rowId+"']").each( (i, el)=> {
  //   alert(el.id.substr(4))
        let ids =  el.id.substr(7);
        let idsArrays = ids.split('_');
       
        if(this.checkProperty(idsArrays ,'length')>1){
          let _id =idsArrays[1];
          columnOrders[_id] = i+1;

        }
    
     });
    // alert(JSON.stringify(columnOrders));

   }
   
   
},
 
 

  getWidgetConfig(){

    this.widgetsConfigDetaiis =null;
    let path ="/dashboard/get-widget-config";

    this.$store.dispatch("commonAction" ,{data:{},'path':path})
      .then((rx) =>{
      
        this.showToster({message:rx.message,isError:false }); 

      })
      .catch((err) =>{
         this.showToster({message:err,isError:true }); 
       
       })

  },
  psSectionScroll(event){


  },
 
  getLayoutConfigList(showPageLoading=false){
    let path = "dashboard/get-layout-config";
     this.showPageLoading =false;
    if(showPageLoading){
      this.showPageLoading =true;
     // this.$vs.loading.close();
    }
    this.$store.dispatch("commonAction" ,{data:{},'path':path})
      .then((rx) =>{
      
        
        if(this.checkProperty(rx  ,"config" ,"length")>0){
          this.layOutRowList = [];
          _.forEach(rx['config'] ,(row)=>{
            row['showMe'] = true;
            if(this.checkProperty(row ,"columns" ,"length") > 0 && (this.checkProperty(row  ,"widgets" ,"length")>0)){
              _.forEach(row['columns'] ,(column)=>{

                let columnWidgets =_.filter(row['widgets'] ,{"columnId":column['_id']});

                column['widgets'] =columnWidgets.map((item)=>{
                  item.expend =false;
                  item.showMe =true;
                  item.tabName ="";
                  if(['ACTION' ,'DEADLINE' ,'UPDATES'].indexOf(this.checkProperty(item ,"code")) >-1){
                    if(['ACTION','UPDATES' ].indexOf(this.checkProperty(item ,"code")) >-1){
                     item.tabName ="TODO";
                    }
                    if(['DEADLINE' ].indexOf(this.checkProperty(item ,"code"))>-1 ){
                      item.tabName ="CASES";
                    }
                  }

                
                  return item;
                });
                 column['showMe'] =true;
                if( this.checkProperty(columnWidgets ,"length")<=0){
                    column['showMe'] =false;
                }
               
                

              })
              let rowSupportColumns =1
              if((['doubelgrid1','doubelgrid2' ,'doubelgrid3'].indexOf(row.columnLayout)>-1 )){
                rowSupportColumns =2
              }else if(['triplegrid1','triplegrid2' ,'triplegrid3' ,'triplegrid4'].indexOf(row.columnLayout)>-1 ){
                rowSupportColumns =3;
              }


              row['addNewWidget'] =false;
              row['availableColumnSlots'] = rowSupportColumns -row['widgets'].length;
              row['emptyColumns'] =[];
              if( row['availableColumnSlots']>0){
                for(let i=0;i<row['availableColumnSlots'];i++){
                  row['emptyColumns'].push(this.emptyColumnData)
                }
                row['addNewWidget'] =true;
                 
                 


              }
              

            }

           if(this.checkProperty( row  ,"widgets" ,"length")>0 ){
            
            let tab =0;
            let noOfColumns =1
            if(['doubelgrid1','doubelgrid2' ,'doubelgrid3'].indexOf(row.columnLayout)>-1){
              tab =1;
              noOfColumns =2;
            }
           
            if(['triplegrid1','triplegrid2' ,'triplegrid3' ,'triplegrid4'].indexOf(row.columnLayout)>-1){
              tab =2;
              noOfColumns =3;
            }
 
 
           
              row['columns'] =   _.orderBy(row['columns'], ['order'], ['asc']);
              row = Object.assign(row ,{"tab":tab ,"noOfColumns":noOfColumns});
              this.layOutRowList.push(row)

            }


          });
        }
         this.showPageLoading =false;
      //   this.$vs.loading.close();

      })
      .catch((err) =>{
        this.showPageLoading =false;
         this.$vs.loading.close();

       })
  },
    getWidgetsBySection(sectionId) {
      return this.widgets.filter((widget) => widget.section === sectionId);
    },
     getwidgetFilters(){
        //getWidgetFilterMasterData
        this.sortingList =[];
        let postData ={
          code:'GET_ALL'
        }
        
         postData['code'] =  'GET_ALL';
        this.$store.dispatch('getWidgetFilterMasterData' ,postData)
        .then((rx)=>{
           this.allWidjectsFilters =rx
                    

        })
        

      },
		
/*ACTION METHODS*/


/**
 * @param action | Boolean
 * @param actionType | String
 * @param item | Object
 * @param actionColumnId | String
 * @param actionRowId | String
 * @param actionCode  | String
 
 */
openAcceptForm({action =false ,actionType=''  ,item=null ,actionColumnId=null,actionRowId=null,actionCode=null}){
     
     this.actionColumnId = actionColumnId;
      this.actionRowId =actionRowId;
      this.actionCode =actionCode,
      

     
      
    this.error =  '';
    this.payloadAccept= {
      "taskId": "",
      "action": "TASK_ACCEPT" ,//'TASK_REJECT',
      "comment": ""
    }
    this.taskAccepting =false;
    if(item){
      this.item =item;
      
    }
   
    if(action   ){
      if(actionType =='TASK_ACCEPT'){
         this.acceptTaskAction('TASK_ACCEPT')
      }else{
        if(actionType =='TASK_REJECT'){
          this.openTaskRejectPopUp =true;
          //this.$modal.show('taskAcceptModal');
        }
      }
     
     
    }else{
       this.openTaskRejectPopUp =false;
    //  this.$modal.hide('taskAcceptModal');
      
    }
    this.$validator.reset();

  },

acceptTaskAction(actionType=''){
     this.$validator.validateAll('acceptingForm').then((result)=>{
    
        if(result || actionType=='TASK_ACCEPT'){
           let seletedTask = _.cloneDeep(this.item);
         
            this.error = '';
            this.taskAccepting =true;
              this.payloadAccept['taskId'] =this.checkProperty(seletedTask , 'data' ,'taskId');
              if(actionType){
                this.payloadAccept['action'] = actionType
              } 
              let payLoad = _.cloneDeep(this.payloadAccept);
              this.$store.dispatch("commonAction", {"data": payLoad ,"path":"/tasks/manage"})
                .then((response) => {   
                
                 
                   this.updateWidgetData();
                    this.showToster({message:response.message,isError:false }); 
                    this.taskAccepting =false; 
                    this.openTaskRejectPopUp =false;
                                    
                })
                .catch((error) => {
                  this.error =error
                    this.taskAccepting =false;  
                })
         }
         
         })


  },


  
  /**
 * @param status | Int
 * @param txt | String
 * @param item | Object
 * @param actionColumnId | String
 * @param actionRowId | String
 * @param actionCode  | String
 */
    openApprovepopup( {status =2 ,txt=''  ,item=null ,actionColumnId=null,actionRowId=null,actionCode=null}){

       this.actionColumnId = actionColumnId;
      this.actionRowId =actionRowId;
      this.actionCode =actionCode,
       this.item =item;


        this.actionText = "Do you want to "+txt+" ?",
        
        this.popupbtnTxt = txt;
        this.selectedStatus = status;
        this.approveConformpopUp =false;
        this.loading =true;
        this.formErrors = '';
          let companyId = this.checkProperty(this.item ,"data", "companyId")
            this.$vs.loading();
            this.$store.dispatch("petitioner/getpetetioner", {
                    companyId: companyId
                }).then(response => {
                  this.approveConformpopUp =true;
                  this.loading =false;
                   this.$vs.loading.close();   
                    this.petitioner = response;
                    this.petitioner['petitionerId'] = response['userId'];
                   
                }).catch((err)=>{
                  this.loading =false;
                 this.$vs.loading.close();   
                });

      }, 
       getpetetioner(  action =false) {
            let companyId = this.checkProperty(this.item ,"data", "companyId")
            this.$vs.loading();
            this.$store
                .dispatch("petitioner/getpetetioner", {
                    companyId: companyId
                })
                .then(response => {
                                  
                   this.$vs.loading.close();   
                    this.petitioner = response;
                    this.petitioner['petitionerId'] = response['userId'];
                   
                }).catch((err)=>{
                 
                 this.$vs.loading.close();   
                });
   
      },
      changetPetitionerstatus( ){
        let post_data = {"companyId":this.petitioner['_id'], "statusId":this.selectedStatus };
        let sts = _.find(this.all_statusids ,{"id":this.selectedStatus});
        if(sts && _.has(sts,"name")){
          post_data['statusName'] = sts['name']

        }
        //alert(JSON.stringify(post_data));

        //post_data = Object.assign(post_data,{"petitionerId":this.selectedpetitioner['_id'] ,"statusId":this.selectedStatus})
         this.loading = true;
         this.formErrors ='';
          this.$store.dispatch("commonAction", {data:post_data ,"path":"/company/update-status"}).then((res) => {
              this.approveConformpopUp =false;
              this.loading =false;
              this.showToster({message:res.message,isError:false });
              this.reloadWallList();
               

            }).catch((error) => {
                this.loading =false;
                this.formErrors = error;
                this.showToster({message:error,isError:true });
               

            });

      },
/*ACTION METHODS END*/
    mountFunction(){
      //alert()
      this.showPageLoading =true;
     this.$store.dispatch("commonAction" ,{data:{} ,path:"/masterdata/list-for-dashboard"}).then((res)=>{
      
       this.listForDashboard =res;
        this.getwidgetFilters();
        this.getWidegetsCodesData();
        this.getLayoutConfigList(true)
     }).catch((rx)=>{

        this.getwidgetFilters();
        this.getWidegetsCodesData();
        this.getLayoutConfigList(true);

     })
    }

  },
  created() {
    this.sortModel = Object.keys(this.sections).map((sectionId) => {
      return {
        sectionId:sectionId,
        selectedGrid :'singlegrid',
        widgets: this.getWidgetsBySection(sectionId),
      };
    });
  },
  mounted() {
    
     this.mountFunction();
     let path ="dashboard/get-widget-data";
     let postData ={
          categoryList:['DEADLINE_STATS'],
          filters: {
          typeIds: [],
          subTypeIds: [],
          petitionerIds: [],
          companyIds: [],
          branchIds: [],
          types: [],
          entityTypeList: [],
          createdDateRange: [],
          getMissingDeadlines: true,
          deadlineDateRange: [],
          dueDateRange: [],
          premiumProcessing: [],
          premiumProcess: false
          },
          perpage: 500,
          sorting: {
          path: "createdOn",
          order: -1
          },
          today: ""
        }
  
        let toDay = moment().format('YYYY-MM-DD');
           const weekStart = moment().startOf('week');
          let nextWeek  = moment().add(1,'week').format('YYYY-MM-DD');
          let yesterDay = moment().subtract(1, 'day').format('YYYY-MM-DD');
          postData['filters']['deadlineDateRange'] =[yesterDay ,nextWeek];
          postData['today'] = toDay;
          
          this.$store.dispatch("commonAction", { data: postData, path: path })
          .then((response) => {
           
            this.deadlineStats = response.DEADLINE_STATS
            if(this.checkProperty(this.deadlineStats, 'cases') && this.checkProperty(this.deadlineStats, 'tasks')){

              this.OverdueCaseCount= this.deadlineStats.cases.missed 
              this.OverdueTaskCount =this.deadlineStats.tasks.missed
              this.dueTodayCaseCount =this.deadlineStats.cases.today
              this.dueTodayTaskCount = this.deadlineStats.tasks.today
            }
          }).catch((err) =>{})
  }
};
  

</script>

<style>

.inner-transition-group {
  min-height: 100px;
    display: flex;
    width: 100%;
    align-items: center;
    margin: 0 auto;
}
 
.flip-list-move {
  transition: transform 0.5s;
}
 
 
.wrappers .wrappers-ul {
  border: 0px solid gray;
  padding: 1rem;
  cursor: pointer;
    background: #fff;
    position: relative;
}
.wrappers {
  display: grid;
  gap: 3rem;
  grid-template-columns: repeat(1, 3fr);
}
 
 
</style>