<template>


     <div class="graph_cnt">
     
   
      <div>
        <div
          v-show="statusCount > 0 && !loading "
          :id="chartDiv"
          style="height: 250px"
        ></div>
        <ul class="chart_legends" v-show="statusCount > 0 && !loading ">
          <template v-for="(cData, ind) in list">
            <li @click="gotoList(checkProperty(cData ,'category'))"  :class="replaceSpaces(cData.category)" :key="ind">
              <p><span
                
              
                v-bind:class="{
                        'chart-lesthan-week': checkProperty(cData ,'category') == '<1 Week',
                        'chart-week': checkProperty(cData ,'category') == '1 Week',
                        'chart-three-week': checkProperty(cData ,'category') == '3+ Weeks',
                       
                       
                      }"
              
              ></span>{{ cData.category }}</p>
            </li>
          </template>
        </ul>

        
      </div>
       <chartLoading v-if="loading" />
       <noList  v-if="!loading && statusCount <=0" ref="NoDataFoundRef"  :loading="loading"  heading="No Data"  type="support"  />
    </div>
                 

</template>
<script>

import DateRangePicker from "vue2-daterange-picker";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import VueApexCharts from "vue-apexcharts";
import Vue from "vue";
import moment from "moment";

import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import chartLoading from "@/views/wall/chartLoading.vue";
import DatePickerCustom from "@/views/common/_date_picker_custom.vue";
am4core.useTheme(am4themes_animated);
import noList from "@/views/common/noList.vue";

import _ from "lodash";
Vue.use(VueApexCharts);

Vue.component("apexchart", VueApexCharts);


    export default {
     components: {
    DateRangePicker,
    chartLoading,
    DatePickerCustom,
    noList,
  },   
     name:'pendingCaseStats',
     props: {
        widgetData:null,
        itemData:null,
        widgetsItems:null,
       
     },
     data:()=>{
        return {
             list:[],
             loading:true,
             statusCount:0,
             chartDiv:'currentStatusCase'

        }
     },
     mounted() {
       const d = new Date();
       let time = d.getTime();
    this.chartDiv ='currentStatusCase_'+time+'';
  let colors =this.getCaseColors();
    setTimeout(()=>{
       if(this.checkProperty(this.widgetsItems ,'data','length')>0){
            _.forEach(this.widgetsItems['data'] ,(item)=>{

                 if(this.checkProperty(this.widgetsItems ,'mData','length')>0 && this.checkProperty(item ,'_id') >0){

                 let roleData = _.find(this.widgetsItems['mData'] ,{"_id":item['_id']});
                
                 if(roleData && this.checkProperty(roleData ,'name')){

                   
                     item = Object.assign(item ,{"category":roleData['name'] });
                     let  statusColor =_.find(colors ,{'id':item['category']});

                    if(statusColor && this.checkProperty(statusColor ,'backgroundColor')){
                        item = Object.assign(item ,{'color':''});
                        item['color'] = statusColor['backgroundColor']
                    }
                    this.statusCount = this.statusCount+item['count'];
                    this.list.push(item);


                 }

                }
            });
            this.loading =false;
            if( this.statusCount >0){
                 this.initChart();
            }else{
                 setTimeout(()=>{
                    this.updateLoading(false); 
                    setTimeout(()=>{ this.loading = false;  this.updateLoading(false);  } ,10)   
                } ,10)
            }
           

        }

    })

       

     },
     methods: {
      gotoList(category){
        let _self = this;
        let matchers ={};
          let createdDateRange =[];
          if(category =='<1 Week'){

            let startDate = moment().subtract(7, 'days').format('YYYY-MM-DD');
            let endDate = moment().format('YYYY-MM-DD');
            createdDateRange =[startDate,endDate]
            matchers = Object.assign(matchers ,{"createdDateRange":createdDateRange});

          }else  if(category =='1 Week'){

            let startDate = moment().subtract(7, 'days').format('YYYY-MM-DD');
            let endDate = moment().format('YYYY-MM-DD');
            createdDateRange =[startDate,endDate]
            matchers = Object.assign(matchers ,{"createdDateRange":createdDateRange});

          }else if('3+ Weeks'){
          let startDate = moment().subtract(21, 'days').format('YYYY-MM-DD');
          let endDate = moment().format('YYYY-MM-DD');
          createdDateRange =[startDate,endDate]
          matchers = Object.assign(matchers ,{"createdDateRange":createdDateRange});


          }

          let path ='/cases';
          if(Object.keys(matchers).length>0){
            let matcherObj = {'matcher':matchers}
            const string = JSON.stringify(matcherObj)
            let encodedString = btoa(string) 
            path =path+"?filter="+encodedString;
          }

          _self.$router.push(path);
          

      },
         initChart() {
          let _self = this;
      var chart = am4core.create(this.chartDiv, am4charts.PieChart3D);
      chart.logo.disabled = true;

      // Add data
      chart.data = this.list;
      /*[{
  "category": "white",
  "count": 501.9,
  "color": "red"
}, {
  "category": "red",
  "count": 301.9,
  "color": "yellow"
}, {
  "category": "orange",
  "count": 201.1,
  "color": "orange"
}, {
  "category": "green",
  "count": 165.8,
  "color": "green"
}, {
  "category": "blue",
  "count": 139.9,
  "color": "blue"
}];
*/
      //chart.contentHeight =320;
      //chart.contentWidth =500;

      //chart.width=200;
      chart.height = 250;
      // Add and configure Series
      var pieSeries = chart.series.push(new am4charts.PieSeries3D());
      pieSeries.dataFields.value = "count";
      pieSeries.dataFields.category = "category";
      pieSeries.innerRadius = am4core.percent(60);
      pieSeries.ticks.template.disabled = true;
      pieSeries.labels.template.disabled = true;

      // This is not working and produces an error
      // pieSeries.slices.template.adapter.add("fill", function (fill, target) {
      //     return target.dataItem.dataContext["color"];
      // });

      // var rgm = new am4core.RadialGradientModifier();
      // rgm.brightnesses.push(-0.8, -0.8, -0.5, 1, 1);
      // pieSeries.slices.template.fillModifier = rgm;
      // pieSeries.slices.template.strokeModifier = rgm;
      pieSeries.slices.template.strokeOpacity = 2;
      pieSeries.slices.template.strokeWidth = 1;
      pieSeries.slices.template.propertyFields.fill = "color";
      pieSeries.slices.template.propertyFields.isActive = "pulled";

      pieSeries.slices.template.cornerRadius = 6;
pieSeries.colors.step = 3;

pieSeries.hiddenState.properties.endAngle = -90;

     
      pieSeries.slices.template.events.on(
        "hit",
        function (ev) {
           _self.gotoList(ev.target.dataItem.category);
          
         
         
        },
        
      );

      pieSeries.slices.template.adapter.add("fill", function(fill, target) {

      
        let dat = _.find( _self.list, {"category":target.dataItem.category} )
        if(dat && _.has(dat ,'color')){
          return dat['color']
        }else{
          return chart.colors.getIndex(target.dataItem.index);
        }


          
        });
    },
     }
    
    
    }
    </script>