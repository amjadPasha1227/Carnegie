<template>

<div class="header">

        <div class="title">
          <!-----{{ checkProperty(widgetData ,'expend') }}-->
          <h4>{{ checkProperty(widgetData ,'title')}} 
            <!-----<span v-if="updatesCount>0"> {{updatesCount}}</span>-->
          </h4>
        </div>
        <VuePerfectScrollbar	 v-if="(['MESSAGES','ACTION' ,'DEADLINE','CLIENT'].indexOf(checkProperty(widgetData,'code' ))>-1) || ([51].indexOf(getUserRoleId)<=-1 && ['UPDATES' ].indexOf(checkProperty(widgetData,'code' ))>-1)" 
        ref="mainSidebarPs"	
        class="scroll-area--main-sidebar"	
        :settings="settings"	
        
      >
      <div class="widget-filters inbox_sent_wrapper" v-if="['MESSAGES'].indexOf(checkProperty(widgetData,'code' ))>-1"   >
        <button type="border" class="filter_btn assigned_btn" :class="{'active':assignedToIds}" @click="loadMsgAssignedMe()">Assigned To Me</button>
       
        <button type="border" class="inbox_btn filter_btn " :class="{'active':widgetData['filters']['msgListType'] == 'inbox'}" @click="assignedToIds=false;widgetData['filters']['assignedToIds']=[];widgetData['filters']['msgListType'] = 'inbox'; $emit('reloadWidgetData')" >Inbox</button>
        <button type="border" class="sent_btn filter_btn" :class="{'active':widgetData['filters']['msgListType'] == 'sent'}"  @click="assignedToIds=false;widgetData['filters']['assignedToIds']=[];widgetData['filters']['msgListType'] = 'sent';$emit('reloadWidgetData')">Sent</button>
      
      </div>

      <div class="widget-filters" v-if="['ACTION' ,'DEADLINE' ].indexOf(checkProperty(widgetData,'code' ))>-1">

        <button class="filter_btn" @click="changeTab('Corporate')"  v-if="['CLIENT'].indexOf(checkProperty(widgetData,'code' ))>-1"  :class="{'active':selecetedTab=='Corporate'}"  ><em>Corporate</em></button>
        <button class="filter_btn" @click="changeTab('Individual')"  v-if="['CLIENT'].indexOf(checkProperty(widgetData,'code' ))>-1"  :class="{'active':selecetedTab=='Individual'}"  ><em>Individual</em></button>
      </div>
        <div class="widget-filters" v-if="['ACTION' ,'DEADLINE' ].indexOf(checkProperty(widgetData,'code' ))>-1">

          <button class="filter_btn" @click="changeTab('Corporate')"  v-if="['CLIENT'].indexOf(checkProperty(widgetData,'code' ))>-1"  :class="{'active':selecetedTab=='Corporate'}"  ><em>Corporate</em></button>
          <button class="filter_btn" @click="changeTab('Individual')"  v-if="['CLIENT'].indexOf(checkProperty(widgetData,'code' ))>-1"  :class="{'active':selecetedTab=='Individual'}"  ><em>Individual</em></button>

          <button class="filter_btn " v-if="['ACTION'].indexOf(checkProperty(widgetData,'code' ))>-1" :class="{'active':selecetedTab=='TODO'}"   @click="changeTab('TODO')" ><em>To-Do</em><span v-if="todoCount>0">{{todoCount}}</span></button>
          <button class="filter_btn" :class="{'active':selecetedTab=='CASES'}"  @click="changeTab('CASES')" ><em>Cases</em><span v-if="caseCount>0"> {{caseCount}}</span></button>
          <button class="filter_btn" :class="{'active':selecetedTab=='TASK'}"   @click="changeTab('TASK')"><em>Tasks</em><span v-if="taskCount>0"> {{taskCount}}</span>  </button>
          <button class="filter_btn" @click="changeTab('UPDATES')"  v-if="['ACTION'].indexOf(checkProperty(widgetData,'code' ))>-1"  :class="{'active':selecetedTab=='UPDATES'}"  ><em>My Updates</em></button>
        </div>
        <div class="widget-filters" v-if="[51].indexOf(getUserRoleId)<=-1 && ['UPDATES' ].indexOf(checkProperty(widgetData,'code' ))>-1">
          <!----internalUserCount:0,
         petitionerCount:0,
         beneficiaryCount:0
        -->
          <button v-if="getTenantTypeId !=2 && [3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1"  class="filter_btn" :class="{'active':selecetedTab=='petitioner'}"   @click="changeTab('petitioner')"><em>Petitioner</em><span v-if="  false&&petitionerCount>0"> {{petitionerCount}}</span>  </button>
          <button v-if="[3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1" class="filter_btn" :class="{'active':selecetedTab=='internal_user'}"  @click="changeTab('internal_user')" ><em>Internal</em><span v-if=" false&& internalUserCount>0"> {{internalUserCount}}</span></button>
          <button v-if="[3,4,5,6,7,8,9,10,11,12,13,14 ,50].indexOf(getUserRoleId)>-1" class="filter_btn" :class="{'active':selecetedTab=='beneficiary'}" @click="changeTab('beneficiary')" ><em>Beneficiaries</em> <span v-if="  false&&petitionerCount>0"> {{beneficiaryCount}}</span></button>
          <button class="filter_btn" :class="{'active':selecetedTab=='all'}" @click="changeTab('all')" ><em>All</em> <span v-if="  false&&petitionerCount>0"> {{beneficiaryCount}}</span></button>
       
        </div>
        </VuePerfectScrollbar>
        <div v-if="['CASE_SIGN_STATS','CASE_STATS_BY_STATUS' ].indexOf(checkProperty(widgetData,'code' ))>-1 " class="subtypes__list petition_stats case_sign_stats" >
          <!----,'CLIENT' 'CURRENT_STATUS_OF_CASE' -->

        <ul>
          <template v-for="(fitem  ,ind) in caseStatsFilterItems">
          <li :title="fitem.name" class="active" @click="changedCaseType(fitem)" :key="ind" v-if="ind<=0 && checkProperty(fitem,'selected' )"><span>{{ fitem.name }}</span></li>
          </template>
          <li v-if="checkProperty(caseStatsFilterItems,'length')>1">
            <div class="menu_dropdown flexible_actions">
              <em class="more_count ">                      
                <template v-if="isSelected">+{{(checkProperty(caseStatsFilterItems ,'length'))-1}}</template>
                <template v-if="!isSelected">{{ checkProperty(caseStatsFilterItems ,'length') }}</template>                    
              </em>
              <div class="menu_list_wrap">
                <ul>
                  <template v-for="(fitem  ,ind) in caseStatsFilterItems">
                      <li @click="changedCaseType(fitem)" :key="ind" v-if="ind>0"><span>{{ fitem.name }}</span></li>
                    </template>             
                </ul>
                
              </div>
            </div>
          </li>
        </ul>
        </div>
        <div class="actions" :code="checkProperty(widgetData,'code' )">
          <ul>
            <li @click="togleExpend()"><figure class="maximize-img"><img src="@/assets/images/maximize.png"  width="18" height="18"/></figure><figure class="minimize-img"><img src="@/assets/images/minimize.png"  width="20" height="20"/></figure></li>
             <li v-if="[ 'INVOICE',  'LCA'].indexOf(checkProperty(widgetData,'code' ))>-1" @click="changeViewType()">
              <!----'CASE_BY_STATUS'-->
              <template  v-if="viewType =='CHART'">
                <figure title="List View"><img src="@/assets/images/list.png" alt="List" width="24" ></figure>
              
              </template>
               <template v-if="viewType =='LIST'">
                <figure title="Chart View"><img src="@/assets/images/chart.png" alt="calendar-img" width="24" ></figure>
               </template>
              
              
             </li>
             <template v-if="checkIsEditRow">
              <li @click="openAddFilterDialog()"><figure><img title="Filters" src="@/assets/images/icons/db_settings.svg" alt="calendar-img" width="18" height="18"></figure></li>
             </template>
             <template v-else>
                <li @click="openAddFilterDialog()"><figure><img title="Filters" src="@/assets/images/funnel.svg" alt="calendar-img" width="14" height="14"></figure></li>
             </template>
            
            <li class="has-dropdown ll" ><figure><more-horizontal-icon size="1.5x" class="custom-class" style="opacity: 0.6;"></more-horizontal-icon></figure>
            <div class="height-dropdown" v-if="checkIsEditRow ">
                 
                <ul class="subdropdown" >
               
                  <li :disabled="duplicating"  v-if="availableEmptyColumns>0" @click="duplicateColumn()"><a><figure><img src="@/assets/images/duplication.png" alt="duplicate-img" width="15"></figure>Duplicate</a></li>
                  <li v-if="checkIsEditRow" @click="deleteColumn(true)"><a class="text-danger"><figure><img src="@/assets/images/delete.png" alt="trash-img" width="15"></figure>Delete</a></li>
                </ul>
              </div>
            </li>
          </ul>
        </div>

       
     
      </div>
</template>
<script>
import moment from "moment";
import { _ } from 'core-js'
import { MoreHorizontalIcon } from 'vue-feather-icons'
import Multiselect from "vue-multiselect-inv";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
export default {
    components: {
        MoreHorizontalIcon,
        Multiselect,
        VuePerfectScrollbar
     
    },
    data: function () {
      return {
        assignedToIds:false,
        caseStatsFilterItems:[
          // { id: 'h1b',name: 'H-1B' ,'selected':true},
          // { id: 'perm',name: 'PERM Process' ,'selected':false},
          // { id: 'i140', name: 'Immigrant Petition (I-140)' ,'selected':false },
          // {  id: 'adj_status_i485', name: 'Adjustment of Status (I-485)' ,'selected':false },
          // { id: 'i130', name: 'I-130','selected':false },
          // {  id: 'i485', name: 'I485','selected':false }
        ],
        settings: { 
          swipeEasing: true,
        },
        duplicating:false,
       
        
         selecetedTab:"TODO",
         todoCount:0,
         caseCount:0,
         taskCount:0,
         updatesCount:0,

         internalUserCount:0,
         petitionerCount:0,
         beneficiaryCount:0
        
       
        
        
      };
     
    },
   
    props: { 
      columnId:'',
      rowId:'',
      widgetData:null,
      rowExistingColumnsLength:0,
      availableEmptyColumns:0,
      viewType:{
        type:String,
        default:'LIST'
        }
     
     
    

   },
    methods:{
      loadMsgAssignedMe(){

        let ueserData = this.getUserData;
        let userId ="";
        if(ueserData && _.has( ueserData ,'userId')){
           userId = ueserData['userId'];
        
        }
        this.assignedToIds = !this.assignedToIds;

        if(this.assignedToIds && userId){
          this.widgetData['filters']['msgListType'] ="";
          this.widgetData['filters']['assignedToIds'] =[];
          this.widgetData['filters']['assignedToIds'].push(userId);
        }else{
          this.widgetData['filters']['assignedToIds'] =[];
          
        }
        this.$emit('reloadWidgetData');
        
      },

       changedCaseType(item){

        if(this.checkProperty(this.widgetData ,'code' ) == 'CLIENT'){
          this.widgetData['filters']['accountType'] = item['id'];
        }


         if(_.has(item ,'id')){
          if(['CURRENT_STATUS_OF_CASE' ,'CASE_STATS_BY_STATUS'].indexOf(this.checkProperty(this.widgetData ,'code' ))>-1 ){

            this.widgetData['filters']['typeIds'] =[item];
           // this.widgetData['filters']['subTypeIds'] =[];

           }else{

            this.widgetData['filters']['caseType'] =item;
            
           }
           this.widgetData['filters']['subTypeIds'] =[];
          
         
          setTimeout( ()=>{
          
          this.$emit('reloadWidgetData')
         },200);
         this.preSelectProcess(item['id']);
         }
        
         
       },
      preSelectProcess(id=''){
        let caseStatsFilterItems =this.getstatsCaseTypes();
        //  [
        //   { id: 'h1b',name: 'H-1B' ,'selected':true},
        //   { id: 'perm',name: 'PERM Process' ,'selected':false},
        //   { id: 'i140', name: 'Immigrant Petition (I-140)' ,'selected':false },
        //   {  id: 'adj_status_i485', name: 'Adjustment of Status (I-485)' ,'selected':false },
        //   { id: 'i130', name: 'I-130','selected':false },
        //   {  id: 'i485', name: 'I485','selected':false }
        // ]
        if(['CURRENT_STATUS_OF_CASE' ,'CASE_STATS_BY_STATUS'].indexOf(this.checkProperty(this.widgetData ,'code' ))>-1 ){
          caseStatsFilterItems =[]
          let item = {
        matcher: {
          statusIds: [],
          typeIds: [],
          "searchString": '',
          getWorkFlowConfig: false,
          getCasenoCodeConfig: false
          // "petitionType":

        },
        page: 1,
        perpage: 1000,
        category: "petition_types",
       

      }
      this.$store
        .dispatch("getMasterData", item)
        .then(response => {
          let caseTypes = response.list;
          //prepare Case menue
          if (this.checkProperty(caseTypes, 'length') > 0) {
            _.forEach(caseTypes,(ctype)=>{
              ctype = Object.assign(ctype,{'selected':false})
              caseStatsFilterItems.push(ctype);
              
            });

            this.caseStatsFilterItems =[];
        if(this.checkProperty(this.widgetData ,'filters' ,'typeIds')){
         
          let selectedId =this.widgetData['filters']['typeIds'][0];
          if(_.has(selectedId,"id")){
            selectedId =selectedId['id']

          }
          if(id !=''){
            selectedId =id;
          }
          let existsItem = _.find(caseStatsFilterItems ,{'id':parseInt(selectedId)});
         
          if(existsItem){
            existsItem['selected'] = true;
            this.caseStatsFilterItems.push(existsItem);
            _.forEach(caseStatsFilterItems ,(item)=>{
               item['selected'] = false;
              if(item['id'] ==existsItem['id']){
                item['selected'] = true;
              }
            
              if(!_.find(this.caseStatsFilterItems ,{'id':item['id']})){
                this.caseStatsFilterItems.push(item);
              }
             

            });

            
          }else{
            this.caseStatsFilterItems = caseStatsFilterItems;
          }
          


        }else{
          this.caseStatsFilterItems = caseStatsFilterItems;
        }
        this.caseStatsFilterItems = _.cloneDeep(this.caseStatsFilterItems);

          }
        })


        }else if(this.checkProperty(this.widgetData ,'code' ) == 'CLIENT'){
        //  "Corporate", // Individual,
          let caseStatsFilterItems =[ 
            { id: 'Corporate',name: 'Corporate' ,'selected':false},
            { id: 'Individual',name: 'Individual' ,'selected':false}
          
          ]

          let selectedId =this.widgetData['filters']['accountType'];
          let existsItem = _.find(caseStatsFilterItems ,{'id':selectedId});
          if(existsItem){
            item['selected'] =true;
            this.caseStatsFilterItems =[];
            this.caseStatsFilterItems.push(existsItem)
            

          }
            _.forEach(caseStatsFilterItems ,(item)=>{
              if(!_.find(this.caseStatsFilterItems ,{"id":item['id']} )){
                item['selected'] =false;
                this.caseStatsFilterItems.push(item)

              }
              
            })

          




        }else{

        
        this.caseStatsFilterItems =[];
        if(this.checkProperty(this.widgetData ,'filters' ,'caseType')){
          let selectedId =this.widgetData['filters']['caseType'];
          if(id !=''){
            selectedId =id;
          }
         

          let existsItem = _.find(caseStatsFilterItems ,{'id':selectedId});
          if(existsItem){
            existsItem['selected'] = true;
            this.caseStatsFilterItems.push(existsItem);
            _.forEach(caseStatsFilterItems ,(item)=>{
               item['selected'] = false;
              if(item['id'] ==existsItem['id']){
                item['selected'] = true;
              }
            
              if(!_.find(this.caseStatsFilterItems ,{'id':item['id']})){
                this.caseStatsFilterItems.push(item);
              }
             

            });

            
          }else{
            this.caseStatsFilterItems = caseStatsFilterItems;
          }
          


        }else{
          this.caseStatsFilterItems = caseStatsFilterItems;
        }
        this.caseStatsFilterItems = _.cloneDeep(this.caseStatsFilterItems);
      }

      this.assignedToIds =false;
      if(['MESSAGES'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1){
        let ueserData = this.getUserData;
        if(ueserData && _.has( ueserData ,'userId')){
          let userId = ueserData['userId'];
          if(this.checkProperty(this.widgetData['filters'] ,"assignedToIds")){
            if(this.widgetData['filters']['assignedToIds'].indexOf(userId) >-1 ){
              this.assignedToIds = true;
            }

          }



        }

       


      }
      },
      togleExpend(){
        //widgetData
        this.widgetData['expend'] = !this.widgetData['expend'];
        this.$emit('togleExpend',{"columnId":this.widgetData['columnId']})
      },
      init(){

        if(['ACTION','DEADLINE'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1){
         this.selecetedTab= "CASES";
          if( this.checkProperty(this.widgetData,'tabName')){
            this.selecetedTab=  this.checkProperty(this.widgetData,'tabName')
          }
       
    }


      },
      getCount(dataproperty='' ,types=['todo'] ,entityTypeList=[] ,tabName='TODO'){
            

      
      
      let path ="dashboard/get-widget-data";
      let postData ={        
        categoryList:['ACTION_COUNT'],
        filters:{

           "types": [], //updates For activity
          "entityTypeList": [],//"petition", "task"
        },
        perpage:10,
       
      };
      
      postData['perpage'] = this.checkProperty(this.widgetData ,"perpage");
      if(this.checkProperty(this.widgetData ,"sorting" ,'path') && this.checkProperty(this.widgetData ,"sorting" ,'order')){
        postData = Object.assign(postData,{"sorting":this.widgetData['sorting']});
      }

     if(this.checkProperty(this.widgetData ,"filters" ) && (['ACTION' ,'DEADLINE'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1) ){
      if((['UPDATES'].indexOf(this.checkProperty(this.widgetData,'code' ))<=-1)){

        _.forEach(this.widgetData['filters'] ,(val ,key)=>{
            //['countryIds' ,'stateIds' ,'typeIds' ,'petitionTypeIds']
            if(['countryIds' ,'stateIds'].indexOf(key)>-1){
              // postData['filters'][key]
              if(_.has(val ,'id')){
                postData['filters'][key] =[val['id']]
              }

            }else{
          
            let arrayListIds = _.filter(val ,(item)=>{
              return _.has(item ,'name') && _.has(item ,'id')
            })
            if(arrayListIds && this.checkProperty(arrayListIds ,'length')>0){
              postData['filters'][key] = arrayListIds.map((item)=>item.id);
            }else{
              postData['filters'][key] =val;

            }
          }


            })

      } else if(this.checkProperty(this.widgetData,'filters' ,tabName )){

          
            _.forEach(this.widgetData['filters'][tabName] ,(val ,key)=>{
            //['countryIds' ,'stateIds' ,'typeIds' ,'petitionTypeIds']
            if(['countryIds' ,'stateIds'].indexOf(key)>-1){
              // postData['filters'][key]
              if(_.has(val ,'id')){
                postData['filters'][key] =[val['id']]
              }

            }else{
          
            let arrayListIds = _.filter(val ,(item)=>{
              return _.has(item ,'name') && _.has(item ,'id')
            })
            if(arrayListIds && this.checkProperty(arrayListIds ,'length')>0){
              postData['filters'][key] = arrayListIds.map((item)=>item.id);
            }else{
              postData['filters'][key] =val;

            }
          }


            })
      }

      }
     
     
      postData['filters']['types'] =[];
      postData['filters']['entityTypeList'] =[];
      
     if((['DEADLINE','ACTION'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1)){
        postData['filters']['types'] =types;
        postData['filters']['entityTypeList'] =entityTypeList;
     }
     //alert(JSON.stringify(entityTypeList))
  
     if((['UPDATES'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1)){
        postData['filters']['types'] =['activity'];
        postData['filters']['entityTypeList'] =[];
     }

     //this.selecetedTab
     if(['UPDATES' ].indexOf(this.checkProperty(this.widgetData,'code' ))>-1){
      
        postData['filters']['userRoleType'] = 'internal_user';
        if([50].indexOf(this.getUserRoleId)>-1){
          postData['filters']['userRoleType'] = 'petitioner';
        }else if([51].indexOf(this.getUserRoleId)>-1){
          postData['filters']['userRoleType'] = 'beneficiary';
        }else{

          if(['internal_user' ,'petitioner','beneficiary'].indexOf(tabName)>-1){
            postData['filters']['userRoleType'] =tabName;
          }
          

        }

       }

      
     
     
       this.$store.dispatch("commonAction" ,{data:postData,'path':path})
       .then((rx) =>{
         let data = rx['ACTION_COUNT'];
         
         if( this.checkProperty(data, 'data') ){
          
          this[dataproperty] = this.checkProperty(data, 'data') ;
         }
      
       
      

     
       

      })
     
        
      },
      changeViewType(){
        

        this.$emit('changeViewType');
        


      },
      changeTab(tab='TODO'){
        this.widgetData['tabName'] = tab;
        this.$emit('changeTab' ,tab);
        this.selecetedTab = tab;

        if(['ACTION'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1){

          if(['TODO' ].indexOf(this.selecetedTab)>-1){
            this.getCount('todoCount' ,['todo'] ,[] ,'TODO');

          }else if(['CASES'].indexOf(this.selecetedTab)>-1){
             this.getCount('caseCount' ,['todo'] ,['petition'] ,'CASES');
            
          }else if(['TASK'].indexOf(this.selecetedTab)>-1){
            this.getCount('taskCount' ,['todo'] ,['task'] ,'TASK');
          }
      }else if(['UPDATES'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1 && false){
         if([50,51].indexOf(this.getUserRoleId)<=-1){
          /*
            internal_user , petitioner .beneficiary
          
          */
         if(this.selecetedTab =='internal_user'){
          this.getCount('internalUserCount' ,['activity'] ,[] ,this.selecetedTab);
         }else if(this.selecetedTab =='petitioner'){
          this.getCount('petitionerCount' ,['activity'] ,[] ,this.selecetedTab);
         }  else if(this.selecetedTab =='beneficiary'){
          this.getCount('beneficiaryCount' ,['activity'] ,[] ,this.selecetedTab);
         }
          
        
         }
        


      }

        
                
       
      },
      
        deleteColumn(){
          this.conformTitle='Are you sure of delete this ?';
           
             if(this.columnId && this.rowId ){
              
             
          let tempData = {
            "rowId": "",
		      	"columnId": "",
          }
            tempData['rowId'] =   this.rowId;
            tempData['columnId'] =   this.columnId;
            this.duplicating =true;
           
            this.$emit("deleteColumn" ,tempData);
            // this.deleteColumnConform =false;
             

        }

        },
        openAddFilterDialog(){
            if(this.columnId && this.rowId ){
             
          let tempData = {
            "rowId": "",
		      	"columnId": "",
            widgetData:null,
            "selecetedTab":''
          }
          tempData['selecetedTab'] = this.selecetedTab;

          if(this.checkProperty(this.widgetData ,'code') =="DEADLINE" && ["TASK", "CASES"].indexOf(this.selecetedTab) <=-1){
            this.selecetedTab = "CASES";
            tempData['selecetedTab'] ="CASES"
          }

            tempData['rowId'] =   this.rowId;
            tempData['columnId'] =   this.columnId;
            tempData['widgetData'] =   this.widgetData;
            this.duplicating =true;
            
            this.$emit("openAddFilterDialog" ,tempData);

        }

        },
      duplicateColumn(){
     
      
        if(this.columnId && this.rowId ){
        
          let tempData = {
            "rowId": "",
		      	"columnId": "",
          }
            tempData['rowId'] =   this.rowId;
            tempData['columnId'] =   this.columnId;
            this.duplicating =true;
            this.$emit("duplicateColumn" ,tempData);
            

          
             
          

        }
      },
    
  },
   mounted() {
    let _self =this;
    this.todoCount =0;
    this.caseCount=0;
    this.taskCount=0;
    this.updatesCount=0;

    this.internalUserCount=0;
    this.petitionerCount =0;
    this.beneficiaryCount =0;



    
    
    
    if(['ACTION' ].indexOf(this.checkProperty(this.widgetData,'code' ))>-1){
      //todoCount:0;
     // caseCount:0;
     // taskCount:0;
     
      this.getCount('todoCount' ,['todo'] ,[] ,'TODO');
      this.getCount('caseCount' ,['todo'] ,['petition'] ,'CASES');
      this.getCount('taskCount' ,['todo'] ,['task'] ,'TASK');
      
     

    }
    if(['UPDATES'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1 ){
          // internal_user petitioner beneficiary
          this.selecetedTab ='internal_user';
          if([50].indexOf(this.getUserRoleId)>-1){
            this.selecetedTab ='beneficiary';
           // this.getCount('petitionerCount' ,['activity'] ,[] ,'petitioner');
          } else if([50,51].indexOf(this.getUserRoleId)<=-1){
            this.selecetedTab ='petitioner';
            
           //  this.getCount('internalUserCount' ,['activity'] ,[] ,'internal_user');
           //  this.getCount('petitionerCount' ,['activity'] ,[] ,'petitioner');
           //  this.getCount('beneficiaryCount' ,['activity'] ,[] ,'beneficiary');
         }
     
     
      
     

    }

    this.init();
    setTimeout(() => {
      _self.preSelectProcess();
    }, 300);
    
   

   },
   computed:{
    isSelected(){
      let selectedItems =_.filter(this.caseStatsFilterItems, {"selected":true});
      if(this.checkProperty(selectedItems,'length')>0){
        return true;
      }else{
        return true//false;
      }

    }
    
   }

  

  
  
  
};

</script>