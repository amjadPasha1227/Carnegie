<template>
    
       <div class="signature-stats">
     
      
        <ul >
          <template v-for="( statusItem ,index) in widgetsItems">
           
          <li @click="redirectTolistPage(statusItem)" class="stats-item cursor" v-bind:class="{
                   'status_created': checkProperty(statusItem ,'statusId') == 1,
                  'status_submited': checkProperty(statusItem ,'statusId') == 2,
                  'status_inProcess': checkProperty(statusItem ,'statusId') == 3,
                  'status_waiting': checkProperty(statusItem ,'statusId') == 4,
                  'status_ready_for_filing':[5, 8].indexOf(checkProperty(statusItem, 'statusId')) > -1,
                  'status_sent_for_signatures': [6, 9,32].indexOf(checkProperty(statusItem, 'statusId')) > -1,
                  'staus_filed_with_USCIS':[7, 18].indexOf(checkProperty(statusItem, 'statusId')) > -1,
                  
                  's received_signed_forms ': [32,10].indexOf(checkProperty(statusItem, 'statusId')) > -1,
                  'RFE_Received': [11, 24].indexOf(checkProperty(statusItem, 'statusId')) > -1,
                  'status_submited-USCIS': checkProperty(statusItem ,'statusId') == 12,
                  'response_to_RFE_Received': checkProperty(statusItem ,'statusId') == 13,
                  'status_jobdescription': checkProperty(statusItem ,'statusId') == 14,
                  'status_pwd_filed': checkProperty(statusItem ,'statusId') == 15,
                  'status_pwd_response': checkProperty(statusItem ,'statusId') == 16,
                  'staus_advertisements': checkProperty(statusItem ,'statusId') == 17,
                  'Status_received_by_USCIS': checkProperty(statusItem ,'statusId') == 19,
                  'Perm_drft_approved': checkProperty(statusItem ,'statusId') == 20,
                  'Perm_submited_dol': checkProperty(statusItem ,'statusId') == 21,
                  'status_approved': checkProperty(statusItem ,'statusId') == 22,
                  'status_denied': checkProperty(statusItem ,'statusId') == 23,
                  'notice_supervisory_audit': checkProperty(statusItem ,'statusId') == 27,
                  'status_supervisory_audit': checkProperty(statusItem ,'statusId') == 28,
                  'status_withdrawn': checkProperty(statusItem ,'statusId') == 31
                }" 
                v-if="checkProperty(statusItem ,'count' ) && checkProperty(statusItem ,'statusName' )" >
                <span>{{ checkProperty(statusItem ,'count' ) }}</span>
                <em> {{ checkProperty(statusItem ,'statusName' ) }}</em>
            
          </li> 
          </template>         
          
        </ul>
        
        
  
        
      </div>

  </template>
  
              
  <script>
  import DateRangePicker from "vue2-daterange-picker";
  import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
  import VueApexCharts from "vue-apexcharts";
  import Vue from "vue";
  import moment from "moment";
  
  import * as am4core from "@amcharts/amcharts4/core";
  import * as am4charts from "@amcharts/amcharts4/charts";
  import am4themes_animated from "@amcharts/amcharts4/themes/animated";
  import chartLoading from "@/views/wall/chartLoading.vue";
  import DatePickerCustom from "@/views/common/_date_picker_custom.vue";
  am4core.useTheme(am4themes_animated);
  
  import NoDataFound from "@/views/common/noData.vue";
  import { _ } from "core-js";
  Vue.use(VueApexCharts);
  
  Vue.component("apexchart", VueApexCharts);
  
  export default {
    components: {
      DateRangePicker,
      chartLoading,
      DatePickerCustom,
      NoDataFound,
    },
    data: function () {
      return {
       chartdivId:'pendingCase-chart',
        loading: true,
        isOpenDateFilter: false,
        filterText: "",
        chartData: [],
        selected_createdDateRange: ["", ""],
        autoApply: "",
        options: {
          labels: [],
          legend: {
            position: "top",
          },
        },
        series: [],
        statusCount: 0,
        allCaseTypes: [],
        selectedCaseTypes: null,
  
        allCaseSubTypes: [],
        selectedCaseSubTypes: [],
        caseStatusList:[],
        loading:false,
      };
    },
  
    mounted() {
     
      //this.getVisaTypes();
     
      const d = new Date();
     let time = d.getTime();
      this.chartdivId ='pendingCase-chart_'+time+'';
      this.filterText = "";
      
  
     
    },
    created() {
      document.addEventListener("scroll", this.handleScroll);
    },
    destroyed() {
      document.removeEventListener("scroll", this.handleScroll);
    },
    methods: {
      redirectTolistPage(item){
        // if(this.checkProperty( item,'statusId') ==99){
        //   this.navigateToDetails(item ,'LCA_LIST' ,'caseSignatuerStats');
        // }else{
        //   this.navigateToDetails(item ,'CASE_LIST' ,'caseSignatuerStats');
        // }
        this.navigateToDetails(item ,'CASE_LIST' ,'caseSignatuerStats');
      },
      handleScroll(event) {
        this.$refs["filter_menu"].dropdownVisible = false;
        // Any code to be executed when the window is scrolled
      },
      reloaStats(seleteddates) {
        this.selected_createdDateRange["startDate"] = seleteddates.startDate;
        this.selected_createdDateRange["endDate"] = seleteddates.endDate;
        this.getStats();
      },
      clear_filter() {
        this.selectedCaseTypes = [];
        this.selectedCaseSubTypes = [];
        this.selected_createdDateRange = [];
        this.filterText = "";
        this.$refs["filter_menu"].dropdownVisible = false;
        this.getStats();
      },
      togleDateFIlter() {
        this.isOpenDateFilter = this.isOpenDateFilter ? false : true;
  
        // if(this.isOpenDateFilter){
        //    alert(this.isOpenDateFilter)
        //     document.addEventListener("click", ()=>{
        //         this.isOpenDateFilter =false;
        //          alert(this.isOpenDateFilter +"FROM TRIGGRED")
  
        //     });
        // }
      },
      generateDate(type = "Today") {
        let startDate = moment().startOf("day").format("YYYY-MM-DD");
        let endDate = moment().endOf("day").format("YYYY-MM-DD");
        this.filterText = "Today";
        if (type == "Today") {
          startDate = moment().startOf("day").format("YYYY-MM-DD");
          endDate = moment().endOf("day").format("YYYY-MM-DD");
          this.selected_createdDateRange["startDate"] = startDate;
          this.selected_createdDateRange["endDate"] = endDate;
        } else if (type == "This Week") {
          this.filterText = "This Week";
          startDate = moment().startOf("week").format("YYYY-MM-DD");
          endDate = moment().endOf("week").format("YYYY-MM-DD");
          this.selected_createdDateRange["startDate"] = startDate;
          this.selected_createdDateRange["endDate"] = endDate;
        } else if (type == "This Month") {
          this.filterText = "This Month";
          startDate = moment().startOf("month").format("YYYY-MM-DD");
          endDate = moment().endOf("month").format("YYYY-MM-DD");
          this.selected_createdDateRange["startDate"] = startDate;
          this.selected_createdDateRange["endDate"] = endDate;
        } else if (type == "Custom_date") {
          startDate = this.selected_createdDateRange["startDate"];
          endDate = this.selected_createdDateRange["endDate"];
          startDate = moment(startDate).format("YYYY-MM-DD");
          endDate = moment(endDate).format("YYYY-MM-DD");
  
          this.filterText = startDate + " To " + endDate;
        }
  
        this.isOpenDateFilter = false;
  
        //  this.getStats();
      },
       
     
      getVisaTypes() {
        let item = {
          matcher: {
            searchString: "",
            getWorkFlowConfig: false,
            // "petitionType":
          },
          page: 1,
          perpage: 100000,
          category: "petition_types",
          sorting: {
            path: "name",
            order: 1,
          },
        };
  
        this.$store.dispatch("getMasterData", item).then((response) => {
          this.allCaseTypes = response.list;
        });
      },
      changedVisaType(item) {
        this.selectedCaseTypes = item;
        this.allCaseSubTypes = [];
        this.selectedCaseSubTypes = [];
        if (_.has(this.selectedCaseTypes, "id")) {
          this.getvisa_subtypes();
        }
        //  this.getStats();
      },
      getvisa_subtypes() {
        if (this.selectedCaseTypes && _.has(this.selectedCaseTypes, "id")) {
          let item = {
            matcher: {
              searchString: "",
              petitionType: parseInt(this.selectedCaseTypes["id"]),
              getWorkFlowConfig: false,
            },
            page: 1,
            perpage: 1000,
            category: "petition_sub_types",
            sorting: {
              path: "name",
              order: 1,
            },
          };
  
          this.$store.dispatch("getMasterData", item).then((response) => {
            this.allCaseSubTypes = response.list;
          });
        }
      },
     
    },
    computed: {},
    props:{
      wallsLoaded:{
        type: Boolean,
        default: true
      },
      widgetsItems:null,
      widgetData:null,
       
    }
  };
  </script>