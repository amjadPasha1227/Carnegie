 <template>
  <div class="graph_block">
     <div class="graph_cnt">
     
      <div>
        <div
          v-show="statusCount > 0 && !loading && wallsLoaded"
          :id="chartdivId"
          style="height: 250px"
        ></div>
        
        <ul class="chart_legends" v-show="statusCount > 0 && !loading && wallsLoaded">
          <template v-for="(cData, ind) in chartData">
            <li :key="ind">
           
              <p><span
              
              v-bind:class="{
                        'Law_Firm': checkProperty(cData ,'roleId') == 1,
                        'Petitioner': checkProperty(cData ,'roleId') == 2,
                        'Beneficiary': checkProperty(cData ,'roleId') == 3,

                        'status_waiting': checkProperty(cData ,'roleId') == 4,
                        'status_ready_for_filing': checkProperty(cData ,'roleId') == 5,
                        'status_sent_for_signatures': checkProperty(cData ,'roleId') == 6,
                        'staus_filed_with_USCIS': checkProperty(cData ,'roleId') == 7,
                        'Status_received_by_USCIS': checkProperty(cData ,'roleId') == 8,
                        'status_approved': checkProperty(cData ,'roleId') == 9,
                        'status_denied': checkProperty(cData ,'roleId') == 10,
                        'RFE_Received': ['11',11].indexOf(checkProperty(cData ,'roleId')) >-1,
                        'response_to_RFE_Filed': checkProperty(cData ,'roleId') == 12,
                        'response_to_RFE_Received': checkProperty(cData ,'roleId') == 13,
                        'status_withdrawn': checkProperty(cData ,'roleId') == 14,
                        ' ': checkProperty(cData ,'roleId') == 15
                      }"
              
              ></span>{{ cData.category }}</p>
            </li>
          </template>
        </ul>

        <template v-if="!loading && statusCount <= 0">
         <NoDataFound   ref="NoDataFoundRef"  :loading="false"  heading="No Data"  type="support"  />
        </template>
      </div>
      

      <chartLoading v-if="loading || !wallsLoaded" />
    </div>
  </div>
</template>

            
<script>
import DateRangePicker from "vue2-daterange-picker";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import VueApexCharts from "vue-apexcharts";
import Vue from "vue";
import moment from "moment";

import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import chartLoading from "@/views/wall/chartLoading.vue";
import DatePickerCustom from "@/views/common/_date_picker_custom.vue";
am4core.useTheme(am4themes_animated);

import NoDataFound from "@/views/common/noData.vue";
import { _ } from "core-js";
Vue.use(VueApexCharts);

Vue.component("apexchart", VueApexCharts);

export default {
  components: {
    DateRangePicker,
    chartLoading,
    DatePickerCustom,
    NoDataFound,
  },
  data: function () {
    return {
     chartdivId:'pendingCase-chart',
      loading: true,
      isOpenDateFilter: false,
      filterText: "",
      chartData: [],
      selected_createdDateRange: ["", ""],
      autoApply: "",
      options: {
        labels: [],
        legend: {
          position: "top",
        },
      },
      series: [],
      statusCount: 0,
      allCaseTypes: [],
      selectedCaseTypes: null,

      allCaseSubTypes: [],
      selectedCaseSubTypes: [],
      caseStatusList:[],
      loading:false,
    };
  },

  mounted() {
   
    //this.getVisaTypes();
   
    const d = new Date();
   let time = d.getTime();
    this.chartdivId ='pendingCase-chart_'+time+'';
    this.filterText = "";
    setTimeout(()=>{

       let colors =this.getCaseColors();

       if(this.checkProperty(this.widgetsItems ,'data','length')>0){
            _.forEach(this.widgetsItems['data'] ,(item)=>{

                 if(this.checkProperty(this.widgetsItems ,'mData','length')>0 && this.checkProperty(item ,'_id') >0){

                 let roleData = _.find(this.widgetsItems['mData'] ,{"_id":item['_id']});
                 if(roleData && this.checkProperty(roleData ,'name')){

                  let  statusColor =_.find(colors ,{'id':item['roleId']});
                    item = Object.assign(item ,{"category":roleData['name'] ,'color':''});

                    if(statusColor && this.checkProperty(statusColor ,'backgroundColor')){
                        item = Object.assign(item ,{'color':''});
                        item['color'] = statusColor['backgroundColor']
                    }
                   

                    if([1,2,3].indexOf(item['roleId'])>-1){
                      if(item['roleId']==1){
                        item['color'] ="#D2AEF5"
                      }else  if(item['roleId']==2){
                        item['color'] ="#96D0B3"
                      }else if(item['roleId']==3){
                        item['color'] ="#F8BF96"
                      }

                    }

                    // 'Law_Firm': checkProperty(cData ,'roleId') == 1,
                    // 'Petitioner': checkProperty(cData ,'roleId') == 2,
                    // 'Beneficiary': checkProperty(cData ,'roleId') == 3,
              
                  
                    this.statusCount = this.statusCount+item['count'];
                  
                      this.chartData.push(item);
                    
                    


                 }

                }
            });
            this.loading =false;
            if( this.statusCount >0){
                 this.initChart();
            }else{
                 setTimeout(()=>{
                    this.updateLoading(false); 
                    setTimeout(()=>{ this.loading = false;  this.updateLoading(false);  } ,10)   
                } ,10)
            }
           

    }

    })

   
  },
  created() {
    document.addEventListener("scroll", this.handleScroll);
  },
  destroyed() {
    document.removeEventListener("scroll", this.handleScroll);
  },
  methods: {
    handleScroll(event) {
      this.$refs["filter_menu"].dropdownVisible = false;
      // Any code to be executed when the window is scrolled
    },
    reloaStats(seleteddates) {
      this.selected_createdDateRange["startDate"] = seleteddates.startDate;
      this.selected_createdDateRange["endDate"] = seleteddates.endDate;
      this.getStats();
    },
    clear_filter() {
      this.selectedCaseTypes = [];
      this.selectedCaseSubTypes = [];
      this.selected_createdDateRange = [];
      this.filterText = "";
      this.$refs["filter_menu"].dropdownVisible = false;
      this.getStats();
    },
    togleDateFIlter() {
      this.isOpenDateFilter = this.isOpenDateFilter ? false : true;

      // if(this.isOpenDateFilter){
      //    alert(this.isOpenDateFilter)
      //     document.addEventListener("click", ()=>{
      //         this.isOpenDateFilter =false;
      //          alert(this.isOpenDateFilter +"FROM TRIGGRED")

      //     });
      // }
    },
    generateDate(type = "Today") {
      let startDate = moment().startOf("day").format("YYYY-MM-DD");
      let endDate = moment().endOf("day").format("YYYY-MM-DD");
      this.filterText = "Today";
      if (type == "Today") {
        startDate = moment().startOf("day").format("YYYY-MM-DD");
        endDate = moment().endOf("day").format("YYYY-MM-DD");
        this.selected_createdDateRange["startDate"] = startDate;
        this.selected_createdDateRange["endDate"] = endDate;
      } else if (type == "This Week") {
        this.filterText = "This Week";
        startDate = moment().startOf("week").format("YYYY-MM-DD");
        endDate = moment().endOf("week").format("YYYY-MM-DD");
        this.selected_createdDateRange["startDate"] = startDate;
        this.selected_createdDateRange["endDate"] = endDate;
      } else if (type == "This Month") {
        this.filterText = "This Month";
        startDate = moment().startOf("month").format("YYYY-MM-DD");
        endDate = moment().endOf("month").format("YYYY-MM-DD");
        this.selected_createdDateRange["startDate"] = startDate;
        this.selected_createdDateRange["endDate"] = endDate;
      } else if (type == "Custom_date") {
        startDate = this.selected_createdDateRange["startDate"];
        endDate = this.selected_createdDateRange["endDate"];
        startDate = moment(startDate).format("YYYY-MM-DD");
        endDate = moment(endDate).format("YYYY-MM-DD");

        this.filterText = startDate + " To " + endDate;
      }

      this.isOpenDateFilter = false;

      //  this.getStats();
    },
     
    initChart() {
    
      this.loading = false;
     let self =this;
      var chart = am4core.create(this.chartdivId, am4charts.XYChart3D);
      chart.logo.disabled = true;
      // Add data
      chart.data = this.chartData;
//       chart.data = [{
//   "category": "white",
//   "count": 501.9,
//   "color": "red"
// }, {
//   "category": "red",
//   "count": 301.9,
//   "color": "yellow"
// }, {
//   "category": "orange",
//   "count": 201.1,
//   "color": "orange"
// }, {
//   "category": "green",
//   "count": 165.8,
//   "color": "green"
// }, {
//   "category": "blue",
//   "count": 139.9,
//   "color": "blue"
// }];

      //chart.contentHeight =320;
      //chart.contentWidth =500;

      //chart.width=200;
      chart.height = 250;

      var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
      categoryAxis.renderer.grid.template.location = 0;
      categoryAxis.dataFields.category = "category";
      categoryAxis.renderer.minGridDistance = 40;
      categoryAxis.fontSize = 0;

var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
valueAxis.renderer.minGridDistance = 30;

var series = chart.series.push(new am4charts.ColumnSeries());
series.dataFields.categoryX = "category";
series.dataFields.valueY = "count";
series.columns.template.tooltipText = "{valueY.value} {category} Cases ";
series.columns.template.tooltipY = 0;
series.columns.template.strokeOpacity = 0;

series.columns.template.adapter.add("fill", function(fill, target) {


let dat = _.find( self.chartData, {"category":target.dataItem.categoryX} )
if(dat && _.has(dat ,'color')){
   return dat['color']
}else{
  return chart.colors.getIndex(target.dataItem.index);
}


  
});

    },
    getVisaTypes() {
      let item = {
        matcher: {
          searchString: "",
          getWorkFlowConfig: false,
          // "petitionType":
        },
        page: 1,
        perpage: 100000,
        category: "petition_types",
        sorting: {
          path: "name",
          order: 1,
        },
      };

      this.$store.dispatch("getMasterData", item).then((response) => {
        this.allCaseTypes = response.list;
      });
    },
    changedVisaType(item) {
      this.selectedCaseTypes = item;
      this.allCaseSubTypes = [];
      this.selectedCaseSubTypes = [];
      if (_.has(this.selectedCaseTypes, "id")) {
        this.getvisa_subtypes();
      }
      //  this.getStats();
    },
    getvisa_subtypes() {
      if (this.selectedCaseTypes && _.has(this.selectedCaseTypes, "id")) {
        let item = {
          matcher: {
            searchString: "",
            petitionType: parseInt(this.selectedCaseTypes["id"]),
            getWorkFlowConfig: false,
          },
          page: 1,
          perpage: 1000,
          category: "petition_sub_types",
          sorting: {
            path: "name",
            order: 1,
          },
        };

        this.$store.dispatch("getMasterData", item).then((response) => {
          this.allCaseSubTypes = response.list;
        });
      }
    },
   
  },
  computed: {},
  props:{
    wallsLoaded:{
      type: Boolean,
      default: true
    },
    widgetsItems:null,
    widgetData:null,
     
  }
};
</script>