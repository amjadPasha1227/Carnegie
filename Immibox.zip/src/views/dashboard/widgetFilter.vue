<template>
  <div>
   <div class="filter-content">
      
        <div class="input-filters">
          <div class="vx-row">
         
            <div class="vx-col w-full">
             <form @submit.prevent > 
              <div class="w-full" v-if="checkIsEditRow">
                    <label for="" class="typo__label">Title<em>*</em> </label>
                    <div class="vs-con-input">
                      <input v-model="updateData.title"  name="title"  data-vv-as="Title" v-validate="'required'" type="text" class="filter-input">
                    </div>
                    <span   class="text-danger text-sm"   v-show="errors.has('title')"  >{{errors.first('title')}}</span>
              </div>
             
              </form>
            </div>
            
            
          </div>
          <h4 v-if="checkIsEditRow" class="filters_title">Filters</h4>
          <div class="vx-row">
            
           
            <!------Task Filter section-->
             <template v-if="['TASK'].indexOf(widgetCode)>-1">
                  
                    <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Assignee(s)</label>
                    <multiselect
                        v-model="updateData.filters.assignedToIds"
                        :options="taskAssignedusersList"
                        :multiple="true"
                        :hideSelected="true"
                        :close-on-select="false"
                        :clear-on-select="false"
                        :preserve-search="true"
                        placeholder="Select"
                        label="name"
                        track-by="name"
                        :preselect-first="false"
                    >
                        <template
                        slot="selection"
                        slot-scope="{ values, isOpen }"
                        >
                        <span
                            class="multiselect__selectcustom"
                            v-if="values.length && !isOpen"
                            >{{ values.length }} Assignee(s) Selected</span
                        >
                        <span
                            class="multiselect__selectcustom"
                            v-if="values.length && isOpen"
                        ></span>
                        </template>
                    </multiselect>
                    </div>
                    <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Watcher(s)</label>
                    <multiselect
                        v-model="updateData.filters.watchingByIds"
                        :options="taskAssignedusersList"
                        :multiple="true"
                        :hideSelected="true"
                        :close-on-select="false"
                        :clear-on-select="false"
                        :preserve-search="true"
                        placeholder="Select"
                        label="name"
                        track-by="name"
                        :preselect-first="false"
                    >
                        <template
                        slot="selection"
                        slot-scope="{ values, isOpen }"
                        >
                        <span
                            class="multiselect__selectcustom"
                            v-if="values.length && !isOpen"
                            >{{ values.length }} Watcher(s) Selected</span
                        >
                        <span
                            class="multiselect__selectcustom"
                            v-if="values.length && isOpen"
                        ></span>
                        </template>
                    </multiselect>
                    </div>
                    <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Priority</label>
                    <multiselect
                        v-model="updateData.filters.priorityIds"
                        :options="taskPriorityList"
                        :multiple="true"
                        :hideSelected="true"
                        :close-on-select="false"
                        :clear-on-select="false"
                        :preserve-search="true"
                        placeholder="Select"
                        label="name"
                        track-by="name"
                        :preselect-first="false"
                    >
                        <template
                        slot="selection"
                        slot-scope="{ values, isOpen }"
                        >
                        <span
                            class="multiselect__selectcustom"
                            v-if="values.length && !isOpen"
                            >{{ values.length }} Priorities Selected</span
                        >
                        <span
                            class="multiselect__selectcustom"
                            v-if="values.length && isOpen"
                        ></span>
                        </template>
                    </multiselect>
                    </div>
                    <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Add To Calendar</label>
                    <multiselect
                        v-model="updateData.filters.addToCalendarList"
                        :options="taskcalendarList"
                        :multiple="true"
                        :hideSelected="true"
                        :close-on-select="false"
                        :clear-on-select="false"
                        :preserve-search="true"
                        placeholder="Select"
                        label="name"
                        track-by="name"
                        :preselect-first="false"
                    >
                        <template
                        slot="selection"
                        slot-scope="{ values, isOpen }"
                        >
                        <span
                            class="multiselect__selectcustom"
                            v-if="values.length && !isOpen"
                            >{{values.length}} Item(s)</span
                        >
                        <span
                            class="multiselect__selectcustom"
                            v-if="values.length && isOpen"
                        ></span>
                        </template>
                    </multiselect>
                    </div>
                     <div class="vx-col md:w-1/2 w-full con-select" v-if="false">
                    <label class="typo__label">Select Status</label>
                    <multiselect
                      v-model="updateData.filters.statusIds"
                      :options="taskStatusList"
                      :multiple="true"
                      :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      <template
                        slot="selection"
                        slot-scope="{ values, isOpen }"
                      >
                        <span
                          class="multiselect__selectcustom"
                          v-if="values.length && !isOpen"
                          >{{ values.length }} Status Selected</span
                        >
                        <span
                          class="multiselect__selectcustom"
                          v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
             </template>

             <!--------------Client Filter Section--------  searchString  -->
             <template v-if="['CLIENT'].indexOf(widgetCode)>-1">
             <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Search by Name/Email</label>

                    <input placeholder="Search by Name/Email" v-model="updateData.filters.searchString" type="text" class="filter-input">
                   
                   
              </div>
                  
                  <div class="vx-col md:w-1/2 w-full con-select" v-if="false">
                    <label class="typo__label">Client Type</label>
                   
                    <multiselect v-model="updateData.filters.clientTypeIds" :options="[{'name':'Individual' ,'id':1} ,{'name':'Corporate' ,'id':2}]" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select" label="name" track-by="name" :preselect-first="false">
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>
                 <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Select Status</label>
                   
                    <multiselect v-model="updateData.filters.statusIds" :options="companySatusList" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select" label="name" track-by="name" :preselect-first="false">
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>

                  

                  <div class="vx-col md:w-1/2 w-full con-select" v-if="[3,4].indexOf(getUserRoleId)>-1">
                    <label class="typo__label">Deleted</label>
                    <multiselect
                     
                      v-model="updateData.filters.statusList"
                      :options="[{'name':'Delete' ,'id':false} ,{'name':'Active' ,'id':true}]"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
             
             </template>
          
             <!------SUPPORT_TICKET-->
             <template v-if="['SUPPORT_TICKET'].indexOf(widgetCode)>-1" >

                  <div v-if="false" class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Priorities</label>
                    <multiselect
                      v-model="updateData.filters.priorityIds"
                      :options="supportPriorityList"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Priorities Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>

                   <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Pending Since</label>

                    <input type="number" placeholder="Pending Since" v-model="updateData.filters.pendingSince" class="filter-input">
                   
                   
                  </div>

                  <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Select Status</label>
                    <multiselect
                      v-model="updateData.filters.statusIds"
                      :options="supportTicketStatusList"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Status Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
             
             
             </template>

             <template v-if="['CASE_STATS_BY_BRANCH'].indexOf(widgetCode)>-1">


              <div class="vx-col md:w-1/2 w-full con-select" v-if="[3].indexOf(getUserRoleId)>-1 && ['CASE_STATS_BY_BRANCH'].indexOf(widgetCode)>-1 ">
                    <label class="typo__label">Branch</label>
                    
                    <multiselect
                      v-model="updateData.filters.branchIds"
                      :options="branchList"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select "
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                       @search-change="peritioners_search_fun"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Branch(s) selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>


                 <div class="vx-col md:w-1/2 w-full con-select" v-if="['CASE_STATS_BY_BRANCH'].indexOf(widgetCode)<=-1">
                    <label class="typo__label">Status</label>
                    <multiselect
                      v-model="updateData.filters.statusIds"
                      :options="allCaseStatusids"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Status Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>

                   <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Case Type</label>
                    <multiselect
                      @input="changedVisaType"
                      v-model="updateData.filters.typeIds"
                      :options="visaTypes"
                      :multiple="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Case Type"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Case Type(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>

                  <!---all_subtypes---->
                  <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Case Subtype</label>
                    <multiselect
                     
                      v-model="updateData.filters.subTypeIds"
                      :options="all_subtypes" 
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Case Subtype"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Case Subtype(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
                   <div class="vx-col md:w-1/2 w-full con-select" v-if="[3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1  &&  ['CASE_STATS_BY_BRANCH'].indexOf(widgetCode)<=-1"  >
                    <label class="typo__label">Petitioners</label>
                    <multiselect v-model="updateData.filters.petitionerIds" :options="all_peritioners" 
                     @input="updatePeritioners('petitionerIds')"
                      :multiple="true" :hideSelected="true"
                                 :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                                 placeholder="Select" label="name" track-by="name" :preselect-first="false"
                                 @search-change="peritioners_search_fun"
                    >
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Peritioner(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>

                    </multiselect>

                  </div>
                   <div class="vx-col md:w-1/2 w-full con-select widget_PP" v-if="false">
                    <label class="typo__label">Premium Processing </label>
                    <multiselect
                     
                      v-model="updateData.filters.premiumProcessing"
                      :options="premiumProcessingList"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Premium Processing(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
                  
                  <div class="vx-col md:w-1/2 w-full con-select" v-if="[3,4].indexOf(getUserRoleId)>-1 && ['CASE_STATS_BY_BRANCH'].indexOf(widgetCode)<=-1">
                    <label class="typo__label">Deleted</label>
                    <multiselect
                     
                      v-model="updateData.filters.statusList"
                      :options="[{'name':'Deleted' ,'id':false} ,{'name':'Active' ,'id':true}]"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }}  Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>

                   
             
             </template>
             <template v-if="['CASE_SIGN_STATS'].indexOf(widgetCode)>-1">
              <div class="vx-col md:w-1/2 w-full con-select">
               
                    <label class="typo__label">Case Type </label>
                    <multiselect
                     
                      v-model="updateData.filters.caseType"
                      :options="allCaseTypes"
                      :multiple="false"
                      :close-on-select="true"
                      :clear-on-select="true"
                      :preserve-search="true"
                      placeholder="Select Case Type"
                      label="name"
                      track-by="name"
                      :preselect-first="true"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Case Type(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>

              <div class="vx-col md:w-1/2 w-full con-select" v-if="[3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1 " >
                    <label class="typo__label">Petitioners</label>
                   
                   
                    <multiselect
                      v-model="updateData.filters.companyIds"
                      :options="all_peritioners"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                       @search-change="peritioners_search_fun"
                       @input="updatePeritioners('companyIds')"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Petitioners selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>

             </template>


             <template  v-if="[ 'MESSAGES' ,'CURRENT_STATUS_OF_CASE','ACTION','UPDATES','DEADLINE', 'CASE_BY_STATUS','CASE_STATS_BY_STATUS','PENDING_CASE_STATS'].indexOf(widgetCode)>-1">

                 <template v-if="tabName !='TASK'">
                  <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Case Type </label>
                    <multiselect
                      @input="changedVisaType"
                      v-model="updateData.filters.typeIds"
                      :options="visaTypes"
                      :multiple="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Case Type"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Case Type(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>

                  <!---all_subtypes---->
                  <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Case Subtype</label>
                    <multiselect
                     
                      v-model="updateData.filters.subTypeIds"
                      :options="all_subtypes" 
                      :multiple="true" 
                      :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Case Subtype"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Case Subtype(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
               


                  <div class="vx-col md:w-1/2 w-full con-select" v-if="[3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1 " >
                    <label class="typo__label">Petitioners</label>
                    <multiselect
                      v-model="updateData.filters.companyIds"
                      :options="all_peritioners"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                       @search-change="peritioners_search_fun"
                       @input="updatePeritioners('companyIds')"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Petitioners selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>
                  </template>
                  <template v-if="['MESSAGES','CASE_SIGN_STATS'].indexOf(widgetCode)<=-1">

                      <div class="vx-col md:w-1/2 w-full con-select" v-if="[3].indexOf(getUserRoleId)>-1">
                          <label class="typo__label">Branch</label>
                          
                          <multiselect
                            v-model="updateData.filters.branchIds"
                            :options="branchList"
                            :multiple="true" :hideSelected="true"
                            :close-on-select="false"
                            :clear-on-select="false"
                            :preserve-search="true"
                            placeholder="Select "
                            label="name"
                            track-by="name"
                            :preselect-first="false"
                            @search-change="peritioners_search_fun"
                          >
                          
                            <template slot="selection" slot-scope="{ values, isOpen }">
                              <span
                              class="multiselect__selectcustom"
                              v-if="values.length && !isOpen"
                              >{{ values.length }} Branch(s) Selected</span
                              >
                              <span
                              class="multiselect__selectcustom"
                              v-if="values.length && isOpen"
                              ></span>
                            </template> 
                          </multiselect>
                        </div>

                        <div class="vx-col md:w-1/2 w-full con-select" v-if="[ 'DEADLINE' ,'PENDING_CASE_STATS'].indexOf(widgetCode)>-1 && false">
                          <label class="typo__label">Assigned To</label>
                          <multiselect
                            v-model="updateData.filters.assignedTo"
                            :options="[{'id':true ,'name':'Client'} ,{'id':false ,'name':'Law Firm'} ]"
                            :multiple="true" :hideSelected="true"
                            :close-on-select="false"
                            :clear-on-select="false"
                            :preserve-search="true"
                            placeholder="Select "
                            label="name"
                            track-by="name"
                            :preselect-first="false"
                            @search-change="peritioners_search_fun"
                          >
                          
                            <template slot="selection" slot-scope="{ values, isOpen }">
                              <span
                              class="multiselect__selectcustom"
                              v-if="values.length && !isOpen"
                              >{{ values.length }} selected</span
                              >
                              <span
                              class="multiselect__selectcustom"
                              v-if="values.length && isOpen"
                              ></span>
                            </template> 
                          </multiselect>
                        </div>

                      <template v-if="[ 'ACTION','UPDATES','DEADLINE' ].indexOf(widgetCode)>-1 && tabName =='TASK'">
                      <div class="vx-col md:w-1/2 w-full con-select" >
                          <label class="typo__label">Created By</label>
                          <multiselect
                            v-model="updateData.filters.createdByIds"
                            :options="internalUsers"
                            :multiple="true" :hideSelected="true"
                            :close-on-select="false"
                            :clear-on-select="false"
                            :preserve-search="true"
                            placeholder="Select "
                            label="name"
                            track-by="name"
                            :preselect-first="false"
                            @search-change="getAssignedUsersList"
                            
                          >
                          
                            <template slot="selection" slot-scope="{ values, isOpen }">
                              <span
                              class="multiselect__selectcustom"
                              v-if="values.length && !isOpen"
                              >{{ values.length }} selected</span
                              >
                              <span
                              class="multiselect__selectcustom"
                              v-if="values.length && isOpen"
                              ></span>
                            </template> 
                          </multiselect>
                        </div>

                        <div class="vx-col md:w-1/2 w-full con-select" >
                          <label class="typo__label">Assignee(s)</label>
                          <multiselect
                            v-model="updateData.filters.assignedToIds"
                            :options="internalUsers"
                            :multiple="true" :hideSelected="true"
                            :close-on-select="false"
                            :clear-on-select="false"
                            :preserve-search="true"
                            placeholder="Select "
                            label="name"
                            track-by="name"
                            :preselect-first="false"
                            @search-change="getAssignedUsersList"
                            @input="filterAssignedUsers"
                          >
                          
                            <template slot="selection" slot-scope="{ values, isOpen }">
                              <span
                              class="multiselect__selectcustom"
                              v-if="values.length && !isOpen"
                              >{{ values.length }} selected</span
                              >
                              <span
                              class="multiselect__selectcustom"
                              v-if="values.length && isOpen"
                              ></span>
                            </template> 
                          </multiselect>
                        </div>
                        <div class="vx-col md:w-1/2 w-full con-select" >
                          <label class="typo__label">Watcher(s)</label>
                          <multiselect
                            v-model="updateData.filters.watchingByIds"
                            :options="internalUsers"
                            :multiple="true" :hideSelected="true"
                            :close-on-select="false"
                            :clear-on-select="false"
                            :preserve-search="true"
                            placeholder="Select "
                            label="name"
                            track-by="name"
                            :preselect-first="false"
                            @search-change="getAssignedUsersList"
                            @input="filterAssignedUsers"
                          >
                          
                            <template slot="selection" slot-scope="{ values, isOpen }">
                              <span
                              class="multiselect__selectcustom"
                              v-if="values.length && !isOpen"
                              >{{ values.length }} selected</span
                              >
                              <span
                              class="multiselect__selectcustom"
                              v-if="values.length && isOpen"
                              ></span>
                            </template> 
                          </multiselect>
                        </div>
                      </template>
                  </template>
                  
             
             </template>

            




             <template v-if="[ 'CLIENT'].indexOf(widgetCode)>-1">
             
                  <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Country</label>
                    <multiselect name="spouseaddresscountry"   v-model="updateData.filters.countryIds"
                          @input="changedCountry" :show-labels="false" track-by="id" label="name"
                          data-vv-as="Country" placeholder="Select Country" :options="countries" :searchable="true"
                          :allow-empty="true">
                          <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                          </multiselect>
                  </div>
                  <div class="vx-col md:w-1/2 w-full con-select"> 
                     <label for class="typo__label">State</label>
                        <multiselect name="State"   v-model="updateData.filters.stateIds"
                          @input="changedState" :show-labels="false" track-by="id" label="name" data-vv-as="State" :multiple="false"
                          placeholder="Select State" :options="states" :searchable="true" :allow-empty="true">
                          <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                        </multiselect>
                  </div>
                  <div class="vx-col md:w-1/2 w-full con-select">
                     <label for class="typo__label">City</label>
                        <multiselect name="city"   v-model="updateData.filters.locationIds"
                        @input="changedCity"
                        :show-labels="false" track-by="id" label="name" data-vv-as="City"
                          placeholder="Select City" :options="locations" :searchable="true" :allow-empty="true" :multiple="true" :close-on-select="false" :hideSelected="true">
                          <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                        </multiselect>
                  </div>
             </template>

           <!--------------BENEFICIARY------->
             <template v-if="[ 'BENEFICIARY'].indexOf(widgetCode)>-1" >
                  <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Status</label>
                    <multiselect
                      v-model="updateData.filters.statusIds"
                      :options="allUserStatusids"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Status"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Status Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
                  <!------
                  petitionTypeIds =item ;
                            this. updateData.filters.petitionSubTypeIds
                  -->
                   <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Case Type</label>
                    <multiselect
                      @input="changedVisaType"
                      v-model="updateData.filters.petitionTypeIds"
                      :options="visaTypes"
                      :multiple="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Case Type"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Case Type(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>

                  <!---all_subtypes---->
                  <div class="vx-col md:w-1/2 w-full con-select" v-if="false">
                    <label class="typo__label">Case Subtype</label>
                    <multiselect
                     
                      v-model="updateData.filters.petitionSubTypeIds"
                      :options="all_subtypes" 
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Subtype"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Case Subtype(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
                   <div class="vx-col md:w-1/2 w-full con-select" v-if="[3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1 "  >
                    <label class="typo__label">Petitioners</label>
                    <multiselect v-model="updateData.filters.petitionerIds" :options="all_peritioners"
                       :multiple="true" :hideSelected="true"
                        @input="updatePeritioners('petitionerIds')"
                                 :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                                 placeholder="Select Petitioners" label="name" track-by="name" :preselect-first="false"
                                 @search-change="peritioners_search_fun"
                    >
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Peritioner(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>

                    </multiselect>

                  </div>
                  <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Get Active Cases</label>

                    <vs-switch class="mb-0"   v-model="updateData.filters.activeCases">
                                <span slot="on">Yes</span>
                                <span slot="off">No</span>
                            </vs-switch>
                  </div>
             </template>
             <!------LCA-->
              <template v-if="[ 'LCA'].indexOf(widgetCode)>-1" >

              <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Search by Job Title</label>

                    <input placeholder="Search by Job Title" v-model="updateData.filters.searchString" type="text" class="filter-input">
                   
                   
              </div>
              
              <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Desired SOC Code(s)</label>
                   
                    <multiselect
                      v-model="updateData.filters.desiredSOCCodeIds"
                      :options="masterSocList"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select SOC Code"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Status selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>

                <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Status</label>
                    
                    <multiselect
                      v-model="updateData.filters.statusIds"
                      :options="allLcaStatuses"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Status"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Status selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/2 w-full con-select" v-if="[3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1 " >
                    <label class="typo__label">Petitioners</label>
                    <multiselect
                      v-model="updateData.filters.petitionerIds"
                      :options="all_peritioners"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Petitioners"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                       @search-change="peritioners_search_fun"
                      @input="updatePeritioners('petitionerIds')"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Petitioners selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>

              
              
              </template>

              
              <template v-if="[ 'INVOICE'].indexOf(widgetCode)>-1" >

                <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Status</label>
                    <multiselect
                      v-model="updateData.filters.statusIds"
                      :options="allInvoiceStatusList" 
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Status"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Status selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/2 w-full con-select" v-if="[3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1 " >
                    <label class="typo__label">Petitioners</label>
                    <multiselect
                      v-model="updateData.filters.companyIds"
                      :options="all_peritioners"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Petitioners"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                      @input="updatePeritioners('companyIds')"
                       @search-change="peritioners_search_fun"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Petitioners selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>
                   <div class="vx-col md:w-1/2 w-full con-select" v-if="[3].indexOf(getUserRoleId)>-1">
                    <label class="typo__label">Branch</label>
                    
                    <multiselect
                      v-model="updateData.filters.branchIds"
                      :options="branchList"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select "
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                       @search-change="peritioners_search_fun"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Branch(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>

              
              
              </template>





            <div class="vx-col md:w-1/2 w-full con-select date_range" v-if="[ 'CASE_BY_STATUS','CASE_STATS_BY_STATUS'].indexOf(widgetCode)>-1 ">
              <label class="typo__label" v-if="tabName=='TASK'" >Due Date</label>
               <label class="typo__label" v-else>Deadline Date</label>
               <!------resetSelectedCreatedDateRange();
      resetSelecteddeadLineDateRange();-->
              
              <date-range-picker
                @update="updatedDeadLineRange"
                :autoApply="autoApply"
                :ranges="false" 
                :opens="'left'"
                v-model="selected_deadLineDateRange"
              ></date-range-picker>

              <span class="cleardate" v-if="checkDeadLineDateRange" @click="resetSelecteddeadLineDateRange()"></span>
            </div>

           
            
            <div class="vx-col md:w-1/2 w-full con-select date_range" v-if="[ 'CASE_SIGN_STATS','CURRENT_STATUS_OF_CASE'].indexOf(widgetCode)<=-1">
                    <label class="typo__label">Created Date Range</label>
                    <date-range-picker
                     
                      :maxDate="new Date()"
                      :autoApply="autoApply"
                      :ranges="false"
                      v-model="selected_createdDateRange"
                    ></date-range-picker>
                     <span class="cleardate" v-if="checkCreatedRateRange" @click="resetSelectedCreatedDateRange()"></span>
            </div>

            
           
           


              <div class="vx-col md:w-1/2 w-full con-select"  v-if="[ 'CASE_SIGN_STATS','CURRENT_STATUS_OF_CASE','PENDING_CASE_STATS'].indexOf(widgetCode)<=-1">
              
                      <label for="" class="typo__label">Number of Records</label>
                      <multiselect @input="updatedPagenation" v-model="updateData.perpage" :options="availablePerPages"></multiselect>
                
              </div>
              <div class="vx-col md:w-1/2 w-full con-select widget_PP" v-if="['PENDING_CASE_STATS','CASE_BY_STATUS','CASE_STATS_BY_STATUS'].indexOf(widgetCode)>-1" >
                  <label class="typo__label"></label>                  
                  <vs-checkbox  id="addCalendar" name="calendar"  @change="premiumProcessChanged()" v-model="updateData.filters.premiumProcess">Premium Processing</vs-checkbox>  

              </div>

              <div class="vx-col md:w-1/2 w-full con-select widget_PP" v-if="['DEADLINE'].indexOf(widgetCode)>-1 && tabName =='CASES'" >
                  <label class="typo__label"></label>    
                       
                  <vs-checkbox  id="addCalendar" name="calendar"  @change="premiumProcessChanged()" v-model="updateData.filters.premiumProcess">Premium Processing  </vs-checkbox>  

              </div>

              


          
           <template class="vx-row" v-if="checkProperty( sortingList ,'length')>0 && ['CURRENT_STATUS_OF_CASE','PENDING_CASE_STATS'].indexOf(widgetCode)<=-1" >
            <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Sort On</label>
                   
                    <multiselect
                      v-model="sortingPath"
                      :options="sortingList" 
                      :multiple="false" 
                      :allow-empty="false"
                      :hideSelected="true"
                      :close-on-select="true"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Sorting Path"
                     :preselect-first="false"
                     @input="updateSortingPath"
                      label="name"
                      track-by="name"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Status selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
               </div>
                <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Sort Order</label>
                    
                    <multiselect
                      v-model="updateData.sortingOrder"
                      :options="sortOrderList" 
                      :multiple="false" 
                      :allow-empty="false"
                      :hideSelected="true"
                      :close-on-select="true"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Sorting Order"
                     :preselect-first="false"
                     label="name"
                     track-by="name"
                     @input="updateSortingOrder"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Status selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
               </div>
          </template>
         
          
           <template class="vx-row" v-if="[ 'MESSAGES'].indexOf(widgetCode)>-1 && false" >
                  <div class="vx-col md:w-1/2 w-full con-select">
                    <label class="typo__label">Mesage Type (Read/ Un-Read)</label>
                    
                    <multiselect
                      :name="readList"
                      v-model="updateData.filters.readList"
                      :options="msgReadList" 
                      :multiple="true" 
                      :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Mesage Type"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Mesage Type(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
                <div class="vx-col w-full form_group custom-radio_wrap"   >
                    <!-- <ul class="custom-radio" vs-type="flex" vs-align="center">
                      <li>
                        
                      <vs-radio    name="msgListType"  vs-value="inbox" v-model="updateData.filters.msgListType" class="w-full"
                              ><span ref="Free-Flow">Inbox Messages</span></vs-radio > 

                      
                      </li>
                            <li>
                  
                          <vs-radio   ref="Sequential"  name="msgListType"  vs-value="sent"   v-model="updateData.filters.msgListType" class="w-full"
                              > <span ref="Sequential">Sent Messages</span></vs-radio > 
                      
                            </li>
                        
                    </ul> -->
                    <div class="form-container p-0">
                      <div class="custom-radio custom-radio_btns">   
                        <vs-radio class="mr-6" name="msgListType"  v-model="updateData.filters.msgListType" vs-value="inbox">Inbox Messages</vs-radio>
                        <vs-radio name="msgListType" v-model="updateData.filters.msgListType" vs-value="sent">Sent Messages</vs-radio>
                      </div> 
                    </div>
              </div>
            </template>
            </div>

        </div>
        
   </div>
        <div class="footer-actions">
        <span class="loader" v-if="widgetUpdating" ><img src="@/assets/images/main/loader.gif"></span>
        <!-- <span class="loader"  ><img src="@/assets/images/main/loader.gif"></span> -->
          <button  color="dark" class="actionbtn clearbtn" :disabled="widgetUpdating"  type="filled" @click="resetFilters()">Clear</button>
          <button @click="updateWidget()" :disabled="widgetUpdating" class="actionbtn applybtn">
           <template v-if="checkIsEditRow">Update</template>
           <template v-else>Apply</template>
          
          </button>
        </div>
   </div>
</template> 
<script>
import Multiselect from "vue-multiselect-inv";
import DateRangePicker from "vue2-daterange-picker";
  import Datepicker from "vuejs-datepicker-inv";
  import moment from "moment";
export default {

    name:'WidgetFilter',
     components: {
        Multiselect,
        DateRangePicker,
        Datepicker
     },
    data: function () {
            return {
              msgUsersList:[],
              petitionDetails:null,
              caseList:[],
             // "msgListTypeList": [{name:"Inbox" ,id:'inbox'},{name:"Sent" ,id:'sent'}],  // inbox or sent by default inbox
		         	"msgReadList": [{name:"Read" ,id:true},{name:"Un-read" ,id:false}],
              allCaseTypes:[],
        //       [
        //   { id: 'h1b',name: 'H-1B'},
        //   { id: 'perm',name: 'PERM Process'},
        //   { id: 'i140', name: 'Immigrant Petition (I-140)' },
        //   {  id: 'adj_status_i485', name: 'Adjustment of Status (I-485)' },
        //   { id: 'i130', name: 'I-130' },
        //   {  id: 'i485', name: 'I485' }
        // ],
              selectedFilters:null,
              internalUsers:[],
              tempAssignedUsersList:[],
              sortOrderList:[{'name':'ASC' ,'id':1},{'name':'DESC' ,'id':-1}],
                autoApply:true,
                selected_createdDateRange: {"startDate":'', "endDate":''},
                primary:false,
                options:[],
                widgetUpdating:false,
                availablePerPages:[5,10,25,50,100,200,250,300,350,400,450,500],
                updateData:{
                    "widgetId": "",
                    "rowId": "",
                    "columnId": "",
                    "title": "",
                    "code": "",
                    "order": 1,
                    "heightInPx": 300,
                    "height": "1X",
                    "filters": {
                       
                        "createdDateRange": []
                    },
                    "sorting": {
                        "path": "createdOn",
                        "order": -1
                    },
                    "sortingOrder":{'name':'ASC' ,'id':1},
                    "perpage": 10
                },
                sortingList:['createdOn' ,'updatedOn'],
                sortingPath:{
                        "name": "Created On",
                        "id": 'createdOn'
                    },
                  

                widgetCode:'',
                peritioners_search_value:'',

                /*Task Master Data List*/
                taskStatusList:[],
                taskPriorityList:[],
                taskAssignedusersList:[],
                taskSelectedCalendar:[],
                taskcalendarList:[{'name':'Yes' ,'id':true} ,{'name':'No' ,'id':false}],
                /* Client Filter Section */
                companySatusList:[],
                countries:[],
                states:[],
                locations:[],

                /*Support Ticket filter section*/

                supportPriorityList:[],
                supportTicketStatusList:[],

                /*  CASE_BY_STATUS  CASE_STATS_BY_STATUS */
                allCaseStatusids:[],
                all_subtypes:[],
                visaTypes:[],
                all_peritioners:[],
                premiumProcessingList:[{name:'Enabled' ,id:true },{name:'Disabled' ,id:false }],
                selected_deadLineDateRange: {"startDate":'', "endDate":''},

                 /* ---BENEFICIARY ---- */
                 allUserStatusids:[],
                 /*LCA*/
                 allLcaStatuses:[],
                 masterSocList:[],

                /*  INVOICE */
                 allInvoiceStatusList:[],

                 branchList:[],

                


               

            }
    
    },
    methods: { 

      getCasList(){
        let obj = {
          matcher: {
            rfeCases:false,
            searchString: "",
            statusIds:[],// [],//this.final_selected_statusids,
            beneficiaryIds:[],
            premiumProcessing:[],
            //"countryIds": [this.country_code],
            stateIds: [],//[1,2,3,4,5,6], 
            locationIds: [],
            //"createdDateRange":self.selected_createdDateRange,
            petitionerIds:[],
            branchIds:[],
            typeIds:[],
            subTypeIds:[],
            deadlineDateRange:[],
            "getMissingDeadlines": false,
            statusList:[],
            intStatusIds:[1],
            "assignedUserIds":[]
          },
          page: 1,
          perpage: 10000000,
          sorting:{path: "updatedOn", order: -1}
        };
        this.caseList =[];
         // "typeIds": [],
        //  "subTypeIds": [],
        //updateData.filters.subTypeIds
        if(this.checkProperty(this.updateData['filters'],"typeIds" ,"length")>0){
          obj['matcher']['typeIds'] = _.map(his.updateData['filters']['typeIds'], (item)=>item['id'])
        }
        if(this.checkProperty(this.updateData['filters'],"subTypeIds" ,"length")>0){
          obj['matcher']['subTypeIds'] = _.map(his.updateData['filters']['subTypeIds'], (item)=>item['id'])
        }
        this.$store.dispatch("commonAction", { "data": obj,"path":"/petition-common/list"}).then(response => { 
          if(response && this.checkProperty(response ,"list", "length" ) >0){
            this.caseList = this.checkProperty(response ,"list", "length" )

          }

        })

      },

      getMsgusers() {
            this.assignedUserName = [];
            this.usersList = [];
           
            let postdata = {
                petitionId: this.checkProperty(this.petitionDetails,'_id'),
                petitionType:"NORMAL",  //"GC" // 'RFE', 'NORMAL' ,'PERM'
                filters:{
                    searchString: '',
                },
            };
            if(( [3].indexOf(this.checkProperty(this.petitionDetails,'type'))>-1 && [15].indexOf(this.checkProperty(this.petitionDetails,'subType'))>-1)){
                postdata['petitionType'] = 'PERM'
            }
            this.$store.dispatch("getcommunicationuserslist", postdata).then(response => {
                let ignoreUsers =[]
                if([3,4,5,6,7,8,9,10,11,12,13,14].indexOf(this.getUserRoleId) >-1){
                    //ignoreUsers =[51];
                }else if([50].indexOf(this.getUserRoleId) >-1){
                    ignoreUsers =[];
                }else if([51].indexOf(this.getUserRoleId) >-1){
                    ignoreUsers =[3,4,5,6,7,8,9,10,11,12,13,14];
                }
                if(ignoreUsers.length>0 && response.length>0){
                    response  = _.filter(response , (usr)=>{
                        return ignoreUsers.indexOf(usr['roleId'] )<=-1
                    })
                }
                let modifiedList = [];
                let tempList  = response
                this.msgUsersList = tempList;
                

                
            });
      },
      updatedPagenation(val){

       
        if( ['ACTION' ,'DEADLINE'].indexOf(this.widgetCode)>-1&&  ['TODO' , "CASES" ,"TASK" ,'UPDATES'].indexOf(this.tabName) >-1){
          this.updateData['pagination'][this.tabName]['perpage'] =val; 
           this.updateData =_.cloneDeep(this.updateData);
            

        
        }

      },

       
        

         getwidgetFilters(){
        //getWidgetFilterMasterData
        let self = this;

        this.sortingList =[];
        let postData ={
          code:''
        }
        
         postData['code'] =  this.widgetCode;
        this.$store.dispatch('getWidgetFilterMasterData' ,postData)
        .then((rx)=>{
          
          this.selected_createdDateRange = {"startDate":'', "endDate":''};
          this.selected_deadLineDateRange = {"startDate":'', "endDate":''};
        

        
          _.forEach( rx['filters'] ,( val , key)=>{

            if( ['ACTION' ,'DEADLINE'].indexOf(this.widgetCode)>-1&&  ['TODO' , "CASES" ,"TASK" ,'UPDATES'].indexOf(key) >-1){
              
              if( !_.has( this.updateData['filters'] ,key)){
                 this.updateData['filters'][key] = val;
                 this.updateData = _.cloneDeep(this.updateData);
                 
              }

              
              let dbFilters = this.checkProperty(this.widgetData['widgetData'] ,'filters' ,key);
              

              _.forEach(val ,(filtVal , filterKey)=>{
             
                  let filterVal = _.cloneDeep(filtVal);
                 let isExistsInDb = _.has(dbFilters ,filterKey);
                  if(isExistsInDb){
                       filterVal = dbFilters[filterKey];
                  }
                    

                  this.updateData['filters'][key][filterKey] = filterVal;
                  
                  if(key ==this.tabName){
                     this.updateData['filters'][filterKey] =filterVal;


                      if(isExistsInDb){

                          if(filterKey =='createdDateRange'){
                            if(this.checkProperty(dbFilters,'createdDateRange' ,'length')>1){

                              let createdDateRange = dbFilters['createdDateRange'];
                              this.selected_createdDateRange["startDate"] = moment(createdDateRange[0]).format('YYYY-MM-DD');
                              this.selected_createdDateRange["endDate"]= moment(createdDateRange[1]).format('YYYY-MM-DD');

                            }

                          }

                          if(filterKey =='deadlineDateRange'){
                            if(this.checkProperty(dbFilters,'deadlineDateRange' ,'length')>1){

                              let deadlineDateRange = dbFilters['deadlineDateRange'];
                              this.selected_createdDateRange["startDate"] = moment(deadlineDateRange[0]).format('YYYY-MM-DD');
                              this.selected_createdDateRange["endDate"]= moment(deadlineDateRange[1]).format('YYYY-MM-DD');

                            }

                          }else if(filterKey == 'dueDateRange'){
                            if(this.checkProperty(dbFilters,'dueDateRange' ,'length')>1){

                              let deadlineDateRange = dbFilters['dueDateRange'];
                              this.selected_createdDateRange["startDate"] = moment(deadlineDateRange[0]).format('YYYY-MM-DD');
                              this.selected_createdDateRange["endDate"]= moment(deadlineDateRange[1]).format('YYYY-MM-DD');

                            }

                          }
                    
                
                      }
                  

                  }
              })
              
            }else{

              let dbFilters = this.checkProperty(this.widgetData['widgetData'] ,'filters');
               let isExistsInDb = _.has(dbFilters ,key);

               if(isExistsInDb){

                  if(key =='createdDateRange'){

                    if(this.checkProperty(dbFilters,'createdDateRange' ,'length')>1){
                        let createdDateRange =  dbFilters[key]
                        this.selected_createdDateRange["startDate"] = moment(createdDateRange[0]).format('YYYY-MM-DD');
                        this.selected_createdDateRange["endDate"]= moment(createdDateRange[1]).format('YYYY-MM-DD');
                    }

                  }

                   if(key =='deadlineDateRange'){
                        if(this.checkProperty(dbFilters,'deadlineDateRange' ,'length')>1){

                          let deadlineDateRange = dbFilters['deadlineDateRange'];
                          this.selected_createdDateRange["startDate"] = moment(deadlineDateRange[0]).format('YYYY-MM-DD');
                          this.selected_createdDateRange["endDate"]= moment(deadlineDateRange[1]).format('YYYY-MM-DD');

                        }

                      }else if(key == 'dueDateRange'){
                        if(this.checkProperty(dbFilters,'dueDateRange' ,'length')>1){

                          let deadlineDateRange = dbFilters['dueDateRange'];
                          this.selected_createdDateRange["startDate"] = moment(deadlineDateRange[0]).format('YYYY-MM-DD');
                          this.selected_createdDateRange["endDate"]= moment(deadlineDateRange[1]).format('YYYY-MM-DD');

                        }

                      }

                this.updateData['filters'][key] =dbFilters[key];

               }else{
                 this.updateData['filters'][key] =val;
               }

               if(this.widgetCode == 'CASE_SIGN_STATS' && isExistsInDb && key=='caseType'){
                 let caseStatsFilterItems = this.getstatsCaseTypes();
                 // [
                //     { id: 'h1b',name: 'H-1B' ,'selected':true},
                //     { id: 'perm',name: 'PERM Process' ,'selected':false},
                //     { id: 'i140', name: 'Immigrant Petition (I-140)' ,'selected':false },
                //     {  id: 'adj_status_i485', name: 'Adjustment of Status (I-485)' ,'selected':false },
                //     { id: 'i130', name: 'I-130','selected':false },
                //     {  id: 'i485', name: 'I485','selected':false }
                // ];

                let seItm = _.find(caseStatsFilterItems , { 'id':dbFilters['caseType']});
                if(seItm ){
                  this.updateData['filters']['caseType'] =seItm;
                }
                

                
               }
               //updateData.filters.caseType


            }

          })
          
         
         
          if(rx && _.has(rx ,'sorting')) {
            this.updateData['sorting'] =rx['sorting'];

          }
          if(this.checkProperty(rx ,'sortingList' ,'length')>0){
            this.sortingList =rx['sortingList'];
          }
          if(this.checkProperty(rx ,'sortingOrder' ,'id')){
           this.updateData['sortingOrder'] =rx['sortingOrder'];
          }

        if(this.checkProperty(this.widgetData['widgetData'] ,'sorting','path' )){
        let sortPath = this.widgetData['widgetData']['sorting']['path'];
        this.sortingPath=  _.find(this.sortingList ,{"id":sortPath});
        

        }


        if(this.checkProperty(this.widgetData ,'rowId' )){

          this.updateData['rowId'] = this.widgetData['rowId']
        }

        if(this.checkProperty(this.widgetData ,'columnId' )){

          this.updateData['columnId'] = this.widgetData['columnId']
        }
        if(this.checkProperty(this.widgetData , 'widgetData','_id' )){

          this.updateData['widgetId'] = this.widgetData['widgetData']['_id']
        }

        if(this.checkProperty(this.widgetData , 'widgetData','title' )){

          this.updateData['title'] = this.widgetData['widgetData']['title']
        }
        if(this.checkProperty(this.widgetData ,'widgetData','code' )){

        this.updateData['code'] = this.widgetData['widgetData']['code']
        }
        if(this.checkProperty(this.widgetData ,'widgetData','order' )){

        this.updateData['order'] = this.widgetData['widgetData']['order']
        }
        if(this.checkProperty(this.widgetData ,'widgetData','heightInPx' )){

        this.updateData['heightInPx'] = this.widgetData['widgetData']['heightInPx']
        }
        if(this.checkProperty(this.widgetData ,'widgetData','height' )){

          this.updateData['height'] = this.widgetData['widgetData']['height']
        }

        if( ['ACTION' ,'DEADLINE'].indexOf(this.widgetCode)>-1&&  ['TODO' , "CASES" ,"TASK" ,'UPDATES'].indexOf(this.tabName) >-1){
         if( this.checkProperty(rx ,'pagination' ,this.tabName)){
          

            if(rx['pagination'][this.tabName]['perpage'] >0){
              this.updateData['perpage'] = rx['pagination'][this.tabName]['perpage']; 
             this.updateData['pagination'] =rx['pagination'];
             this.updateData =_.cloneDeep(this.updateData);
            }
           
            if( this.checkProperty(this.widgetData ,'widgetData','pagination')){
              this.updateData['pagination'] =this.widgetData['widgetData']['pagination'];
           
              if(this.checkProperty(this.updateData['pagination'] ,this.tabName ,'perpage')>0){
             
                this.updateData['perpage'] = this.checkProperty(this.updateData['pagination'] ,this.tabName  ,'perpage');
              }

            }
             
            this.updateData =_.cloneDeep(this.updateData);
         }
         //pagination

        }else{
          if(this.checkProperty(this.widgetData ,'widgetData','perpage' )){

            this.updateData['perpage'] = this.widgetData['widgetData']['perpage']
          }

        }

        

        //sortOrderList sorting {'name':'ASC' ,'id':1},{'name':'DESC  order' ,'id':-1}
        if(this.checkProperty(this.widgetData['widgetData'] ,'sorting','order' ) >-1){
          
            if(this.checkProperty(this.widgetData['widgetData'] ,'sorting','order' ) ==1){
              this.updateData['sortingOrder'] = {'name':'ASC' ,'id':1}

            }
            if(this.checkProperty(this.widgetData['widgetData'] ,'sorting','order' ) ==-1){
              this.updateData['sortingOrder'] = {'name':'DESC  order' ,'id':-1}

            }
            

        }

        setTimeout(()=>{
          if( this.checkProperty(this.widgetData ,'widgetData' ,'filters' ) && this.checkProperty(this.widgetData['widgetData'] ,'filters' ,'companyIds')){
            
            this.updateData.filters.companyIds = this.widgetData['widgetData']['filters']['companyIds'];
            self.updateData['filters'] = _.cloneDeep(self.updateData['filters']);
          }

         //  alert(JSON.stringify(this.updateData.filters));
         // alert(JSON.stringify(this.updateData.filters));
          self.updateData  =_.cloneDeep(self.updateData);
        },200)
        this.updateData  =_.cloneDeep(this.updateData);
         
         // this.initData();
           

        })
        .catch((err)=>{})

         },

       updatedDeadLineRange(val){
        
        

        if (  val["startDate"] &&  val["startDate"] != "" && val["endDate"] != "" &&  val["endDate"] ) {
           let startDate = moment(val["startDate"]).format('YYYY-MM-DD');
           let endData = moment(val["endDate"]).format('YYYY-MM-DD');
          if(this.tabName=='CASES' || (this.tabName=='TODO' && ['DEADLINE'].indexOf(this.widgetCode)>-1)){
              
              this.updateData['filters']['CASES']['deadlineDateRange'] =[startDate ,endData];
              this.updateData['filters']['CASES']['dueDateRange'] =[startDate ,endData];
               this.updateData =_.cloneDeep(this.updateData);
          }else if(this.tabName=='TASK'){

              this.updateData['filters']['TASK']['deadlineDateRange'] =[startDate ,endData];
              this.updateData['filters']['TASK']['dueDateRange'] =[startDate ,endData];
              this.updateData =_.cloneDeep(this.updateData);
          }

          

        }
      },

      resetFilters(){
        this.resetSelecteddeadLineDateRange();
        this.resetSelectedCreatedDateRange();
        //getWidgetFilterMasterData
        this.sortingList =[];
        let postData ={
          code:''
        }
        
         postData['code'] =  this.widgetCode;
        this.$store.dispatch('getWidgetFilterMasterData' ,postData)
        .then((rx)=>{
               
          if(rx && _.has(rx ,'filters')) {
          let keys =Object.keys(rx['filters']);

         if(keys.indexOf(this.tabName)>-1){
           
              let tabFilter = rx[this.tabName]
              this.updateData['filters'][this.tabName] = tabFilter;
            _forEach(tabFilter ,(fval ,fkey)=>{

                this.updateData['filters'][fkey] = fval;
            })
          }else{
           
            this.updateData['filters'] = rx['filters'];
            
          }
            

          }
          if(rx && _.has(rx ,'sorting')) {
            this.updateData['sorting'] =rx['sorting'];

          }
          if(this.checkProperty(rx ,'sortingList' ,'length')>0){
            this.sortingList =rx['sortingList'];
          }
          if(this.checkProperty(rx ,'sortingOrder' ,'id')){
           this.updateData['sortingOrder'] =rx['sortingOrder'];
          }
           if( ['ACTION' ,'DEADLINE'].indexOf(this.widgetCode)>-1&&  ['TODO' , "CASES" ,"TASK" ,'UPDATES'].indexOf(this.tabName) >-1){
            if( this.checkProperty(rx ,'pagination' ,this.tabName)){
          

            if(rx['pagination'][this.tabName]['perpage'] >0){
              this.updateData['perpage'] = rx['pagination'][this.tabName]['perpage']; 
              this.updateData['pagination'][this.tabName]['perpage'] =rx['pagination'];
              this.updateData =_.cloneDeep(this.updateData);
            }

             

           }

           }


          this.updateWidget();
        }).catch((err)=>{
           this.updateWidget();
        });
      },

       updatePeritioners(filterKeyName ='petitionerIds'){
        if(['MESSAGES'].indexOf(this.widgetCode)>-1 &&  (_.has(this.updateData ,'filters.'+filterKeyName)) ){
          this.updateData['filters']['petitionerIds'] =this.updateData['filters'][filterKeyName]
        }else if(_.has(this.updateData ,'filters.'+filterKeyName)){

        
         if(['ACTION' ,'DEADLINE'].indexOf(this.widgetCode)>-1 && this.checkProperty(this.updateData ,"filters" ,this.tabName)){
            this.updateData['filters'][this.tabName][filterKeyName] = this.updateData['filters'][filterKeyName];
          }
        }

       },
      

      resetSelecteddeadLineDateRange(){
        this.selected_deadLineDateRange = {"startDate":'', "endDate":''};
      },

      resetSelectedCreatedDateRange(){
        this.selected_createdDateRange = {"startDate":'', "endDate":''};
      },
      

      filterAssignedUsers(obj){
        setTimeout(()=>{

       
       
      
      // let seletedAssignedUsers =  this.seleted_assignedUsers.map((item)=>{return item._id});
      let seletedAssignedUsers =[];
      _.forEach(this.updateData['filters'].assignedToIds ,(item)=>{
        seletedAssignedUsers.push(item['id']);
      })
      
       let selected_watchedUsers =  this.updateData['filters']['assignedByIds'].map((item)=>{return item.id});

     
      this.internalUsers = _.filter(this.tempAssignedUsersList ,(item)=>{
        if(
          (seletedAssignedUsers.length>0 && seletedAssignedUsers.indexOf(item['_id'])>-1)
          ||(selected_watchedUsers.length>0 && selected_watchedUsers.indexOf(item['_id']) >-1)
          || ( this.checkProperty( this.getUserData ,'userId') == item['_id'])
          ){
        
          return false
        }else{
          return true
        }

      })
       } ,10)
       

      },

        getAssignedUsersList(text=''){
        let postData={
            filters:{
                title : text
            }
        };
        this.$store.dispatch("getList",{data: postData, path:"tasks/get-assigned-users"})
        .then((response)=>{
            this.internalUsers = response.map((item)=>{  return {"name":item["name"] , "id":item["_id"]  } });;;
            this.tempAssignedUsersList  = _.cloneDeep(this.internalUsers);
        })
        },

      getBranchList(){
        
        let postData ={
          "filters":{"title":"","createdDateRange":[],"statusList":[],"activeList":[]},
           //"getMasterData":true,
           "page":1,
           "perpage":250000,
           "sorting":{"path":"createdOn","order":-1}};
        this.$store.dispatch("getList" ,{ "data":postData,"path":"/branch/list"})
        .then((res)=>{
          let list = res.list
        
          this.branchList =list.map((item)=>{  return {"name":item["name"] , "id":item["_id"]  } });;
          
             
          //alert(JSON.stringify(res));
        })
        .catch((err)=>{
          this.branchList =[] ;
        })
      },

      updateSortingOrder(item){

        this.updateData['sortingOrder']  = item;
        if(_.has(item ,'id' )){
          this.updateData['sorting']['order'] = item['id'];


        }

      },
      updateSortingPath(item ){
        if(this.checkProperty(item ,'id')){
           this.updateData.sorting.path = item['id'];
        }
       
      },
      

     

        updateWidget(){
           this.$validator.validateAll().then((result)=>{
         
            if(result){
            
            this.widgetUpdating = true;
            let path ="/dashboard/update-widget-config";
            let postData = _.cloneDeep(this.updateData)
            if(['ACTION' ,'DEADLINE'].indexOf(this.widgetCode)>-1 && this.checkProperty(this.updateData ,"filters" ,this.tabName)){
                  _.forEach(this.updateData['filters'], (values , subKey)=>{
                    if(["TODO" ,"CASES",'TASK','UPDATES'].indexOf(subKey)<=-1){
                      postData['filters'][subKey] = values;
                       

                       if( ! _.has(postData['filters'] ,this.tabName )){

                        postData['filters'][this.tabName] ={  };

                       }
                       postData['filters'][this.tabName][subKey] =values;


                    }





                  })
        
                      if (
                  this.selected_createdDateRange["startDate"] &&
                  this.selected_createdDateRange["startDate"] != "" &&
                  this.selected_createdDateRange["endDate"] != "" &&
                  this.selected_createdDateRange["endDate"]
                ) {
                  postData['filters'][this.tabName]["createdDateRange"] = [
                    this.selected_createdDateRange["startDate"],
                    this.selected_createdDateRange["endDate"]
                  ];
                }else{
                  postData['filters'][this.tabName]["createdDateRange"]  =[];

                }
            }else{

              
                          if (
                      this.selected_createdDateRange["startDate"] &&
                      this.selected_createdDateRange["startDate"] != "" &&
                      this.selected_createdDateRange["endDate"] != "" &&
                      this.selected_createdDateRange["endDate"]
                    ) {

                        let startDate = moment(this.selected_createdDateRange["startDate"]).format("YYYY-MM-DD");
                        let endDate = moment(this.selected_createdDateRange["endDate"]).format("YYYY-MM-DD");
        
                      postData['filters']["createdDateRange"] = [startDate ,endDate   ];
                    }else{
                      postData['filters']["createdDateRange"]  =[];

                    }

            }

      //selected_deadLineDateRange
      if([ 'CASE_STATS_BY_BRANCH','CASE_BY_STATUS' ,'CASE_STATS_BY_STATUS'].indexOf(this.widgetCode)>-1){

         let key ="deadlineDateRange";
          postData['filters'][key] = [];

      

        if (
        this.selected_deadLineDateRange["startDate"] &&
        this.selected_deadLineDateRange["startDate"] != "" &&
        this.selected_deadLineDateRange["endDate"] != "" &&
        this.selected_deadLineDateRange["endDate"]
      ) {

         let startDate = moment(this.selected_deadLineDateRange["startDate"]).format("YYYY-MM-DD");
        let endDate = moment(this.selected_deadLineDateRange["endDate"]).format("YYYY-MM-DD");
       
        postData['filters'][key] = [ startDate,  endDate ];
        
        
      }
        }

        if(['ACTION' ,'DEADLINE'].indexOf(this.widgetCode)>-1){
               //(this.tabName=="TASK" || this.tabName=="CASES" )
           if (
        this.selected_deadLineDateRange["startDate"] &&
        this.selected_deadLineDateRange["startDate"] != "" &&
        this.selected_deadLineDateRange["endDate"] != "" &&
        this.selected_deadLineDateRange["endDate"]
      ) {
        let startDate = moment(this.selected_deadLineDateRange["startDate"]).format("YYYY-MM-DD");
        let endDate = moment(this.selected_deadLineDateRange["endDate"]).format("YYYY-MM-DD");
        postData['filters']['dueDateRange'] = [startDate,  endDate ];
        postData['filters']['deadlineDateRange'] = [startDate, endDate ];

        postData['filters'][this.tabName]['deadlineDateRange'] = postData['filters']['dueDateRange'];
        postData['filters'][this.tabName]['dueDateRange'] = postData['filters']['dueDateRange'];
      }
      

        }

        

      

              if(this.checkIsEditRow){ 
      
                  this.$store.dispatch("commonAction" ,{data:postData,'path':path})
                  .then((rx) =>{
                  
                    
                    this.widgetUpdating =false;
                      //this.showToster({message:rx.message,isError:false }); 
                      this.$emit("updatedFilter" ,postData)
                  

                  })
                  .catch((err) =>{
                      this.widgetUpdating =false;
                    this.showToster({message:err,isError:true }); 
                  
                  })
              }else{
                this.$emit("updatedFilter" ,postData);

              }
        }

           });
          
        },

      

        /*Get Task list Master Data*/
            getTaskAssignedUsersList(){
                    let postData={
                        filters:{
                            title : this.searchtxt
                        }
                    };
                    this.$store.dispatch("getList",{data: postData, path:"tasks/get-assigned-users"})
                    .then((response)=>{
                        
                        
                        this.taskAssignedusersList = response.map((item)=>{  return {"name":item["name"] , "id":item["_id"]  } });
                        
                    })
            },

            getPriorityIds(){
            this.$store.dispatch("getmasterdata","task_priority")
            .then((response)=>{
            this.taskPriorityList = response.map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });;

            })
            },

            getStatusIds(){
                this.$store.dispatch("getmasterdata","task_status")
            .then((response)=>{
                this.taskStatusList = response.map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });;;
            })
            },
            getTaskMasterData(){
                this.getStatusIds();
                this.getPriorityIds();
                this.getTaskAssignedUsersList();
            },
            /*Get Task list Master Data End*/

            /* get Client list filter master data   */

            getCompanyStatusList(){
            this.companySatusList =[];
            let postdata ={
                page:1,
                perpage: 1000,
                category: "company_status",

            };
            this.$store.dispatch("getMasterData" ,postdata)
            .then((res)=>{
            this.companySatusList = res['list'].map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });

            this.companySatusList = _.filter(this.companySatusList ,(item)=>{
            return [1,2,3,4].indexOf(item['id'])>-1;

            })

            })
            .catch(()=>{

            })


            },
            changedCountry(){

            if( this.updateData.filters.countryIds && _.has(this.updateData.filters.countryIds , "id")){
            this.masterData('states');
            }else{
            this.updateData.filters.stateIds =null 
            this.updateData.filters.locationIds =[]; 
            }

            },
            changedState(){

            this.locations =[];
            if( _.has(this.updateData.filters.stateIds , "id")){
            this.masterData('locations');
            }
            },
            //locationId
            changedCity(){

            if( _.has(this.updateData.filters.locationIds , "id")){
            //this.updateTenantData.address.locationId = this.updateTenantData.address.selectedCity['id'];
            this.masterData('locations');
            }

            },
            masterData(category="countries"){

            /*
            countries:[]
            states:[],
            locations:[],
            */
            let matcher ={};
            let postData = {
            matcher: matcher,
            page:1,
            perpage: 1000,
            category: category,

            };
            if(category =="states"){

            matcher = { "countryId": this.checkProperty(this.updateData.filters ,'countryIds' ,'id')}
            }
            if(category =="locations"){

            matcher = { "stateId": this.checkProperty(this.updateData.filters ,'stateIds' ,'id')  }
            }
            postData['matcher'] = matcher;

            this.$store.dispatch("getMasterData" , postData)
            .then((res)=>{
            //countries

            if(category == "countries"){

                this.countries = res['list'].map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });
                
                //alert(JSON.stringify(this.countries))
            }
            if(category =="states"){


                this.states= res['list'].map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });
                
                
                
            }
            if(category =="locations"){

                this.locations= res['list'].map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });
                
                
            }
            })
            .catch((err)=>{
            this[category] =[];

            })

            },


         /* get Client list filter master data  End */

         /*Support Tickets */

          getSupportPriorityList(){
            let postData = {
                matcher: {},
                page:1,
                perpage: 1000,
                category: 'priority',
            
            }
            this.$store
                .dispatch("getMasterData",postData)
                .then((response) => {
                
                this.supportPriorityList = response.list.map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });;
                });

          },
           getSupportTicketStatusList() {
      this.$store
        .dispatch("getmasterdata", "support_status")
        .then((response) => {
          this.supportTicketStatusList = response.map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });;
        }); 

       
          },
         /* Support Tickets End*/

         /* CASE_BY_STATUS  CASE_STATS_BY_STATUS*/
          getCaseStatusids() {
          

          this.$store
            .dispatch("get_petition_statusids")
            .then(response => {
              this.allCaseStatusids = response.map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });
            
            });
          },

        getVisaTypes(){
          let item ={
          matcher:{
              "searchString":'',
              getWorkFlowConfig:true
             // "petitionType":

          },   
          page:this.page,
          perpage: this.perpage,
          category: "petition_types",
         "sorting": {
            "path": "name",
            "order": 1
            }
          
        };

        this.$store
          .dispatch("getMasterData",item )
          .then(response => {
            this.visaTypes = response.list.map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });
           
          });
        },
        changedVisaType(item){


       
          
          this.all_subtypes = [];
         
         let typeKey = "typeIds";
          let subTypeKey = "subTypeIds";
         
         if( [ 'BENEFICIARY'].indexOf(this.widgetCode)>-1){
            typeKey = "petitionTypeIds";
            subTypeKey = "petitionSubTypeIds";
         }
          this.updateData.filters[typeKey] =item ;
          let alreadySelectedSubTypes = _.cloneDeep(this.updateData.filters[subTypeKey]);
          this.updateData.filters[subTypeKey] =[];

             let petitionTypes = [];
          if(this.checkProperty(this.updateData.filters[typeKey] ,'length')){
            petitionTypes = this.updateData.filters[typeKey].map((item)=>item['id'])
            this.updateData.filters[subTypeKey] = _.filter(alreadySelectedSubTypes ,(item)=>{
                return petitionTypes.indexOf(item['type'])>-1;

            });
          }
        
        
            this.getvisa_subtypes();

          
        },
        getvisa_subtypes() {
  
           let typeKey = "typeIds";
          let subTypeKey = "subTypeIds";
         
         if( [ 'BENEFICIARY'].indexOf(this.widgetCode)>-1){
            typeKey = "petitionTypeIds";
            subTypeKey = "petitionSubTypeIds";
         }

          let petitionTypes = [];
       if(this.checkProperty(this.updateData.filters[typeKey] ,'length')){
         petitionTypes = this.updateData.filters[typeKey].map((item)=>item['id'])
       }
          if( this.updateData.filters[typeKey] && _.has( this.updateData.filters[typeKey],"id") || this.checkProperty(petitionTypes ,'length') >0 ){
      
      
          
          let item = {
            matcher: {
              searchString: '',
              petitionType:0,
              getWorkFlowConfig: false,
              petitionTypes:[]
            },
            page: 1,
            perpage: 1000,
            category: "petition_sub_types",
            "sorting": {
                "path": "name",
                "order": 1
                }
          };
          if(this.checkProperty(petitionTypes ,'length') >0){
            item['matcher']['petitionTypes'] = petitionTypes;
          }else if( this.checkProperty(this.updateData.filters ,typeKey,'id') >0){
             item['matcher']['petitionType'] = parseInt( this.updateData.filters[typeKey]['id']);
          }else{
            return false;

          }
          

          this.$store.dispatch("getMasterData", item).then((response) => {
            this.all_subtypes = response.list.map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });
          
          });
          }
        },
         get_peritioners() {

     
           let self =this;
     //petitioner_list_for_tenant_users

       let item ={
          page:1,
          perpage: 10000,
          category: "petitioner_list_for_tenant_users",
          matcher:{
            "searchString":this.peritioners_search_value,
          
          },
          "sorting": {
            "path": "name",
            "order": 1
            }
                      
        };
        if([51].indexOf(this.getUserRoleId)>-1){
          item['category'] = "petitioner_list_for_beneficaries"
        }

  
        this.$store.dispatch("getMasterData", item).then(response => {
         
          this.all_peritioners =response.list.map((item)=>{  return {"name":item["name"] , "id":item["_id"]  } });
        //updateData.filters.companyIds
        //updateData.filters.petitionerIds
       
        

        });
        },
        
        /*CASE_BY_STATUS CASE_STATS_BY_STATUS END*/

        /* BENEFICIARY Start*/
      getAllUserstatusids() {
        let postData = {
          page:1,
          perpage: 10000,
          category: "user_status",
          // tenantId: "5db7d79d6032453bd060ed9c",
        }

        this.$store.dispatch("getMasterData", postData).then(response => {
          let list  =response.list.map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });
        this.allUserStatusids =  _.filter(list,function(i){
        return i['id']!=1;
        });
        });
      },
        /* BENEFICIARY End*/

        /*LCA */
     getLcaStatusList() {
      this.$store
        .dispatch("getmasterdata", "lca_inventory_status")
        .then(response => {
          this.allLcaStatuses = response.map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });;

          this.allLcaStatuses = _.filter(this.allLcaStatuses ,(item)=>{
             return [1,2,3,4].indexOf(item['id'])>-1;
          })
         
        });
    },

    
     getLcsocList() {
      let query = {};
            query["page"] = 1;
            query["perpage"] = 10000;
            query["matcher"] = {};
            query["category"] = "soc_codes";
            query["sorting"] = this.sortKey;

      this.$store
        .dispatch("getMasterData", query)
        .then((response) => {
          this.masterSocList = response['list'].map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });;

        
          //alert(this.perpage);
        })
        .catch(() => {
          this.masterSocList = [];
         
        });
    },

    /*Invoice */
    getInvoiceStatusList(){

       this.$store
        .dispatch("getmasterdata", "invoice_status")
        .then(response => {
          this.allInvoiceStatusList = response.map((item)=>{  return {"name":item["name"] , "id":item["id"]  } });;
          
         
        });

    },

    peritioners_search_fun(searchValue) {
      this.peritioners_search_value = searchValue;
      this.get_peritioners();
    },
    premiumProcessChanged(){

      this.updateData.filters.premiumProcessing =[]; 
      if(this.updateData.filters.premiumProcess){
         this.updateData.filters.premiumProcessing=[{name:'Enabled' ,id:true }]; 
      }
    },




    },
    created() {

    },
     mounted() {
      this.allCaseTypes = this.getstatsCaseTypes();
      setTimeout(() =>{
            
            if(this.checkProperty(this.widgetData , 'widgetData','code' )){
            
              this.widgetCode =this.checkProperty(this.widgetData ,'widgetData' ,'code' );
                
             

              if(['TASK'].indexOf( this.widgetCode)>-1){
                this.getTaskMasterData();
              }
              if(['CLIENT'].indexOf( this.widgetCode)>-1){
                

                 this.getCompanyStatusList();
                 
                 
              }
               if(['SUPPORT_TICKET'].indexOf( this.widgetCode)>-1){
                 this.getSupportTicketStatusList()
                 this.getSupportPriorityList();
              }


             if([ 'CASE_SIGN_STATS', 'CURRENT_STATUS_OF_CASE','ACTION','UPDATES', 'DEADLINE','PENDING_CASE_STATS','CASE_STATS_BY_BRANCH' ,'CASE_BY_STATUS' ,'CASE_STATS_BY_STATUS'].indexOf( this.widgetCode)>-1){
              this.getCaseStatusids();
              this.getVisaTypes();
              this.get_peritioners();
              this.getBranchList();
              this.getAssignedUsersList();
              
                       

             }
             if('MESSAGES'==this.widgetCode){
              this.getVisaTypes();
              this.get_peritioners();

             }

             if(['BENEFICIARY' ].indexOf( this.widgetCode)>-1){
                  this.getAllUserstatusids();
                  this.getVisaTypes();
                  this.get_peritioners();
             }


             if(['LCA' ].indexOf( this.widgetCode)>-1){
                  this. getLcaStatusList();
                  this.get_peritioners();
                  this.getLcsocList();
             }

             if(['INVOICE' ].indexOf( this.widgetCode)>-1){
                  this. getInvoiceStatusList();
                   this.get_peritioners();
                  this.getBranchList();
                  
             }

            
            this.getwidgetFilters();


               if([ 'LCA' ,'CASE_STATS_BY_BRANCH','CASE_BY_STATUS',"CASE_STATS_BY_STATUS",'CLIENT'].indexOf( this.widgetCode)>-1){
                    setTimeout(()=>{
                        
                          this.masterData("countries");
                          this.masterData("states");
                          this.masterData("locations");
                          this.getvisa_subtypes();
                            if(this.checkProperty(this.widgetData , 'widgetData','filters' )){
                               
                                if(this.checkProperty(this.widgetData['widgetData']['filters'] ,'deadlineDateRange' ,'length' ) >1){

                                 let startDate = this.widgetData['widgetData']['filters']['deadlineDateRange'][0];
                                  let endDate = this.widgetData['widgetData']['filters']['deadlineDateRange'][1];
                                   startDate =moment(startDate)
                                    endDate =moment(endDate)
                                   this.updateData['filters']['deadlineDateRange'] = [ startDate,endDate ]
                                   this.selected_deadLineDateRange["startDate"] =startDate
                                  this.selected_deadLineDateRange["endDate"] =endDate;
                                   

                                }
                            
                             
                            }
                        

                      } )
               }

              // dueDateRange
              if([ 'DEADLINE','ACTION' ].indexOf( this.widgetCode)>-1){
                    setTimeout(()=>{
                       this.getvisa_subtypes();
                       let  tab =this.tabName;
                            if(this.checkProperty(this.widgetData , 'widgetData','filters' )){
                              if(this.checkProperty(this.widgetData['widgetData']['filters'] ,tab  )){
                                if(this.checkProperty(this.widgetData['widgetData']['filters'] ,tab ,'dueDateRange'  )){

                                  if(this.checkProperty(this.widgetData['widgetData']['filters'][tab] ,'dueDateRange' ,'length'  )>0){

                                 let startDate = this.widgetData['widgetData']['filters'][tab]['dueDateRange'][0];
                                  let endDate = this.widgetData['widgetData']['filters'][tab]['dueDateRange'][1];
                                   startDate =moment(startDate)
                                    endDate =moment(endDate)
                                   this.updateData['filters']['deadlineDateRange'] = [ startDate,endDate ]
                                   this.selected_deadLineDateRange["startDate"] =startDate
                                  this.selected_deadLineDateRange["endDate"] =endDate;
                                   

                                }

                                }

                              }

                            }

                    } ,10)
              }

           

              //widgetData['filters']['caseType']
                

              
            }

            //selected_createdDateRange

            if(this.checkProperty(this.widgetData , 'widgetData','filters' )){

              if(['ACTION' ,'DEADLINE'].indexOf(this.widgetCode)>-1){
                if(this.checkProperty(this.widgetData['widgetData']['filters'] ,this.tabName)){

                   if(this.checkProperty(this.widgetData['widgetData']['filters'][this.tabName] ,'createdDateRange' ,'length' ) >1){

                  let startDate = this.widgetData['widgetData']['filters'][this.tabName]['createdDateRange'][0];
                  let endDate = this.widgetData['widgetData']['filters'][this.tabName]['createdDateRange'][1];
                    startDate =moment(startDate)
                    endDate =moment(endDate)
                    this.updateData['filters']['createdDateRange'] = [ startDate,endDate ]
                    this.selected_createdDateRange["startDate"] =startDate
                    this.selected_createdDateRange["endDate"] =endDate;
                    

                }


                }

              }else{

                 if(this.checkProperty(this.widgetData['widgetData']['filters'] ,'createdDateRange' ,'length' ) >1){

                  let startDate = this.widgetData['widgetData']['filters']['createdDateRange'][0];
                  let endDate = this.widgetData['widgetData']['filters']['createdDateRange'][1];
                    startDate =moment(startDate)
                    endDate =moment(endDate)
                    this.updateData['filters']['createdDateRange'] = [ startDate,endDate ]
                    this.selected_createdDateRange["startDate"] =startDate
                    this.selected_createdDateRange["endDate"] =endDate;
                    

                }


              }
                
               

              
            }
             setTimeout(() =>{

              if(this.checkProperty(this.widgetData['widgetData'] ,'sorting' )){
                  
                   this.updateData['sorting'] = this.checkProperty(this.widgetData['widgetData'] ,'sorting' ) 
                }

              if(this.checkProperty(this.widgetData['widgetData'] ,'sorting' )){

              if(this.checkProperty(this.widgetData['widgetData'] ,'sorting','order' ) ==1){
              this.updateData['sortingOrder'] = {'name':'ASC' ,'id':1}

              }
              if(this.checkProperty(this.widgetData['widgetData'] ,'sorting','order' ) ==-1){
              this.updateData['sortingOrder'] = {'name':'DESC' ,'id':-1}

              }

              


              }

            })
          
            });

     },
     props: { 
      tabName:'',
      columnId:'',
       rowId:'',
       widgetData:null,
        
     },
     computed:{
      checkDeadLineDateRange(){

          if (
                  this.selected_deadLineDateRange["startDate"] &&
                  this.selected_deadLineDateRange["startDate"] != "" &&
                  this.selected_deadLineDateRange["endDate"] != "" &&
                  this.selected_deadLineDateRange["endDate"]
                ) {
                  return true;
                }else{
                  return false;
                }

      }, 
      checkCreatedRateRange(){
          if (
                  this.selected_createdDateRange["startDate"] &&
                  this.selected_createdDateRange["startDate"] != "" &&
                  this.selected_createdDateRange["endDate"] != "" &&
                  this.selected_createdDateRange["endDate"]
                ) {
                  return true;
                }else{
                  return false;
                }
      },
      checkTitle(){
         return this.updateData.title.trim() =='';
      } 
     }

}
</script>     