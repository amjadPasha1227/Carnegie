<template>
<div class="widget-task-list">

    <div class="task-details cursor" @click="goToPageDetails('/ticket-details/'+checkProperty( itemData,'_id'))" >
      <!----  <h4>Case Submitted dfsdfdsf</h4>-->
        <p>{{checkProperty( itemData,'subject')}}</p>
       
        <ul> 
            <li v-if="checkProperty( itemData,'createdByDetails' ,'name')">{{checkProperty( itemData,'createdByDetails' ,'name')}} <span v-if="checkProperty( itemData,'createdByDetails' ,'roleName')">{{checkProperty( itemData,'createdByDetails' ,'roleName')}}</span></li>
            <li v-if="checkProperty( itemData,'createdOn')">{{checkProperty( itemData,'createdOn') | formatDate}}  <span></span></li>
        </ul>
    </div>
    <div class="task-status" >

        <ul >

        <li v-if="checkProperty( itemData,'statusDetails' ,'name')" >
            <span class="statusspan"
            
               v-bind:class="{
                    'status_created': checkProperty(itemData ,'statusDetails','id') == 1,
                    'status_submited': checkProperty(itemData ,'statusDetails','id') == 2,
                    'status_inProcess': checkProperty(itemData ,'statusDetails','id') == 3,
                    'status_waiting': checkProperty(itemData ,'statusDetails','id') == 4,
                    'status_ready_for_filing': checkProperty(itemData ,'statusDetails','id') == 5,
                    'status_sent_for_signatures': checkProperty(itemData ,'statusDetails','id') == 6,
                    'staus_filed_with_USCIS': checkProperty(itemData ,'statusDetails','id') == 7,
                    'Status_received_by_USCIS': checkProperty(itemData ,'statusDetails','id') == 8,
                    'status_approved': checkProperty(itemData ,'statusDetails','id') == 9,
                    'status_denied': checkProperty(itemData ,'statusDetails','id') == 10,
                    'RFE_Received': ['11',11].indexOf(checkProperty(itemData ,'statusDetails','id')) >-1,
                    'response_to_RFE_Filed': checkProperty(itemData ,'statusDetails','id') == 12,
                    'response_to_RFE_Received': checkProperty(itemData ,'statusDetails','id') == 13,
                    'status_withdrawn': checkProperty(itemData ,'statusDetails','id') == 14,
                    ' ': checkProperty(itemData ,'statusDetails','id') == 15
                  }"
            
            >{{checkProperty( itemData,'statusDetails' ,'name')}}</span>
                
        </li>
            <!---
            <li>
            <a href="#" class="approve-btn"></a>
            </li>
            <li>
            <a href="#" class="close-btn"></a>
            </li>
            <li>
            <a href="#" class="upload-btn"></a>
            </li>
            -->
        </ul>
        <p  v-if="checkProperty( itemData,'updatedOn')" class="task-timing"> {{ checkProperty( itemData,'updatedOn') | timeago}}</p>
    </div>
</div>                  

</template>
<script>
    export default {
     name:'caseByStatus',
     props: {
        widgetData:null,
        itemData:null
     }
    
    
    }
    </script>