<template>
<div>

   <template v-if="viewType=='LIST' ">

      <template v-for="(itemData ,itmIndex) in widgetsItems['data']" >
          <div class="widget-task-list" :key="itmIndex" >
            <!-- <div class="task-thumbnail">
                <figure><img src="@/assets/images/check-mark.png"></figure>
            </div> -->
          
            <div class="task-details cursor" @click="detailsNavigate(itemData ,'CASE_DETAILS')">
              <h4></h4>
              <p v-on:click.stop.prevent="detailsNavigate(itemData ,'CASE_DETAILS')"  >{{checkProperty( itemData,'caseNo')}}</p>
              <ul>
                <li v-if="checkProperty( itemData,'typeDetails' ,'name')">
                <span v-on:click.stop.prevent="detailsNavigate(itemData ,'CASE_LIST' ,'typeIds')" >
                {{checkProperty( itemData,'typeDetails' ,'name')}}
                </span>
                
                
                 <span v-on:click.stop.prevent="detailsNavigate(itemData ,'CASE_LIST' ,'subTypeIds')" v-if="checkProperty( itemData,'subTypeDetails' ,'name')">
                 ({{checkProperty( itemData,'subTypeDetails' ,'name')}})
                 </span>
                 </li>
                

                <li v-if="checkProperty( itemData,'petitionerDetails' ,'name')" class="cursor" v-on:click.stop.prevent="detailsNavigate(itemData ,'CASE_LIST','petitionerIds' )">
                {{checkProperty( itemData,'petitionerDetails' ,'name')}} <span>(Petitioner)</span>
                
                </li>
                <li class="cursor" v-on:click.stop.prevent="detailsNavigate(itemData ,'CASE_LIST','beneficiaryIds' )"
                v-if="checkProperty( itemData,'beneficiaryDetails' ,'name')" >
                
                {{checkProperty( itemData,'beneficiaryDetails' ,'name')}} <span>(Beneficiary)</span></li>
              </ul>
            </div>
            <div class="task-status" >
            
              <ul>

                <li  v-on:click.stop.prevent="detailsNavigate(itemData ,'CASE_LIST','statusIds' )" v-if="checkProperty( itemData,'statusDetails' ,'name')" >
                <span class="statusspan cursor"
                 v-on:click.stop.prevent="detailsNavigate(itemData ,'CASE_LIST','statusIds' )"
                  v-bind:class="{
                  'status_created': checkProperty(itemData ,'statusDetails','id') == 1,
                  'status_submited': checkProperty(itemData ,'statusDetails','id') == 2,
                  'status_inProcess': checkProperty(itemData ,'statusDetails','id') == 3,
                  'status_waiting': checkProperty(itemData ,'statusDetails','id') == 4,
                  'status_ready_for_filing': checkProperty(itemData ,'statusDetails','id') == 5,
                  'status_sent_for_signatures': checkProperty(itemData ,'statusDetails','id') == 6,
                  'staus_filed_with_USCIS': checkProperty(itemData ,'statusDetails','id') == 7,
                  'status_ready_for_filing': checkProperty(itemData ,'statusDetails','id') == 8,
                  'status_sent_for_signatures': checkProperty(itemData ,'statusDetails','id') == 9,
                  'status_denied': checkProperty(itemData ,'statusDetails','id') == 10,
                  'RFE_Received': ['11',11].indexOf(checkProperty(itemData ,'statusDetails','id')) >-1,
                  'status_submited-USCIS': checkProperty(itemData ,'statusDetails','id') == 12,
                  'response_to_RFE_Received': checkProperty(itemData ,'statusDetails','id') == 13,
                  'status_jobdescription': checkProperty(itemData ,'statusDetails','id') == 14,
                  'status_pwd_filed': checkProperty(itemData ,'statusDetails','id') == 15,
                  'status_pwd_response': checkProperty(itemData ,'statusDetails','id') == 16,
                  'staus_advertisements': checkProperty(itemData ,'statusDetails','id') == 17,
                  'staus_filed_with_USCIS': checkProperty(itemData ,'statusDetails','id') == 18,
                  'Status_received_by_USCIS': checkProperty(itemData ,'statusDetails','id') == 19,
                  'Perm_drft_approved': checkProperty(itemData ,'statusDetails','id') == 20,
                  'Perm_submited_dol': checkProperty(itemData ,'statusDetails','id') == 21,
                  'status_approved': checkProperty(itemData ,'statusDetails','id') == 22,
                  'status_denied': checkProperty(itemData ,'statusDetails','id') == 23,
                  'RFE_Received': checkProperty(itemData ,'statusDetails','id') == 24,
                  'notice_supervisory_audit': checkProperty(itemData ,'statusDetails','id') == 27,
                  'status_supervisory_audit': checkProperty(itemData ,'statusDetails','id') == 28,
                  'status_withdrawn': checkProperty(itemData ,'statusDetails','id') == 14,
                  'status_withdrawn': checkProperty(itemData ,'statusDetails','id') == 31,
                  ' ': checkProperty(itemData ,'statusDetails','id') == 15
                }"
                
                >{{checkProperty( itemData,'statusDetails' ,'name')}}</span>
                    
                </li>
                <!---- statusDetails
                  class="{
                        'status_created': checkProperty(itemData ,'statusDetails','id') == 1,
                        'status_submited': checkProperty(itemData ,'statusDetails','id') == 2,
                        'status_inProcess': checkProperty(itemData ,'statusDetails','id') == 3,
                        'status_waiting': checkProperty(itemData ,'statusDetails','id') == 4,
                        'status_ready_for_filing': checkProperty(itemData ,'statusDetails','id') == 5,
                        'status_sent_for_signatures': checkProperty(itemData ,'statusDetails','id') == 6,
                        'staus_filed_with_USCIS': checkProperty(itemData ,'statusDetails','id') == 7,
                        'Status_received_by_USCIS': checkProperty(itemData ,'statusDetails','id') == 8,
                        'status_approved': checkProperty(itemData ,'statusDetails','id') == 9,
                        'status_denied': checkProperty(itemData ,'statusDetails','id') == 10,
                        'RFE_Received': ['11',11].indexOf(checkProperty(itemData ,'statusDetails','id')) >-1,
                        'response_to_RFE_Filed': checkProperty(itemData ,'statusDetails','id') == 12,
                        'response_to_RFE_Received': checkProperty(itemData ,'statusDetails','id') == 13,
                        'status_approved': checkProperty(itemData ,'statusDetails','id') == 22,
                        'status_withdrawn': checkProperty(itemData ,'statusDetails','id') == 14,
                        ' ': checkProperty(itemData ,'statusDetails','id') == 15
                      }"
                <li>
                
                  <a href="#" class="approve-btn"></a>
                </li>
                <li>
                  <a href="#" class="close-btn"></a>
                </li>
                <li>
                  <a href="#" class="upload-btn"></a>
                </li> 
                -->
              </ul>
              <p  v-if="checkProperty( itemData,'updatedOn')" class="task-timing"> {{ checkProperty( itemData,'updatedOn') | timeago}}</p>
            </div>
          </div>
      </template>    
    </template>
    <template v-else> 
    

    <div class="graph_cnt">
   
      <div>
        <div
          v-show="statusCount > 0 && !loading && wallsLoaded"
          :id="chartDivId"
          style="height: 250px"
        ></div>
        <ul class="chart_legends" v-show="statusCount > 0 && !loading && wallsLoaded">
          <template v-for="(cData, ind) in chartData">
            <li  :key="ind"
             @click=" detailsNavigate(cData ,'CASE_LIST' ,'cahartstatusIds')"
              class="cursor"
            >
            
              <p><span
              
               v-bind:class="{
                  'status_created': checkProperty(cData ,'statusId') == 1,
                  'status_submited': checkProperty(cData ,'statusId') == 2,
                  'status_inProcess': checkProperty(cData ,'statusId') == 3,
                  'status_waiting': checkProperty(cData ,'statusId') == 4,
                  'status_ready_for_filing':[5,8].indexOf( checkProperty(cData ,'statusId'))>-1,
                  'status_sent_for_signatures': [6,9].indexOf( checkProperty(cData ,'statusId'))>-1,
                  
                  'RFE_Received': ['11',11 ,24].indexOf(checkProperty(cData ,'statusId')) >-1,
                  'status_submited-USCIS': checkProperty(cData ,'statusId') == 12,
                  'response_to_RFE_Received': checkProperty(cData ,'statusId') == 13,
                  'status_jobdescription': checkProperty(cData ,'statusId') == 14,
                  'status_pwd_filed': checkProperty(cData ,'statusId') == 15,
                  'status_pwd_response': checkProperty(cData ,'statusId') == 16,
                  'staus_advertisements': checkProperty(cData ,'statusId') == 17,
                  'staus_filed_with_USCIS':[18,7] .indexOf(checkProperty(cData ,'statusId')) >-1,
                  'Status_received_by_USCIS': checkProperty(cData ,'statusId') == 19,
                  'Perm_drft_approved': checkProperty(cData ,'statusId') == 20,
                  'Perm_submited_dol': checkProperty(cData ,'statusId') == 21,
                  'status_approved': checkProperty(cData ,'statusId') == 22,
                  'status_denied': [10,23].indexOf(checkProperty(cData ,'statusId')) >-1, 
                  
                  'notice_supervisory_audit': checkProperty(cData ,'statusId') == 27,
                  'status_supervisory_audit': checkProperty(cData ,'statusId') == 28,
                  'status_withdrawn': checkProperty(cData ,'statusId') == 14,
                  'status_withdrawn': checkProperty(cData ,'statusId') == 31,
                  ' ': checkProperty(cData ,'statusId') == 15,
                  
                  
                }"
              
              ></span> {{ cData.category }}</p>
            </li>
          </template>
          <!-- class="{
                        'status_created': checkProperty(cData ,'statusId') == 1,
                        'status_submited': checkProperty(cData ,'statusId') == 2,
                        'status_inProcess': checkProperty(cData ,'statusId') == 3,
                        'status_waiting': checkProperty(cData ,'statusId') == 4,
                        'status_ready_for_filing': checkProperty(cData ,'statusId') == 5,
                        'status_sent_for_signatures': checkProperty(cData ,'statusId') == 6,
                        'staus_filed_with_USCIS': checkProperty(cData ,'statusId') == 7,
                        'Status_received_by_USCIS': checkProperty(cData ,'statusId') == 8,
                        'status_approved': checkProperty(cData ,'statusId') == 9,
                        'status_denied': checkProperty(cData ,'statusId') == 10,
                        'RFE_Received': ['11',11].indexOf(checkProperty(cData ,'statusId')) >-1,
                        'response_to_RFE_Filed': checkProperty(cData ,'statusId') == 12,
                        'response_to_RFE_Received': checkProperty(cData ,'statusId') == 13,
                        'status_withdrawn': checkProperty(cData ,'statusId') == 14,
                        ' ': checkProperty(cData ,'statusId') == 15
                      }" -->
        </ul>

        <template v-if="!loading && statusCount <= 0">
           <NoDataFound  ref="NoDataFoundRef"  :loading="false"  heading="No Data"  type="support"  />
        </template>
      </div>
      

      <chartLoading v-if="loading || !wallsLoaded" />
    </div>
    
     </template>
</div>      

</template>
<script>
import NoDataFound from "@/views/common/noData.vue";
import DateRangePicker from "vue2-daterange-picker";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import VueApexCharts from "vue-apexcharts";
import Vue from "vue";
import moment from "moment";

import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import chartLoading from "@/views/wall/chartLoading.vue";
import DatePickerCustom from "@/views/common/_date_picker_custom.vue";
am4core.useTheme(am4themes_animated);

import { _ } from "core-js";
Vue.use(VueApexCharts);

Vue.component("apexchart", VueApexCharts);

export default {
 name:'caseByStatus',
 props: {
    widgetData:null,
    widgetsItems:null,
    viewType:{
        type:String,
        default:'LIST'
    }
 },
  components: {
    DateRangePicker,
    chartLoading,
    DatePickerCustom,
    NoDataFound,
  },
  data: function () {
    return {
       chartDivId :'cases-chart', 
      caseStatusList:[],
      wallsLoaded:true,     
      loading: true,
      isOpenDateFilter: false,
      filterText: "",
      chartData: [],
      selected_createdDateRange: ["", ""],
      autoApply: "",
      options: {
        labels: [],
        legend: {
          position: "top",
        },
      },
      series: [],
      statusCount: 0,
      allCaseTypes: [],
      selectedCaseTypes: null,

      allCaseSubTypes: [],
      selectedCaseSubTypes: [],
    };
  },

  mounted() {

    let postData = {
        "matcher": { 
          "searchString":"",
          "tenantId": "",
          "branchId": "",
          "getWorkFlowConfig": false,
          "getCasenoCodeConfig": false,
          "tenantCustomId": "",
          "petitionTypes": [],
          "getInactiveListAlso": false,
          "caseType": ""
          },
          "category": "case_status",
          "page": 1,
          "perpage": 250000,
          "sorting": {    
            "path": "name",
            "order": 1
          }
      }
      this.$store.dispatch("getMasterData",postData).then(response => {
          //alert(JSON.stringify(response))
           this.caseStatusList = response.list;
      })
    
    const d = new Date();
   let time = d.getTime();
    this.chartDivId ='cases-chart_'+time+'';
    setTimeout(()=>{
          this.getStats();
    })
    this.filterText = "";
  },
  created() {
    document.addEventListener("scroll", this.handleScroll);
  },
  destroyed() {
    document.removeEventListener("scroll", this.handleScroll);
  },
  methods: {
    detailsNavigate(item,cat='',fkey=''){ 
      if([15].indexOf(this.checkProperty(item ,'subTypeDetails','id'))>-1 ){
        if( cat=='CASE_DETAILS'){
          cat ="PERM_DETAILS"
        }else if( cat=='CASE_LIST'){
          cat ="PERM_LIST"
        }

      }

      this.navigateToDetails(item ,cat ,fkey);

      

    },
    handleScroll(event) {
      this.$refs["filter_menu"].dropdownVisible = false;
      // Any code to be executed when the window is scrolled
    },
    reloaStats(seleteddates) {
      this.selected_createdDateRange["startDate"] = seleteddates.startDate;
      this.selected_createdDateRange["endDate"] = seleteddates.endDate;
      this.getStats();
    },
    clear_filter() {
      this.selectedCaseTypes = [];
      this.selectedCaseSubTypes = [];
      this.selected_createdDateRange = [];
      this.filterText = "";
      this.$refs["filter_menu"].dropdownVisible = false;
      this.getStats();
    },
    togleDateFIlter() {
      this.isOpenDateFilter = this.isOpenDateFilter ? false : true;

      // if(this.isOpenDateFilter){
      //    alert(this.isOpenDateFilter)
      //     document.addEventListener("click", ()=>{
      //         this.isOpenDateFilter =false;
      //          alert(this.isOpenDateFilter +"FROM TRIGGRED")

      //     });
      // }
    },
    generateDate(type = "Today") {
      let startDate = moment().startOf("day").format("YYYY-MM-DD");
      let endDate = moment().endOf("day").format("YYYY-MM-DD");
      this.filterText = "Today";
      if (type == "Today") {
        startDate = moment().startOf("day").format("YYYY-MM-DD");
        endDate = moment().endOf("day").format("YYYY-MM-DD");
        this.selected_createdDateRange["startDate"] = startDate;
        this.selected_createdDateRange["endDate"] = endDate;
      } else if (type == "This Week") {
        this.filterText = "This Week";
        startDate = moment().startOf("week").format("YYYY-MM-DD");
        endDate = moment().endOf("week").format("YYYY-MM-DD");
        this.selected_createdDateRange["startDate"] = startDate;
        this.selected_createdDateRange["endDate"] = endDate;
      } else if (type == "This Month") {
        this.filterText = "This Month";
        startDate = moment().startOf("month").format("YYYY-MM-DD");
        endDate = moment().endOf("month").format("YYYY-MM-DD");
        this.selected_createdDateRange["startDate"] = startDate;
        this.selected_createdDateRange["endDate"] = endDate;
      } else if (type == "Custom_date") {
        startDate = this.selected_createdDateRange["startDate"];
        endDate = this.selected_createdDateRange["endDate"];
        startDate = moment(startDate).format("YYYY-MM-DD");
        endDate = moment(endDate).format("YYYY-MM-DD");

        this.filterText = startDate + " To " + endDate;
      }

      this.isOpenDateFilter = false;

      //  this.getStats();
    },
     
    initChart() {
      var chart = am4core.create(this.chartDivId, am4charts.PieChart3D);
      chart.logo.disabled = true;
      this.chartData=  _.shuffle(this.chartData)
      //chart.legend = new am4charts.Legend();

/*
      chart.colors.list = [
      am4core.color("#D2AEF5"),
      am4core.color("#d1f4a8"),
      am4core.color("#ff4560"),
      am4core.color("#A8CF8D"),
      am4core.color("#97D856"),
      am4core.color("#E6ADE6"),
      am4core.color("#ED957B"),
      am4core.color("#ccf4d4"),
      am4core.color("#F5DB9F"),
      am4core.color("#f887dc"),
      am4core.color("#96D0B3"),
      am4core.color("#989898"),
      am4core.color("#33226b"),
         

  ];
 */ 

      // Add data
      chart.data = this.chartData;
      /*[{
  "category": "white",
  "count": 501.9,
  "color": "red"
}, {
  "category": "red",
  "count": 301.9,
  "color": "yellow"
}, {
  "category": "orange",
  "count": 201.1,
  "color": "orange"
}, {
  "category": "green",
  "count": 165.8,
  "color": "green"
}, {
  "category": "blue",
  "count": 139.9,
  "color": "blue"
}];
*/
      //chart.contentHeight =320;
      //chart.contentWidth =500;

      //chart.width=200;
      chart.height = 250;
      // Add and configure Series
      var pieSeries = chart.series.push(new am4charts.PieSeries3D());
      pieSeries.dataFields.value = "count";
      pieSeries.dataFields.category = "category";
      pieSeries.innerRadius = am4core.percent(60);
      pieSeries.ticks.template.disabled = true;
      pieSeries.labels.template.disabled = true;

      // This is not working and produces an error
      // pieSeries.slices.template.adapter.add("fill", function (fill, target) {
      //     return target.dataItem.dataContext["color"];
      // });

      // var rgm = new am4core.RadialGradientModifier();
      // rgm.brightnesses.push(-0.8, -0.8, -0.5, 1, 1);
      // pieSeries.slices.template.fillModifier = rgm;
      // pieSeries.slices.template.strokeModifier = rgm;
      pieSeries.slices.template.strokeOpacity = 2;
      pieSeries.slices.template.strokeWidth = 1;
      pieSeries.slices.template.propertyFields.fill = "color";
      pieSeries.slices.template.propertyFields.isActive = "pulled";

      pieSeries.slices.template.cornerRadius = 6;
pieSeries.colors.step = 3;

pieSeries.hiddenState.properties.endAngle = -90;

      var _self = this;
      pieSeries.slices.template.events.on(
        "hit",
        function (ev) {
          let caseType = _.find(_self.caseStatusList ,{ "name":ev.target.dataItem.category} )
         // alert(JSON.stringify(_self.caseStatusList));
          
          let pet =  {
            name: "petitions",
           
          }
           
            
          if(caseType && _.has( caseType ,"id")){
            let matchers = {};
            matchers = Object.assign(matchers ,{'statusIds':[caseType['id']]});
            let matcherObj = {'matcher':matchers}
            const string = JSON.stringify(matcherObj)
         
          let encodedString = btoa(string) 
            
            pet =Object.assign(pet , { 'query': { 'filter': encodedString }  })
           }
         
          _self.$router.push(pet);
        },
        this
      );
      pieSeries.slices.template.adapter.add("fill", function(fill, target) {


      let dat = _.find( _self.chartData, {"category":target.dataItem.category} )
      if(dat && _.has(dat ,'color')){
      return dat['color']
      }else{
      return chart.colors.getIndex(target.dataItem.index);
      }



      });

    },

    getVisaTypes() {
      let item = {
        matcher: {
          searchString: "",
          getWorkFlowConfig: false,
          // "petitionType":
        },
        page: 1,
        perpage: 100000,
        category: "petition_types",
        sorting: {
          path: "name",
          order: 1,
        },
      };

      this.$store.dispatch("getMasterData", item).then((response) => {
        this.allCaseTypes = response.list;
      });
    },
    changedVisaType(item) {
      this.selectedCaseTypes = item;
      this.allCaseSubTypes = [];
      this.selectedCaseSubTypes = [];
      if (_.has(this.selectedCaseTypes, "id")) {
        this.getvisa_subtypes();
      }
      //  this.getStats();
    },
    getvisa_subtypes() {
      if (this.selectedCaseTypes && _.has(this.selectedCaseTypes, "id")) {
        let item = {
          matcher: {
            searchString: "",
            petitionType: parseInt(this.selectedCaseTypes["id"]),
            getWorkFlowConfig: false,
          },
          page: 1,
          perpage: 1000,
          category: "petition_sub_types",
          sorting: {
            path: "name",
            order: 1,
          },
        };

        this.$store.dispatch("getMasterData", item).then((response) => {
          this.allCaseSubTypes = response.list;
        });
      }
    },
    getStats() {
      
      //dashboard/get-stats
      let colors =this.getCaseColors();
      
     
      this.statusCount = 0;
      this.options["labels"] = [];
      this.series = [];
      this.chartData = [];
      this.loading = true;
     
       if(this.checkProperty(this.widgetsItems ,'data','length')>0){
            _.forEach(this.widgetsItems['data'] ,(item)=>{

                 if(this.checkProperty(this.widgetsItems ,'mData','length')>0 && this.checkProperty(item ,'statusId') >0){
                  item['statusId'] = parseInt(item['statusId']);
                 let roleData = _.find(this.widgetsItems['mData'] ,{"id":item['statusId']});

                 if(roleData && this.checkProperty(roleData ,'name')){

                 
                   
                    item = Object.assign(item ,{"category":roleData['name'] });
                  let  statusColor =_.find(colors ,{'id':item['statusId']});
                    if(statusColor && this.checkProperty(statusColor ,'backgroundColor')){
                        item = Object.assign(item ,{'color':''});
                        item['color'] = statusColor['backgroundColor']
                    }
                    this.statusCount = this.statusCount+item['count'];
                    this.chartData.push(item);


                 }

                }
            });
            this.chartData=  _.shuffle(this.chartData)
            this.loading =false;
            if( this.statusCount >0){
                 this.initChart();
            }else{
                 setTimeout(()=>{
                    this.updateLoading(false); 
                    setTimeout(()=>{ this.loading = false;  this.updateLoading(false);  } ,10)   
                } ,10)
            }
           

    }
          this.loading = false;
        
    },
  },


}
</script>