<template>
<div class="widget-task-list">

    <div class="task-details "  >
      
        <p class="d-flex align-items-center branch-title">
            <a v-on:click.stop.prevent="navigateToDetails(itemData, 'BRANCH_CASES' ,'typeIds')">{{checkProperty( itemData,'typeName')}}</a>
            <em>&nbsp;- <a v-on:click.stop.prevent="navigateToDetails(itemData, 'BRANCH_CASES' ,'subTypeIds')">{{checkProperty( itemData,'subTypeName')}}</a></em>
        </p>
        
        <ul>
            <li v-on:click.stop.prevent="navigateToDetails(itemData, 'BRANCH_CASES' ,'getActiveCases')"  v-if="checkProperty( itemData,'activeCount') >0">Active Cases: {{checkProperty( itemData,'activeCount')}}</li>
            <li v-on:click.stop.prevent="navigateToDetails(itemData, 'BRANCH_CASES' ,'getClosedCases')"  v-if="checkProperty( itemData,'closedCount') >0">Closed Cases: {{checkProperty( itemData,'closedCount')}} </li>
        </ul>

        <!-- <p v-on:click.stop.prevent="navigateToDetails(itemData, 'BRANCH_CASES' ,'getActiveCases')"  v-if="checkProperty( itemData,'activeCount') >0" >Active Count: {{checkProperty( itemData,'activeCount')}} </p>
        <p  v-on:click.stop.prevent="navigateToDetails(itemData, 'BRANCH_CASES' ,'getClosedCases')"  v-if="checkProperty( itemData,'closedCount') >0">Closed Count: {{checkProperty( itemData,'closedCount')}} </p>
            -->
       
    </div>
    <div class="task-status" >

        <ul >

        <li v-if="checkProperty( itemData,'statusDetails' ,'name')" >
            <span class="statusspan"
            
               v-bind:class="{
                    'status_created': checkProperty(itemData ,'statusDetails','id') == 1,
                    'status_submited': checkProperty(itemData ,'statusDetails','id') == 2,
                    'status_inProcess': checkProperty(itemData ,'statusDetails','id') == 3,
                    'status_waiting': checkProperty(itemData ,'statusDetails','id') == 4,
                    'status_ready_for_filing': checkProperty(itemData ,'statusDetails','id') == 5,
                    'status_sent_for_signatures': checkProperty(itemData ,'statusDetails','id') == 6,
                    'staus_filed_with_USCIS': checkProperty(itemData ,'statusDetails','id') == 7,
                    'Status_received_by_USCIS': checkProperty(itemData ,'statusDetails','id') == 8,
                    'status_approved': checkProperty(itemData ,'statusDetails','id') == 9,
                    'status_denied': checkProperty(itemData ,'statusDetails','id') == 10,
                    'RFE_Received': ['11',11].indexOf(checkProperty(itemData ,'statusDetails','id')) >-1,
                    'response_to_RFE_Filed': checkProperty(itemData ,'statusDetails','id') == 12,
                    'response_to_RFE_Received': checkProperty(itemData ,'statusDetails','id') == 13,
                    'status_withdrawn': checkProperty(itemData ,'statusDetails','id') == 14,
                    ' ': checkProperty(itemData ,'statusDetails','id') == 15
                  }"
            
            >{{checkProperty( itemData,'statusDetails' ,'name')}}</span>
                
            </li>
            <!---
            <li>
            <a href="#" class="approve-btn"></a>
            </li>
            <li>
            <a href="#" class="close-btn"></a>
            </li>
            <li>
            <a href="#" class="upload-btn"></a>
            </li>
            -->
        </ul>
        <p  v-if="checkProperty( itemData,'updatedOn')" class="task-timing"> {{ checkProperty( itemData,'updatedOn') | timeago}}</p>
    </div>
</div>                  

</template>
<script>
    export default {
     name:'caseByStatus',
     props: {
        widgetData:null,
        itemData:null
     }
    
    
    }
    </script>