<template>
  <div class="added-widgets">
    <div class="mycases-widgets" id="heightChange" :class="{'small' : (selectedHeight == 'small'), 'medium' : (selectedHeight == 'medium'),'large' : (selectedHeight == 'large') }">
      <div class="header">
        <div class="title">
          <h4>My Cases</h4>
        </div>
        <div class="widget-filters">
          <button class="filter_btn active"><em>To-Do</em><span>2</span></button>
          <button class="filter_btn"><em>Cases</em><span>21</span></button>
          <button class="filter_btn"><em>Tasks</em></button>
          <button class="filter_btn"><em>Updates</em></button>
        </div>
        <div class="actions">
          <ul>
            <li  @click="popupFilter=true"><figure><img src="@/assets/images/funnel.svg" alt="calendar-img" width="14" height="14"></figure></li>
            <li class="has-dropdown"><figure><more-horizontal-icon size="1.5x" class="custom-class" style="opacity: 0.6;"></more-horizontal-icon></figure>
            <div class="height-dropdown">
                <!-- <div class="height-section">
                  <span>Height</span>
                  <ul>
                   <li @click="setHeighet('small'); ">1x</li>
                    <li @click="setHeighet('medium');">1.5</li>
                    <li @click="setHeighet('large');">2x</li>
                  </ul>
                </div> -->
                <ul class="subdropdown">
                  <li><a><figure><img src="@/assets/images/duplication.png" alt="duplicate-img" width="15"></figure>Duplicate</a></li>
                  <li><a class="text-danger"><figure><img src="@/assets/images/delete.png" alt="trash-img" width="15"></figure>Delete</a></li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <VuePerfectScrollbar	
            ref="mainSidebarPs"	
            class="scroll-area--main-sidebar"	
            :settings="settings"	
            @ps-scroll-y="psSectionScroll"	
          >
          <div class="widget-content">
              <template v-if="checkProperty(widgetsItems ,'data' ,'length')>0 && !isListLoading">

                <div class="widget-cases-list"  v-for="(item ,itmIndex) in widgetsItems['data']" :key="itmIndex">
                  <div class="case-details">
                    <div class="case-info">
                      <p>H1B-ADMT-2022-10008 - <span>H-1B - Amendment</span></p>
                    </div>
                    <p class="case-status signature">Sent for Signatures</p>
                  </div>
                  <div class="case-admin-details">
                    <ul>
                      <li>BulBul Apps <span>(Petitioner)</span></li>
                      <li>Thomas V Allen, <span>(Admin)</span></li>
                    </ul>
                  </div>
                </div>
              </template>
               <template v-else>

               <NoDataFound
            ref="NoDataFoundRef"
            :loading="isListLoading"
            heading="No Data"
            type="support"
            />
                
              </template>


              <!-----

              <div class="widget-cases-list">
                <div class="case-details">
                  <div class="case-info">
                    <p>H1B-ADMT-2022-10008 - <span>New Employment - Change of Status</span></p>
                  </div>
                  <p class="case-status inprogress">In-Progress</p>
                </div>
                <div class="case-admin-details">
                  <ul>
                    <li>BulBul Apps <span>(Petitioner)</span></li>
                    <li>Thomas V Allen, <span>(Admin)</span></li>
                  </ul>
                </div>
              </div>
              <div class="widget-cases-list">
                <div class="case-details">
                  <div class="case-info">
                    <p>H1B-ADMT-2022-10008 - <span>H-1B - Amendment</span></p>
                  </div>
                  <p class="case-status created">Case Created</p>
                </div>
                <div class="case-admin-details">
                  <ul>
                    <li>BulBul Apps <span>(Petitioner)</span></li>
                    <li>Thomas V Allen, <span>(Admin)</span></li>
                  </ul>
                </div>
              </div>
              <div class="widget-cases-list">
                <div class="case-details">
                  <div class="case-info">
                    <p>H1B-ADMT-2022-10008 - <span>New Employment - Change of Status</span></p>
                  </div>
                  <p class="case-status approved">Case Approved</p>
                </div>
                <div class="case-admin-details">
                  <ul>
                    <li>BulBul Apps <span>(Petitioner)</span></li>
                    <li>Thomas V Allen, <span>(Admin)</span></li>
                  </ul>
                </div>
              </div>
              <div class="widget-cases-list">
                <div class="case-details">
                  <div class="case-info">
                    <p>H1B-ADMT-2022-10008 - <span>H-1B - Amendment</span></p>
                  </div>
                  <p class="case-status Qsubmitted">Questionnaire Submitted</p>
                </div>
                <div class="case-admin-details">
                  <ul>
                    <li>BulBul Apps <span>(Petitioner)</span></li>
                    <li>Thomas V Allen, <span>(Admin)</span></li>
                  </ul>
                </div>
              </div>
              <div class="widget-cases-list">
                <div class="case-details">
                  <div class="case-info">
                    <p>H1B-ADMT-2022-10008 - <span>New Employment - Change of Status</span></p>
                  </div>
                  <p class="case-status signature">Sent for Signatures</p>
                </div>
                <div class="case-admin-details">
                  <ul>
                    <li>BulBul Apps <span>(Petitioner)</span></li>
                    <li>Thomas V Allen, <span>(Admin)</span></li>
                  </ul>
                </div>
              </div>
              <div class="widget-cases-list">
                <div class="case-details">
                  <div class="case-info">
                    <p>H1B-ADMT-2022-10008 - <span>New Employment - Change of Status</span></p>
                  </div>
                  <p class="case-status filed">Case Filed with USCIS</p>
                </div>
                <div class="case-admin-details">
                  <ul>
                    <li>BulBul Apps <span>(Petitioner)</span></li>
                    <li>Thomas V Allen, <span>(Admin)</span></li>
                  </ul>
                </div>
              </div>
              -->
      </div>
          </VuePerfectScrollbar>
    </div>
    <vs-popup class="holamundo filter_modal"  title="" :active.sync="popupFilter">
      <div class="filter-header">
        <a href="#"><img src="@/assets/images/left-arrow.png" width="12" alt="left-arrow"></a>
        <div class="filter-title">
          <h4>Add Filters</h4>
        </div>
      </div>

      <div class="filter-content">
        <div class="input-filters">
          <div class="vx-row">
            <div class="vx-col w-1/2">
              <div class="w-full">
                    <label for="" class="form_label">Label</label>
                    <div class="vs-con-input">
                      <input type="text" class="filter-input">
                    </div>
              </div>
            </div>
            <div class="vx-col w-1/2">
              <div class="w-full">
                    <label for="" class="form_label">Label</label>
                    <div class="vs-con-input">
                      <input type="text" class="filter-input">
                    </div>
              </div>
            </div>
          </div>
          <div class="vx-row">
            <div class="vx-col w-1/2">
              <div class="w-full">
                    <label for="" class="form_label">Label</label>
                    <multiselect v-model="value" :options="options"></multiselect>
              </div>
            </div>
            <div class="vx-col w-1/2">
              <div class="w-full">
                    <label for="" class="form_label">Label</label>
                    <div>
                      <ul class="custom-radio">
                        <li>
                          <vs-radio v-model="primary">Primary</vs-radio>
                        </li>
                        <li>
                          <vs-radio v-model="primary">Primary</vs-radio>
                        </li>
                      </ul>
                    </div>
              </div>
            </div>
          </div>
        </div>
        <div class="input-actions">
          <p>Show tasks that are in multiple Lists more than once</p>
          <div class="switch">                  
            <vs-switch>
              <span slot="on"></span>
              <span slot="off"></span>
            </vs-switch>
          </div>
        </div>
        <div class="input-actions">
          <p>Include subtasks</p>
          <div class="switch">                  
            <vs-switch>
              <span slot="on"></span>
              <span slot="off"></span>
            </vs-switch>
          </div>
        </div>
        <div class="input-actions add-btn-section">
          <a href="#" class="add-widget-btn">Add Widget</a>
        </div>
      </div>
     
    </vs-popup> 
  </div>
</template>
 
 
<script>
 import VuePerfectScrollbar from "vue-perfect-scrollbar";
 import Multiselect from "vue-multiselect-inv";
 import { MoreHorizontalIcon } from 'vue-feather-icons'
import NoDataFound from "@/views/common/noData.vue";


  export default {
     props: { 
       columnId:'',
      rowId:'',
     widgetData:null ,
      wedgetHights:{
       
        "1X":'small',
        "1.5":"medium",
        "2X":"large"
      } 
   },
    components: {
      VuePerfectScrollbar,
      Multiselect,
      MoreHorizontalIcon,
      NoDataFound,
    },
    data: function () {
      return {
        popupFilter:false,
        value: null,
        options: [],
        primary:'',
        selectedHeight:'small',
        isListLoading:true,
        widgetsItems:null,
         settings: { 
        swipeEasing: false,
      },
      }
    },
     props: { 
    widgetData:null  
   },
    methods:{
        setHeighet(height='small'){
        
        this.selectedHeight=height
      },
      psSectionScroll(event){

      },
    getWigetsData(){
      this.isListLoading =true;
      this.widgetsItems =null;
      let path ="dashboard/get-widget-data";
      let postData ={
        categoryList:[],
        filters:{}
      };
      postData['categoryList'].push(this.checkProperty(this.widgetData ,"code"));
      if(this.checkProperty(this.widgetData ,"filters") ){
        postData['filters'] = this.checkProperty(this.widgetData ,"filters");
      }
       this.updateLoading(true); 
       this.$store.dispatch("commonAction" ,{data:postData,'path':path})
       
      .then((rx) =>{
      this.widgetsItems = rx[this.checkProperty(this.widgetData ,"code")];
      this.isListLoading =false;
      setTimeout(()=>{
          this.updateLoading(false); 
          setTimeout(()=>{ this.isListLoading = false;  this.updateLoading(false);  } ,10)   
      } ,10)
       

      })
      .catch((err) =>{
         this.isListLoading =false;
        setTimeout(()=>{
              this.updateLoading(false); 
              setTimeout(()=>{ this.isListLoading = false;  this.updateLoading(false);  } ,10)   
          } ,10)
         
       
       })
    }
  },
   mounted() {
   
    setTimeout(() =>{
      if(this.checkProperty(this.widgetData ,"code") ){
         if(this.checkProperty(this.wedgetHights , this.checkProperty(this.widgetData ,'height'))){
           this.setHeighet(this.wedgetHights[this.widgetData['height'] ]);
        }
        this.getWigetsData();
      }

    })

   }

  

  
  
  
};
</script>
