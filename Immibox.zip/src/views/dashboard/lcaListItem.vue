



<template>
<div>
    <template v-if="viewType=='LIST' ">

        <template v-for="(itemData ,itmIndex) in widgetsItems['data']" >

                <div class="widget-task-list" :key="itmIndex">

                     <div class="task-details cursor" @click="gottPage(itemData);" >
      <!----  <h4>Case Submitted dfsdfdsf</h4>-->
        <p>{{checkProperty( itemData,'caseNo')}}</p>
        
        
        

         <ul >
                <li v-if="checkProperty( itemData['petitionDetails'],'typeDetails' ,'name')">
                <span  >
                {{checkProperty( itemData['petitionDetails'],'typeDetails' ,'name')}}
                </span>
                
                
                 <span  v-if="checkProperty( itemData['petitionDetails'],'subTypeDetails' ,'name')">
                 ({{checkProperty( itemData['petitionDetails'],'subTypeDetails' ,'name')}})
                 </span>
                 
                 </li>
                

                <li v-if="checkProperty( itemData,'petitionerDetails' ,'name')" class="cursor" >
                {{checkProperty( itemData,'petitionerDetails' ,'name')}} <span>(Petitioner)</span>
                
                </li>
                <li class="cursor" 
                v-if="checkProperty( itemData,'beneficiaryDetails' ,'name')" >
                
                {{checkProperty( itemData,'beneficiaryDetails' ,'name')}} <span>(Beneficiary)</span></li>
              </ul>



    </div>
    <div class="task-status" >

        <ul >

        <li class="cursor" v-on:click.stop.prevent="navigateToDetails({'statusDetails':{'id':checkProperty(itemData ,'statusId')}} ,'LCA_LIST','statusIds' )" v-if="checkProperty( itemData,'statusDetails' ,'name')"  >
            <span class="statusspan cursor"
            
               v-bind:class="{
                  'lca_created': checkProperty(itemData ,'statusId') == 1,
                  'lca_filed': checkProperty(itemData ,'statusId') == 2,
                  'lca_certified': checkProperty(itemData ,'statusId') == 3,
                  'lca_denied': checkProperty(itemData ,'statusId') == 4,
                  'lca_request_for_withdrawal': checkProperty(itemData ,'statusId') == 5,
                  'lca_withdrawn': checkProperty(itemData ,'statusId') == 6,
                  'lca_expired': checkProperty(itemData ,'statusId') == 7,
                    'Status_received_by_USCIS': checkProperty(itemData ,'statusDetails','id') == 8,
                    'status_approved': checkProperty(itemData ,'statusDetails','id') == 9,
                    'status_denied': checkProperty(itemData ,'statusDetails','id') == 10,
                    'RFE_Received': ['11',11].indexOf(checkProperty(itemData ,'statusDetails','id')) >-1,
                    'response_to_RFE_Filed': checkProperty(itemData ,'statusDetails','id') == 12,
                    'response_to_RFE_Received': checkProperty(itemData ,'statusDetails','id') == 13,
                    'status_withdrawn': checkProperty(itemData ,'statusDetails','id') == 14,
                    ' ': checkProperty(itemData ,'statusDetails','id') == 15
                  }"
            
            >{{checkProperty( itemData,'statusDetails' ,'name')}}</span>
                
            </li>
            <!---
            <li>
            <a href="#" class="approve-btn"></a>
            </li>
            <li>
            <a href="#" class="close-btn"></a>
            </li>
            <li>
            <a href="#" class="upload-btn"></a>
            </li>
            -->
        </ul>
        <p  v-if="checkProperty( itemData,'updatedOn')" class="task-timing"> {{ checkProperty( itemData,'updatedOn') | timeago}}</p>
    </div>
                </div>
        </template>
      </template>
      <template v-else>
      <div class="graph_cnt" >
        
       
            
              <!--<apexchart width="320" type="donut" :options="options" :series="series" ></apexchart>
              
               //'lca_denied': checkProperty(cData ,'statusId') == 4, //#ED957B
                  //'lca_request_for_withdrawal': checkProperty(cData ,'statusId') == 5, #1F9BE5
                  //'lca_withdrawn': checkProperty(cData ,'statusId') == 6, #8FEDF5
                  //'lca_expired': checkProperty(cData ,'statusId') == 7, #FCCFCF
              
              -->
              <div v-show="!loading && wallsLoaded && statusCount >0" :id="chartDivId" style="height:250px;"></div>
             <ul class="chart_legends" v-if="!loading && statusCount >0">
              <template v-for="(cData,ind) in chartData"  >
                      <li :class="replaceSpaces(cData.category)" :key="ind"
                       v-on:click.stop.prevent="navigateToDetails({'statusDetails':{'id':checkProperty(cData ,'statusId')}} ,'LCA_LIST','statusIds' )"
                      ><p><span

                      
                       v-bind:class="{
                        'lca_created': checkProperty(cData ,'statusId') == 1,
                        'lca_filed': checkProperty(cData ,'statusId') == 2,
                        'lca_certified': checkProperty(cData ,'statusId') == 3,
                        'lca_denied': checkProperty(cData ,'statusId') == 4,
                        'lca_request_for_withdrawal': checkProperty(cData ,'statusId') == 5,
                        'lca_withdrawn': checkProperty(cData ,'statusId') == 6,
                        'lca_expired': checkProperty(cData ,'statusId') == 7,
                        'Status_received_by_USCIS': checkProperty(cData ,'statusId') == 8,
                        'status_approved': checkProperty(cData ,'statusId') == 9,
                        'status_denied': checkProperty(cData ,'statusId') == 10,
                        'RFE_Received': ['11',11].indexOf(checkProperty(cData ,'statusId')) >-1,
                        'response_to_RFE_Filed': checkProperty(cData ,'statusId') == 12,
                        'response_to_RFE_Received': checkProperty(cData ,'statusId') == 13,
                        'status_withdrawn': checkProperty(cData ,'statusId') == 14,
                        ' ': checkProperty(cData ,'statusId') == 15
                      }"
                      
                      ></span>{{cData.category}}</p></li>         
              </template>
              
             
            </ul>
              <template v-if="!loading && statusCount<=0">
             <NoDataFound  ref="NoDataFoundRef"  :loading="false"  heading="No Data"  type="support"  />
            </template>

             <chartLoading v-if="loading || !wallsLoaded" />
        </div>
      </template>            

</div>

</template>

<script>
import NoDataFound from "@/views/common/noData.vue";
import DateRangePicker from "vue2-daterange-picker";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import VueApexCharts from 'vue-apexcharts'
import Vue from 'vue'
import moment from 'moment'

import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import chartLoading from "@/views/wall/chartLoading.vue"
am4core.useTheme(am4themes_animated);
import DatePickerCustom from "@/views/common/_date_picker_custom.vue";

import { _ } from 'core-js'
Vue.use(VueApexCharts)


Vue.component('apexchart', VueApexCharts)

export default {
 name:'caseByStatus',
 props: {
    widgetData:null,
    widgetsItems:null,
    viewType:{
        type:String,
        default:'LIST'
    }
 },
  components: {
    DateRangePicker,
    chartLoading,
    DatePickerCustom,
    NoDataFound,
  },
  data: function () {
    return {

        chartDivId: 'lca-chart',

      caseStatusList:[],
      wallsLoaded:true,     
      loading: true,
      isOpenDateFilter: false,
      filterText: "",
      chartData: [],
      selected_createdDateRange: ["", ""],
      autoApply: "",
      options: {
        labels: [],
        legend: {
          position: "top",
        },
      },
      series: [],
      statusCount: 0,
      allCaseTypes: [],
      selectedCaseTypes: null,

      allCaseSubTypes: [],
      selectedCaseSubTypes: [],
    };
  },

  mounted() {
   
    //this.getVisaTypes();
    const d = new Date();
   let time = d.getTime();
    this.chartDivId ='lca-chart_'+time+'';
    setTimeout(()=>{
          this.getStats();
    })
  
    this.filterText = "";
  },
  created() {
    document.addEventListener("scroll", this.handleScroll);
  },
  destroyed() {
    document.removeEventListener("scroll", this.handleScroll);
  },
  methods: {
    gottPage(itemData){
      
      //this.$store.dispatch('setPetitionTab', 'set_LCA');
      setTimeout(()=>{
         this.goToPageDetails('/lca-inventory-details/'+this.checkProperty( itemData,'_id'));
      },5)
     

  },
    handleScroll(event) {
      this.$refs["filter_menu"].dropdownVisible = false;
      // Any code to be executed when the window is scrolled
    },
    reloaStats(seleteddates) {
      this.selected_createdDateRange["startDate"] = seleteddates.startDate;
      this.selected_createdDateRange["endDate"] = seleteddates.endDate;
      this.getStats();
    },
    clear_filter() {
      this.selectedCaseTypes = [];
      this.selectedCaseSubTypes = [];
      this.selected_createdDateRange = [];
      this.filterText = "";
      this.$refs["filter_menu"].dropdownVisible = false;
      this.getStats();
    },
    togleDateFIlter() {
      this.isOpenDateFilter = this.isOpenDateFilter ? false : true;

      // if(this.isOpenDateFilter){
      //    alert(this.isOpenDateFilter)
      //     document.addEventListener("click", ()=>{
      //         this.isOpenDateFilter =false;
      //          alert(this.isOpenDateFilter +"FROM TRIGGRED")

      //     });
      // }
    },
    generateDate(type = "Today") {
      let startDate = moment().startOf("day").format("YYYY-MM-DD");
      let endDate = moment().endOf("day").format("YYYY-MM-DD");
      this.filterText = "Today";
      if (type == "Today") {
        startDate = moment().startOf("day").format("YYYY-MM-DD");
        endDate = moment().endOf("day").format("YYYY-MM-DD");
        this.selected_createdDateRange["startDate"] = startDate;
        this.selected_createdDateRange["endDate"] = endDate;
      } else if (type == "This Week") {
        this.filterText = "This Week";
        startDate = moment().startOf("week").format("YYYY-MM-DD");
        endDate = moment().endOf("week").format("YYYY-MM-DD");
        this.selected_createdDateRange["startDate"] = startDate;
        this.selected_createdDateRange["endDate"] = endDate;
      } else if (type == "This Month") {
        this.filterText = "This Month";
        startDate = moment().startOf("month").format("YYYY-MM-DD");
        endDate = moment().endOf("month").format("YYYY-MM-DD");
        this.selected_createdDateRange["startDate"] = startDate;
        this.selected_createdDateRange["endDate"] = endDate;
      } else if (type == "Custom_date") {
        startDate = this.selected_createdDateRange["startDate"];
        endDate = this.selected_createdDateRange["endDate"];
        startDate = moment(startDate).format("YYYY-MM-DD");
        endDate = moment(endDate).format("YYYY-MM-DD");

        this.filterText = startDate + " To " + endDate;
      }

      this.isOpenDateFilter = false;

      //  this.getStats();
    },
     
     initChart(){
      let self =this;
        this.loading =false;

     
var chart = am4core.create(this.chartDivId, am4charts.PieChart3D);
chart.logo.disabled = true;
// Add data
chart.data = this.chartData;
/*[{
  "category": "white",
  "count": 501.9,
  "color": "red"
}, {
  "category": "red",
  "count": 301.9,
  "color": "yellow"
}, {
  "category": "orange",
  "count": 201.1,
  "color": "orange"
}, {
  "category": "green",
  "count": 165.8,
  "color": "green"
}, {
  "category": "blue",
  "count": 139.9,
  "color": "blue"
}];
*/
//chart.contentHeight =320;
//chart.contentWidth =500;

//chart.width=200;
chart.height=250;
// Add and configure Series
var pieSeries = chart.series.push(new am4charts.PieSeries3D());
pieSeries.dataFields.value = "count";
pieSeries.dataFields.category = "category";
pieSeries.innerRadius = am4core.percent(60);
pieSeries.ticks.template.disabled = true;
pieSeries.labels.template.disabled = true;


pieSeries.slices.template.events.on(
        "hit",
        function (ev) {
         // alert("11111111111");
          self.navigateToDetails({'statusDetails':{'id':ev.target.dataItem._dataContext.statusId}} ,'LCA_LIST','statusIds' )

          /*
          'lca_created': checkProperty(cData ,'statusId') == 1,
                        'lca_filed': checkProperty(cData ,'statusId') == 2,
                        'lca_certified': checkProperty(cData ,'statusId') == 3,
                        'lca_denied': checkProperty(cData ,'statusId') == 4,
                        'lca_request_for_withdrawal': checkProperty(cData ,'statusId') == 5,
                        'lca_withdrawn': checkProperty(cData ,'statusId') == 6,
          */
          
         //  _self.gotoList(ev.target.dataItem.category);
          
         
         
        },
        
      );

// This is not working and produces an error
// pieSeries.slices.template.adapter.add("fill", function (fill, target) {
//     return target.dataItem.dataContext["color"];
// });


// var rgm = new am4core.RadialGradientModifier();
// rgm.brightnesses.push(-0.8, -0.8, -0.5, 1, 1);
// pieSeries.slices.template.fillModifier = rgm;
// pieSeries.slices.template.strokeModifier = rgm;
 pieSeries.slices.template.strokeOpacity = 2;
 pieSeries.slices.template.strokeWidth = 1;
pieSeries.slices.template.propertyFields.fill = "color";
      },

    getVisaTypes() {
      let item = {
        matcher: {
          searchString: "",
          getWorkFlowConfig: false,
          // "petitionType":
        },
        page: 1,
        perpage: 100000,
        category: "petition_types",
        sorting: {
          path: "name",
          order: 1,
        },
      };

      this.$store.dispatch("getMasterData", item).then((response) => {
        this.allCaseTypes = response.list;
      });
    },
    changedVisaType(item) {
      this.selectedCaseTypes = item;
      this.allCaseSubTypes = [];
      this.selectedCaseSubTypes = [];
      if (_.has(this.selectedCaseTypes, "id")) {
        this.getvisa_subtypes();
      }
      //  this.getStats();
    },
    getvisa_subtypes() {
      if (this.selectedCaseTypes && _.has(this.selectedCaseTypes, "id")) {
        let item = {
          matcher: {
            searchString: "",
            petitionType: parseInt(this.selectedCaseTypes["id"]),
            getWorkFlowConfig: false,
          },
          page: 1,
          perpage: 1000,
          category: "petition_sub_types",
          sorting: {
            path: "name",
            order: 1,
          },
        };

        this.$store.dispatch("getMasterData", item).then((response) => {
          this.allCaseSubTypes = response.list;
        });
      }
    },
    getStats() {
      
      //dashboard/get-stats
      

      this.statusCount = 0;
      this.options["labels"] = [];
      this.series = [];
      this.chartData = [];
      this.loading = true;
      let colors =this.getCaseColors();
     
       if(this.checkProperty(this.widgetsItems ,'data','length')>0){
            _.forEach(this.widgetsItems['data'] ,(item)=>{

                 if(this.checkProperty(this.widgetsItems ,'mData','length')>0 && this.checkProperty(item ,'statusId') >0){

                 let roleData = _.find(this.widgetsItems['mData'] ,{"id":item['statusId']});

                   let  statusColor =_.find(colors ,{'id':item['statusId']});

                 if(roleData && this.checkProperty(roleData ,'name')){
                   
                    item = Object.assign(item ,{"category":roleData['name']});

                    if(statusColor && this.checkProperty(statusColor ,'backgroundColor')){
                        item = Object.assign(item ,{'color':''});
                        item['color'] = statusColor['backgroundColor']
                    }
 

                    if([1,2,3,4,5,6,7].indexOf(item['statusId'])>-1){
                      if(item['statusId'] ==1){
                        item['color'] ="#F98C00" ; //created
                      }else if(item['statusId'] ==2){
                        item['color'] ="#C0CA33"; //filed
                      }else if(item['statusId'] ==3){
                        item['color'] ="#32CD32"; //certified
                      }else if(item['statusId'] ==4){
                        item['color'] ="#ED957B"; //certified
                      }else if(item['statusId'] ==5){
                        item['color'] ="#1F9BE5"; //certified
                      }else if(item['statusId'] ==6){
                        item['color'] ="#8FEDF5"; //certified
                      }else if(item['statusId'] ==7){
                        item['color'] ="#FCCFCF"; //certified
                      }
                      
                    }


                  // 'lca_created': checkProperty(cData ,'statusId') == 1, #F98C00
                  // 'lca_filed': checkProperty(cData ,'statusId') == 2, #C0CA33
                  // 'lca_certified': checkProperty(cData ,'statusId') == 3, #32CD32
                  //'lca_denied': checkProperty(cData ,'statusId') == 4, //#ED957B
                  //'lca_request_for_withdrawal': checkProperty(cData ,'statusId') == 5, #1F9BE5
                  //'lca_withdrawn': checkProperty(cData ,'statusId') == 6, #8FEDF5
                  //'lca_expired': checkProperty(cData ,'statusId') == 7, #FCCFCF

                /*  [ { "_id": "6257fa6e621cbad27e2772f1", "id": 1, "name": "Initiated", "sortName": "initiated" },
                 { "_id": "6257fa6e621cbad27e2772f2", "id": 2, "name": "Filed", "sortName": "filed" }, 
                 { "_id": "6257fa6e621cbad27e2772f3", "id": 3, "name": "Certified", "sortName": "certified" },
                 { "_id": "6257fa6e621cbad27e2772f4", "id": 4, "name": "Denied", "sortName": "denied" },
                 { "_id": "6257fa6e621cbad27e2772f5", "id": 5, "name": "Request for Withdrawal", "sortName": "request for withdrawal" },
                 { "_id": "6257fa6e621cbad27e2772f6", "id": 6, "name": "Withdrawn", "sortName": "withdrawn" }, 
                 { "_id": "6257fa6e621cbad27e2772f7", "id": 7, "name": "Expired", "sortName": "expired" } 
                  ]*/
                    this.statusCount = this.statusCount+item['count'];
                    this.chartData.push(item);


                 }

                }
            });
            this.loading =false;
            if( this.statusCount >0){
                 this.initChart();
            }else{
                 setTimeout(()=>{
                    this.updateLoading(false); 
                    setTimeout(()=>{ this.loading = false;  this.updateLoading(false);  } ,10)   
                } ,10)
            }
           

    }
          this.loading = false;
        
    },
  },


}
</script>
