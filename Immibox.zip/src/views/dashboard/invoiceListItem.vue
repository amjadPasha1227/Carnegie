<template>
<div>
    <template v-if="viewType=='LIST' ">

        <template v-for="(itemData ,itmIndex) in widgetsItems['data']" >

                <div class="widget-task-list" :key="itmIndex">

                    <div class="task-details cursor" @click="goToDetailsPage(itemData)" >
                    <!----  <h4>Case Submitted dfsdfdsf</h4> -->
                    <!-- ;goToPageDetails('/petition-details/'+checkProperty( itemData,'petitionId')) -->
                        <p>{{checkProperty( itemData,'petitionDetails','caseNo')}}</p>
                        
                        <ul> 
                          
                            <!-- <li v-if="checkProperty( itemData,'createdByDetails' ,'name')">{{checkProperty( itemData,'createdByDetails' ,'name')}} <span v-if="checkProperty( itemData,'petitionDetails' ,'subTypeDetails')">{{checkProperty( itemData['petitionDetails'],'subTypeDetails' ,'name')}}</span></li> -->
                            <li v-if="checkProperty( itemData,'amount' )">{{checkProperty( itemData,'amount' ) | formatprice}} <span >(Total)</span></li>
                            <li v-if="checkTotalAmount({'item':itemData,'type':'Paid'})">{{checkTotalAmount({'item':itemData,'type':'Paid'}) | formatprice}} <span >(Paid)</span></li>
                            <!-- <li v-if="checkTotalAmount(itemData)">{{checkTotalAmount(itemData) | formatprice}} <span >(Due)</span></li> -->
                            <li v-if="checkTotalAmount({'item':itemData,'type':'Due'})">{{checkTotalAmount({'item':itemData,'type':'Due'}) | formatprice}} <span >(Due)</span></li>
                           
                        </ul>
                    </div>
                    <div class="task-status" >

                        <ul >

                        <li v-if="checkProperty( itemData,'statusDetails' ,'name')" >
                            <span class="statusspan"
                            
                            v-bind:class="{
                                    'invoice-created': checkProperty(itemData ,'statusId') == 1,
                                    'invoice-sent': checkProperty(itemData ,'statusId') == 2,
                                    'status_inProcess': checkProperty(itemData ,'statusId') == 3,
                                    'status_waiting': checkProperty(itemData ,'statusId') == 4,
                                    'invoice-partially-paid': checkProperty(itemData ,'statusId') == 5,
                                    'invoice-fully-paid': checkProperty(itemData ,'statusId') == 6,
                                    'staus_filed_with_USCIS': checkProperty(itemData ,'statusDetails','id') == 7,
                                    'Status_received_by_USCIS': checkProperty(itemData ,'statusDetails','id') == 8,
                                    'status_approved': checkProperty(itemData ,'statusDetails','id') == 9,
                                    'status_denied': checkProperty(itemData ,'statusDetails','id') == 10,
                                    'RFE_Received': ['11',11].indexOf(checkProperty(itemData ,'statusDetails','id')) >-1,
                                    'response_to_RFE_Filed': checkProperty(itemData ,'statusDetails','id') == 12,
                                    'response_to_RFE_Received': checkProperty(itemData ,'statusDetails','id') == 13,
                                    'status_withdrawn': checkProperty(itemData ,'statusDetails','id') == 14,
                                    ' ': checkProperty(itemData ,'statusDetails','id') == 15
                                }"
                            
                            >{{checkProperty( itemData,'statusDetails' ,'name')}}</span>
                                
                            </li>
                            <!---
                            <li>
                            <a href="#" class="approve-btn"></a>
                            </li>
                            <li>
                            <a href="#" class="close-btn"></a>
                            </li>
                            <li>
                            <a href="#" class="upload-btn"></a>
                            </li>
                            -->
                        </ul>
                        <p  v-if="checkProperty( itemData,'updatedOn')" class="task-timing"> {{ checkProperty( itemData,'updatedOn') | timeago}}</p>
                    </div>
                </div>
        </template>
      </template>
      <template v-else>
      <div class="graph_cnt" >
          
              <!--<apexchart width="320" type="donut" :options="options" :series="series" ></apexchart> -->
              <div v-show="!loading && wallsLoaded && statusCount >0" :id="chartDivId" style="height:250px;"></div>
             <ul class="chart_legends" v-if="!loading && statusCount >0">
              <template v-for="(cData,ind) in chartData"  >
                      <li :class="replaceSpaces(cData.category)" :key="ind"><p><span
                      
                      v-bind:class="{
                        'invoice-created': checkProperty(cData ,'statusId') == 1,
                        'invoice-sent': checkProperty(cData ,'statusId') == 2,
                        'status_inProcess': checkProperty(cData ,'statusId') == 3,
                        'status_waiting': checkProperty(cData ,'statusId') == 4,
                        'invoice-partially-paid': checkProperty(cData ,'statusId') == 5,
                        'invoice-fully-paid': checkProperty(cData ,'statusId') == 6,
                        'staus_filed_with_USCIS': checkProperty(cData ,'statusId') == 7,
                        'Status_received_by_USCIS': checkProperty(cData ,'statusId') == 8,
                        'status_approved': checkProperty(cData ,'statusId') == 9,
                        'status_denied': checkProperty(cData ,'statusId') == 10,
                        'RFE_Received': ['11',11].indexOf(checkProperty(cData ,'statusId')) >-1,
                        'response_to_RFE_Filed': checkProperty(cData ,'statusId') == 12,
                        'response_to_RFE_Received': checkProperty(cData ,'statusId') == 13,
                        'status_withdrawn': checkProperty(cData ,'statusId') == 14,
                        ' ': checkProperty(cData ,'statusId') == 15
                      }"
                      
                      
                      ></span>{{cData.category}}</p></li>         
              </template>
              
             
            </ul>
              <template v-if="!loading && statusCount<=0">
             <NoDataFound  ref="NoDataFoundRef"  :loading="false"  heading="No Data"  type="support"  />
            </template>

             <chartLoading v-if="loading || !wallsLoaded" />
        </div>
      </template>           

</div>

</template>

<script>
import NoDataFound from "@/views/common/noData.vue";
import DateRangePicker from "vue2-daterange-picker";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import VueApexCharts from 'vue-apexcharts'
import Vue from 'vue'
import moment from 'moment'

import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import chartLoading from "@/views/wall/chartLoading.vue"
am4core.useTheme(am4themes_animated);
import DatePickerCustom from "@/views/common/_date_picker_custom.vue";

import { _ } from 'core-js'
Vue.use(VueApexCharts)


Vue.component('apexchart', VueApexCharts)

export default {
 name:'caseByStatus',
 props: {
    widgetData:null,
    widgetsItems:null,
    viewType:{
        type:String,
        default:'LIST'
    }
 },
  components: {
    DateRangePicker,
    chartLoading,
    DatePickerCustom,
    NoDataFound,
  },
  data: function () {
    return {
     chartDivId:'invoice-chart',
 
      caseStatusList:[],
      wallsLoaded:true,     
      loading: true,
      isOpenDateFilter: false,
      filterText: "",
      chartData: [],
      selected_createdDateRange: ["", ""],
      autoApply: "",
      options: {
        labels: [],
        legend: {
          position: "top",
        },
      },
      series: [],
      statusCount: 0,
      allCaseTypes: [],
      selectedCaseTypes: null,

      allCaseSubTypes: [],
      selectedCaseSubTypes: [],
    };
  },

  mounted() {
   
    //this.getVisaTypes();
     //this.getVisaTypes();
    const d = new Date();
   let time = d.getTime();
    this.chartDivId ='invoice-chart_'+time+'';
    setTimeout(()=>{
          this.getStats();
    })
    this.filterText = "";
  },
  created() {
    document.addEventListener("scroll", this.handleScroll);
  },
  destroyed() {
    document.removeEventListener("scroll", this.handleScroll);
  },
  methods: {
    goToDetailsPage(item){
      let invoiceItem = item
      if(this.checkProperty(invoiceItem,'petitionDetails','type')==3 && this.checkProperty(invoiceItem,'petitionDetails','type')==15 ){
        //this.$router.push('/gc-employment-details/'+this.checkProperty( invoiceItem,'petitionId'));
        this.$router.push({ name: 'gc-employment-details', params: { itemId:this.checkProperty( invoiceItem,'petitionId'),tabname:'Fees/Invoices' } }).catch(err => {})
      }
      else{
        //this.$router.push('/petition-details/'+this.checkProperty( invoiceItem,'petitionId'));
        this.$router.push({ name: 'petition-details', params: { itemId:this.checkProperty( invoiceItem,'petitionId'),tabname:'Fees/Invoices' } }).catch(err => {})
      }
    },
    handleScroll(event) {
      this.$refs["filter_menu"].dropdownVisible = false;
      // Any code to be executed when the window is scrolled
    },
    reloaStats(seleteddates) {
      this.selected_createdDateRange["startDate"] = seleteddates.startDate;
      this.selected_createdDateRange["endDate"] = seleteddates.endDate;
      this.getStats();
    },
    clear_filter() {
      this.selectedCaseTypes = [];
      this.selectedCaseSubTypes = [];
      this.selected_createdDateRange = [];
      this.filterText = "";
      this.$refs["filter_menu"].dropdownVisible = false;
      this.getStats();
    },
    togleDateFIlter() {
      this.isOpenDateFilter = this.isOpenDateFilter ? false : true;

      // if(this.isOpenDateFilter){
      //    alert(this.isOpenDateFilter)
      //     document.addEventListener("click", ()=>{
      //         this.isOpenDateFilter =false;
      //          alert(this.isOpenDateFilter +"FROM TRIGGRED")

      //     });
      // }
    },
    generateDate(type = "Today") {
      let startDate = moment().startOf("day").format("YYYY-MM-DD");
      let endDate = moment().endOf("day").format("YYYY-MM-DD");
      this.filterText = "Today";
      if (type == "Today") {
        startDate = moment().startOf("day").format("YYYY-MM-DD");
        endDate = moment().endOf("day").format("YYYY-MM-DD");
        this.selected_createdDateRange["startDate"] = startDate;
        this.selected_createdDateRange["endDate"] = endDate;
      } else if (type == "This Week") {
        this.filterText = "This Week";
        startDate = moment().startOf("week").format("YYYY-MM-DD");
        endDate = moment().endOf("week").format("YYYY-MM-DD");
        this.selected_createdDateRange["startDate"] = startDate;
        this.selected_createdDateRange["endDate"] = endDate;
      } else if (type == "This Month") {
        this.filterText = "This Month";
        startDate = moment().startOf("month").format("YYYY-MM-DD");
        endDate = moment().endOf("month").format("YYYY-MM-DD");
        this.selected_createdDateRange["startDate"] = startDate;
        this.selected_createdDateRange["endDate"] = endDate;
      } else if (type == "Custom_date") {
        startDate = this.selected_createdDateRange["startDate"];
        endDate = this.selected_createdDateRange["endDate"];
        startDate = moment(startDate).format("YYYY-MM-DD");
        endDate = moment(endDate).format("YYYY-MM-DD");

        this.filterText = startDate + " To " + endDate;
      }

      this.isOpenDateFilter = false;

      //  this.getStats();
    },
     
     initChart(){
        this.loading =false;
    
var chart = am4core.create(this.chartDivId, am4charts.PieChart3D);
chart.logo.disabled = true;
// Add data
chart.data = this.chartData;
/*[{
  "category": "white",
  "count": 501.9,
  "color": "red"
}, {
  "category": "red",
  "count": 301.9,
  "color": "yellow"
}, {
  "category": "orange",
  "count": 201.1,
  "color": "orange"
}, {
  "category": "green",
  "count": 165.8,
  "color": "green"
}, {
  "category": "blue",
  "count": 139.9,
  "color": "blue"
}];
*/
//chart.contentHeight =320;
//chart.contentWidth =500;

//chart.width=200;
chart.height=250;
// Add and configure Series
var pieSeries = chart.series.push(new am4charts.PieSeries3D());
pieSeries.dataFields.value = "count";
pieSeries.dataFields.category = "category";
pieSeries.innerRadius = am4core.percent(60);
pieSeries.ticks.template.disabled = true;
pieSeries.labels.template.disabled = true;

// This is not working and produces an error
// pieSeries.slices.template.adapter.add("fill", function (fill, target) {
//     return target.dataItem.dataContext["color"];
// });


// var rgm = new am4core.RadialGradientModifier();
// rgm.brightnesses.push(-0.8, -0.8, -0.5, 1, 1);
// pieSeries.slices.template.fillModifier = rgm;
// pieSeries.slices.template.strokeModifier = rgm;
 pieSeries.slices.template.strokeOpacity = 2;
 pieSeries.slices.template.strokeWidth = 1;
pieSeries.slices.template.propertyFields.fill = "color";
let _self = this;
pieSeries.slices.template.adapter.add("fill", function(fill, target) {


let dat = _.find( _self.chartData, {"category":target.dataItem.category} )
if(dat && _.has(dat ,'color')){
return dat['color']
}else{
return chart.colors.getIndex(target.dataItem.index);
}



});



      },

    getVisaTypes() {
      let item = {
        matcher: {
          searchString: "",
          getWorkFlowConfig: false,
          // "petitionType":
        },
        page: 1,
        perpage: 100000,
        category: "petition_types",
        sorting: {
          path: "name",
          order: 1,
        },
      };

      this.$store.dispatch("getMasterData", item).then((response) => {
        this.allCaseTypes = response.list;
      });
    },
    changedVisaType(item) {
      this.selectedCaseTypes = item;
      this.allCaseSubTypes = [];
      this.selectedCaseSubTypes = [];
      if (_.has(this.selectedCaseTypes, "id")) {
        this.getvisa_subtypes();
      }
      //  this.getStats();
    },
    getvisa_subtypes() {
      if (this.selectedCaseTypes && _.has(this.selectedCaseTypes, "id")) {
        let item = {
          matcher: {
            searchString: "",
            petitionType: parseInt(this.selectedCaseTypes["id"]),
            getWorkFlowConfig: false,
          },
          page: 1,
          perpage: 1000,
          category: "petition_sub_types",
          sorting: {
            path: "name",
            order: 1,
          },
        };

        this.$store.dispatch("getMasterData", item).then((response) => {
          this.allCaseSubTypes = response.list;
        });
      }
    },
    getStats() {
      
      //dashboard/get-stats
      
  let colors =this.getCaseColors();
      this.statusCount = 0;
      this.options["labels"] = [];
      this.series = [];
      this.chartData = [];
      this.loading = true;
     
       if(this.checkProperty(this.widgetsItems ,'data','length')>0){
            _.forEach(this.widgetsItems['data'] ,(item)=>{

                 if(this.checkProperty(this.widgetsItems ,'mData','length')>0 && this.checkProperty(item ,'statusId') >0){

                 let roleData = _.find(this.widgetsItems['mData'] ,{"id":item['statusId']});
                 if(roleData && this.checkProperty(roleData ,'name')){
                   
                    item = Object.assign(item ,{"category":roleData['name']});
                    let  statusColor =_.find(colors ,{'id':item['statusId']});
                    if([1,2,5,6].indexOf(item['statusId'])>-1){
                      if(item['statusId'] ==1){
                        statusColor ={"backgroundColor":'#D2AEF5'}
                      }else if(item['statusId'] ==2){
                        statusColor ={"backgroundColor":'#96D0B3'}
                      }else if(item['statusId'] ==5){
                        statusColor ={"backgroundColor":'#F8BF96'}
                      }else if(item['statusId'] ==6){
                        statusColor ={"backgroundColor":'#32CD32'}
                      }
                      
                    }
                     if(statusColor && this.checkProperty(statusColor ,'backgroundColor')){
                        item['color'] = statusColor['backgroundColor']
                    }


                    this.statusCount = this.statusCount+item['count'];
                    this.chartData.push(item);


                 }

                }
            });
            this.loading =false;
            if( this.statusCount >0){
                 this.initChart();
            }else{
                 setTimeout(()=>{
                    this.updateLoading(false); 
                    setTimeout(()=>{ this.loading = false;  this.updateLoading(false);  } ,10)   
                } ,10)
            }
           

    }
          this.loading = false;
        
    },
  },
  computed:{
    checkTotalAmount(){
      return(data)=>{
        let returnval = null
        let invoiceItem = data['item']
        if(this.checkProperty(invoiceItem,'partlyPaidLogs') && this.checkProperty(invoiceItem,'partlyPaidLogs','length')>0 ){
          let amount = 0
          invoiceItem['partlyPaidLogs'].forEach(item => {
            amount += item.amount;
          });
           returnval = amount
        }
        if(this.checkProperty(data,'type') == 'Paid'  ){
          return returnval
        }
        if( this.checkProperty(data,'type') == 'Due' ){
          returnval =  invoiceItem['amount'] - returnval 
        }
        return returnval
      }
    },
  }


}
</script>