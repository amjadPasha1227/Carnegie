<template>
  <div class="added-widgets">
    <div class="deadline-widgets" id="heightChange" :class="{'small' : (selectedHeight == 'small'), 'medium' : (selectedHeight == 'medium'),'large' : (selectedHeight == 'large') }">
      <!-----
      <div class="header">
        <div class="title">
          <h4>Deadlines</h4>
        </div>
        <div class="widget-filters">
          <button class="filter_btn active"><em>To-Do</em><span>2</span></button>
          <button class="filter_btn"><em>Cases</em><span>21</span></button>
          <button class="filter_btn"><em>Tasks</em></button>
          <button class="filter_btn"><em>Updates</em></button>
        </div>
        <div class="actions">
          <ul>
            <li @click="popupFilter=true"><figure><img src="@/assets/images/funnel.svg" alt="calendar-img" width="14" height="14"></figure></li>
            <li class="has-dropdown"><figure><more-horizontal-icon size="1.5x" class="custom-class" style="opacity: 0.6;"></more-horizontal-icon></figure>
            <div class="height-dropdown">
                
                <ul class="subdropdown">
                  <li :disabled="duplicating" @click="duplicateColumn()"><a><figure><img src="@/assets/images/duplication.png" alt="duplicate-img" width="15"></figure>Duplicate</a></li>
                  <li><a class="text-danger"><figure><img src="@/assets/images/delete.png" alt="trash-img" width="15"></figure>Delete</a></li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
      </div>
      -->
     
     
     <widgetHeader @togleExpend="togleExpend"  :selecetedTab="tabName" @changeTab="changeTab"  :rowExistingColumnsLength="rowExistingColumnsLength" :availableEmptyColumns="availableEmptyColumns" @deleteColumn="deleteColumn" @duplicateColumn="duplicateColumn" @openAddFilterDialog="openAddFilterDialog" :columnId="columnId" :rowId="rowId" :widgetData="widgetData" />
     
      <VuePerfectScrollbar	
        ref="mainSidebarPs"	
        class="scroll-area--main-sidebar"	
        :settings="settings"	
        @ps-scroll-y="psSectionScroll"	
      >
      
        <template  v-if="(checkProperty(widgetsItems ,'data' ,'length')>0 && (checkProperty(missedDeadLineCaseList ,'length')>0 || checkProperty(todayCaseList ,'length') >0  || checkProperty( tomorrowCaseList ,'length')>0)  ) && !isListLoading">
        <div class="missed-deadlines" v-if="checkProperty(missedDeadLineCaseList ,'length')>0">
                <h4 class="deadlines_title">Missed Deadlines </h4>
                
                  <div class="widget-content">
                  <div class="widget-deadline-list" v-for="(item ,itmIndex) in missedDeadLineCaseList" :key="itmIndex">
                    <div class="deadline-details">
                      <div class="missed-date cursor"  v-if="checkProperty(item ,'caseNo')"   v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST' ,'deadlineDate')">
                        <p  class="date">{{checkProperty(item ,'deadlineDate') | formatDateDD}}  </p>
                        <p class="month">{{checkProperty(item ,'deadlineDate') | formatDateMMM}}</p>
                      </div>
                       <div class="missed-date cursor" v-else   v-on:click.stop.prevent="navigateToDetails(item ,'TASK_LIST' ,'deadlineDate')">
                        <p  class="date">{{checkProperty(item ,'deadlineDate') | formatDateDD}}  </p>
                        <p class="month">{{checkProperty(item ,'deadlineDate') | formatDateMMM}}</p>
                      </div>
                      <div class="deadline-info"   >
              
                      <template  v-if="checkProperty(item ,'caseNo')" >
                       
                        <p v-on:click.stop.prevent="navigateToDetails(item ,'CASE_DETAILS')" v-if="checkProperty(item ,'caseNo') &&  item.subTypeDetails.id !=15">
                            {{checkProperty(item ,'caseNo')}} 
                            
                          </p>
                          <p v-on:click.stop.prevent="navigateToDetails(item ,'PERM_DETAILS')" v-if="checkProperty(item ,'caseNo')  && (item.subTypeDetails.id ==15)">
                            {{checkProperty(item ,'caseNo')}} 
                            
                          </p>

                           <ul

                           v-if="checkProperty( item,'typeDetails' ,'name') || checkProperty( item,'subTypeDetails' ,'name')
                           || checkProperty( item,'petitionerDetails' ,'name') || checkProperty( item,'beneficiaryDetails' ,'name')
                           
                           "
                             
                           >
                            <li v-if="checkProperty( item,'typeDetails' ,'name')">
                            <span v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST' ,'typeIds')" >
                            {{checkProperty( item,'typeDetails' ,'name')}}
                            </span>
                            
                            
                            <span v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST' ,'subTypeIds')" v-if="checkProperty( item,'subTypeDetails' ,'name')">
                            ({{checkProperty( item,'subTypeDetails' ,'name')}})
                            </span>
                            </li>
                            

                            <li v-if="checkProperty( item,'petitionerDetails' ,'name')" v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST','petitionerIds' )">
                            {{checkProperty( item,'petitionerDetails' ,'name')}} <span>(Petitioner)</span>
                            
                            </li>
                            <li v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST','beneficiaryIds' )"
                            v-if="checkProperty( item,'beneficiaryDetails' ,'name')" >
                            
                            {{checkProperty( item,'beneficiaryDetails' ,'name')}} <span>(Beneficiary)</span>
                            </li>
                          </ul>
                   


                        </template>
                        <template v-else>

                        <p class="cursor" v-on:click.stop.prevent="goToPageDetails('/tasks-list?id='+checkProperty( item,'_id'))" v-if="checkProperty(item ,'title')">{{checkProperty(item ,'title')}} <template v-if="checkProperty(item ,'customId')"> - <span>{{checkProperty(item ,'customId')}} </span></template></p>
                        
                        </template>
                      </div>
                      
                       <span class="statusspan cursor"  v-if="checkProperty(item ,'caseNo')"
                       
                              v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST','statusIds' )"
                              
                              v-bind:class="{
                            'status_created': checkProperty(item ,'statusDetails','id') == 1,
                            'status_submited': checkProperty(item ,'statusDetails','id') == 2,
                            'status_inProcess': checkProperty(item ,'statusDetails','id') == 3,
                            'status_waiting': checkProperty(item ,'statusDetails','id') == 4,
                            'status_ready_for_filing': checkProperty(item ,'statusDetails','id') == 5,
                            'status_sent_for_signatures': checkProperty(item ,'statusDetails','id') == 6,
                            'staus_filed_with_USCIS': checkProperty(item ,'statusDetails','id') == 7,
                            'status_approved': checkProperty(item ,'statusDetails','id') == 9,
                            'status_denied': checkProperty(item ,'statusDetails','id') == 10,
                            'RFE_Received': ['11',11].indexOf(checkProperty(item ,'statusDetails','id')) >-1,
                            'response_to_RFE_Filed': checkProperty(item ,'statusDetails','id') == 12,
                            'response_to_RFE_Received': checkProperty(item ,'statusDetails','id') == 13,
                            'status_withdrawn': checkProperty(item ,'statusDetails','id') == 14,
                            ' ': checkProperty(item ,'statusDetails','id') == 15
                          }"
                              
                      >{{checkProperty(item ,'statusDetails' ,'name')}}
                      </span>
                      <span class="statusspan cursor" v-else
                       
                       v-on:click.stop.prevent="navigateToDetails(item ,'TASK_LIST','statusIds' )"
                      
                      v-bind:class="{
                    'status_created': checkProperty(item ,'statusDetails','id') == 1,
                    'status_submited': checkProperty(item ,'statusDetails','id') == 2,
                    'status_inProcess': checkProperty(item ,'statusDetails','id') == 3,
                    'status_waiting': checkProperty(item ,'statusDetails','id') == 4,
                    'status_ready_for_filing': checkProperty(item ,'statusDetails','id') == 5,
                    'status_sent_for_signatures': checkProperty(item ,'statusDetails','id') == 6,
                    'staus_filed_with_USCIS': checkProperty(item ,'statusDetails','id') == 7,
                    'Status_received_by_USCIS': checkProperty(item ,'statusDetails','id') == 8,
                    'status_approved': checkProperty(item ,'statusDetails','id') == 9,
                    'status_denied': checkProperty(item ,'statusDetails','id') == 10,
                    'RFE_Received': ['11',11].indexOf(checkProperty(item ,'statusDetails','id')) >-1,
                    'response_to_RFE_Filed': checkProperty(item ,'statusDetails','id') == 12,
                    'response_to_RFE_Received': checkProperty(item ,'statusDetails','id') == 13,
                    'status_withdrawn': checkProperty(item ,'statusDetails','id') == 14,
                    ' ': checkProperty(item ,'statusDetails','id') == 15
                  }"
                      
                      >{{checkProperty(item ,'statusDetails' ,'name')}}
                      </span>
                    </div>
                  </div>
                  
                </div>
                  
        </div>
        <div class="missed-deadlines" v-if="checkProperty(todayCaseList ,'length')>0">
          <h4 class="deadlines_title">Today</h4>
              <div class="widget-content">
              <div class="widget-deadline-list" v-for="(item ,itmIndex) in todayCaseList" :key="itmIndex">
              <div class="deadline-details">
              <!--
                      <div class="missed-date cursor" v-if="tabName!='TASK'"   v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST' ,'deadlineDate')">
                        <p  class="date">{{checkProperty(item ,'deadlineDate') | formatDateDD}}  </p>
                        <p class="month">{{checkProperty(item ,'deadlineDate') | formatDateMMM}}</p>
                      </div>
                       <div class="missed-date cursor" v-else   v-on:click.stop.prevent="navigateToDetails(item ,'TASK_LIST' ,'deadlineDate')">
                        <p  class="date">{{checkProperty(item ,'deadlineDate') | formatDateDD}}  </p>
                        <p class="month">{{checkProperty(item ,'deadlineDate') | formatDateMMM}}</p>
                      </div>
                      -->
                      <div class="deadline-info"   >
              
                      <template v-if="checkProperty(item ,'caseNo')" >
                       
                        <p v-on:click.stop.prevent="navigateToDetails(item ,'CASE_DETAILS')" v-if="checkProperty(item ,'caseNo') &&  item.subTypeDetails.id !=15">
                            {{checkProperty(item ,'caseNo')}} 
                            
                          </p>
                          <p v-on:click.stop.prevent="navigateToDetails(item ,'PERM_DETAILS')" v-if="checkProperty(item ,'caseNo')  && (item.subTypeDetails.id ==15)">
                            {{checkProperty(item ,'caseNo')}} 
                            
                          </p>

                           <ul>
                            <li v-if="checkProperty( item,'typeDetails' ,'name')">
                            <span v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST' ,'typeIds')" >
                            {{checkProperty( item,'typeDetails' ,'name')}}
                            </span>
                            
                            
                            <span v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST' ,'subTypeIds')" v-if="checkProperty( item,'subTypeDetails' ,'name')">
                            ({{checkProperty( item,'subTypeDetails' ,'name')}})
                            </span>
                            </li>
                            

                            <li v-if="checkProperty( item,'petitionerDetails' ,'name')" v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST','petitionerIds' )">
                            {{checkProperty( item,'petitionerDetails' ,'name')}} <span>(Petitioner)</span>
                            
                            </li>
                            <li v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST','beneficiaryIds' )"
                            v-if="checkProperty( item,'beneficiaryDetails' ,'name')" >
                            
                            {{checkProperty( item,'beneficiaryDetails' ,'name')}} <span>(Beneficiary)</span>
                            </li>
                          </ul>
                   


                        </template>
                        <template v-else>

                        <p class="cursor" v-on:click.stop.prevent="goToPageDetails('/tasks-list?id='+checkProperty( item,'_id'))" v-if="checkProperty(item ,'title')">{{checkProperty(item ,'title')}} <template v-if="checkProperty(item ,'customId')"> - <span>{{checkProperty(item ,'customId')}} </span></template></p>
                        
                        </template>
                      </div>
                      
                       <span class="statusspan cursor" v-if="checkProperty(item ,'caseNo')"
                       
                              v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST','statusIds' )"
                              
                              v-bind:class="{
                            'status_created': checkProperty(item ,'statusDetails','id') == 1,
                            'status_submited': checkProperty(item ,'statusDetails','id') == 2,
                            'status_inProcess': checkProperty(item ,'statusDetails','id') == 3,
                            'status_waiting': checkProperty(item ,'statusDetails','id') == 4,
                            'status_ready_for_filing': checkProperty(item ,'statusDetails','id') == 5,
                            'status_sent_for_signatures': checkProperty(item ,'statusDetails','id') == 6,
                            'staus_filed_with_USCIS': checkProperty(item ,'statusDetails','id') == 7,
                            'status_ready_for_filing': checkProperty(item ,'statusDetails','id') == 8,
                            'status_approved': checkProperty(item ,'statusDetails','id') == 9,
                            'status_denied': checkProperty(item ,'statusDetails','id') == 10,
                            'RFE_Received': ['11',11].indexOf(checkProperty(item ,'statusDetails','id')) >-1,
                            'response_to_RFE_Filed': checkProperty(item ,'statusDetails','id') == 12,
                            'response_to_RFE_Received': checkProperty(item ,'statusDetails','id') == 13,
                            'status_withdrawn': checkProperty(item ,'statusDetails','id') == 14,
                            ' ': checkProperty(item ,'statusDetails','id') == 15
                          }"
                              
                      >{{checkProperty(item ,'statusDetails' ,'name')}}
                      </span>
                      <span class="statusspan cursor" v-else
                       
                       v-on:click.stop.prevent="navigateToDetails(item ,'TASK_LIST','statusIds' )"
                      
                      v-bind:class="{
                    'status_created': checkProperty(item ,'statusDetails','id') == 1,
                    'status_submited': checkProperty(item ,'statusDetails','id') == 2,
                    'status_inProcess': checkProperty(item ,'statusDetails','id') == 3,
                    'status_waiting': checkProperty(item ,'statusDetails','id') == 4,
                    'status_ready_for_filing': checkProperty(item ,'statusDetails','id') == 5,
                    'status_sent_for_signatures': checkProperty(item ,'statusDetails','id') == 6,
                    'staus_filed_with_USCIS': checkProperty(item ,'statusDetails','id') == 7,
                    'status_ready_for_filing': checkProperty(item ,'statusDetails','id') == 8,
                    'status_approved': checkProperty(item ,'statusDetails','id') == 9,
                    'status_denied': checkProperty(item ,'statusDetails','id') == 10,
                    'RFE_Received': ['11',11].indexOf(checkProperty(item ,'statusDetails','id')) >-1,
                    'response_to_RFE_Filed': checkProperty(item ,'statusDetails','id') == 12,
                    'response_to_RFE_Received': checkProperty(item ,'statusDetails','id') == 13,
                    'status_withdrawn': checkProperty(item ,'statusDetails','id') == 14,
                    ' ': checkProperty(item ,'statusDetails','id') == 15
                  }"
                      
                      >{{checkProperty(item ,'statusDetails' ,'name')}}
                      </span>
              </div>
             </div>
          </div>
        </div>
        <div class="missed-deadlines" v-if="checkProperty(tomorrowCaseList ,'length')>0">
                <h4 class="deadlines_title">Upcoming Deadlines </h4>
                
                  <div class="widget-content">
                  <div class="widget-deadline-list" v-for="(item ,itmIndex) in tomorrowCaseList" :key="itmIndex">
                    <div class="deadline-details">
                      <div class="missed-date cursor" v-if="checkProperty(item ,'caseNo')"   v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST' ,'deadlineDate')">
                        <p  class="date">{{checkProperty(item ,'deadlineDate') | formatDateDD}}  </p>
                        <p class="month">{{checkProperty(item ,'deadlineDate') | formatDateMMM}}</p>
                      </div>
                       <div class="missed-date cursor" v-else   v-on:click.stop.prevent="navigateToDetails(item ,'TASK_LIST' ,'deadlineDate')">
                        <p  class="date">{{checkProperty(item ,'deadlineDate') | formatDateDD}}  </p>
                        <p class="month">{{checkProperty(item ,'deadlineDate') | formatDateMMM}}</p>
                      </div>
                      <div class="deadline-info"   >
              
                      <template v-if="checkProperty(item ,'caseNo')" >
                       
                        <p v-on:click.stop.prevent="navigateToDetails(item ,'CASE_DETAILS')" v-if="checkProperty(item ,'caseNo') &&  item.subTypeDetails.id !=15">
                            {{checkProperty(item ,'caseNo')}} 
                            
                          </p>
                          <p v-on:click.stop.prevent="navigateToDetails(item ,'PERM_DETAILS')" v-if="checkProperty(item ,'caseNo')  && (item.subTypeDetails.id ==15)">
                            {{checkProperty(item ,'caseNo')}} 
                            
                          </p>

                           <ul>
                            <li v-if="checkProperty( item,'typeDetails' ,'name')">
                            <span v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST' ,'typeIds')" >
                            {{checkProperty( item,'typeDetails' ,'name')}}
                            </span>
                            
                            
                            <span v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST' ,'subTypeIds')" v-if="checkProperty( item,'subTypeDetails' ,'name')">
                            ({{checkProperty( item,'subTypeDetails' ,'name')}})
                            </span>
                            </li>
                            

                            <li v-if="checkProperty( item,'petitionerDetails' ,'name')" v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST','petitionerIds' )">
                            {{checkProperty( item,'petitionerDetails' ,'name')}} <span>(Petitioner)</span>
                            
                            </li>
                            <li v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST','beneficiaryIds' )"
                            v-if="checkProperty( item,'beneficiaryDetails' ,'name')" >
                            
                            {{checkProperty( item,'beneficiaryDetails' ,'name')}} <span>(Beneficiary)</span>
                            </li>
                          </ul>
                   


                        </template>
                        <template v-else>

                        <p class="cursor" v-on:click.stop.prevent="goToPageDetails('/tasks-list?id='+checkProperty( item,'_id'))" v-if="checkProperty(item ,'title')">{{checkProperty(item ,'title')}} <template v-if="checkProperty(item ,'customId')"> - <span>{{checkProperty(item ,'customId')}} </span></template></p>
                        
                        </template>
                      </div>
                      
                       <span class="statusspan cursor" v-if="checkProperty(item ,'caseNo')"
                       
                              v-on:click.stop.prevent="navigateToDetails(item ,'CASE_LIST','statusIds' )"
                              
                              v-bind:class="{
                            'status_created': checkProperty(item ,'statusDetails','id') == 1,
                            'status_submited': checkProperty(item ,'statusDetails','id') == 2,
                            'status_inProcess': checkProperty(item ,'statusDetails','id') == 3,
                            'status_waiting': checkProperty(item ,'statusDetails','id') == 4,
                            'status_ready_for_filing': checkProperty(item ,'statusDetails','id') == 5,
                            'status_sent_for_signatures': checkProperty(item ,'statusDetails','id') == 6,
                            'staus_filed_with_USCIS': checkProperty(item ,'statusDetails','id') == 7,
                            'status_ready_for_filing': checkProperty(item ,'statusDetails','id') == 8,
                            'status_approved': checkProperty(item ,'statusDetails','id') == 9,
                            'status_denied': checkProperty(item ,'statusDetails','id') == 10,
                            'RFE_Received': ['11',11].indexOf(checkProperty(item ,'statusDetails','id')) >-1,
                            'response_to_RFE_Filed': checkProperty(item ,'statusDetails','id') == 12,
                            'response_to_RFE_Received': checkProperty(item ,'statusDetails','id') == 13,
                            'status_withdrawn': checkProperty(item ,'statusDetails','id') == 14,
                            ' ': checkProperty(item ,'statusDetails','id') == 15
                          }"
                              
                      >{{checkProperty(item ,'statusDetails' ,'name')}}
                      </span>
                      <span class="statusspan cursor" v-else
                       
                       v-on:click.stop.prevent="navigateToDetails(item ,'TASK_LIST','statusIds' )"
                      
                      v-bind:class="{
                    'status_created': checkProperty(item ,'statusDetails','id') == 1,
                    'status_submited': checkProperty(item ,'statusDetails','id') == 2,
                    'status_inProcess': checkProperty(item ,'statusDetails','id') == 3,
                    'status_waiting': checkProperty(item ,'statusDetails','id') == 4,
                    'status_ready_for_filing': checkProperty(item ,'statusDetails','id') == 5,
                    'status_sent_for_signatures': checkProperty(item ,'statusDetails','id') == 6,
                    'staus_filed_with_USCIS': checkProperty(item ,'statusDetails','id') == 7,
                    'Status_received_by_USCIS': checkProperty(item ,'statusDetails','id') == 8,
                    'status_approved': checkProperty(item ,'statusDetails','id') == 9,
                    'status_denied': checkProperty(item ,'statusDetails','id') == 10,
                    'RFE_Received': ['11',11].indexOf(checkProperty(item ,'statusDetails','id')) >-1,
                    'response_to_RFE_Filed': checkProperty(item ,'statusDetails','id') == 12,
                    'response_to_RFE_Received': checkProperty(item ,'statusDetails','id') == 13,
                    'status_withdrawn': checkProperty(item ,'statusDetails','id') == 14,
                    ' ': checkProperty(item ,'statusDetails','id') == 15
                  }"
                      
                      >{{checkProperty(item ,'statusDetails' ,'name')}}
                      </span>
                    </div>
                  </div>
                  
                </div>
                  
        </div>


       
        </template>
        <template v-else>
        <div class="widget-content">
         <NoDataFound
            ref="NoDataFoundRef"
            :loading="isListLoading"
            heading="No Data"
            type="support"
            />
        </div>


              
                
              </template>
      </VuePerfectScrollbar>
    </div>
    
     
  
  </div>
</template>
 
 
<script>
 import VuePerfectScrollbar from "vue-perfect-scrollbar";
 import Multiselect from "vue-multiselect-inv";
 import { MoreHorizontalIcon } from 'vue-feather-icons'
import NoDataFound from "@/views/common/noData.vue";
import moment from "moment";
import widgetHeader from "./widgetHeader.vue";

  export default {
    components: {
      NoDataFound,
      VuePerfectScrollbar,
      Multiselect,
      MoreHorizontalIcon,
      widgetHeader
    },
    data: function () {
      return {
      groupedlist:[],  
      todayCaseList: [],
      tomorrowCaseList : [],
      missedDeadLineCaseList : [],

        popupFilter:false,
        value: null,
        options: [],
        primary:'', 


        selectedHeight:'small',
         isListLoading:true,
        widgetsItems:null,
        settings: { 
          swipeEasing: false,
        },
        duplicating:false,
        widGetCode:'DEADLINE'
        
        
      };
     
    },
    props: { 
       listForDashboard:null,
      availableEmptyColumns:0,
      rowExistingColumnsLength:0,
      columnId:'',
      rowId:'',
    widgetData:null,
     wedgetHights:{
       
        "1X":'small',
        "1.5":"medium",
        "2X":"large"
      },
      tabName:'CASES',
      selectedBranch:null,
      dueDatekey:'deadlineDate'

   },
    methods:{
      togleExpend(data){
        this.$emit('togleExpend' ,data)
      },

      changeTab(tab){
        //this.tabName =tab;
      
        this.$emit('changeTab' ,tab);
        setTimeout(()=>{
          this.getWigetsData();

        })
      
         
       },


      
      deleteColumn(data){
       
         let tempData = {
            "rowId": "",
		      	"columnId": "",
          }

        if(this.checkProperty(data ,'rowId' ) && this.checkProperty(data ,'columnId' )){
            tempData['rowId'] =   this.checkProperty(data ,'rowId' );
            tempData['columnId'] =   this.checkProperty(data ,'columnId' );

        }else  if(this.columnId && this.rowId ){
         
            tempData['rowId'] =   this.rowId;
            tempData['columnId'] =   this.columnId;
            this.duplicating =true;
           

        }
       
        this.$emit("deleteColumn" ,tempData);

      },
      openAddFilterDialog(data){

        let tempData = {
            "rowId": "",
		      	"columnId": "",
            "widgetData":null,
            "selecetedTab":""
          }

           if(this.checkProperty(data ,'selecetedTab')){
                tempData['selecetedTab'] = this.checkProperty(data ,'selecetedTab');
            }

        if(this.checkProperty(data ,'rowId' ) && this.checkProperty(data ,'columnId' )){
            tempData['rowId'] =   this.checkProperty(data ,'rowId' );
            tempData['columnId'] =   this.checkProperty(data ,'columnId' );
            tempData['widgetData'] =   this.checkProperty(data ,'widgetData' );

        }else  if(this.columnId && this.rowId ){
         
            tempData['rowId'] =   this.rowId;
            tempData['columnId'] =   this.columnId;
            tempData['widgetData'] =   this.widgetData;
            this.duplicating =true;
           

        }
       
        this.$emit("openAddFilterDialog" ,tempData);

      },
      duplicateColumn(data){
       
         let tempData = {
            "rowId": "",
		      	"columnId": "",
          }

        if(this.checkProperty(data ,'rowId' ) && this.checkProperty(data ,'columnId' )){
            tempData['rowId'] =   this.checkProperty(data ,'rowId' );
            tempData['columnId'] =   this.checkProperty(data ,'columnId' );

        }else  if(this.columnId && this.rowId ){
         
            tempData['rowId'] =   this.rowId;
            tempData['columnId'] =   this.columnId;
            this.duplicating =true;
           

        }
         this.$emit("duplicateColumn" ,tempData);
      },
      
      psSectionScroll(event){

      },
    getWigetsData(){
       this.todayCaseList = [];
      this.tomorrowCaseList = [];
      this.missedDeadLineCaseList = [];
      this.groupedlist=[];

      this.isListLoading =true;
      this.widgetsItems =null;
      let path ="dashboard/get-widget-data";
      let postData ={
        categoryList:['DEADLINE'],
        filters:{},
        perpage:10

      };
      let tempTabName ="DEADLINE"
     
      postData['perpage'] = this.checkProperty(this.widgetData ,"perpage");
      if(this.checkProperty(this.widgetData ,"sorting" ,'path') && this.checkProperty(this.widgetData ,"sorting" ,'order')){
        postData = Object.assign(postData,{"sorting":this.widgetData['sorting']});
      }
      if(this.checkProperty(this.widgetData ,"filters" ) ){
       // postData['filters'] = this.checkProperty(this.widgetData ,"filters"); //this.tabName
              
        if(['ACTION' ,'DEADLINE'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1){

          if(this.checkProperty(this.widgetData,'filters' ,this.tabName )){

          
            _.forEach(this.widgetData['filters'][this.tabName] ,(val ,key)=>{
              //['countryIds' ,'stateIds' ,'typeIds' ,'petitionTypeIds']
            if(['countryIds' ,'stateIds' ].indexOf(key)>-1){
              // postData['filters'][key]
              if(_.has(val ,'id')){
                postData['filters'][key] =[val['id']]
              }

            }else{
          
            let arrayListIds = _.filter(val ,(item)=>{
              return _.has(item ,'name') && _.has(item ,'id')
            })
            if(arrayListIds && this.checkProperty(arrayListIds ,'length')>0){
              postData['filters'][key] = arrayListIds.map((item)=>item.id);
            }else{
              postData['filters'][key] =val;

            }
          }


          })
          }

        


         
     

        }else{

        
        _.forEach(this.widgetData['filters'] ,(val ,key)=>{

          if(['countryIds' ,'stateIds' ].indexOf(key)>-1){
            // postData['filters'][key]
            if(_.has(val ,'id')){
              postData['filters'][key] =[val['id']]
            }

          }else{
        
           let arrayListIds = _.filter(val ,(item)=>{
            return _.has(item ,'name') && _.has(item ,'id')
           })
           if(arrayListIds && this.checkProperty(arrayListIds ,'length')>0){
            postData['filters'][key] = arrayListIds.map((item)=>item.id);
           }else{
            postData['filters'][key] =val;

           }
        }


        })
       
        }

      }

       

        
         postData['categoryList'] = ['DEADLINE'];
         this.widGetCode =  "DEADLINE";
         this.dueDatekey ='deadlineDate'
        if(['TASK'].indexOf(this.tabName)>-1){
          postData['categoryList'] = ['TASK_DEADLINE'];
          tempTabName ="TASK_DEADLINE";
          this.dueDatekey ='dueDate'
          this.widGetCode =  "TASK_DEADLINE";
         
        }
        if( this.checkProperty( postData['filters'] ,'deadlineDateRange', 'length') !=2 ){
        }
           let toDay = moment().format('YYYY-MM-DD');
           const weekStart = moment().startOf('week');
          // alert(weekStart);

          let nextWeek  = moment().add(1,'week').format('YYYY-MM-DD');
          let yesterDay = moment().subtract(1, 'day').format('YYYY-MM-DD');
           postData['filters']['deadlineDateRange'] =[yesterDay ,nextWeek];

       

       
     
       this.updateLoading(true); 
        postData['filters']['types'] = [];
        postData['filters']["entityTypeList"] = [];
        postData['filters']["getMissingDeadlines"]=  true;
       this.$store.dispatch("commonAction" ,{data:postData,'path':path})
       
      .then((rx) =>{
      this.widgetsItems = rx[tempTabName];

      if(this.checkProperty(this.widgetsItems,"data" ,'length')>0 ){

        _.forEach(this.widgetsItems['data'] ,(item)=>{
          if(this.checkProperty(item ,'deadlineDate') ){
            item['dueDate'] = this.checkProperty(item ,'deadlineDate')
          }else if(this.checkProperty(item ,'dueDate') ){
            item['deadlineDate'] = this.checkProperty(item ,'dueDate')
          }

        })

        
            //find todayCaseList  ,   tomorrowCaseList ,  missedDeadLineCaseList;
            var futurecases = this.tomorrowCaseList = _.filter(this.widgetsItems['data'], (item) => {
              let today = moment().startOf("day");
              let tomorrow  = moment().add(1,'days')
              let deadlineDate = moment(item[this.dueDatekey]).startOf("day");
              return deadlineDate.isAfter(today ,'day');
            });

            this.missedDeadLineCaseList = _.filter(this.widgetsItems['data'], (item) => {
              let today = moment().startOf("day");
              let deadlineDate = moment(item[this.dueDatekey]).startOf("day");
              return deadlineDate.isBefore(today ,'day');
            });

              this.todayCaseList = _.filter(this.widgetsItems['data'], (item) => {
              let today = moment();
              let deadlineDate = moment(item['deadlineDate']);
              return deadlineDate.isSame(today ,"day");
            });



            var result = _.chain(futurecases)
              .groupBy((datum) =>
                moment(new Date(datum[this.dueDatekey])).startOf("day").format()
              )
              .map((items, id) => ({
                date: id,
                items: items,
              }))
              .value();

              this.groupedlist = _.sortBy(result, "date");
         

      }


      this.isListLoading =false;
      setTimeout(()=>{
          this.updateLoading(false); 
          setTimeout(()=>{ this.isListLoading = false;  this.updateLoading(false);  } ,10)   
      } ,10)
       

      })
      .catch((err) =>{
         this.isListLoading =false;
        setTimeout(()=>{
              this.updateLoading(false); 
              setTimeout(()=>{ this.isListLoading = false;  this.updateLoading(false);  } ,10)   
          } ,10)
         
       
       })
    },

   
  },
   mounted() {

     if(['DEADLINE'].indexOf(this.checkProperty(this.widgetData,'code' ))>-1){
       this.selecetedTab= "CASES";
    }
   
    setTimeout(() =>{
      if(this.checkProperty(this.widgetData ,"code") ){

        this.widGetCode = this.checkProperty(this.widgetData ,"code");

        if(this.checkProperty(this.widgetData ,'height')){
          this.selectedHeight =this.widgetData['height'];
          
        }
       
        this.getWigetsData();
      }

    })

   }

  

  
  
  
};
</script>
