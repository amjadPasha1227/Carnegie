<template>
<div>
     <div class="dashboard__section">
        <div class="dashboard_cnt">  
            <div class="dashboard_left">
                <div class="grid_actions">
                    <ul>
                  <!--  // all, todo activity changedTab -->
                        <li @click="changedTab('all')" :class="{'active':tabName=='all'}"><a>ALL ACTIVITIES</a></li>
                        <li @click="changedTab('todo')" :class="{'active':tabName=='todo'}" ><a>MY TASKS ({{getToDoWallListCount}})</a></li>
                        <li @click="changedTab('activity')"  :class="{'active':tabName=='activity'}"><a>TASKS</a></li>
                    </ul>
                </div>
                <div class="grid_title">
                    <span>TODAY</span>
                </div>  
            <div class="grid" v-if="!isLodaing">
                <div class="grid-item grid_2x">
                    <div class="wishes_box">
                        <h6>
                            <template v-if="checkProperty(user ,'userName') !=''">
                                {{ user.userName }}
                            </template>
                            <template v-else>
                            {{ user.name }}
                            </template>
                            <img src="@/assets/images/main/smile.png"></h6> 
                        <h4 v-if="tabName=='todo' ||  tabName=='all'">You have {{getToDoWallListCount}} pending task(s).</h4>
                        <!--<span class="note"><img src="@/assets/images/main/note_icon.png"></span>-->
                    </div>
                </div>


                
                <template v-if="!isLodaing">
                    <template  v-for="(item , ind) in getWallList.list" >
                            <toDoGridItem :key="ind" :item="item" v-if="item.type=='todo'"  :itemIndex="ind" :itemTemplate="itemTemplate"  @reloadWals="wallList"/>
                            <activityItem :key="ind" :item="item" v-if="item.type=='activity'" :itemIndex="ind"  :itemTemplate="itemTemplate"  @reloadWals="wallList"/>
                    </template>
                </template>



                
            
            </div>
            
             <paginate v-if="( getWallList['list'].length>0  && !isLodaing)"  v-model="page" :page-count="countTotalPages" :page-range="3" :margin-pages="2" :click-handler="pageNate"
        prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
        :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
  

            <NoDataFound ref="NoDataFoundRef" :loading="!isLodaing" v-if="( getWallList['list'].length<=0  && !isLodaing)" content="" :heading="'No Result Found'" type='Users' />


    </div>
    </div>
    </div>
</div>
</template>

<style scoped>
.dashboard-wrapper{
     height: auto !important;
}
.dashboard-wrapper .dashboard-content {
    width: calc(100% - 0px);
    padding: 30px 30px 10px;
    height: auto;
}
.dashboard-wrapper .dashboard-content .login-name{
    font-size: 1.2806973457336426rem;
    line-height: 1.5rem;
    margin-bottom: 10px;
}
.ux-tabs{
        position: relative;
    display: flex;
    flex-wrap: nowrap;
    padding: 0;
    margin-bottom: 0;
}
.ux-tab-item{
        display: inline-flex;
    margin-top: 0;
    margin-bottom: -1px;
    padding: 8px 20px;
    color: #757575;
}
.active-tab{
        border-bottom: 1px solid #000!important;
            color: #626262
}
.dashboardCardsList {
  position: relative;
  height: 100%;

}

.item {
  position: absolute;
  width:250px;

}

.dashboardCardsList .dsCard{


        border-style: none;
    border-width: 0px;
    border-color: hsla(0, 0%, 70%, 0);
    border-radius: 3px;
    box-shadow: 0 8px 30px -8px #d3d3d3;

}
.color1d{
    background-color: rgba(217, 235, 202,1);
}
.color2d{
    background-color: rgba(255, 236, 187,1);
}
.color3d{
    background-color: rgba(198, 197, 232,1);
}
.color4d{
    background-color: rgba(255, 215, 201,1);
}

.darktheme .color1d{
    background-color:#0E1D48;
}
.darktheme .color2d{
    background-color: #33a30f;
}
.darktheme .color3d{
    background-color: #7461e5;
}
.darktheme .color4d{
    background-color: #056785 ;
}
.darktheme .vue-avatar--wrapper{color:#000 !important;}
.documentsList{
    margin-top:-10px;
    padding-bottom: 10px;
}
.dashboard-wrapper{

    background-color: #ffffff;
    height: calc(100vh - 120px)
}
</style>

<script>
import VueApexCharts from 'vue-apexcharts'
import Vue from 'vue'
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import { MoreVerticalIcon } from 'vue-feather-icons'
import DateRangePicker from "vue2-daterange-picker";
import Avatar from 'vue-avatar'
import WallMessage from '../views/wall/message.vue'
import { MasonryGrid, JustifiedGrid, FrameGrid, PackingGrid } from "@egjs/vue-grid";
import toDoGridItem from './wall/toDoGridItem.vue'
import activityItem from './wall/activityItem.vue'
import { _ } from 'core-js'
import NoDataFound from "@/views/common/noData.vue";
import 'vue2-daterange-picker/dist/vue2-daterange-picker.css'
Vue.use(VueApexCharts)
import Paginate from "vuejs-paginate";

Vue.component('apexchart', VueApexCharts)

export default {
    components: {
        Paginate,
        MasonryGrid,
        WallMessage,
        Avatar,
        VuePerfectScrollbar,
        MoreVerticalIcon,
        DateRangePicker,
        toDoGridItem,
        activityItem,
        NoDataFound
    },
    data: function () {
         
       


        return {
            callFromSerch:false,
            itemTemplate:[],
            isLodaing:true,
            tabName:'all',
             perPage:25,
            page:1,
      
          gap:0,
    frame: [[1,1,2,2],[3,3,2,2],[4,4,4,5]],
    rectSize: 0,
    useFrameFill: true,
             dateRange: {
               // startDate: '2019-12-26',
               // endDate: '2019-12-28',
                },
            username: '',
            activities: [],
            options: {},
            series: [50, 102, 155, 141, 117],
            dashboard_data: {},
            lca_requests: [],
            new_petitioners: [],
            new_petitions: [],
            petitionersCount: {},
            beneficiaryStats: {},

            petitionsCount: {},
            rfe_petitions: [],

            //recent activity data
            recent_activitys: [],
            my_tasks: [],
            roleId: 0,
            wallFilterData: {
          "filters":{
            "types": ['todo'], // all, todo activity
            "createdDateRange": []
          },
          "page": 1,
          "perpage": 25,
          "sorting": {
            "path": "createdOn",
            "order": -1
          }
        }

        }
    },
   
    mounted() {
        this.username = this.$store.state.user.name;
        this.roleId = this.$store.state.user['roleId'][0];
       
        this.petitionsCount = {
            petitionCount: 0,
            rfeCount: 0,
            totalCount: 0
        };
        this.petitionersCount = {
            approvedCount: 0,
            pendingCount: 0,
            totalCount: 0
        };
        this.beneficiaryStats = {
            "total": 0,
            "active": 0,
            "inactive": 0
        };

        this.get_dashboardData();
        this.get_recentActivitys();
        this.get_mytasks();
        this.getactivities();
         this.wallFilterData = {
          "filters":{
            "types": [this.tabName], // all, todo activity
            "createdDateRange": []
          },
          "page": this.page,
          "perpage": this.perPage,
          "sorting": {
            "path": "createdOn",
            "order": -1
          }
        }
    this.wallList();

    },
    methods: {
        pageNate(pageNum) {
         
          this.page = pageNum;
     
             this.wallFilterData = {
          "filters":{
            "types": [this.tabName], // all, todo activity
            "createdDateRange": []
          },
          "page": this.page,
          "perpage": this.perPage,
          "sorting": {
            "path": "createdOn",
            "order": -1
          }
        }
        this.wallList();
      },
         getRandomTemplate(){
      let tmp = [

        [
          "grid_1x","grid_1x",
          "grid_3x" , "grid_3x" ,"grid_3x" ,
          "grid_2x" , "grid_1x" , "grid_1x",
          "grid_1x" , "grid_2x",  "grid_1x",
          "grid_2x","grid_2x",
          "grid_1x","grid_1x", "grid_2x",
          "grid_3x" , "grid_3x" ,"grid_3x" ,
          "grid_1x" , "grid_2x",  "grid_1x",
         "grid_2x","grid_2x",
         "grid_1x","grid_1x", "grid_2x",


        ],
     
        [
           "grid_2x","grid_2x",
          
          "grid_2x" , "grid_1x" , "grid_1x",
          "grid_3x" , "grid_3x" ,"grid_3x" ,
           "grid_2x","grid_2x",
          "grid_1x" , "grid_2x",  "grid_1x",
          "grid_3x" , "grid_3x" ,"grid_3x" ,
          "grid_1x","grid_1x", "grid_2x",
          "grid_2x","grid_2x",
          "grid_1x" , "grid_2x",  "grid_1x",
          "grid_3x" , "grid_3x" ,"grid_3x" ,
        ],

        [
           "grid_1x","grid_1x",
           "grid_1x" , "grid_2x",  "grid_1x",
            "grid_3x" , "grid_3x" ,"grid_3x" ,
           "grid_2x","grid_2x",
          "grid_2x" , "grid_1x" , "grid_1x",
          "grid_1x" , "grid_2x",  "grid_1x",
          "grid_3x" , "grid_3x" ,"grid_3x" ,
         "grid_2x","grid_2x",
          "grid_1x","grid_1x", "grid_2x",
          "grid_3x" , "grid_3x" ,"grid_3x" ,
        ],

         [
           "grid_2x",
           "grid_1x" , "grid_1x",  "grid_1x","grid_1x",
             "grid_2x","grid_2x",
            "grid_3x" , "grid_3x" ,"grid_3x" ,
           "grid_2x","grid_2x",
          "grid_2x" , "grid_1x" , "grid_1x",
           "grid_3x" , "grid_3x" ,"grid_3x" ,
          "grid_1x" , "grid_2x",  "grid_1x",
          "grid_3x" , "grid_3x" ,"grid_3x" ,
          "grid_1x","grid_1x", "grid_2x",
          "grid_2x","grid_2x",
          "grid_3x" , "grid_3x" ,"grid_3x" ,
        ],

     
      ]
      let random=  _.random((tmp.length)-1);
     
      return tmp[random];
    },
    updateLoading(value){
        setTimeout(()=>{
            try{
        this.$refs['NoDataFoundRef'].updateLoading(value);


      }catch(err){}

        } ,100)
      
    },
    geAlltWallList({callFromSerch=false , postData={}}) {
             this.itemTemplate = this.getRandomTemplate();
             this.isLodaing =true;
              this.$vs.loading();
              
      this.updateLoading(true);
      this.$store
         .dispatch("common/getWallList",postData )
         .then(response => {
             this.isLodaing =false;   
           this.updateLoading(false);
           setTimeout(() =>{
                 jQuery('.grid').isotope({
                     layoutMode: 'packery',
                    itemSelector: '.grid-item'
                 });
                 this.$vs.loading.close();
                 
                 

           } ,100)

         
       
           
           //alert(this.perpage);
         }).catch(()=>{
             this.$vs.loading.close();
           this.updateLoading(false);
           jQuery('.grid').isotope({
            layoutMode: 'packery',
            itemSelector: '.grid-item'
            });
          this.isLodaing =false;

         })
     },
        changedTab(tabName='all'){
             this.page =1;
            this.tabName =tabName;
             this.wallFilterData = {
          "filters":{
            "types": [this.tabName], // all, todo activity
            "createdDateRange": []
          },
          "page": this.page,
          "perpage": this.perPage,
          "sorting": {
            "path": "createdOn",
            "order": -1
          }
        }

            this.wallList();
        },
        wallList(){
            this.geAlltWallList({ postData:this.wallFilterData });
        },
        get_dashboardData: function () {
            this.$store.dispatch("get_dashboard_data", {}).then(response => {
                this.dashboard_data = response;
                this.lca_requests = this.dashboard_data['lca_requests'] ? this.dashboard_data['lca_requests'] : [];

                this.petitionsCount = this.dashboard_data['petitionsCount'] ? this.dashboard_data['petitionsCount'] : {
                    petitionCount: 0,
                    rfeCount: 0,
                    totalCount: 0
                };
                this.petitionersCount = this.dashboard_data['petitionersCount'] ? this.dashboard_data['petitionersCount'] : {
                    approvedCount: 0,
                    pendingCount: 0,
                    totalCount: 0
                };
                this.beneficiaryStats = this.dashboard_data['beneficiaryStats'] ? this.dashboard_data['beneficiaryStats'] : {
                    "total": 0,
                    "active": 0,
                    "inactive": 0
                };

                this.new_petitioners = this.dashboard_data['new_petitioners'] ? this.dashboard_data['new_petitioners'] : [];
                this.new_petitions = this.dashboard_data['new_petitions'] ? this.dashboard_data['new_petitions'] : [];
                this.rfe_petitions = this.dashboard_data['rfe_petitions'] ? this.dashboard_data['rfe_petitions'] : [];
            });
        },
        get_recentActivitys: function () {
            this.$store.dispatch("get_recent_activitys", {}).then(response => {
                this.recent_activitys = response.list;
            });
        },
        getactivities: function () {
            this.$store.dispatch("getactivities").then(response => {
                this.activities = response;
            });
        },
        get_mytasks: function () {
            this.$store.dispatch("get_my_tasks", {}).then(response => {

                this.my_tasks = response.list.map((element) => {
                    //"navigationKey":

                    element["data"]['navigation_link'] = "#";
                    if (element["data"]["navigationKey"] == "USER_DETAILS")
                        // element["data"]['navigation_link'] ="#/company/details/"+element["data"]['companyId'];

                        if (element["data"]["navigationKey"] == "COMPANY_DETAILS")
                            element["data"]['navigation_link'] = "/company/details/" + element["data"]['companyId'];

                    if (element["data"]["navigationKey"] == "PETITION_DETAILS")
                        element["data"]['navigation_link'] = "/petition-details/" + element["data"]['petitionId'];

                    if (element["data"]["navigationKey"] == "LCA_DETAILS")
                        element["data"]['navigation_link'] = "/lca-details/" + element["data"]['lcaId'];

                    if (element["data"]["description"].includes("questionnaire ")) element["data"]['navigation_link'] = "/questionnaire/" + element["data"]['petitionId'];

                    return element;

                });
                //this.my_tasks = a//response.list;

            });
        },
        refresh() {
           // alert("REFERESH");
            this.get_recentActivitys();
        },
    },
    computed: {
        countTotalPages(){
              return this.totalpages = Math.ceil(this.getWallList.totalCount / this.perPage);
        },
        user() {
      return this.$store.state.user;
    },
    getToDoWallListCount(){
        let returnVal =0;
       let todoList =  _.filter(this.getWallList.list ,{ "type":'todo'});
       if(todoList){
           returnVal = todoList.length;
       }
       return returnVal;

    }
    }
};
</script>
