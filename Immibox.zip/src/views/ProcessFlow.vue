<template>
  <div class="tabs-layout-header-items">
    <div class="items-left">
      <ul class="peoples_list">
        <li v-if="petition.paralegalDetails!=null">
          <figure>
            <img class="user-image" src="@/assets/images/main/avatar2.svg" />
          </figure>
          <div class="peoples-dropdown">
            <h6>
              {{petition.paralegalDetails.name}}
              <span>Paralegal</span>
            </h6>
            <p>
              <a href="#">{{petition.paralegalDetails.email}}</a>
              <span>{{petition.paralegalDetails.phone}}</span>
            </p>
          </div>
        </li>

        <li v-if="petition.supervisorDetails!=null">
          <figure>
            <img class="user-image" src="@/assets/images/main/avatar2.svg" />
          </figure>
          <div class="peoples-dropdown">
            <h6>
              {{petition.supervisorDetails.name}}
              <span>Supervisor</span>
            </h6>
            <p>
              <a href="#">{{petition.supervisorDetails.email}}</a>
              <span>{{petition.supervisorDetails.phone}}</span>
            </p>
          </div>
        </li>

        <li v-if="petition.attorneyDetails!=null">
          <figure>
            <img class="user-image" src="@/assets/images/main/avatar2.svg" />
          </figure>
          <div class="peoples-dropdown">
            <h6>
              {{petition.attorneyDetails.name}}
              <span>Attorney</span>
            </h6>
            <p>
              <a href="#">{{petition.attorneyDetails.email}}</a>
              <span>{{petition.attorneyDetails.phone}}</span>
            </p>
          </div>
        </li>
      </ul>
    </div>

    <div class="items-right">
      <ul>
        <li class="flowdropdown" v-if="checkActionconditions">
          <vs-dropdown vs-custom-content vs-trigger-click>
            <vs-button
              color="primary"
              class="actions-btn"
              type="border"
              icon-pack="feather"
              icon="icon-chevron-down"
              icon-after
            >Actions</vs-button>
            <vs-dropdown-menu ref="filter_menu" class="actions-content petition-action-content">
              <ul>
                <li
                  v-if="currentRole && [6].includes(currentRole) && petition.questionnaireFilled && petition.statusId == 1

              &&  petition.currentActivity!='QUESTIONNIRE_APPROVED'
            "
                >
                  <a href="javascript:;" @click="approveOrreject('approved')">Approve Questionnaire</a>
                </li>
                <li
                  v-if="currentRole && [6].includes(currentRole) && petition.questionnaireFilled && petition.statusId == 1

              &&  petition.currentActivity!='QUESTIONNIRE_APPROVED'
            "
                >
                  <a href="javascript:;" @click="approveOrreject('rejected')">Reject Questionnaire</a>
                </li>

                <li v-if="currentRole && currentRole==2 && petition.paralegalDetails==null">
                  <a href="javascript:;" @click="AssignParalegal=true">Assign Paralegal</a>
                </li>
                <li v-if="currentRole && currentRole==2 && petition.supervisorDetails==null">
                  <a href="javascript:;" @click="SubmitParalegal=true">Submit to Supervisor</a>
                </li>
                <li v-if="currentRole && currentRole==3 &&!petition.paralegalApproved">
                  <a href="javascript:;" @click="approveparalegal()">Approve Paralegal</a>
                </li>
                <li v-if="currentRole && currentRole==3 && !petition.paralegalApproved">
                  <a href="javascript:;" @click="replaceparalegal()">Replace Paralegal</a>
                </li>
                <li v-if="currentRole && currentRole==4 && petition.offshoreManagerDetails == null">
                  <a href="javascript:;" @click="assigntorole(8)">Submit to Offshore Manager</a>
                </li>
                <li v-if="currentRole && currentRole==8 && petition.offshoreUserDetails == null">
                  <a href="javascript:;" @click="assigntorole(9)">Submit to Offshore</a>
                </li>
                <li v-if="currentRole && currentRole==4 && petition.attorneyDetails == null">
                  <a href="javascript:;" @click="assigntorole(5)">Submit to Attorney</a>
                </li>
                     <li v-if="currentRole && currentRole==6 && petition.petitionerSignRequested && petition.statusId < 9">
                  <a href="javascript:;" @click="submitSignedDocuments()">Submit Signed Documents</a>
                </li>
                <li
                  v-if="currentRole && petition.attorneyDetails != null && (!petition.filingFeeDetails || (petition.filingFeeDetails &&  petition.filingFeeDetails.length == 0 ) ) && (currentRole==3 || currentRole==4  || currentRole==5) "
                >
                  <a href="javascript:;" @click="showfilingFeesPopup()">Enter Filing fees</a>
                </li>
                <li v-if="currentRole && (currentRole==5 ) && petition.filingFeeDetails &&  petition.filingFeeDetails.length > 0 &&  !petition.petitionerSignRequested">
                  <a href="javascript:;" @click="showPetitionersign()">Send for Signing</a>
                </li>

                <li
                  v-if="currentRole && petition.courierTrackingCategory==null && petition.petitionerSignRequested && (currentRole==2 || currentRole==3 || currentRole==4 || currentRole==5) && petition.attorneyDetails != null"
                >
                  <a href="javascript:;" @click="updateTrackingDetails()">Case Filed</a>
                </li>
                <li
                  v-if="currentRole && petition.courierTrackingCategory=='UPDATE_TRACKING_NUMBER' && petition.petitionerSignRequested && (currentRole==2 || currentRole==3 || currentRole==4 || currentRole==5) && petition.attorneyDetails != null"
                >
                  <a href="javascript:;" @click="updateTrackingDetails()">Update USCIS Receipt</a>
                </li>
                <li
                  v-if="currentRole && petition.courierTrackingCategory=='UPDATE_USCIS_RECEIPT_NUMBER' && petition.statusId !=13 && petition.petitionerSignRequested && (currentRole==2 || currentRole==3 || currentRole==4 || currentRole==5) && petition.attorneyDetails != null"
                >
                  <a href="javascript:;" @click="updateUSCISstatus()">Update USCIS Status</a>
                </li>
              </ul>
            </vs-dropdown-menu>
          </vs-dropdown>
        </li>
        <li>
          <div class="dropdown-button-container">
            <vs-button>
              <span
                class="status_approved"
                v-if="petition.currentActivity =='QUESTIONNIRE_REJECTED'"
              >Questionnire Rejected</span>
              <span v-else class="status_approved">{{petition.statusDetails.name}}</span>
            </vs-button>
          </div>
        </li>

        <!--    <li><button class="btn btn-brown" @click="AssignParalegal=true" >Assign Paralegal</button></li>
                  <li><button class="btn btn-brown" @click="SubmitParalegal=true">Submit to Supervisor</button></li>
        -->
        <!-- *********************** using html  ********************

        -->
        <li>
          <!-- history side bar-->
          <template lang="html">
            <div id="parentx">
              <img
                @click.stop="active=true"
                class="cursor-pointer"
                src="@/assets/images/main/settings.svg"
              />
              <vs-sidebar
                position-right
                parent="body"
                default-index="1"
                class="sidebarx history-sidebar"
                spacer
                v-model="active"
              >
                <div class="header-sidebar" slot="header">
                  <h4>Petition History</h4>
                  <figure>
                    <img
                      @click="active=false;gethistory()"
                      src="@/assets/images/main/icon-remove.svg"
                    />
                  </figure>
                </div>
                <VuePerfectScrollbar class="scroll-area">
                  <div class="timeline-sidebar">
                    <ul>
                      <li v-for="(history, index) in petitionhistory" :key="index">
                        <div class="timeline-icon">
                          <i class="icon IP-tick-sign"></i>
                        </div>
                        <div class="timeline-info">
                          <button class="btn active-green ml-0">{{history.createdByRoleName}}</button>
                          <ul>
                            <li>
                              <h3>{{history.title}}</h3>
                              <span>{{history.description}}</span>

                              <span>{{history.createdOn | formatDateTime}}</span>
                            </li>
                          </ul>
                        </div>
                      </li>
                    </ul>
                  </div>
                </VuePerfectScrollbar>
              </vs-sidebar>
            </div>
          </template>
        </li>
      </ul>



      <vs-popup
      class="Change_petition_wrap"
      title="Upload Signed Documents"
      :active.sync="uploadSignedPopup"
    >
      <div class="Change_petition">
        <div class="vx-col w-full marb10">
          <div v-for="(docData, index) in documentData" :key="index">
            <div class="vx-row">
              <div class="vx-col w-full">
                <vx-input-group class="form-input-group select-upload-group">
                  <div class="uploadsec_wrap">
                    <div class="w-full">
                      <file-upload
                        v-model="docData.documentUploaded"
                        class="file-upload-input mb-0"
                        style="height:50px;"
                        :name="'pdocuments'+index"
                        :multiple="true" :hideSelected="true"
                        v-validate="'required'"
                        label="Forms and Letters"
                        data-vv-as="Forms and Letters"
                        :accept="allDocEntity"
                        @input="selectedDocuments(index, docData.documentUploaded)"
                      >
                        <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                        Upload
                      </file-upload>
                      <span class="file-type">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('pdocuments'+index)"
                      >{{ errors.first('documents'+index) }}</span>
                      <VuePerfectScrollbar class="scrollbardoc">
                        <div
                          class="uploded-files_wrap"
                          v-if="docData.documentUploaded && docData.documentUploaded.length >0 "
                        >
                          <div
                            class="w-full"
                            v-for="(fil, fileindex) in docData.documentUploaded"
                            :key="fileindex"
                          >
                            <div class="uploded-files">
                              <vx-input-group class="form-input-group">
                                <vs-input
                                  v-on:keyup="fileNameChenged(index ,fileindex)"
                                  required
                                  class="w-full"
                                  :name="'fName'+index"
                                  v-model="docData.documentUploaded[fileindex]['name']"
                                  data-vv-as="File Name"
                                />
                                <span
                                  class="text-danger text-sm"
                                  v-show="!docData.documentUploaded[fileindex]['name']"
                                >Please Enter file name</span>
                                <span
                                  class="text-danger text-sm"
                                  v-show="errors.has('fName'+index)"
                                >{{ errors.first('fName'+index) }}</span>

                                <div
                                  class="delete"
                                  style="z-index:999"
                                  @click="remove_uploadedfile(index ,fileindex)"
                                >
                                  <img src="@/assets/images/main/cross.svg" />
                                </div>
                              </vx-input-group>
                            </div>
                          </div>
                        </div>
                      </VuePerfectScrollbar>
                    </div>
                  </div>
                </vx-input-group>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="actions_footer">
        <button @click="fileuploadPopup=false" class="btn cancel">Cancel</button>
        <button class="btn" v-bind:disble="disable_uploadBtn" @click="uploadFiles()">
          <img class="loader" v-if="fuploder" src="@/assets/images/main/loader.gif" />Save
        </button>
      </div>
    </vs-popup>

      <vs-popup
      v-if="updateTrackingPopup"
        class="holamundo main-popup"
        title="Update Tracking Details"
        :active.sync="updateTrackingPopup"
      >
        <!-- <vs-popup class="holamundo"  title="Lorem ipsum dolor sit amet" :active.sync="filingFeesPopup"> -->
        <form data-vv-scope="trackingform" class="trackingform">
          <div class="form-container">
            <div v-if="this.petition.courierTrackingCategory==null">
              <div class="vx-col w-full">
                <vs-input
                  style="width:100%"
                  data-vv-as="Tracking ID"
                  v-validate="'required'"
                  v-model="tracking.trackingId"
                  name="trackingId"
                  label="Tracking ID"
                />
              </div>
              <div class="vx-col w-full">
                <vs-input
                  style="width:100%"
                  data-vv-as="Tracking URL"
                  v-validate="'required'"
                  v-model="tracking.trackingUrl"
                  name="trackingId"
                  label="Tracking URL"
                />
              </div>
            </div>

            <div v-if="this.petition.courierTrackingCategory!=null">
              <div class="vx-col w-full">
                <vs-input
                  style="width:100%"
                  data-vv-as="Receipt Number"
                  v-validate="'required'"
                  v-model="tracking.receiptNumber"
                  name="receiptNumber"
                  label="Receipt Number"
                />
              </div>
              <div class="vx-col w-full">
                <vs-input
                  style="width:100%"
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="tracking.receiptName"
                  name="receiptName"
                  label="Comments"
                />
              </div>

              <div class="vx-col w-full upload-wrap">
                <file-upload
                  v-model="trackingdoc"
                  class="file-upload-input mb-0"
                  style="height:50px;"
                  name="trackingdoc"
                  :multiple="false"
                  v-validate="'required'"
                  data-vv-as="Forms and Letters"
                  :accept="allDocEntity"
                  @input="selectedDocuments(index, trackingdoc)"
                >
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload *
                </file-upload>
                <span class="file-type marb15">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>

                <div class="file_view"
                  v-for="(file, fileindex) in trackingdoc"
                  :key="fileindex"
                >{{file.name}}</div>
              </div>
            </div>
          </div>

          <div class="popup-footer">
            <vs-button color="success" @click="updateTracking" class="save" type="filled">Submit</vs-button>
          </div>
        </form>
      </vs-popup>

      <vs-popup
        class="holamundo main-popup trackingpopup"
        title="Update USCIS Status"
        :active.sync="updateUSCISstatusPopup"
      >
        <!-- <vs-popup class="holamundo"  title="Lorem ipsum dolor sit amet" :active.sync="filingFeesPopup"> -->
        <form data-vv-scope="uscisstatus" class="trackingform">
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full">
                <div class="con-select w-full select-large marb15">
                  <label class="title_label">Case Status</label>
                  <multiselect
                    name="casestatus"
                    v-validate="'required'"
                    v-model="casestatus"
                    :show-labels="false"
                    track-by="value"
                    label="text"
                    data-vv-as="Case Status"
                    placeholder="Choose Case Status"
                    :options="uscisstatuslist"
                    :searchable="true"
                    :allow-empty="false"
                  ></multiselect>
                </div>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('uscisstatus.casestatus')"
                >{{ errors.first("uscisstatus.casestatus") }}</span>
              </div>
<div v-if="casestatus.value =='USCIS_RECEIVED_RFE' " class="vs-col d-felx d-received_wrap">
                <div class="vs-col">
                  <label class="date-picker-label">RFE Issued Date</label>

                  <datepicker  :typeable="true"
                    icon-pack="IntakePortal"
                    icon-after
                    name="issuedDate"
                    v-model="issuedDate"
                    v-validate="'required'"
                    icon="IP-calendar-1"
                    data-vv-as="Business established date"
                    placeholder="DD/MM/YYYY"
                    :open-date="new Date(openDate)"
                    :disabled-dates="{from: new Date(startEligibleDate)}"
                  ></datepicker>
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('petitioner.')"
                  >{{ errors.first("petitioner.") }}</span>
                </div>

                <div class="vs-col">
                  <label class="date-picker-label">RFE Recevied Date</label>
                  <datepicker  :typeable="true"
                    icon-pack="IntakePortal"
                    icon-after
                    name="receivedDate"
                    v-model="receivedDate"
                    v-validate="'required'"
                    icon="IP-calendar-1"
                    data-vv-as="Business established date"
                    placeholder="DD/MM/YYYY"
                    :open-date="new Date(openDate)"
                    :disabled-dates="{from: new Date(startEligibleDate)}"
                  ></datepicker>
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('receivedDate.')"
                  >{{ errors.first("receivedDate.") }}</span>
                </div>

                <div class="vs-col">
                  <label class="date-picker-label">RFE Due Date</label>
                  <datepicker  :typeable="true"
                    icon-pack="IntakePortal"
                    icon-after
                    name="dueDate"
                    v-model="dueDate"
                    v-validate="'required'"
                    icon="IP-calendar-1"
                    data-vv-as="Business established date"
                    placeholder="DD/MM/YYYY"
                    :open-date="new Date(openDate)"
                    :disabled-dates="{from: new Date(startEligibleDate)}"
                  ></datepicker>
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('dueDate.')"
                  >{{ errors.first("dueDate.") }}</span>
                </div>
              </div>
              <div class="vx-col w-full upload-wrap">
                <file-upload
                  v-model="uscisdocument"
                  class="file-upload-input mb-0"
                  style="height:50px;"
                  name="trackingdoc"
                  :multiple="false"
                  v-validate="'required'"
                  data-vv-as="Forms and Letters"
                  :accept="allDocEntity"
                  @input="selectedDocuments(index, uscisdocument)"
                >
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                </file-upload>
                <span class="file-type marb15">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>

                <div
                  class="file_view"
                  v-for="(file, fileindex) in uscisdocument"
                  :key="fileindex"
                >{{file.name}}</div>
              </div>

              

              <div class="vx-col w-full">
                <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="usciscomments"
                  name="usciscomments"
                  label="Comments…"
                  class="w-full"
                />

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('uscisstatus.usciscomments')"
                >{{ errors.first("uscisstatus.usciscomments") }}</span>
              </div>
            </div>
          </div>

          <div class="popup-footer">
            <vs-button color="success" @click="petitionApproval" class="save" type="filled">Submit</vs-button>
          </div>
        </form>
      </vs-popup>

      <vs-popup
        class="holamundo main-popup filling_popup"
        title="Submit for Signing"
        :active.sync="requestsignPopup"
      >
        <!-- <vs-popup class="holamundo"  title="Lorem ipsum dolor sit amet" :active.sync="filingFeesPopup"> -->
        <form data-vv-scope="requestsignform">
          <div class="form-container padt25">
            <div class="vx-col w-full">
              <vs-textarea
                data-vv-as="Comments"
                v-validate="'required'"
                v-model="requestsignformcomments"
                name="requestsignformcomments"
                label="Comments…"
                class="w-full"
              />

              <span
                class="text-danger text-sm"
                v-show="errors.has('requestsignform.requestsignformcomments')"
              >{{ errors.first("requestsignform.requestsignformcomments") }}</span>
            </div>
          </div>

          <div class="popup-footer">
            <vs-button
              color="success"
              @click="submitpetitionrequest"
              class="save"
              type="filled"
            >Submit</vs-button>
          </div>
        </form>
      </vs-popup>

      <vs-popup
        class="holamundo main-popup filling_popup"
        title="Filing Fees"
        :active.sync="filingFeesPopup"
      >
        <form data-vv-scope="filingFeesform">
          <div class="form-container filingFeesformcontainer">
           
            <vs-row vs-w="12" v-for="(filingFee, index) in filingFeeData" :key="index">
              <vs-col vs-lg="4" vs-sm="4" vs-xs="12">
                <vx-input-group>
                  <vs-input
                    data-vv-as="Amount"
                    v-validate="'required'"
                    v-model="filingFee.amount"
                    :name="'amount'+index"
                    v-mask="'#####'"
                    label="Amount($)"
                  />
                  <vs-checkbox v-model="filingFee.invoice" :name="'invoice'+index">Exclude from invoice</vs-checkbox>
                </vx-input-group>
              </vs-col>
              <vs-col vs-lg="8" vs-sm="8" vs-xs="12">
                <label class="dec_lable">Description</label>
                <div class="dec_content">
                  <vs-textarea
                    data-vv-as="Description"
                    v-validate="'required'"
                    v-model="filingFee.description"
                    :name="'filingdescription'+index"
                    class="w-full"
                  />

                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('filingFeesform.filingdescription'+index)"
                  >{{ errors.first('filingFeesform.filingdescription'+index) }}</span>

                  <div class="delete" v-if="filingFeeData.length > 1">
                    <a @click="removefilingfee(index)">
                      <img src="@/assets/images/main/delete-row-img.svg" />
                    </a>
                  </div>
                </div>
              </vs-col>
            </vs-row>
          </div>

          <vs-col
            class="float-none padl25 padb25"
            vs-type="flex"
            vs-align="center"
            vs-lg="8"
            vs-sm="12"
          >
            <a @click="addfilingfee" class="add-more ml-0" type="filled">
              <span>+</span> More
            </a>
          </vs-col>

          <div class="popup-footer">
            <vs-button color="success" @click="submitFilingFees" class="save" type="filled">Submit</vs-button>
          </div>
        </form>
      </vs-popup>

      <vs-popup
      v-if="assigntoRolePopup"
        class="holamundo main-popup"
        :title="assigntoRoletitle"
        :active.sync="assigntoRolePopup"
      >
        <form data-vv-scope="assignroleform">
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full">
                <div class="con-select w-full select-large">
                  <multiselect
                    name="assigntorole"
                    v-validate="'required'"
                    v-model="assigntoroleModel"
                    :show-labels="false"
                    track-by="id"
                    label="name"
                    :data-vv-as="assigntoroletxt"
                    :placeholder="chooseassigntorole"
                    :options="selectedroleslist"
                    :searchable="true"
                    :allow-empty="false"
                  ></multiselect>
                </div>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('assignroleform.assigntorole')"
                >{{ errors.first("assignroleform.assigntorole") }}</span>
              </div>

              <div class="vx-col w-full">
                <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="assignedrolecomments"
                  name="assignedrolecomments"
                  label="Comments…"
                  class="w-full"
                />

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('assignroleform.assignedrolecomments')"
                >{{ errors.first("assignroleform.assignedrolecomments") }}</span>
              </div>
            </div>
            <div class="text-danger text-sm formerrors" v-show="paralegalformerrors">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >{{ paralegalformerrors }}</vs-alert>
            </div>
          </div>
          <div class="popup-footer">
            <vs-button color="success" @click="submitassignrole" class="save" type="filled">Assign</vs-button>
          </div>
        </form>
      </vs-popup>

      <vs-popup
        class="holamundo main-popup"
        :title="replaceParalegaltitle"
        :active.sync="replaceParalegal"
      >
        <form data-vv-scope="approveparalegalfoform">
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full" v-if="!approveParalegalform">
                <div class="con-select w-full select-large">
                  <multiselect
                    name="paralegal"
                    v-validate="'required'"
                    v-model="paralegalModel"
                    :show-labels="false"
                    track-by="id"
                    label="name"
                    data-vv-as="Paralegal"
                    placeholder="Choose Paralegal"
                    :options="paralegallist"
                    :searchable="true"
                    :allow-empty="false"
                  ></multiselect>
                </div>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('approveparalegalfoform.paralegal')"
                >{{ errors.first("approveparalegalfoform.paralegal") }}</span>
              </div>

              <div class="vx-col w-full">
                <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="paralegalcomments"
                  name="paralegalcomments"
                  label="Comments…"
                  class="w-full"
                />

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('approveparalegalfoform.paralegalcomments')"
                >{{ errors.first("approveparalegalfoform.paralegalcomments") }}</span>
              </div>
            </div>
            <div class="text-danger text-sm formerrors" v-show="paralegalformerrors">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >{{ paralegalformerrors }}</vs-alert>
            </div>
          </div>
          <div class="popup-footer">
            <vs-button
              color="success"
              @click="submitapproveparalegal"
              class="save"
              type="filled"
            >Assign</vs-button>
          </div>
        </form>
      </vs-popup>

      <vs-popup
        class="holamundo main-popup"
        title="Submit to Supervisor"
        :active.sync="SubmitParalegal"
      >
        <form data-vv-scope="supervisorform">
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full">
                <div class="con-select w-full select-large">
                  <label for class="vs-select--label">Supervisor</label>
                  <multiselect
                    name="supervisor"
                    v-validate="'required'"
                    v-model="supervisorMode"
                    :show-labels="false"
                    data-vv-as="Supervisor"
                    label="name"
                    placeholder="Select Supervisor"
                    :options="supervisorlist"
                    :searchable="true"
                    :allow-empty="false"
                  ></multiselect>
                </div>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('supervisorform.supervisor')"
                >{{ errors.first("supervisorform.supervisor") }}</span>
              </div>
              <div class="vx-col w-full">
                <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  name="supervisorcomments"
                  v-model="supervisorcomments"
                  label="Comments…"
                  class="w-full"
                />

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('supervisorform.supervisorcomments')"
                >{{ errors.first("supervisorform.supervisorcomments") }}</span>
              </div>
            </div>
          </div>
          <div class="popup-footer">
            <vs-button color="success" @click="assignsupervisorform" class="save" type="filled">Save</vs-button>
          </div>
        </form>
      </vs-popup>
      <vs-popup
       v-if="AssignParalegal"
        class="holamundo main-popup"
        title="Assign Paralegal"
        :active.sync="AssignParalegal"
      >
        <form data-vv-scope="paralegalfoform">
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full">
                <div class="con-select w-full select-large">
                  <label for class="vs-select--label">Paralegal</label>
                  <multiselect
                    name="paralegal"
                    v-validate="'required'"
                    v-model="paralegalModel"
                    :show-labels="false"
                    track-by="id"
                    label="name"
                    data-vv-as="Paralegal"
                    placeholder="Select Paralegal"
                    :options="paralegallist"
                    :searchable="true"
                    :allow-empty="false"
                  ></multiselect>
                </div>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('paralegalfoform.paralegal')"
                >{{ errors.first("paralegalfoform.paralegal") }}</span>
              </div>
              <div class="vx-col w-full">
                <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="paralegalcomments"
                  name="paralegalcomments"
                  label="Comments…"
                  class="w-full"
                />

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('paralegalfoform.paralegalcomments')"
                >{{ errors.first("paralegalfoform.paralegalcomments") }}</span>
              </div>
            </div>
            <div class="text-danger text-sm formerrors" v-show="paralegalformerrors">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >{{ paralegalformerrors }}</vs-alert>
            </div>
          </div>
          <div class="popup-footer">
            <vs-button
              color="success"
              @click="assignparalegalform"
              class="save"
              type="filled"
            >Assign</vs-button>
          </div>
        </form>
      </vs-popup>

      <vs-popup
       v-if="approveRejectPop"
        class="holamundo main-popup"
        v-bind:title="approveRejectTitle"
        :active.sync="approveRejectPop"
      >
        <form data-vv-scope="approverejectquestion">
          <div class="media-header" v-if="petition.beneficiaryInfo.name">
            <img src="@/assets/images/main/avatar2.svg" />
            <div class="media-content">
              <p>{{petition.beneficiaryInfo.name}}</p>
            </div>
          </div>
          <div class="form-container">
            <div v-if="approveaction" class="requestlcaform">
              <p v-if="!petition.lcaId">In Order to Submit Case, Please upload/request for LCA.</p>

              <!-- <p v-if="petition.lcaId" >LCAID ==  {{petition.lcaId }} </p> -->

              <div class="vx-row" v-if="petition.lcaId">
                <div class="vx-col w-full">
                  <vs-textarea
                    name="approveRejec_Instructions"
                    data-vv-as="Instructions"
                    class="w-full"
                    label="Comments"
                    v-model="approveRejecInstructions"
                  />
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('approverejectquestion.approveRejec_Instructions')"
                  >{{ errors.first("approverejectquestion.approveRejec_Instructions") }}</span>
                </div>
              </div>

              <vs-button
                color="success"
                v-if="petition.lcaId"
                @click="saveApproveOrreject"
                class="save"
                type="filled"
              >Send</vs-button>

              <router-link
                v-if="!petition.lcaId"
                :to="{ name: 'requestlca', params: { itemId: petition._id } }"
              >
                <button @click="approveRejectPop=false" class="btn btn-brown">Request LCA</button>
              </router-link>

              <router-link
                v-if="!petition.lcaId"
                :to="{ name: 'requestlca', params: { itemId: petition._id, upload:true } }"
              >
                <button @click="approveRejectPop=false" class="btn btn-brown">Upload LCA</button>
              </router-link>
            </div>

            <div class="vx-row" v-if="!approveaction">
              <div class="vx-col w-full">
                <vs-textarea
                  name="approveRejec_Instructions"
                  data-vv-as="Instructions"
                  class="w-full"
                  label="Comments"
                  v-model="approveRejecInstructions"
                />
                <span
                  class="text-danger text-sm"
                  v-show="errors.has('approverejectquestion.approveRejec_Instructions')"
                >{{ errors.first("approverejectquestion.approveRejec_Instructions") }}</span>
              </div>
            </div>
          </div>
          <div class="popup-footer" v-if="!approveaction">
            <vs-button
              color="dark"
              @click="approveRejectPop=false"
              class="cancel"
              type="filled"
            >Cancel</vs-button>
            <vs-button color="success" @click="saveApproveOrreject" class="save" type="filled">Send</vs-button>
          </div>
        </form>
      </vs-popup>
    </div>
  </div>
</template>
<script>
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import Vue from "vue";
import FileUpload from "vue-upload-component/src";
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import JQuery from "jquery";

export default {
  components: {
    FileUpload,
    VuePerfectScrollbar,
    Datepicker
  },
  props: {
    petition: {
      type: Object,
      default: null
    },
    currentRole: {
      type: Number,
      default: null
    }
  },
  computed: {
    checkActionconditions() {
      if(this.petition.statusId == 12){
        return false;
      }
      if (this.currentRole && this.currentRole == 7) {
        return false;
      }
      if (this.currentRole && this.currentRole == 9) {
        return false;
      }
      if (this.currentRole && this.currentRole == 6) {
        if (
          this.petition.questionnaireFilled &&
          this.petition.statusId == 1 &&
          this.petition.currentActivity != "QUESTIONNIRE_APPROVED"
        ) {
          return false;
        }
      }

      return true;
    }
  },
  methods: {},
  data: () => ({
    filingFeeData: [
      {
        amount: null,
        invoice: false,
        description: ""
      }
    ],
    tracking: {},
    uscisstatuslist: [
      {
        value: "USCIS_APPROVED",
        text: "Case Approved"
      },
      {
        value: "USCIS_RECEIVED_RFE",
        text: "RFE Received"
      },
      {
        value: "USCIS_DENIED",
        text: "Case Denied"
      }
    ],
    trackingdoc: [],
    issuedDate: null,
    receivedDate: null,
    dueCate: null,
    openDate: new Date().setFullYear(new Date().getFullYear()),
    startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
    updateTrackingPopup: false,
    updateUSCISstatusPopup: false,
    filingFeesPopup: false,
    casestatus: {},
    uscisdocument: [],
    usciscomments: "",
    requestsignPopup: false,
    assigntoRoletitle: "",
    requestsignformcomments: "",
    assigntoroletxt: "",
    chooseassigntorole: "",
    assignedRoleId: null,
    assigntoRolePopup: false,
    approvalstatus: false,
    approveaction: false,
    rolesubmitaction: "",
    replaceParalegaltitle: "Replace Paralegal",
    paralegalformerrors: "",
    supervisorcomments: "",
    assignedrolecomments: "",
    paralegalcomments: "",
    petitionhistory: [],
    SubmitParalegal: false,
    SuccessQuestionnaire: false,
    AssignParalegal: false,
    paralegalModel: [],
    assigntoroleModel: [],
    supervisorMode: [],
    paralegallist: [],
    supervisorlist: [],
    selectedroleslist: [],
    replaceParalegal: false,
    approveParalegalform: false,
    active: false,
    approveRejectPop: false,
    approveRejectTitle: "Approve Questionnire",
    approveRejecInstructions: "",
    actionType: "approved",
    is_change_paralegal: false,
    is_change_superwiser: false,
    uploadSignedPopup:false,
        documents: [],
    documentData: [
      {
        type: "Forms, Letters and Others",
        documentUploaded: []
      }
    ],
    formsData: []
  }),
  methods: {
    
    fetchSignedUrl(value) {
      value.document = value.document.replace(this.$globalgonfig._S3URL,"");
      let postdata = {
        keyName: value.document
      };
      this.$store.dispatch("getSignedUrl", postdata).then(response => {
        window.open(response.data.result.data, "_blank");
      });
    },
    remove(item, type) {
      type.splice(type.indexOf(item), 1);
      return false;
    },
         uploadFiles() {
        let formData = new FormData();
        let postData = {};
        let count = 0;
        var self = this;

        
          let payload_data = {
            petitionId: this.petition._id,
            comment: "Petition Signed"
          };
          // "action": "QUESTIONNIRE_APPROVED" // "QUESTIONNIRE_REJECTED" / "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "READY_FOR_FILING" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED"

           payload_data["action"] = "READY_FOR_FILING";

          this.$store
            .dispatch("manageApproval_process", payload_data)
            .then(response => {
          
            });


        this.documentData.documentUploaded.forEach(function(doc){
          var docsp = [];
          docsp.push(doc);
                   let uploadPayload = {
          documents: docsp,
          petitionId: self.petition._id,
        }
        self.$store.dispatch('uploadScannedCopies', uploadPayload).then(response=> {});
        })

              setTimeout(function(){

                  self.$emit("updatepetition");
             // self.showMessages(response.message);
              self.uploadSignedPopup = false;

              })
 
      },
      submitSignedDocuments(){
this.uploadSignedPopup = true;
      },
    addfilingfee: function() {
      this.filingFeeData.push({
        amount: null,
        description: ""
      });
    },
    removefilingfee: function(index) {
      Vue.delete(this.filingFeeData, index);
    },
    showfilingFeesPopup() {
      if (
        this.petition.filingFeeDetails &&
        this.petition.filingFeeDetails.amount > 0
      )
        this.filingFeeData = this.petition.filingFeeDetails.feeDetails;
      this.filingFeesPopup = true;
      //alert('dddd');
    },
    showPetitionersign() {
      this.requestsignPopup = true;
    },
    updateUSCISstatus() {
      this.updateUSCISstatusPopup = true;
    },
    updateTrackingDetails() {
      this.updateTrackingPopup = true;

             this.tracking.documents = [];
                this.uscisdocument  = [];
                this.trackingdoc  = [];
    },
    updateTracking() {
      this.tracking.petitionId = this.petition._id;
      this.tracking.action =
        this.petition.courierTrackingCategory != "UPDATE_TRACKING_NUMBER"
          ? "UPDATE_TRACKING_NUMBER"
          : "UPDATE_USCIS_RECEIPT_NUMBER";
      this.$store
        .dispatch("updateTrackingDetails", this.tracking)
        .then(response => {
          this.$emit("updatepetition");
          this.showMessages(response.message);
          this.updateTrackingPopup = false;
          this.$emit("loadstatus");
        });
    },
    assigntorole(roleId) {
      this.assigntoRolePopup = true;
      this.assignedRoleId = roleId;
      if (roleId == 9) {
        this.assigntoRoletitle = "Submit to Offshore";
        this.assigntoroletxt = "Offshore";
        this.chooseassigntorole = "Choose Offshore";
        this.rolesubmitaction = "ASSIGN_OFFSHORE_USER";
      }
      if (roleId == 5) {
        this.assigntoRoletitle = "Submit to Attorney";
        this.assigntoroletxt = "Attorney";
        this.chooseassigntorole = "Choose Attorney";
        this.rolesubmitaction = "ASSIGN_ATTORNEY";
      }
      if (roleId == 8) {
        this.assigntoRoletitle = "Submit to Offshore Manager";
        this.assigntoroletxt = "Manager";
        this.chooseassigntorole = "Choose Offshore Manager";
        this.rolesubmitaction = "ASSIGN_OFFSHORE_MANAGER";
      }
    this.selectedroleslist=[]; 
      this.$store.dispatch("getusersByrole", roleId).then(response => {
        this.selectedroleslist = response.list;
      });
    },
    submitFilingFees() {
      this.$validator.validateAll("filingFeesform").then(result => {
        if (result) {
          var postdata = {
            petitionId: this.petition._id,
            filingFeeData: this.filingFeeData
          };
          this.$store.dispatch("submitFilingFees", postdata).then(response => {
            this.$emit("updatepetition");
            this.showMessages(response.message);
            this.filingFeesPopup = false;
          });
        }
      });
    },
    submitpetitionrequest() {
      var postdata = {
        petitionId: this.petition._id,
        comments: this.requestsignformcomments
      };

      this.$store.dispatch("requestforsign", postdata).then(response => {
        this.$emit("updatepetition");
        this.showMessages(response.message);
        this.requestsignPopup = false;
      });
    },
    addfilingfee: function() {
      this.filingFeeData.push({
        amount: null,
        description: ""
      });
    },
    removefilingfee: function(index) {
      Vue.delete(this.filingFeeData, index);
    },
    submitassignrole() {
      this.$validator.validateAll("assignroleform").then(result => {
        if (result) {
          var postdata = {
            petitionId: this.petition._id,
            userId: this.assigntoroleModel._id,
            userName: this.assigntoroleModel.name,
            roleId: this.assignedRoleId,
            typeName: this.petition.typeDetails.name,
            subTypeName: this.petition.subTypeDetails.name,
            comment: this.assignedrolecomments,
            action: this.rolesubmitaction,
            submitted: true
          };

          this.$store.dispatch("assigntoarole", postdata).then(response => {
            this.$emit("updatepetition");
            this.showMessages(response.message);
            this.assigntoRolePopup = false;
          });
        }
      });
    },
    change_superwiser() {
      if (this.currentRole == 5) {
        this.SubmitParalegal = true;
        this.is_change_superwiser = true;
      }
    },
    change_paralegal() {
      if (this.currentRole == 5 || this.currentRole == 3) {
        this.replaceParalegaltitle = "Replace Paralegal";
        this.replaceParalegal = true;
        this.approveParalegalform = false;
        this.is_change_paralegal = true;
      }

      //alert("change_paralegal");
    },

    replaceparalegal() {
      this.replaceParalegaltitle = "Replace Paralegal";
      this.replaceParalegal = true;
      this.approveParalegalform = false;
      this.is_change_paralegal = false;
    },
    approveparalegal() {
      this.replaceParalegaltitle = "Approve Paralegal";
      this.replaceParalegal = true;
      this.approveParalegalform = true;
    },
    submitapproveparalegal() {
      this.$validator.validateAll("approveparalegalfoform").then(result => {
        if (result) {
          var paralegalid = this.petition.paralegalDetails._id;
          var userName = this.petition.paralegalDetails.name;
          if (
            this.paralegalModel != null &&
            this.approveParalegalform == false
          ) {
            paralegalid = this.paralegalModel._id;
            userName = this.paralegalModel.name;
          }
          var postdata = {
            petitionId: this.petition._id,
            userId: this.petition.paralegalDetails._id,
            userName: this.petition.paralegalDetails.name,
            roleId: 4,
            typeName: this.petition.typeDetails.name,
            subTypeName: this.petition.subTypeDetails.name,
            comment: this.supervisorcomments,
            action: "ASSIGN_PARALEGAL",
            submitted: true
          };

          if (this.is_change_paralegal) {
            //alert("ACTION");
            postdata["userId"] = this.paralegalModel._id;
            postdata["userName"] = this.paralegalModel.name;
            postdata["typeName"] = this.paralegalModel.roleDetails[0]["name"];
            postdata["action"] = "REPLACE_PARALEGAL";
            postdata["lastUserName"] = this.petition.paralegalDetails.name;
            //return false;
          }
          //petition/assign-a-role

          this.$store.dispatch("assigntoarole", postdata).then(response => {
            this.$emit("updatepetition");
            this.showMessages(response.message);
            this.replaceParalegal = false;
          });
        }
      });
    },
    assignparalegalform() {
      this.$validator.validateAll("paralegalfoform").then(result => {
        if (result) {
          var postdata = {
            petitionId: this.petition._id,
            userId: this.paralegalModel._id,
            userName: this.paralegalModel.name,
            roleId: 4,
            typeName: this.petition.typeDetails.name,
            subTypeName: this.petition.subTypeDetails.name,
            comment: this.supervisorcomments,
            action: "ASSIGN_PARALEGAL"
          };

          this.$store.dispatch("assigntoarole", postdata).then(response => {
            this.$emit("updatepetition");
            this.showMessages(response.message);
            this.AssignParalegal = false;
          });
        }
      });
    },

    assignsupervisorform() {
      this.$validator.validateAll("supervisorform").then(result => {
        if (result) {
          var postdata = {
            petitionId: this.petition._id,
            userId: this.supervisorMode._id,
            userName: this.supervisorMode.name,
            roleId: 3,
            typeName: this.petition.typeDetails.name,
            subTypeName: this.petition.subTypeDetails.name,
            comment: this.paralegalcomments,
            action: "ASSIGN_SUPERVISOR",
            submitted: true
          };

          this.$store.dispatch("assigntoarole", postdata).then(response => {
            this.$emit("updatepetition");
            this.showMessages(response.message);
            this.SubmitParalegal = false;
          });
        }
      });
    },
    approveOrreject(action_type = 1) {
      this.approveRejectTitle = "Approve Questionnaire";
      this.actionType = "approved";
      this.approveRejecInstructions = "";

      this.actionType = 1;
      if (action_type == "approved") {
        this.actionType = "approved";
        this.approveRejectTitle = "Approve Questionnaire";
        this.approveaction = true;
        this.$emit("passparent", 3);
      }
      if (action_type == "rejected") {
        this.actionType = "rejected";
        this.approveRejectTitle = "Reject Questionnaire";
        this.approveaction = false;
        this.approveRejectPop = true;
      }
    },
    saveApproveOrreject() {
      //alert(this.approveRejecInstructions);

      this.$validator.validateAll("approverejectquestion").then(result => {
        if (result) {
          // this.approveRejec_Instructions="* Instructions is required"

          let payload_data = {
            petitionId: this.petition._id,
            comment: this.approveRejecInstructions
          };
          // "action": "QUESTIONNIRE_APPROVED" // "QUESTIONNIRE_REJECTED" / "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "READY_FOR_FILING" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED"

          if (this.actionType == "approved") {
            payload_data["action"] = "QUESTIONNIRE_APPROVED";
          } else {
            payload_data["action"] = "QUESTIONNIRE_REJECTED";
          }
          this.$store
            .dispatch("manageApproval_process", payload_data)
            .then(response => {
              this.$emit("updatepetition");
              this.showMessages(response.message);
              this.approveRejectPop = false;
            });
        }
      });
    },
    petitionApproval() {
      //alert(this.approveRejecInstructions);

      this.$validator.validateAll("uscisstatus").then(result => {
        if (result) {
          // this.approveRejec_Instructions="* Instructions is required"

          let payload_data = {
            petitionId: this.petition._id,
            comment: this.usciscomments,
            action: this.casestatus.value
          };

          let rfepayload = {
            petitionId: this.petition._id,
             comment: this.usciscomments,
            description: this.usciscomments,
                        action: this.casestatus.value

          };
          // "action": "QUESTIONNIRE_APPROVED" // "QUESTIONNIRE_REJECTED" / "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "READY_FOR_FILING" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED"

          if (this.casestatus.value == "USCIS_RECEIVED_RFE") {
            payload_data["today"] = moment().format("YYYY-MM-DD");
            payload_data["typeName"] = this.petition.typeDetails.name;
            payload_data["subTypeName"] = this.petition.subTypeDetails.name;

      rfepayload["today"] = moment().format("YYYY-MM-DD");
            rfepayload["typeName"] = this.petition.typeDetails.name;
            rfepayload["subTypeName"] = this.petition.subTypeDetails.name;

            rfepayload["issuedDate"] = moment(this.issuedDate).format(
              "YYYY-MM-DD"
            );
            rfepayload["receivedDate"] = moment(this.receivedDate).format(
              "YYYY-MM-DD"
            );
            rfepayload["dueDate"] = moment(this.dueDate).format("YYYY-MM-DD");
           rfepayload["documents"] = this.uscisdocument;

          }
          this.$store
            .dispatch("manageApproval_process", rfepayload)
            .then(response => {
              this.$store.dispatch("fileRFE", rfepayload).then(response => {
                this.$emit("updatepetition");
                this.showMessages(response.message);
                this.updateUSCISstatusPopup = false;
              });
            });
        }
      });
    },
    gethistory() {
      this.$store
        .dispatch("petitionhistory", this.petition._id)
        .then(response => {
          this.petitionhistory = response.result.list;
        });
    },
    reloadPetition() {
      this.$store.dispatch("getpetition", this.petition._id).then(response => {
        this.petition = response.data.result;
        if (this.petition.lcaId != null) {
          this.$store
            .dispatch("fetchLcaDetails", this.petition.lcaId)
            .then(response => {
              this.lcaDetails = response.data.result;
            });
        }

      let postDt = {userId:'' ,isRfeCase:false}
      if(_.has(this.petition ,"rfeCase" )){
        postDt['isRfeCase'] = this.petition['rfeCase']
      }
      postDt['userId'] = this.petition['userId'];
        this.$store
          .dispatch("getpetitionsdropdown", postDt)
          .then(response => {
            this.petitions = response;
          });
      });
      this.$store.dispatch("petitionhistory", petitionId).then(response => {
        this.petitionhistory = response.result.list;
      });
    },
    showMessages(message) {
      this.$vs.notify({
        title: "Success",
        position: "top-right",
        color: "success",
        iconPack: "feather",
        icon: "icon-check",
        text: message
      });
    },
    selectedDocuments(index, docs) {
      let formData = new FormData();
      docs = docs.map(
        item =>
          (item = {
            name: item.name,
            file: item.file,
            url: "",
            path:'',
            mimetype: item.type
          })
      );

      if (docs.length > 0) {
        var self = this;
        docs.forEach(function(doc) {
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          self.$store.dispatch("uploadS3File", formData).then(response => {
            if (response.data && response.data.result) {
              response.data.result.forEach(urlGenerated => {
                doc.url = urlGenerated;
                doc.path = urlGenerated;
                delete doc.file;
                self.tracking.documents = docs;
                self.uscisdocument = docs;
                self.trackingdoc = docs;
                self.documentData.documentUploaded = docs;
              });
            }
          });
        });
      }
    }
  },
  mounted() {
    this.$store.dispatch("getusersByrole", 4).then(response => {
      this.paralegallist = response.list;
    });
    this.$store.dispatch("getusersByrole", 3).then(response => {
      this.supervisorlist = response.list;
    });

    this.gethistory();
    setTimeout(function(){
      if( JQuery('.actions-content').find('li').length > 0){
      JQuery('.flowdropdown').show();

      }else{

         JQuery('.flowdropdown').hide();
      }
    },500)
  }
};
</script>