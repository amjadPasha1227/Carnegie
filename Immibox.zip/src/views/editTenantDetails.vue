<template>
    <div>

      <div class="form_section">
      <div class="form-container">

        <div class="vx-row">
            <template >
            <div class="vx-col md:w-1/2 w-full" >
            <div class="form_group">
                <label class="form_label">Sub Domain Name<em>*</em></label>
                <div class="sub_domain">
                  <vs-input type="text" 
                  :disabled=" false && checkProperty(tenantDetails , 'profCompleted') =='Yes'"
                  oninput="this.value = this.value.replace(/[^a-z A-Z 0-9 .]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                  v-model="updateTenantData.slug" class="w-full "
                  name="subDomain" ref="subDomain" autocomplete="off" autocorrect="off"
                  autocapitalize="none" v-validate="'required|min:4|max:15'" data-vv-as="Sub Domain Name" />
                  <p>.immibox.com</p>
                </div>
                
                <span class="text-danger text-sm" v-show="errors.has('subDomain')">{{ errors.first("subDomain") }}</span>
            </div>
            </div>
            <div class="vx-col w-1/2" >
            <div class="form_group">
              <label class="form_label">Company Short Code<em>*</em></label>
                <vs-input type="text" 
                :disabled="checkProperty(tenantDetails , 'profCompleted') =='Yes'"
                oninput="this.value = this.value.replace(/[^a-z A-Z 0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                v-model="updateTenantData.idPrefix" class="w-full"
                name="company_short_code" ref="company_short_code" autocomplete="off" autocorrect="off"
                autocapitalize="none" v-validate="'required|min:3|max:15'" data-vv-as="Company Short Code" />
                <span class="text-danger text-sm" v-show="errors.has('company_short_code')">{{ errors.first("company_short_code") }}</span>
            </div>
            </div>
        </template>
        </div>
        <div class="vx-row">
          <div class="vx-col md:w-1/2 w-full" @click="documents=[]">
              <div class="form_group file_group">
              <div class="vs-component">
              <label class="form_label">Logo</label>
              <file-upload v-model="documents" class="file-upload-input"
          name="logo" data-vv-as="Logo" :multiple="false"
          :accept="imageDocEntity"
              @input="upload(documents ,'logo')">
              <img class="file-icon" src="@/assets/images/main/upload-big-arrow.svg"> Upload Logo
              </file-upload>
              </div> 
              <img class="file-icon upload-logo"  v-if="updateTenantData.logo" :src="updateTenantData.logo"  @click="remove('logo')">
              <span class="text-danger text-sm" v-show="errors.has('logo')">{{ errors.first("logo") }}</span>
              </div>              
          </div>
      
            <div class="vx-col md:w-1/2  w-full" @click="documents=[]">
              <div class="form_group file_group">
                  <div class="vs-component">
                      <label class="form_label">Favicon</label>
                      <file-upload v-model="documents" class="file-upload-input"
                      name="favicon" data-vv-as="Favicon" :multiple="false"
                      :accept="imageDocEntity"
                      @input="upload(documents ,'favicon')">
                      <img class="file-icon " src="@/assets/images/main/upload-big-arrow.svg"> Upload Favicon
                      </file-upload>
                  </div> 
                  <img v-if="updateTenantData.favicon" class="file-icon upload-favicon" :src="updateTenantData.favicon" @click="remove('favicon')" >
                    <span class="text-danger text-sm" v-show="errors.has('logo')">{{ errors.first("logo") }}</span>
              </div>              
            </div>
        </div> 
        <div class="vx-row">
          
            <div class="vx-col md:w-1/2 w-full" > 
              <div class="form_group">
                <label class="form_label">Admin Email</label>
                <vs-input autocomplete="off" autocorrect="off" :disabled="true"  name="adminEmail" v-model="updateTenantData.adminEmail" class="w-full"
                  data-vv-as="Admin Email"/>
                <span class="text-danger text-sm" v-show="errors.has('adminEmail')">{{ errors.first("adminEmail") }}</span>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" > 
              <div class="form_group">
                <label class="form_label">Name</label>
                <vs-input  autocomplete="off" autocorrect="off"  :disabled="true"  name="name" v-model="updateTenantData.name" class="w-full"
                  data-vv-as="Name"   />
                <span class="text-danger text-sm"
                  v-show="errors.has('Name')">{{ errors.first("Name") }}</span>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" > 
              <div class="form_group">
                <label class="form_label">First Name<em>*</em></label>
                <vs-input  autocomplete="off" autocorrect="off" v-validate="'required'"  name="adminFirstName" v-model="updateTenantData.adminFirstName" class="w-full"
                  data-vv-as="First Name"   />
                <span class="text-danger text-sm"
                  v-show="errors.has('adminFirstName')">{{ errors.first("adminFirstName") }}</span>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" > 
              <div class="form_group">
                <label class="form_label">Last Name<em>*</em></label>
                <vs-input  autocomplete="off" autocorrect="off" v-validate="'required'"   name="adminLastName" v-model="updateTenantData.adminLastName" class="w-full"
                  data-vv-as="Last Name" />
                <span class="text-danger text-sm"
                  v-show="errors.has('adminLastName')">{{ errors.first("adminLastName") }}</span>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" > 
              <div class="form_group">
                <label class="form_label">From Email<em>*</em></label>
                <vs-input  autocomplete="off" autocorrect="off"   name="fromEmail" v-model="updateTenantData.fromEmail" class="w-full"
                  data-vv-as="From Email" v-validate="'required|email'" />
                <span class="text-danger text-sm"
                  v-show="errors.has('fromEmail')">{{ errors.first("fromEmail") }}</span>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" > 
              <div class="form_group">
                <label class="form_label">Contact Email<em>*</em></label>
                <vs-input   autocomplete="off" autocorrect="off"  name="contactEmail" v-model="updateTenantData.contactEmail" class="w-full"
                  data-vv-as="Contact Email"  v-validate="'required|email'" />
                <span class="text-danger text-sm"
                  v-show="errors.has('contactEmail')">{{ errors.first("contactEmail") }}</span>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" > 
              <div class="form_group ph_number">
                <div class="vs-component"> 
              <label class="form_label">Phone Number<em>*</em></label>
                  <VuePhoneNumberInput
                                              icon-pack="feather"
                                              class="w-full no-icon-border"
                                              :no-example="false"
                                              v-validate="'required'"
                                              v-bind="vuePhone.props"
                                              name="phone"
                                              data-vv-as="Phone Number"
                                              :default-country-code="checkProperty(updateTenantData['phoneCountryCode'] ,'countryCode')"
                                              placeholder="Phone Number"
                                              :no-country-selector="false"
                                            v-model="updateTenantData.phone" 
                                              @update="updatePhone"
                                              :preferred-countries="['US', 'IN']"
                                              /> 
                  <span class="text-danger text-sm"  v-show="errors.has('phone')">{{ errors.first("phone") }}</span>
                </div>
              </div>
            </div>
          
          
        
          
        </div>
          
          <h3 class="small-header"> Address</h3>
          <div class="vx-row">

            <div class="vx-col md:w-1/2 w-full" > 
              <div class="form_group">
                <label class="form_label">Street Address<em>*</em></label>
                <vs-input  autocomplete="off" autocorrect="off"   name="address1" v-model="updateTenantData.address.line1" class="w-full"
                  data-vv-as="Street Address" v-validate="'required'" />
                <span class="text-danger text-sm" v-show="errors.has('address1')">{{ errors.first("address1") }}</span>
              </div>
            </div>

            <div class="vx-col md:w-1/2 w-full" > 
              <div class="form_group">
                <label class="form_label">Apt, Suite</label>
                <vs-input   name="address2" v-model="updateTenantData.address.line2" class="w-full"
                  data-vv-as="Apt, Suite"    />
                <span class="text-danger text-sm"
                  v-show="errors.has('address2')">{{ errors.first("address2") }}</span>
              </div>
            </div>

            <div class="vx-col md:w-1/2 w-full"   >
              <div class="form_group">
                <div class="con-select w-full select-large">
                  <label for class="form_label">Country<em>*</em></label>
                  <multiselect name="spouseaddresscountry"   v-model="updateTenantData.address.selectedCountry"
                    @input="changedCountry" :show-labels="false" track-by="id" label="name"
                    data-vv-as="Country" v-validate="'required'"  placeholder="Select Country" :options="countries" :searchable="true"
                    :allow-empty="false"></multiselect>                    
                </div>
                <span class="text-danger text-sm" v-show="errors.has('spouseaddresscountry')">{{ errors.first("spouseaddresscountry") }}</span>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full"  >
              <div class="form_group">
                <div class="con-select w-full select-large">
                  <label class="form_label">State<em>*</em></label>
                  <multiselect name="State"   v-model="updateTenantData.address.selectedState"
                    @input="changedState" :show-labels="false" track-by="id" label="name" data-vv-as="State"
                    placeholder="Select State" :options="states" :searchable="true" :allow-empty="false"  v-validate="'required'" >
                  </multiselect>
                </div>
                <span class="text-danger text-sm" v-show="errors.has('State')">{{ errors.first("State") }}</span>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full"  >
            <div class="form_group">
              <div class="con-select w-full select-large">
                <label for class="vs-select--label">City<em>*</em></label>
                <multiselect name="city"   v-model="updateTenantData.address.selectedCity"
                @input="changedCity"
                v-validate="'required'"
                :show-labels="false" track-by="id" label="name" data-vv-as="City"
                  placeholder="Select City" :options="locations" :searchable="true" :allow-empty="false">
                </multiselect>
              </div>

              <span class="text-danger text-sm" v-show="errors.has('city')">{{ errors.first("city") }}</span>
            </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" >
              <div class="form_group">
                <label for class="vs-select--label">Zip Code<em>*</em></label>
              <vs-input name="zipcode" v-model="updateTenantData.address.zipcode"
                v-validate="'numeric|required|min:5|max:6'" class="w-full" data-vv-as="Zip Code"
                oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                placeholder="Zip Code" />

              <span class="text-danger text-sm" v-show="errors.has('zipcode')">{{ errors.first("zipcode") }}</span>
              </div>
            </div>
            
            

          </div>
      </div>
      <div class="form-footer">
          <button v-if="updateTenantData.profComplted =='Yes'"  @click="completeTenantprofile=false"  class="cancel">Cancel</button>
          <button class="save" :disabled="validateTenantData || formSubmited"   @click="updateTenantProfile()"> Update</button>
     </div>
      </div>
       

    </div>


</template>

<script>


import moment from "moment";
import Datepicker from "vuejs-datepicker-inv";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';  
import FileUpload from "vue-upload-component/src";
import * as _ from "lodash";

export default {
  name: "the-navbar",
  props: {
    navbarColor: {
      type: String,
      default: "#fff",
    },
  },
  data() {
    return {
      formSubmited:false,
      showIncompleteCheckListTxt:true,
      isloading:false,
      documents:[],
     countries:[],
     states:[],
     locations:[],
     formerrors: {
        msg: ""
      },
      vuePhone:{
        props:{
          translations:{
            phoneNumberLabel:"Phone Number"
          }
        }

      },
      tenantDetails:null,
      updateTenantData:{
      "profComplted":"no",
		  "tenantId": "",
    	"name": "",
      "adminEmail":'',
		  "adminFirstName":"",
		  "adminLastName":"",
		  "phone": "",
		  "phoneCountryCode": {countryCode:'',countryCallingCode:''},
		  "logo": "",
		 "favicon": "",
		 "fromEmail": "",
		 "contactEmail": "",
     "idPrefix": "",
		 "slug": "",
		 "assetPath": "",
		"address": {
        "line1" : "",
        "line2" : "",
        "countryId" : '',
        "stateId" : '',
        "locationId" : '',
        "zipcode" : ""
		}
	    },
      completeTenantprofile:false,
      
     
      autoApply: "",
      reminderCount: 0,
      disable_reminder_btn: false,
      delNotification:{"notifyId": '' , 'removeAll':false},
      deleteAllConform:false,
      notification_popuptitle:'Delete',
      companyDetails:null,
      updateCompanyData: {
        "companyId":"",
        "email":'',
        "name": "",
        "phone":"",
        "phoneCountryCode":{countryCode:'',countryCallingCode:''},
        "fax":"",
        "faxCountryCode":{countryCode:'',countryCallingCode:''},
        "irstaxId":"",
        "naicsCode":"",
        "address": {
          "line1": "",
          "line2": "",
          "locationId":0 ,
          "stateId":0 ,
          "countryId":0 ,
          "zipcode": ""
        },
        "authorizedSignatory": { 
          "name":'',
          "firstName": "",
          "lastName": "",
          "title": "",
          "email": "",
          "phone": "",
          "phoneCountryCode":{countryCode:'',countryCallingCode:''}
        },
        "natureOfBusiness":"",
        "businessEstdDate":"",
        "totalFullTimeEmployees":"",
        "are50orMoreEmployeesInUS":"no",
        "areAbove50PercentH1BL1ALABStatus":"no",
        "finalDeterminationFromDOL":"no",
        "estimatedNetAnualIncome":2342.55,
        "estimatedGrossAnualIncome":2342.55,
        "logo": "https://innvectra.rmtportal.com/logo.png",
        //"completeRegistration": true // it should be true only if it is petitioner
	    }
    };
  },
  watch: {
    $route() {
      
      this.isTenantProfileCompleted;
     
      this.formSubmited =false;

     
      
    },
  },
  mounted() {
    this.masterData("countries");
    this.pageTitle = this.$route.meta.title;
    
   
    if(this.getUserRoleId ==3 && _.has(this.getUserData , 'tenantDetails')){
        this.getTenantDetails();
        
    }
    
    
     
  },
  computed: {
    
    isValidURL() {
        var res = this.updateTenantData.slug.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g);
        return (res !== null)
    },
    isTenantProfileCompleted(){
       
      if(this.getUserRoleId ==3){
        if(this.$store.getters['isTenantProfileCompleted']){
          this.$modal.hide('updateTenantProfile-modal');
        }
        return  this.$store.getters['isTenantProfileCompleted']?false:true;
      }else{
        return false;
      }
      
    },
    
    validateTenantData(){
      /*
      updateTenantData:{
		  "tenantId": "",
    	"name": "",
		  "adminFirstName":"",
		  "adminLastName":"",
		  "phone": "",
		  "phoneCountryCode": "",
		  "logo": "",
		 "favicon": "test/favicon.ico",
		 "fromEmail": "contact-test@yopmail.com",
		 "contactEmail": "info-test@yopmail.com",
     "idPrefix": "",
		 "slug": "",
		 "assetPath": "",
		"address": {
        "line1" : "",
        "line2" : "",
        "countryId" : '',
        "stateId" : '',
        "locationId" : '',
        "zipcode" : ""
		}
	    }
      */
      if(
        ( 
           ( !(_.has(this.updateTenantData ,'name')) || !this.updateTenantData.name.trim())
       ||  ( !(_.has(this.updateTenantData ,'adminEmail')) || !this.updateTenantData.adminEmail.trim())    
       || !(_.has(this.updateTenantData ,'adminFirstName')) || !this.updateTenantData.adminFirstName.trim())
       || ( !(_.has(this.updateTenantData ,'adminLastName')) || !this.updateTenantData.adminLastName.trim())
       ||  ( !(_.has(this.updateTenantData ,'adminLastName')) || !this.updateTenantData.adminLastName.trim())
       ||  ( !(_.has(this.updateTenantData ,'phone')) || !this.updateTenantData.phone)
       ||  ( !(_.has(this.updateTenantData ,'logo')) || !this.updateTenantData.logo.trim())
       ||  ( !(_.has(this.updateTenantData ,'favicon')) || !this.updateTenantData.favicon.trim())
       ||  ( !(_.has(this.updateTenantData ,'fromEmail')) || !this.updateTenantData.fromEmail.trim())
       ||  ( !(_.has(this.updateTenantData ,'contactEmail')) || !this.updateTenantData.contactEmail.trim())
       ||  ( !(_.has(this.updateTenantData ,'slug')) || !this.updateTenantData.slug.trim())
       ||  ( !(_.has(this.updateTenantData ,'idPrefix')) || !this.updateTenantData.idPrefix.trim())
       ||  ( !(_.has(this.updateTenantData ,'address')) || !this.updateTenantData.address)
       ||  ( !(_.has(this.updateTenantData['address'] ,'line1')) || !this.updateTenantData['address'].line1)
       ||  ( !(_.has(this.updateTenantData['address'] ,'line2')) || !this.updateTenantData['address'].line2)
       ||  ( !(_.has(this.updateTenantData['address'] ,'countryId')) || !this.updateTenantData['address'].countryId)
       ||  ( !(_.has(this.updateTenantData['address'] ,'stateId')) || !this.updateTenantData['address'].stateId)
       ||  ( !(_.has(this.updateTenantData['address'] ,'locationId')) || !this.updateTenantData['address'].locationId)
       ||  ( !(_.has(this.updateTenantData['address'] ,'zipcode')) || !this.updateTenantData['address'].zipcode)

      ){
        return true;
      }else{
        return false;
      }

    },
   
  },
  methods: {
       
    getTenantDetails(){
      let postData = {
          tenantId : this.getUserData['tenantDetails']['_id']
        }
        this.$store.dispatch("get_tenant_details", postData)
              .then(response => {
                this.tenantDetails= response;
                this.initTenantProfileData();
                this.isTenantProfileCompleted;
    
               
              })
               .catch(error => {
                  this.showToster({message:error,isError:true });
              })

    },
    updatePhone(item) {
         
       
      if (item.isValid) {
        
       this.updateTenantData.phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
       this.updateTenantData.phone = item.nationalNumber;
       
      }
     },
    initTenantProfileData(){
      if(this.getUserRoleId ==3 && _.has(this.getUserData , 'tenantDetails')){
      let tempupdateTenantData = this.updateTenantData;
      let tenantDetails = this.getUserData['tenantDetails'];

     let address = {line1:"" , line2:"",countryId:'' ,selectedCountry:null ,stateId:'',selectedState:null,locationId:'',selectedCity:null ,zipcode:''};
      
      //	"name": "",
     // "adminEmail":'',

     if( (_.has(this.tenantDetails ,'name')) && tenantDetails.name.trim()){
          tempupdateTenantData['name'] = this.tenantDetails.name.trim()

      }
      if( (_.has(this.tenantDetails ,'adminEmail')) && tenantDetails.adminEmail.trim()){
          tempupdateTenantData['adminEmail'] = this.tenantDetails.adminEmail.trim()

      }
      if( (_.has(this.tenantDetails ,'adminFirstName')) && tenantDetails.adminFirstName.trim()){
          tempupdateTenantData['adminFirstName'] = this.tenantDetails.adminFirstName.trim()

      }
       if( (_.has(this.tenantDetails ,'adminLastName')) && tenantDetails.adminLastName.trim()){
          tempupdateTenantData['adminLastName'] = this.tenantDetails.adminLastName.trim()

      }
       if( (_.has(this.tenantDetails ,'phone')) && tenantDetails.phone){
          tempupdateTenantData['phone'] = this.tenantDetails.phone;

      }
       if( (_.has(this.tenantDetails ,'phoneCountryCode')) && tenantDetails.phoneCountryCode){
          tempupdateTenantData['phoneCountryCode'] = this.tenantDetails.phoneCountryCode;

      }
      
      if( (_.has(this.tenantDetails ,'logo')) && tenantDetails.phone){
          tempupdateTenantData['logo'] = this.tenantDetails.logo;

      }
      if( (_.has(this.tenantDetails ,'favicon')) && tenantDetails.favicon){
          tempupdateTenantData['favicon'] = this.tenantDetails.favicon;

      }
      if( (_.has(this.tenantDetails ,'fromEmail')) && tenantDetails.fromEmail){
          tempupdateTenantData['fromEmail'] = this.tenantDetails.fromEmail;

      }
      if( (_.has(this.tenantDetails ,'contactEmail')) && tenantDetails.contactEmail){
          tempupdateTenantData['contactEmail'] = this.tenantDetails.contactEmail;

      }
      if( (_.has(this.tenantDetails ,'contactEmail')) && tenantDetails.contactEmail){
          tempupdateTenantData['contactEmail'] = this.tenantDetails.contactEmail;

      }
      if( (_.has(this.tenantDetails ,'slug')) && tenantDetails.slug){
          tempupdateTenantData['slug'] = this.tenantDetails.slug;

      }
      if( (_.has(this.tenantDetails ,'idPrefix')) && tenantDetails.idPrefix){
          tempupdateTenantData['idPrefix'] = this.tenantDetails.idPrefix;

      }
      if( (_.has(this.tenantDetails ,'idPrefix')) && tenantDetails.idPrefix){
          tempupdateTenantData['idPrefix'] = this.tenantDetails.idPrefix;

      }
      
      
      if(_.has(this.tenantDetails ,'address' )){


         tempupdateTenantData['address']= address;
        if(_.has(this.tenantDetails['address'] ,"line1")){
          tempupdateTenantData['address']["line1"] = tenantDetails['address']['line1'];
        }
        if(_.has(this.tenantDetails['address'] ,"line2")){
          tempupdateTenantData['address']["line2"] = tenantDetails['address']['line2'];
        }
        if(_.has(this.tenantDetails['address'] ,"countryId")){
          tempupdateTenantData['address']["countryId"] = tenantDetails['address']['countryId'];
          if(this.countries.length>=0){
            tempupdateTenantData['address']['selectedCountry'] = _.find(this.countries,{"id":tempupdateTenantData['address']["countryId"]})
            this.changedCountry();
          }
        }
        if(_.has(this.tenantDetails['address'] ,"stateId")){
          tempupdateTenantData['address']["stateId"] = tenantDetails['address']['stateId'];
        }
        if(_.has(this.tenantDetails['address'] ,"locationId")){
          tempupdateTenantData['address']["locationId"] = tenantDetails['address']['locationId'];
        }
        if(_.has(this.tenantDetails['address'] ,"zipcode")){
          tempupdateTenantData['address']["zipcode"] = tenantDetails['address']['zipcode'];
        }

      }else{
        tempupdateTenantData['address'] = address;
      }

      
      if( (_.has(this.tenantDetails ,'_id')) && tenantDetails._id){
          tempupdateTenantData['tenantId'] = this.tenantDetails._id;

      }

      tempupdateTenantData =Object.assign(tempupdateTenantData ,{'profComplted':'no'})
      if(_.has(this.tenantDetails ,'profComplted')){
        tempupdateTenantData['profComplted'] = tenantDetails['profComplted'];

      }

      this.updateTenantData = tempupdateTenantData;

        

      if(
    
      /*
       ( !(_.has(this.updateTenantData ,'adminFirstName')) || !this.updateTenantData.adminFirstName.trim())
       || ( !(_.has(this.updateTenantData ,'adminLastName')) || !this.updateTenantData.adminLastName.trim())
       ||  ( !(_.has(this.updateTenantData ,'phone')) || !this.updateTenantData.phone)
       ||  ( !(_.has(this.updateTenantData ,'logo')) || !this.updateTenantData.logo.trim())
       ||  ( !(_.has(this.updateTenantData ,'favicon')) || !this.updateTenantData.favicon.trim())
       ||  ( !(_.has(this.updateTenantData ,'fromEmail')) || !this.updateTenantData.fromEmail.trim())
       ||  ( !(_.has(this.updateTenantData ,'contactEmail')) || !this.updateTenantData.contactEmail.trim())
       ||
       */
       ( !(_.has(this.tenantDetails ,'profComplted')) || !tenantDetails.profComplted.trim() ||  tenantDetails.profComplted.toLowerCase() !="yes")
       //||  ( !(_.has(this.updateTenantData ,'slug')) || !this.updateTenantData.slug.trim())
       //||  ( !(_.has(this.updateTenantData ,'idPrefix')) || !this.updateTenantData.idPrefix.trim())
       /*
       ||  ( !(_.has(this.updateTenantData ,'address')) || !this.updateTenantData.address)
       ||  ( !(_.has(this.updateTenantData['address'] ,'line1')) || !this.updateTenantData['address'].line1)
       ||  ( !(_.has(this.updateTenantData['address'] ,'line2')) || !this.updateTenantData['address'].line2)
       ||  ( !(_.has(this.updateTenantData['address'] ,'countryId')) || !this.updateTenantData['address'].countryId)
       ||  ( !(_.has(this.updateTenantData['address'] ,'stateId')) || !this.updateTenantData['address'].stateId)
       ||  ( !(_.has(this.updateTenantData['address'] ,'locationId')) || !this.updateTenantData['address'].locationId)
       ||  ( !(_.has(this.updateTenantData['address'] ,'zipcode')) || !this.updateTenantData['address'].zipcode)
       */

      ){
         this.completeTenantprofile =true;
      }

      

    }
    this.$validator.reset();
    },
    updateTenantProfile(){
       //alert(JSON.stringify(this.updateTenantData))
       this.$validator.validateAll().then(result => {
         if(result){
          let postData = _.cloneDeep(this.updateTenantData);
         
           if(this.updateTenantData.profComplted !='Yes'){
            // this.updateTenantData.profComplted ="Yes";
             postData = Object.assign(postData ,{"assetPath":postData['slug'].trim() ,"profComplted":'Yes',"profCompleted":"Yes"})

           }
           this.formSubmited =true;
           //alert();
           //return false;
           this.$store.dispatch("updateTenantProfile" ,postData)
           .then(response => {
              this.showToster({message:response.message,isError:false });
              this.completeTenantprofile =false;
              this.getTenantDetails();
               this.isTenantProfileCompleted;
               this.formSubmited =false;
           })
           .catch(error =>{
             this.formSubmited =false;
              this.showToster({message:error,isError:true });
           })
         }
       });
    },
     upload(files , type="logo") {
        let model = _.cloneDeep(files);
        this.documents =[];  
        this.loading = true;
        let formData = new FormData();
        let temp_count = 0;
        let mapper = model.map(
              item =>
              (item = {
                  name: item.name,
                  file: item.file ? item.file : null,
                  path: item.url ? item.url : "",
                  url:item.url ? item.url : "",
                  extn: item.name.split('.').pop(),
                  mimetype: item.type ? item.type : item.mimetype,
                  uploadedBy:this.checkProperty(this.getUserData,'userId'),
                  uploadedByName:this.checkProperty(this.getUserData,'name'),
                  uploadedByRoleId:this.getUserRoleId,
                  uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
                  
              })
          );
         
        if (mapper.length > 0) {
            this.isloading = true;
            
            mapper.forEach((doc, index) => {
                formData.append('files', doc.file);
                formData.append('secureType', 'public');
                this.$store.dispatch("uploadS3File", formData).then(response => {
                    temp_count++;
                   // alert(type) updateCompanyData
                    response.data.result.forEach(urlGenerated => {
                      
                        
                        if(this.getUserRoleId ==12){
                            if(type=="logo"){
                          this.updateCompanyData = Object.assign(this.updateCompanyData,{"logo":urlGenerated})
                        }else{
                         // alert(type+" ----- ")
                          this.updateCompanyData = Object.assign(this.updateCompanyData,{"favicon":urlGenerated})
                        }

                        }else{

                          if(type=="logo"){
                          this.updateTenantData = Object.assign(this.updateTenantData,{"logo":urlGenerated})
                        }else{
                         // alert(type+" ----- ")
                          this.updateTenantData = Object.assign(this.updateTenantData,{"favicon":urlGenerated})
                        }

                        }
                      
                           
                            
                          if(temp_count >= mapper.length){
                              this.documents=[];

                          }
                          doc.url = urlGenerated;
                          delete doc.file;
                          mapper[index] = doc;
                       
                    })
                });
            });
             model.splice(0, mapper.length, ...mapper);
        }
    },
      remove(item) {
       
         if(this.getUserRoleId ==12){
                            
            this.updateCompanyData[item] =''
         }else{
            this.updateTenantData[item] = '';
         }
        
      },
     changedCountry(){
         this.states =[];
        this.locations =[];
        let dataKey ="updateTenantData";
        if(this.getUserRoleId ==12){
          dataKey="updateCompanyData";
        }
        if( _.has(this[dataKey].address.selectedCountry , "id")){
            this[dataKey].address.countryId = this[dataKey].address.selectedCountry['id'];
           
            this.masterData('states');
        }
        
    },
    changedState(){
        let dataKey ="updateTenantData";
        if(this.getUserRoleId ==12){
          dataKey="updateCompanyData";
        }
       
         this.locations =[];
         if( _.has(this[dataKey].address.selectedState , "id")){
            this[dataKey].address.stateId = this[dataKey].address.selectedState['id'];
           this.masterData('locations');
        }
    },
    //locationId
    changedCity(){
      let dataKey ="updateTenantData";
        if(this.getUserRoleId ==12){
          dataKey="updateCompanyData";
        }
     
      if( _.has(this[dataKey].address.selectedCity , "id")){
            this[dataKey].address.locationId = this[dataKey].address.selectedCity['id'];
           this.masterData('locations');
        }

    },
    masterData(category="countries"){

         /*
        countries:[]
        states:[],
        locations:[],
         */
        let matcher ={};
         let postData = {
        matcher: matcher,
        page:1,
        perpage: 1000,
        category: category,
       
      };

      let dataKey ="updateTenantData";
       let detailsDataKey ="tenantDetails"; 
            
        if(this.getUserRoleId ==12){
          dataKey="updateCompanyData";
          detailsDataKey= "companyDetails";
        }

      if(category =="states"){

          matcher = { "countryId": this[dataKey].address.selectedCountry['id']}
      }
       if(category =="locations"){

          matcher = { "stateId": this[dataKey].address.selectedState['id']  }
      }
       postData['matcher'] = matcher;

         this.$store.dispatch("getMasterData" , postData)
         .then((res)=>{
             //countries
            
             
             if(category == "countries"){

                 this.countries = res['list'];
                 
                 //alert(JSON.stringify(this.countries))
             }
             if(category =="states"){


                  this.states= res['list'];
                  if(_.has(this[detailsDataKey]['address'] ,"stateId")){
                  this[dataKey]['address'].selectedState = _.find(this.states ,{"id":this[detailsDataKey]['address']['stateId']});
                  this.changedState();
                  }
                  
                  
             }
            if(category =="locations"){
              
                this.locations= res['list'];
                if(_.has(this[detailsDataKey]['address'] ,"locationId")){
                  this[dataKey]['address'].selectedCity = _.find(this.locations ,{"id":this[detailsDataKey]['address']['locationId']}) ;
                  }
                
            }
         })
         .catch((err)=>{
             
             this[category] =[];

         })

    },
   selected(item) {
      this.$router.push(item.url);
      this.showFullSearch = false;
    },
    
    
    
  },
  directives: {
   
  },
  components: {
    VuePhoneNumberInput,
    FileUpload,
   
    moment,
    Datepicker,
  },
};
</script>