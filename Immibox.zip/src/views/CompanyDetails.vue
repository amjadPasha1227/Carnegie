<template>
<div class="main-tabs-content company_details">
    <!-- header area-->
    <div class="tabs-layout-header">
        <div class="tabs-layout-header-items client-details_tab petitioner_tabs">
            <div class="items-left w-auto" v-if="petitioner.registrationCompleted">
                <h2 class="small-header">{{petitioner.name}}

                </h2>

            </div>
            <div class="items-left" style="background:none;width:auto" v-if="!petitioner.registrationCompleted">

                <ul class="items-list">
                    <li>
                        Name
                        <span>
                            {{petitioner.name}}
                        </span> </li>
                    <li>
                        Email
                        <span>
                        
                            {{checkProperty(petitioner ,'email')}}
                        </span> </li>

                </ul>
            </div>
        
            <div class="items-right">

                <ul>

                    <li v-if="petitioner.registrationCompleted && petitioner.statusDetails.id == 2">
                        <vs-button class="actions-btn2">
                            <!--<span class="primary-btn" v-if="!petitioner['qbCustomerId'] " @click="qb_link_customer=true;selected_customer={}">
                                Link Customer to QuickBooks
                            </span>
                            -->
                            <span v-if="petitioner['qbCustomerId'] " class="status_linked">
                                QuickBooks Linked
                            </span>
                        </vs-button>
                    </li>
                    <li class="edit_btn_list" v-if="checkPetProfileEditPermisions && checkProperty(petitioner,'statusDetails')
                     && checkProperty(petitioner.statusDetails,'id') ==2 &&  checkProperty(petitioner ,'status') !=false && checkEditPermissions" 
                    @click="petEditProfile()">
                        <span class="items_edit">
                            <img src="@/assets/images/main/icon-edit.svg" />Edit
                        </span>
                    </li>
                    <li v-if="petitioner.registrationCompleted">
                        <div class="dropdown-button-container">

                            <vs-button>
                                <span class="status_registered status_approved" v-bind:class="{
                    status_registered: petitioner.statusDetails.id == 1,
                    status_approved: petitioner.statusDetails.id == 2,
                    status_rejected: petitioner.statusDetails.id == 3
                  }">
                                    {{petitioner.statusDetails.name}}
                                </span>

                            </vs-button>
                            
                            <vs-dropdown v-if="petitioner.statusDetails.id!=2 && petitioner.statusDetails.id!=5">
                                <vs-button class="btn-drop">
                                    Actions
                                    <i class="material-icons">arrow_drop_down</i>
                                </vs-button>
                                <vs-dropdown-menu class="actions-dropdown">
                                    <vs-dropdown-item v-if="petitioner.statusDetails.id != 2">
                                        <vs-checkbox @click="updatestatus(2,'Approved')" v-model="approved">Approve</vs-checkbox>
                                    </vs-dropdown-item>
                                    <vs-dropdown-item v-if="petitioner.statusDetails.id != 3">
                                        <vs-checkbox @click="updatestatus(3,'On Hold')" v-model="onhold">On Hold</vs-checkbox>
                                    </vs-dropdown-item>

                                </vs-dropdown-menu>
                            </vs-dropdown>

                             <vs-dropdown
                  v-if="petitioner.comments && petitioner.comments.length > 0"
                  vs-custom-content
                  vs-trigger-hover
                  class="msg_dropdown_icon"
                >
                  <a class="a-icon" href.prevent>
                    <img src="@/assets/images/main/message_icon.svg" />
                  </a>

                  <vs-dropdown-menu class="loginx msg_dropdown">
                   <span style="padding:10px 0px;">  <p >{{petitioner.comments[0].comment }}</p>  </span>
                  </vs-dropdown-menu>
                </vs-dropdown>



                        
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    
    <!-- content section start here-->
    <div class="tabs-content 1 tab_details_cnt">

        <div class="main-list-wrap" v-if="petitioner && petitioner.name && !petitioner.registrationCompleted">

            <div class="status-popup text-center nodoc_sub">
                <figure>
                    <img src="@/assets/images/main/professional.svg">
                </figure>
                <h3 class="mt-5">{{ petitioner.alertMessage }}</h3>
            </div>

        </div>

        <vs-tabs v-if="petitioner.registrationCompleted">
            <vs-tab>
                <vs-tabs position="left" color="" v-model="active_tab">
                    <!-- Company Details start here -->
                    <vs-tab label="Company Details">
                        <div class="tab-inner-content">
                            <div class="tabs-content-panel tab-pad-wrap ">

                                <div class="main-list-wrap" v-if="petitioner.registrationCompleted">
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Full legal name of your company
                                                    <span>{{petitioner.name}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                     First Name
                                                    <span>{{checkProperty(petitioner,'adminFirstName')?checkProperty(petitioner,'adminFirstName'):'--'}}</span>
                                               
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                   Last Name
                                                    <span>{{checkProperty(petitioner,'adminLastName')?checkProperty(petitioner,'adminLastName'):'--'}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                   Email
                                                    <span>{{checkProperty(petitioner,'email')}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Company Short Code
                                                    <span>{{checkProperty(petitioner,'idPrefix')?checkProperty(petitioner,'idPrefix'):'--'}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    NAICS Code (as per Tax Return) 
                                                    <span>{{petitioner.naicsCode}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner,'feiNumber')">
                                            <div class="main-list">
                                                <p>
                                                    Federal Employer Identification Number
                                                    <span>{{petitioner.feiNumber}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Phone Number
                                                    <span>
                                                    
                                                    <template v-if="checkProperty(petitioner ,'phone')"> 
                                                        {{checkProperty(petitioner ,"phoneCountryCode" ,'countryCallingCode')?checkProperty(petitioner ,"phoneCountryCode" ,'countryCallingCode')+('&nbsp;'):''}}{{checkProperty(petitioner ,"phone")}}
                                                    </template>
                                                    <template v-else>--</template>
                                                    
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner ,'homePhone')">
                                            <div class="main-list">
                                                <p>
                                                    Mobile Telephone Number
                                                    <span>
                                                        {{checkProperty(petitioner ,"homePhoneCountryCode" ,'countryCallingCode')?checkProperty(petitioner ,"homePhoneCountryCode" ,'countryCallingCode')+('&nbsp;'):''}}{{checkProperty(petitioner ,"homePhone")}}
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="petitioner['feinDocs'] && petitioner['feinDocs'].length>0">
                                        <div class="lca_header_list" >
                                            <div class="list__cnt">
                                                <div class="list-elements">
                                                    <h4 v-if="checkProperty(petitioner ,'feinDocs') && checkProperty(getUserData, 'tenantDetails') && checkProperty(getUserData, 'tenantDetails', 'slug') == 'slg'"
                                                    >FEIN Document or SS-4</h4>
                                                    <h4 v-if="checkProperty(petitioner ,'feinDocs')">FEIN Document or Latest Tax Return Document</h4>
                                               
                                                <ul>
                                                    <template v-if="petitioner['feinDocs'] && petitioner['feinDocs'].length>0">
                                                        <template v-for="(feinDoc ,index) in petitioner['feinDocs']">                       
                                                           <li :key="index" v-if="checkProperty(feinDoc,'status')" :title="checkProperty(feinDoc,'name')" @click="download_or_view(feinDoc)">        
                                                              
                                                                <figure>               
                                                                    <img v-if="checkFileFormat(feinDoc['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                                    <img v-else-if="checkFileFormat(feinDoc['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                                    <img v-else-if="checkFileFormat(feinDoc['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                                    <img v-else-if="checkFileFormat(feinDoc['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                                    <img v-else-if="checkFileFormat(feinDoc['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                                    <img v-else-if="checkFileFormat(feinDoc['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                                                    <img v-else-if="checkFileFormat(feinDoc['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                                    <img v-else src="@/assets/images/main/icon-img.svg" /> 
                                                                    <span class="download_icon"></span>
                                                                </figure> 
                                                                <!-- <a class="certified-name" :title="checkProperty(feinDoc,'name')">{{feinDoc.name}}</a> -->
                                                             
                                                                            
                                                          </li>
                                                        </template>  
                                                    </template>
                                                </ul>
                                              </div>
                                            </div>
                                          </div>
                                       </div>
                                       <div class="vx-col md:w-1/2 w-full p-0" v-if="petitioner['signDocs'] && petitioner['signDocs'].length>0 && checkProperty(configurationDetails,'ptnrAttorneySignByInternal')">
                                        <div class="lca_header_list" >
                                            <div class="list__cnt">
                                                <div class="list-elements">
                                                    <h4 v-if="checkProperty(petitioner ,'signDocs')">Electronic Signature</h4>
                                                        <ul>
                                                            <template v-if="petitioner['signDocs'] && petitioner['signDocs'].length>0">
                                                                <template v-for="(signDoc ,index) in petitioner['signDocs']">                       
                                                                    <li :key="index" v-if="checkProperty(signDoc,'status')" :title="checkProperty(signDoc,'name')" @click="download_or_view(signDoc)">            
                                                                        <figure>               
                                                                            <img v-if="checkFileFormat(signDoc['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                                            <img v-else-if="checkFileFormat(signDoc['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                                            <img v-else-if="checkFileFormat(signDoc['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                                            <img v-else-if="checkFileFormat(signDoc['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                                            <img v-else-if="checkFileFormat(signDoc['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                                            <img v-else-if="checkFileFormat(signDoc['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                                                            <img v-else-if="checkFileFormat(signDoc['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                                            <img v-else src="@/assets/images/main/icon-img.svg" /> 
                                                                            <span class="download_icon"></span>
                                                                        </figure> 
                                                                        <!-- <a class="certified-name" :title="checkProperty(feinDoc,'name')">{{feinDoc.name}}</a> -->
                                                                    </li>
                                                                </template>  
                                                            </template>
                                                        </ul>
                                                </div>
                                            </div>
                                          </div>
                                       </div>
                                       <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Fax Number
                                                    <span>
                                                        <template v-if="checkProperty(petitioner ,'fax')"> 
                                                            {{checkProperty(petitioner ,"phoneCountryCode" ,'countryCallingCode')?checkProperty(petitioner ,"phoneCountryCode" ,'countryCallingCode')+('&nbsp;'):''}}{{checkProperty(petitioner ,"fax") | formatPhone}}
                                                        </template>
                                                        <template v-else>--</template>
                                                    
                                                    
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner ,'address')"> 
                                            <div class="main-list">
                                                <p>
                                                    Address
                                                  <span v-html="$options.filters.addressformat(petitioner.address)"></span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                   <div class="vx-row m-0 main-list-panel" v-if="[50].indexOf(getUserRoleId)>-1 && checkProperty(petitioner ,'config' ,'commuEmails') && checkProperty(petitioner ,'config' ,'ptnrBriefDays')" >
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Briefing Days
                                                    <span>{{petitioner['config']['ptnrBriefDays']}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    List of additional contacts to be notified
                                                    <span>
                                                    
                                                   
                                                        {{checkProperty(petitioner ,"config" ,'commuEmails')}}
                                                    
                                                    
                                                    
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <h3 class="small-header mt-8" style="color: #E50019;">Representative/Authorized Signatory</h3>
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col  md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Name 
                                                    <span> {{petitioner.authorizedSignatory.name}}</span>
                                                <span class="user_role"> {{ petitioner.authorizedSignatory.title }} </span>
                                                </p>
                                            </div>
                                        </div>
                                        
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Email
                                                    <span>{{petitioner.authorizedSignatory.email}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Phone Number
                                                    
                                                    <span> {{checkProperty(petitioner.authorizedSignatory ,"phoneCountryCode" ,'countryCallingCode')?checkProperty(petitioner.authorizedSignatory ,"phoneCountryCode" ,'countryCallingCode')+('&nbsp;'):''}}{{petitioner.authorizedSignatory.phone}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner.authorizedSignatory ,'homePhone')">
                                            <div class="main-list">
                                                <p>
                                                    Mobile Telephone Number
                                                    <span>
                                                        {{checkProperty(petitioner.authorizedSignatory ,'homePhoneCountryCode' ,'countryCallingCode')?checkProperty(petitioner.authorizedSignatory ,'homePhoneCountryCode' ,'countryCallingCode')+('&nbsp;'):''}}{{checkProperty(petitioner.authorizedSignatory ,"homePhone")}}
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="conpany-assignments">
                                    <defaultUserAssignment :companyId="petitioner._id" :isCompany="true"  />
                                </div>
                            </div>
                        </div>
                    </vs-tab>
                    <!-- Business Information start here -->
                    <vs-tab label="Business Information" v-if="petitioner.registrationCompleted">
                        <div class="tab-inner-content">
                            <div class="tabs-content-panel tab-pad-wrap">
                                <div class="main-list-wrap">

                                <div class="vx-row m-0 main-list-panel" v-if="petitioner.typeOfBusiness!=''">
                                        <div class="vx-col w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Type of Business
                                                    <span  ><pre style="padding-top:10px;white-space: pre-line;max-width:100%;word-wrap: break-word;    font-family: inherit;" v-html="petitioner.typeOfBusiness"></pre></span>
                                                </p>
                                            </div>
                                        </div>
                                       
                                    </div>
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col w-full p-0">
                                            <div class="main-list d-block">
                                                <p> Briefly describe the nature of your business </p>
                                                <div class="editor_view mt-3 pb-0" v-html="petitioner.natureOfBusiness" ></div> 
                                            </div>
                                        </div>
                                       
                                    </div>
                                    <div class="vx-row m-0 main-list-panel">
                                         <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Date of business was established
                                                    <span>{{petitioner.businessEstdDate | formatDate}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Total number of full-time employees
                                                    <span>{{petitioner.totalFullTimeEmployees}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Are 50 or more individuals employed in United States?
                                                    <span style="text-transform: capitalize;">{{petitioner.are50orMoreEmployeesInUS}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Are more than 50 percent of those employees in
                                                    <br />H-1B, L-1A or L-1B nonimmigrant status?
                                                    <span style="text-transform: capitalize;">{{petitioner.areAbove50PercentH1BL1ALABStatus}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner, 'estimatedNetAnualIncome')">
                                            <div class="main-list">
                                                
                                                <!-- <p>
                                                    Estimated net annual income
                                                    <span>{{petitioner.estimatedNetAnualIncome}}</span>
                                                </p> -->
                                                <p>
                                                    Estimated net annual income
                                                  
                                                    <span>{{checkType({'field':petitioner.estimatedNetAnualIncome})}}</span>
                                                </p>
                                            </div>
                                        </div> 
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Estimated gross annual income
                                                    <span>{{checkType({'field':petitioner.estimatedGrossAnualIncome})}}</span>
                                                    <!-- <span> {{petitioner.estimatedGrossAnualIncome}}</span> -->
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="vx-row m-0 main-list-panel"> 
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Final determination from DOL or Federal Arbitrator of willful
                                                    violation of any H1B program requirement within 5 years of date.
                                                    <span>{{petitioner.finalDeterminationFromDOL}}</span>
                                                </p>
                                            </div>
                                        </div> 
                                    </div>
                                    <h3 class="small-header mt-8" style="color: #E50019;">Settings</h3>
                                    <div class="vx-row m-0 main-list-panel"> 
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner,'config','commuEmails')">
                                            <div class="main-list">
                                                <p>
                                                    List of additional contacts to be notified
                                                    <span v-if="checkProperty(petitioner,'config','commuEmails')">{{ petitioner.config.CommuEmails}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0"  v-if="checkProperty(petitioner,'config','ptnrBriefDays')"> 
                                            <div class="main-list">
                                                <p>
                                                    Receive tasks brief every
                                                    <span v-if="checkProperty(petitioner,'config','ptnrBriefDays')" >{{petitioner.config.ptnrBriefDays}} day(s)</span>
                                                </p>
                                            </div>
                                        </div> 
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner,'config','bnfBriefDays')">
                                            <div class="main-list">
                                                <p>
                                                    Send beneficiary tasks brief every
                                                    <span v-if="checkProperty(petitioner,'config','bnfBriefDays')">{{petitioner.config.bnfBriefDays}} day(s)</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner,'config','remindPtnrInfoUpdateDays')">
                                            <div class="main-list">
                                                <p>
                                                    Remind petitioner to update information for every
                                                    <span v-if="checkProperty(petitioner,'config','remindPtnrInfoUpdateDays')">{{petitioner.config.remindPtnrInfoUpdateDays}} day(s)</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner,'config','enablePermFilingReminder')">
                                            <div class="main-list">
                                                <p>
                                                    Send reminder if PERM Application is not filed
                                                    <span v-if="checkProperty(petitioner,'config','enablePermFilingReminder') && petitioner.config.enablePermFilingReminder==true">Yes</span>
                                                    <span v-if="checkProperty(petitioner,'config','enablePermFilingReminder') && petitioner.config.enablePermFilingReminder==false">No</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner,'config','enableI140Reminders')">
                                            <div class="main-list">
                                                <p>
                                                    Send reminder if I-140 is not filed
                                                    <span v-if="checkProperty(petitioner,'config','enableI140Reminders') && petitioner.config.enableI140Reminders==true">Yes </span>
                                                    <span v-if="checkProperty(petitioner,'config','enableI140Reminders') && petitioner.config.enableI140Reminders==false">No </span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner,'config','enableSponQuestionnireReminder')">
                                            <div class="main-list">
                                                <p>
                                                    Send reminder to Petitioner if the Sponsorship Questionnaire is not responded to DOL
                                                    <span v-if="checkProperty(petitioner,'config','enableSponQuestionnireReminder') && petitioner.config.enableSponQuestionnireReminder==true">Yes </span>
                                                    <span v-if="checkProperty(petitioner,'config','enableSponQuestionnireReminder') && petitioner.config.enableSponQuestionnireReminder==false">No </span>
                                                </p>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </vs-tab>


                    <vs-tab :label="'Company Docs'">
                        <div class="pt_doc">
                        <vs-tabs> 
                            <vs-tab :label="'Petitioner Documents '" v-if="checkProperty(configurationDetails,'acceptCompayDocsForPtnr')" >
                                <template v-if="checkProperty(configurationDetails,'acceptCompayDocsForPtnr')">
                                    
                                    <vs-col class="pad0" v-if="!editDocs">
                                        <div class="company-doc-view pt-0 pb-0">
                                            <button @click="editDocs=true" class="edit-doc company_doc_btn" style="top: 20px;"> <img src="@/assets/images/main/icon-edit.svg" />Edit Documents</button>
                                            <documentsListView @download_or_view="download_or_view" :docTitle="'Petitioner Documents'" v-if="checkProperty( petitioner ,'status') !=false" :documentsList="ptnrDocuments" :petitionDetails="null" />
                                        </div> 
                                    </vs-col>
                                    <vs-col class="pad0 edit_petitioner_docs" v-if="editDocs">
                                        <div class="form_section pad20 pt-0 pb-0">
                                            <casedocumentslist :docslist="ptnrDocslist" :showTitle="false"  formscope="" :fieldsArray="[]" v-model="ptnrDocuments" :tplsection="'documents'"  :fieldName="''" ></casedocumentslist>
                                            <!-- <p><strong>Note:</strong> Letterhead document must contains either header or footer. <a>Click here</a> to view sample document.</p> -->
                                        </div>
                                        <div class="petitioner_doc_actions">
                                            <button @click="editDocs=false;updateDocuments()" class="cancel"><span>Cancel</span></button>
                                            <button @click="editDocs=false;submitCompanyDocs()" class="save"><span>Update</span></button>
                                        </div>
                                    </vs-col>
                                </template>
                            </vs-tab>
                            <vs-tab :label="'Internal Documents '" >
                                <div class="petitioner_comp_doc">
                                <CompanyDocsTemplates :companyId="companyId"  :uploadCompanyDocs="(checkProperty( petitioner ,'status') !=false)" @updatepetition="getpetetioner" :currentUser="currentUserId" v-bind:currentRole="getUserRoleId" @download_or_view="download_or_view"  v-bind:petition="petitioner"  />
                            </div>
                            </vs-tab>
                        </vs-tabs>  
                        </div>
                    </vs-tab>
                    <vs-tab label="Settings" v-if="petitioner.config">
                        <div class="tab-inner-content">
                            <div class="tabs-content-panel tab-pad-wrap">
                                <div class="main-list-wrap">
                                    <div class="vx-row m-0 main-list-panel"> 
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner,'config','commuEmails')">
                                            <div class="main-list">
                                                <p>
                                                    List of additional contacts to be notified
                                                    <span v-if="checkProperty(petitioner,'config','commuEmails')">
                                                        <span v-for="(email, index) in petitioner.config.commuEmails.split(',')" :key="index">
                                                                {{ email }}<br />
                                                        </span>
                                                        <!-- {{ petitioner.config.commuEmails}} -->
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0"  v-if="checkProperty(petitioner,'config','ptnrBriefDays')"> 
                                            <div class="main-list">
                                                <p>
                                                    Receive tasks brief every
                                                    <span v-if="checkProperty(petitioner,'config','ptnrBriefDays')" >{{petitioner.config.ptnrBriefDays}} day(s)</span>
                                                </p>
                                            </div>
                                        </div> 
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner,'config','bnfBriefDays')">
                                            <div class="main-list">
                                                <p>
                                                    Send beneficiary tasks brief every
                                                    <span v-if="checkProperty(petitioner,'config','bnfBriefDays')">{{petitioner.config.bnfBriefDays}} day(s)</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner,'config','remindPtnrInfoUpdateDays')">
                                            <div class="main-list">
                                                <p>
                                                    Remind petitioner to update information for every
                                                    <span v-if="checkProperty(petitioner,'config','remindPtnrInfoUpdateDays')">{{petitioner.config.remindPtnrInfoUpdateDays}} day(s)</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner,'config','enablePermFilingReminder')">
                                            <div class="main-list">
                                                <p>
                                                    Send reminder if PERM Application is not filed
                                                    <span v-if="checkProperty(petitioner,'config','enablePermFilingReminder') && petitioner.config.enablePermFilingReminder==true">Yes</span>
                                                    <span v-if="checkProperty(petitioner,'config','enablePermFilingReminder') && petitioner.config.enablePermFilingReminder==false">No</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner,'config','enableI140Reminders')">
                                            <div class="main-list">
                                                <p>
                                                    Send reminder if I-140 is not filed
                                                    <span v-if="checkProperty(petitioner,'config','enableI140Reminders') && petitioner.config.enableI140Reminders==true">Yes </span>
                                                    <span v-if="checkProperty(petitioner,'config','enableI140Reminders') && petitioner.config.enableI140Reminders==false">No </span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petitioner,'config','enableSponQuestionnireReminder')">
                                            <div class="main-list">
                                                <p>
                                                    Send reminder to Petitioner if the Sponsorship Questionnaire is not responded to DOL
                                                    <span v-if="checkProperty(petitioner,'config','enableSponQuestionnireReminder') && petitioner.config.enableSponQuestionnireReminder==true">Yes </span>
                                                    <span v-if="checkProperty(petitioner,'config','enableSponQuestionnireReminder') && petitioner.config.enableSponQuestionnireReminder==false">No </span>
                                                </p>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </vs-tab>
                </vs-tabs>
            </vs-tab>
            
        </vs-tabs>
    </div>
    <vs-popup class="holamundo main-popup" title="Comments" v-if="updatestatuspop" :active.sync="updatestatuspop">
        <form>
            <div class="form-container">
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <!-- <vs-textarea v-model="comment" name="comment" label="Write a Comment…" v-validate="'required'" class="w-full" /> -->
                        <ckeditor  v-model="comment" name="comment" label="Write a Comment…" v-validate="'required'" class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

                    </div>
                    <span class="text-danger text-sm" v-show="errors.has('comment')">{{ errors.first("comment") }}</span>

                </div>
            </div>
            <div class="popup-footer">
                <vs-button color="success" @click="postStatus" class="save" type="filled">Update</vs-button>
            </div>
        </form>
    </vs-popup>

    <vs-popup class="holamundo main-popup" title="Link Customer to QuickBooks" v-if="qb_link_customer" :active.sync="qb_link_customer">
        <div class="form-container">
            <div class="vx-row">

                <div class="vx-col w-full">
                    <div class="form_group">
                        <label class="form_label">Choose Customer</label>
                        <div class="con-select">
                            <multiselect v-model="selected_customer" :options="customers_list" :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Choose Customer" label="name" track-by="name" :preselect-first="false">
                                <template slot="selection" slot-scope="{ values, isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                            </multiselect>
                        </div>
                    </div>

                    <p v-if="checkProperty(petitioner ,'_id') &&checkProperty(petitioner ,'name') &&  checkProperty(petitioner ,'phone') && this.checkProperty(this.petitioner,'authorizedSignatory' ,'email')" style="padding:15px 0px;"> Not found in the list? <a href="javascript:;" @click="createQucikBooks()">Create </a> Customer in QuickBooks

                    </p>
                </div>
            </div>
        </div>
        <div class="popup-footer">
            <vs-button color="dark" class="cancel" @click="qb_link_customer=false" type="filled">Cancel</vs-button>
            <vs-button color="success" class="save " @click="link_customer()" type="filled">Save</vs-button>
        </div>
    </vs-popup>

    <vs-popup class="document_modal document_modal-v2" :class="{ expand: expandModal }" :title="checkProperty(selectedFile,'name')" :active.sync="docPrivew">
        <div class="document_actions" @click="expandModal = !expandModal">
                <figure v-if="!expandModal" class="maximize-img"><img src="@/assets/images/maximize.png"  width="18" height="18"/></figure>
                <figure v-else class="minimize-img"><img src="@/assets/images/minimize.png"  width="20" height="20"/></figure>
        </div>
        <h2>
        <img 
        :class="{
            'pdf_view_download':docType == 'pdf',
            'office_view_download':docType == 'office',
            'image_view_download':docType =='image'
            }" 
            class="download-button"
            @click="downloads3file(selectedFile)" 
            src="@/assets/images/download.svg"
        />
        </h2>
        <div>
            <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close':docType =='image'}" class="close close2" @click="docPrivew= false"></span>
            <template v-if="docType=='office'">
                
                
                <div style="height:90vh">
 
                   <div id="officeDocView" style="height:100%"></div>
                </div>
            
            </template>
            <template v-else-if="docType == 'image'">
                <img :src="docValue">
            </template>
            <template v-else-if="docType == 'pdf'">
                <div class="pdf" style="height: 90vh">
                    <!-- <object :data="docValue" type="application/pdf" width="1000" height="600" v-if="docPrivew">
                        alt : <a :href="docValue">PDF</a>
                    </object> -->
                    
                  <iframe
              v-if="docValue != '' && docPrivew"
              border="0"
              style="border: 0px"
              :src="docValue"
              height="100%"
              width="100%"
            >PDF</iframe>
                </div>
            </template>
        </div>
    </vs-popup>


</div>
</template>

<script>
const formatter = new Intl.NumberFormat("en-US", {
style: "currency",
currency: "USD",
minimumFractionDigits: 2
});
import casedocumentslist from "@/views/common/casedocuments.vue";
import defaultUserAssignment from '@/views/defaultUserAssignment.vue'
import moment from 'moment'
import * as oAuthClient from 'intuit-oauth';
import CompanyDocsTemplates from  "./petition/CompanyDocsTemplates";
import documentsListView from "@/views/common/documentsListView.vue";
import VueDocPreview from 'vue-doc-preview'
export default {
     components: {
        defaultUserAssignment,
        CompanyDocsTemplates,
        VueDocPreview,
        documentsListView,
        casedocumentslist
    },
    provide() {
    return {
      parentValidator: this.$validator,
    };
  },
    data() {
        return {
            expandModal: false,
            ptnrDocslist: [
                {
                    required: false,
                    key: 'articleOfIncorp',
                    fieldName: 'articleOfIncorp',
                    label: 'Articles of Incorporation'
                },
                {
                    key: 'stateRegCert',
                    fieldName: 'stateRegCert',
                    required: false,
                    label: 'State Registration Certificate'
                },
                {
                    key: 'fein',
                    fieldName: 'fein',
                    required: false,
                    label: 'Document identifying the EIN number (Form SS-4 issued by IRS)'
                },
                {
                    key: 'goodStandCert',
                    fieldName: 'goodStandCert',
                    required: false,
                    label: 'Good standing certificate'
                },
                {
                    key: 'markMetOrWebsitePrints',
                    fieldName: 'markMetOrWebsitePrints',
                    required: false,
                    label: 'Marketing materials/website printouts'
                },
                {
                    key: 'orgCharts',
                    fieldName: 'orgCharts',
                    required: false,
                    label: 'Organizational chart'
                },
                {
                    key: 'latestTaxReturn',
                    fieldName: 'latestTaxReturn',
                    required: false,
                    label: 'Last two years Federal income tax returns'
                },
                {
                    key: 'latestWageReports',
                    fieldName: 'latestWageReports',
                    required: false,
                    label: 'Copy of Last four quaterly wage reports'
                },
                {
                    key: 'letterHeads',
                    fieldName: 'letterHeads',
                    required: false,
                    noteInfo:true,
                    label: 'Copy of Petitioner letterhead in word format',
                    fileAcceptType:"MSWORD"
                },
            ],
            ptnrDocuments:{
                articleOfIncorp: [],
                stateRegCert: [],
                fein: [],
                goodStandCert: [],
                markMetOrWebsitePrints: [],
                orgCharts: [],
                latestTaxReturn: [],
                latestWageReports: [],
                letterHeads:[]
            },
            editDocs:false,
            companyId:null,
            docPrivew: false,
            docValue: '',
            docType: "",
            selectedFile: null,


              currentRole: null,
             currentUserId: null,
            selected_customer: {},
            qb_link_customer: false,
            petitioner: [],
            updatestatuspop: false,
            companyId: null,
            comment: null,
            statusId: 0,
            arppoved: true,
            onhold: false,
            rejected: true,
            active_tab: 0,
            tabs: [{
                index: 0
            }, {
                index: 1
            }],
            billAddr: {},
            notes: '',
            customers_list: [],
            configurationDetails:null,
        };
    },
    methods: {
        petEditProfile(){
            let companyId = this.$route.params.itemId;
            this.$router.push('/petitioner-edit/'+companyId)
        },
        checkEditPermissions(){
        let petitionersPermessions =[3,4,5 ,50]
        if(this.checkProperty( this.getUserData ,'tenantDetails' ,'permissions')){
            if(this.checkProperty( this.getUserData['tenantDetails']['permissions'] ,'PETITIONER_COMPLETE_PROFILE')){
                petitionersPermessions = this.getUserData['tenantDetails']['permissions']['PETITIONER_COMPLETE_PROFILE'];
            }
        }
        if(petitionersPermessions.indexOf(this.getUserRoleId)>-1){
            return true;
        }else{
            return false;
        }
      },

        formatprice(amount) {
            return formatter.format(amount);
        },
        // download_or_view(value) {
        //     alert()
        //     if (_.has(value, "path")) {
        //         value['url'] = value['path'];
        //         value['document'] = value['path'];
        //     }

        //     if (_.has(value, "url")) {
        //         value['path'] = value['url'];
        //         value['document'] = value['url'];
        //     }

        //     if (_.has(value, "document")) {
        //         value['path'] = value['document'];
        //         value['url'] = value['document'];
        //     }

        //     this.selectedFile = value;
        //     this.docValue = '';
        //     this.docPrivew = false;
        //     this.docType = false;
        //     this.docType = this.findmsDoctype(value);

        //     if (this.docType == "office" || this.docType == "image") {

        //         value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        //         value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        //         let postdata = {
        //             keyName: value.url
        //         };
        //         this.$store.dispatch("getSignedUrl", postdata).then((response) => {
        //             this.docValue = response.data.result.data;

        //             if (this.docType == "office") {
        //                 this.docValue = encodeURIComponent(response.data.result.data);
        //             }
        //             this.docPrivew = true;
        //         });

        //     } else {

        //         this.downloads3file(value);
        //     }

        // },
        download_or_view(docItem) {
           
            let value = _.cloneDeep(docItem);
            this.expandModal= false;
            if( this.checkProperty(this.getPetitionDetails ,'caseNo') && this.checkProperty(value ,'name')){
                let docName = _.cloneDeep(value['name']);
                value['name'] = this.checkProperty(this.getPetitionDetails ,'caseNo')+"_"+docName;
            }
      
     
            var _self = this;
            this.formSubmited =false;
            if (_.has(value, "path")) {
            value["url"] = value["path"];
            value["document"] = value["path"];
            }

            if (_.has(value, "url")) {
            value["path"] = value["url"];
            value["document"] = value["url"];
            }

            if (_.has(value, "document")) {
            value["path"] = value["document"];
            value["url"] = value["document"];
            }
            // value = Object.assign(value ,{ 'petitionId':this.petition['_id']})
            // value = Object.assign(value ,{ 'subTypeDetails':this.petition['subTypeDetails']})


            this.selectedFile = value;
            this.docValue = "";
            this.docPrivew = false;
            this.docType = false;
            this.docType = this.findmsDoctype(value);
            
     if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf")  ) {
     //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
       value.url = value.url.replace(this.$globalgonfig._S3URL, "");
       value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
       let postdata = {
         keyName: value.url,
         "petitionId":value['petitionId'],
         
         // entityType:value['petitionId']
        // "fileName":value.name?value.name:''
       };
       
       this.$store.dispatch("getSignedUrl", postdata).then((response) => {
         this.docValue = response.data.result.data;

         if (this.docType == "office") {
           document.getElementById("officeDocView").innerHTML= "  <div  id='officeDocViewTemplate' style='height:100%'></div>";
             let _editing= true;
           
             if([50,51].indexOf(this.getUserRoleId)>-1){
                   _editing= false;
             }

             if(value.viewmode){
               _editing= false;
             }
             var _ob  = {}
             if(value.editedDocument){
                    _ob ={
               
               petitionId:_self.checkProperty(_self.petition ,'_id'),
                name:value.name,
               _id:value._id,
                 "extn": "docx",
               "formLetterType": "Letter",
                 parentId:value.parentId
             }

             }else{

                    _ob ={
                      
                   name:value.name,
                        petitionId:_self.checkProperty(_self.petition ,'_id'),
               _id:value._id,
              "extn": "docx",
               "formLetterType": "Letter",
                 parentId:value._id

             }

             }
         
             
             window.docEditor = new DocsAPI.DocEditor("officeDocViewTemplate",
           {
               
               "document": {
                  "c": "forcesave",
                   "fileType": "docx",
                   "key": value._id,
                    "userdata": JSON.stringify(_ob),
                   "title": value.name,
                   "url": response.data.result.data,
                    permissions: {
                   edit: _editing,
                   download: true,
                   reader:false,
                   review: false,
                   comment: false
                  }
               },
             
               "documentType": "word",
               "height": "100%",
               "width": "100%",
              
              "editorConfig": {
                  "userdata": JSON.stringify(_ob),
              "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload="+JSON.stringify(_ob)+"&token="+_self.$store.state.token+"&name="+value.name.replace('.docx',''),
       "customization": {
             "logo": {
               "image": "https://immibox.com/app/favicon.png",
               "imageDark": "https://immibox.com/app/favicon.png",
               "url": "https://immibox.com"
           },
         "anonymous": {
               "request": false,
               "label": "Guest"
           },
           "chat": false,
           "comments": false,
           "compactHeader": false,
           "compactToolbar": true,
           "compatibleFeatures": false,
           "feedback": {
               "visible": false
           },
           "forcesave": true,
           "help": false,
           "hideNotes": true,
           "hideRightMenu": true,
           "hideRulers": true,
             layout: { 
                 toolbar: {
                    "collaboration": false,
                 },
             },
           "macros": false,
           "macrosMode": "warn",
           "mentionShare": false,
           "plugins": false,
           "spellcheck": false,
           "toolbarHideFileName": true,
           "toolbarNoTabs": true,
           "uiTheme": "theme-light",
           "unit": "cm",
           "zoom": 100
       },
},          events: {
        onReady: function () {
      
           },
           onDocumentStateChange: function (event) {
             var url = event.data;
             if(!event.data){

               if(value.editedDocument){

                }

             }
           }

}
           });
           //this.docValue = encodeURIComponent(response.data.result.data);
         }

           if (this.docType == "pdf") {
             var _vid= value._id;
             if(value.parentId){
                _vid= value.parentId;
             }
             var  viewmode = 0; //1== edit , 0== Disble Edit
             let pdfViewUrl ='https://immibox.com/viewer/pdfjs-dist/web/viewerv2.html';            
            if(_.has(this.$globalgonfig, 'PDF_VIEW_URL')){
              pdfViewUrl = this.$globalgonfig['PDF_VIEW_URL']; //PDF_EDIT_URL
            }
             if(_.has( value ,'viewmode')){
               if(value.viewmode){
                viewmode= 0;
             }else{
               viewmode= 1;
               if(_.has(this.$globalgonfig, 'PDF_EDIT_URL')){
                pdfViewUrl = this.$globalgonfig['PDF_EDIT_URL'];
               }
             }

             }
             
           this.docValue = pdfViewUrl+"?view="+viewmode+"+&file="+encodeURIComponent(response.data.result.data);
         }
         this.docPrivew = true;
       });
     } else {
      
      

       this.downloads3file(value);
     }
    
   },

        checkCustomerAvailability() {
            let newPetitionerPayload = {
                billAddr: this.billAddr,
                notes: this.notes,
                displayName: this.petitioner.authorizedSignatory.name,
                primaryPhone: {
                    "FreeFormNumber": this.petitioner.phone
                },
                primaryEmail: {
                    "Address": this.petitioner.authorizedSignatory.email
                }
            }
            let postdata = {
                email: this.petitioner.authorizedSignatory.email,
            }
            Object.assign(postdata, newPetitionerPayload);

            this.$store.dispatch("checkPetitionerAvailability", postdata)
                .then(response => {})
                .catch(err => {})
        },
        updatestatus(statusId, statusName) {
            this.updatestatuspop = true;
            this.statusId = statusId;
            this.statusName = statusName;
            this.currentDate = moment().format('YYYY-MM-DD');
            this.companyId = this.$route.params.itemId;
        },
        postStatus() {
            var $this = this;
            this.$validator.validateAll().then(result => {
                if (result) {
                    this.postStausupdate();
                }

            })

        },
        postStausupdate() {
            this.$store
                .dispatch("petitioner/updatecompanystatus", {
                    companyId: this.companyId,
                    statusId: this.statusId,
                    statusName: this.statusName,
                    currentDate: this.currentDate,
                    comment: this.comment
                })
                .then(response => {
                    this.$router.go(this.$route.name);
                });
        },
        submitCompanyDocs(){
            let postData = {
                companyId:this.companyId,
                documents:[]
            };
             postData['documents'] = _.cloneDeep(this.ptnrDocuments)
            this.$store.dispatch("commonAction", {data:postData,path:'/company/documents-update'})
            .then((response) =>{ 
                this.editDocs=false;
                this.showToster({message:response.message,isError:false });
                this.getpetetioner()
            })
        },
        updateDocuments(){
            if(this.checkProperty(this.petitioner,'documents')){
                let tempDocs = this.checkProperty(this.petitioner,'documents')
                // if(_.has(tempDocs,'letterHeads')){
                //     delete tempDocs["letterHeads"]
                // }
                this.ptnrDocuments = _.cloneDeep(tempDocs)
            }
        },
        getpetetioner() {
            var companyId = this.$route.params.itemId;
            this.$store
                .dispatch("petitioner/getpetetioner", {
                    companyId: this.companyId
                })
                .then(response => {
                    this.petitioner = response;
                    this.petitioner['petitionerId'] = response['userId'];
                    if(_.has(response,'documents')){
                        this.updateDocuments();
                        //this.getGlobalConfigDetails();
                        
                    }
                   // alert(this.petitioner['petitionerId']);
                    if (this.petitioner.address.locationDetails != null) {
                        this.billAddr = {
                            "Line1": this.checkProperty(this.petitioner ,'address','line1'),
                            "City": this.checkProperty(this.petitioner.address ,'locationDetails','name'),
                            "Line2": this.checkProperty(this.petitioner ,'address','line2'),
                            "Country": this.checkProperty(this.petitioner.address ,'countryDetails','name'),
                            "CountrySubDivisionCode": this.checkProperty(this.petitioner.address ,'stateDetails','name'),
                            "PostalCode": this.checkProperty(this.petitioner ,'address','zipcode'),
                        }

                    }

                    if (this.petitioner.statusDetails.id == 3) {
                        this.approved = false;
                        this.onhold = true;
                        this.rejected = false;
                    }
                    if (this.petitioner.statusDetails.id == 4) {
                        this.approved = false;
                        this.onhold = false;
                        this.rejected = true;
                    }
                    //  alert(this.petitioner['qbCustomerId']);
                    this.get_customers_list();
                });
        },
        get_customers_list() {

            let postData = {};
            this.$store.dispatch("get_customers_list", postData)
                .then(response => {
                    this.customers_list = response;

                });

        },
        createQucikBooks() {
            let postData = {
                "companyId":this.checkProperty(this.petitioner,'_id'),
                "name": this.checkProperty(this.petitioner,'name'), 
                "email":this.checkProperty(this.petitioner,'authorizedSignatory' ,'email'),
                "phone": this.checkProperty(this.petitioner,'phone'),
                "line": this.checkProperty(this.petitioner ,'address','line1'),
                "city": this.checkProperty(this.petitioner.address ,'locationDetails','name'),
                "country": this.checkProperty(this.petitioner.address ,'countryDetails','name'), 
                "state":this.checkProperty(this.petitioner.address ,'stateDetails','name'),
                "zipcode": this.checkProperty(this.petitioner ,'address','zipcode'),
            }
            

            this.$store.dispatch("createQucikBooks", postData)
                .then(response => {

                    //  alert(JSON.stringify(response));
                    this.$vs.notify({
                        title: "Success",
                        position: "top-right",
                        color: "primary",
                        text: response["message"]
                    });
                    this.getpetetioner();
                    this.qb_link_customer = false;

                    //this.qconfig  = response['result'];

                }).catch((error)=>{
                    
                    this.showToster({message:error,isError:true })
                })
                

        },
        link_customer() {

            if (this.selected_customer['_id'] && this.petitioner['_id']) {
                let postData = {
                    "companyId": this.petitioner['_id'],
                    "customerId": this.selected_customer['_id']
                }

                this.$store.dispatch("link_customers_qb", postData)
                    .then(response => {

                        //  alert(JSON.stringify(response));
                        this.$vs.notify({
                             title: "Success",
                            text: response["message"],
                            title: "Success",
                             position: "top-right",
                            color: "primary",
                        });
                        this.getpetetioner();
                        this.qb_link_customer = false;

                        //this.qconfig  = response['result'];

                    });

            }
        },
        getGlobalConfigDetails(){
            let postData ={}
            //this.configurationDetails =null
            this.$store.dispatch("commonAction", {data:postData,path:'global-config/details'})
            .then((response) =>{ 
                if(this.checkProperty(response ,"config"  )){
                this.configurationDetails = response['config'];
                }
            })
        },

    },
    mounted() {
         this.currentRole = this.$store.state.user.loginRoleId;
         this.currentUserId = this.$store.state.user._id;
         this.companyId = this.$route.params.itemId;

        this.getpetetioner();
        

         this.getGlobalConfigDetails();

    },
    watch:{
        $route:function(){
            setTimeout(()=>{
                this.companyId = this.$route.params.itemId;
                this.getpetetioner();
            })
        }
    },
    computed:{
        checkType(){
            return (data)=>{
                if(/^[0-9]*$/.test(data['field']) || /^[0-9]*[.][0-9]+$/.test(data['field'])){
                    return this.formatprice(data['field'])
                }
                else{
                    return data['field']
                }
            }
            
        }
    }
};
</script>
