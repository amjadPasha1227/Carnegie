<template>
  <div class="tab-inner-content">
    <div class="subactions">
      <!-- <a  href="" class="action_btn"> Download Certificate </a> 
    
      <div class="action_menu_wrap">
        <span class="action_btn" v-on:click="showMobileMenu = !showMobileMenu"  v-bind:class="{ active: showMobileMenu }">Download Certificate</span>
        <div class="action_menu" v-bind:class="{ active: showMobileMenu }">
          <ul>
            <li><a href="#">Certificate 1</a></li>
            <li><a href="#">Certificate 2</a></li>
            <li><a href="#">Certificate 3</a></li>
            <li><a href="#">Certificate 4</a></li>
          </ul>
        </div>
      </div>-->

      <span
        class="action_status"
        v-bind:class="{
                    status_registered: lcaDetails.statusDetails.id == 1,
                    status_approved: lcaDetails.statusDetails.id == 2,
                    status_rejected: lcaDetails.statusDetails.id == 3
                  }"
      >LCA - {{lcaDetails.statusDetails.name}}</span>
    </div>

    <div class="tabs-content-panel tab-pad-wrap lca-view-details">
      <div class="lca-bottom-content" v-if="lcaDetails.clientName!=null">
        <div class="main-list-wrap">
          <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/2 w-full p-0">
              <div class="main-list">
                <p>
                  Client Name
                  <span>{{lcaDetails.clientName | empty}}</span>
                </p>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0">
              <div class="main-list">
                <p>
                  Job Title
                  <span>{{lcaDetails.jobTitle | empty}}</span>
                </p>
              </div>
            </div>
          </div>
          <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/2 w-full p-0">
              <ul class="main-list">
                <li>
                  <p>Job Duties</p>
                  <span>{{lcaDetails.jobDuties | empty}}</span>
                </li>
              </ul>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0">
              <div class="main-list">
                <p>
                  SOC Code
                  <span >{{lcaDetails.desiredSOCCode | empty}}</span>
                </p>
              </div>
            </div>
          </div>
          <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/2 w-full p-0">
              <ul class="main-list">
                <li>
                  <p>Masters Degree</p>
                  <span >{{lcaDetails.mastersDegree.schoolName | empty}}</span>
                </li>
              </ul>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0">
              <div class="main-list">
                <p>
                  Major
                  <span >{{lcaDetails.mastersDegree.major | empty}}</span>
                </p>
              </div>
            </div>
          </div>
          <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/2 w-full p-0">
              <ul class="main-list">
                <li>
                  <p>Job Duties</p>
                  <span>{{lcaDetails.jobDuties | empty}}</span>
                </li>
              </ul>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0">
              <div class="main-list">
                <p>
                  SOC Code
                  <span >{{lcaDetails.desiredSOCCode  | empty}}</span>
                </p>
              </div>
            </div>
          </div>
          <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/2 w-full p-0">
              <div class="main-list">
                <p >
                  Primary Work Location
                  <b v-if="lcaDetails.workAddress.workLocation">(Home Work Location)</b>
                  <span v-html="$options.filters.addressformat(lcaDetails.workAddress)"></span>
                </p>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="lcaDetails.secondaryWorkAddress">
              <div class="main-list">
                  <p >
                  Second Work Location
                  <b v-if="lcaDetails.secondaryWorkAddress.workLocation">(Home Work Location)</b>
                   <span v-html="$options.filters.addressformat(lcaDetails.secondaryWorkAddress)"></span>

                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<!--for active tab-->
<script>
import FileUpload from "vue-upload-component/src";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
export default {
  components: {
    VuePerfectScrollbar,
    FileUpload
  },

  props: {
    petition: {
      type: Object,
      default: null
    }
  },
  methods: {
    fetchSignedUrl(value) {
      
      value.document = value.document.replace(this.$globalgonfig._S3URL,"");
      let postdata = {
        keyName: value.document
      };
      

      this.$store.dispatch("getSignedUrl", postdata).then(response => {
        window.open(response.data.result.data, "_blank");
      });
    },
    scrollHandle(evt) {
      
    },
    generateUrlLink(item) {
      let postdata = {
        keyName: item.url
          .toString()
          .replace(this.$globalgonfig._S3URL,"")
      };
      

      this.$store.dispatch("getSignedUrl", postdata).then((response, index) => {
        this.hrefEachFile = response.data.result.data;
      });
    },
    remove(item, type) {
      type.splice(type.indexOf(item), 1);
      
      let updateFormsData = {
        documents: this.lcaDetails.documents,
        updateType: "documents",
        action: "UPLOAD_DOCUMENTS",
        lcaId: this.lcaDetails._id
      };
      

      this.$store
        .dispatch("updateLcaDetails", updateFormsData)
        .then(response => {
          
        });
      return false;
    },
    updatestatus(index, value) {
      
      let postdata = {
        lcaId: this.lcaDetails._id,
        statusId: index + 1,
        statusName: value
      };
      this.$store.dispatch("updateLcaStatus", postdata).then(response => {
        
        if (response.status === 200) {
          this.$router.go(this.$route.name);
        }
        // this.$router.go(this.$route.name);
      });
    },
    fetchDetails() {
      this.formsAndLetterSignedUrls = [];
      this.$store
        .dispatch("fetchLcaDetails", this.petition.lcaId)
        .then(response => {
          this.lcaDetails = response.data.result;
          this.lcaStatus = this.lcaDetails.statusDetails
            ? this.lcaDetails.statusDetails.name
            : "";
          this.address =
            this.lcaDetails.workAddress &&
            this.lcaDetails.workAddress.locationDetails
              ? this.lcaDetails.workAddress.line1 +
                ", " +
                this.lcaDetails.workAddress.line2 +
                ", " +
                this.lcaDetails.workAddress.locationDetails.name +
                ", " +
                this.lcaDetails.workAddress.stateDetails.name +
                ", " +
                this.lcaDetails.workAddress.countryDetails.name
              : "";
          this.address2 =
            this.lcaDetails.secondaryWorkAddress &&
            this.lcaDetails.secondaryWorkAddress.countryDetails
              ? this.lcaDetails.secondaryWorkAddress.line1 +
                ", " +
                this.lcaDetails.secondaryWorkAddress.line2 +
                ", " +
                this.lcaDetails.secondaryWorkAddress.stateDetails.name +
                ", " +
                this.lcaDetails.secondaryWorkAddress.countryDetails.name
              : "";
          
        });
    },
    submitSOCCode() {
      if (this.number === null) {
        return false;
      } else {
        let updatedValue = {
          lcaId: this.lcaDetails._id,
          number: this.number,
          action: "UPDATE_BASIC_INFO",
          updateType: "lca-number"
        };
        this.$store
          .dispatch("updateLcaDetails", updatedValue)
          .then(response => {
            
            this.$router.go(this.$route.name);
          });
      }
    },
    fetchStatusMasterData() {
      this.$store
        .dispatch("getmasterdata", "lca_inventory_status")
        .then(response => {
          this.allLcaStatuses = response;
          
        });
    },
    uploadForms() {
      let formData = new FormData();
      this.lcaDetails.documents.formETA9035And9035E = this.lcaDetails.documents.formETA9035And9035E.map(
        item =>
          (item = {
            name: item.name,
            file: item.file,
            url: "",
            mimetype: item.type
          })
      );
      
      this.lcaDetails.documents.formETA9035And9035E.forEach(files => {
        formData.append("files", files.file);
        formData.append("secureType", "private");
        this.$store.dispatch("uploadS3File", formData).then(response => {
          response.data.result.forEach(urlGenerated => {
            files.url = urlGenerated;
            
            delete files.file;
          });
          let updateFormsData = {
            documents: this.lcaDetails.documents,
            updateType: "documents",
            action: "UPLOAD_DOCUMENTS",
            lcaId: this.lcaDetails._id
          };
          
          this.$store
            .dispatch("updateLcaDetails", updateFormsData)
            .then(response => {
              
              this.$router.go(this.$route.name);
            });
        });
      });
    },
    uploadCertificate() {
      let formData = new FormData();
      this.lcaDetails.documents.lca = this.lcaDetails.documents.lca.map(
        item =>
          (item = {
            name: item.name,
            file: item.file,
            url: "",
            mimetype: item.type
          })
      );
      
      this.lcaDetails.documents.lca.forEach(files => {
        formData.append("files", files.file);
        formData.append("secureType", "private");
        this.$store.dispatch("uploadS3File", formData).then(response => {
          files.url = response.data.result;
          let updateFormsData = {
            documents: this.lcaDetails.documents,
            updateType: "documents",
            action: "UPLOAD_DOCUMENTS",
            lcaId: this.lcaDetails._id
          };
          

          this.$store
            .dispatch("updateLcaDetails", updateFormsData)
            .then(response => {
              
              this.$router.go(this.$route.name);
            });
        });
      });
    },
    fetchActivityList() {
      let postdata = {
        lcaId: this.$route.params.itemId,
        page: 1,
        perpage: 10
      };
      this.$store.dispatch("fetchLCAactivities", postdata).then(response => {
        this.activityList = response.data.result.list;
      });
    }
  },
  data: () => ({
    lcaDetails: [],
    number: "",
    address: "",
    address2: "",
    certifiedLCA: "",
    lcaStatus: "",
    allLcaStatuses: [],
    formFiles: [],
    certificateFiles: [],
    documentsUploaded: [],
    certificateSignedUrls: "",
    formsAndLetterSignedUrls: [],
    selected_status: "",
    activityList: [],
    hrefEachFile: ""
  }),
  mounted() {
    this.fetchDetails();
    this.fetchStatusMasterData();
    this.fetchActivityList();
  }
};
</script>