// axios
//set NODE_OPTIONS=--max-old-space-size=104096
import axios from 'axios'
import store from './store/store';
import _ from "lodash";
import router from './router'
import moment from "moment";
//let domain = globalconfig._BASEURL;
//let domain = "https://cms.thomasvallen.com/api";
//let domain = "http://localhost:8989";
//let domain = "http://192.168.100.43:8989";
//let domain = "http://192.168.100.53:8989";
//let domain = "/api";
//let domain = "https://anyclap.com/api/";
//let domain = "https://slg.anyclap.com";
let domain = "https://thomasvallen.anyclap.com/api/"; 
//domain ="https://thomasvallen.immibox.com/api/"
//domain ="http://192.168.100.53:8989/"
if (process.env.NODE_ENV == 'production') {
  domain = "/api/";
}

let anonymousLogin =false;

const instance = axios.create({
    baseURL:domain
  // You can add your headers here
})

instance.interceptors.request.use(function(config) {
  var token = store.state.token;
    
   

    if(store.getters["petitioner/getToken"] ){
      token = store.getters["petitioner/getToken"] 
    }

    let currentRoute  = router.currentRoute;
    if(_.has(currentRoute ,"meta.getTokenFromUrl") && (_.has(currentRoute, "query.token")) ){
      token = _.get(currentRoute, 'query.token', '');
      anonymousLogin =true;
    }

    if(_.has(currentRoute ,"meta.getTokenFromUrl") && (_.has(currentRoute, "query.key")) ){
      token = _.get(currentRoute, 'query.key', '');
      anonymousLogin =true;
    }
    
    if( !token&& currentRoute['query']['accessToken']){
    
      token =currentRoute['query']['accessToken'];
      
    }
    if(!_.has(config['data'] ,"timezone") ){
      config['data']['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone;//moment.tz.guess()
    }
    

    if ( token != null ) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    if(_.has(config, 'data')){
      if(!_.has(config['data'] ,"today")){
        config['data']['today'] = moment().format("YYYY-MM-DD")
      }

      if(!_.has(config['data'] ,"timezone") ){
        config['data']['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone;//moment.tz.guess()
      }
      // moment.tz.guess()
    }
    
    return config;
  }, function(err) {
    return Promise.reject(err);
  });

  
  instance.interceptors.response.use(
    function(response){     
      return response;
    }, 
    function(error){
        // handle error LOGIN_USER_INACTIVE
        let err = _.cloneDeep(error);
        if(error && _.has(error,'response' ) && _.has(error.response ,"data" ) && _.has(error.response.data ,"result" ) && _.has(error.response.data.result ,"error" ) &&  _.has(error.response.data.result.error ,"code" )  ){
          if(error.response.data.result.error.code =='TOKEN_EXPIRED' || error.response.data.result.error.code =='LOGIN_USER_INACTIVE' || error.response.data.result.error.code =='ROLE_CHANGED' ){
            localStorage.removeItem('token');
            localStorage.removeItem('userRole');
            localStorage.removeItem('user');
            localStorage.removeItem('LS_ROUTE_KEY');
            store.dispatch('logout');
            store.dispatch('logout').then(()=>{

              if(anonymousLogin){
              
                window.location.replace(window.location.origin);
              }else{
                location.reload();
              }

            });
            
           
           
            //this.showToster({message:'sdhsdhfdsf',isError:true})
           // alert(error.response.data.result.error.code)
           
           
          }
         
        }
            
        return Promise.reject(error);
        //return error;
    });
   
   


export default instance;
