

<template>
  <div class="layout--full-page">

  
<div v-if="!checkCurrentUrl" class="anonymouslogin_header" slot="header"  >
<!----This is for annomous Login--->
  <div class="logo flex items-center">
     
      <img  src="@/assets/images/logo/immiBox_logo.svg"  alt="logo"  />
      
     
  </div>
</div>
    <router-view></router-view>
  </div>
  
</template>
