<template>
  <div class="layout--main"
    :class="[navbarClasses, footerClasses, { 'app-page': isAppPage, 'searche-opened': getisGlobalSearchOpened }]">
    <!-- <div class="overlay" v-if="getisGlobalSearchOpened"  v-on:click.stop.prevent="togleGlobalSearch()"></div> -->
    <vx-sidebar :sidebarItems="sidebarItems" :settingsItems="settingsItems" :logo="getTextLogo" :smallLogo="getSmallLogo"
      title="Vuesax" ref="vxsidebar" parent=".layout--main" />





    <div id="content-area" :class="[contentAreaClass, { 'show-overlay': bodyOverlay }]">
      <div id="content-overlay"></div>

      <div class="content-wrapper" id="content-drag">
        <the-navbar ref="navBar" @hideremindersnav="showreminderscomp()" :navbarColor="navbarColor" :class="[
          { 'text-white': isNavbarDark && !isThemeDark },
          { 'text-base': !isNavbarDark && isThemeDark }
        ]" />

        <div class="router-view">
          <div id="router-content" class="router-content" :class="{ 'mt-0': navbarType == 'hidden' }">
            <transition :name="routerTransition">
              <div class="router-header flex flex-wrap items-center mb-6"
                v-if="$route.meta.breadcrumb || $route.meta.pageTitle">
                <div class="content-area__heading" :class="{
                  'pr-4 border-0 md:border-r border-t-0 border-b-0 border-l-0 border-solid border-grey-light':
                    $route.meta.breadcrumb
                }">
                  <h2 class="mb-1">{{ routeTitle }}</h2>
                </div>

                <!-- BREADCRUMB -->
                <vx-breadcrumb class="ml-4 md:block hidden" v-if="$route.meta.breadcrumb" :route="$route" />

                <!-- DROPDOWN -->
                <vs-dropdown class="ml-auto md:block hidden cursor-pointer" vs-trigger-click>
                  <vs-button radius icon="icon-settings" icon-pack="feather"></vs-button>

                  <vs-dropdown-menu class="w-32">
                    <vs-dropdown-item>
                      <div @click="$router.push('/profile')" class="flex items-center">
                        <feather-icon icon="UserIcon" class="inline-block mr-2" svgClasses="w-4 h-4" />
                        <span>Profile</span>
                      </div>
                    </vs-dropdown-item>

                    <vs-dropdown-item>
                      <div @click="$router.push('/apps/todo')" class="flex items-center">
                        <feather-icon icon="CheckSquareIcon" class="inline-block mr-2" svgClasses="w-4 h-4" />
                        <span>Tasks</span>
                      </div>
                    </vs-dropdown-item>

                    <vs-dropdown-item>
                      <div @click="$router.push('/apps/email')" class="flex items-center">
                        <feather-icon icon="MailIcon" class="inline-block mr-2" svgClasses="w-4 h-4" />
                        <span>Inbox</span>
                      </div>
                    </vs-dropdown-item>
                  </vs-dropdown-menu>
                </vs-dropdown>
              </div>
            </transition>
            <div class="content-area__content">

              <transition :name="routerTransition" mode="out-in">
                <router-view :key="$route.fullPath" @changeRouteTitle="changeRouteTitle"></router-view>
              </transition>


              <back-to-top bottom="5%" visibleoffset="500" v-if="!hideScrollToTop">
                <vs-button icon-pack="feather" icon="icon-arrow-up" class="shadow-lg" />
              </back-to-top>
            </div>
          </div>
        </div>
      </div>
      <!------ v-if="checkProperty($route ,'name') !='petition-details'"  -->
      <the-footer v-if="checkProperty($route, 'name') != 'basic-settings'"></the-footer>
    </div>


    <Reminders v-if="hideremcomp" @reloadRemindersCount="reloadRemindersCount()" @hidereminders="hidereminderscomp()" />
    <div class="calande-tooltip" id="tooltipcal"></div>

</div>
</template>

<script>
import VxSidebar from "@/layouts/components/vx-sidebar/VxSidebar.vue";
import TheNavbar from "../components/TheNavbar.vue";
import TheFooter from "../components/TheFooter.vue";
import themeConfig from "@/../themeConfig.js";
import BackToTop from "vue-backtotop";
import Reminders from "@/views/Reminders.vue";
import _ from "lodash";
import JQuery from "jquery";
import smlLogo from '@/assets/images/logo/logo.svg';
import txtLogo from "@/assets/images/logo/logo_text.svg"
import globalSearch from "@/views/globalSearchh.vue";


export default {
  mounted() {

this.getGlobalConfigDetails()
    this.textLogo = txtLogo;
    this.smallLogo = smlLogo;
    this.getCaseTypeList();
    

  },
  data() {
    return {
      hideremcomp: false,
      navbarType: themeConfig.navbarType || "floating",
      navbarColor: themeConfig.navbarColor || "#fff",
      footerType: themeConfig.footerType || "static",
      routerTransition: themeConfig.routerTransition || "none",
      isNavbarDark: false,
      routeTitle: this.$route.meta.pageTitle,
      sidebarItems: [],
      settingsItems: [],
      disableCustomizer: themeConfig.disableCustomizer,
      windowWidth: window.innerWidth, //width of windows
      hideScrollToTop: themeConfig.hideScrollToTop,
      disableThemeTour: themeConfig.disableThemeTour,
      smallLogo: '',
      textLogo: '',
      caseTypes: [],
      configurationDetails:null,
      externalCasePermissinos:[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50]
    };
  },
  watch: {
    $route() {
      this.$store.commit('updatedNewLogo', { "url": null, 'type': 'favicon' });
      this.$store.commit('updatedNewLogo', { "url": null, 'type': 'logo' });
      var elemenet = document.getElementById("tooltipcal");
      elemenet.style.display = "none"

      this.routeTitle = this.$route.meta.pageTitle;
      var _s = this;

      let nonfloatPage = _.find(this.settingsItems, function (o) {
        return o.slug == _s.$route.name;
      });
      if (!nonfloatPage) {




      }

    },
    isThemeDark(val) {
      if (this.navbarColor == "#fff" && val) {
        this.updateNavbarColor("#10163a");
      } else {
        this.updateNavbarColor("#fff");
      }
    },
  },
  computed: {
    checkCapCaseCount(){
      let returnVal =false;
      let userData = JSON.parse(localStorage.getItem('loginUserData'));
      if(userData && _.has( userData ,'capCaseCount')){
        if(userData['capCaseCount'] >0){
          returnVal =true;
        }
        
      }
      return returnVal;
    },
    checkRfeCaseCount(){
      let returnVal =false;
      let userData = JSON.parse(localStorage.getItem('loginUserData'));
      if(userData && _.has( userData ,'rfeCaseCount')){
        if(userData['rfeCaseCount'] >0){
          returnVal =true;
        }
        
      }
      return returnVal;
    },
    getTextLogo() {


      //  if(this.checkProperty( this.getUserData ,"tenantDetails" , 'whiteLabled')){
      //     if(this.checkProperty( this.getUserData ,"tenantDetails" , 'logo')){

      //       return this.checkProperty( this.getUserData ,"tenantDetails" , 'logo')


      //     }else{
      //       return '';

      //     }


      //  }else{

      //    return this.textLogo ;

      //  }
      if (this.checkProperty(this.$store.state.newLogoUploaded, 'length') > 0) {
        return this.$store.state.newLogoUploaded
      }

      else {

        if (this.checkProperty(this.getUserData, "tenantDetails", 'logo')) {

          return this.checkProperty(this.getUserData, "tenantDetails", 'logo')


        } else {
          return this.textLogo;

        }



      }


    },
    getSmallLogo() {

      if (this.checkProperty(this.$store.state.newFaviconUploaded, 'length') > 0) {
        return this.$store.state.newFaviconUploaded
      }

      else {

        if (this.checkProperty(this.getUserData, "tenantDetails", 'favicon')) {

          return this.checkProperty(this.getUserData, "tenantDetails", 'favicon')


        } else {
          return this.smallLogo;

        }



      }

      // return this.smallLogo
    },
    isAppPage() {
      if (this.$route.path.includes("/apps/")) return true;
      else return false;
    },
    isThemeDark() {
      return this.$store.state.theme == "dark";
    },
    sidebarWidth() {
      return this.$store.state.sidebarWidth;
    },
    bodyOverlay() {

      return this.$store.state.bodyOverlay;
    },
    contentAreaClass() {
      if (this.sidebarWidth == "default") return "content-area-default";
      else if (this.sidebarWidth == "reduced") return "content-area-reduced";
      else if (this.sidebarWidth == "extended") return "content-area-extended";
      else if (this.sidebarWidth) return "content-area-full";
    },
    navbarClasses() {
      return {
        "navbar-hidden": this.navbarType == "hidden",
        "navbar-sticky": this.navbarType == "sticky",
        "navbar-static": this.navbarType == "static",
        "navbar-floating": this.navbarType == "floating",
      };
    },
    footerClasses() {
      return {
        "footer-hidden": this.footerType == "hidden",
        "footer-sticky": this.footerType == "sticky",
        "footer-static": this.footerType == "static",
      };
    },
  },
  methods: {

    getCaseTypeList() {
      let allPetitionsMenu = {
        url: "/cases",
        name: "All",
        slug: "petitions",
        icon: "FileTextIcon",
        title: "Cases",
        access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50, 51],
        active:false,

      }
      let lcaMenu = {
        url: "/lcalist",
        name: "LCA Library",
        slug: "LCA",
        icon: "FileTextIcon",
        title: "LCA",
        access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,50]
      }
      let permMenu = {
        url: "/cases",
        name: "PERM",
        slug: "companyList",
        icon: "companyList",
        title: "Petitioners",
        access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50, 51], //[3,4,5,6,7,8,9,10,11,12,13]
        active:false,
      }
      let pwdMenu = {
        url: "/pwd-list",
        name: "PWD Library",
        slug: "companyList",
        icon: "companyList",
        title: "Petitioners",
        access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50], //[3,4,5,6,7,8,9,10,11,12,13]
        active:false,
      }
      let rfeMenu = {
        url: "/ref-cases",
        name: "RFE Cases",
        slug: "ref-cases",
        icon: "FileTextIcon",
        title: "RFE Cases",
        access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50, 51]
      }
      let caseTransferItem = {
        url: "/case-transfer",
        name: "Bulk Assignment",
        slug: "petitions",
        icon: "FileTextIcon",
        title: "Petitions",
        access: [3, 4],
      };

      let capRegList = {
        url: "/cap-registrations",
        name: "Cap Registrations",
        slug: "Cap Registrations",
        icon: "FileTextIcon",
        title: "Petitions",
        access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50, 51],
      };
      let externalCases = {
        url: "/external-cases",
        name: "External Cases",
        slug: "External Cases",
        icon: "FileTextIcon",
        title: "External Cases",
        access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50],
      };
      this.caseTypes = [];

      let item = {
        matcher: {
          statusIds: [],
          typeIds: [],
          "searchString": '',
          getWorkFlowConfig: false,
          getCasenoCodeConfig: false
          // "petitionType":

        },
        page: 1,
        perpage: 1000,
        category: "petition_types",
        sorting: this.sortKey,

      };
      //alert()
      this.$store
        .dispatch("getMasterData", item)
        .then(response => {
          this.caseTypes = response.list;
          //prepare Case menue
          if (this.checkProperty(this.caseTypes, 'length') > 0) {

            this.sidebarItems.map((item) => {

              if (this.checkProperty(item, 'name') == 'Cases') {
                //alert(JSON.stringify(item))
                let subTypes = []

                _.forEach(this.caseTypes, (caseType) => {
                  let path = "/petitions";
                  path = "/cases"
                  let subitm = {
                    url: "/cases",//"/petitions", 
                    name: "Cases",
                    slug: "petitions",
                    icon: "FileTextIcon",
                    title: "Petitions",
                    access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50, 51],
                    active:false,
                  }
                  let matchers = { "typeIds": [], 'subTypeIds': [] };
                  matchers['typeIds'] = [caseType['id']];

                  if (caseType["name"] == 'GC - Employment' || caseType["id"] == 3) {
                    matchers['subTypeIds'] = [15,16 ,17]

                  }
                  if (Object.keys(matchers).length > 0) {
                    let matcherObj = { 'matcher': matchers }
                    const string = JSON.stringify(matcherObj)
                    let encodedString = btoa(string)

                    subitm['url'] = "/cases?filter=" + encodedString;;
                    subitm['name'] = caseType["name"];


                    if (caseType['id'] == 1) {
                      subTypes.push(allPetitionsMenu);
                    }
                    subTypes.push(subitm);
                    if (caseType['id'] == 1) {
                      subTypes.push(lcaMenu);
                    }
                    if (caseType['id'] == 2) {
                      let matc = { "typeIds": [3], 'subTypeIds': [15] };

                      let matchObj = { 'matcher': matc }
                      let stri = JSON.stringify(matchObj)
                      let encodedString = btoa(stri)
                      permMenu['url'] = "/cases?filter=" + encodedString;
                      subTypes.push(permMenu);
                    }
                    if (!_.find(subTypes, { name: "PWD Library" })) {
                          subTypes.push(pwdMenu);
                    }
                    
                  }
                })

                if (!_.find(subTypes, { name: "Cap Registrations" })) {
                  let matc = { "capTypeList": [true] };
                  let matchObj = { 'matcher': matc }
                  let stri = JSON.stringify(matchObj)
                  let encodedString = btoa(stri)
                  capRegList['url'] = "/cap-registrations?filter=" + encodedString;
                  //subTypes.push(capRegList); 
                }

                if (!_.find(subTypes, { url: "/lcalist" })) {
                  subTypes.push(lcaMenu);
                }
                if (!_.find(subTypes, { name: "PERM" })) {

                  let matc = { "typeIds": [3], 'subTypeIds': [15] };
                  let matchObj = { 'matcher': matc }
                  let stri = JSON.stringify(matchObj)
                  let encodedString = btoa(stri)
                  permMenu['url'] = "/cases?filter=" + encodedString;
                  subTypes.push(permMenu);
                }
                if (subTypes.length > 0 && [51].indexOf(this.getUserRoleId) < 0) {
                  item['submenu'] = subTypes;
                 // item['submenu'].push(rfeMenu)
                }
                if(this.configurationDetails && this.checkProperty(this.configurationDetails ,'isAllowExternalCases')){
                  item['submenu'].push(externalCases)
                }
                item['submenu'].push(caseTransferItem);
              }
            })
            this.sidebarItems = this.sidebarItems;
          }
        }).catch((e) => {
          this.caseTypes = [];
        })
    },
    getGlobalConfigDetails(){
      this.$store.commit('updateManageCapRegistrations',false );
      let postData ={}
      this.configurationDetails =null
      this.$store.dispatch("commonAction", {data:postData,path:'global-config/details'})
      .then((response) =>{ 
        if(this.checkProperty(response ,"config"  )){
          this.configurationDetails = response['config'];

          if(_.has(this.configurationDetails ,"manageCapRegistrations"  )){
                let manageCapRegistrations = this.configurationDetails['manageCapRegistrations'];
                this.$store.commit('updateManageCapRegistrations',manageCapRegistrations );
               }
        }
      })
    },
    reloadRemindersCount() {
      try {
        this.$refs['navBar'].getReminderlist();
      } catch (e) {}
    },
    showreminderscomp() {
      this.hideremcomp = true;
    },
    hidereminderscomp() {
      this.hideremcomp = false;
    },
    changeRouteTitle(title) {
      this.routeTitle = title;
    },
    updateNavbarColor(val) {
      this.navbarColor = val;
      if (val == "#fff") this.isNavbarDark = false;
      else this.isNavbarDark = true;
    },
    handleWindowResize(event) {
      this.windowWidth = event.currentTarget.innerWidth;
      this.setSidebarWidth();
    },
    setSidebarWidth() {
      if (this.windowWidth < 1200) {
        this.$store.commit("TOGGLE_IS_SIDEBAR_ACTIVE", false);
        this.$store.dispatch("updateSidebarWidth", "no-sidebar");
        this.disableThemeTour = true;
      } else if (this.windowWidth < 1200) {
        this.$store.dispatch("updateSidebarWidth", "reduced");
      } else {
        this.$store.commit("TOGGLE_IS_SIDEBAR_ACTIVE", true);
      }
    },
    toggleHideScrollToTop(val) {
      this.hideScrollToTop = val;
    },
  },
  components: {
    VxSidebar,
    TheNavbar,
    TheFooter,
    BackToTop,
    Reminders,
    globalSearch
  },
  created() {
    this.getGlobalConfigDetails();
    let beneficiariesAccessPermessions = [3, 4, 5, 6, 7, 50];
    let petitionersPermessions = [3, 4, 5, 6, 7, 11]; //3,4,5,6,7,8,9,10,11,12,13 //PETITIONER_COMPLETE_PROFILE
    let taskListPermissions = [];

    let individuals = "/beneficiaries";
    let beneficiariesTabName ="Beneficiaries"
    // let matchers ={"typeIds":[1]};
    // let matcherObj = {'matcher':matchers}
    // let string = JSON.stringify(matcherObj)                    
    // let encodedString = btoa(string) 
    // individuals = individuals+"?filter="+encodedString;

    let corporates = "/petitioners";
    //  matchers ={"typeIds":[2]};
    //  matcherObj = {'matcher':matchers}
    //  string = JSON.stringify(matcherObj)                    
    //  encodedString = btoa(string) 
    // corporates = corporates+"?filter="+encodedString;

    let caseReportsPermissions = [3, 4];

    if (this.checkProperty(this.getUserData, 'tenantDetails', 'permissions')) {


      if (this.checkProperty(this.getUserData['tenantDetails']['permissions'], 'PETITIONER_COMPLETE_PROFILE')) {

        petitionersPermessions = this.getUserData['tenantDetails']['permissions']['PETITIONER_COMPLETE_PROFILE'];

      }

      if (this.checkProperty(this.getUserData['tenantDetails']['permissions'], 'TASK_LIST')) {

        taskListPermissions = this.getUserData['tenantDetails']['permissions']['TASK_LIST'];

      }
        if (this.checkProperty(this.getUserData['tenantDetails']['permissions'], 'REPORTS_CASE')) {

          caseReportsPermissions = this.getUserData['tenantDetails']['permissions']['REPORTS_CASE'];

      }

      

    }



    let branchPermessions = [3]
    let corporateCustomerReportsPermissions  = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    let customersPermission =[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
    if (this.getTenantTypeId == 2) {
      customersPermission =[];
     // beneficiariesTabName ="Employees";
      petitionersPermessions = [];
      if ([3, 4].indexOf(this.getUserRoleId) > -1) {

        beneficiariesAccessPermessions = [3, 4, 50];

        branchPermessions = [];

      }

      corporateCustomerReportsPermissions =[];

    }
    let benCapMenu =[];
    if(this.checkCapCaseCount){
      benCapMenu =[51];
    }
    
    let benRfeMenu =[];
    if(this.checkRfeCaseCount){
      benRfeMenu =[]//[51];
    }
   
    
  
    this.sidebarItems = [
      {
        url: "/dashboard",
        name: "Dashboard",
        slug: "dashboard",
        icon: "PieChartIcon",
        title: "Dashboard",
        access: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50],

      },
      {
        url: "/cap-registrations",
        name: "Cap Registrations",
        slug: "Cap Registrations",
        icon: "FileTextIcon",
        title: "Petitions",
        access: benCapMenu,
      },
      {
        url: "/cases",
        name: "Cases",
        slug: "petitions",
        icon: "FileTextIcon",
        title: "Petitions",
        access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50, 51],
        active:false,
        /*
        submenu:[           
          { url: "/petitions", 
            name: "Cases",
            slug: "petitions",
            icon: "FileTextIcon",
            title: "Petitions",
            access:[3,4,5,6,7,8,9,10,11,12,13,14 ,50,51]
          },            
          {
            url: "/ref-cases",
            name: "RFE Cases",
            slug: "ref-cases",
            icon: "FileTextIcon",
            title: "RFE Cases",
            access:[3,4,5,6,7,8,9,10,11,12,13,14 ,50,51]
          },
        ],
        */
      },
      // {
      //   url: "/external-cases",
      //   name: "External Cases",
      //   slug: "External Cases",
      //   icon: "FileTextIcon",
      //   title: "External Cases",
      //   access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50],
      // },
      {
        url: "/cap-registrations",
        name: "Cap Registrations",
        slug: "Cap Registrations",
        icon: "FileTextIcon",
        title: "Petitions",
        access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50],
      },
      
      // { 
      //     url: "/cap-registrations", 
      //     name: "Cap Registrations",  
      //     slug: "petitions", 
      //     icon: "FileTextIcon",  
      //     title: "Petitions", 
      //     access:[51], 
      //   },
      {
        url: "/cap-reports",//submenu"/petitions", 
        name: "Reports",
        slug: "petitions",
        icon: "FileTextIcon",
        title: "Cap Registrations",
        access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
        submenu: [
        {
            url: "/case-list-reports",//submenu"/petitions", 
            name: "Case List",
            slug: "petitions",
            icon: "FileTextIcon",
            title: "Petitions",
            access: caseReportsPermissions//[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],

          },
          {
            url: "/over-due-reports",//submenu"/petitions", 
            name: "Overdue Cases",
            slug: "petitions",
            icon: "FileTextIcon",
            title: "Petitions",
            access: caseReportsPermissions//[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],

          },
          {
            url: "/branchwise-case-summary",//submenu"/petitions", 
            name: "Branchwise Case Summary",
            slug: "petitions",
            icon: "FileTextIcon",
            title: "Petitions",
            access: caseReportsPermissions//[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],

          },
          {
            url: "/cases-by-customer",//submenu"/petitions", 
            name: "Cases by Customer",
            slug: "petitions",
            icon: "FileTextIcon",
            title: "Petitions",
            access: caseReportsPermissions//[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],

          },
          {
            url: "/cap-reports",//submenu"/petitions", 
            name: "Cap Registrations",
            slug: "petitions",
            icon: "FileTextIcon",
            title: "Petitions",
            access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],

          },
          {
            url: '/corporate-customer-reports',//submenu"/petitions", 
            name: "Corporate Customers",
            slug: "petitions",
            icon: "FileTextIcon",
            title: "Petitions",
            access:corporateCustomerReportsPermissions ,//[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]

          },
          {
            url: '/individual-customer-reports',//submenu"/petitions", 
            name: "Individual Customers",
            slug: "petitions",
            icon: "FileTextIcon",
            title: "Petitions",
            access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],

          },
          {
            url: '/sent-emails-list',//submenu"/petitions", 
            name: "Sent Emails",
            slug: "petitions",
            icon: "FileTextIcon",
            title: "Petitions",
            access: [3, 4],

          }

        ]
      },
      {
        url: "/messages",
        name: "Messages",
        slug: "messages",
        icon: "FileTextIcon",
        title: "Petitions",
        access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50,51],
      },
      /*
      //case-transfer
       {
          url: "/case-transfer",
          name: "Bulk Assignment",
          slug: "petitions",
          icon: "FileTextIcon",
          title: "Petitions",
          access:[3,4],
       },
      {
          url: "/lcalist",
          name: "LCA",
          slug: "LCA",
          icon: "FileTextIcon",
          title: "LCA",
          access:[3,4,5,6,7,8,9,10,11,12,13,14]
      },
      {
        url: "/perm",
        name: "PERM",
        slug: "companyList",
        icon: "companyList",
        title: "Petitioners",
        access:[3,4,5,6,7,8,9,10,11,12,13,14,50,51], //[3,4,5,6,7,8,9,10,11,12,13,14]
      },
      */

      {
        url: "/ref-cases",
        name: "RFE Cases",
        slug: "ref-cases",
        icon: "FileTextIcon",
        title: "RFE Cases",
        access: benRfeMenu
      },
      {
        url: "/tasks-list",
        name: "Tasks",
        slug: "Users",
        icon: "UserIcon",
        title: "tasks",
        access: taskListPermissions
      },

      {
        url: "/customers",
        name: "Customers",
        slug: "customers",
        icon: "PieChartIcon",
        title: "Customers",
        access: [1, 2],
      },
      {
        // url: corporates,
        url: "/petitioners",
        name: "Customers",
        slug: "customers",
        icon: "PieChartIcon",
        title: "Customers",
        access: customersPermission ,
        submenu: [

          //corporates
          {
            //  url: corporates ,
            url: "/petitioners",
            name: "Corporates",
            slug: "customers",
            icon: "PieChartIcon",
            title: "Customers",
            access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
          },
          //individuals
          {
            url: '/individuals',
            name: "Individuals",
            slug: "customers",
            icon: "PieChartIcon",
            title: "Customers",
            access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
          },



        ]
      },
      //  {
      //   url: "/ref-cases",
      //   name: "RFE Cases",
      //   slug: "ref-cases",
      //   icon: "FileTextIcon",
      //   title: "RFE Cases",
      //   access:[3,4,5,6,7,8,9,10,11,12,13,14 ,50,51]
      // },

      {
        url: "/beneficiaries",
        name: beneficiariesTabName,// "Beneficiaries",
        slug: "beneficiaries",
        icon: "UserIcon",
        title: "Petitions",
        access: beneficiariesAccessPermessions
      },
      {
        url: "/documents",
        name: "Documents",
        slug: "documents",
        icon: "PieChartIcon",
        title: "Documents",
        access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
      },
      {
        url: "/notes-list",
        name: "Notes",
        slug: "notes",
        icon: "PieChartIcon",
        title: "Notes",
        access: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50, 51]
      },
      {
        url: "/bulk-emails",
        name: "Marketing",
        slug: "Users",
        icon: "UserIcon",
        title: "tasks",
        access: [],
        submenu: [

          {
            url: "/bulk-emails",
            name: "Send Email",
            slug: "Users",
            icon: "UserIcon",
            title: "tasks",
            access: [3, 4]
          },
          {
            url: "/email-templates",
            name: "Templates",
            slug: "Users",
            icon: "UserIcon",
            title: "tasks",
            access: [3, 4]
          },

        ]
      },
      {
        url: "/support-tickets",
        name: "Support",
        slug: "Users",
        icon: "UserIcon",
        title: "Users",
        access: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 50, 51]
      },
      {
        url: "/petitioners",
        name: "Petitioners",
        slug: "companyList",
        icon: "companyList",
        title: "Petitioners",
        //access:petitionersPermessions
        access: []
      },
      // {
      //   url: "/paf-generation",
      //   name: "PAF Generation",
      //   slug: "companyList",
      //   icon: "companyList",
      //   title: "Petitioners",
      //   access: [50]
      // },

      {
        url: "/users",
        name: "Administration",
        slug: "Users",
        icon: "UserIcon",
        title: "Users",
        access: [3],
        submenu: [
          {
            url: "/users",
            name: "Users",
            slug: "users",
            icon: "UserIcon",
            title: "Users",
            access: [3, 4]//[3,4 ]
          },
          {
            url: "/basic-settings",
            name: "Settings",
            slug: "basic-settings",
            icon: "FileTextIcon",
            title: "Settings",
            access: [3, 50]
          }
        ]
      },
      {
        url: "/branch-list",
        name: "Branches",
        slug: "branch-list",
        icon: "FileTextIcon",
        title: "Branches",
        access: []//branchPermessions
      },
      {
        url: "/users",
        name: "Users",
        slug: "users",
        icon: "UserIcon",
        title: "Users",
        access: [1, 2]
      }
    ];
    this.setSidebarWidth();
    if (this.navbarColor == "#fff" && this.isThemeDark) {
      this.updateNavbarColor("#10163a");
    } else {
      this.updateNavbarColor(this.navbarColor);
    }
  },
};
</script>
