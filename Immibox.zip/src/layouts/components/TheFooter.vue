

<template>
    <footer class="the-footer flex-wrap justify-between" :class="classes">
    <!---<span v-else>© {{curretYear}} ImmiBox - A Product by Ideateq LLC, All rights Reserved</span>--->
        <span v-if="isWhiteLabled">© {{curretYear}} {{ checkProperty( getUserData ,'tenantDetails','name')}}. Powered by <a href="https://immibox.com">ImmiBox.com</a></span>
        <span v-else>© {{curretYear}}  ImmiBox.com - A product by Ideateq Inc. All rights Reserved.</span>
       <!-----
        <div class="ask-questions-section"  :class="{questionsopen : showQuestions}" >
        <div id="content-overlae" @click="showQuestions = false"></div>
          <div class="question-btn_wrap" :class="{hidetext : hideText}">
            <a class="question-btn" @click="showQuestions = !showQuestions" >
                <figure><img src="@/assets/images/help-guide.png"></figure>
                <span> Help Guide</span>
            </a>
          </div>
          <div class="help-search-wrapper" >
                <span class="close" @click="showQuestions = false"><img src="@/assets/images/main/cross.svg" /></span>
                <div class="search-area">
                    <h6>Help Guide</h6>
                    <input class="searchinput" v-model="searchQuery" placeholder="Search">
                </div>
                <div class="suggested-articles">
                    <label>Suggested articles</label>
                    <VuePerfectScrollbar
                        ref="mainSidebarPs"
                        class=""
                        :settings="settings"
                        >
                    <ul>
                        <li  v-for="page in resultQuery"
                :key="page.link"><a target="_blank" :href='page.link'>{{page.title}}</a></li>
                       <li v-if="searchQuery && resultQuery.length == 0">No Results Found</li>
                    </ul>
                     </VuePerfectScrollbar>
                    <div class="action-btns" v-if="resources.length > 0">
                        <a :href="'https://immibox.com/help/register-as-customer/?token='+resources[0].nonce" target="_blank" class="ask-btn">Browse All</a>
                    </div>
                </div>
            </div>
       </div>
      -->
       <template >
        <modal
        name="profileUpdatemodal"
        classes="v-modal-sec"
        :min-width="200"
        :min-height="200"
        :scrollable="true"
        :reset="true"
        width="650px"
        height="auto"
        >
        <div class="v-modal">
        <div class="popup-header fromDetailsPage"> 
        <h2 class="popup-title">
          Profile Update Notification 

        </h2>
        <!-- <span @click="$modal.hide('profileUpdatemodal');usciscUpdateStatusError='';">
          <em class="material-icons">close</em>
        </span> -->
        </div>

        <div class="form-container main-list-wrap">
          <template v-if="getUserRoleId == 3">
      <div class="vx-row m-0 main-list-panel">
        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(tenantDetailss,'adminEmail')">
              <div class="main-list">
                  <p>
                      Admin Email
                      <span>{{checkProperty(tenantDetailss,'adminEmail')}}</span>
                  </p>
              </div>
          </div>
          <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(tenantDetailss,'name')">
              <div class="main-list">
                  <p>
                      Name
                      <span>{{checkProperty(tenantDetailss,'name')}}</span>
                  </p>
              </div>
          </div>
          <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(tenantDetailss,'adminFirstName')">
              <div class="main-list">
                  <p>
                      First Name
                      <span>{{checkProperty(tenantDetailss,'adminFirstName')}}</span>
                  </p>
              </div>
          </div>
          <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(tenantDetailss,'adminLastName')">
              <div class="main-list">
                  <p>
                      Last Name
                      <span>{{checkProperty(tenantDetailss,'adminLastName')}}</span>
                  </p>
              </div>
          </div>
          <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(tenantDetailss,'idPrefix')">
              <div class="main-list">
                  <p>
                    Company Short Code
                      <span>{{checkProperty(tenantDetailss,'idPrefix')}}</span>
                  </p>
              </div>
          </div>
          <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(tenantDetailss,'fromEmail')">
              <div class="main-list">
                  <p>
                    From Email
                      <span>{{checkProperty(tenantDetailss,'fromEmail')}}</span>
                  </p>
              </div>
          </div>
          <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(tenantDetailss,'contactEmail')">
              <div class="main-list">
                  <p>
                    Contact Email
                      <span>{{checkProperty(tenantDetailss,'contactEmail')}}</span>
                  </p>
              </div>
          </div>
          <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(tenantDetailss,'phone')">
              <div class="main-list">
                  <p>
                    Phone Number
                    <span><template v-if="checkProperty(tenantDetailss ,'phoneCountryCode' ,'countryCallingCode')">{{checkProperty(tenantDetailss ,'phoneCountryCode' ,'countryCallingCode')+"&nbsp;"}}</template>
                    {{tenantDetailss.phone | formatPhone}}</span>
                  </p>
              </div>
          </div>
          <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(tenantDetailss,'feiNumber')">
              <div class="main-list">
                  <p>
                    Federal Employer Identification Number
                      <span>{{checkProperty(tenantDetailss,'feiNumber')}}</span>
                  </p>
              </div>
          </div>
          <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(tenantDetailss,'address')">
              <div class="main-list">
                  <p>
                    Address
                      <span v-html="$options.filters.addressformat(checkProperty(tenantDetailss,'address'))"></span>
                  </p>
              </div>
          </div>
          <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(tenantDetailss,'mailingaddress') && !tenantDetailss.mailingAddressSame">
              <div class="main-list">
                  <p>
                    Mailing Address
                      <span v-html="$options.filters.addressformat(checkProperty(tenantDetailss,'mailingaddress'))"></span>
                  </p>
              </div>
          </div>
        
      </div>
          </template>
          <template v-if="getUserRoleId == 50">
            <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'email')">
                  <div class="main-list">
                      <p>
                          Email
                          <span>{{checkProperty(companyDetailss,'email')}}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'name')">
                  <div class="main-list">
                      <p>
                        Company Name
                          <span>{{checkProperty(companyDetailss,'name')}}</span>
                      </p>
                  </div>
              </div>
              <!-- <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'idPrefix')">
                  <div class="main-list">
                      <p>
                        Company Short Code
                          <span>{{checkProperty(companyDetailss,'idPrefix')}}</span>
                      </p>
                  </div>
              </div> -->
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'adminFirstName')">
                  <div class="main-list">
                      <p>
                          First Name
                          <span>{{checkProperty(companyDetailss,'adminFirstName')}}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'adminLastName')">
                  <div class="main-list">
                      <p>
                          Last Name
                          <span>{{checkProperty(companyDetailss,'adminLastName')}}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'phone')">
                  <div class="main-list">
                      <p>
                        Phone Number
                        <span><template v-if="checkProperty(companyDetailss ,'phoneCountryCode' ,'countryCallingCode')">{{checkProperty(companyDetailss ,'phoneCountryCode' ,'countryCallingCode')+"&nbsp;"}}</template>
                        {{companyDetailss.phone | formatPhone}}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'fax')">
                  <div class="main-list">
                      <p>
                        Fax Number
                        <span><template v-if="checkProperty(companyDetailss ,'faxCountryCode' ,'countryCallingCode')">{{checkProperty(companyDetailss ,'faxCountryCode' ,'countryCallingCode')+"&nbsp;"}}</template>
                        {{companyDetailss.fax | formatPhone}}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'naicsCode')">
                  <div class="main-list">
                      <p>
                        NAICS Code (as per Tax Return)
                          <span>{{checkProperty(companyDetailss,'naicsCode')}}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'feiNumber')">
                  <div class="main-list">
                      <p>
                        Federal Employer Identification Number
                          <span>{{checkProperty(companyDetailss,'feiNumber')}}</span>
                      </p>
                  </div>
              </div>
            </div>
              <h3 class="small-header">Representative/Authorized Signatory</h3>
            <div class="vx-row m-0 main-list-panel">
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'authorizedSignatory','title')">
                  <div class="main-list">
                      <p>
                        Position/Title
                          <span>{{checkProperty(companyDetailss,'authorizedSignatory','title')}}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'authorizedSignatory','name')">
                  <div class="main-list">
                      <p>
                        Name
                          <span>{{checkProperty(companyDetailss,'authorizedSignatory','name')}}</span>
                      </p>
                  </div>
              </div>
              <!-- <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'authorizedSignatory','firstName')">
                  <div class="main-list">
                      <p>
                        First Name
                          <span>{{checkProperty(companyDetailss,'authorizedSignatory','firstName')}}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'authorizedSignatory','lastName')">
                  <div class="main-list">
                      <p>
                        Last Name
                          <span>{{checkProperty(companyDetailss,'authorizedSignatory','lastName')}}</span>
                      </p>
                  </div>
              </div> -->
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'authorizedSignatory','email')">
                  <div class="main-list">
                      <p>
                        Email
                          <span>{{checkProperty(companyDetailss,'authorizedSignatory','email')}}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'authorizedSignatory','phone')">
                  <div class="main-list">
                      <p>
                        Phone Number
                        <span><template v-if="checkProperty(companyDetailss['authorizedSignatory'] ,'phoneCountryCode' ,'countryCallingCode')">{{checkProperty(companyDetailss['authorizedSignatory'] ,'phoneCountryCode' ,'countryCallingCode')+"&nbsp;"}}</template>
                        {{checkProperty(companyDetailss,'authorizedSignatory','phone') | formatPhone}}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col w-full p-0" v-if="checkProperty(companyDetailss,'address')">
                  <div class="main-list">
                      <p>
                      Address
                          <span v-html="$options.filters.addressformat(checkProperty(companyDetailss,'address'))"></span>
                      </p>
                  </div>
              </div>
            </div>
              <h3 class="small-header">Business Information</h3>
            <div class="vx-row m-0 main-list-panel">
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'typeOfBusiness')">
                  <div class="main-list">
                      <p>
                        Type of Business
                          <span>{{checkProperty(companyDetailss,'typeOfBusiness')}}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'businessEstdDate')">
                  <div class="main-list">
                      <p>
                        Date of business was established
                          <span>{{checkProperty(companyDetailss,'businessEstdDate') | formatDate }}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'totalFullTimeEmployees')">
                  <div class="main-list">
                      <p>
                        Total number of full-time employees
                          <span>{{checkProperty(companyDetailss,'totalFullTimeEmployees')}}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'estimatedGrossAnualIncome')">
                  <div class="main-list">
                      <p>
                        Estimated gross annual income
                          <span>{{checkProperty(companyDetailss,'estimatedGrossAnualIncome')}}</span>
                      </p>
                  </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(companyDetailss,'estimatedNetAnualIncome')">
                  <div class="main-list">
                      <p>
                        Estimated net annual income
                          <span>{{checkProperty(companyDetailss,'estimatedNetAnualIncome')}}</span>
                      </p>
                  </div>
              </div>
          </div>
          </template>
          <p class="msg_text reminder_msg " v-if="footerMessage != ''">{{footerMessage}}</p> 
          <p class="msg_text " v-else>It is a reminder to make your details are up to date to make process seamless with USCIS/DOl. Take necessary action based on details mentioned above.</p>
        </div>
        <div @click="usciscUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="usciscUpdateStatusError!=''">
          <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ usciscUpdateStatusError }}</vs-alert>
        </div>
        <div class="popup-footer relative">
        <div class="vx-col w-full">
        </div>
        <vs-button color="dark" class="cancel footer_action" type="filled" @click="getNotificationPopup('No')">Remind me Later</vs-button>
        <vs-button color="success" class="save footer_action" type="filled"  @click="getNotificationPopup('Yes')">Update Now</vs-button>
        </div>

        </div>
        </modal>
      </template>
    </footer>
</template> 

<script>
import moment from 'moment'
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import _ from "lodash";

import JQuery from "jquery";
export default {

    name: "the-footer",
    props: {
        classes: {
            type: String,
        },
    },
    watch: {
        $route() {
          this.$route['params']['allDocumentsActiveTab']= '';
          const $ = JQuery;
          $('body').removeClass('widget-expended')
            this.getGlobalConfigDetails()
        }
    },
     data: () => ({
        configDetails:null,
        lastUpdatedDate:'',
        companyDetailss:'',
        footerMessage:'',
        usciscUpdateStatusError:'',
        tenantDetailss:'',
        resources:[],
       // showQuestions: false,
        hideText: false,
        curretYear:  '',
        searchQuery: null,
        settings: {
            
            wheelSpeed: 0.6,
        },
     }),
     components:{
         moment,
         VuePerfectScrollbar

     },
     methods:{
      getGlobalConfigDetails(){
          let postData ={}
          let path = 'global-config/details'
          this.$store.dispatch("commonAction", {data:postData,path:path})
          .then((response) =>{ 
            let details = response
            if(this.getUserRoleId == 3 && this.getTenantTypeId ==2){
              if(this.checkProperty(details ,'config' ,'remindPtnrInfoUpdateDays' )){
                this.configDetails = this.checkProperty(details ,'config' ,'remindPtnrInfoUpdateDays' );
                this.getLastUpdatedDate()
              }else{
                this.configDetails = this.$globalgonfig.showAlert;
                this.getLastUpdatedDate();
              }
            }
            if(this.checkProperty(this.getUserData,'companyId') && [50].indexOf(this.getUserRoleId)>-1 ){
              let postData={
                companyId : this.checkProperty(this.getUserData,'companyId')
              }
              this.$store.dispatch("commonAction", {"data":postData ,"path":"/company/details"}).then((response)=>{
                this.companyDetailss= response
                if(this.checkProperty(response ,'config' ,'remindPtnrInfoUpdateDays' ) ){
                  this.configDetails = this.checkProperty(response ,'config' ,'remindPtnrInfoUpdateDays' );
                  this.getLastUpdatedDate()
                }else{
                  this.configDetails = this.$globalgonfig.showAlert
                  this.getLastUpdatedDate()
                }               
              }).catch((error)=>{
              })
            }     
          }).catch((eer)=>{
            this.getLastUpdatedDate()
          })
        },
        getCommonMessages(){
      let payLoad={
        "category": [ "COMMON_MESSAGES"]
      }
      this.$store.dispatch("commonAction", {"data":payLoad ,"path":"/messages/list"}).then((response)=>{
        if( _.has(response['messages']['COMMON_MESSAGES'] , 'ptnrCompanyInfoUpdate')){
          this.footerMessage = response['messages']['COMMON_MESSAGES']['ptnrCompanyInfoUpdate']
        }
      }).catch((error)=>{
      })
    },
    getCompanyDetail(){
      if(this.checkProperty(this.getUserData,'companyId')){
        let postData={
          companyId : this.checkProperty(this.getUserData,'companyId')
        }
        this.$store.dispatch("commonAction", {"data":postData ,"path":"/company/details"}).then((response)=>{
          this.companyDetailss= response
        }).catch((error)=>{
        })
      }
    },
    getLastUpdatedDate(){
      this.usciscUpdateStatusError=''
      this.lastUpdatedDate =null;
      let latestUpdateDate = null; 
      let user = JSON.parse(localStorage.getItem('user'));
      if((this.getUserRoleId == 3 && this.getTenantTypeId ==2) || this.getUserRoleId == 50){
        if(this.getUserRoleId == 3 && this.getTenantTypeId ==2){
        this.lastUpdatedDate = this.checkProperty(this.getUserData,'tenantDetails', 'profileUpdatedOn');
          // if(_.has(user ,'tenantDetails.profileUpdatedOn')){
          //   this.lastUpdatedDate = user['tenantDetails']['profileUpdatedOn'];
          // }
        }if(this.getUserRoleId == 50){
          this.lastUpdatedDate = this.checkProperty(this.getUserData, 'companyDetails', 'profileUpdatedOn');
          // if(_.has(user ,'companyDetails.profileUpdatedOn')){
          //   this.lastUpdatedDate = user['companyDetails']['profileUpdatedOn'];
          // } 
        }
     
      try{
          if(this.lastUpdatedDate){
            latestUpdateDate =  moment(this.lastUpdatedDate)//.format("YYYY-MM-DD") 
          let presentDate= moment()//.format("YYYY-MM-DD") ;
          if(presentDate.diff(latestUpdateDate,'days') >= this.configDetails){
            this.$modal.show('profileUpdatemodal')
             this.activatePopUp = true
          }
        }
      }catch(err){
        let date = moment();
        if(this.getUserRoleId == 3 && this.getTenantTypeId ==2){
            this.$store.commit('tenantUpdatedOn',date)
          }
          if(this.getUserRoleId == 50){
            this.$store.commit('petitionerUpdatedOn',date)
          }
      }
    }
    },
    getNotificationPopup(action=''){
      //alert(action);
      this.usciscUpdateStatusError='';
      this.archiving = false
      if(action=='Yes'){
        //let updatedDate = moment().add(30,"days");
        let updatedDate = moment();
          if(this.getUserRoleId == 3){
            this.$modal.hide('profileUpdatemodal')
            this.$store.commit('tenantUpdatedOn',updatedDate)
            this.$router.push("/basic-settings");
          }
          if(this.getUserRoleId == 50){
            this.$modal.hide('profileUpdatemodal')
            this.$store.commit('petitionerUpdatedOn',updatedDate)
            this.$router.push("/basic-settings");
          }
      }
      if(action=='No'){
      let postData={
      }
      let path = ''
      if(this.getUserRoleId == 3){
        path = "/tenant/update-profile-complete-date"
      }
      if(this.getUserRoleId == 50){
        path = "/company/update-profile-complete-date"
      }
      this.$store.dispatch('commonAction', {"data":postData ,"path":path}).then((response) => {
        this.$modal.hide('profileUpdatemodal')
        this.archiving = false;
        let date = moment();
          if(this.getUserRoleId == 3){
            this.$store.commit('tenantUpdatedOn',date)
          }
          if(this.getUserRoleId == 50){
            this.$store.commit('petitionerUpdatedOn',date)
          }
      }).catch((error)=>{
        this.archiving = false;
        this.$modal.hide('profileUpdatemodal')
        this.usciscUpdateStatusError =error;
      })
    }
    },
    getTenantDetail() {
      let postData = {
        tenantId: this.getUserData["tenantDetails"]["_id"],
      };
      this.$store
        .dispatch("get_tenant_details", postData)
        .then((response) => {
          this.tenantDetailss = response;
        })
        .catch((error) => {});
    },
     },
      computed: {
    resultQuery(){
      if(this.searchQuery){
      return this.resources.filter((item)=>{
        return this.searchQuery.toLowerCase().split(' ').every(v => item.title.toLowerCase().includes(v))
      })
      }else{
      return this.resources.filter((item)=>{
            return item && item.post_parent == 0
      })
      }
    }
  },
     mounted(){
      if((this.getUserRoleId == 3 && this.getTenantTypeId ==2) || this.getUserRoleId == 50){
        this.getGlobalConfigDetails()
      }
        this.getCommonMessages()
        // if(this.getUserRoleId == 50){
        // this.getCompanyDetail()
        // }
        
        this.getTenantDetail()
         this.curretYear = moment().format('YYYY')

         fetch('https://immibox.com/wp-json/help/v1/allposts')
            .then(response => response.json())    // one extra step
            .then(data => {
                this.resources= data;
            })
            .catch((error) => {});

        JQuery(document).keyup(function(e){
          if(e.keyCode==27 ){
             if(document.body.classList.contains('vm--block-scroll')){
              return false;
             }
             
          }
        });

                }
}
</script>
