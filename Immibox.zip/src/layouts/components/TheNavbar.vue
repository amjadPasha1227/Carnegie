 
<template>
  <div class="header_sec">
    <div class="vx-navbar-wrapper">
      <vs-navbar class="vx-navbar navbar-custom" :color="navbarColor" :class="classObj">
        <feather-icon class="sm:inline-flex xl:hidden cursor-pointer mr-1" icon="MenuIcon"
          @click.stop="showSidebar"></feather-icon>

        <template v-if="breakpoint != 'md'">
          <ul class="vx-navbar__starred-pages">
            <draggable v-model="starredPagesLimited" :group="{ name: 'pinList' }" class="flex cursor-move">
              <li class="starred-page" v-for="page in starredPagesLimited" :key="page.url">
                <vx-tooltip :text="page.label" position="bottom" delay=".3s">
                  <feather-icon svgClasses="h-6 w-6" class="p-2 cursor-pointer" :icon="page.labelIcon"
                    @click="$router.push(page.url)"></feather-icon>
                </vx-tooltip>
              </li>
            </draggable>
          </ul>

          <!-- STARRED PAGES MORE -->
          <div class="vx-navbar__starred-pages--more-dropdown" v-if="starredPagesMore.length">
            <vs-dropdown vs-custom-content vs-trigger-click>
              <feather-icon icon="ChevronDownIcon" svgClasses="h-4 w-4" class="cursor-pointer p-2"></feather-icon>
              <vs-dropdown-menu>
                <ul class="vx-navbar__starred-pages-more--list">
                  <draggable v-model="starredPagesMore" :group="{ name: 'pinList' }" class="cursor-move">
                    <li class="
                         starred-page--more
                         flex
                         items-center
                         cursor-pointer
                       " v-for="page in starredPagesMore" :key="page.url" @click="$router.push(page.url)">
                      <feather-icon svgClasses="h-5 w-5" class="ml-2 mr-1" :icon="page.labelIcon"></feather-icon>
                      <span class="px-2 pt-2 pb-1">{{ page.label }}</span>
                    </li>
                  </draggable>
                </ul>
              </vs-dropdown-menu>
            </vs-dropdown>
          </div>

          <div class="header-left-heading" :class="backbutton">
           
            
            <span v-if="pageTitle != 'Dashboard' && checkBackButton" class="backBtn" @click="gotoBackPage()"> <img
                src="@/assets/images/main/return_arrow.png"></span>

            {{ pageTitle }}
          </div>
        <!-- <div class="global_search">
           <input class="searchinput" placeholder="placeholder" />
           <div class="seach_results_sec">
             <div class="results_tab">
               <ul>
                 <li class="active">
                   <a>All</a>
                 </li>
                 <li>
                   <a>Notes</a>
                 </li>
                 <li>
                   <a>Cases</a>
                 </li>
                 <li>
                   <a>Tasks</a>
                 </li>
               </ul>
             </div>
             <div class="results_list">                
               <ul>
                 <li><h4>Notes</h4></li>
                 <li>
                   <figure>                      
                     <img src="@/assets/images/icons/UserRoles.svg">
                   </figure>
                   <div class="results_info">
                     <label>Lorem Ipsum is simply dummy text</label>
                     <p>May 23, 2022 08:12 PM</p>
                   </div>
                 </li>
                 <li>
                   <figure>                      
                     <img src="@/assets/images/icons/UserRoles.svg">
                   </figure>
                   <div class="results_info">
                     <label>Lorem Ipsum is simply dummy text</label>
                     <p>May 23, 2022 08:12 PM</p>
                   </div>
                 </li>
                 <li>
                   <figure>                      
                     <img src="@/assets/images/icons/UserRoles.svg">
                   </figure>
                   <div class="results_info">
                     <label>Lorem Ipsum is simply dummy text</label>
                     <p>May 23, 2022 08:12 PM</p>
                   </div>
                 </li>
               </ul>
             </div>
           </div>
           </div> -->
          <vs-spacer></vs-spacer>
        </template>

        <vs-spacer></vs-spacer>

        <div class="search_action" v-if="[1, 2, 51].indexOf(getUserRoleId) <= -1 && checkProfileComplition">
          <globalSearch ref="globalSearchRef"></globalSearch>
          <div class="searchoverlay" v-on:click.stop.prevent="togleGlobalSearch(); clearSearchText()"></div>
        </div>
      <!-- <div class="search_action" @click="togleGlobalSearch()"  v-if="!getisGlobalSearchOpened">
           <input type="text" placeholder="Search">
         </div> -->

        <div class="create_global" v-if="[51].indexOf(getUserRoleId) < 0 && checkProfileComplition">
          <label><em><img src="@/assets/images/main/plus_red.png" /></em>Create</label>
          <ul>

            <li v-if="routePath != '' && routePath != '/cases' && checkCaseCreatePermisions">
              <router-link :to="{ name: 'petitions', params: { 'openCreatePopup': true } }">
                <em><img src="@/assets/images/main/plus_white.png" /></em>New Case</router-link>
            </li>
            <li v-if="routePath != '' && routePath != '/cap-registrations' && checkCapCaseCreatePermisions">
              <router-link :to="{ name: 'cap-registrations', params: { 'openCreatePopup': true } }">
                <em><img src="@/assets/images/main/plus_white.png" /></em>New CAP Registration</router-link>
            </li>
            <li v-if="routePath != '' && routePath != '/external-cases' && checkCaseCreatePermisions && checkAllow">
              <router-link :to="{ name: 'external-cases', params: { 'openCreatePopup': true } }">
                <em><img src="@/assets/images/main/plus_white.png" /></em>New External Case</router-link>
            </li>
            <li v-if="routePath != '' && routePath != '/pwd-list' && checkCaseCreatePermisions">
              <router-link :to="{ name: 'pwd-list', params: { 'openCreatePopup': true } }">
                <em><img src="@/assets/images/main/plus_white.png" /></em>New PWD</router-link>
            </li>

          <!--  <li  v-if="routePath !='' && routePath !='/perm' && checkCaseCreatePermisions">
           <router-link :to="{ name: 'perm', params: { 'openCreatePopup':true }}">
             <em><img src="@/assets/images/main/plus_white.png" /></em>New PERM</router-link>
             </li> -->
             <li v-if="routePath != '' && routePath != '/lcalist' && checkLCACreatePermisions">
              <router-link :to="{ name: 'lca', params: { 'openCreatePopup': true } }">
                <em><img src="@/assets/images/main/plus_white.png" /></em>New LCA</router-link>
            </li>

            <li v-if="routePath != '' && routePath != '/tasks-list' && [1, 2, 50, 51].indexOf(getUserRoleId) <= -1">
              <router-link :to="{ name: 'tasks-list', params: { 'openCreatePopup': true } }">
                <em><img src="@/assets/images/main/plus_white.png" /></em>New Task</router-link>
            </li>

            <li v-if="routePath != '' && routePath != '/petitioners' && checkPetInvitePermisions && getTenantTypeId != 2">
              <router-link :to="{ name: 'petitioners', params: { 'openCreatePopup': true } }">
                <em><img src="@/assets/images/main/plus_white.png" /></em>New Customer</router-link>
            </li>
            <li v-if="routePath != '' && routePath != '/individuals' && checkPetInvitePermisions">
              <router-link :to="{ name: '/individuals', params: { 'openCreatePopup': true } }">
                <em><img src="@/assets/images/main/plus_white.png" /></em>New Individual</router-link>
            </li>
            <li v-if="routePath != '' && routePath != '/support-tickets' && getUserRoleId != 1 && getUserRoleId != 2">
              <router-link :to="{ name: 'support-tickets', params: { 'openCreatePopup': true } }">
                <em><img src="@/assets/images/main/plus_white.png" /></em>Support Ticket</router-link>
            </li>
            <li v-if="routePath != '' && routePath != '/notes-list'">
              <router-link :to="{ name: 'notes-list', params: { 'openCreatePopup': true } }">
                <em><img src="@/assets/images/main/plus_white.png" /></em>Note</router-link>
            </li>
          </ul>
        </div>
        <div class="casecalendar_btn" v-if="[1, 2, 50, 51].indexOf(getUserRoleId) < 0 && checkProfileComplition">
          <router-link class="calendar_btn" to="/deadlines">Deadlines</router-link>
        </div>

        <!-- Messages -->
        <div @click="getCommunicationList(true)" v-if="checkProfileComplition">
          <vs-dropdown vs-custom-content :vs-trigger-click="true" class="cursor-pointer notification-alert">
          <!-- <feather-icon
           icon="BellIcon"
           class="cursor-pointer mt-1 sm:mr-6 mr-2"
           :badge="unreadNotifications.length"
           ></feather-icon> -->
            <span class="notification-icon">
              <img src="@/assets/images/main/messages.svg" />
              <em v-if="checkProperty(communicationData, 'list', 'length') > 0 && showMessageIcon"></em>
            </span>
            <vs-dropdown-menu class="notification-dropdown dropdown-custom vx-navbar-dropdown"
              :class="{ 'no-notifications-dropdown': communicationData && checkProperty(communicationData, 'list', 'length') == 0 }"
              ref="filter_menu">
              <div class="notification-top">
                <h3>{{ checkProperty(communicationData, 'list', 'length') >
                  0 ? checkProperty(communicationData, 'list', 'length') : 'No ' }} Message(s)</h3>
                   <!-- v-if="checkProperty(communicationData, 'totalCount') > 10" -->
                   <template v-if="checkProperty(communicationData, 'totalCount') >= 1">
                <a href="javascript:;" 
                  @click="$router.push('/messages'); closeMessage()">
                  <span>View All</span>
                </a>
              </template>

              </div>
              <VuePerfectScrollbar ref="mainSidebarPs" class="scroll-area--nofications-dropdown p-0" :settings="settings">
                <ul>

                  <li v-for="(tr, indexx) in communicationData['list']" :key="indexx"
                    class="flex justify-between notification cursor-pointer" @click="tr['read'] = true"
                    :class="{ 'message-readed': checkProperty(tr, 'read') }">
                    <div class="flex items-start notification-items">
                      <div @click="tr['read'] = true; communicationlink(tr); closeMessage()">
                        <!-- {{ checkProperty(tr,'message') }  v-html="checkProperty(tr, 'message')"} -->
                        <span class="font-medium block notification-title">
                          {{ getTrimmedContent(tr.message) }}
                        </span>
                        <p class="time" v-if="checkProperty(tr, 'fromUserName')">
                          <span> {{ checkProperty(tr, 'fromUserName') }}<em>({{ checkProperty(tr, 'fromUserRoleName')
                          }})</em>
                            - {{ tr.createdOn | formatDateTime }}</span>
                        </p>
                        <span class="time" v-if="checkProperty(tr, 'petitionDetails')">
                          {{ tr.petitionDetails.caseNo }}
                        </span>
                      </div>
                    </div>


                  </li>
                </ul>


              </VuePerfectScrollbar>

            </vs-dropdown-menu>
            <!-- Messages -->
            <vs-dropdown-menu class="notification-dropdown dropdown-custom vx-navbar-dropdown">
              <div class="notification-top">
                <h3>{{ unreadNotifications.length > 0 ? unreadNotifications.length : 'No ' }} Notifications</h3>

                <a href="javascript:;" v-if="unreadNotifications.length > 0"
                  @click="conformDeleteNotification('removeAll')">
                  <span>Delete All</span>
                </a>
              </div>

              <VuePerfectScrollbar ref="mainSidebarPs" class="scroll-area--nofications-dropdown p-0" :settings="settings">
                <ul>
                  <li v-for="ntf in unreadNotifications" :key="ntf.index"
                    class="flex justify-between notification cursor-pointer">
                    <div class="flex items-start notification-items">
                      <!--<feather-icon :icon="ntf.icon" :svgClasses="[`text-${ntf.category}`, 'stroke-current mr-1 h-6 w-6']"></feather-icon>-->
                      <div>
                        <span class="font-medium block notification-title">
                          {{ ntf.title }}
                        </span>
                        <p>{{ ntf.description }}</p>
                        <span class="time">{{ ntf.createdOn | timeago }}</span>
                        <a href="javascript:;" @click="conformDeleteNotification(ntf['_id'])">Delete</a>
                      </div>
                    </div>
                  </li>
                </ul>
              </VuePerfectScrollbar>
            <!-- <div class="
                       checkout-footer
                       fixed
                       bottom-0
                       rounded-b-lg
                       text-primary
                       w-full
                       p-2
                       font-semibold
                       text-center
                       border
                       border-b-0
                       border-l-0
                       border-r-0
                       border-solid
                       d-theme-border-grey-light
                       cursor-pointer">
                       <span>View All Notifications</span>
             </div>-->
            </vs-dropdown-menu>
          </vs-dropdown>
        </div>
        <!-- USER META -->
        <div class="the-navbar__user-meta flex items-center">
          <vs-dropdown vs-custom-content vs-trigger-click class="cursor-pointer">
            <div class="profile">
              <div class="profile-icon">
                <figure>
                  <img @error="setDefaultPhoto($event)" key="onlineImg" :src="user.profilePicture" alt="user-img"
                    height="30" />
                <!-- <img
                   v-else
                   key="localImg"
                   :src="require(`@/assets/images/portrait/small/${activeUserImg}`)"
                   alt="user-img"
                   width="30"
                   height="30"
                   @error="setDefaultPhoto($event)"
                     />-->
                </figure>
                <!-- <span style="text-transform:uppercase">{{user.name.substring(0,2)}}</span> -->
              </div>
              <div class="profile-text text-right hidden sm:block">
                <p class="">

                  <template v-if="checkProperty(user, 'name') != ''">
                    {{ user.name }}
                  </template>
                  <template v-else>
                    {{ user.userName }}
                  </template>

                </p>
                <small v-if="user.loginRoleName">{{
                  user.loginRoleName
                }}</small>
                <small v-else-if="getUserRoleName">{{
                  getUserRoleName
                }} </small>
              </div>
              <em class="profile_arrow hidden sm:flex"><img src="@/assets/images/main/down_arrow3.svg" /></em>
            </div>
            <vs-dropdown-menu color="#fff" class="vx-navbar-dropdown actions-dropdown profileDropdown">
              <ul style="min-width: 9rem" class="profileMenu">
                <vs-dropdown-item to="/profile">
                  <feather-icon icon="UserIcon" svgClasses="w-4 h-4"></feather-icon>
                  <span class="ml-2">Profile</span>
                </vs-dropdown-item>
              <!-- <vs-dropdown-item to="/mytasks">
                 <feather-icon
                   icon="CheckSquareIcon"
                   svgClasses="w-4 h-4"
                 ></feather-icon>
                 <span class="ml-2">Tasks</span>
                 </vs-dropdown-item> -->
                <vs-dropdown-item v-if="[1, 2, 3, 50].indexOf(getUserRoleId) > -1" to="/basic-settings">
                  <feather-icon icon="CheckSquareIcon" svgClasses="w-4 h-4"></feather-icon>
                  <span class="ml-2">{{getSettingsTitle}}</span>
                </vs-dropdown-item>


                <vs-divider class="m-1"></vs-divider>
                <vs-dropdown-item @click="logout">
                  <feather-icon icon="LogOutIcon" svgClasses="w-4 h-4"></feather-icon>
                  <span class="ml-2">Logout</span>
                </vs-dropdown-item>
              </ul>
            </vs-dropdown-menu>
          </vs-dropdown>
        </div>
      </vs-navbar>
    </div>
    <vs-popup class="Change_petition_wrap" v-bind:title="notification_popuptitle" :active.sync="deleteAllConform">
      <div class="Change_petition">
        <div class="vx-col w-full marb10">
          <h3 class="text-center">
            Are you sure want to delete notification(s)?
          </h3>
        </div>
      </div>
      <div class="actions_footer">
        <button @click="deleteAllConform = false" class="btn cancel">No</button>
        <button class="btn" @click="action_onnotification('removeAll')">
          Yes
        </button>
      </div>
    </vs-popup>



  </div>
</template>

<script>
import VxAutoSuggest from "@/components/vx-auto-suggest/VxAutoSuggest.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import draggable from "vuedraggable";
import DateRangePicker from "vue2-daterange-picker";
import moment from "moment";
import Datepicker from "vuejs-datepicker-inv";
import globalSearch from "@/views/globalSearchh.vue";

import * as _ from "lodash";
import { indexOf } from "@amcharts/amcharts4/.internal/core/utils/Array";

export default {
  name: "the-navbar",
  props: {
    navbarColor: {
      type: String,
      default: "#fff",
    },
  },
  data() {
    return {
      canRegCap:false,
      archiving: false,
      tenantDetailss: '',
      msgPetitionId: '',
      showMessages: false,
      routePath: '',
      showModel: false,
      communicationData: [],
      formSubmited: false,
      showIncompleteCheckListTxt: true,
      isloading: false,
      backURL: null,
      documents: [],
      countries: [],
      states: [],
      locations: [],
      formerrors: {
        msg: "",
      },
      disabledDates: {
        to: new Date(),
      },
      navbarSearchAndPinList: this.$store.state.navbarSearchAndPinList,
      searchQuery: "",
      showFullSearch: false,
      pageTitle: "",
      unreadNotifications: [],
      settings: {

        wheelSpeed: 0.6,
      },
      autoFocusSearch: false,
      showBookmarkPagesDropdown: false,
      SubmtRminder: false,
      reminder: {
        name: "",
        description: "",
        dueDate: new Date(),
      },
      autoApply: "",
      reminderCount: 0,
      disable_reminder_btn: false,
      delNotification: { notifyId: "", removeAll: false },
      deleteAllConform: false,
      notification_popuptitle: "Delete",
    };
  },
  watch: {
    $route() {
      this.checkCapRegcase();
      //this.getCommunicationList()
      this.getRoutePath()
      this.pageTitle = this.$route.meta.title;
      this.formSubmited = false;


      if (this.showBookmarkPagesDropdown)
        this.showBookmarkPagesDropdown = false;

    },
    // $route (to, from){
    //     this.getCommunicationList();
    // }
  },
  mounted() {
    
    this.checkCapRegcase();
    this.canRegCap = false;
    this.getRoutePath()
    this.getCommunicationList()
    this.pageTitle = this.$route.meta.title;
    // this.getNotifications();
    this.getReminderlist();
  },
  computed: {
    checkAllow(){
            let returnVal = false;
            if(this.checkProperty(this.$store.state,'user') && this.checkProperty(this.$store.state,'user','globalConfig')){
                if(this.checkProperty(this.$store.state['user'],'globalConfig','isAllowExternalCases')){
                    returnVal = true;
                }else{
                    returnVal = false;
                }
            }else{
                returnVal = false;
            }
            return returnVal;
           //return this.$store.state.user.globalConfig.isAllowExternalCases
        },
    checkBackButton(){
      let allTitles = [
        "LCA Library",
        "Messages",
        "PWD Library",
        "My Profile","Deadlines","Dashboard","Cases" ,
      "RFE Cases" ,"Bulk Assignment" ,
      "Cap Registrations" ,"Cap Registrations","Corporate Customer Reports",
      "Individual Customer Reports","Sent Emails","Tasks","Customers","Individuals",
      "Beneficiaries","Documents" ,"Notes","Support Tickets","Users","Company Details & Settings" 
      ,"LCA",
      "External Cases",
      "Case Reports",
      "Over Due Reports",
      "Cap Registrations",
      "Overdue Cases",
      "Branchwise Case Summary",
      "Cases by Customer",
      "Case List"
    ]
      let pgTitle = this.pageTitle;
        pgTitle = pgTitle.trim();
      
        if(allTitles.indexOf(pgTitle)>-1){

          return false;
        }else{
          return true;
        }
    },

    checkProfileComplition() {
      let returnVal = true;
      if ([3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14].indexOf(this.getUserRoleId) > -1) {
        returnVal = false;
        let userData = this.getUserData;

        if (this.checkProperty(userData, 'tenantDetails', 'profCompleted') == "Yes") {
          returnVal = true;
        }

      } else if ([50].indexOf(this.getUserRoleId) > -1) {
        returnVal = false;
        let userData = this.getUserData;

        if (this.checkProperty(userData, 'companyRegistrationCompleted')) {
          returnVal = true;
        }
      }
      return returnVal;
    },
    showMessageIcon() {


      if (_.find(this.communicationData['list'], { 'read': false })) {
        return true;
      } else {
        return false;
      }
    },

    getUserRoleName() {
      let userData = this.getUserData;
      if (_.has(userData, "loginRoleName")) {
        return userData['loginRoleName'];

      } else {
        return false;
      }
    },
    user() {
      return this.$store.state.user;
    },
    sidebarWidth() {
      return this.$store.state.sidebarWidth;
    },
    breakpoint() {
      return this.$store.state.breakpoint;
    },
    backbutton() {
      if (this.$store.state.common.fromState) {
        let fromUrl = this.$store.state.common.fromState.path;
        if (this.$route.path != '/dashboard' && fromUrl != "/" && fromUrl != this.$route.path) {
          this.backURL = fromUrl;
          return "bkenable";
        } else {
          return "";
        }
      } else {
        return "";
      }
    },
    classObj() {
      if (this.sidebarWidth == "default") return "navbar-default";
      else if (this.sidebarWidth == "reduced") return "navbar-reduced";
      else if (this.sidebarWidth == "extended") return "navbar-reduced";
      else if (this.sidebarWidth) return "navbar-full";
    },
    data() {
      return this.$store.state.navbarSearchAndPinList;
    },
    starredPages() {
      return this.$store.state.starredPages;
    },
    starredPagesLimited: {
      get() {
        return this.starredPages.slice(0, 10);
      },
      set(list) {
        this.$store.dispatch("arrangeStarredPagesLimited", list);
      },
    },
    starredPagesMore: {
      get() {
        return this.starredPages.slice(10);
      },
      set(list) {
        this.$store.dispatch("arrangeStarredPagesMore", list);
      },
    },

    user_displayName() {
      return "john_doe";
    },
    activeUserImg() {
      return this.$store.state.AppActiveUser.img;
    },
    getSettingsTitle() {
      if ([1].indexOf(this.getUserRoleId) > -1) {
        return "Settings"
      } else {
        return "Company Details & Settings"
      }
    }

  },
  methods: {
    getTrimmedContent(content) {
      // Strip HTML tags using a temporary element
      const tempElement = document.createElement("div");
      tempElement.innerHTML = content;
      const plainText = tempElement.textContent || tempElement.innerText || "";

      // Trim the content to 200 characters and add "..." if needed
      const trimmedText = plainText.length > 100 ? plainText.slice(0, 100) + "..." : plainText;

      return trimmedText;
    },
    checkCapRegcase(){
      this.canRegCap = false;
      this.$store.dispatch("commonAction", { "data": {}, "path": "/cap-registrations/can-create-case" }).then((response) => {
        this.canRegCap = response;
        
        })
    },
    makeAsRead() {

      let postData = { "messageIds": [] };

      let messages = _.filter(this.communicationData['list'], (item) => {
        return (this.checkProperty(item, 'fromUserId') != this.checkProperty(this.getUserData, 'userId')) && this.checkProperty(item, 'read') != true;
      })

      postData['messageIds'] = messages.map((item) => item['_id']);

      if (this.checkProperty(postData['messageIds'], 'length') > 0) {


        this.$store.dispatch("commonAction", { "data": postData, "path": "/communication/mark-as-read" }).then((response) => {
          
        })

      }

    },

    getCommunicationList(callFromClick = false) {

      let obj = {
        forNotifications: true,
        filters: {
          caseNo: "",
          petitionIds: [],
          typeIds: [],
          subTypeIds: [],
          createdDateRange: [],
          forNotifications: true,
          msgListType:'inbox'
        },
        page: 1,
        perpage: 10,
      };
      this.$store.dispatch("getList", { data: obj, path: "/communication/list" })
        .then((response) => {
          this.communicationData = response;
          if (this.msgPetitionId && this.checkProperty(this.communicationData, 'list', 'length') > 0) {
            _.forEach(this.communicationData['list'], (item) => {
              if (this.checkProperty(item, 'petitionId') == this.msgPetitionId) {
                item['read'] = true;

              }
            })
            this.msgPetitionId = '';



          }
          if (callFromClick) {
            // setTimeout(()=>{
            this.makeAsRead();
            //},300)
          }

        }).catch((error) => {

        })
    },

    communicationlink(value) {
      this.msgPetitionId = this.checkProperty(value, 'petitionId');
      if (this.checkProperty(value, 'entityType') == 'case') {
        this.$router.push({ name: 'petition-details', params: { itemId: this.checkProperty(value, 'petitionId'), tabname: 'Communication' } }).catch(err => { })
      }
      if (this.checkProperty(value, 'entityType') == 'perm') {
        this.$router.push({ name: 'gc-employment-details', params: { itemId: this.checkProperty(value, 'petitionId'), tabname: 'Communication' } }).catch(err => { })
      }
    },
    closeMessage() {
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    getRoutePath() {
      this.routePath = '';
      setTimeout(() => {
        this.routePath = this.$router.currentRoute.path
      }, 100);

    },
    clearSearchText() {
      try {

        this.$refs['globalSearchRef'].clearText();

      } catch (e) {

      }
    },
    gotoBackPage() {
      let routesArray = ['/cases', '/petitions', '/ref-cases', '/perm','/external-cases','/notes-list','/support-tickets',
      '/beneficiaries','/petitioners','/individuals','/lcalist','/pwd-list','/cap-registrations']
      if (routesArray.indexOf(this.backURL) > -1) {
        let path = { 'path': this.backURL, "query": {} }

        if (this.checkProperty(this.$route, 'query', 'filter')) {
          path["query"]['filter'] = this.checkProperty(this.$route, 'query', 'filter')
        }
        this.$router.push(path);

      } else {
        this.$router.push(this.backURL)

      }

    },
    editMyDetails() {
      if (this.getUserRoleId == 3) {
        this.$store.dispatch("editTenantDetails").then((res) => {
          this.isTenantProfileCompleted;
        });
      }
    },
    editCompanyDetails() {
      this.$store.dispatch("editCompanyDetails").then((res) => {
        this.getPetitionerProfileCompaltion();
      });
    },
    updateCompanyPhone(item) {
      if (item.isValid) {
        this.updateCompanyData.phoneCountryCode = {
          countryCode: item.countryCode,
          countryCallingCode: item.countryCallingCode,
        };
        this.updateCompanyData.phone = item.nationalNumber;
      }
    },
    updateCompanyFax(item) {
      if (item.isValid) {
        this.updateCompanyData.faxCountryCode = {
          countryCode: item.countryCode,
          countryCallingCode: item.countryCallingCode,
        };
        this.updateCompanyData.fax = item.nationalNumber;
      }
    },
    updateAuthorizedSignatoryPhone(item) {
      if (item.isValid) {
        this.updateCompanyData["authorizedSignatory"].phoneCountryCode = {
          countryCode: item.countryCode,
          countryCallingCode: item.countryCallingCode,
        };
        this.updateCompanyData["authorizedSignatory"].phone =
          item.nationalNumber;
      }
    },
    getCompanyDetails() {
      let postData = { companyId: this.getUserData["companyId"] };
      this.$store
        .dispatch("getCompanyDetails", postData)
        .then((response) => {
          let companyData = response;
          this.companyDetails = response;
          this.getPetitionerProfileCompaltion;
          //now update updateCompanyData verable for update company data.
          _.forEach(companyData, (value, key) => {
            // alert("key=="+key +"   VALUE=="+value);
            if (key == "address") {
              let address = {
                line1: "",
                line2: "",
                countryId: "",
                selectedCountry: null,
                stateId: "",
                selectedState: null,
                locationId: "",
                selectedCity: null,
                zipcode: "",
              };

              _.forEach(companyData["address"], (adval, adkey) => {
                if (_.has(address, adkey)) {
                  address[adkey] = adval;
                }
              });

              this.updateCompanyData["address"] = address;
              this.updateCompanyData = _.cloneDeep(this.updateCompanyData);

              if (_.has(this.updateCompanyData["address"], "countryId")) {
                if (this.countries.length >= 0) {
                  this.updateCompanyData["address"]["selectedCountry"] = _.find(
                    this.countries,
                    { id: this.updateCompanyData["address"]["countryId"] }
                  );
                  this.updateCompanyData = _.cloneDeep(this.updateCompanyData);
                  this.changedCountry();
                }
              }
            } else if (key == "authorizedSignatory") {
              _.forEach(
                companyData["authorizedSignatory"],
                (authval, authkey) => {
                  if (
                    _.has(
                      this.updateCompanyData["authorizedSignatory"],
                      authkey
                    )
                  ) {
                    this.updateCompanyData.authorizedSignatory[authkey] =
                      authval;
                    //alert(this.updateCompanyData['authorizedSignatory'][authkey]);
                  }
                }
              );
            } else if (_.has(this.updateCompanyData, key)) {
              this.updateCompanyData[key] = value;
              if (key == "are50orMoreEmployeesInUS") {
                if (value.toLowerCase() == "yes") {
                  this.updateCompanyData["are50orMoreEmployeesInUS"] = true;
                } else {
                  this.updateCompanyData["are50orMoreEmployeesInUS"] = false;
                }
              }
              if (key == "finalDeterminationFromDOL") {
                if (value.toLowerCase() == "yes") {
                  this.updateCompanyData["finalDeterminationFromDOL"] = true;
                } else {
                  this.updateCompanyData["finalDeterminationFromDOL"] = false;
                }
              }
              if (key == "areAbove50PercentH1BL1ALABStatus") {
                if (value.toLowerCase() == "yes") {
                  this.updateCompanyData[
                    "areAbove50PercentH1BL1ALABStatus"
                  ] = true;
                } else {
                  this.updateCompanyData[
                    "areAbove50PercentH1BL1ALABStatus"
                  ] = false;
                }
              }
            }
            let tempupdateCompanyData = _.cloneDeep(this.updateCompanyData);
            this.updateCompanyData = tempupdateCompanyData;
          });
          this.$validator.reset();
        })
        .catch((error) => {
        });
    },
    updateCompanyDetails() {
      //alert(JSON.stringify(this.updateTenantData))
      this.$validator.validateAll().then((result) => {
        if (result) {
          let postData = _.cloneDeep(this.updateCompanyData);

          postData = Object.assign(postData, { completeRegistration: true });

          if (this.updateCompanyData.are50orMoreEmployeesInUS) {
            postData = Object.assign(postData, {
              are50orMoreEmployeesInUS: "Yes",
            });
          } else {
            postData = Object.assign(postData, {
              are50orMoreEmployeesInUS: "No",
            });
          }

          if (this.updateCompanyData.areAbove50PercentH1BL1ALABStatus) {
            postData = Object.assign(postData, {
              areAbove50PercentH1BL1ALABStatus: "Yes",
            });
          } else {
            postData = Object.assign(postData, {
              areAbove50PercentH1BL1ALABStatus: "No",
            });
          }
          if (this.updateCompanyData.finalDeterminationFromDOL) {
            postData = Object.assign(postData, {
              finalDeterminationFromDOL: "Yes",
            });
          } else {
            postData = Object.assign(postData, {
              finalDeterminationFromDOL: "No",
            });
          }
          this.formSubmited = true;
          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: "/company/update",
            })
            .then((response) => {
              this.showToster({ message: response.message, isError: false });

              this.completeTenantprofile = false;
              this.getCompanyDetails();

              this.getPetitionerProfileCompaltion;
              this.formSubmited = false;
            })
            .catch((error) => {
              this.formSubmited = false;
              this.showToster({ message: error, isError: true });
            });
        }
      });
    },
    removeText() {
      this.$store.dispatch("removeText");
    },
    getTenantDetails() {
      let postData = {
        tenantId: this.getUserData["tenantDetails"]["_id"],
      };
      this.$store
        .dispatch("get_tenant_details", postData)
        .then((response) => {
          this.tenantDetails = response;
          this.initTenantProfileData();
          this.isTenantProfileCompleted;
        })
        .catch((error) => {
          this.showToster({ message: error, isError: true });
        });
    },
    updatePhone(item) {
      if (item.isValid) {
        this.updateTenantData.phoneCountryCode = {
          countryCode: item.countryCode,
          countryCallingCode: item.countryCallingCode,
        };
        this.updateTenantData.phone = item.nationalNumber;
      }
    },
    initTenantProfileData() {
      if (this.getUserRoleId == 3 && _.has(this.getUserData, "tenantDetails")) {
        let tempupdateTenantData = this.updateTenantData;
        let tenantDetails = this.getUserData["tenantDetails"];

        let address = {
          line1: "",
          line2: "",
          countryId: "",
          selectedCountry: null,
          stateId: "",
          selectedState: null,
          locationId: "",
          selectedCity: null,
          zipcode: "",
        };

        //	"name": "",
        // "adminEmail":'',

        if (_.has(this.tenantDetails, "name") && tenantDetails.name.trim()) {
          tempupdateTenantData["name"] = this.tenantDetails.name.trim();
        }
        if (
          _.has(this.tenantDetails, "adminEmail") &&
          tenantDetails.adminEmail.trim()
        ) {
          tempupdateTenantData["adminEmail"] =
            this.tenantDetails.adminEmail.trim();
        }
        if (
          _.has(this.tenantDetails, "adminFirstName") &&
          tenantDetails.adminFirstName.trim()
        ) {
          tempupdateTenantData["adminFirstName"] =
            this.tenantDetails.adminFirstName.trim();
        }
        if (
          _.has(this.tenantDetails, "adminLastName") &&
          tenantDetails.adminLastName.trim()
        ) {
          tempupdateTenantData["adminLastName"] =
            this.tenantDetails.adminLastName.trim();
        }
        if (_.has(this.tenantDetails, "phone") && tenantDetails.phone) {
          tempupdateTenantData["phone"] = this.tenantDetails.phone;
        }
        if (
          _.has(this.tenantDetails, "phoneCountryCode") &&
          tenantDetails.phoneCountryCode
        ) {
          tempupdateTenantData["phoneCountryCode"] =
            this.tenantDetails.phoneCountryCode;
        }

        if (_.has(this.tenantDetails, "logo") && tenantDetails.phone) {
          tempupdateTenantData["logo"] = this.tenantDetails.logo;
        }
        if (_.has(this.tenantDetails, "favicon") && tenantDetails.favicon) {
          tempupdateTenantData["favicon"] = this.tenantDetails.favicon;
        }
        if (_.has(this.tenantDetails, "fromEmail") && tenantDetails.fromEmail) {
          tempupdateTenantData["fromEmail"] = this.tenantDetails.fromEmail;
        }
        if (
          _.has(this.tenantDetails, "contactEmail") &&
          tenantDetails.contactEmail
        ) {
          tempupdateTenantData["contactEmail"] =
            this.tenantDetails.contactEmail;
        }
        if (
          _.has(this.tenantDetails, "contactEmail") &&
          tenantDetails.contactEmail
        ) {
          tempupdateTenantData["contactEmail"] =
            this.tenantDetails.contactEmail;
        }
        if (_.has(this.tenantDetails, "slug") && tenantDetails.slug) {
          tempupdateTenantData["slug"] = this.tenantDetails.slug;
        }
        if (_.has(this.tenantDetails, "idPrefix") && tenantDetails.idPrefix) {
          tempupdateTenantData["idPrefix"] = this.tenantDetails.idPrefix;
        }
        if (_.has(this.tenantDetails, "idPrefix") && tenantDetails.idPrefix) {
          tempupdateTenantData["idPrefix"] = this.tenantDetails.idPrefix;
        }

        if (_.has(this.tenantDetails, "address")) {
          tempupdateTenantData["address"] = address;
          if (_.has(this.tenantDetails["address"], "line1")) {
            tempupdateTenantData["address"]["line1"] =
              tenantDetails["address"]["line1"];
          }
          if (_.has(this.tenantDetails["address"], "line2")) {
            tempupdateTenantData["address"]["line2"] =
              tenantDetails["address"]["line2"];
          }
          if (_.has(this.tenantDetails["address"], "countryId")) {
            tempupdateTenantData["address"]["countryId"] =
              tenantDetails["address"]["countryId"];
            if (this.countries.length >= 0) {
              tempupdateTenantData["address"]["selectedCountry"] = _.find(
                this.countries,
                { id: tempupdateTenantData["address"]["countryId"] }
              );
              this.changedCountry();
            }
          }
          if (_.has(this.tenantDetails["address"], "stateId")) {
            tempupdateTenantData["address"]["stateId"] =
              tenantDetails["address"]["stateId"];
          }
          if (_.has(this.tenantDetails["address"], "locationId")) {
            tempupdateTenantData["address"]["locationId"] =
              tenantDetails["address"]["locationId"];
          }
          if (_.has(this.tenantDetails["address"], "zipcode")) {
            tempupdateTenantData["address"]["zipcode"] =
              tenantDetails["address"]["zipcode"];
          }
        } else {
          tempupdateTenantData["address"] = address;
        }

        if (_.has(this.tenantDetails, "_id") && tenantDetails._id) {
          tempupdateTenantData["tenantId"] = this.tenantDetails._id;
        }

        tempupdateTenantData = Object.assign(tempupdateTenantData, {
          profComplted: "no",
        });
        if (_.has(this.tenantDetails, "profComplted")) {
          tempupdateTenantData["profComplted"] = tenantDetails["profComplted"];
        }

        this.updateTenantData = tempupdateTenantData;

        if (
          /*
       ( !(_.has(this.updateTenantData ,'adminFirstName')) || !this.updateTenantData.adminFirstName.trim())
       || ( !(_.has(this.updateTenantData ,'adminLastName')) || !this.updateTenantData.adminLastName.trim())
       ||  ( !(_.has(this.updateTenantData ,'phone')) || !this.updateTenantData.phone)
       ||  ( !(_.has(this.updateTenantData ,'logo')) || !this.updateTenantData.logo.trim())
       ||  ( !(_.has(this.updateTenantData ,'favicon')) || !this.updateTenantData.favicon.trim())
       ||  ( !(_.has(this.updateTenantData ,'fromEmail')) || !this.updateTenantData.fromEmail.trim())
       ||  ( !(_.has(this.updateTenantData ,'contactEmail')) || !this.updateTenantData.contactEmail.trim())
       ||
       */
          !_.has(this.tenantDetails, "profComplted") ||
          !tenantDetails.profComplted.trim() ||
          tenantDetails.profComplted.toLowerCase() != "yes"
          //||  ( !(_.has(this.updateTenantData ,'slug')) || !this.updateTenantData.slug.trim())
          //||  ( !(_.has(this.updateTenantData ,'idPrefix')) || !this.updateTenantData.idPrefix.trim())
          /*
       ||  ( !(_.has(this.updateTenantData ,'address')) || !this.updateTenantData.address)
       ||  ( !(_.has(this.updateTenantData['address'] ,'line1')) || !this.updateTenantData['address'].line1)
       ||  ( !(_.has(this.updateTenantData['address'] ,'line2')) || !this.updateTenantData['address'].line2)
       ||  ( !(_.has(this.updateTenantData['address'] ,'countryId')) || !this.updateTenantData['address'].countryId)
       ||  ( !(_.has(this.updateTenantData['address'] ,'stateId')) || !this.updateTenantData['address'].stateId)
       ||  ( !(_.has(this.updateTenantData['address'] ,'locationId')) || !this.updateTenantData['address'].locationId)
       ||  ( !(_.has(this.updateTenantData['address'] ,'zipcode')) || !this.updateTenantData['address'].zipcode)
       */
        ) {
          this.completeTenantprofile = true;
        }
      }
      this.$validator.reset();
    },
    updateTenantProfile() {
      //alert(JSON.stringify(this.updateTenantData))
      this.$validator.validateAll().then((result) => {
        if (result) {
          let postData = _.cloneDeep(this.updateTenantData);

          if (this.updateTenantData.profComplted != "Yes") {
            // this.updateTenantData.profComplted ="Yes";
            postData = Object.assign(postData, {
              assetPath: postData["slug"].trim(),
              profComplted: "Yes",
              profCompleted: "Yes",
            });
          }
          this.formSubmited = true;
          //alert();
          //return false;
          this.$store
            .dispatch("updateTenantProfile", postData)
            .then((response) => {
              this.showToster({ message: response.message, isError: false });
              this.completeTenantprofile = false;
              this.getTenantDetails();
              this.isTenantProfileCompleted;
              this.formSubmited = false;
            })
            .catch((error) => {
              this.formSubmited = false;
              this.showToster({ message: error, isError: true });
            });
        }
      });
    },
    upload(files, type = "logo") {
      let model = _.cloneDeep(files);
      this.documents = [];
      this.loading = true;
      let formData = new FormData();
      let temp_count = 0;
      let mapper = model.map(
        (item) =>
        (item = {
          name: item.name,
          file: item.file ? item.file : null,
          path: item.url ? item.url : "",
          url: item.url ? item.url : "",
          extn: item.name.split(".").pop(),
          mimetype: item.type ? item.type : item.mimetype,
        })
      );

      if (mapper.length > 0) {
        this.isloading = true;
        mapper.forEach((doc, index) => {
          formData.append("files", doc.file);
          formData.append("secureType", "public");
          this.$store.dispatch("uploadS3File", formData).then((response) => {
            temp_count++;
            // alert(type) updateCompanyData
            response.data.result.forEach((urlGenerated) => {
              if (this.getUserRoleId == 12) {
                if (type == "logo") {
                  this.updateCompanyData = Object.assign(
                    this.updateCompanyData,
                    { logo: urlGenerated }
                  );
                } else {
                  // alert(type+" ----- ")
                  this.updateCompanyData = Object.assign(
                    this.updateCompanyData,
                    { favicon: urlGenerated }
                  );
                }
              } else {
                if (type == "logo") {
                  this.updateTenantData = Object.assign(this.updateTenantData, {
                    logo: urlGenerated,
                  });
                } else {
                  // alert(type+" ----- ")
                  this.updateTenantData = Object.assign(this.updateTenantData, {
                    favicon: urlGenerated,
                  });
                }
              }

              if (temp_count >= mapper.length) {
                this.documents = [];
              }
              doc.url = urlGenerated;
              delete doc.file;
              mapper[index] = doc;
            });
          });
        });
        model.splice(0, mapper.length, ...mapper);
      }
    },
    remove(item) {
      if (this.getUserRoleId == 12) {
        this.updateCompanyData[item] = "";
      } else {
        this.updateTenantData[item] = "";
      }
    },
    changedCountry() {
      this.states = [];
      this.locations = [];
      let dataKey = "updateTenantData";
      if (this.getUserRoleId == 12) {
        dataKey = "updateCompanyData";
      }
      if (_.has(this[dataKey].address.selectedCountry, "id")) {
        this[dataKey].address.countryId =
          this[dataKey].address.selectedCountry["id"];

        this.masterData("states");
      }
    },
    changedState() {
      let dataKey = "updateTenantData";
      if (this.getUserRoleId == 12) {
        dataKey = "updateCompanyData";
      }

      this.locations = [];
      if (_.has(this[dataKey].address.selectedState, "id")) {
        this[dataKey].address.stateId =
          this[dataKey].address.selectedState["id"];
        this.masterData("locations");
      }
    },
    //locationId
    changedCity() {
      let dataKey = "updateTenantData";
      if (this.getUserRoleId == 12) {
        dataKey = "updateCompanyData";
      }

      if (_.has(this[dataKey].address.selectedCity, "id")) {
        this[dataKey].address.locationId =
          this[dataKey].address.selectedCity["id"];
        this.masterData("locations");
      }
    },
    getNotifications() {
      let poatData = { page: 1, perpage: 99999 };
      this.$store
        .dispatch("getGlobalnotifications", poatData)
        .then((response) => {
          this.unreadNotifications = response.result.list;
        });
    },
    conformDeleteNotification(notifyId = "") {
      this.delNotification = { notifyId: "", removeAll: false };
      if (notifyId == "removeAll") {
        this.delNotification = { removeAll: true };
        this.notification_popuptitle = "Delete All";
      } else {
        this.delNotification = { notifyId: notifyId };
        this.notification_popuptitle = "Delete";
      }
      this.deleteAllConform = true;
    },
    action_onnotification() {
      let postData = this.delNotification;

      this.$store.dispatch("removeNonification", postData).then((response) => {
        this.deleteAllConform = false;
        this.delNotification = { notifyId: "", removeAll: false };
        this.getNotifications();
      });
    },
    showReminderBox() {
      this.$emit("hideremindersnav");
    },
    logout() {
      this.$store.dispatch("logout").then(() => {
        this.$router.push("/login");
      });
    },
    showSidebar() {
      this.$store.commit("TOGGLE_IS_SIDEBAR_ACTIVE", true);
    },
    selected(item) {
      this.$router.push(item.url);
      this.showFullSearch = false;
    },
    actionClicked(item) {
      this.$store.dispatch("updateStarredPage", {
        index: item.index,
        val: !item.highlightAction,
      });
    },
    showNavbarSearch() {
      this.showFullSearch = true;
    },
    showSearchbar() {
      this.showFullSearch = true;
    },
    elapsedTime(startTime) {
      let x = new Date(startTime);
      let now = new Date();
      var timeDiff = now - x;
      timeDiff /= 1000;

      var seconds = Math.round(timeDiff);
      timeDiff = Math.floor(timeDiff / 60);

      var minutes = Math.round(timeDiff % 60);
      timeDiff = Math.floor(timeDiff / 60);

      var hours = Math.round(timeDiff % 24);
      timeDiff = Math.floor(timeDiff / 24);

      var days = Math.round(timeDiff % 365);
      timeDiff = Math.floor(timeDiff / 365);

      var years = timeDiff;

      if (years > 0) {
        return years + (years > 1 ? " Years " : " Year ") + "ago";
      } else if (days > 0) {
        return days + (days > 1 ? " Days " : " Day ") + "ago";
      } else if (hours > 0) {
        return hours + (hours > 1 ? " Hrs " : " Hour ") + "ago";
      } else if (minutes > 0) {
        return minutes + (minutes > 1 ? " Mins " : " Min ") + "ago";
      } else if (seconds > 0) {
        return seconds + (seconds > 1 ? ` sec ago` : "just now");
      }

      return "Just Now";
    },
    outside: function () {
      this.showBookmarkPagesDropdown = false;
    },
    randomDate({ hr, min, sec }) {
      let date = new Date();

      if (hr) date.setHours(date.getHours() - hr);
      if (min) date.setMinutes(date.getMinutes() - min);
      if (sec) date.setSeconds(date.getSeconds() - sec);

      return date;
    },
    getReminderlist() {

      let post_data = {
        page: 1,
        perpage: 1000,
        today: new Date(),
        matcher: {},
      };
      post_data["matcher"]["statusIds"] = [1];

      this.$store.dispatch("submitRminderList", post_data).then((response) => {
        this.reminderCount = response["data"]["result"]["totalCount"];
      });
    },
  },
  directives: {
    "click-outside": {
      bind: function (el, binding) {
        const bubble = binding.modifiers.bubble;
        const handler = (e) => {
          if (bubble || (!el.contains(e.target) && el !== e.target)) {
            binding.value(e);
          }
        };
        el.__vueClickOutside__ = handler;
        document.addEventListener("click", handler);
      },
      unbind: function (el) {
        document.removeEventListener("click", el.__vueClickOutside__);
        el.__vueClickOutside__ = null;
      },
    },
  },
  components: {
    VxAutoSuggest,

    VuePerfectScrollbar,
    draggable,
    DateRangePicker,
    moment,
    Datepicker,
    globalSearch,
  },
};
</script>
