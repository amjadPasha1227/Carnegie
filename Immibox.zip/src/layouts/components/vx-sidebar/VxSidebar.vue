<template>
  <div class="parentx" v-bind:class="{ settingsOpen: isActive }">
    <div  v-bind:class="{ disableMenu: disableLeftnav }" v-if="disableLeftnav"> </div>
     
    <vs-sidebar
      v-hammer:swipe.left="onSwipeLeft"
      ref="mainSidebar"
      :parent="parent"
      :hiddenBackground="clickNotClose"
      :reduce="reduce"
      default-index="-1"
      class="sidebarx main-menu-sidebar items-no-padding"
      v-model="isSidebarActive"
      :click-not-close="clickNotClose"
      :reduce-not-rebound="reduceNotRebound" 
    >

    <!-- <span class="Settings_item" :class="{'basic-settings':checkProperty($route ,'name') =='basic-settings' && [50].indexOf(getUserRoleId) <=-1}" v-if="[1,2,3,50].indexOf(getUserRoleId) >-1"> -->
      <!-- <span class="Settings_item" v-if="[1,2,3,4 ,50].indexOf(getUserRoleId)>-1">
    
            <router-link to="/basic-settings">
              <div class="">
              Settings </div></router-link>
          </span> -->

          <span class="Settings_item help-guide"   :class="{questionsopen : showQuestions}">
           
            <a  @click="showQuestions = !showQuestions" >
              <div class=""><span class="truncate" style="display: none;"> Help Guide </span></div>
            </a>
            
          </span>
      <template v-for="(settingsItem, index) in settingsItemsFiltered">
        <template v-if="index == 0">
          <span :key="`header-${index}`" class="Settings_item">
            <router-link :to="settingsItem.url">
              <div class="">
              Settings </div></router-link>
          </span>
        </template>
      </template>
      <div class="menu_wrap" >
        <div
          class="sidenav_list"
          @mouseenter="sidebarMouseEntered"
          @mouseleave="sidebarMouseLeave"
        >
          <div
            class="header-sidebar flex items-center justify-between"
            slot="header"
          >
            <!-- <div class="logo flex items-center">
              <router-link to="/dashboard" class="flex items-center">
                <img
                  :src="logo"
                  alt="logo"
                  class=" logosmall"
                  v-if="logo"
                />
                <span
                  class="logo-text"
                  v-show="isMouseEnter || !reduce"
                  v-if="title"
                >
                  <img src="@/assets/images/logo/immiBox_logo.svg" />
                </span>
              </router-link>
            </div> -->
           <div class="logo flex items-center clientlogo test">
               <router-link to="/dashboard" class="flex items-center">
             
                <img
                  :src="smallLogo"
                  alt="logo"
                  class=" logosmall"
                  v-if="smallLogo "
                />
                
                <span
                  class="logo-text"
                  v-show="isMouseEnter || !reduce"
                  v-if="title && logo"
                >
                  <img :src="logo" />
                </span>
                
              </router-link>               
            </div>
            <div>
              <template v-if="showCloseButton">
                <feather-icon
                  icon="XIcon"
                  class="m-0 cursor-pointer"
                  @click="$store.commit('TOGGLE_IS_SIDEBAR_ACTIVE', false)"
                ></feather-icon>
              </template>
              <template v-else-if="!showCloseButton && !sidebarItemsMin">
                <feather-icon
                  icon="MenuIcon"
                  class="mr-0 cursor-pointer"
                  svg-classes="stroke-current"
                  v-if="!reduce"
                  @click="toggleReduce(true)"
                  id="btnSidebarToggler"
                ></feather-icon>
                <feather-icon
                  icon="MenuIcon"
                  class="mr-0 cursor-pointer"
                  svg-classes="stroke-current"
                  v-if="reduce"
                  @click="toggleReduce(false)"
                  id="btnSidebarToggler"
                ></feather-icon>
              </template>
            </div>
          </div>
          
          <div class="shadow-bottom" v-show="showShadowBottom"></div>
    
          <VuePerfectScrollbar
            ref="mainSidebarPs"
            class="scroll-area--main-sidebar"
            :settings="settings"
            @ps-scroll-y="psSectionScroll"
          >
            <template v-for="(sidebarItem, index) in sidebarItems">
              <template
                v-if="sidebarItem.access.indexOf(currentUserRole) != -1"
              >
                <!-- GROUP ITEM HEADER -->
                <span
                  :key="`header-${index}`"
                  v-if="sidebarItem.header && !sidebarItemsMin"
                  class="navigation-header truncate"
                  >{{ sidebarItem.header }}</span
                >
                <template v-else-if="!sidebarItem.header">
                  <!-- IF IT'S SINGLE ITEM -->
                  <template v-if="!sidebarItem.submenu">
                    <span
                      :key="`header-${index}`"
                      v-on:click="isActive = false"
                    >
                      <vx-sidebar-item
                        v-bind:class="{
                          [sidebarItem.name.toLowerCase()]: sidebarItem.slug,
                        }"
                        ref="sidebarLink"
                        :key="`sidebarItem-${index}`"
                        :index="index"
                        :to="
                          sidebarItem.slug != 'external' ? sidebarItem.url : ''
                        "
                        :href="
                          sidebarItem.slug == 'external' ? sidebarItem.url : ''
                        "
                        :icon="sidebarItem.icon"
                        :target="sidebarItem.target"
                        :slug="sidebarItem.slug"
                      >
                        <span v-show="!sidebarItemsMin" class="truncate">{{
                          sidebarItem.name
                        }}</span>
                        <vs-chip
                          class="ml-auto"
                          :color="sidebarItem.tagColor"
                          v-if="sidebarItem.tag && (isMouseEnter || !reduce)"
                          >{{ sidebarItem.tag }}</vs-chip
                        >
                      </vx-sidebar-item>
                    </span>
                  </template>

                  <!-- IF HAVE SUBMENU / DROPDOWN -->
                  <template v-else>
                    <vx-sidebar-group
                      ref="sidebarGrp"
                      :key="`group-${index}`"
                      :openHover="openGroupHover"
                      :group="sidebarItem"
                      :groupIndex="index"
                      :open="isGroupActive(sidebarItem)"
                       v-bind:class="{
                          [sidebarItem.name.toLowerCase()]: sidebarItem.slug,
                        }"

                    ></vx-sidebar-group>
                  </template>
                </template>
              </template>
            </template>

          
          </VuePerfectScrollbar>

       
        </div>

   
      </div>
      
    </vs-sidebar>
    <!-- setting menu removed
    <div
      v-hammer:swipe.right="onSwipeRightSidebarSwipeArea"
      v-if="!isSidebarActive"
      class="sidebar-swipe-area"
      id="sidebar-swipe-area"
    ></div>

              
              
           

    
         <div class="settings_sec">

         


          <div class="settings_list">
            <ul>
              <template v-for="(settingsItem, index) in settingsItemsFiltered">
                <template
                  v-if="settingsItem.access.indexOf(currentUserRole) != -1"
                >
                  <li
                  
                    :key="`header-${index}`"
                    :class="[
                      {
                        'vs-sidebar-item-active': currentpah == settingsItem.url,
                          [settingsItem.slug.toLowerCase()]: true,
                      },
                      
                    ]"

                    
                  >
                    <router-link :to="settingsItem.url">{{
                      settingsItem.title
                    }}</router-link>
                  </li>
                </template>
              </template>
            </ul>
          </div>
        </div>
        -->

         <div class="ask-questions-section"  :class="{questionsopen : showQuestions}" >
        <div id="content-overlae" @click="showQuestions = false"></div>
          
          <div class="help-search-wrapper" >
            <span class="close" @click="showQuestions = false"><img src="@/assets/images/main/cross.svg" /></span>
            <div class="search-area">
                <h6>Help Guide</h6>
                <input class="searchinput" v-model="searchQuery" placeholder="Search">
            </div>
            <div class="suggested-articles">
                <label>Suggested articles</label>
                <VuePerfectScrollbar
                    ref="mainSidebarPs"
                    class=""
                    :settings="settings"
                    >
                <ul>
                    <li  v-for="page in resultQuery"
            :key="page.link"><a target="_blank" :href='page.link'>{{page.title}}</a></li>
                   <li v-if="searchQuery && resultQuery.length == 0">No Results Found</li>
                </ul>
                 </VuePerfectScrollbar>
                <div class="action-btns" v-if="resources.length > 0">
                    <a :href="'https://immibox.com/help/register-as-customer/?token='+resources[0].nonce" target="_blank" class="ask-btn">Browse All</a>
                </div>
            </div>
        </div>
       </div>
    
  </div>


</template>

<script>
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import VxSidebarGroup from "./VxSidebarGroup.vue";
import VxSidebarItem from "./VxSidebarItem.vue";
import _ from "lodash";

export default {
  name: "vx-sidebar",
  props: {
    sidebarItems: {
      type: Array,
      required: true,
    },
    settingsItems: {
      type: Array,
      required: true,
    },
    title: {
      type: String,
    },
    logo: {
      type: String,
    },
    smallLogo:{
      type: String,
      default: "",
    },
    parent: {
      type: String,
    },
    openGroupHover: {
      type: Boolean,
      default: false,
    },
    reduceNotRebound: {
      type: Boolean,
      default: true,
    },
  },
  data: () => ({
    searchQuery: null,
    resources:[],
    clickNotClose: false, // disable close sidebar on outside click
    reduce: false, // determines if sidebar is reduce - component property
    showCloseButton: false, // show close button in smaller devices
    isMouseEnter: false,
    gcapplications: false,
    petitionslist: false,
    showrfetab: false,
        showQuestions: false,
        hideText: false,
    settings: {
      // perfectscrollbar settings
     // maxScrollbarLength: 60,
      //wheelSpeed: 1,
      swipeEasing: true,
    },
    windowWidth: window.innerWidth, //width of windows
    showShadowBottom: false,
    currentpah: null,
    currentUserRole: 0,
    isActive: false,
    settingsItemsFiltered: null,
  }),
  computed: {
    resultQuery(){
      if(this.searchQuery){
      return this.resources.filter((item)=>{
        return this.searchQuery.toLowerCase().split(' ').every(v => item.title.toLowerCase().includes(v))
      })
      }else{
      return this.resources.filter((item)=>{
            return item && item.post_parent == 0
      })
      }
    },
     disableLeftnav() {
     
       if([3,50].indexOf(this.$store.state.user.roleId) > -1 && this.$store.state.common.profileCompleted!=null ){
         return !this.$store.state.common.profileCompleted;
       }
        return false;
    },
    isSidebarActive: {
      get() {
        return this.$store.state.isSidebarActive;
      },
      set(val) {
        this.$store.commit("TOGGLE_IS_SIDEBAR_ACTIVE", val);
      },
    },
    reduceSidebar() {
      return Boolean(this.reduce && this.reduceButton);
    },
    reduceButton: {
      get() {
        return this.$store.state.reduceButton;
      },
      set(val) {
        this.$store.commit("TOGGLE_REDUCE_BUTTON", val);
      },
    },
    sidebarItemsMin() {
      return this.$store.state.sidebarItemsMin;
    },
    isGroupActive() {
      return (sidebarItem) => {
        let fullPath = '';
        let path = this.$route.path;
        let spltAr =this.$route.fullPath.split('?');
        if(spltAr && spltAr.length>0){
          fullPath = spltAr[0];
        }
       
        let open = false;
        let func = function (sidebarItem) {
          if (sidebarItem.submenu) {
            sidebarItem.submenu.forEach((item) => {
              
              if (path == item.url || fullPath == item.url) {
                open = true;
              } else if (item.submenu) {
                func(item);
              }
            });
          }
        };
        func(sidebarItem);
        return open;
      };
    },
  },
  watch: {
    reduce(val) {
      if (val == true) {
        this.$store.dispatch("updateSidebarWidth", "reduced");
      } else {
        this.$store.dispatch("updateSidebarWidth", "default");
      }

      setTimeout(function () {
        window.dispatchEvent(new Event("resize"));
      }, 100);
    },
    reduceButton() {
      this.setSidebarWidth();
    },
    $route() {
      this.currentpah = this.$route.name;
            var _s = this;
        this.isActive = _.find(this.settingsItems, function (o) {
      return o.slug == _s.$route.name;
    });
           this.reduce = true;
         this.$store.commit("UPDATE_SIDEBAR_ITEMS_MIN", true);


      if (this.isSidebarActive && this.showCloseButton)
        this.$store.commit("TOGGLE_IS_SIDEBAR_ACTIVE", false);
    },
  },
  methods: {
    sidebarMouseEntered() {
      if (this.reduce) this.$store.commit("UPDATE_SIDEBAR_ITEMS_MIN", false);
      this.isMouseEnter = true;
    },
    sidebarMouseLeave() {
      if (this.reduce) {
        this.$store.commit("UPDATE_SIDEBAR_ITEMS_MIN", true);
      }
      this.isMouseEnter = false;
    },
    toggleReduce(val) {
      this.reduceButton = val;
      this.setSidebarWidth();
    },
    handleWindowResize(event) {
      this.windowWidth = event.currentTarget.innerWidth;
      this.setSidebarWidth();
    },
    setSidebarWidth() {
      if (this.windowWidth < 1200) {
        if (this.windowWidth < 992)
          this.$store.commit("UPDATE_WINDOW_BREAKPOINT", "md");
        else this.$store.commit("UPDATE_WINDOW_BREAKPOINT", "lg");

        this.$store.commit("TOGGLE_IS_SIDEBAR_ACTIVE", false);
        if (this.reduceButton) this.reduce = false;
        // this.reduceButton = false;
        this.showCloseButton = true;
        this.clickNotClose = false;
        this.$store.dispatch("updateSidebarWidth", "no-sidebar");
        this.$store.commit("UPDATE_SIDEBAR_ITEMS_MIN", false);
      } else {
        this.$store.commit("UPDATE_WINDOW_BREAKPOINT", "xl");
        if (this.reduceButton) this.reduce = true;
        else this.reduce = false;

        this.$store.commit("TOGGLE_IS_SIDEBAR_ACTIVE", true);
        if (this.reduceButton && !this.isMouseEnter)
          this.$store.commit("UPDATE_SIDEBAR_ITEMS_MIN", true);
        else this.$store.commit("UPDATE_SIDEBAR_ITEMS_MIN", false);

        this.clickNotClose = true;
        this.showCloseButton = false;
        if (this.reduceSidebar)
          this.$store.dispatch("updateSidebarWidth", "reduced");
        else this.$store.dispatch("updateSidebarWidth", "default");
      }

      var _s = this;
      var _settingsPage = _.find(this.settingsItems, function (o) {
        return o.slug == _s.$route.name;
      });
      if (_settingsPage || this.$route.meta.sideBar =="small") {
        this.$store.dispatch("updateSidebarWidth", "reduced");
        this.reduce = true;
        this.$store.commit("UPDATE_SIDEBAR_ITEMS_MIN", true);
      }
    },
    psSectionScroll() {
      if (this.$refs.mainSidebarPs.$el.scrollTop > 0)
        this.showShadowBottom = true;
      else this.showShadowBottom = false;
    },
    onSwipeLeft() {
      if (this.isSidebarActive && this.showCloseButton)
        this.isSidebarActive = false;
    },
    onSwipeRightSidebarSwipeArea() {
      if (!this.isSidebarActive && this.showCloseButton)
        this.isSidebarActive = true;
    },
  },
  components: {
    VxSidebarGroup,
    VxSidebarItem,
    VuePerfectScrollbar,
  },
  mounted() {
    var _s = this;


    this.currentUserRole = parseInt(this.$store.state.userRole);
    this.isActive = _.find(this.settingsItems, function (o) {
      return o.slug == _s.$route.name;
    });
    if(this.isActive){
         this.$store.commit("UPDATE_SIDEBAR_ITEMS_MIN", true);
    }

    this.settingsItemsFiltered = _.filter(this.settingsItems, function (o) {
      return o.access.indexOf(_s.currentUserRole) != -1;
    });

  
    this.$nextTick(() => {
      window.addEventListener("resize", this.handleWindowResize);
    });
    this.setSidebarWidth();

    if(this.$route.meta.sideBar =="small" && (this.$route.name!= "dashboard" && [50].indexOf(this.getUserRoleId) < 0)){
              this.$store.dispatch("updateSidebarWidth", "reduced");

    //  this.$store.dispatch("updateSidebarWidth", "reduced");

    }

    fetch('https://immibox.com/wp-json/help/v1/allposts')
            .then(response => response.json())    // one extra step
            .then(data => {
                this.resources= data;
            })
  },
  beforeDestroy() {
    window.removeEventListener("resize", this.handleWindowResize);
  },
};
</script>

<style lang="scss">
@import "@/assets/scss/vuesax/components/vxSidebar.scss";
</style>
