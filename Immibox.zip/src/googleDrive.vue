<template>
<GDriveSelector />
</template>

<script>
import GDriveSelector from "@/components/googleDrive/GDriveSelector";

export default {
  name: "App",
  components: {
    GDriveSelector
  }
};
</script>