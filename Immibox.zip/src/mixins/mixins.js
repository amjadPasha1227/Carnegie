import Vue from 'vue'
import mprofileImage from "@/assets/images/main/avatar3.svg"
import fprofileImage from "@/assets/images/fprofile.svg"
import clientProfile from "@/assets/images/client_profile.png"
import defaultavathar from "@/assets/images/main/avatar4.svg"

import JQuery from "jquery";
import { _ } from 'core-js'
import moment from "moment";


Vue.mixin({
  data(){
    return{
    
      invitepetitioner:false,
      colors:{
        "no_color": "#252222",
        "petition_started":'#d1f4a8',
        "in_review":"#775dd0",
        "assigned_to_attorney":"#ff4560",
        "case_accepted":"#33226b",
        "submit_to_uscis":"#008ffb",
        "filed":"#00e396",
         "denied":'#feb019',
         "assigned_to_paralegal":"#f887dc",
         "assigned_to_attorney":"#00e396",
         "case_started":"#00e396",
         "approved":"#3ED901",

         "law_firm":'#775dd0',
         "petitioner":'#00e396',
         "beneficiary":'#e50019',
         //LCA
         "initiated":"#d1f4a8",
         "certified":"#008ffb",
         "denied":"#feb019",
         "request_for_withdrawal":"#00e396",
         "Withdrawn":"#feb019",
         "expired":"#775dd0",

         //Invoice 
         "not_sent":"#d1f4a8",
         "delivery_error":"#ff4560",
         "viewed":"#775dd0",
         "partially_paid":"#008ffb",
         "paid":"#00e396",
         "deposited":"#feb019",

         "sent":"#feb019",
         
      },

      /*
      :[{"id":1,"name":"Initiated"},
      {"id":2,"name":"Filed"},
      {"id":3,"name":"Certified"},
      {"id":4,"name":"Denied"},
      {"id":5,"name":"Request for Withdrawal"},
      {"id":6,"name":"Withdrawn"},
      {"id":7,"name":"Expired"}]
      */
      

    }
  },
  created: function () {
  },
  methods: {

   getstatsCaseTypes(){
    return [
      { id: 'h1b',name: 'H-1B' ,'selected':true},
      { id: 'perm',name: 'PERM Process' ,'selected':false},
      { id: 'i140', name: 'Immigrant Petition (I-140)' ,'selected':false },
      {  id: 'adj_status_i485', name: 'Adjustment of Status (I-485)' ,'selected':false },
      { id: 'i130', name: 'I-130','selected':false },
      {  id: 'i485', name: 'I-485','selected':false }
  ];
   },

   getCaseColors(statusId=-1) {
    /*
                  'status_created': checkProperty(petition ,'statusDetails','id') == 1,
                  'status_submited': checkProperty(petition ,'statusDetails','id') == 2,
                  'status_inProcess': checkProperty(petition ,'statusDetails','id') == 3,
                  'status_waiting': checkProperty(petition ,'statusDetails','id') == 4,
                  'status_ready_for_filing':[5, 8].indexOf(checkProperty(petition, 'statusId')) > -1,
                  'status_sent_for_signatures': [6,9,33].indexOf(checkProperty(petition, 'statusId')) > -1,
                  'staus_filed_with_USCIS':[7, 18].indexOf(checkProperty(petition, 'statusId')) > -1,
                  'received_signed_forms': [32, 10].indexOf(checkProperty(petition, 'statusId')) > -1,
                  'RFE_Received': [11, 24].indexOf(checkProperty(petition, 'statusId')) > -1,
                  'status_submited-USCIS': checkProperty(petition ,'statusDetails','id') == 12,
                  'response_to_RFE_Received': checkProperty(petition ,'statusDetails','id') == 13,
                  'status_jobdescription': checkProperty(petition ,'statusDetails','id') == 14,
                  'status_pwd_filed': checkProperty(petition ,'statusDetails','id') == 15,
                  'status_pwd_response': checkProperty(petition ,'statusDetails','id') == 16,
                  'staus_advertisements': checkProperty(petition ,'statusDetails','id') == 17,
                  'Status_received_by_USCIS': checkProperty(petition ,'statusDetails','id') == 19,
                  'Perm_drft_approved': checkProperty(petition ,'statusDetails','id') == 20,
                  'Perm_submited_dol': checkProperty(petition ,'statusDetails','id') == 21,
                  'status_approved': checkProperty(petition ,'statusId') == 22,
                  'status_denied': checkProperty(petition ,'statusDetails','id') == 23,
                  'notice_supervisory_audit': checkProperty(petition ,'statusDetails','id') == 27,
                  'status_supervisory_audit': checkProperty(petition ,'statusDetails','id') == 28,
                  'status_withdrawn': checkProperty(petition ,'statusDetails','id') == 31
    */

    let allColor=  [
        
        { backgroundColor: '#32CD32',"id" : 1,  "name" : "Case Started", "className":'status_created' },
        { backgroundColor: '#C0CA33',"id" : 2,  "name" : "Questionnaire Submitted", "className":'status_submited' },
        { backgroundColor: '#F98C00',"id" : 3,  "name" : "In Process", "className":'status_inProcess' },
        { backgroundColor: '#1F9BE5',"id" : 4,  "name" : "Waiting for Details", "className":'status_waiting' },
        { backgroundColor: '#1F9BE5',"id" : 5,  "name" : "Forms & Letters Generated" , "className":'status_ready_for_filing'},
        { backgroundColor: '#32CD32',"id" : 6,  "name" : "Attorney Review" , "className":'status_sent_for_signatures'},
        { backgroundColor: '#8E24AA',"id" : 7,  "name" : "Paralegal Review" , "className":'staus_filed_with_USCIS'},
        { backgroundColor: '#1F9BE5',"id" : 8,  "name" : "Ready for Filing", "className":'status_ready_for_filing' },
        { backgroundColor: '#32CD32',"id" : 9,  "name" : "Sent for Signatures", "className":'status_sent_for_signatures' },
        { backgroundColor: '#C0CA33',"id" : 10,  "name" : "Received Signed Forms", "className":'received_signed_forms' },
        { backgroundColor: '#C0CA33',"id" : 11,  "name" : "Supervisor Review" , "className":'RFE_Received'},
        { backgroundColor: '#32CD32',"id" : 12,  "name" : "Submitted to USCIS", "className":'status_submited-USCIS' },
        { backgroundColor: '#C0CA33',"id" : 13 , "name" : "Receipt Received", "className":'response_to_RFE_Received' },
        { backgroundColor: '#1F9BE5',"id" : 14,  "name" : "Job Description" , "className":'status_jobdescription'},
        { backgroundColor: '#32CD32',"id" : 15,  "name" : "PWD Filed", "className":'status_pwd_filed' },
        { backgroundColor: '#1F9BE5',"id" : 16,  "name" : "PWD Response", "className":'status_pwd_response' },
        { backgroundColor: '#8E24AA',"id" : 17,  "name" : "Advertisements", "className":'staus_advertisements' },
        { backgroundColor: '#8E24AA',"id" : 18,  "name" : "Finalized PERM Questionnaire", "className":'staus_filed_with_USCIS' },
        { backgroundColor: '#32CD32',"id" : 19,  "name" : "PERM Draft Created" , "className":'Status_received_by_USCIS'},
        { backgroundColor: '#32CD32',"id" : 20,  "name" : "PERM Draft Approved", "className":'Perm_drft_approved' },
        { backgroundColor: '#32CD32',"id" : 21,  "name" : "PERM Submitted to DOL", "className":'Perm_submited_dol' },
        { backgroundColor: '#32CD32',"id" : 22,  "name" : "Case Approved", "className":'status_approved' },
        { backgroundColor: '#EC2E15',"id" : 23 ,  "name" : "Case Denied", "className":'status_denied' },
        { backgroundColor: '#C0CA33',"id" : 24,  "name" : "RFE Received" , "className":'RFE_Received'},
        { backgroundColor: '#C0CA33',"id" : 25,  "name" : "Response to RFE Filed", "className":'status_pwd_filed' },
        { backgroundColor: '#C0CA33',"id" : 26,  "name" : "Response to RFE Received", "className":'RFE_Received' }, 
        { backgroundColor: '#1F9BE5',"id" : 27,  "name" : "Notice of Audit", "className":'notice_supervisory_audit' },
        { backgroundColor: '#1F9BE5',"id" : 28,  "name" : "Notice of Supervisory Audit", "className":'status_supervisory_audit' },
        { backgroundColor: '#C0CA33',"id" : 29,  "name" : "Audit Response Submitted" , "className":''},
        { backgroundColor: '#8E24AA',"id" : 30,  "name" : "NOID", "className":'' },
        { backgroundColor: '#757575',"id" : 31,  "name" : "Withdrawn", "className":'status_withdrawn' },
        { backgroundColor: '#C0CA33',"id" : 32,  "name" : "Response Docs Prepared", "className":'received_signed_forms' },
        { backgroundColor: '#32CD32',"id":33,  "name" : "Response Docs Approved", "className":'status_sent_for_signatures' },         
        { backgroundColor: '#D2AEF5',"id" : '<1 Week',  "name" : "<1 Week", "className":''  },
        { backgroundColor: '#96D0B3',"id" :'1 Week', "name" : "1 Week", "className":'' },
        { backgroundColor: '#F8BF96', "id" : '3+ Weeks', "name" : "3+ Weeks", "className":''},
      ]

      if(statusId>-1){

       let statusData =  _.find(allColor,{"id":statusId});
       if(statusData && _.has(statusData,'className')){
        return statusData['className'];
       }else{
        return '';
       }

        
      }else{
        return allColor;
      }

   


  },
    
   
    navigateToDetails(item ,navType ,filterKey=''){
        
      if(navType=='PWD_LIST' || navType=='CASE_LIST' || navType=='PERM_LIST' || navType =='LCA_LIST' || navType =='BRANCH_CASES' ){
     
       let path ='/cases';
       

       if(navType =='LCA_LIST' ){
        path ="/lcalist"
       }
       if(navType =='PWD_LIST' ){
        path ="/pwd-list"
       }
        let matchers ={};
        if(filterKey =='typeIds' && this.checkProperty( item ,'typeDetails' ,'id')){
          matchers = Object.assign(matchers ,{'typeIds':[item['typeDetails']['id']]})
        }
        if(filterKey =='subTypeIds' && this.checkProperty( item ,'subTypeDetails' ,'id')){
          matchers = Object.assign(matchers ,{'subTypeIds':[item['subTypeDetails']['id']]});
           matchers = Object.assign(matchers ,{'typeIds':[item['typeDetails']['id']]})
        }



        if(filterKey =='typeIds' &&  navType =='BRANCH_CASES' && this.checkProperty( item ,'type')){
          matchers = Object.assign(matchers ,{'branchIds':[item['branchId']] ,'typeIds':[item['type']]})
        }


        if(navType=='PERM_LIST'){
          path = "/cases";
          matchers = Object.assign(matchers ,{'subTypeIds':[15]});
          matchers = Object.assign(matchers ,{'typeIds':[3]})
          // matchers['typeIds'].push(3)
          // matchers['subTypeIds'].push(15)
         }
  
        

        if(filterKey =='subTypeIds' && navType =='BRANCH_CASES' && this.checkProperty( item ,'subType')){
          matchers = Object.assign(matchers ,{'branchIds':[item['branchId']] ,'subTypeIds':[item['subType']]});
           matchers = Object.assign(matchers ,{'typeIds':[item['type']]})
        }
        
        

         if(filterKey =='petitionerIds' && this.checkProperty( item ,'petitionerDetails' ,'_id')){
          matchers = Object.assign(matchers ,{'petitionerIds':[item['petitionerDetails']['_id']]});
         
        }

         if(filterKey =='beneficiaryIds' && this.checkProperty( item ,'beneficiaryDetails' ,'_id')){
          matchers = Object.assign(matchers ,{'beneficiaryIds':[item['beneficiaryDetails']['_id']]});
         
        }

        
        
        if(filterKey =='statusIds' && this.checkProperty( item ,'statusDetails' ,'id')){
          matchers = Object.assign(matchers ,{'statusIds':[item['statusDetails']['id']]});
         
        }

        if(filterKey =='cahartstatusIds' && this.checkProperty( item ,'statusId' )){
          matchers = Object.assign(matchers ,{'statusIds':[ item['statusId'] ] });
         
        }
        if(filterKey =='caseSignatuerStats'){

          
        

         // matchers = Object.assign(matchers ,{'getActiveCases':true});
          if(this.checkProperty(item ,'statusIds' ,'length') >0){
            matchers = Object.assign(matchers ,{'statusIds': item['statusIds']  });
          }
          matchers = Object.assign(matchers ,{ "typeIds":[],'subTypeIds':[]});

          if(this.checkProperty(item ,'typeIds' ,'length') >0){
            matchers = Object.assign(matchers ,{'typeIds': item['typeIds']  });
          }
          if(this.checkProperty(item ,'subTypeIds' ,'length') >0){
            matchers = Object.assign(matchers ,{'subTypeIds': item['subTypeIds']  });
          }
         
          if(this.checkProperty( item ,'statusId' ) ==99){
            matchers = Object.assign(matchers ,{'getPendingWithLCA':true ,"statusIds":[]});
          }
         
        }

        if(filterKey =='deadlineDate' && this.checkProperty( item ,'deadlineDate' )){
          let  deadlineDateRange = moment(item['deadlineDate']).format('YYYY-MM-DD')
          matchers = Object.assign(matchers ,{'deadlineDateRange':[ deadlineDateRange ,deadlineDateRange] });
         
        }
        

        if(filterKey =='getActiveCases'){
          matchers = Object.assign(matchers ,{'getActiveCases':true});
          if(navType =='BRANCH_CASES'){

            matchers = Object.assign(matchers ,{'branchIds':[item['branchId']] ,'getActiveCases':true});


          }
         
        }
         if(filterKey =='getClosedCases'){
          matchers = Object.assign(matchers ,{'getClosedCases':true});

          if(navType =='BRANCH_CASES'){

            matchers = Object.assign(matchers ,{'branchIds':[item['branchId']] ,'getClosedCases':true});


          }
         
        }
        if(filterKey =='premiumProcessing'){
        matchers = Object.assign(matchers ,{'premiumProcessing':[true]});

        }
        if(filterKey =='rfeCases'){
          matchers = Object.assign(matchers ,{'rfeCases':true});
  
          }
        if(filterKey =='customers' && this.checkProperty( item ,'petitionerUserDetails' ,'_id') ){
          //
          matchers = Object.assign(matchers ,{'petitionerIds':[item['petitionerUserDetails']['_id']]});
  
          }
      //alert(JSON.stringify(item));

      if(filterKey=='branchIds' && this.checkProperty( item ,'branchId')){
  
        matchers = Object.assign(matchers ,{'branchIds':[item['branchId']]});
        
          }    
          

        


        if(Object.keys(matchers).length>0){
        let matcherObj = {'matcher':matchers}
        const string = JSON.stringify(matcherObj)
       
        let encodedString = btoa(string) 
        path =path+"?filter="+encodedString;
    
       
     
      }
      this.$router.push(path);


        
      }else if(navType=='CASE_DETAILS'){
       
       if(!this.checkProperty( item ,'data' ,'petitionId') && this.checkProperty( item ,'data' ,'pwdId')){
           let path = '/pwd-case-details/'+this.checkProperty( item,'data' ,'pwdId');
           let matchers ={};
           this.$router.push(path);
       }else {
       
        let path = '/petition-details/'+this.checkProperty( item,'_id');
        let petitionId = this.checkProperty( item,'_id');
        if(this.checkProperty( item ,'data' ,'petitionId') ){
         petitionId = this.checkProperty( item ,'data' ,'petitionId');
        }
       if(this.checkProperty( item ,'data' ,'subType') ==15){
         path = '/gc-employment-details/'+petitionId;
       }else{
        path = '/petition-details/'+petitionId;
       }
       this.$router.push(path);

      }
      
       
       
      }else if(navType=='PERM_DETAILS'){
        let path = '/gc-employment-details/'+this.checkProperty( item,'_id');
        if(this.checkProperty( item ,'data' ,'petitionId') ){
          path = '/gc-employment-details/'+this.checkProperty( item ,'data' ,'petitionId');
        }
        let matchers ={};
          this.$router.push(path);
        
       }else if( navType=='BENEFICIARY_LIST'){
        let path="/beneficiaries";
        let matchers ={};

        if(filterKey =='statusIds' && this.checkProperty( item ,'statusDetails' ,'id')){
          matchers = Object.assign(matchers ,{'statusIds':[item['statusDetails']['id']]});
         
        }
        if(Object.keys(matchers).length>0){
          let matcherObj = {'matcher':matchers}
          const string = JSON.stringify(matcherObj)
         
          let encodedString = btoa(string) 
          path =path+"?filter="+encodedString;
      
         
       
        }
        this.$router.push(path);


      } else if( navType=='PETITIONERS_LIST'){
        let path="/petitioners";
        let matchers ={};

        if(filterKey =='statusIds' && this.checkProperty( item ,'statusDetails' ,'id')){
          matchers = Object.assign(matchers ,{'statusIds':[item['statusDetails']['id']]});
         
        }
        if(Object.keys(matchers).length>0){
          let matcherObj = {'matcher':matchers}
          const string = JSON.stringify(matcherObj)
         
          let encodedString = btoa(string) 
          path =path+"?filter="+encodedString;
      
         
       
        }
        this.$router.push(path);


      } else if( navType=='TASK_LIST'){
        let path="/tasks-list";
        let matchers ={};

        if(filterKey =='statusIds' && this.checkProperty( item ,'statusDetails' ,'id')){
          matchers = Object.assign(matchers ,{'statusIds':[item['statusDetails']['id']]});
         
        }

        if(filterKey =='deadlineDate' && this.checkProperty( item ,'deadlineDate' )){
          let  dueDateRange = moment(item['deadlineDate']).format('YYYY-MM-DD')
          matchers = Object.assign(matchers ,{'dueDateRange':[ dueDateRange ,dueDateRange] });
         
        }
        if(Object.keys(matchers).length>0){
          let matcherObj = {'matcher':matchers}
          const string = JSON.stringify(matcherObj)
         
          let encodedString = btoa(string) 
          path =path+"?filter="+encodedString;
      
         
       
        }
        this.$router.push(path);


      }else if(navType=='PWD_DETAILS'){
        let path = '/pwd-case-details/'+this.checkProperty( item,'_id');
        
 
          let matchers ={};
          this.$router.push(path);
        
       }
      
        
       
      

    },

    togleGlobalSearch(action =false){
      
      this.$store.commit('togleGlobalSearch' ,action);
      setTimeout( ()=> {
        try {        
            let $ = JQuery;
            if(action){
              $("#gsearchinput" ).focus();
            }else{
              $("#gsearchinput").blur(); 
            }
          
            

         
        }catch (e) {
         

        }

        try {
        
          let $ = JQuery;
          
          this.$refs['globalSearchRef'].clearText();      
        
       
      }catch (e) {
       

      }
      },10)
    },
    
    goToPageDetails(path=''  ){
      if(path !=''){
        
        
         this.$router.push(path);


      }

     
    },
     canRenderField( tplKey='',fieldsArray=null, display=false ,section='' ,fieldName=null ){
      
      if(display)return true;
      if(tplKey ==null || fieldsArray == null || this.checkProperty(fieldsArray ,'length') <=0){
        return true;
      }else if( _.findIndex(fieldsArray ,fieldName) >-1 && fieldName != null){
           return true;
      }else if(section !='' && tplKey !=''){
        //alert(section)
        let field=  _.find(fieldsArray ,{"section":section,"key":tplKey})
       if(field){
          return true
        }else{
          return false;
        }

      }else{
        return true;

      }
      
   
    },

    checkFieldIsRequired({key=null,section='', fieldsArray=null, required=false,mRequired = false,notRequired= false }){
      let field=  _.find(fieldsArray ,{"section":section,"key":key})
      if(mRequired){
        return true;
      }
      else if(notRequired){
        return false;
      }
      else{
        if(field){
            if(_.has(field ,'required')){
              if(field['required'] ==true || field['required'] =='true' ){
                return true;
  
              }else{
                return false;
  
              }
  
            }else{
              return false;
            }
        }else if(required ==true){
          return required;
        }else if(key ==null || fieldsArray == null || this.checkProperty(fieldsArray ,'length') <=0){
          return false;
        }else{
          return false;
        }
      }
      
   
    },
    checkTemplateField(checkKey = "") {
      let return_value = true;
      if (checkKey != "" && _.has(this.questionnaireDetails, "fields")) {
        return_value =
          _.findIndex(this.questionnaireDetails.fields, (el) => {
            return el == checkKey;
          }) > -1
            ? true
            : false;
      }

      //this.$validator.reset();

      return return_value;
    },
    checkIsTempAccount(email =''){
      let parts = email.split("@");
      if(this.checkProperty(parts ,"length")>0){
         let domain = parts[(parts.length)-1]
        if(['temp-account.com'].indexOf(domain)>-1){
          return false
        }else{
          return true
        }

      }else{
        return true


      }

    },
    tempLogin(item=null){
      let currentRoute  = this.$route;
     
      let tempLoginUrls = ['fill-questionnaire' ,"filled-case-details","fill-perm-questionnaire" ,'filled-perm-case-details'];
     if(_.has(item,'beneficiaryInfo') && tempLoginUrls.indexOf(_.get( currentRoute,'name' ,'')) >-1 &&  _.has(currentRoute ,"meta.getTokenFromUrl") && (_.has(currentRoute, "query.token")) ){
        //login Here ;
        let token = currentRoute['query']['token'];
        let userData =item['beneficiaryInfo'];
        userData =Object.assign(userData,{ "roleId":51,"loginRoleId":51 ,"loginRoleName":"anonymous "})
        let tenantId = _.get(item , "tenantId" ,'');

        let data=  {token:token, user:userData, userrole:51 ,tenantId:tenantId} 
       
        this.$store.commit('tempauth_success', data)
      }else{
        let data = this.$store.getters['getloginUserData'];
        this.$store.commit('auth_success', data)

      }
    },
    setToken(){
      let currentRoute  = this.$route;
      let tempLoginUrls = ['fill-questionnaire' ,"filled-case-details","fill-perm-questionnaire" ,'filled-perm-case-details'];    
      if(tempLoginUrls.indexOf(_.get( currentRoute,'name' ,'')) >-1 &&  _.has(currentRoute ,"meta.getTokenFromUrl") && (_.has(currentRoute, "query.token")) ){
     // alert("dsd fsdhfgdsg dsh")
      }else{
      
        // Restore Original Login Data
        let data = this.$store.getters['getloginUserData'];
        //alert(JSON.stringify(data));
        this.$store.commit('auth_success', data)

      }
    },

    setFavIcon(tempSave = false){
     

      try{

    const favicon = document.getElementById("faiconId");
    const host = window.location.host;
    const parts = host.split('.');
    if(tempSave){
      if(this.$store.state.newFaviconUploaded != ''){
        favicon.href = this.$store.state.newFaviconUploaded;
      }
    }
    else{
      if(favicon && this.checkProperty(parts ,"length")>2  || (this.isWhiteLabled && this.checkProperty( this.getUserData ,"tenantDetails" , 'favicon') )){


        if((this.isWhiteLabled && this.checkProperty( this.getUserData ,"tenantDetails" , 'favicon') )){
          favicon.href = this.checkProperty( this.getUserData ,"tenantDetails" , 'favicon');
  
        }
        else if(this.checkProperty(this.getTenantLogo ,'favicon')){
           favicon.href = this.checkProperty(this.getTenantLogo  ,"favicon");
  
        }else if(this.checkProperty(this.getUserData ,"tenantDetails" ,"favicon")){
           favicon.href = this.checkProperty(this.getUserData ,"tenantDetails" ,"favicon");
  
        }
       
  
      }
    }

   }catch(e){
    
   }
    },

   replaceSpaces(string){
    var result = string.replace(/ /g, "_");
    return result.toLowerCase();
   },

    getActionName(nextWorkWorkFlow ,type='actionLable'){
      let returnValue='';
      if((_.has(nextWorkWorkFlow ,'name'))){
        returnValue=nextWorkWorkFlow['name'];
      }
      /*
      if(_.has(nextWorkWorkFlow ,'code')){

        this.$store
        .dispatch("getActivityCodes")
        .then((response) => {
          let activityList = response;
          let actiVity = _.find(activityList , {"code":nextWorkWorkFlow['code']})
          
        })
       


      }else if(_.has(nextWorkWorkFlow ,'name')){
        returnValue = nextWorkWorkFlow['name'];
      }
      */
      return returnValue;

    },
   
    updatePetiotionActionBtn(action=false){
      //alert();
      this.$store.dispatch('managePetitionActionBtn' ,action);
      return true;
    },
  setDefaultPhoto(event ,gender='M' ,type='user'){
   if(type =='user'){

   
    if(gender=='M' || gender=='O'){
      event.target.src = mprofileImage
    }else if(gender=='F'){
      event.target.src = fprofileImage
    } else {
      event.target.src =  mprofileImage
    }
  }else if(type=='company'){
    event.target.src = clientProfile
  }else{
    event.target.src =  clientProfile

  }
  
    
  },
  setDefaultavatar(event){
     event.target.src =  defaultavathar
   },


  avtarName(object =null ,mainKey='' ,subKey ='' ,returnValue=''){
      var  _rt;
    if(object != null && mainKey !='' ){
        if(_.has(object ,mainKey)){

            if(subKey !=''){
                if( _.has(object[mainKey] ,subKey )){
                  _rt = object[mainKey][subKey];

                }else{
                  _rt = returnValue;

                }


            }else{
              _rt =object[mainKey];

            }


        }else{
          _rt = returnValue;
        }


    }else{
      _rt = returnValue;
    }
    return _rt.substring(0, 2).toUpperCase() 
  },
    checkProperty(object =null ,mainKey='' ,subKey ='' ,returnValue=''){
      
      if(object != null && mainKey !='' ){
          if(_.has(object ,mainKey)){

              if(subKey !=''){
                  if( _.has(object[mainKey] ,subKey )){
                    returnValue = object[mainKey][subKey];
                    if(subKey=='countryCallingCode' && returnValue){
                      
                      if(!(returnValue.includes("+"))){
                          returnValue = "+"+returnValue
                      }
                     
                     

                    }


                    return returnValue;
                  }else{
                      return returnValue;

                  }


              }else{
                  return object[mainKey];

              }


          }else{
              return returnValue;
          }


      }else{
          return returnValue;
      }
      //"phoneCountryCode" ,'countryCallingCode'

    },
    showToster({message='',isError=false, duration = 10000 }){
      // alert(JSON.stringify(message))
      let durtion = duration
        if(isError){
    
          this.$vs.notify({
            count:10000,
            time:10000,
            title: "Error",
           position:'top-right',
           color:'danger',
           iconPack: 'feather',
           icon:'icon-check',
            text:message
          });
    
        }else{
          this.$vs.notify({
            count:durtion,
            time:durtion,
            title: "Success",
           position:'top-right',
           color:'success',
           iconPack: 'feather',
           icon:'icon-check',
            text:message
          });
          
    
      }
    },

    findmsDoctype(item){
      

      
      try{
        let name= _.get(item ,'name','') ;
      let mimetype=_.get(item ,'mimetype','') ;
      let ext ='';
      let arr = name.split(".");
      if(arr.length>0){
        ext =arr[arr.length-1];
      }
      if(item && !ext ){
          if(_.has(item ,'extn')){
            ext = item['extn'];
           
          }
     
      }
      if(item && !mimetype ){
        if(_.has(item ,'mimetype')){
          mimetype = item['mimetype'];
         
        }
   
    }
     
      let docTypes =[
        'doc' ,"docx","txt","odt","rtf","dotm","wps","xml",
        "xl","xlsx","xla","xlsb","application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      ]
      let imagTypes = ['jpeg','jpg' ,'png' ,"svg" ,"image/jpeg","image/jpg" ,"image/png" ,"image/svg"];
      let pdfTypes =['pdf'];
     
      if( (_.findIndex(docTypes ,(vl)=>{ return vl==ext} ) !=-1 )  || docTypes.indexOf(mimetype)>-1){
        return "office";
      }else if( (_.findIndex(imagTypes ,(vl)=>{ return vl==ext} ) !=-1 )  || imagTypes.indexOf(mimetype)>-1  ){
        return "image";

      }else if( _.findIndex(pdfTypes ,(vl)=>{ return vl==ext} ) !=-1 || mimetype =="application/pdf"){
        
        return "pdf";
      
      }else {
        return false;
      }
    }catch(err){
     
      
      return false;
    }

    },
    customFormatter(date) {
      
      return moment(new Date(date).setHours(0, 0, 0, 0)).format('MM/DD/YYYY');
    },
    downloads3file(value) {
     
    
      if(_.has(value  ,"path")){
        value = Object.assign(value ,{ "url": value['path']})
      }
      if(_.has(value  ,"url")){
        value = Object.assign(value ,{ "path": value['url']})
      }
      if(_.has(value  ,"petitionId")){
        value = Object.assign(value ,{ "petitionId": value['petitionId']})
      }
      value.url = value.url.replace(this.$globalgonfig._S3URL, "");
      value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
      let postdata = { keyName: value.url};
      if(this.checkProperty(value ,'name')){
        postdata = Object.assign(postdata ,{'fileName':value.name});
        

      }
      if(this.checkProperty(value ,'petitionId')){
        postdata = Object.assign(postdata ,{'petitionId':value.petitionId});
        

      }
      
      this.$vs.loading();
      this.$store.dispatch("getSignedUrl", postdata).then(response => {
        this.$vs.loading.close();
        window.open(response.data.result.data, '_blank').focus();;
        //window.location.href = response.data.result.data;
        this.$vs.loading.close();
      });
    },
    checkEmptyorNullObj(Obj) {
      var bool = false;
      if (Obj == null || Obj == undefined) {
        return bool;
      }
      Object.keys(Obj).forEach(function(key, keyIndex) {
        if (
          Obj[key] != null &&
          typeof Obj[key] === "object" &&
          Obj[key] !== null
        ) {
          Object.keys(Obj[key]).forEach(function(subkey, subkeyIndex) {
            if (subkey == "_id" || subkey == "id" || subkey == "status" ) {
            } else {
              if (
                Obj[key] &&
                Obj[key][subkey] &&
                typeof Obj[key][subkey] === "object" &&
                Obj[key][subkey] !== null
              ) {
                Object.keys(Obj[key][subkey]).forEach(function(
                  ssubkey,
                  ssubkeyIndex
                ) {
                  if (ssubkey == "_id" || ssubkey == "id" || subkey == "status") {
                  } else {
                    if (
                      Obj[key][subkey][ssubkey] != null &&
                      Obj[key][subkey][ssubkey] != undefined &&
                      Obj[key][subkey][ssubkey] != ""
                    ) {
                      bool = true;
                    }
                  }
                });
              } else {
                if (
                  Obj[key] &&
                  Obj[key][subkey] &&
                  Obj[key][subkey] != null &&
                  Obj[key][subkey] != undefined &&
                  Obj[key][subkey] != ""
                ) {
                  bool = true;
                }
              }
            }
          });
        } else {
          if (Obj[key] != null && Obj[key] != "") {
            bool = true;
          }
        }
      });
      return bool;
    },
    checkFileFormat(mimetype=''){
     
      let return_val ='commonfiles.png';
      let mimeTypes= {
          video_mime_types:[
            'audio/basic',
            'auido/L24',
            'audio/mid',
            'audio/mp4',
            'audio/x-aiff',
            'audio/x-mpegurl',
            'audio/vnd.rn-realaudio',
            'audio/ogg',
            'audio/vorbis',
            'audio/vnd.wav',
            'audio/mpeg',
            'application/annodex',
            'application/mp4',
            'application/ogg',
            'application/vnd.rn-realmedia',
            'application/x-matroska',
            'video/3gpp',
            'video/3gpp2',
            'video/annodex',
            'video/divx',
            'video/flv',
            'video/h264',
            'video/mp4',
            'video/mp4v-es',
            'video/mpeg',
            'video/mpeg-2',
            'video/mpeg4',
            'video/ogg',
            'video/ogm',
            'video/quicktime',
            'video/ty',
            'video/vdo',
            'video/vivo',
            'video/vnd.rn-realvideo',
            'video/vnd.vivo',
            'video/webm',
            'video/x-bin',
            'video/x-cdg',
            'video/x-divx',
            'video/x-dv',
            'video/x-flv',
            'video/x-la-asf',
            'video/x-m4v',
            'video/x-matroska',
            'video/x-motion-jpeg',
            'video/x-ms-asf',
            'video/x-ms-dvr',
            'video/x-ms-wm',
            'video/x-ms-wmv',
            'video/x-msvideo',
            'video/x-sgi-movie',
            'video/x-tivo',
            'video/avi',
            'video/x-ms-asx',
            'video/x-ms-wvx',
            'video/x-ms-wmx',
          ],
          pdf:['application/pdf' ,"application/pdf"],
          msDoc:[ 'application/msword' ,"application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
          msXl:[
            'application/excel',
            'application/x-excel',
            'application/x-msexcel',
            'application/vnd.ms-excel',
          ],
          msPpt:[
            'application/mspowerpoint',
            'application/vnd.ms-powerpoint',
            'application/powerpoint',
            'application/x-mspowerpoint',
          ],
          zip:[
            'application/x-rar-compressed', 
            'application/octet-stream',
            'application/zip', 
            'application/octet-stream', 
            'application/x-zip-compressed', 
            'multipart/x-zip'
          ],
         image:['image/jpeg','image/png' ,'image/jpg' ,'image/gif' ,"image/ief","image/jpeg" ]

      }
      /*
       @/assets/images/main/commonfiles.png
        @/assets/images/main/zip-file-format.png 
        @/assets/images/main/film.png
         @/assets/images/main/xls.svg 
      @/assets/images/main/ppt.svg 
      @/assets/images/main/pdf.svg 
      @/assets/images/main/image.svg 
      @/assets/images/main/doc.svg
      */
     
      let fileNames = {
        video_mime_types:"film",
        pdf:"pdf",
        msDoc:"doc",
        msXl:"xls",
        msPpt:"ppt",
        zip:"zip-file-format",
        image:'image'
      }
      try{
        _.forEach(fileNames ,(val,key)=>{
         
          
          if(_.has(mimeTypes ,key) && mimetype){
            if(mimetype.includes('image/')){
              return_val ="image"
            }else if(mimeTypes[key].indexOf(mimetype) >-1){
            return_val =key;
            // alert(key)
            //rturn ;
            }
          }

        })
        return return_val;
      }catch(e){
        return_val ='commonfiles.png';
          return return_val;

      }
      
     
    },
    updateLoading(value ,refId=''){
      try{
        let refe ="NoDataFoundRef";
        if(refId){
          refe =refId;
        }
        if(this.$refs[refe]){

          this.$refs[refe].updateLoading(value);

        }


      }catch(err){
        
        
      }
    },

    validateEmail(email){
      return String(email)
        .toLowerCase()
        .match(
          /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        );
    },
    formatDocLabel(value){
      if (value) {
        var doctypes = [
          {
            'key':'bnfSpouseLatestI797',
            'name':'Latest I-797, Notice of Approval of the spouse (if spouse is on H-1B or L-1 status)'
          },
          {
            'key':'bnfSpousePassport',
            'name':'Spouse’s Passport- First page with photo, Visa page and last page with address'
          },
          {
            'key':'bnfSpouseRecentPayStubs',
            'name':'Three recent pay stubs (if spouse is on H-1B or L-1 status)'
          },
          {
            'key':'bnfSpouseFormAllI20',
            'name':'Spouse’s all Form I-20s (if spouse is on F-1 status)'
          },
          {
            'key':'passportVisaI94',
            'name':'Passport- First page with photo, Visa page and last page with address'
          },
          {
            'key':'passport',
            'name':'Passport- First page with photo and last page with address'
          },{
            'key':'visa',
            'name':'Visa'
          },
          {
            'key':'formI94',
            'name':'I94'
          },
          {
            'key':'formI797',
            'name':'Form I-797'
          },{
            'key':'marriageCertificate',
            'name':'Marriage Certificate (if spouse is on H-1B, L-1, or F-1 status) '
          },{
            'key':'birthCertificate',
            'name':'Birth Certificate'
          },{
            'key':'resume',
            'name':'Resume'
          },{
            'key':'education',
            'name':'Master’s/ Bachelor’s degree certificate, transcripts, 12th and 10th certificates'
          },{
            'key':'expLetters',
            'name':'Experience Letters'
          },{
            'key':'INSNotices',
            'name':'I-797, Notice of Approval granting the current nonimmigrant status (if applicable)'
          },
          {
            'key':'formI20',
            'name':'All Form I-20s if applicable'
          },{
            'key':'socialSecurityCardAndProfLicense',
            'name':'Social Security Card'
          },{
            'key':'I140ApprovalNotice',
            'name':'I–140 Approval Notice'
          },
    
          {
            'key':'I797NoticeofApprovalforI140',
            'name':'I-797, Notice of Approval for I-140 if available'
          },
          
          {
            'key':'payStubs',
            'name':'Three recent pay stubs'
          },
          //offerLetter
          {
            'key':'offerLetter',
            'name':'Employment Offer Letter'
          },
          {
            'key':'employmentAgreement',
            'name':'Employment Agreement'
          },
          
          
          //clientLetter
          {
            'key':'clientLetter',
            'name':'Client Letter'
          }
          ,
          //vendorLetter
          {
            'key':'vendorLetter',
            'name':'Vendor Letter if applicable'
          }
          //msa
          ,
          //vendorLetter
          {
            'key':'msa',
            'name':'MSA/Service Agreement and PO/SOW'
          }
          ,
          //po
          {
            'key':'po',
            'name':'PO'
          },
          {
            'key':'travelHistory',
            'name':'Travel History'
          },
          {
            'key':'ssn',
            'name':'Social Security Number'
          },
          
          {
            'key':'other',
            'name':'Others'
          }
          ,
          {
            'key':'approvalNotice',
            'name':'Approval Notice'
          },
          {
            'key':'beneficiaryDocs',
            'name':'Beneficiary Documents'
          },
    
          {
            'key':'h1bRegSelectionNotice',
            'name':'H-1B Registration Selection Notice'
          },
          {
            'key':'ead',
            'name':'EADs (if on OPT or STEM OPT Extension)'
          },
          {
            'key':'primeVendor',
            'name':'Prime Vendor Letter if applicable'
          },
          // {
          // 	'key':'formI94',
          // 	'name':'I-94'
          // }
          ,
          //slgApprovalNoticeOfPrevH4
          {
            'key':'slgApprovalNoticeOfPrevH4',
            'name':'SLG Spouse Current and Previous H4 Approval Copies'
          },
    
          {
            'key':'priorFormI797',
            'name':'All prior I-797, Notice of Approvals granting H-1B status'
          },
          {
            'key':'noticeOfApprovalOfH1Status',
            'name':'Notice of approval of H1 Status'
          },
          {
            'key':'approvalNoticeOfPrevH4',
            'name':'Previous H4 approval notices'
          },
          {
            'key': 'slgEvalOfEduCredentials',
            //'name': 'Evaluation of Education certification'
            // "name":"Education/Education+Experience Evaluation" and 
            "name":"Education Evaluation"
          },
          {
            'key' : 'slgEvalOfEduExpCredentials',
            'name':'Education+Experience Evaluation'
          },
          {
            'key' : 'slgEduCredentials',
            'name':'Education certification'
          },
          {
            'key' : 'slgTransScripts',
            'name':'Transcripts/Marks memo’s'
          },
    
          {
            'key': "slgAdvancedDegrees",
            'name': "Adavanced Degree Certificate"
          },
          {
            'key': "slgCurPrevH1BH4ApprovalsByINS",
            'name': "Previous H1B & H4 Approvals by INS"
          },
          {
            "key":"slgResume",
            "name":"Current Resume- Please mention the accurate names of the employer and periods of employment. Do not state the client names"
            },
            {
             "key":"slgCollegeDegreesCert",
            "name":"All College Degrees"
            },
            {
             "key":"slgTransScripts",
            "name":"Transcripts/Marks memo’s."
            },
            {
             "key":"slgExpLetters",
            "name":"Letters of Experience.Each experience letter on company letterhead must document your professional experience and must include the (1) job title (2) duration of employment (beginning date and ending date), (3) full time (i.e., 40 hours) or part time position, and (4) the job duties.  If you had more than one position within the company, please list each position along with the job description"
            },
            
            {
             "key":"slgPassportAndVisa",
             "name":"Copy of New and Old Passport"
            },
            {
             "key":"slgI94",
             "name":"I-94"
            },
            
            {
             "key":"slgPrevNonimmApprovalNotices",
             "name":"Copy of all Previous Nonimmigrant Approval Notices (e.g., H-1B, H-4, L-1A, L-1B, L-2 etc.,)"
            },
            {
             "key":"slgI140OrPermNoties",
             "name":"Copy of any I-140 approval notices or PERM filing Notices (if applicable)"
            },
            {
             "key":"slgPrevLaborApplications",
             "name":"Copy of the previously filed Labor Application, if applicable"
            },
            
            {
             "key":"slgAckOfPrevLaborApplications",
             "name":"Copy of the Acknowledgement letter for the previously filed Labor application, if applicable"
            },
            {
             "key":"slgPaystubs",
             "name":"Copies of Most recent paystubs (last 2 to 3 months)"
            },
            
            {
             "key":"slgI20",
             "name":"Copies of all I-20’s"
            },
            {
             "key":"slgEad",
             "name":"Copies of EAD cards"
             
            },
    
            {
            "key":"w2",
            "name":"Copy of all w2"
            
           },
          //  {
          // 	"key":"slgEvalOfEduCredentials",
          // 	"name":"Evaluation of Education certification"
            
          //  },
           {
            "key":"slgPrevImmApprovalNotices",
            "name":"Copy of all Previous Immigrant Approval Notices (e.g., H-1B, H-4, L-1A, L-1B, L-2 etc.,)"
            
           },
    
          
    
          //approvalNotice
          //perm Advertisement Documents
          {
            key: 'sunday',
            name: 'Copy of Advertisement',
            },
            {
            key: 'jobFair',
            name: 'Copy of Advertisement',
            },
            {
            key: 'campusRecruitment',
            name: 'Copy of Advertisement',
            },
            {
            key: 'empWebsite',
            name: 'Copy of Advertisement',
            },
            {
            key: 'profOrgOrTrade',
            name: 'Copy of Advertisement',
            },
            {
            key: 'jobSearchWebsite',
            name: 'Copy of Advertisement',
            },
            {
            key: 'pvtEmpmtFirm',
            name: 'Copy of Advertisement',
            },
            {
            key: 'empRefProgram',
            name: 'Copy of Advertisement',
            },
            {
            key: 'campusPlacement',
            name: 'Copy of Advertisement',
            },
            {
            key: 'localNewsPaper',
            name: 'Copy of Advertisement',
            },
            {
            key: 'tvAds',
            name: 'Copy of Advertisement',
            },
            {
            key: 'recruReportSummary',
            name: 'Recruitment Report and Summary describing the recruitment efforts and results',
            },
            {
            key: 'busNecLetterByEplr',
            name: 'Business Necessity Letter Provided by Employer',
            },
            {
            key: 'intrOfcMemomandum',
            name: 'Signed copies',
            },
            {
            key: 'payReceipt',
            name: 'Receipt',
            },
            {
            key: 'documents', 
            name: 'Acknowledgement',
            },
            {
            key: 'usicsDocuments',
            name: 'Documents',
            },
            /// Education form documents
            {
            key:'educationPassport',
            name:'Passport'
            },
            {
            key:'graduationCertificate',
            name:'Certificate of Graduation'
            },
            {
            key:'transcripts',
            name:'Transcripts/Marks Memo'
            }, {
            'key':'eduTranscripts',
            'name':'U.S. Master’s Degree Certificate and Transcripts'
          },
          //485 fields copy of the EAD CARD(S), front and  back  
          {
            key: "appliedAOSInUSDocs",
            name: "copy of applied AOS in the united states or an immigrant visa at the US Embassy"
          },
          {
            key: "eadCard",
            name: "Copy of the EAD CARD(S), front and  back"
          },
          {
            key: "slgSignedOfferLetter",
            name: "Signed Offer Letter"
          },
          {
            key: "slgOfferLetter",
            name: "Unsigned Offer Letter"
          },
          {
            key: "marriageCertDocs",
            name: "Copy of Marriage Certificates"
          },
          {
            key: "haveYouArrestedBeforeDocs",
            name: "Copy of the Documents"
          },
          {
            key: "marriageCertificate",
            name:"Marriage Certificate (if spouse is on H-1B, L-1, or F-1 status) "
            //name: "Copy of the marriage certificate, with certified translation if required."
          },
          {
            key: "underlyingLaborApplications",
            name: "Copy of the underlying Labor Certification (PERM) if applicable"
          },
          {
            key: "mostRecentTaxTranscrips",
            name: "A copy of Most Recent Year’s Tax Transcripts – can be obtained from"
          },
          {
            key: "w2",
            name: "Copy of all w2"
          },
          {
            key: "photographs",
            name: "Photographs"
          },
          {
            key: "medicalExamins",
            name: "Medical Examins"
          },
          {
            key: "dependentForI134",
            name: "Dependent For I-134"
          },
          {
            key: "dependentTaxReturns",
            name: "Dependent Tax Returns"
          },
          {
            key: "bankStatements",
            name: "Bank Statements"
          }, 
          {
            key: "evidenceOfContinuVisaStatus",
            name: "Evidence of Continue Visa Status"
          }, 
          {
            key: "evidenceOfFilePetitionBefore30Apr2001",
            name: "Evidence of File Petition Before 30-Apr-2001"
          }, 
          {
            key: "proofOfIncomeOrAsset",
            name: "Proof of Income or Asset"
          }, 
          { 
            key: "proofOfMedicalInsurence",
            name: "Proof of Medical Insurence"
          }, 
          {
            key: "recentCreditReport",
            name: "Recent Credit Report"
          }, 
          {
            key: "permResidence",
            name: "Permenant Residence" 
          }, 
          {
            key: "empAuth",
            name: "Employment Auth"
          },
          {
            key: "capSelectNotice",
            name: "CAP Selection Notice"
          },
          {
            key: "formI797H4ApprovalNotice",
            name: "Form I-797 H4 approval notice if applicable",
                
            },
          {
        
          key: "h4Ead",
          name: "H4 EAD if applicable",
              
          },
          {
        
          key: "marriageCertificate",
          name: "Marriage Certificate (if spouse is on H-1B, L-1, or F-1 status) ",
          },
          {
          key: "formI797H1BApprovalNoticePrinNonCtzn",
          name: "Form I-797 H-1B approval notice of Principal Non-citizen",
          },
        
          {
        
          key: "passportOfPrinNonCtzn",
          name: "Passport of Principal Non-citizen- First page with photo, Visa page and last page with address",
          },
          {
        
          key: "last3MonthsPayslipsOfPrinNonCtzn",
          name: "Last 3 months pay statements of Principal Non-citizen",
              
          },
          {
            key: "slgApprovalNoticeOfPrevH4 ",
            name: "SLG Current and Previous H4 Approval Copies"
          },
          {
            key: "spouse_docs_slgApprovalNoticeOfPrevH4 ",
            name: "Current and Previous H4 Approval Copies"
          },
          {
            key: "child_docs_slgApprovalNoticeOfPrevH4 ",
            name: "Current and Previous H4 Approval Copies"
          },
          {
            key: "Petitioner",
             name: "Petitioner",
          },
          {
          key: "cheques",
          name: "Cheques", 
          },
          {
            //companyDocs
            key: "companyDocs",
             name: "Company Documents",
          },
          {
          key: "Forms",
          name: "Forms",   
          },
          {
            key: "Letters",
            name: "Letters",  
            },
          {
          key: "beneficiary_forms_and_letters",
          name: "Beneficiary Forms And Letters", 
          },
          {
            key: "spouse_forms_and_letters",
            name: "Spouse Forms And Letters",  
          },
          {
            key: "child_1",
            name: "Child 1 Forms And Letters",
          },
          {
            key: "child_2",
            name: "Child 2 Forms And Letters",
                
          },
          {
            key: "child_3",
            name: "Child 3 Forms And Letters",    
          },
          {
            key: "child_4",
            name: "Child 4 Forms And Letters",     
          },
          {
            key: "child_5",
            name: "Child 5 Forms And Letters",
          },
          {
            key: "child_6",
            name: "Child 6 Forms And Letters",     
          },
          {
            key: "child_7",
            name: "Child 7 Forms And Letters", 
          },
          {
            key: "child_8",
            name: "Child 8 Forms And Letters",     
          },
          {
            key: "Petitioner",
            name: "Petitioner",   
          },
          {
            key: "Beneficiary",
            name: "Beneficiary",  
          },
          {
            key: "Law Firm",
            name: "Law Firm", 
          },
          {
            key: "Company",
            name: "Company", 
          },
          {
            key: "USCIS",
            name: "USCIS",  
          },
          {
            key: "USCISDocs",
            name: "USCIS",   
          },
          {
            key: "USCIS Docs",
            name: "USCISDocs",   
          },
          {
            key: "recent_forms_and_letters",
            name: "Recent Forms and Letters",    
          },
          {
            key: "recent_beneficiary_docs",
            name: "Beneficiary Recent",   
          },
          {
    
            key: "recent_scanned_copies",
            name: "Recent Scanned Copies",
                
          },
          //////Petitioner Documents
          {
            key: "articleOfIncorp",
            name: "Articles of Incorporation",	
          },
          {
            key: "stateRegCert",
            name: "State Registration Certificate",	
          },
          {
            key: "fein",
            name: "Document identifying the EIN number (Form SS-4 issued by IRS)",	
          },
          {
            key: "goodStandCert",
            name: "Good standing certificate",	
          },
          {
            key: "markMetOrWebsitePrints",
            name: "Marketing materials/website printouts",	
          },
          {
            key: "orgCharts",
            name: "Organizational chart",	
          },
          {
            key: "latestTaxReturn",
            name: "Last two years Federal income tax returns",	
          },
          {
            key: "latestWageReports",
            name: "Copy of Last four quaterly wage reports",	
          },
          {
            key: "letterHeads",
            name: "Copy of Petitioner letterhead in word format",	
          },
        ]
        var find = _.find(doctypes, { 'key': value});
        return find?find.name:"";
      }
    }
   

  },
  computed:{
    checkIsEditRow(){
       return this.$store.state['editDashBoardRow'];

    },
    getisGlobalSearchOpened(){
      return this.$store.state['globalSearchopen'];
      
    },
    getPetitionActionStatus(){
      return this.$store.state.showPetitionActionBtn
    },
    getCompletedActivities(){
      let returnVal =[];
      if(this.checkProperty( this.getPetitionDetails ,'completedActivities')){
        returnVal = this.getPetitionDetails['completedActivities'];
      }
      return returnVal

    },

    checkPetEditPermission(){
      if([50,3,11].indexOf(this.getUserRoleId)>-1 && !this.checkisSubmitToLawFirmCompleted ){
        return true;

      }else{
        return false;
      }
   },
   //SUBMIT_TO_LAW_FIRM
 checkisSubmitToLawFirmCompleted(){
   let returnVal =false;
  let getWorkFlowDetails =   this.getWorkFlowDetails
   if(
     (this.checkAdminLoginroles)
    && ( this.getPetitionDetails && getWorkFlowDetails)
    && ( _.has(this.getPetitionDetails ,'completedActivities') && this.getPetitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM')>-1  )

   ){
     returnVal =true;

   }

   return returnVal;

 },

    caseFiledTxt(){
      //COURIER_TRACKING
      //UPDATE_USCIS_RECEIPT_NUMBER

      let returnText ="Update Tracking Info";
      
    if(this.getPetitionDetails && this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity')== 'UPDATE_USCIS_RECEIPT_NUMBER'){
        returnText = "Update Receipt Number";
    }

      return returnText;
    },

    checkTrackingPermessions(){
      let petitionDetails = this.getPetitionDetails;
     let workFlowDetails = this.getWorkFlowDetails;
     let returnVal =false;
    
    
     if(petitionDetails && workFlowDetails && _.has( workFlowDetails,'config') && (petitionDetails['nextWorkflowActivity'] == 'COURIER_TRACKING' || petitionDetails['nextWorkflowActivity'] == 'UPDATE_USCIS_RECEIPT_NUMBER' ) ){
        let code = petitionDetails['nextWorkflowActivity'];
       
       let requestPetitionerSign = _.find(workFlowDetails.config ,{'code':code});
       if(
         (
           (_.has(requestPetitionerSign ,"editors") &&  _.find(requestPetitionerSign.editors ,{"roleId":this.getUserRoleId}) ) ||  this.checkAdminLoginroles 
         
         )
       && this.checkProperty(requestPetitionerSign ,'actionRequired') =="Yes"
      
       && ( _.has(petitionDetails , 'petitionerSignRequested') && petitionDetails['petitionerSignRequested'] )
      
      // &&(completedActivityList && (completedActivityList.length>0 && completedActivityList.indexOf("ASSIGN_ATTORNEY")>-1) )
      // && this.scannedCopiesList.length>0

       ){
         returnVal =true;
        

       }
       

     }
     return returnVal;

   },
   checkCourierTracking(){
      let petitionDetails = this.$store.state.petitionDetails;
     let workFlowDetails = this.$store.state.workFlowDetails;
     let returnVal =false;
     let code = "COURIER_TRACKING";
     let completedActivityList = this.getPetitionDetails['completedActivities'];
     if(workFlowDetails && _.has( workFlowDetails,'config')  ){
       
       let requestPetitionerSign = _.find(workFlowDetails.config ,{'code':code});
       if(
         ( 
          ( _.has(requestPetitionerSign ,"editors") &&  _.find(requestPetitionerSign.editors ,{"roleId":this.getUserRoleId})) || this.checkAdminLoginroles 
       )
       && this.checkProperty(requestPetitionerSign ,'actionRequired') =="Yes"

       && (this.getPetitionDetails.courierTrackingCategory=='UPDATE_TRACKING_NUMBER' )
       &&(completedActivityList && (completedActivityList.length>0 && completedActivityList.indexOf("ASSIGN_ATTORNEY")>-1) )
       && this.scannedCopiesList.length>0

       ){
         returnVal =true;

       }
       

     }
     return returnVal;

   },
   checkSubmitToUscis(){
     let petitionDetails = this.$store.state.petitionDetails;
     let workFlowDetails = this.$store.state.workFlowDetails;
     let returnVal =false;
     let code = "UPDATE_USCIS_RESPONSE";
     if(workFlowDetails && _.has( workFlowDetails,'config') && petitionDetails['nextWorkflowActivity'] == code ){
       
       let requestPetitionerSign = _.find(workFlowDetails.config ,{'code':code});
       if(
         (
          (  _.has(requestPetitionerSign ,"editors") &&  _.find(requestPetitionerSign.editors ,{"roleId":this.getUserRoleId})) || this.checkAdminLoginroles 
         )
       && this.checkProperty(requestPetitionerSign ,'actionRequired') =="Yes"
       && this.scannedCopiesList.length>0
       ){
         returnVal =true;

       }
       

     }
     return returnVal;

   },
  
   checkUpdateUscisResponse(){
     //
      let petitionDetails = this.$store.state.petitionDetails;
     let workFlowDetails = this.$store.state.workFlowDetails;
     let returnVal =false;
     let code = "UPDATE_USCIS_RESPONSE";
     if(workFlowDetails && _.has( workFlowDetails,'config') && petitionDetails['nextWorkflowActivity'] == code ){
       
       let requestPetitionerSign = _.find(workFlowDetails.config ,{'code':code});
       if(          
         (
           (_.has(requestPetitionerSign ,"editors") &&  _.find(requestPetitionerSign.editors ,{"roleId":this.getUserRoleId}))  || this.checkAdminLoginroles 
         
         )
        && this.checkProperty(requestPetitionerSign ,'actionRequired') =="Yes"
       //  && this.scannedCopiesList.length>0
       ){
         
         returnVal =true;

       }
       

     }
     return returnVal;

   },
   
   checkFilingFeeActivity(){
     let petitionDetails = this.$store.state.petitionDetails;
     let completedActivities  = [];
     if(this.checkProperty(petitionDetails ,'completedActivities' )){
       completedActivities = petitionDetails['completedActivities']
     }
     if(
        completedActivities.indexOf('SUBMIT_TO_LAW_FIRM')>-1
       //( _.has(petitionDetails , 'nextWorkflowActivity') && petitionDetails['nextWorkflowActivity'] =='FILING_FEE')
     
     ){
     
      let workFlowDetails = this.$store.state.workFlowDetails;
      if(_.has(workFlowDetails ,'config') && workFlowDetails['config'] ){
       let config = workFlowDetails['config'];
       let filingFee = _.find(config ,{"code":'FILING_FEE'})
        if(
         ( _.find(filingFee['editors'] ,{"roleId":this.getUserRoleId}) || this.checkAdminLoginroles )
          
          && this.checkProperty(filingFee ,'actionRequired') =="Yes"   ){
           return true;
        }else{
           return false;
        }

      }else{
        return false;
      }

     
     }else{
       return false;
     }

   },


    ///////////////////
    checkSendForSigning(){
    
      let workFlowDetails = this.$store.state.workFlowDetails;
      let returnVal =false;
      if(workFlowDetails && _.has( workFlowDetails,'config') ){

        let code = "REQUEST_PETITIONER_SIGN";
        let approveCase = "CASE_APPROVED";
       
        let requestPetitionerSign = _.find(workFlowDetails.config ,{'code':code});
       if( (_.has( this.getPetitionDetails ,"nextWorkflowActivity") && this.getPetitionDetails['nextWorkflowActivity'] ==code )
            &&
            ( ( _.has(requestPetitionerSign ,"editors")  &&  _.find(requestPetitionerSign.editors ,{"roleId":this.getUserRoleId}) ) || this.checkAdminLoginroles )
            && this.checkProperty(requestPetitionerSign ,'actionRequired') =="Yes"
            ){
          returnVal =true;

        }
       
         
        

      }
      return returnVal;
    },
    checkLcaUpdate(){
      //{{lcaDetails.createdByRoleId}} -- {{lcaDetails.createdBy}}
      let petitionDetails = this.$store.state.petitionDetails;
      let workFlowDetails = this.$store.state.workFlowDetails;
      let self =this;
      let returnVal =false;
      let code = "LCA_SUBMIT";
       let completedActivityList = petitionDetails['completedActivities'];
      let lcaDetails =  this.getLcaDetails

       let userId = this.checkProperty( this.getUserData ,"userId")

       if(completedActivityList && completedActivityList.indexOf("CASE_APPROVED")>-1){
         returnVal =false
         return returnVal;
       }
       
     else if( (lcaDetails && _.has(lcaDetails , 'createdBy' ) &&  _.has(lcaDetails , "statusId")  && this.checkProperty(lcaDetails ,'statusLogs' ,"length" ) >0 ) 
        && ( ( [2,3].indexOf(lcaDetails['statusId'])>-1 ) || ( this.checkAdminLoginroles ) )
        ){



          let statusLogs  = this.checkProperty(lcaDetails ,'statusLogs' );
          let filedSataus = _.find(statusLogs ,{"statusId":2 ,"createdBy":userId} );
           let certifiedStatus = _.find(statusLogs ,{"statusId":3 ,"createdBy":userId} );
           if(filedSataus ||certifiedStatus || ( this.checkAdminLoginroles ) ){
              returnVal =true;
           }

       

      }else if(lcaDetails && workFlowDetails && _.has( workFlowDetails,'config')  ){
        let requestPetitionerSign = _.find(workFlowDetails.config ,{'code':code});
        if(
          (
            (_.has(requestPetitionerSign ,"editors") &&  _.find(requestPetitionerSign.editors ,{"roleId":this.getUserRoleId})) || ( this.checkAdminLoginroles )
          )
        && (this.checkProperty(requestPetitionerSign ,'actionRequired') =="Yes")
      //  || 
        ){
          returnVal =true;

        }
      }

          
      return returnVal;

    },
    checkCaseCustomNumberAssigned(){
      let returnValue =true;
    
    if( this.getPetitionDetails &&  _.has(this.getPetitionDetails ,'allowCustomCaseNo') && this.checkProperty(this.getPetitionDetails , 'allowCustomCaseNo') ){

      if( _.has(this.getPetitionDetails ,'completedActivities') && this.getPetitionDetails.completedActivities.indexOf('ASSIGN_CUSTOM_CASE_NO')>-1  ){

        returnValue =true
      }else{
          returnValue =false
      }
      
    

    }
    return returnValue

    },
    checkPetProfileEditPermisions(){
      let returnValue =false;
      //tenantDetails
      if(this.checkProperty( this.getUserData ,'tenantDetails' ,'permissions')){
       
          if(this.checkProperty( this.getUserData['tenantDetails']['permissions'] ,'PETITIONER_COMPLETE_PROFILE' ,'length')>0){
            if(this.getUserData['tenantDetails']['permissions']['PETITIONER_COMPLETE_PROFILE'].indexOf(this.getUserRoleId)>-1 ){
              returnValue =true
            }


         }

      }
      return returnValue
    },

    checkPetInvitePermisions(){
      let returnValue =false;
      //tenantDetails
      if(this.checkProperty( this.getUserData ,'tenantDetails' ,'permissions')){
       
          if(this.checkProperty( this.getUserData['tenantDetails']['permissions'] ,'PETITIONER_INVITE' ,'length')>0){
            if(this.getUserData['tenantDetails']['permissions']['PETITIONER_INVITE'].indexOf(this.getUserRoleId)>-1 ){
              returnValue =true
            }


         }

      }
      return returnValue
    },

    checkTaskListPermisions(){
      let returnValue =false;
      //tenantDetails
      if(this.checkProperty( this.getUserData ,'tenantDetails' ,'permissions')){
       
          if(this.checkProperty( this.getUserData['tenantDetails']['permissions'] ,'TASK_LIST' ,'length')>0){
            if(this.getUserData['tenantDetails']['permissions']['TASK_LIST'].indexOf(this.getUserRoleId)>-1 ){
              returnValue =true
            }


         }

      }
      return returnValue
    },

    checkCaseCreatePermisions(){
      let returnValue =false;
      //tenantDetails
      if(this.checkProperty( this.getUserData ,'tenantDetails' ,'permissions')){
       
          if(this.checkProperty( this.getUserData['tenantDetails']['permissions'] ,'CASE_CREATE' ,'length')>0){
            let userData = _.cloneDeep(this.getUserData);
            if(userData && this.checkProperty( userData ,'tenantDetails' ,'permissions') && userData['tenantDetails']['permissions']['CASE_CREATE'].indexOf(this.getUserRoleId)>-1 ){
              returnValue =true
            }


         }

      }
      return returnValue
    },
    checkCapCaseCreatePermisions(){
      let returnValue =false;
      if(this.checkProperty( this.getUserData ,'tenantDetails' ,'permissions')){
          if(this.checkProperty( this.getUserData['tenantDetails']['permissions'] ,'CAP_LCA_CREATE' ,'length')>0){
            let userData = _.cloneDeep(this.getUserData);
            if(userData && this.checkProperty( userData ,'tenantDetails' ,'permissions') && userData['tenantDetails']['permissions']['CAP_LCA_CREATE'].indexOf(this.getUserRoleId)>-1 ){
              returnValue =true
            }


         }

      }
      return returnValue
    },

    checkLCACreatePermisions(){
      let returnValue =false;
      //tenantDetails
      if(this.checkProperty( this.getUserData ,'tenantDetails' ,'permissions')){
       
          if(this.checkProperty( this.getUserData['tenantDetails']['permissions'] ,'LCA_CREATE' ,'length')>0){
            let userData = _.cloneDeep(this.getUserData);
            if(userData && this.checkProperty( userData ,'tenantDetails' ,'permissions') && userData['tenantDetails']['permissions']['LCA_CREATE'].indexOf(this.getUserRoleId)>-1 ){
              returnValue =true
            }


         }

      }
      return returnValue
    },


    checkBeneficaryInvitePermisions(){
      let returnValue =false;
      //tenantDetails
      if(this.checkProperty( this.getUserData ,'tenantDetails' ,'permissions')){
       
          if(this.checkProperty( this.getUserData['tenantDetails']['permissions'] ,'BENEFICIARY_INVITE' ,'length')>0){
            if(this.getUserData['tenantDetails']['permissions']['BENEFICIARY_INVITE'].indexOf(this.getUserRoleId)>-1 ){
              returnValue =true
            }


         }

      }
      return returnValue
    },

    isWhiteLabled(){
      if(this.checkProperty( this.getUserData ,"tenantDetails" , 'whiteLabled')){
        return true;
      }else{
        return false

      }
    },
   // ASSIGN_SUPERVISOR
   getCaseStatusTab(){
    if(this.checkProperty( this.$store.state ,'toggleCaseStatusTab') ){

      return this.$store.state['toggleCaseStatusTab'];
    }else{
     return "showCaseStatus"
     
    }

    

  },

   checkAssignSupervisorPermessions(){
    let returnVal =false;
    let wf = _.cloneDeep(this.getWorkFlowDetails);
    if(wf && _.has(wf,"config")){

    
      let lcaRequired = _.find( wf['config'] ,{"code":"ASSIGN_SUPERVISOR"});
     
      if(
        (lcaRequired && _.has(lcaRequired , 'editors') &&  _.has(lcaRequired , 'actionRequired') && lcaRequired['editors'].length>0 && lcaRequired.actionRequired =="Yes"   )
       && (_.find(lcaRequired['editors'] ,{"roleId":this.getUserRoleId}) || this.checkAdminLoginroles) 
      ){
        returnVal =true;
      }
    }

    return returnVal;
    
    
  },

    checkSubmiToLawPermessions(){
      let returnVal =false;
      let wf = _.cloneDeep(this.getWorkFlowDetails);
      if(wf && _.has(wf,"config")){
  
      
        let lcaRequired = _.find( wf['config'] ,{"code":"SUBMIT_TO_LAW_FIRM"});
       
        if(
          (lcaRequired && _.has(lcaRequired , 'editors') &&  _.has(lcaRequired , 'actionRequired') && lcaRequired['editors'].length>0 && lcaRequired.actionRequired =="Yes"   )
         && (_.find(lcaRequired['editors'] ,{"roleId":this.getUserRoleId}) || this.checkAdminLoginroles) 
        ){
          returnVal =true;
        }
      }
  
      return returnVal;
      
      
    },
    checkCurrentUrl(){
      let currentRoute  = this.$route;
      let currentRouteName = _.get( currentRoute,'name' ,'');
      let tempLoginUrls = ['fill-questionnaire' ,"filled-case-details","fill-perm-questionnaire" ,'filled-perm-case-details' ,'fill-lca-anonymous-user','filled-cap-registration-details','fill-cap-registration'];
      if(tempLoginUrls.indexOf(currentRouteName) >-1  ){
       return false
     }else{
       return true;
     }
     

    },
    checkSubmitUscisCompleted(){
      let getWorkFlowDetails =   this.getWorkFlowDetails
      if(
     
       ( this.getPetitionDetails && getWorkFlowDetails)
        && 
         ( _.has(this.getPetitionDetails ,'completedActivities')
         
           &&  this.getPetitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') >-1
          
         )
  
      ){
       return true;
  
      }else{
        return false
      }
    },
    getTenantTypeId(){
      
        return this.checkProperty( this.getUserData ,"tenantDetails" ,"typeId");
        
  
      
    },
    isdefaultWorkflowComplted(){
      if(this.$store.getters.isdefaultWorkflowComplted === false || this.$store.getters["common/isdefaultWorkflowComplted"] === false ){

        return false;
      }

      return true

    },
    getRandomBgClass(){
      let clsList = ["bg-1","bg-2" ,"bg-3","bg-4","bg-5", "bg-6","bg-7","bg-8","bg-9","bg-10","bg-11","bg-12","bg-13"];
      let random=  _.random((clsList.length)-1);
    //  random = Math.floor(Math.random() * clsList.length);
      return clsList[random];
    },
    getRandomClass(){
      let clsList = ["grid_1x","grid_2x",'grid_3x'];
      let random=  _.random((clsList.length)-1);
    //  random = Math.floor(Math.random() * clsList.length);
      return clsList[random];
    },

    getWallList(){
      try{
        return this.$store.getters['common/getWallList'] ;
      }catch(er){
        return [];
      }
     
    },
    getPoweredBy(){
     return this.$globalgonfig._POWEREDBY

    },

    getTenantLogo(){
      try{
        return this.$store.getters['common/getTenantLogo'] ;
      }catch(er){
        return null;
      }
     
    },
    
    
    getUserRoleId(){

      return parseInt(this.$store.state.user.roleId);
    },
    getUserData(){
      return this.$store.state.user
    },
    allDocEntity(){
      return 'image/*,application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    },
    pdfDocEntity(){
      return 'application/pdf'
    },
    wordDocEntity(){
      return 'application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    },
    imageDocEntity(){
      return '.jpg,.jpeg,.png'
    },
    getCapCaseDetails(){
      return this.$store.state.capRegisterDetails
    },
    getTenantId(){
      return this.$store.getters['common/getTenantId'] ;
    },
    getTenantType(){
      return this.$store.getters['common/getTenantType'] ;
    },
    getWorkFlowDetails(){
      
      return this.$store.state.workFlowDetails;
     
  },
   getLcaDetails(){
      return this.$store.state.lcaDetails
  },
  getPetitionDetails(){
      return this.$store.state.petitionDetails
  },
  checkPetitionLcaRequired(){
    let returnVal =false;
    let wf = _.cloneDeep(this.getWorkFlowDetails);
    if(wf && _.has(wf,"config")){

    
      let lcaRequired = _.find( wf['config'] ,{"code":"LCA_REQUEST"});
      let lcaSubmit = _.find( wf['config'] ,{"code":"LCA_SUBMIT"});
      if(
        (lcaRequired && _.has(lcaRequired , 'editors') &&  _.has(lcaRequired , 'actionRequired') && lcaRequired['editors'].length>0 && lcaRequired.actionRequired =="Yes"   )
       // && (_.find(lcaRequired['editors'] ,{"roleId":this.getUserRoleId}) || this.checkAdminLoginroles) 
      ){
        returnVal =true;
      }
    }

    return returnVal;
    
    
  },
  checkPetitionLcaSubmit(){
    let returnVal =false;
    let wf = _.cloneDeep(this.getWorkFlowDetails);
    if(wf && _.has(wf,"config")){
     
      let lcaRequired = _.find( wf.config ,{"code":"LCA_REQUIRED"});
      let lcaSubmit = _.find( wf.config ,{"code":"LCA_SUBMIT"});
      if(
        (lcaSubmit && _.has(lcaSubmit , 'editors') &&  _.has(lcaSubmit , 'actionRequired') && lcaSubmit['editors'].length>0 && lcaSubmit.actionRequired =="Yes"  )
        &&  (_.find(lcaSubmit['editors'] ,{"roleId":this.getUserRoleId}) || this.checkAdminLoginroles) 
      ){
        returnVal =true;
      }
    }

    return returnVal;
    
    
  },
  checkFIlingFeeEditPermession(){

    // let adminsactiVityList = _.find(this.workFlowDetails.config , {"code":'MANAGER_LIST'});
    // if(adminsactiVityList && adminsactiVityList.editors){
    // this.adminsList = _.map(adminsactiVityList.editors, 'roleId');
    // }

    let returnVal =false;
    let wf = _.cloneDeep(this.getWorkFlowDetails);
    if(wf && _.has(wf,"config")){
     
      let filingFee = _.find( wf.config ,{"code":"FILING_FEE"});
      let adminsactiVityList = _.find(wf.config , {"code":'MANAGER_LIST'});
     
      if(
        (filingFee && _.has(filingFee , 'editors') &&  filingFee['editors'].length>0   )
        &&  (_.find(filingFee['editors'] ,{"roleId":this.getUserRoleId}) || this.checkAdminLoginroles) 
      ){
               returnVal =true;
      }else if(adminsactiVityList && adminsactiVityList.editors){
            let adminsList = _.map(adminsactiVityList.editors, 'roleId');
            returnVal  = adminsList.indexOf(this.getUserRoleId) > -1;
          }

    }

    return returnVal;
    

  },
  checkAdminLoginroles(){
    let returnValue=false;

    if([3,4].indexOf(this.getUserRoleId) >-1){
        returnValue=true;
    }
    return returnValue
  },
  
  checkCaseApprove(){
    let returnVal =false;
   let getWorkFlowDetails =   this.getWorkFlowDetails
    if(
      (this.checkAdminLoginroles)
     && ( this.getPetitionDetails && getWorkFlowDetails)
      && 
       ( _.has(this.getPetitionDetails ,'completedActivities')
        && this.getPetitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM')>-1 
         &&  this.getPetitionDetails.completedActivities.indexOf('CASE_APPROVED') <=-1
        && this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity') !="CASE_APPROVED"
       )

    ){
      returnVal =true;

    }

    return returnVal;

  },
  isCaseApproved(){
    
    let getWorkFlowDetails =   this.getWorkFlowDetails
     if(
    
      ( this.getPetitionDetails && getWorkFlowDetails)
       && 
        ( _.has(this.getPetitionDetails ,'completedActivities')
        
          &&  this.getPetitionDetails.completedActivities.indexOf('CASE_APPROVED') >-1
         
        )
 
     ){
      return true;
 
     }else{
       return false
     }
 
     

  },

  isUpdatedUscisResponce(){
    //USCIS_APPROVED
    //USCIS_RECEIVED_RFE
    //USCIS_DENIED
    //USCIS_WITHDRAWN
    
    let getWorkFlowDetails =   this.getWorkFlowDetails
     if(
    
      ( this.getPetitionDetails && getWorkFlowDetails)
       && 
        ( _.has(this.getPetitionDetails ,'completedActivities')
        
          && ( 
            this.getPetitionDetails.completedActivities.indexOf('UPDATE_USCIS_RESPONSE') >-1
            || this.getPetitionDetails.completedActivities.indexOf('USCIS_APPROVED') >-1
            || this.getPetitionDetails.completedActivities.indexOf('USCIS_RECEIVED_RFE') >-1
            || this.getPetitionDetails.completedActivities.indexOf('USCIS_DENIED') >-1
            || this.getPetitionDetails.completedActivities.indexOf('USCIS_WITHDRAWN') >-1
            
           
            

          )
         
        )
 
     ){
      return true;
 
     }else{
       return false
     }
 
     

  },
  checkLcastatus(){
    let getPetitionDetails = this.getPetitionDetails;
    let getLcaDetails = this.getLcaDetails;
    let returnVal =true;
    let wf = this.getWorkFlowDetails;

    if(wf && _.has(wf,"config")){
    
      let lcaRequired = _.find( wf.config ,{"code":"LCA_REQUIRED"});
    
      if( (lcaRequired && _.has(lcaRequired , 'editors') && lcaRequired.actionRequired =="Yes"  )
        
      ){
        if((getLcaDetails && [2,3].indexOf(getLcaDetails['statusId']))>-1 ){
          returnVal =true;
        }else{
          returnVal =false;
        }
        
      }else{
        returnVal =true;
      }
    }

    return returnVal;

  },
  checkPetitionLcaRequiredandPermessions(){
    let returnVal =false;
    let wf = _.cloneDeep(this.getWorkFlowDetails);
    if(wf && _.has(wf,"config")){

    
      let lcaRequired = _.find( wf['config'] ,{"code":"LCA_REQUEST"});
      let lcaSubmit = _.find( wf['config'] ,{"code":"LCA_SUBMIT"});
      if(
        ((lcaRequired && _.has(lcaRequired , 'editors') &&  _.has(lcaRequired , 'actionRequired') && lcaRequired['editors'].length>0 && lcaRequired.actionRequired =="Yes"   )
       && (_.find(lcaRequired['editors'] ,{"roleId":this.getUserRoleId}) || this.checkAdminLoginroles) ) || 
       (lcaSubmit &&   lcaSubmit['editors'].length>0 &&  (_.find(lcaSubmit['editors'] ,{"roleId":this.getUserRoleId }) || this.checkAdminLoginroles ) )
      ){
        returnVal =true;
      }
    }

    return returnVal;
    
    
  },
  isApproveCaseCompleted(){

    let getWorkFlowDetails =   this.getWorkFlowDetails
    if(
   
     ( this.getPetitionDetails && getWorkFlowDetails)
      && 
       ( _.has(this.getPetitionDetails ,'completedActivities')
       
         &&  this.getPetitionDetails.completedActivities.indexOf('ASSIGN_ATTORNEY') >-1
        
       )

    ){
     return true;

    }else{
      return false
    }

  },
  checkDoceAssigned(){

    let getWorkFlowDetails =   this.getWorkFlowDetails
     if(
    
      ( this.getPetitionDetails && getWorkFlowDetails)
       && 
        ( _.has(this.getPetitionDetails ,'completedActivities')
        
          &&  this.getPetitionDetails.completedActivities.indexOf('ASSIGN_DOCUMENTATION_EXECUTIVE') >-1
         
        )
 
     ){
      return true;
 
     }else{
       return false
     }

  },

  checkDocmAssigned(){

    let getWorkFlowDetails =   this.getWorkFlowDetails
     if(
    
      ( this.getPetitionDetails && getWorkFlowDetails)
       && 
        ( _.has(this.getPetitionDetails ,'completedActivities')
        
          &&  this.getPetitionDetails.completedActivities.indexOf('ASSIGN_DOCUMENTATION_MANAGER') >-1
         
        )
 
     ){
      return true;
 
     }else{
       return false
     }

  },
  
  
  checkIsloginUserDocm(){
      
    let petitionDetails = this.$store.state.petitionDetails;
    let workFlowDetails = this.$store.state.workFlowDetails;
    let returnVal =false;
    let code = "ASSIGN_DOCUMENTATION_MANAGER";
    if(
      (workFlowDetails && _.has( workFlowDetails,'config') )
    
    && ( 
      _.has(petitionDetails ,'completedActivities') &&  petitionDetails.completedActivities.indexOf('ASSIGN_DOCUMENTATION_MANAGER') >-1
       )
    ){

      let requestPetitionerSign = _.find(workFlowDetails.config ,{'code':code});
     let  docmUseeListConf = _.find(workFlowDetails.config ,{'code':'DOCUMENTATION_MANAGER_LIST'});
      if(
        this.checkProperty(requestPetitionerSign ,'actionRequired') =="Yes"
        && (_.find(docmUseeListConf['editors'] ,{"roleId":this.getUserRoleId})) 
      ){
        returnVal =true;

      }
      

    }
    return returnVal;

  },
  checkIsloginUserDoce(){
      
    let petitionDetails = this.$store.state.petitionDetails;
    let workFlowDetails = this.$store.state.workFlowDetails;
    let returnVal =false;
   
    if(
      (workFlowDetails && _.has( workFlowDetails,'config'))
       && ( 
         _.has(petitionDetails ,'completedActivities') &&  petitionDetails.completedActivities.indexOf('ASSIGN_DOCUMENTATION_EXECUTIVE') >-1
          )
    
    ){

      let requestPetitionerSign = _.find(workFlowDetails.config ,{'code':'ASSIGN_DOCUMENTATION_EXECUTIVE'});
     let  doceUserListConf = _.find(workFlowDetails.config ,{'code':'DOCUMENTATION_EXECUTIVE_LIST'});
      if(
        this.checkProperty(requestPetitionerSign ,'actionRequired') =="Yes"
        && (_.find(doceUserListConf['editors'] ,{"roleId":this.getUserRoleId})) 
      ){
        returnVal =true;

      }
      

    }
    return returnVal;

  },
  checkisDoceActivityCompleted(){
    let returnVal =false;
   let getWorkFlowDetails =   this.getWorkFlowDetails
    if(
      (this.checkAdminLoginroles)
     && ( this.getPetitionDetails && getWorkFlowDetails)
     && ( _.has(this.getPetitionDetails ,'completedActivities') && this.getPetitionDetails.completedActivities.indexOf('ASSIGN_DOCUMENTATION_EXECUTIVE')>-1  )

    ){
      returnVal =true;

    }

    return returnVal;

  },

  checkrequestSigninActivityCompleted(){
    let returnVal =false;
   let getWorkFlowDetails =   this.getWorkFlowDetails
    if(
      
     ( this.getPetitionDetails && getWorkFlowDetails)
     && ( _.has(this.getPetitionDetails ,'completedActivities') && this.getPetitionDetails.completedActivities.indexOf('REQUEST_PETITIONER_SIGN')>-1  )

    ){
      
      returnVal =true;

    }

    return returnVal;

  },

  checkFilingFeeActivityCompleted(){
    let returnVal =false;
   let getWorkFlowDetails =   this.getWorkFlowDetails
    if(
      
     ( this.getPetitionDetails && getWorkFlowDetails)
     && ( _.has(this.getPetitionDetails ,'completedActivities') && this.getPetitionDetails.completedActivities.indexOf('FILING_FEE')>-1  )

    ){
      
      returnVal =true;

    }

    return returnVal;

  },

  checkSubtoLawFirmActivityCompleted(){
    let returnVal =false;
   let getWorkFlowDetails =   this.getWorkFlowDetails
    if(
      
     ( this.getPetitionDetails && getWorkFlowDetails)
     && ( _.has(this.getPetitionDetails ,'completedActivities') && this.getPetitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM')>-1  )

    ){
      
      returnVal =true;

    }

    return returnVal;

  }

  


    
    
  },
  mounted(){
   
    const $ = JQuery;
    $('form').on( 'focus', ':input', function(){
       $(this).attr( 'autocomplete', 'off' );
       $(this).attr( 'autocorrect', 'off' );
       
      
   });
   $('form').on( 'click', ':input', function(){
     $(this).attr( 'autocomplete', 'off' );
      $(this).attr( 'autocorrect', 'off' );
     
 });
 window.addEventListener('scroll', function(e) {
 
 });

    //this.setToken();

      this.setFavIcon()

  },
  watch: {
    $route(to, from) {
     
      let tempLoginUrls = ['fill-questionnaire' ,"filled-case-details","fill-perm-questionnaire" ,'filled-perm-case-details'];
      let fromName =from['name'];
      let toName =to['name'];
      this.setToken();
    }
  }
 
})
