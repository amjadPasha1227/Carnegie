import Vue from 'vue'
import Vuex from 'vuex'

import state from "./state"
import getters from "./getters"
import mutations from "./mutations"
import actions from "./actions"


import mobulePetitioner from './petitioner/mobulePetitioner.js'
import common from './common/store.js'
import subscription from '@/store/subscription'

Vue.use(Vuex)


export default new Vuex.Store({
    getters,
    mutations,
    state,
    actions,
    modules: {
      common:common,
      petitioner: mobulePetitioner,
      subscription:subscription,
  },
    strict: process.env.NODE_ENV !== 'production'
})
