

const getters = {
  isLoggedIn: state => !!state.token,
  authStatus: state => state.status,
  getuser: state => state.user,
  getuserRole: state => state.userRole,
  isdefaultWorkflowComplted: state => state.defaultWorkflowComplted,
  isTenantProfileCompleted: state => state.tenantProfileCompleted,
  getTenantCheckListStatus: state => state.tenantCheckListCpmpleted,
  gettenantCheckListNotCompletedTxt: state=>state.tenantCheckListNotCompletedTxt,
  getPetitionerProfileCompaltion: state => state.petitionerProfileCompleted,
  getCompanyDetails: state => state.companyDatails,
  getselectedPetitionTab: state=> state.selectedPetitionTab,
  getloginUserData:(state)=>{

   return {token:state.loginToken, user:state.loginUserData, userrole:state.loginuserRole , tenantId:state.logintenantId}

  }
 
	}

export default getters