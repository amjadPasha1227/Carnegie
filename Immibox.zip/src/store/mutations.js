/*=========================================================================================
  File Name: mutations.js
  Description: Vuex Store - mutations
  ----------------------------------------------------------------------------------------
  Item Name: Vuesax Admin - VueJS Dashboard Admin Template
  Author: Pixinvent
  Author URL: http://www.themeforest.net/user/pixinvent
==========================================================================================*/

import _ from "lodash";
const mutations = {

    updateManageCapRegistrations(state,manageCapRegistrations){
        
        state.manageCapRegistrations =manageCapRegistrations?true:false
    },
   
    updateDropBoxRedirectUrl(state ,data){
        localStorage.setItem('dropBoxRedirectUrlData' ,JSON.stringify(data))
        state.dropBoxRedirectUrlData =data
    },
    

    setDashBoardWIdgetsListOrChart(state ,data){
        //{ wedgetId="",viewType="LIST" }
        if(_.get(data ,'wedgetId') && _.get(data ,'viewType') ){
            let wedgetItems = _.cloneDeep(state['dashBoardWIdgetsListOrChart']);
            let fobj = _.find(wedgetItems ,{'wedgetId':data['wedgetId']});
           
            
            if(fobj){
                state['dashBoardWIdgetsListOrChart'] =[];
                _.forEach( wedgetItems, (wedgetItem)=>{
                    if(wedgetItem['wedgetId'] ==data['wedgetId']){
                      wedgetItem['viewType'] =data['viewType']
                    }
                    state['dashBoardWIdgetsListOrChart'].push(wedgetItem);

                });
                

            }else{
                

                state['dashBoardWIdgetsListOrChart'].push(data);
            }

        }

    },
    updatedNewLogo(state, val){

        if( val.type=='logo'){

            state.newLogoUploaded = val.url
        }
        else{
            state.newFaviconUploaded = val.url
        }
        
    },

    togleDashBoardRow(state ){
      
       
        if(state['editDashBoardRow']){
            state['editDashBoardRow'] =false;
        }else{
            state['editDashBoardRow'] =true;
        }
       

    },
    togleGlobalSearch(state ,action=false){
       
        state['globalSearchopen'] =action
        
       

    },
    isDraggeded(state, val = false){
        state['isDragged'] = val
    },
    updateExternalCases(state, val = false){

        state.user['globalConfig']['isAllowExternalCases'] = val;
        localStorage.setItem("user",JSON.stringify(state.user));
    },
      auth_request(state){
        state.status = 'loading'
      },

      tempauth_success(state, {token, user, userrole ,tenantId=''}){
        state.status = 'success'
        state.token = token
        state.user = user
        state.userRole = userrole
        state.tenantId = tenantId;
       // alert(JSON.stringify(state.user))  
                    
        
      },
      auth_success(state, {token, user, userrole ,tenantId=''}){
        state.status = 'success'
        state.token = token
        state.user = user
        state.userRole = userrole
        state.tenantId = tenantId;
        //alert(state.tenantId)

        state.loginToken = token
        state.loginUserData = user;
        state.loginuserRole = userrole
        state.logintenantId = tenantId;

        isProfilecompleted(state,user)
        localStorage.setItem('isProfilecompleted', state.profileCompleted)
        
      },
      auth_error(state){
        state.status = 'error'
      },
      logout(state){
        state.status = ''
        state.token = ''
      },

    // ////////////////////////////////////////////
    // SIDEBAR & UI UX
    // ////////////////////////////////////////////

    UPDATE_SIDEBAR_WIDTH(state, width) {
        state.sidebarWidth = width;
    },
    UPDATE_SIDEBAR_ITEMS_MIN(state, val) {
        state.sidebarItemsMin = val;
    },
    TOGGLE_REDUCE_BUTTON(state, val) {
        state.reduceButton = val;
    },
    TOGGLE_CONTENT_OVERLAY(state, val) {
        state.bodyOverlay = val;
    },
    TOGGLE_IS_SIDEBAR_ACTIVE(state, value) {
        state.isSidebarActive = value;
    },
    UPDATE_THEME(state, val) {
        state.theme = val;
    },
    UPDATE_WINDOW_BREAKPOINT(state, val) {
        state.breakpoint = val;
    },
    UPDATE_PRIMARY_COLOR(state, val) {
        state.themePrimaryColor = val;
    },
    UPDATE_WINDOW_WIDTH(state, width) {
      state.windowWidth = width;
    },
    tenantUpdatedOn(state, date) {
       // alert('tenantUpdatedOn');
        state.user["tenantDetails"]["profileUpdatedOn"] = date;
        localStorage.setItem("user",JSON.stringify(state.user));
    },
    petitionerUpdatedOn(state, date) {
       // alert('petitionerUpdatedOn');
        state.user["companyDetails"]["profileUpdatedOn"] = date;
        localStorage.setItem("user",JSON.stringify(state.user));
        localStorage.setItem("user",JSON.stringify(state.user));
    },
    updateCapCaseDetails(state, data){
        state.capRegisterDetails = data
    },
    updateManageRfeCase(state, data){
        state.manageRfeCase = data
    },
    updateReloadPetitionHistory(state, data){
        state.reloadPetitionHistory = data;
    },


    // ////////////////////////////////////////////
    // COMPONENT
    // ////////////////////////////////////////////

    // VxAutoSuggest
    UPDATE_STARRED_PAGE(state, payload) {
        // find item index in search list state
        const index = state.navbarSearchAndPinList.data.findIndex((item) => item.index == payload.index)
        // update the main list
        state.navbarSearchAndPinList.data[index].highlightAction = payload.val;

        // if val is true add it to starred else remove
        if(payload.val) {
            state.starredPages.push(state.navbarSearchAndPinList.data[index])
        }else {
            // find item index from starred pages
            const index = state.starredPages.findIndex((item) => item.index == payload.index)
            // remove item using index
            state.starredPages.splice(index, 1);
        }
    },

    // The Navbar
    ARRANGE_STARRED_PAGES_LIMITED(state, list) {
        const starredPagesMore = state.starredPages.slice(10);
        state.starredPages = list.concat(starredPagesMore);
    },
    ARRANGE_STARRED_PAGES_MORE(state, list) {
        let downToUp = false
        let lastItemInStarredLimited = state.starredPages[10];
        const starredPagesLimited = state.starredPages.slice(0, 10);
        state.starredPages = starredPagesLimited.concat(list);

        state.starredPages.slice(0,10).map((i) => {
            if(list.indexOf(i) > -1) downToUp = true
        })
        if(!downToUp) {
            state.starredPages.splice(10, 0, lastItemInStarredLimited);
        }
    },
    tenantProfiledataUpdate(state,data){
       
        if(data!=null){
            let userData= _.cloneDeep(state.user);
            if(_.has(userData ,"tenantDetails") && Object.keys(data).length>0){
                let tenantDetails =userData['tenantDetails']
                _.forEach(data,(val ,key)=>{
                    //alert(key+" -------  "+val);
                    let tempkey ={};
                    tempkey[key] =val;
                    tenantDetails =Object.assign(tenantDetails ,tempkey)
                    /*
                    if((key=="adminFirstName" && val) ){
                     userData = Object.assign(userData ,{'firstName':val})
                    }
                    if((key=="adminLastName" && val) ){
                        userData = Object.assign(userData ,{'lastName':val})
                    }
                    
                    if((key=="name" && val) ){
                         userData = Object.assign(userData ,{'name':val})
                    } 
                    */ 
                  
                  })
                 
                  userData = Object.assign(userData ,{"tenantDetails":tenantDetails})
                  state.user = userData;
                  state.loginUserData = userData;

                  localStorage.setItem("user",JSON.stringify(userData));
                  localStorage.setItem("loginUserData",JSON.stringify(userData));


            }


        }
    

    },
    updateProfilePic(state,profilePicture){
        let userData= state.user;
        if(profilePicture){
            userData = Object.assign(userData,{"profilePicture":profilePicture});
            state.user = userData;
            localStorage.setItem("user",JSON.stringify(userData));
        }
    },
    updateProfileData(state,data){
        if(data!=null){
            let userData= state.user;
            if( Object.keys(data).length>0){
               
                _.forEach(data,(val ,key)=>{
                    //alert(key+" -------  "+val);
                    let tempkey ={};
                    tempkey[key] =val;
                    //alert(JSON.stringify(tempkey));
                    userData =Object.assign(userData ,tempkey)
                  
                  })
                
                  state.user = userData
                  state.loginUserData = userData;
                  localStorage.setItem("user",JSON.stringify(userData));
                  localStorage.setItem("loginUserData",JSON.stringify(userData));
                }
            }

    },
    updateTenantChecklistStatus(state,result){
        state['tenantCheckListNotCompletedTxt'] =  '';
        if(_.has( result,"petitionSetupCompleted") && !result['petitionSetupCompleted']){
            state['tenantCheckListNotCompletedTxt'] += '\n Petition Setup InComplete; ';
        }
        if(_.has( result,"workflowSetupCompleted") && !result['workflowSetupCompleted']){
            state['tenantCheckListNotCompletedTxt'] += ' \n Workflow Setup InComplete; ';
        }
        if(_.has( result,"branchSetupCompleted") && !result['branchSetupCompleted']){
            state['tenantCheckListNotCompletedTxt'] += '\n Branch Setup InComplete; ';

        }

    },
    checkTenantProfileCompaltion(state,tenantDetails){
       
        if( ( _.has(state.user ,'roleId' ) && state.user.roleId ==3) && ( (_.has(tenantDetails ,'profCompleted')) && tenantDetails.profCompleted.toLowerCase().trim() !="yes")){
            
            state['tenantProfileCompleted'] = false;

        }else{
            state['tenantProfileCompleted'] = true;
            if( ( _.has(state.user ,'roleId' ) && state.user.roleId ==3) && ( (_.has(tenantDetails ,'defaultWorkflowComplted')) && tenantDetails.defaultWorkflowComplted)){
            
                state.defaultWorkflowComplted = true
    
            }
            
        }
    },
    editTenantDetails(state){
        
        if( ( ( _.has(state.user ,'roleId' ) && state.user.roleId ==3 ) )){
            
            state['tenantProfileCompleted'] = false;

        }

    },

    checkPetitionerProfileCompaltion(state,petitionerDetails){
        state.companyDatails = petitionerDetails;
        //if( petitionerDetails && ( ( _.has(state.user ,'roleId' ) && state.user.roleId ==12) && ( (_.has(petitionerDetails ,'registrationCompleted')) && petitionerDetails.registrationCompleted))){
         if( petitionerDetails && ( ( _.has(state.user ,'roleId' ) && state.user.roleId ==50) && ( (_.has(petitionerDetails ,'registrationCompleted') && petitionerDetails.registrationCompleted) || (_.has(petitionerDetails ,'companyRegistrationCompleted') && petitionerDetails.companyRegistrationCompleted)  ) )){
           
            state['petitionerProfileCompleted'] = true;
            let data = _.clone(state.user)
            data = Object.assign(data,{ 'petitionerProfileCompleted':true , "registrationCompleted":true ,"companyRegistrationCompleted":true})
            data['petitionerProfileCompleted'] =true;
            data['registrationCompleted'] =true;
            data['companyRegistrationCompleted'] =true;
            
            state.user = data
            state.loginUserData = data;
            localStorage.setItem("user",JSON.stringify(data));
            localStorage.setItem("loginUserData",JSON.stringify(data));
            
            

        }else{
            state['petitionerProfileCompleted'] = false;
           
        }
    },
    editCompanyDetails(state){
        
        if( ( ( _.has(state.user ,'roleId' ) && state.user.roleId ==50 ) )){
            
            state['petitionerProfileCompleted'] = false;

        }

    },
    /*
     petition:null,
    lcaDetails:null,
    workFlowDetails:null,
    */
    setPetitionData(state ,{petitionDetails=null ,lcaDetails=null,workFlowDetails=null}){
        state.petitionDetails = petitionDetails;
        state.lcaDetails = lcaDetails;
        state.workFlowDetails = workFlowDetails;

    },

    managePetitionActionBtn(state ,action=false){
        state.showPetitionActionBtn =action;
    },
    setPetitionTab(state , {tabName}){
        if(tabName){
         
          state.selectedPetitionTab =tabName
         
        
         
        }
        
      },
      toggleCaseStatusTab(state ,tab='showActivities'){
        state.toggleCaseStatusTab = tab;
       
      },
      selectedForEditDocument(state ,document){
       // alert(JSON.stringify(document))
      
          state.selectedForEditDocument = document
      },
    
}



function isProfilecompleted(state,userDetails){
    if (_.has(state.user, 'roleId') && state.user.roleId == 3) {
      if (_.has(userDetails.tenantDetails, 'profCompleted') && userDetails.tenantDetails.profCompleted.toLowerCase().trim() == "yes") {
        state.profileCompleted = true
      } else {
        state.profileCompleted = false
      }
  
  
      if (_.has(userDetails.tenantDetails, 'defaultWorkflowComplted') && userDetails.tenantDetails.defaultWorkflowComplted) {
        state.defaultWorkflowComplted = true
      } else {
        state.defaultWorkflowComplted = false
      }
  
      
    }
    if (_.has(state.user, 'roleId') && state.user.roleId == 50) {
        
      if ((_.has(userDetails, 'companyRegistrationCompleted') && userDetails.companyRegistrationCompleted)  || (_.has(userDetails ,'registrationCompleted') && userDetails.registrationCompleted)) {
        state.petitionerProfileCompleted =true;
       // state.profileCompleted = true
      } else {
        state.petitionerProfileCompleted = false;
      //  state.profileCompleted = false
      }
    }
  
  
  }


export default mutations
