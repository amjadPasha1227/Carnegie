import navbarSearchAndPinList from '@/layouts/components/navbarSearchAndPinList'
import themeConfig from '@/../themeConfig.js'
import colors from '@/../themeConfig.js'

const state = {
    manageCapRegistrations:false,
    dashBoardWIdgetsListOrChart:[
        {
            "wedgetId":"",
            "viewType":"LIST"
        }
    ],
        
    isDragged:false,
    globalSearchopen:false,
    editDashBoardRow:false,
    isSidebarActive: true,
    breakpoint: null,
    sidebarWidth: "default",
    reduceButton: themeConfig.sidebarCollapsed,
    bodyOverlay: false,
    sidebarItemsMin: false,
    theme: themeConfig.theme || 'light',
    navbarSearchAndPinList: navbarSearchAndPinList,
    AppActiveUser: {
        id: 0,
        name: 'John Doe',
        about: 'Dessert chocolate cake lemon drops jujubes. Biscuit cupcake ice cream bear claw brownie brownie marshmallow.',
        img: 'avatar-s-11.png',
        status: 'online',
    },
    status: '',
    token: localStorage.getItem('token') || '',
    user : JSON.parse(localStorage.getItem('user')) || [],
    themePrimaryColor: colors.primary,

    starredPages: navbarSearchAndPinList.data.filter((page) => page.highlightAction),
    userRole: localStorage.getItem('userRole') || '',


    loginToken: localStorage.getItem('loginToken') || '',
    loginUserData:JSON.parse(localStorage.getItem('loginUserData')) || {},
    loginuserRole: localStorage.getItem('loginuserRole') || '',
    logintenantId:localStorage.getItem('logintenantId') || '',

    // Can be used to get current window with
    // Note: Above breakpoint state is for internal use of sidebar component
    windowWidth: null,
    tenantProfileCompleted:true,
    tenantCheckListCpmpleted:true,
    tenantCheckListNotCompletedTxt:'',
    petitionerProfileCompleted:true,
    companyDatails:null, //this is for only petitioner role (12)
    petitionDetails:null,
    lcaDetails:null,
    workFlowDetails:null,
    showPetitionActionBtn:false,
    profileCompleted: null,
    defaultWorkflowComplted: null,
    selectedPetitionTab:localStorage.getItem('selectedPetitionTab') || 'Case Details',
    toggleCaseStatusTab:'showCaseStatus',
    selectedForEditDocument:null,
    newLogoUploaded:'',
    newFaviconUploaded:'',
    capRegisterDetails:null,
    dropBoxRedirectUrlData:localStorage.getItem('dropBoxRedirectUrlData')?JSON.parse(localStorage.getItem('dropBoxRedirectUrlData')):null,
    manageRfeCase:'',
    reloadPetitionHistory:false,
    
}

export default state
