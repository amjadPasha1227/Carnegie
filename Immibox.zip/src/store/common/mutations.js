
import _ from "lodash";

const mutations = {

  setTenantLogo(state, data) {
    state.tenantImagesData ={ logo:'', favicon:''};
    if(data && _.has(data , 'logo')){
      state.tenantImagesData['logo'] = data.logo;
    }
    if(data && _.has(data , 'favicon')){
      state.tenantImagesData['favicon'] = data.favicon;
    }
   
  },
 
  setTenantid(state, tenantId) {
    state.tenantId = tenantId
  },
  setTenantType(state, tenantId) {
    state.tenantType = tenantId
  },
  set_route(state, payLoad) {
    state.fromState = payLoad.from
    state.toState = payLoad.to
  },
  auth_success(state, {token, user, userrole ,tenantId=''}){
    state.status = 'success';
  
    if (token!=null) state.token = token
    state.user = user
    state.userRole = userrole
    state.tenantId = tenantId
    isProfilecompleted(state,user)
    localStorage.setItem('isProfilecompleted', state.profileCompleted)
  },
  setProfileCompleted(state, userDetails) {
    isProfilecompleted(state,userDetails)
  },
  setChecklistCompleted(state, tenantId) {
    state.tenantId = tenantId
  },
  activateSettingTab(state, tab) {
    state.activeSettingTab = tab;
    
  },
  setWallList(state ,list){
    let wall={  "page": 1,
              "perpage": 25,
              "totalCount": 0,
              "list":[]
            };

    let tempList = _.cloneDeep(list);
    /*
    if(_.has(list ,"list")){
     
      
      _.forEach(list.list,(item)=>{
        if(tempList['list'].length<=23){

        
        tempList['list'].push(item)
        
        }
        if(tempList['list'].length<=23){

        
          tempList['list'].push(item)
          
          }
        if(tempList['list'].length<=23){


          tempList['list'].push(item)
          
          }
          if(tempList['list'].length<=23){


            tempList['list'].push(item)
            
            }  

      })
     

      //alert(tempList['list'].length);
      
    }
    */
    state.wallList =list?list:wall;
  }
}


function isProfilecompleted(state,userDetails){
  if (_.has(state.user, 'roleId') && state.user.roleId == 3) {
    if (_.has(userDetails.tenantDetails, 'profCompleted') && userDetails.tenantDetails.profCompleted.toLowerCase().trim() == "yes") {
      state.profileCompleted = true
    } else {
      state.profileCompleted = false
    }


    if (_.has(userDetails.tenantDetails, 'defaultWorkflowComplted') && userDetails.tenantDetails.defaultWorkflowComplted) {
      state.defaultWorkflowComplted = true
    } else {
      state.defaultWorkflowComplted = false
    }

    
  }
  if (_.has(state.user, 'roleId') && state.user.roleId == 50) {
    if (_.has(userDetails, 'companyRegistrationCompleted') && userDetails.companyRegistrationCompleted) {
      state.profileCompleted = true
    } else {
      state.profileCompleted = false
    }
  }


}

export default mutations
