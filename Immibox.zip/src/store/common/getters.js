
const getters = {
  getTenantId: state => state.tenantId,
  getTenantType: state => state.tenantType,
  
  getPetitionerId: state => state.getPetitionerId,
  isdefaultWorkflowComplted: state => state.defaultWorkflowComplted,
  profileCompleted:state => state.profileCompleted,
  checlistCompleted:state => state.checlistCompleted,
  getTenantLogo: state => state.tenantImagesData,
  getActiveSettingTab: state => state.activeSettingTab,
  getWallList:state => state.wallList,
}

export default getters