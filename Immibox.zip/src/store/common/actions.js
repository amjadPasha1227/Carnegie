import axios from '@/axios.js';
import * as _ from "lodash";

import store from '@/store/store'

const actions = {
  
  login({ commit }, item) {
    return new Promise((resolve) => {
      axios.post("/auth/login", item)
        .then((response) => {
          const token = response.data.result.data.accessToken
          const userRole = response.data.result.data.loginRoleId;
          const user = response.data.result.data;
          localStorage.setItem('userRole', userRole)
          localStorage.setItem('token', token)
          localStorage.setItem('user', JSON.stringify(user))
          axios.defaults.headers.common['Authorization'] = token
          let tenantId = '';
          if(_.has(user ,'tenantId')){
            tenantId = user['tenantId'];
          }
                 

          commit('auth_success', {token:token, user:user, userrole:userRole , tenantId:tenantId})

          resolve(response)
        })
        .catch((error) => { 
          
          resolve(error.response.data.result) })
    })
  },
  getTenantdetails({ commit }, payLoad) {
    return new Promise((resolve) => {
      axios.post("/tenant/details-by-subdomain", payLoad)
        .then((response) => {
          let _r = response.data.result
          if (_r && _r._id) {
            commit("setTenantid", _r._id);
           
            
          }
          if (_r && _r.typeId) {
           
            commit("setTenantType", _r.typeId);
            
          }
          commit("setTenantLogo", _r);
          
          resolve(_r);

        })
        .catch((error) => {
          commit("setTenantLogo", null);
          commit("setTenantid", null);
          commit("setTenantType", null);
          resolve(error);
        })
    })
  },
  updateCommonstate({ commit }, payLoad) {
    commit('auth_success', payLoad)
  },
  setRoutes({ commit }, payLoad) {
    commit('set_route', payLoad)
  },
  authGaurdcb({ commit }, item) { 
    return new Promise((resolve) => {
      axios.post("/users/login-user-details", item)
        .then((response) => {
          
          const userRole = response.data.result.loginRoleId;
          const user = response.data.result;
          localStorage.setItem('userRole', userRole)
          localStorage.setItem('user', JSON.stringify(user))
        //  axios.defaults.headers.common['Authorization'] = token

      
       

          let tenantId = '';
          if(_.has(user ,'tenantId')){
            tenantId = user['tenantId'];
          }
          commit('auth_success', {token:null, user:user, userrole:userRole , tenantId:tenantId})
          resolve(response)
        })
        .catch((error) => { 
          
          resolve(error) })
    })
  },
  activateSettingTab({ commit }, tab='profile') {
    commit('activateSettingTab', tab)
  },
  getWallList({ commit }, payLoad) {
    return new Promise((resolve) => {
      axios.post("/walls/list", payLoad)
        .then((response) => {
          commit("setWallList", response.data.result);
          resolve(response.data.result.list)

        })
        .catch((error) => {
      let wall={  "page": 1,
              "perpage": 25,
              "totalCount": 0,
              "list":[]
            };
          commit("setWallList", wall);
           reject(error.response.data.result.error.message);
        })
    })
  },
}

export default actions
