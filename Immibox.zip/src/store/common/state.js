
const state = {
    tenantImagesData:{
        logo:'',
        favicon:''
    },
    tenantId: null,
    tenantType:null,
    getPetitionerId: null,
    profileCompleted: null,
    defaultWorkflowComplted: null,
    checlistCompleted: null,
    fromState:null,
    toState:null,
    activeSettingTab:'profile',
    wallList:{  "page": 1,
    "perpage": 25,
    "totalCount": 0,
    "list":[]
  },
  
}

export default state
