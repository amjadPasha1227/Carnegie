

const state = {
    show_loading:false,
    subscriptions:[],
    isCardExists:localStorage.getItem('isCardExists')?localStorage.getItem('isCardExists'):null,
    cardDetails:[],
    currentPlan:null,
}


export default state
