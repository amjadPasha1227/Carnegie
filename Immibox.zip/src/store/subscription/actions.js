import axios from 'axios'
import store from '../store'
import _ from 'lodash';




let domain = "https://anyclap.com/paymentsbeta/"; 
//let domain = "https://immibox.com/paymentsbeta/"; 

let  host = window.location.host;
host = host.toLowerCase();
  const parts = host.split('.');
 
//   if (parts.length > 0) {
//     if (['anyclap', '192.168.100.13:8080', 'localhost:8080', 'localhost:8081', '192', 'localhost:8083'].indexOf(parts[0].toLowerCase()) > -1
//     || (host.includes('anyclap.com'))
//     ) {
//         //domain = "https://anyclap.com/paymentsbeta/"; 
//     } 
// }
if (process.env.NODE_ENV == 'production') {
  domain = "/paymentsbeta/";
}
const instance = axios.create({
    baseURL: domain
    // You can add your headers here
})

instance.interceptors.request.use(function (config) {
    const token = store.state.token;
    if (token != null) {
        config.headers.Authorization = "Bearer 6H8Blp5yL/EJ2tBpfEK1EgGcWWo6zi1W75nEYQTcBoZvC/Aj";  //IMMIBOX
        //config.headers.Authorization = "Bearer uy5ekch3faoJidU/LEK1FACYWTA5xSNW687DM1fRB9psXPF8"; // anyclap

        if ( ['anyclap', '192.168.100.102:808', 'localhost:8080', 'localhost:8081', '192', 'localhost:8083'].indexOf(parts[0].toLowerCase()) > -1
         || (host.includes('anyclap.com'))
        ) {
          //  config.headers.Authorization = "Bearer uy5ekch3faoJidU/LEK1FACYWTA5xSNW687DM1fRB9psXPF8";
        }
        
    }
    return config;
}, function (err) {
    return Promise.reject(err);
});


const actions = {
    //masterdata/list
    getInvoiceList(){
        //invoices/list
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/invoices/list", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    }
    ,
    getMaterData({ commit }, payLoad) {
        
       //alert(JSON.stringify(payLoad))
        return new Promise((resolve, reject) => {
            instance.post("masterdata/list", payLoad)
                .then(res => {

                    resolve(res.data.result);
                })
                .catch(err => {
                    reject(err.response.data.result.error_message);
                })
        });

    },
    subscribe({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/plans/subscribe", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    upgradeplan({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/plans/upgrade", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    attachpaymentmethod({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/billing/attach-payment-method", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    chargeforplan({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/billing/charge-for-plan", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    getplans({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/plans/list-for-end-users", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    getplansList({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/plans/list", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    cardDetails({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/billing/get-payment-methods", data)
                .then((response) => {
                    commit("loading", false);
                    commit("setIsCardExists" ,response.data.result);
                    resolve(response.data.result);


                })
                .catch((error) => {
                    commit("loading", false);
                    data ={"list":[]}
                    commit("setIsCardExists" ,data)
                    reject(error);
                })
        })
    },
    getSelectedPlan({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/plans/get-selected-plan", data)
                .then((response) => {
                    commit("loading", false);
                    let data = _.orderBy(response.data.result, 'invoiceDetails', 'asc');
                    commit("UPDATE_SUBSCRIPTIONS",data)
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error);
                })
        })
    },
    cancelPlan({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/plans/cancel", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    getList({ commit }, { data, path = "/plans/testing" }) {

        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post(path, data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    
                    commit("loading", false);
                    reject(error.response.data.result.error_message);
                })
        })
    },

    createCupon({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/coupons/create", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })

    },

    validateCupon({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/coupons/validate", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);

                    reject(error.response.data.result.error_message.message);
                })
        })

    }


}

export default actions
