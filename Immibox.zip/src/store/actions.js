
import axios from '@/axios.js';
import { reject } from 'core-js/fn/promise';
import * as _ from "lodash";
import moment from 'moment'
import store from '@/store/store'

import state from './state'
let tenantId =''
if(_.has(state , "user")){
  if(_.has(state['user'] ,"tenantId")){

    tenantId = state['user']["tenantId"];
  }

}



const actions = {

  loginFromAccessToken({ commit }, item) {
    return new Promise((resolve ,reject) => {
      axios.post("/users/login-user-details", item)
        .then((response) => {
          
          const token = item['accessToken'];//response.data.result.data.accessToken
          const userRole = response.data.result.loginRoleId;
          const user = response.data.result;
          localStorage.setItem('userRole', userRole)
          localStorage.setItem('token', token)
          localStorage.setItem('user', JSON.stringify(user))


          localStorage.setItem('loginuserRole', userRole)
          localStorage.setItem('loginToken', token)
          localStorage.setItem('loginUserData', JSON.stringify(user))
          localStorage.setItem('logintenantId', '')
         

          axios.defaults.headers.common['Authorization'] = token
          let tenantId = '';
          if(_.has(user ,'tenantId')){
            tenantId = user['tenantId'];
          }
         
          if([3 ,4].indexOf(userRole)>-1 && _.has(user ,'tenantDetails')){
           
            let subscriber = {
              name: user.name,
              email: user.email,
              phone: "",
              phoneCode: ''
            }

            let tenantDetails = user['tenantDetails'];
            if(_.has(tenantDetails ,"adminName")){
              subscriber['name'] = tenantDetails["adminName"]
            }
            if(_.has(tenantDetails ,"adminEmail")){
              subscriber['email'] = tenantDetails["adminEmail"]
            }
            if(_.has(tenantDetails ,"phone")){
              subscriber['phone'] = tenantDetails["phone"]
            }

            if(_.has(tenantDetails ,"phoneCountryCode")){

              if(_.has(tenantDetails['phoneCountryCode'] ,"countryCallingCode")){
                  subscriber['phoneCode'] = tenantDetails['phoneCountryCode']['countryCallingCode']
              }
            }
             
              let payLoad = {
                 subscriber:subscriber,
                page: 1,
                perpage: 100,
                appActivity: true
              };
       
        store.dispatch("subscription/cardDetails", payLoad).then((cardResponse) => {

                const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
                let planPayLoad = {
                  selPlanIds: [],
                  plans: [],
                  source: null,
                  serviceTypeId: 1,
                  methodTypeId: 1,
                  newSource: true,
                  subscriber: subscriber,
                  today: moment(new Date()).format("YYYY-MM-DD"),
                  timezone: timezone, //moment(new Date()).tz.guess(),
                  browserTS: moment(new Date())
              };
              
              store.dispatch("subscription/getSelectedPlan", planPayLoad).then((currentPlan) => {
        
                if(_.has(currentPlan , 'length')){
                  if(currentPlan.length>0){
                    store.commit("subscription/updateCurrentPlan" ,currentPlan[0])
        
        
                  }
        
                }

                commit('auth_success', {token:token, user:user, userrole:userRole , tenantId:tenantId})
                resolve(response)
        
              }).catch((err) => {
                commit('auth_success', {token:token, user:user, userrole:userRole , tenantId:tenantId})
                resolve(response)
              })
          
        }).catch((err)=>{
          
          commit('auth_success', {token:token, user:user, userrole:userRole , tenantId:tenantId})
          resolve(response)


        })
       
          
          }else{
            commit('auth_success', {token:token, user:user, userrole:userRole , tenantId:tenantId})
            resolve(response)

          }
          
        })
        .catch((error) => { 
          
       
          reject(error.response.data.result) })
    })
  },
  
  login({ commit }, item) {
    return new Promise((resolve) => {
      axios.post("/auth/login", item)
        .then((response) => {
          const user = response.data.result.data;

      if((_.has(user, 'accounts') && user.accounts.length > 0) || _.has(user, 'companies') && user.companies.length > 0 ){
        resolve(response);
        return false;

      }

         
         
          const token = response.data.result.data.accessToken
          const userRole = response.data.result.data.loginRoleId;
         
          localStorage.setItem('userRole', userRole)
          localStorage.setItem('token', token)
          localStorage.setItem('user', JSON.stringify(user))


          localStorage.setItem('loginuserRole', userRole)
          localStorage.setItem('loginToken', token)
          localStorage.setItem('loginUserData', JSON.stringify(user))
          localStorage.setItem('logintenantId', '')

              localStorage.setItem('petProfilecompleted', 'true');
              localStorage.setItem('tenantProfilecompleted', 'true');
              if (_.has(user, 'roleId') && user.roleId == 3) {
                if (_.has(user.tenantDetails, 'profCompleted') && user.tenantDetails.profCompleted.toLowerCase().trim() == "yes") {
                  localStorage.setItem('tenantProfilecompleted', 'true');
                } else {
                  localStorage.setItem('tenantProfilecompleted', 'false');
                }
            
            
            
                
              }
              if (_.has(user, 'roleId') && user.roleId == 50) {
                  
                if ((_.has(user, 'companyRegistrationCompleted') && user.companyRegistrationCompleted)  || (_.has(user ,'registrationCompleted') && user.registrationCompleted)) {
                  localStorage.setItem('petProfilecompleted', 'true');
                } else {
                  localStorage.setItem('petProfilecompleted', 'false');
                }
              }
         

          axios.defaults.headers.common['Authorization'] = token
          let tenantId = '';
          if(_.has(user ,'tenantId')){
            tenantId = user['tenantId'];
          }
         
          if([3 ,4].indexOf(userRole)>-1 && _.has(user ,'tenantDetails')){
           
            let subscriber = {
              name: user.name,
              email: user.email,
              phone: "",
              phoneCode: ''
            }

            let tenantDetails = user['tenantDetails'];
            if(_.has(tenantDetails ,"adminName")){
              subscriber['name'] = tenantDetails["adminName"]
            }
            if(_.has(tenantDetails ,"adminEmail")){
              subscriber['email'] = tenantDetails["adminEmail"]
            }
            if(_.has(tenantDetails ,"phone")){
              subscriber['phone'] = tenantDetails["phone"]
            }

            if(_.has(tenantDetails ,"phoneCountryCode")){

              if(_.has(tenantDetails['phoneCountryCode'] ,"countryCallingCode")){
                  subscriber['phoneCode'] = tenantDetails['phoneCountryCode']['countryCallingCode']
              }
            }
             
              let payLoad = {
                 subscriber:subscriber,
                page: 1,
                perpage: 100,
                appActivity: true
              };
       
        store.dispatch("subscription/cardDetails", payLoad).then((cardResponse) => {

                const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
                let planPayLoad = {
                  selPlanIds: [],
                  plans: [],
                  source: null,
                  serviceTypeId: 1,
                  methodTypeId: 1,
                  newSource: true,
                  subscriber: subscriber,
                  today: moment(new Date()).format("YYYY-MM-DD"),
                  timezone: timezone, //moment(new Date()).tz.guess(),
                  browserTS: moment(new Date())
              };
              
              store.dispatch("subscription/getSelectedPlan", planPayLoad).then((currentPlan) => {
        
                if(_.has(currentPlan , 'length')){
                  if(currentPlan.length>0){
                    store.commit("subscription/updateCurrentPlan" ,currentPlan[0])
        
        
                  }
        
                }

                commit('auth_success', {token:token, user:user, userrole:userRole , tenantId:tenantId})
                resolve(response)
        
              }).catch((err) => {
                commit('auth_success', {token:token, user:user, userrole:userRole , tenantId:tenantId})
                resolve(response)
              })
          
        }).catch((err)=>{
          
          commit('auth_success', {token:token, user:user, userrole:userRole , tenantId:tenantId})
          resolve(response)


        })
       
          
          }else{
            commit('auth_success', {token:token, user:user, userrole:userRole , tenantId:tenantId})
            resolve(response)

          }
          
        })
        .catch((error) => { 
          
         // alert(error);
          resolve(error.response.data.result) })
    })
  },
  authGaurdcb({ commit }, item) {
    return new Promise((resolve) => {
      axios.post("/users/login-user-details", item)
        .then((response) => {
          
          const userRole = response.data.result.loginRoleId;
          const user = response.data.result;
          localStorage.setItem('userRole', userRole)
          localStorage.setItem('user', JSON.stringify(user))
        //  axios.defaults.headers.common['Authorization'] = token
          let tenantId = '';
          if(_.has(user ,'tenantId')){
            tenantId = user['tenantId'];
          }
          commit('auth_success', {token:null, user:user, userrole:userRole , tenantId:tenantId})

          resolve(response)
        })
        .catch((error) => { 
          
          resolve(error) })
    })
  },
  logout({commit}){
    return new Promise((resolve) => {
      commit('logout')
      localStorage.setItem('petProfilecompleted', 'true');
      localStorage.setItem('tenantProfilecompleted', 'true');
      localStorage.removeItem('token');
      localStorage.removeItem('userRole');
      localStorage.removeItem('user');
      localStorage.removeItem('LS_ROUTE_KEY');
      localStorage.removeItem('isCardExists');
      localStorage.removeItem('isProfilecompleted')

      localStorage.removeItem('loginToken');
      localStorage.removeItem('loginuserRole');
      localStorage.removeItem('loginUserData');
      localStorage.removeItem('logintenantId');

      //localStorage.setItem(LS_ROUTE_KEY, from.name);
      commit('auth_success', {token:'', user:{}, userrole:'' , tenantId:null})
      delete axios.defaults.headers.common['Authorization']
      store.commit("subscription/updateCurrentPlan" ,null)
      store.commit("subscription/setIsCardExists" ,null)
      
      resolve()
    })
  },
  getcountries(){
    return new Promise((resolve) => {
      let item ={
        page:1,
        perpage: 1000,
        category: "countries",
        //tenantId: "5db7d79d6032453bd060ed9c",
      };
      if(tenantId){
        item = Object.assign( item ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/list", item)
        .then((response) => {
          resolve(response.data.result.list)
        });
    })
  },
  getstates({commit},countryId){
    return new Promise((resolve) => {
      let item ={
        matcher: {
          countryId:countryId
        },
        page:1,
        perpage: 1000,
        category: "states",
        //tenantId: "5db7d79d6032453bd060ed9c",
      };

      if(tenantId){
        item = Object.assign( item ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/list", item)
        .then((response) => {
        //  commit('getcountries')
          resolve(response.data.result.list)
        });
    })
  },
  getvisatypes({commit}){
    return new Promise((resolve) => {
      let item ={
        matcher: {
        },
        page:1,
        perpage: 1000,
        category: "petition_types",
       // tenantId: "5db7d79d6032453bd060ed9c",
      };
      if(tenantId){
        item = Object.assign( item ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/list", item)
        .then((response) => {
          resolve(response.data.result.list)
        });
    })
  },
  getvisasubtypes({commit}){
    return new Promise((resolve) => {
      let item ={
        matcher: {
        },
        page:1,
        perpage: 1000,
        category: "petition_sub_types",
       // tenantId: "5db7d79d6032453bd060ed9c",
      };
      if(tenantId){
        item = Object.assign( item ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/list", item)
        .then((response) => {
          resolve(response.data.result.list)
        });
    })
  },
  getlocations({commit},obj){
    return new Promise((resolve) => {
      let item ={
        matcher: {
          stateId:obj.stateId
        },
        page:1,
        perpage: 1000,
        category: "locations",
        //tenantId: "5db7d79d6032453bd060ed9c",
      };
      if(tenantId){
        item = Object.assign( item ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/list", item)
        .then((response) => {
        //  commit('getlocations')
          resolve(response.data.result.list)
        });
    })
  },
  addLocations({commit},obj){
    return new Promise((resolve) => {
      let item ={
        page:1,
        perpage: 1000,
        stateId:obj.stateId,
        name:obj.name,
        category: "locations",
       // tenantId: "5db7d79d6032453bd060ed9c",
      };

      if(tenantId){
        item = Object.assign( item ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/add", item)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  getactivities(){
    return new Promise((resolve) => {
      let item ={
        page:1,
        perpage: 1000,
        category: "countries",
       // tenantId: "5db7d79d6032453bd060ed9c",
      };

      if(tenantId){
        item = Object.assign( item ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/list", item)
        .then((response) => {
          resolve(response.data.result.list)
        });
    })

  },
  getmasterdata({ commit }, type){
    return new Promise((resolve) => {
      let item ={
        page:1,
        perpage: 1000,
        category: type,
        //tenantId: "5db7d79d6032453bd060ed9c",
      };

      if(tenantId){
        item = Object.assign( item ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/list", item)
      .then((response) => {

        let list = response.data.result.list
        
        if( type == 'soc_codes' && list){
       

          list = _.map(list ,(item)=>{

            if(_.has(item, 'designation')){

              item['name'] = item['name'] + ' ('+item['designation']+')'

            }
            return item;
           

          });

        }


        resolve(list)
      });
    })
  },
  updatepassword({ commit }, postdata) {
    return new Promise((resolve) => {
      postdata.roleId = (postdata.roleId)? postdata.roleId : 7,
      axios.post("/auth/change-password", postdata)
        .then((response) => {
          resolve(response);

          var userItem = JSON.parse(localStorage.getItem('user'));
          userItem.passwordUpdated = true;
          localStorage.setItem('user',JSON.stringify(userItem))

        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  forgotpassword({ commit }, postdata) {
    return new Promise((resolve) => {
     // postdata.roleId = (postdata.roleId)? postdata.roleId : 7,
      axios.post("/auth/forgot-password", postdata)
        .then((response) => {
          resolve(response);

          var userItem = JSON.parse(localStorage.getItem('user'));
          userItem.passwordUpdated = true;
          localStorage.setItem('user',JSON.stringify(userItem))

        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  
  tenantInvite({ commit }, postdata) {
    return new Promise((resolve ,reject) => {
      //postdata.roleId = 7,
      axios.post("/tenant/invite", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          //alert(JSON.stringify(error.response))
          reject(error.response.data.result.error.message);

         

         })
    })
  },
  tenantregister({ commit }, postdata) {
    return new Promise((resolve ,reject) => {
      //postdata.roleId = 7,
      axios.post("/tenant/register", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
         
            //resolve(error.response.data.result);
            reject(error.response.data.result.error.message);

       
         })
    })
  },
  petitionerregister({ commit }, postdata) {
    return new Promise((resolve ,reject) => {
      //postdata.roleId = 7,
      axios.post("/auth/signup", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
         
          reject(error.response.data.result.error.message);

         })
    })
  },
  beneficiaryregister({ commit }, postdata) {
    return new Promise((resolve ,reject) => {
      postdata.roleId = 51,
      axios.post("/users/register", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          
         reject(error.response.data.message);

         })
    })
  },

  userregister({ commit }, postdata) {
   
    if(tenantId){
      postdata = Object.assign( postdata ,{"tenantId":tenantId})
    }
    return new Promise((resolve ,reject ) => {
      axios.post("/users/register", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  getpetition({ commit }, itemid) {
    return new Promise((resolve) => {
      var obj = {
        petitionId:itemid
      }
      axios.post("/petition/details", obj)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  setPetitionData({ commit },payLoad){
    return new Promise((resolve) => {
    commit('setPetitionData' ,payLoad );
    resolve();
    })
  },

  getrfepetition({ commit }, itemid) {
    return new Promise((resolve) => {
      var obj = {
        petitionId:itemid
      }
      axios.post("/rfe-petition/details", obj)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  getpermpetition({ commit }, itemid) {
    return new Promise((resolve) => {
      var obj = {
        petitionId:itemid
      }
      axios.post("/perm/details", obj)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  getgcpetition({ commit }, itemid) {
    return new Promise((resolve) => {
      var obj = {
        petitionId:itemid
      }
      axios.post("/gc-petition/details", obj)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  getGlobalnotifications({ commit } ,postData) {
    return new Promise((resolve) => {
      var obj = {
        "page": 1,
        "perpage": 99999
      }
      axios.post("/notify/list", postData)
        .then((response) => {
          resolve(response.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  
  rfepetitionhistory({ commit }, itemid) {
    return new Promise((resolve) => {
      
      var obj = {
        petitionId:itemid,
        "page": 1,
        "perpage": 25
      }
      axios.post("/rfe-petition/activity-list", obj)
        .then((response) => {
          resolve(response.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  gcpetitionhistory({ commit }, itemid) {
    return new Promise((resolve) => {
      
      var obj = {
        petitionId:itemid,
        "page": 1,
        "perpage": 25
      }
      axios.post("/gc-petition/activity-list", obj)
        .then((response) => {
          resolve(response.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  petitionhistory({ commit }, itemid) {
    return new Promise((resolve) => {
      
      var obj = {
        petitionId:itemid,
        "page": 1,
        "perpage": 25
      }
      axios.post("/petition/activity-list", obj)
        .then((response) => {
          resolve(response.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  savelcadetails({ commit }, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/lca/request", postdata)
        .then((response) => {
          
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            reject(error.response.data.result.error);

         }

         })
    })
  },
  fetchlcalist({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("/lca/list", postdata)
        .then((response) => {
          
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  
  getrfepetitionsdropdown({commit},bid) {
    return new Promise((resolve) => {
      var beneficiaryIds = [];
      beneficiaryIds.push(bid);
      var postdata = {
        matcher:{
          getMasterDataOnly:true,
          beneficiaryIds:beneficiaryIds,
        },
        "page": 1,
        "perpage": 100
      }
      axios.post("/rfe-petition/list", postdata)
        .then((response) => {
          
          resolve(response.data.result.list)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  /**
     * Get Company details
     * @param userId | String
     * @param isRfeCase | boolean
     */
  getpetitionsdropdown({commit},{userId ,isRfeCase=false}) {
 
    return new Promise((resolve) => {
      var beneficiaryIds = [];
      beneficiaryIds.push(userId);
      var postdata = {
        matcher:{
          rfeCases:isRfeCase,
          getMasterDataOnly:true,
          beneficiaryIds:beneficiaryIds,
        },
        "page": 1,
        "perpage": 100
      }
      axios.post("/petition/list", postdata)
        .then((response) => {
          
          resolve(response.data.result.list)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  fetchLcaDetails({commit}, itemid) {
    return new Promise((resolve) => {
      let obj = {
        lcaId:itemid
      }
      axios.post("/lca/details", obj)
        .then((response) => {
          
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },
  updateLcaDetails({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/lca/update", postdata)
        .then((response) => {
          
          resolve(response)
        })
        .catch((error) => {
         
            reject(error.response.data.result.error.message);
          
        })
    })
  },
  updateLcaStatus({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("/lca/update-status", postdata)
        .then((response) => {
          
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },
  uploadS3File({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("/s3/upload", postdata)
        .then((response) => {
          
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result.message);
          }
        })
    })
  },
  getSignedUrl({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("s3/get-signed-url", postdata)
        .then((response) => {
          
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },
  downloaddetailsaspdf({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("petition/download-details-as-pdf", postdata)
        .then((response) => {
          
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },
  
  downloaddocsbyorder({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("petition/generate-pdf", postdata)
        .then((response) => {
          
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },
  downloaddocsbyorderPerm({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("perm/generate-pdf", postdata)
        .then((response) => {
          
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },
  fetchLCAactivities({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("lca/activity-list", postdata)
        .then((response) => {
          
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },
  assigntoarole({commit},postdata) {
    return new Promise((resolve) => {
      axios.post("petition/assign-a-role", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  gcpassigntoarole({commit},postdata) {
    return new Promise((resolve) => {
      axios.post("gc-petition/assign-a-role", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  rfeassigntoarole({commit},postdata) {
    return new Promise((resolve) => {
      axios.post("rfe-petition/assign-a-role", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  managedocumentupload({commit},postdata) {
    //alert(JSON.stringify(postdata));
    return new Promise((resolve ,reject) => {
      axios.post("petition/manage-document-upload", postdata)
        .then((response) => {
          //alert(JSON.stringify(response));
          resolve(response.data.result)
        })
        .catch((error) => {
         
          //resolve(error.response.data.result);
          reject(error.response.data.result.error.message);
    
     
       })
    })
    
  },
  managegcediting({commit},postdata) {
    return new Promise((resolve) => {
      axios.post("gc-petition/manage-edit-option", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  generategcpdfs({commit},postdata) {
    return new Promise((resolve) => {
      axios.post("generate-pdf-form-document", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  getusersByrole({commit},roleId) {
    return new Promise((resolve) => {

      var roleIds = [];
      roleIds.push(roleId);

      var postdata = {
        "matcher":{
          roleIds:roleIds
        },
        page:1,
        perpage: 1000,

      }
      axios.post("users/list", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  uploadFormsAndLetters({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("petition/upload-forms-and-letters", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
         
          //resolve(error.response.data.result);
          reject(error.response.data.result.error.message);
    
     
       })
    })
  },
  uploadPermFormsAndLetters({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("perm/upload-forms-and-letters", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
         
          //resolve(error.response.data.result);
          reject(error.response.data.result.error.message);
    
     
       })
    })
  },

  uploadBenDocuments({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/petition/upload-beneficiary-docs", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
           
          reject(error.response.data.message);
    
     
       })
    })
  },

  approveBenDocuments({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/petition/accept-beneficiary-docs", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
           
          reject(error.response.data.message);
    
     
       })
    })
  },

  //updateDocumentVersion

  updateDocumentVersion({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("petition/update-forms-and-letters-version", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },

  downloadFormslatters({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      let path="/petition/download-forms-letters";
          path ="/filled-forms-and-letters/download";
      axios.post(path, postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error)=>{
          reject(error.response.data.result.error.message);
        });
        
    })
  },


  deleteFormAndLetter({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      let path ="petition/delete-forms-and-letters";
          path ="/filled-forms-and-letters/delete";
      axios.post(path, postdata)
        .then((response) => {
          resolve(response.data.result)
        }).catch((error)=>{
          reject(error.response.data.result.error.message);
        });
    })
  },
  uploadScannedCopies({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("petition/upload-scanned-copy", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error)=>{ 
          
          reject(error.response.data.result.error.message);
        })
    })
  },
  updateRfeReesponseDocs({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/petition/upload-rfe-response-docs", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error)=>{ 
          
          reject(error.response.data.result.error.message);
        })
    })
  },
  sendForRfeReesponseReview({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/petition/req-rfe-response-docs-approval", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error)=>{ 
          
          reject(error.response.data.result.error.message);
        })
    })
  },
  deleteScannedCopies({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/petition/delete-scanned-copy", postdata)
        .then((response) => {
          resolve(response.data.result)
        }).catch((error)=>{
          reject(error.response.data.result.error.message);
        });
    })
  },
  downloadScannedCopies({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/petition/download-scanned-copy", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error)=>{
          reject(error.response.data.result.error.message);
        });
        
    })
  },


/*

Company Documents
*/
uploadCompanyDocuments({commit}, postdata) {
  return new Promise((resolve ,reject) => {
    axios.post("/company/documents-save", postdata)
      .then((response) => {
        resolve(response.data.result)
      })
      .catch((error)=>{ 
        
        reject(error.response.data.result.error.message);
      })
  })
},
deleteCompanyDoc({commit}, postdata) {
  return new Promise((resolve ,reject) => {
    axios.post("/company/documents-delete", postdata)
      .then((response) => {
        resolve(response.data.result)
      }).catch((error)=>{
        reject(error.response.data.result.error.message);
      });
  })
},
downloadCompanyDoc({commit}, postdata) {
  return new Promise((resolve ,reject) => {
    axios.post("/petition/download-scanned-copy", postdata)
      .then((response) => {
        resolve(response.data.result)
      })
      .catch((error)=>{
        reject(error.response.data.result.error.message);
      });
      
  })
},
/* ---------------------------- */



  rfeuploadScannedCopies({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("rfe-petition/upload-scanned-copy", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  deleteScannedCopy({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("petition/delete-scanned-copy", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  updateTrackingDetails({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("petition/manage-tracking-details", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          
          if( _.has(error.response ,"data")){
            reject(error.response.data.message);
          }else{
            reject("Unable to update");
          } 
                   })
    })
  },
  rfeupdateTrackingDetails({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("rfe-petition/manage-tracking-details", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  getuserdetails({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("users/details", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  updateuserdetails({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("users/update-profile-picture", postdata)
        .then((response) => {
         commit("updateProfilePic", postdata.profilePicture)
          resolve(response.data.result)
          
        });
    })
  },
  //users/update
  updateProfile({commit}, postdata) {
    return new Promise((resolve, reject) => {
      axios.post("users/update", postdata)
        .then((response) => {
          
       		commit("updateProfileData", postdata)
          resolve(response.data.result)
        })
        .catch((error) => {
          
        if( _.has(error.response ,"data")){
          reject(error.response.data.message);
        }else{
          reject("Unable to update");
        } 
                 })
    })
  },
  // uploadS3File({ commit }, postdata) {
  //   return new Promise((resolve) => {
  //     commit("loading", true);
  //     axios.post("/s3/upload", postdata)
  //       .then((response) => {
  //         commit("loading", false);
  //         resolve(response)
  //       })
  //       .catch((error) => {
  //         commit("loading", false);
  //         if (error.response) {
  //           resolve(error.response.data.result);
  //         }
  //       })
  //   })
  // },
  updateProfilePicture({commit}, postdata){
    return new Promise((resolve) => {
      axios.post("users/update-profile-picture", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },

  getlatestpetition({commit},bid) {
    return new Promise((resolve) => {
      var beneficiaryIds = [];
      beneficiaryIds.push(bid);
      var postdata = {
        matcher:{
          beneficiaryIds:beneficiaryIds,
        },
        "page": 1,
        "perpage": 2
      }
      axios.post("/petition/list", postdata)
        .then((response) => {
          
          resolve(response.data.result.list)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  pushAuthCode({commit}, postdata) {
    return new Promise((resolve)=> {
      
      axios.post('/quickbook/auth', postdata)
      .then(response=> {
        resolve(response)
        
      })
    })
  },
  checkPetitionerAvailability({commit}, postdata) {
    return new Promise((resolve)=> {
      
      axios.post('/quickbook/customer-availability', postdata)
      .then(response=> {
        resolve(response)
        
      })
    })
  },

    // ////////////////////////////////////////////
    // SIDEBAR & UI UX
    // ////////////////////////////////////////////

    updateSidebarWidth({ commit }, width) {
      commit('UPDATE_SIDEBAR_WIDTH', width);
    },
    toggleContentOverlay({ commit }) {
      commit('TOGGLE_CONTENT_OVERLAY');
    },
    updateTheme({ commit }, val) {
      commit('UPDATE_THEME', val);
    },
    updateWindowWidth({ commit }, width) {
      commit('UPDATE_WINDOW_WIDTH', width);
    },


    // ////////////////////////////////////////////
    // COMPONENT
    // ////////////////////////////////////////////

    // VxAutoSuggest
    updateStarredPage({ commit }, payload) {
      commit('UPDATE_STARRED_PAGE', payload)
    },

    //  The Navbar
    arrangeStarredPagesLimited({ commit }, list) {
      commit('ARRANGE_STARRED_PAGES_LIMITED', list)
    },
    arrangeStarredPagesMore({ commit }, list) {
      commit('ARRANGE_STARRED_PAGES_MORE', list)
    },
    get_userstatusids(){
      return new Promise((resolve) => {
        let item ={
          page:1,
          perpage: 10000,
          category: "user_status",
         // tenantId: "5db7d79d6032453bd060ed9c",
        };
        if(tenantId){
          item = Object.assign( item ,{"tenantId":tenantId})
        }
        axios.post("/masterdata/list", item)
          .then((response) => {
            resolve(response.data.result.list)
          });
      });
  
    },
  get_statusids(){
    return new Promise((resolve) => {
      let item ={
        page:1,
        perpage: 10000,
        category: "company_status",
      //  tenantId: "5db7d79d6032453bd060ed9c",
      };
      if(tenantId){
        item = Object.assign( item ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/list", item)
        .then((response) => {
          resolve(response.data.result.list)
        });
    });

  },

  get_petition_statusids(){
    return new Promise((resolve) => {
      let item ={
        page:1,
        perpage: 10000,
        category: "petition_status",
       // tenantId: "5db7d79d6032453bd060ed9c",
      };
      if(tenantId){
        item = Object.assign( item ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/list", item)
        .then((response) => {
          resolve(response.data.result.list)
        });
    });

  },
  get_case_statusids({ commit }, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/masterdata/list", postdata)
        .then((response) => {
          
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            reject(error.response.data.result.error);

         }

         })
    })
  },

 
  get_dashboard_data(){

    return new Promise((resolve) => {
      const item ={ };
      axios.post("/dashboard", item)
          .then((response) => {
            resolve(response.data.result)
          });
    });

  },
  //notify/list
  get_recent_activitys(){

    return new Promise((resolve) => {
      const item ={"page":1, "perpage":15};
      axios.post("/notify/list", item)
          .then((response) => {
            resolve(response.data.result)
          });
    });

  },
  //my tasks
  get_my_tasks(){

    return new Promise((resolve) => {
      const item ={"page":1, "perpage":15};
      axios.post("todos/list", item)
          .then((response) => {
            resolve(response.data.result)
          });
    });

  },
  getmastedata({commit}){
    return new Promise((resolve) => {
      const item ={

        page:1,
        perpage: 1000,
        category: "user_roles",

      };
      axios.post("/masterdata/list", item)
        .then((response) => {
          resolve(response.data.result.list)
        });
    })
  },

  getusers({commit} ,postdata){
    return new Promise((resolve) => {
      axios.post("users/list", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  get_userstatusids(){
    return new Promise((resolve) => {
      let item ={
        page:1,
        perpage: 10000,
        category: "user_status",
       // tenantId: "5db7d79d6032453bd060ed9c",
      };
      if(tenantId){
        item = Object.assign( item ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/list", item)
        .then((response) => {
          resolve(response.data.result.list)
        });
    });

  },
 
  get_salary_frequencies({commit}){
    return new Promise((resolve) => {
      let item ={
        matcher: {
        },
        page:1,
        perpage: 1000,
        category: "salary_frequencies",
        //tenantId: "5db7d79d6032453bd060ed9c",
      };

      if(tenantId){
        item = Object.assign( item ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/list", item)
        .then((response) => {
          resolve(response.data.result.list)
        });
    })
  },
  //manage-approval-process
  manageApproval_process({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/petition/manage-approval-process", postdata)
          .then((response) => {

            resolve(response.data)
          })
          .catch((error) => {
            
          if( _.has(error.response ,"data")){
            reject(error.response.data.message);
          }else{
            reject("Unable to update");
          }

          })
    })
  },
  uploadUscisResponseDocs({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/petition/upload-uscis-docs", postdata)
          .then((response) => {

            resolve(response.data)
          })
          .catch((error) => {
            
          if( _.has(error.response ,"data")){
            reject(error.response.data.message);
          }else{
            reject("Unable to update");
          }

          })
    })
  },
 rfemanageApproval_process({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("/rfe-petition/manage-approval-process", postdata)
          .then((response) => {

            resolve(response.data)
          })
          .catch((error) => {
            if (error.response) {
              resolve(error.response);

            }

          })
    })
  },
  fileRFE({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("/rfe-petition/manage-rfe-notice", postdata)
          .then((response) => {

            resolve(response.data)
          })
          .catch((error) => {
            if (error.response) {
              resolve(error.response);

            }

          })
    })
  },
  getcommunicationbypetition({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("/communication/list", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  getcommunicationuserslist({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/communication/user-list", postdata)
        .then((response) => {
          
          resolve(response.data.result)
        }).catch((error)=>{
          reject(error.response.data.message);
        })
    })
  },
  submitcomment({commit}, postdata) {
    return new Promise((resolve , reject) => {
      axios.post("/communication/save", postdata)
        .then((response) => {
          
          resolve(response.data.result)
        })
        .catch((error)=>{
          reject(error.response.data.message);
        })
    })
  },
  submitFilingFeesOld({commit},postdata) {
    return new Promise((resolve) => {
      axios.post("petition/filing-fees", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  submitFilingFees({commit},postdata) {
    return new Promise((resolve ,reject) => {
      
      axios.post("invoices/create", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
         
          //resolve(error.response.data.result);updateFilingFees
          reject(error.response.data.result.error.message);
    
     
       })
    })
  },
 updateFilingFees({commit},postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("invoices/update", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
         
          //resolve(error.response.data.result);updateFilingFees
          reject(error.response.data.result.error.message);
    
     
       })
    })
    
  },
  filingFeeDetails({commit},postdata) {
    return new Promise((resolve,reject) => {
      axios.post("invoices/details", postdata)
        .then((response) => {
          resolve(response.data.result)
        })  .catch(error => {
          reject(error.response.data.message);
        })
    })
  },

  rfesubmitFilingFees({commit},postdata) {
    return new Promise((resolve) => {
      axios.post("rfepetition/filing-fees", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  requestforsign({commit},postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("petition/request-for-petitioner-sign", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
         
          //resolve(error.response.data.result);updateFilingFees
          reject(error.response.data.result.error.message);
    
     
       })
    })
  },
  rferequestforsign({commit},postdata) {
    return new Promise((resolve) => {
      axios.post("rfe-petition/request-for-petitioner-sign", postdata)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  getCourierList({commit}, postdata) {
    return new Promise((resolve) => {
      let item ={
        page:1,
        perpage: 1000,
        category: "carriers",
       // tenantId: "5db7d79d6032453bd060ed9c",
      };

      if(tenantId){
        item = Object.assign( item ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/list", item)
        .then((response) => {
          resolve(response.data.result.list)
        });
    })
  },

  submitRminder({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("reminders/save", postdata)
        .then((response) => {
          
          resolve(response.data.result)
        });
    })
  },

  submitRminderList({commit}, postdata) {
    
    return new Promise((resolve) => {
      axios.post("reminders/list", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },

  updateReminder({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("reminders/update", postdata)
        .then((response) => {
          
          resolve(response.data.result)
        });
    })
  },

  updateReminderStatus({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("reminders/update-status", postdata)
        .then((response) => {
          
          resolve(response.data.result)
        });
    })
  },


  

  updategetQuickBookConfig({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("quickbooks/save-config", postdata)
        .then((response) => {
          
          resolve(response.data.result)
        });
    })
  },

  //get-customers-list
  get_customers_list({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("quickbooks/get-customers-list", postdata)
        .then((response) => {
          
          resolve(response.data.result)
        });
    })
  },
  createQucikBooks({commit}, postdata) {
         
    return new Promise((resolve ,reject) => {
      axios.post("quickbooks/create-customer", postdata)
        .then((response) => {
          
          resolve(response.data.result)
        })
        .catch((err)=>{
          reject(err.response.data.message)
        });
    })
  },
  link_customers_qb({commit}, postdata) {
    return new Promise((resolve) => {
      axios.post("quickbooks/link-customer", postdata)
        .then((response) => {
          
          resolve(response.data.result)
        });
    })
  },
  getwiseLavel(){
    return new Promise((resolve) => {
      let postdata ={
        page:1,
        perpage: 1000,
        category: "wage_levels",
       
      };

      if(tenantId){
        postdata = Object.assign( postdata ,{"tenantId":tenantId})
      }
      axios.post("/masterdata/list", postdata)
        .then((response) => {
         // alert(response);
          resolve(response.data.result.list)
        });
    })
  },
  getstatsbyuser({commit}) {
    return new Promise((resolve) => {
      axios.post("petition/get-stats-by-user")
        .then((response) => {
          
          resolve(response.data.result)
        });
    })
  },
  //notify/remove
  removeNonification({ commit }, postdata) {
    return new Promise((resolve) => {
      postdata.roleId = (postdata.roleId)? postdata.roleId : 7,
      axios.post("/notify/remove", postdata)
        .then((response) => {
          resolve(response);

          

        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  generategcpdf({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/gc-petition/generate-pdf-form-document", postdata)
        .then((response) => {
          resolve(response);
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  getgcpdflist({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/gc-petition/pdf-form-version-list", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  savegcpdflist({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/gc-petition/save-pdf-form-version", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  }
  ,downloadgcforms({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/gc-petition/download-all-forms", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
         }
         })
    })
  },downloadallapplicantfiles({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/gc-petition/download-documents", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
         }
         })
    })
  },

  //support-tickets/create
  supportTicketsCreate({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/support-tickets/create", postdata)
        .then((response) => {
          
          resolve(response.data.result)
        })
        .catch((err)=>{
          
          reject(err.response.data.message)
        });
    })
  },
  supportTicketsUpdate({commit}, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/support-tickets/update", postdata)
        .then((response) => {
          
          resolve(response.data.result)
        })
        .catch((err)=>{
          reject(err.response.data.message)
        });
    })
  },
  //support-tickets/list
  supportTicketsList({ commit } ,postData) {
    return new Promise((resolve) => {
      axios.post("/support-tickets/list", postData)
        .then((response) => {
          resolve(response.data['result'])
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

         }

         })
    })
  },
  //support-tickets/assign
  supportTicketsAssign({ commit }, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/support-tickets/assign", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          if (error.response) {
            reject(error.response.data.result.error.message);
         }
         })
    })
  },
  //support-tickets/update
  supportTicketupdate({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/support-tickets/update", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
         }
         })
    })
  },
  //support-tickets/details
  supportTickesDetails({ commit }, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/support-tickets/details", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
         
          reject(error.response.data.result.error);
         })
    })
  },
//support-tickets/assign
supportTicketsComment({ commit }, postdata) {
  return new Promise((resolve ,reject) => {
    axios.post("/support-tickets/comment", postdata)
      .then((response) => {
        resolve(response.data.result)
      })
      .catch((error) => {
        if (error.response) {
          reject(error.response.data.result.error);
       }
       })
  })
},
supportTickeCommentList({ commit }, postdata) {
  return new Promise((resolve ,reject) => {
    axios.post("/support-tickets/comment-list", postdata)
      .then((response) => {
        resolve(response.data.result)
      })
      .catch((error) => {
        reject(error.response.data.result.error);
       })
  })
},


resend({ commit }, postdata) {
  return new Promise((resolve ,reject) => {
    //postdata.roleId = 7,
    axios.post("/users/resend-verify-link", postdata)
      .then((response) => {
        resolve(response)
      })
      .catch((error) => {
       
          reject(error.response.data.result.error.message);

    

       })
  })
},
uploadLocal({commit}, postdata) {
  return new Promise((resolve) => {
    axios.post("/common/local-upload", postdata)
      .then((response) => {
        
        resolve(response)
      })
      .catch((error) => {
        if (error.response) {
          resolve(error.response.data.result);
        }
      })
  })
},
getMasterData({commit},data){
  return new Promise((resolve ,reject) => {
    /*
    if(tenantId){
      data = Object.assign( data ,{"tenantId":tenantId})
    }
    */
   
   axios.post("/masterdata/list", data)
      .then((response) => {
        let res = response.data.result
          if( _.has(data,'category') &&  data['category'] == 'soc_codes' && _.has( res ,'list')){
            res['list'] = _.map(res['list'] ,(item)=>{
              if(_.has(item, 'designation')){
                item['name'] = item['name'] + ' ('+item['designation']+')';
              }
              return item
            });
          }
          resolve(res)
        //resolve(response.data.result)
      })
      .catch((error) => {
        reject(error.response.data.message);
      })
  });

},
createMasterNewRole({commit},data){
  return new Promise((resolve ,reject) => {
    if(tenantId){
      data = Object.assign( data ,{"tenantId":tenantId})
    }
   
    axios.post("/masterdata/add", data)
      .then((response) => {
        resolve(response.data.result)
      })
      .catch((error) => {
        reject(error.response.data.message);
      })
  });

},
updateMasetrRole({commit},data){
  return new Promise((resolve ,reject) => {
    if(tenantId){
      data = Object.assign( data ,{"tenantId":tenantId})
    }
   
    axios.post("/masterdata/update", data)
      .then((response) => {
        resolve(response.data.result)
      })
      .catch((error) => {
        
        reject(error.response.data.message);
       // reject(err.message);
      })
  });

},
resendemailActivationKey({commit} ,postdata){
  return new Promise((resolve ,reject) => {
    axios.post("/tenant/resend-activation-key", postdata)
      .then((response) => {
        resolve(response.data.result)
      })
      .catch((error)=>{
        if (error.response) {
          reject(error.response.data.message);
       }
        
      });
  })
},
verifyTenantEmail({commit} ,postdata){
  return new Promise((resolve ,reject) => {
    axios.post("/auth/verify-email", postdata)
      .then((response) => {
        //alert(JSON.stringify(response))
        resolve(response.data.result)
      })
      .catch((err)=>{
        
        reject(err.response.data.message);
      });
  })
},
changetenantStatus({commit}, postdata) {
  return new Promise((resolve ,reject) => {
    axios.post("/tenant/update-status", postdata)
      .then((response) => {

        resolve(response.data)
      })
      .catch((err) => {
        reject(err.response.data.message);

      })
  })
}, 
changeuserStatus({commit}, postdata) {
  return new Promise((resolve ,reject) => {
    axios.post("users/manage-status", postdata)
      .then((response) => {

        resolve(response.data)
      })
      .catch((error) => {
        //alert(JSON.stringify(error.response.data.message))
        reject(error.response.data);

      })
  })
},
deleteTenant({commit}, postdata) {
  return new Promise((resolve) => {
    axios.post("/tenant/delete", postdata)
      .then((response) => {

        resolve(response.data)
      })
      .catch((error) => {
        if (error.response) {
          resolve(error.response);

        }

      })
  })
},
createformandLetter({commit} ,postdata){
  return new Promise((resolve ,reject) => {
    axios.post("/form-letter/create", postdata)
      .then((response) => {
        resolve(response.data.result)
      })
      .catch((err) => {
        reject(err.response.data.message);
      })
  })

},
//updateformandLetter
updateformandLetter({commit} ,postdata){
  return new Promise((resolve ,reject) => {
    axios.post("/form-letter/update", postdata)
      .then((response) => {
        resolve(response.data.result)
      })
      .catch((err) => {
        reject(err.response.data.message);
      })
  })
},
formandLetterDetails({commit} ,postdata){
  return new Promise((resolve ,reject) => {
    axios.post("/form-letter/details", postdata)
      .then((response) => {
        resolve(response.data.result)
      })
      .catch((err) => {
        reject(err.response.data.message);
      })
  })
},
deleteformandLetter({commit}, postdata) {
  return new Promise((resolve ,reject) => {
    axios.post("/form-letter/delete", postdata)
      .then((response) => {

        resolve(response.data.result)
      })
      .catch((err) => {
        reject(err.response.data.message);
      })
  })
},


getList({commit}, {data ,path=""}) {
  return new Promise((resolve, reject) => {
      axios.post(path, data)
      .then((response) => {
          
          resolve(response.data.result)
      })
      .catch((error) => { 
         
        reject(error.response.data.result.error.message);

      })
  })
},

commonAction({commit}, {data ,path=""}) {
  return new Promise((resolve, reject) => {
      axios.post(path, data)
      .then((response) => {
          
        if(_.has(response ,'data.result')){
          resolve(response.data.result)
        }else if(_.has(response ,'data')){
          resolve(response.data)
        }else{
          resolve(response);
        }
      })
      .catch((error) => { 
      // alert(JSON.stringify(error.response.data.result));
       // alert(error.response.data.message);
        reject(error.response.data.message);

      })
  })
},
commonCaseAction({commit}, {data ,path=""}) {
  return new Promise((resolve, reject) => {
      axios.post(path, data)
      .then((response) => {
          
          resolve(response.data.result)
      })
      .catch((error) => { 
      // alert(JSON.stringify(error.response.data.result));
       // alert(error.response.data.message);
        reject(error.response.data);

      })
  })
},
commonActionWithErrorData({commit}, {data ,path=""}) {
  return new Promise((resolve, reject) => {
      axios.post(path, data)
      .then((response) => {
          if(_.has(response ,'data.result')){
            resolve(response.data.result)
          }else if(_.has(response ,'data')){
            resolve(response.data)
          }else{
            resolve(response);
          }
         
      })
      .catch((error) => { 
      // alert(JSON.stringify(error.response.data.result));
       // alert(error.response.data.message);
        reject(error.response.data['result']['error']);

      })
  })
},
bulkAssign({commit}, {data ,path=""}) {
  return new Promise((resolve, reject) => {
      axios.post(path, data)
      .then((response) => {
          
          resolve(response.data.result)
      })
      .catch((error) => { 
      // alert(JSON.stringify(error.response.data.result));
       // alert(error.response.data.message);
        reject(error.response.data['result']['error']);

      })
  })
},
caseConfigUpdateOrCreate({commit}, {data ,path=""}) {
  return new Promise((resolve, reject) => {
      axios.post(path, data)
      .then((response) => {
          
          resolve(response.data.result)
      })
      .catch((error) => { 
      // alert(JSON.stringify(error.response.data.result));
       // alert(error.response.data.message);
        reject(error.response.data.result.error);

      })
  })
},

updateWorkflow({commit}, {data ,path=""}) {
  return new Promise((resolve, reject) => {
      axios.post(path, data)
      .then((response) => {
          
          resolve(response.data.result)
      })
      .catch((error) => { 
       //alert(error.response.data.result.error.message);
        //reject(error.response.data.message);
        reject(error.response.data.result.error);

      })
  })
},

get_tenant_details({commit} ,postData) {
    
 
  return new Promise((resolve ,reject) => {
    
    axios.post("/tenant/details", postData)
      .then((response) => {
        commit("checkTenantProfileCompaltion" ,response['data']['result']);
        resolve(response['data']['result'])
      })
      .catch((error) => { 
        commit("checkTenantProfileCompaltion" ,{}); 
        reject(error.response.data.message);
    })
    
  })
},
getCompanyDetails({commit} ,postData) {
    
 
  return new Promise((resolve ,reject) => {
    
    axios.post("/company/details", postData)
      .then((response) => {
        commit("checkPetitionerProfileCompaltion" ,response['data']['result']);
        resolve(response['data']['result'])
      })
      .catch((error) => { 
        commit("checkPetitionerProfileCompaltion" ,null); 
        reject(error.response.data.message);
    })
    
  })
},
getChecklist({commit} ,postData){
  return new Promise((resolve ,reject) => {
    
    axios.post("/tenant/get-checklist", postData)
      .then((response) => {
        commit("updateTenantChecklistStatus" ,response['data']['result']);
        resolve(response['data']['result'])
      })
      .catch((error) => { 
        commit("updateTenantChecklistStatus" ,{}); 
        reject(error.response.data.message);
    })
    
  })

},
removeText({commit}){
  commit("updateTenantChecklistStatus" ,{}); 

},
setPetitionTab({commit}, tabName='Case Details'){
  return new Promise((resolve) => {
    localStorage.setItem('selectedPetitionTab', tabName);
    
    commit("setPetitionTab" ,{tabName:tabName}); 
    resolve();

  })

},
getActivityCodes({commit}){
  return new Promise((resolve) => {
    let codes = [
      {
         "code":"CREATE_PETITION",
         "name":"When a case is created, who will be notified?",
         "editors":[
            {
               "roleId":50,
               "roleName":"Petitioner"
            }
         ],
         "watchers":[
            {
               "roleId":51,
               "roleName":"Beneficiary"
            },
            {
               "roleId":4,
               "roleName":"Branch Manager"
            }
         ],
         "include":true,
         "actionRequired":true,
         "step":1,
         showMe:true,
         optional:false,
         showError:false
      },
      {
         "code":"SUBMIT_BY_BENEFICIARY",
         "name":"When case details are submitted by the Beneficiary, who will be notified?",
         "editors":[
            {
               "roleId":51,
               "roleName":"Beneficiary"
            }
         ],
         "watchers":[
            {
               "roleId":50,
               "roleName":"Petitioner"
            },
            {
               "roleId":4,
               "roleName":"Branch Manager"
            }
         ],
         "include":true,
         "actionRequired":true,
         "step":1,
         showMe:true,
         optional:false, showError:false
      },

      
      {
        "code":"SUBMIT_TO_LAW_FIRM",
        "name":"Who can submit the case to law firm?",
        "editors":[
           {
              "roleId":50,
              "roleName":"Petitioner"
           }
        ],
        "watchers":[
           {
              "roleId":51,
              "roleName":"Beneficiary"
           },
           {
              "roleId":4,
              "roleName":"Branch Manager"
           }
        ],
        "include":true,
        "actionRequired":true,
        "step":1,
        showMe:true,
        optional:false,
        showError:false
      },
     
      {
         "code":"LCA_REQUEST",
         "name":"Does LCA required to create/process the case?",
         "editors":[
            {
               "roleId":50,
               "roleName":"Petitioner"
            }
         ],
         "watchers":[
            {
               "roleId":4,
               "roleName":"Branch Manager"
            },
            {
               "roleId":6,
               "roleName":"Attorney"
            },
            {
               "roleId":11,
               "roleName":"LCA Manager"
            }
         ],
         "include":true,
         "actionRequired":true,
         "step":1,
         showMe:true,
         optional:true, showError:false
      },
      {
         "code":"LCA_SUBMIT",
         "name":"Who will be responsible for LCA process?",
         "editors":[
            {
               "roleId":11,
               "roleName":"LCA Manager"
            }
         ],
         "watchers":[
            {
               "roleId":4,
               "roleName":"Branch Manager"
            },
            {
               "roleId":6,
               "roleName":"Attorney"
            },
            {
               "roleId":8,
               "roleName":"paralegal"
            },
            {
               "roleId":50,
               "roleName":"Petitioner"
            }
         ],
         "include":true,
         "actionRequired":true,
         "step":1,
         showMe:true,
         optional:false, showError:false
      },
      { 

        
        "code":"MANAGER_LIST",
        "name":"Who will act as an Administrator of the case?",
        "editors":[
          {
            roleId: 3,
            roleName: "Admin",
          },
           {
            "roleId":4,
            "roleName":"Branch Manager"
          }
        ],
        "watchers":[
           
        ],
        "include":true,
        "actionRequired":true, // actionRequired always true
        "step":1,
        showMe:true,
        optional:false, showError:false
     },
      { 

        
        "code":"ASSIGN_SUPERVISOR",
        "name":" Who is the first receiver of the new case?",
        "editors":[
           {
              "roleId":5,
              "roleName":"Front Office User"
           }
        ],
        "watchers":[
           
        ],
        "include":true,
        "actionRequired":true, // actionRequired always true
        "step":1,
        showMe:true,
        optional:false, showError:false,
        "canAssignAllUsersVal": true,
        "canAssignAllUsers": "Yes"
     },
     {
      "code":"SUPERVISOR_LIST",
      "name":"Who will supervise the case process?",
      "editors":[
         {
            "roleId":7,
            "roleName":"Supervisor"
         }
      ],
      "watchers":[
         
      ],
      "include":true,
      "actionRequired":true,  //actionRequired always true
      "step":2, 
      showMe:true,
      optional:true, showError:false
   },
      {
         "code":"ASSIGN_PARALEGAL",
         "name":"ASSIGN_PARALEGAL",
         "editors":[
            {
               "roleId":7,
               "roleName":"Supervisor"
            }
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":true,
         "confirmRequiredVal":false,
         "confirmRequired":"No",
         "step":2,
         showMe:false,
         optional:true, showError:false
      },
      {
         "code":"PARALEGAL_LIST",
         "name":"Who will validate and finalize the case details and documents required?",
         "editors":[
            {
               "roleId":8,
               "roleName":"Paralegal"
            }
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":true,
         "confirmRequiredVal":false,
         "confirmRequired":"No",
         "step":2,
         showMe:true,
         optional:true, showError:false
      },
      
      {
         "code":"ASSIGN_DOCUMENTATION_MANAGER",
         "name":"ASSIGN_DOCUMENTATION_MANAGER",
         "editors":[
            {
               "roleId":8,
               "roleName":"paralegal"
            }
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":true,
         "confirmRequiredVal":false,
         "confirmRequired":"No",
         "step":2,
         showMe:false,
         optional:true, showError:false
      },
      {
         "code":"DOCUMENTATION_MANAGER_LIST",
         "name":"Who will supervise/prepare Documents, Forms and Letters?",
         "editors":[
            {
               "roleId":9,
               "roleName":"Documentation Manager"
            }
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":true,
         "confirmRequiredVal":false,
         "confirmRequired":"No",
         "step":2,
         showMe:true,
         optional:true, showError:false
      },
      {
         "code":"ASSIGN_DOCUMENTATION_EXECUTIVE",
         "parentCode":"REVIEW_BY_DOCUMENTATION_MANAGER",
         "name":"ASSIGN_DOCUMENTATION_EXECUTIVE",
         "editors":[
            {
               "roleId":9,
               "roleName":"Documentation Manager"
            }
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":true,
         "confirmRequiredVal":false,
         "confirmRequired":"No",
         "step":2,
         showMe:false,
         optional:true, showError:false
      },
      {
         "code":"DOCUMENTATION_EXECUTIVE_LIST",
         "name":"Who will be responsible for review and prepare Documents, Forms and Letters?",
         "editors":[
            {
               "roleId":10,
               "roleName":"Documentation Executive"
            }
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":true,
         "confirmRequiredVal":false,
         "confirmRequired":"No",
         "step":2,
         showMe:true,
         optional:true, showError:false
      },

     {
        "code":"ASSIGN_ATTORNEY",
        "name":"ASSIGN_ATTORNEY",
        "editors":[
           {
              "roleId":8,
              "roleName":"Paralegal"
           }
        ],
        "watchers":[
           
        ],
        "include":true,
        "actionRequired":true,
        "step":2,
        showMe:false,
        optional:false, showError:false
     },
     {
       "code": "ATTORNEY_LIST",
       "name": "Who will sign the case as an Attorney?",
       "editors": [{
         "roleId": 6,
         "roleName": "Attorney"
       }],
       "watchers": [],
       "include": "Yes",
       "actionRequired": "Yes",
       "step":2,
       showMe:true,
       optional:true, showError:false
     },
       {
      "code":"ASSIGN_CASE_APPROVER",
      "name":"Who will assign the case approver?",
      "editors":[
         {
            "roleId":6,
            "roleName":"Attorney"
         }
      ],
      "watchers":[
         
      ],
      "include":true,
      "actionRequired":true,
      "step":2,
      showMe:true,
      optional:true, showError:false
   },
      {
         "code":"CASE_APPROVED",
         "name":"Who will review and approve the case?",
         "editors":[
            {
               "roleId":6,
               "roleName":"Attorney"
            },
            {
               "roleId":8,
               "roleName":"Paralegal"
            }
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":true,
         "step":2,
         showMe:true,
         optional:true, showError:false
      },
      {
         "code":"FILING_FEE",
         "name":"Who can create the invoice?",
         "editors":[
            {
               "roleId":6,
               "roleName":"Attorney"
            },
            {
               "roleId":8,
               "roleName":"Paralegal"
            }
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":true,
         "step":3,
         showMe:true,
         optional:true, showError:false
      },
      {
         "code":"FILE_AFTER_INVOICE",
         "name":"File with USCIS only after generation of invoice",
         "editors":[
            
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":false,
         "step":3,
         showMe:true, optional:true, showError:false
      },
      {
         "code":"FILE_AFTER_INVOICE_PAYMENT",
         "name":"File with USCIS only after payment received",
         "editors":[
            
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":false,
         "step":3,
         showMe:true, optional:true, showError:false
      },
      {
         "code":"REQUEST_PETITIONER_SIGN",
         "name":"Who can request for signature(s) from the Petitioner?",
         "editors":[
            {
               "roleId":6,
               "roleName":"Attorney"
            }
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":true,
         "step":3,
         showMe:true,
         optional:false, showError:false
      },
      {
        "code":"DOC_SIGNER_LIST",
        "name":"Who will sign the documents?",
        "editors":[
           {
            "roleId":50, "roleName": "Petitioner"
           }
        ],
        "watchers":[
           
        ],
        "include":true,
        "actionRequired":true,  //actionRequired always true
        "step":3, 
        showMe:true,
        optional:false, showError:false
     },
     {
      "code":"SUPERVISOR_FORMS_REVIEW",
      "name":"Who will reaview documents before submission the case to USCIS?",
      "editors":[
        {"roleId": 7, "roleName": "Supervisor"}
      ],
      "watchers":[
         
      ],
      "include":true,
      "actionRequired":true,  //actionRequired always true
      "step":3, 
      showMe:true,
      optional:false,
      showError:false
   },
      {
         "code":"SUBMIT_TO_USCIS",
         "name":"Who is responsible for submission of case to USCIS?",
         "editors":[
            {
               "roleId":6,
               "roleName":"Attorney"
            },
            {
               "roleId":8,
               "roleName":"Paralegal"
            }
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":true,
         "step":3,
         showMe:true,
         optional:false, showError:false
      },
      {
         "code":"COURIER_TRACKING",
         "name":"Who can input Courier Tracking number?",
         "editors":[
            {
               "roleId":5,
               "roleName":"Front Office User"
            }
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":true,
         "step":3,
         showMe:true,
         optional:false, showError:false
      },
      
      {
        "code":"UPDATE_USCIS_RECEIPT_NUMBER",
        "name":"Who can input the USCIS Receipt Number?",
        "editors":[
           {
              "roleId":5,
              "roleName":"Front Office User"
           }
        ],
        "watchers":[
           
        ],
        "include":true,
        "actionRequired":true,
        "step":3,
        showMe:true,
        optional:false, showError:false
     },
      {
         "code":"UPDATE_USCIS_RESPONSE",
         "name":"Who can update the USCIS response?",
         "editors":[
            {
               "roleId":5,
               "roleName":"Front Office User"
            },
            {
               "roleId":8,
               "roleName":"Paralegal"
            }
         ],
         "watchers":[
            
         ],
         "include":true,
         "actionRequired":true,
         "step":3,
         showMe:true,
         optional:false, showError:false
      },
      {
        "code": "UPDATE_DOL_RESPONSE",
        "name": "Who will update DOL Response?",
        "editors": [
          {
            "roleId": 8,
            "roleName": "Paralegal"
          }
        ],
        "watchers": [],
        "include":true,
         "actionRequired":true,
         "step":3,
         showMe:true,
         optional:false, showError:false
      }
     ]
     let user = state.user;
     if(_.has( user,'tenantDetails')){
       if(_.has(user['tenantDetails'] ,"typeId") && user['tenantDetails']['typeId']  ==2){
         let defaultEditors =[
          {
            roleId: 3,
            roleName: "Admin",
          },
          {
            roleId: 4,
            roleName: "Branch Manager",
          }

         ];
         _.forEach(codes ,(item)=>{
           if(['CREATE_PETITION' ,"LCA_REQUEST"].indexOf(item['code'])>-1 ){

            item['editors'] =defaultEditors;
           }

         });

       }


     }

      resolve(codes)
   
})

},
managePetitionActionBtn({commit} ,postData){
  return new Promise((resolve) => {
    
    commit('managePetitionActionBtn' ,postData);
    resolve();
  });


},
updateTenantProfile({commit} ,postData){
  return new Promise((resolve ,reject) => {
    axios.post("/tenant/update", postData)
      .then((response) => {
        commit("tenantProfiledataUpdate" ,postData)
          resolve(response.data.result)
      })
      .catch((error) => { 
        //alert(JSON.stringify(error));
        if( _.has(error.response ,"data")){
          reject(error.response.data.message);
        }else{
          reject("Unable to update"+error);
        } 
        
      })

  });

},

editCompanyDetails({commit}){
  return new Promise((resolve ) => {
  commit('editCompanyDetails');
  resolve({});
  })
},
editTenantDetails({commit}){
  return new Promise((resolve ) => {
  commit('editTenantDetails');
  resolve({});
  })
},
completereview({commit} ,postData){
  return new Promise((resolve ,reject) => {
    axios.post("/petition/confirm-review-completed", postData)
      .then((response) => {
          resolve(response.data.result)
      })
      .catch((error) => { 
        if( _.has(error.response ,"data")){
          reject(error.response.data.message);
        }else{
          reject("Unable to update"+error);
        } 
        
      })

  });
},
completePermReview({commit} ,postData){
  return new Promise((resolve ,reject) => {
    axios.post("/perm/confirm-review-completed", postData)
      .then((response) => {
          resolve(response.data.result)
      })
      .catch((error) => { 
        if( _.has(error.response ,"data")){
          reject(error.response.data.message);
        }else{
          reject("Unable to update"+error);
        } 
        
      })

  });
},
 //dashboard/get-stats
 getStats({ commit }, payLoad) {
  return new Promise((resolve) => {
    axios.post("/dashboard/get-stats", payLoad)
      .then((response) => {
      
        resolve(response.data.result)

      })
      .catch((error) => {
          reject(error.response.data.result.error.message);
      })
  })
},
getWidgetFilterMasterData({ commit }, payLoad){
  let data=
   [

    //MESSAGES
    {
   
      "name": "Messages",
      "description": "You can track your messages here",
      "code": "MESSAGES",
      "sortName": "Updates",
      
      filters:{
          'caseType': null,
          "typeIds": [],
          "subTypeIds": [],
          "petitionerIds":[],
          "msgListType":"",
		     	"readList": [] , //[{name:"Read" ,id:true},{name:"Un-read" ,id:false}]
          "createdDateRange":[],
          "assignedToIds":[]
         
           
        },
      perpage:100,
      
      "sorting": {
        "path": "createdOn",
        "order": -1
      }
    },
    //CASE_SIGN_STATS
    {
   
      "name": "Updates",
      "description": "Summary of Pending Cases",
      "code": "CASE_SIGN_STATS",
      "sortName": "Updates",
      // "filters":{
        
      //   "createdDateRange":[],
      // },
      filters:{
          'caseType': { id: 'h1b',name: 'H-1B'},
          "typeIds": [],
          "subTypeIds": [],
          "petitionerIds":[], //Cases Clients
         
           
        },
      perpage:100,
      
      "sorting": {
        "path": "createdOn",
        "order": -1
      }
    },
    {
   
      "name": "Updates",
      "description": "You can track your updates here",
      "code": "UPDATES",
      "sortName": "Updates",
      // "filters":{
        
      //   "createdDateRange":[],
      // },
      filters:{
          "typeIds": [],
          "subTypeIds": [],
          "petitionerIds":[], //Cases Clients
          "beneficiaryIds":[] ,
          "branchIds":[],
          "userRoleType": "internal_user", // "petitioner", "beneficiary",

          "types": ["activity"], //updates For activity
          "entityTypeList": [],//"petition", "task"
          "branchIds":[],
           'assignedByIds':[],
           'assignedToIds':[],
           "watchingByIds":[],
           'createdByIds':[],
           "dueDateRange":[],
           "addToCalendarList":[],
           "createdDateRange":[],
           
        },
      perpage:100,
      
      "sorting": {
        "path": "createdOn",
        "order": -1
      }
    },
    {
   
      "name": "Actions",
      "description": "You can track your actions here",
      "code": "ACTION",
      "sortName": "actions",
      // "filters":{
        
      //   "createdDateRange":[],
      // },
      filters:{
        "TODO":{

          "typeIds": [],
          "subTypeIds": [],
          "petitionerIds":[], //Cases Clients
          "branchIds":[],

          "types": ["todo"], //updates For activity
          "entityTypeList": ["petition", "task"],//"petition", "task"
          "assignedByList": [],
          "assignedToList": [],
           "createdDateRange":[],
        },
        "CASES":{
          "typeIds": [],
          "subTypeIds": [],
          "petitionerIds":[], //Cases Clients
          "branchIds":[],

          "types": ["activity"], //updates For activity
          "entityTypeList": ['petition'],//"petition", "task"
          "assignedByList": [],
          "assignedToList": [],
           "createdDateRange":[],
        },
        'TASK':{
          "types": ["activity"], //updates For activity
          "entityTypeList": ['task'],//"petition", "task"
         
           "createdDateRange":[],
           "branchIds":[],
           'assignedByIds':[],
           'assignedToIds':[],
           "watchingByIds":[],
           'createdByIds':[],
           "dueDateRange":[],
           "addToCalendarList":[],
        },
        'UPDATES':{
          "typeIds": [],
          "subTypeIds": [],
          "petitionerIds":[], //Cases Clients
          "branchIds":[],

          "types": ["activity"], //updates For activity
          "entityTypeList": [],//"petition", "task"
          "branchIds":[],
           'assignedByIds':[],
           'assignedToIds':[],
           "watchingByIds":[],
           'createdByIds':[],
           "dueDateRange":[],
           "addToCalendarList":[],
           "createdDateRange":[],
        },

      },
      "pagination":{
        "TODO":{
          perpage:25
        },
        "CASES":{
          perpage:25
        },
        "TASK":{
          perpage:25
        },
        "TODO":{
          perpage:25
        },
        "UPDATES":{
          perpage:25
        }

      },
      tabSorting:{

        "TODO":{
        
        },
        "CASES":{
         
        },
        "TASK":{
        
        },
        "TODO":{
         
        },
        "UPDATES":{
         
        }

      },
      "sorting": {
        "path": "createdOn",
        "order": -1
      }
    },
    {
     
      "name": "Deadlines",
      "description": "You can track your deadlines here",
      "code": "DEADLINE",
      "sortName": "deadlines",
      /*
    "filters":{
    
      "typeIds":[], //cases
      "subTypeIds":[], //cases
      "premiumProcessing":[],
       premiumProcess:false,//cases (Check box)
      "petitionerIds":[], //Cases Clients
      "beneficiaryIds":[] ,//cases
      "deadlineDateRange":[] ,
      "createdDateRange":[],
   
       
    },
    */

    filters:{
      "TODO":{
        "typeIds": [],
        "subTypeIds": [],
        "petitionerIds":[], //Cases Clients
        "companyIds":[],
        "types": ["todo"], //updates For activity
        "entityTypeList": [],//"petition", "task"
        "branchIds":[],
           'assignedByIds':[],
           'assignedToIds':[],
           "watchingByIds":[],
           'createdByIds':[],
           "dueDateRange":[],
           "addToCalendarList":[],
           "createdDateRange":[],
      },
      "CASES":{
        "typeIds": [],
        "subTypeIds": [],
        "petitionerIds":[], //Cases Clients
        "companyIds":[],
        "branchIds":[],
        "types": [], //updates For activity
        "entityTypeList": [],//"petition", "task"
        
         "createdDateRange":[],
         "getMissingDeadlines":true,
         "deadlineDateRange":[],
         "dueDateRange":[],
         "premiumProcessing": [],
         "branchIds": [],
         premiumProcess:false,
      },
      'TASK':{
        "types": [], //updates For activity
        "entityTypeList": [],//"petition", "task"
        "branchIds":[],
        'assignedByIds':[],
        'assignedToIds':[],
        "watchingByIds":[],
        'createdByIds':[],
        
        "addToCalendarList":[],
       //  "createdDateRange":[],
         "getMissingDeadlines":true,
         "deadlineDateRange":[],
         "dueDateRange":[],
      },
      'UPDATES':{

        "typeIds": [],
        "subTypeIds": [],
        "petitionerIds":[], //Cases Clients
        "companyIds":[],


        "types": ["activity"], //updates For activity
        "entityTypeList": [],//"petition", "task"
        "branchIds":[],
           'assignedByIds':[],
           'assignedToIds':[],
           "watchingByIds":[],
           'createdByIds':[],
           "dueDateRange":[],
           "addToCalendarList":[],
         "createdDateRange":[],
      },


    },

    "pagination":{
      "TODO":{
        perpage:25
      },
      "CASES":{
        perpage:25
      },
      "TASK":{
        perpage:25
      },
      "TODO":{
        perpage:25
      },
      "UPDATES":{
        perpage:25
      }

    },

    "sorting": {
      "path": "createdOn",
      "order": -1
    },
    
    },
    
    {
     
      "name": "Cases by Status",
      "description": "You can track your cases by status here",
      "code": 'CASE_STATS_BY_STATUS',
      "sortName": "cases by status",
     "filters":{
      "rfeCases": false,
      "searchString":"",
      "petitionerIds": [],
      "beneficiaryIds": [],
      "statusIds": [],
      "statusList": [],
      "typeIds": [ {
        "_id": "64dcb9eab59fbb080f6b8e7b",
        "id": 1,
        "name": "H-1B",
        "selected": true
    }],
      "subTypeIds": [],
      "genders": [],
      "maritalStatusIds": [],
      "countryIds": [],
      "stateIds": [],
      "locationIds": [],
      "createdDateRange": [],
      "getMasterDataOnly": false, // Send true when needs master data only
      "lcaStatusIds": [],
      "invoiceStatusIds": [],
      "getMissingDeadlines": false, 
      "deadlineDateRange": [],
      "premiumProcessing": [],
      "branchIds": [],
      premiumProcess:false,
      },
    "sorting": {
      "path": "createdOn", //deadlineDays, updatedOn, createdByName, typeName, subTypeName, caseNo, statusName, clientName, beneficiaryName
      "order": 1
    },
    'sortingOrder':{'name':'ASC' ,'id':1},
    "sortingList":[
      
        {
          "id":  'createdOn' ,
           "name":"Created Date"
        },
        {
          "id":  'updatedOn' ,
           "name":"Updated Date"
        },
        {
        "id":  'deadlineDays' ,
         "name":"Deadline Days"
        },
      
     
      {
        "id":  'createdByName',
         "name":"Created ByName"
      },
      {
        "id":  'typeName' ,
         "name":"Case Type"
      },
      {
        "id":  'subTypeName' ,
         "name":"Case Subtype"
      },

      {
        "id":  'caseNo' ,
         "name":"Case Number"
      },
      {
        "id":  'statusName' ,
         "name":"Status Name"
      },
      {
        "id":  'beneficiaryName' ,
         "name":"Beneficiary Name"
      },
      {
        "id":  'clientName' ,
         "name":"Client Name"
      },

             
      
    ],
    },
    {
     
      "name": "Cases by Status",
      "description": "You can track your cases by status here",
      "code": "CASE_BY_STATUS",
      "sortName": "cases by status",
     "filters":{
      "rfeCases": false,
      "searchString":"",
      "petitionerIds": [],
      "beneficiaryIds": [],
      "statusIds": [],
      "statusList": [],
      "typeIds": [],
      "subTypeIds": [],
      "genders": [],
      "maritalStatusIds": [],
      "countryIds": [],
      "stateIds": [],
      "locationIds": [],
      "createdDateRange": [],
      "getMasterDataOnly": false, // Send true when needs master data only
      "lcaStatusIds": [],
      "invoiceStatusIds": [],
      "getMissingDeadlines": false, 
      "deadlineDateRange": [],
      "premiumProcessing": [],
      "branchIds": [],
      premiumProcess:false,
      },
    "sorting": {
      "path": "createdOn", //deadlineDays, updatedOn, createdByName, typeName, subTypeName, caseNo, statusName, clientName, beneficiaryName
      "order": 1
    },
    'sortingOrder':{'name':'ASC' ,'id':1},
    "sortingList":[
      
        {
          "id":  'createdOn' ,
           "name":"Created Date"
        },
        {
          "id":  'updatedOn' ,
           "name":"Updated Date"
        },
        {
        "id":  'deadlineDays' ,
         "name":"Deadline Days"
        },
      
     
      {
        "id":  'createdByName',
         "name":"Created ByName"
      },
      {
        "id":  'typeName' ,
         "name":"Case Type"
      },
      {
        "id":  'subTypeName' ,
         "name":"Case Subtype"
      },

      {
        "id":  'caseNo' ,
         "name":"Case Number"
      },
      {
        "id":  'statusName' ,
         "name":"Status Name"
      },
      {
        "id":  'beneficiaryName' ,
         "name":"Beneficiary Name"
      },
      {
        "id":  'clientName' ,
         "name":"Client Name"
      },

             
      
    ],
    },
    {
     
      "name": "Cases Stats by Branch",
      "description": "You can track your cases stats by branch here",
      "code": "CASE_STATS_BY_BRANCH",
      "sortName": "cases stats by branch",
      "filters":{
        "rfeCases": false,
        "searchString":"",
        'branchIds':[],
        "petitionerIds":[], //Cases Clients
        "companyIds":[],
        "beneficiaryIds": [],
        "statusIds": [],
        "statusList": [],
        "typeIds": [],
        "subTypeIds": [],
        "genders": [],
        "maritalStatusIds": [],
        "countryIds": [],
        "stateIds": [],
        "locationIds": [],
        "createdDateRange": [],
        "getMasterDataOnly": false, // Send true when needs master data only
        "lcaStatusIds": [],
        "invoiceStatusIds": [],
        "getMissingDeadlines": false, 
        "deadlineDateRange": [],
        "premiumProcessing": [],
        premiumProcess:false,
      },
      "sorting": {
        "path": "createdOn", //deadlineDays, updatedOn, createdByName, typeName, subTypeName, caseNo, statusName, clientName, beneficiaryName
        "order": 1
      },
     
      "sortingList":[
        {
          "id":  'createdOn' ,
           "name":"Created Date"
        },
        {
          "id":  'deadlineDays' ,
           "name":"Deadline Days"
        },
        {
          "id":  'updatedOn' ,
           "name":"Updated Date"
        },
       
        {
          "id":  'createdByName',
           "name":"Created ByName"
        },
        {
          "id":  'typeName' ,
           "name":"Case Type"
        },
        {
          "id":  'subTypeName' ,
           "name":"Case Subtype"
        },

        {
          "id":  'caseNo' ,
           "name":"Case Number"
        },
        {
          "id":  'statusName' ,
           "name":"Status Name"
        },
        {
          "id":  'beneficiaryName' ,
           "name":"Beneficiary Name"
        },
        {
          "id":  'clientName' ,
           "name":"Client Name"
        },

               
        
      ],
      'sortingOrder':{'name':'ASC' ,'id':1},
    },
    {
      
      "name": "Clients",
      "description": "You can track your clients here",
      "code": "CLIENT",
      "sortName": "clients",
       "filters":{ 
        "accountType": "Corporate", // Individual,
          "searchString": "",
          "clientTypeIds":[],
          "statusIds": [],
          "statusList": [],
          "countryIds": [],
          "stateIds": [],
          "locationIds": [],
          "createdDateRange": []

       },
       "sorting": {
        "path": "createdOn", //"createdOn", customIdSNo, invitedByName, createdByName, name, email, phone, statusName, updatedOn
        "order": -1
      },
      //"sortingList":["createdOn" ,'updatedOn','customIdSNo' ,'invitedByName' ,'createdByName' ,'name' ,'email' ,'phone' ,'statusName'],
      "sortingList":[
        {
          "id":  'createdOn' ,
           "name":"Created Date"
        },
        {
          "id":  'updatedOn' ,
           "name":"Updated Date"
        },
       
        {
          "id":  'createdByName',
           "name":"Created ByName"
        },
        {
          "id":  'invitedByName' ,
           "name":"Invited By Name"
        },
        {
          "id":  'name' ,
           "name":"name"
        },
  
        {
          "id":  'Email' ,
           "name":"email"
        },
        {
          "id":  'statusName' ,
           "name":"Status Name"
        },
        {
          "id":  'phone' ,
           "name":"Phone"
        },
              
        
      ],
      'sortingOrder':{'name':'ASC' ,'id':1},
    },
    {
     
      "name": "Beneficiaries",
      "description": "You can track your beneficiaries here",
      "code": "BENEFICIARY",
      "sortName": "beneficiaries",
       "filters": {
          "title": "",
          "statusList": [],
          "branchIds": [],
          "companyIds": [], // Required only for Tenant Admin and Branch Manager to list Beneficiaries
          "createdByIds": [],
          "createdDateRange": [],
          "roleIds": [],
          "statusIds": [],
          "petitionTypeIds": [],
          "petitionSubTypeIds": [],
          "petitionCreatedDateRange": [],
          "petitionStatusIds": [],
          "getPetitionStats": true,
           typeIds:[],
           subTypeIds:[],
           activeCases:true
        },
      "sorting": {
        "path": "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName
        "order": 1
      },
      "sortingList":[

        {"id":'createdOn'     ,"name":"Created Date"},
        {"id":'updatedOn'     ,"name":"Updated Date"},
        {"id":'invitedByName' ,"name":'Invited By Name'} ,
        {"id":'name' ,        "name":"Name"} ,
        {"id":'email' ,       "name":'Email'} ,
        {"id":'phone' ,       "name":'Phone'} ,
        {"id":'statusName' ,  "name":'Status'}
       ],
      'sortingOrder':{'name':'ASC' ,'id':1},
    },
    {
     
      "name": "LCAs",
      "description": "You can track your LCAs here",
      "code": "LCA",
      "sortName": "lcas",
       "filters": {
          "desiredSOCCodeIds":[],
          "internalEmployee": false, // true
          "searchString":"",
          "petitionerIds": [],
          "beneficiaryIds": [],
          "statusIds": [],
          "typeIds": [],
          "countryIds": [],
          "stateIds": [],
          "locationIds": [],
          "createdDateRange": []
      },
   
    "sorting": {
      "path": "createdOn", //updatedOn, createdByName, caseNo, statusName
      "order": 1
    },
    "sortingList":[
      {"id":'createdOn'     ,"name":"Created Date"},
      {"id":'updatedOn'     ,"name":"Updated Date"},
      {"id":'createdByName' ,"name":'Created By Name'} ,
      {"id":'caseNo' ,"name":'Case Number'} ,
      {"id":'statusName' ,  "name":'Status'}
   
    
    ],
    'sortingOrder':{'name':'ASC' ,'id':1},
    },
    {
     
      "name": "Invoices",
      "description": "You can track your actions here",
      "code": "INVOICE",
       "sortName": "invoices",
      "filters":{ 
       
        "title": "",
        "statusIds": [],
        "companyIds": [],
        "createdByIds": [],
        "createdDateRange": [],
        "branchIds": [],
        "dueDateRange": []
      },
      "sorting": {
        "path": "createdOn",
        "order": -1
      }
    },
    {
    
      "name": "Support Tickets",
      "description": "You can track your support tickets here",
      "code": "SUPPORT_TICKET",
      "sortName": "support tickets",
     "filters":{
      "createdDateRange": [],
      "title": "",
			"statusIds": [],
			"assignedToIds": [],
			"priorityIds": [],
			"createdByIds": [],
			"dateRange": [],
			"tenantIds": [],
			"typeIds": [],
      'pendingSince':0
     },
     "sorting": {
        "path": "createdOn", // "createdByName", // tenantName, statusName, priorityName, typeName, customIdSNo, subject, createdOn, updatedOn
        "order": -1
     },
     "sortingList":[
      {"id":'createdOn'     ,"name":"Created Date"},
      {"id":'updatedOn'     ,"name":"Updated Date"},
      {"id":'createdByName'     ,"name":"Created By Name"},
      {"id":'tenantName'     ,"name":"Customer Name"},
      {"id":'statusName' ,  "name":'Status'},
      {"id":'priorityName' ,  "name":'Priority'},
      {"id":'typeName' ,  "name":'Type'},
      {"id":'customIdSNo' ,  "name":'custom Number'},
      {"id":'subject' ,  "name":'Subject'},
      
    //  'createdOn' ,'updatedOn' ,'createdByName' ,'tenantName' ,'statusName','priorityName','typeName' ,'customIdSNo' ,'subject'
    ],
     'sortingOrder':{'name':'ASC' ,'id':1},
    },
    {
     
      "name": "Pending Cases Stats",
      "description": "You can track your pending case stats here",
      "code": "PENDING_CASE_STATS",
      "sortName": "pending cases stats",
      "filters":{
        "typeIds":[],
        "subTypeIds":[],
         'companyIds':[],
         "premiumProcessing": [],
         "branchIds": [],
         'assignedTo':[],  //(Client / Law Firm)
         "premiumProcess":false,
        "createdDateRange": [],
      },
      "sorting": {
        "path": "createdOn",
        "order": -1
      }
    },
    {
    
      "name": "Current Status of Cases",
      "description": "You can track your case stats here",
      "code": "CURRENT_STATUS_OF_CASE",
      "sortName": "current status of cases",
      "filters":{
        "typeIds":[{
          "_id": "64dcb9eab59fbb080f6b8e7b",
          "id": 1,
          "name": "H-1B",
          "selected": true
      }],
        "subTypeIds":[],
        "createdDateRange": [],
        "petitionerIds":[], //Cases Clients
        "petitionerIds":[], //Cases Clients
        "branchIds": [],
       
      },
      "sorting": {
        "path": "createdOn",
        "order": -1
      }
    },
    {
    
      "name": "Tasks",
      "description": "You can track your tasks here",
      "code": "TASK",
      "sortName": "tasks",
    "filters":{
    
      "title": "",
      "priorityIds": [],
      "statusIds": [],
      "addToCalendarList": [],
      "assignedToIds": [],
      "watchingByIds": [],
      "createdByIds": [],
      "createdDateRange": [],
      "dueDateRange": []
      
    },
    "sorting": {
      "path": "createdOn", //"createdOn", //customId, title, statusName, createdByName, updatedOn, priorityName
      "order": -1
    },
    "sortingList":[
      
      {"id":'createdOn'     ,"name":"Created Date"},
      {"id":'updatedOn'     ,"name":"Updated Date"},
      {"id":'customId' ,  "name":'custom Number'},
      {"id":'title' ,  "name":'Title'},
      {"id":'statusName' ,  "name":'Status'},
     {"id":'createdByName'     ,"name":"Created By Name"},
      {"id":'priorityName' ,  "name":'Priority'},
   
    ],
    'sortingOrder':{'name':'ASC' ,'id':1}, 
    }
  ]

  return new Promise((resolve) => {
    let filterData = data;
    if(payLoad['code']!='GET_ALL'){
       filterData= _.find(data ,{"code":payLoad['code']})
    }
 
    if(filterData){
      resolve(filterData)
    }else{
      resolve(null)
    }
      
  })
}

}

export default actions
