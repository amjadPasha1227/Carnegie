
import state from './modulePetitionerState.js'
import mutations from './modulePetitionerMutations.js'
import actions from './modulePetitionerActions.js'
import getters from './modulePetitionerGetters.js'

export default {
  isRegistered: false,
  namespaced: true,
  state: state,
  mutations: mutations,
  actions: actions,
  getters: getters
}
