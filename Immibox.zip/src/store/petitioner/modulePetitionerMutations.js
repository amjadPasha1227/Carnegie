
export default {
  auth_request(state){
    state.status = 'loading'
  },
  auth_success(state, {token, user, userrole ,tenantId=''}){
    state.status = 'success'
    state.token = token
    state.user = user
    state.userRole = userrole
    state.tenantId = tenantId;
    //alert(state.tenantId)
    
    
  },
  auth_error(state){
    state.status = 'error'
  },
  logout(state){
    state.status = ''
    state.token = ''
    state.user = {}
  },
  PETITIONER_SIGNUP(state, item) {
    state.petitionersignup = item;
  },
  PETITIONER_SIGNUP_ERROR(state, item) {
    state.petitionersignuperror = item;
  },
  USER_ACTIVATE(state, item) {
    state.petitioneractivate = item;
  }
}