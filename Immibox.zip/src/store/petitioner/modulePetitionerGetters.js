
export default {
  getToken: state => state.token,
  isLoggedIn: state => !!state.token
  // getItem: state => (productId) => state.products.find((product) => product.id == productId),
}
