
import axios from '@/axios.js';
import store from '../store'
import moment from 'moment'
import _ from "lodash";

export default {
  register({ commit }, item) {
    return new Promise((resolve) => {
      axios.post("/auth/signup", item)
        .then((response) => {
          commit('PETITIONER_SIGNUP', response.data.result);
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            commit('PETITIONER_SIGNUP_ERROR', error.response.data.result);
          }
          resolve(error.response.data.result);

        })
    })
  },
  invite({ commit }, item) {
    return new Promise((resolve) => {
      axios.post("/auth/invite-petitioner", item)
        .then((response) => {
          commit('PETITIONER_SIGNUP', response.data.result);
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            commit('PETITIONER_SIGNUP_ERROR', error.response.data.result);
          }
          resolve(error.response.data.result);

        })
    })
  },
  requestactivationEmail({ commit }, item) {
    return new Promise((resolve) => {
      axios.post("/auth/request-activation-email", item)
        .then((response) => {
          commit('PETITIONER_SIGNUP', response.data.result);
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            commit('PETITIONER_SIGNUP_ERROR', error.response.data.result);
          }
          resolve(error.response.data.result);

        })
    })
  },
  requestactivationKey({ commit }, item) {
    return new Promise((resolve) => {
      axios.post("/auth/request-activation-key", item)
        .then((response) => {
          commit('PETITIONER_SIGNUP', response.data.result);
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            commit('PETITIONER_SIGNUP_ERROR', error.response.data.result);
          }
          resolve(error.response.data.result);

        })
    })
  },
  activateaccount({ commit }, item) {
    return new Promise((resolve) => {
      axios.post("/users/activate", item)
        .then((response) => {
          commit('activate_account', item)
          resolve(response)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })
  },
  login({ commit }, item) {
    return new Promise((resolve) => {
      axios.post("/auth/login", item)
        .then((response) => {
          const token = response.data.result.data.accessToken
          const userRole = response.data.result.data.loginRoleId;
          const user = response.data.result.data;
          if(_.has(user ,'accounts') && user.accounts.length>0  ){
            resolve(response)
          }else{
         
            localStorage.setItem('userRole', userRole)
            localStorage.setItem('token', token)
            localStorage.setItem('user', JSON.stringify(user))
            axios.defaults.headers.common['Authorization'] = token
            let tenantId = '';
            if(_.has(user ,'tenantId')){
              tenantId = user['tenantId'];
            }
            commit('auth_success', {token:token, user:user, userrole:userRole , tenantId:tenantId})
            
            store.dispatch("common/updateCommonstate", {token:token, user:user, userrole:userRole , tenantId:tenantId})
            resolve(response)
        }
        })
        .catch((error) => { resolve(error.response.data.result) })
    })
  },

  checkCompanyApproval({ commit }, item) {
    
    return new Promise((resolve ,reject) => {
      axios.post("/auth/checkCompanyApproval", item)
        .then((res) => {
          let response  = res.data.result
          // const token = response.data.result.data.accessToken
          // const userRole = response.data.result.data.loginRoleId;
          // const user = response.data.result.data;
          // localStorage.setItem('userRole', userRole)
          // localStorage.setItem('token', token)
          // localStorage.setItem('user', JSON.stringify(user))
          // axios.defaults.headers.common['Authorization'] = token
          // commit('auth_success', token, user, userRole)
          //(user.loginRoleId && [6].indexOf(user.loginRoleId ) >= 0 &  user.registrationCompleted && user.companyId!=null && user.companyStatusId != 2 && to.path != "/waiting-for-approval")
          var user_data = store.getters.getuser;
          user_data.registrationCompleted = response['registrationCompleted']
          user_data.companyId = response['companyId']
          user_data.companyStatusId  = response['companyStatusId']
          let token = localStorage.getItem('token')
          let userRole =  localStorage.getItem('userRole')
          var userItem = JSON.parse(localStorage.getItem('user'));
          userItem.companyStatusId  = response['companyStatusId']
          localStorage.setItem('user', JSON.stringify(userItem))

         commit('auth_success', token, user_data, userRole );
         resolve(response)
        
         
          
        })
        .catch((error) => { reject(error.response.data.result) })
    })
  },

  forgot_password({ commit }, item) {
    return new Promise((resolve) => {
      axios.post("/auth/forgot-password", item)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => { resolve(error.response) })
    })
  },

  set_forgot_password({ commit }, item) {

    return new Promise((resolve) => {
      axios.post("/auth/update-password", item)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => { resolve(error.response) })
    })
  },
  completeregistration({ commit }, item) {
    return new Promise((resolve) => {
      item.completeRegistration = true;
      item.companyId = store.state.user.companyId;
      axios.post("/company/update", item)
        .then((response) => {
          var userItem = JSON.parse(localStorage.getItem('user'));
          userItem.registrationCompleted = true;
          userItem.statusId = true;
          localStorage.setItem('user', JSON.stringify(userItem))
          // commit('petitioner_reg_complete', userItem)

          resolve(response)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })
  },
  getpetitioners({ commit }, item) {
    return new Promise((resolve) => {
      var obj = {
        "matcher": {
          "searchString": item.search,
          "statusIds": item.statusIds,
          "countryIds": item.countryIds,
          "stateIds": item.stateIds,
          "locationIds": item.locationIds,
          "registeredDateRange": item.registeredDateRange


        },
        page: item.page,
        perpage: item.perpage,

      }
      if (item['sortKeys']) {
        obj['sortKeys'] = item['sortKeys'];

      }

      axios.post("/company/list", obj)
        .then((response) => {

          resolve(response.data.result)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })
  },
  getbeneficiaries({ commit }, item) {
    return new Promise((resolve) => {
      var users = [];
      //users.push(store.state.user._id);
     
      axios.post("/users/list", item)
        .then((response) => {

          resolve(response.data.result)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })
  },
  getpetitions({ }, item) {
    return new Promise((resolve) => {
      var obj = {
        "matcher": {
          "searchString": item.search,
        },
        page: 1,
        perpage: 25,
      }

      // if (store.state.user.loginRoleId == 7) {
      //   item.matcher.beneficiaryIds = [];
      //   item.matcher.beneficiaryIds.push(store.state.user._id);;
      // }


      axios.post("/petition/list", item)
        .then((response) => {

          resolve(response.data.result)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })
  },

  getrfepetitions({ }, item) {
    return new Promise((resolve) => {
      var obj = {
        "matcher": {
          "searchString": item.search,
        },
        page: 1,
        perpage: 25,
      }

      if (store.state.user.loginRoleId == 7) {
        item.matcher.beneficiaryIds = [];
        item.matcher.beneficiaryIds.push(store.state.user._id);;
      }


      axios.post("/rfe-petition/list", item)
        .then((response) => {

          resolve(response.data.result)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })
  },
  getpetetioner({ }, companyId) {
    
    return new Promise((resolve) => {
      axios.post("/company/details", companyId)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })
  },
  updatecompanystatus({ }, postdata) {
    return new Promise((resolve) => {
      axios.post("/company/update-status", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })
  },
  sendquestionnaire({ }, postdata) {
    return new Promise((resolve) => {
      axios.post("/petition/send-questionnaire", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })
  },
  petitionupdate({ }, postdata) {
    return new Promise((resolve ,reject) => {
      axios.post("/petition/update", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })
  },
  createnewpetition({ }, postdata) {
    return new Promise((resolve ,reject) => {
      var post = {
        type: postdata.type,
        userId: postdata.userId,
        userName: postdata.userName,
        typeName: postdata.typeName,
        subType: postdata.subType,
        subTypeName: postdata.subTypeName,
        petitionerId: postdata.petitionerId,
        today: moment().format('YYYY-MM-DD'),
        branchId:postdata.branchId
      };
      var _s = "petition"
      if(postdata.subType == 15){
        _s = "perm"
      }
      axios.post("/"+_s+"/create", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => { 
          reject(error.response.data);
        })
    })
  },

  entity_bulk_replace({ }, postdata) {
    return new Promise((resolve) => {
      axios.post("/petition/entity-bulk-replace", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })
  },
  getgcpetitions({ }, item) {
    return new Promise((resolve) => {
      var obj = {
        "matcher": {
          "searchString": item.search,
        },
        page: 1,
        perpage: 25,
      }

      if (store.state.user.loginRoleId == 7) {
        item.matcher.beneficiaryIds = [];
        item.matcher.beneficiaryIds.push(store.state.user._id);;
      }
      axios.post("/gc-petition/list", item)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })
  },
  createapplication({ }, postdata) {
    return new Promise((resolve) => {
      axios.post("/gc-petition/create", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })


  },
 deleteapplication({ }, postdata) {
    return new Promise((resolve) => {
      axios.post("/gc-petition/delete", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })


  },
 updateapplication({ }, postdata) {
    return new Promise((resolve) => {
      axios.post("/gc-petition/update", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => { resolve(error.response.data.result) })
    })


  }



}
