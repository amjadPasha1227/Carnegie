import Vue from 'vue'
import App from './App.vue'

// Vuesax Component Framework
import Vuesax from 'vuesax'
import 'vue-multiselect-inv/dist/vue-multiselect.min.css'
import 'material-icons/iconfont/material-icons.css' //Material Icons
import 'vuesax/dist/vuesax.css'; // Vuesax
Vue.use(Vuesax)  


import VModal from 'vue-js-modal/dist/ssr.nocss'
import 'vue-js-modal/dist/styles.css'
Vue.use(VModal ,{ dynamicDefault: { draggable: true, resizable: true } })



// Theme Configurations
import '../themeConfig.js'


// Globally Registered Components
import './globalComponents.js'


// Styles: SCSS
import './assets/scss/main.scss'


// Tailwind
import '@/assets/css/main.css';


// Vue Router
import router from './router'

//import Tawk from 'vue-tawk'

// Vuex Store
import store from './store/store'



import VueTour from 'vue-tour'
require('vue-tour/dist/vue-tour.css')
Vue.use(VueTour)


// Vuesax Admin Filters
import './filters/filters'

// Vuejs - Vue wrapper for hammerjs
import { VueHammer } from 'vue2-hammer'
Vue.use(VueHammer)
import "./vee-validate";


import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';

Vue.component('vue-phone-number-input', VuePhoneNumberInput);
import * as _ from "lodash";

// VeeValidate
import VeeValidate from 'vee-validate';
Vue.use(VeeValidate);

import { Validator } from 'vee-validate';

import PhoneNumber from 'awesome-phonenumber'
import EventBus from 'vue-e-bus'
Vue.use(EventBus);
var maxValue =''
const phoneNumber = {
  getMessage: field => `${field} is not a valid phone number`,
  validate (value) {
    return new Promise(resolve => {
      let phone = new PhoneNumber(value);
      resolve({ valid: phone.isValid() })
    })
  }
}
Validator.extend('phoneNumber', phoneNumber)

const phonevalid = {
  getMessage: field => `${field} is not a valid phone number`,
  validate (value) {
    return new Promise(resolve => {
      value=value.replace(/\(|\)/g, '').replace(/-/g,'');
      value="+1"+value;
      let phone = new PhoneNumber(value,'US');
      resolve({ valid: phone.isValid() })
    })
  }
}
Validator.extend('phonevalid', phonevalid)

Validator.extend("maxval", {
 
  validate(value, args) {
    maxValue =args[0]
    if(value<=parseInt(args[0])){
      return true;
    }else{
      return false;
    }
  },
  params: ['length'],
  getMessage: field => {
     if(maxValue !=''){
      return 'Field value must be less than or equal to '+maxValue
     }else{
      return "In"
     }
   
},
 // message: 'Max value {length} is required ddgfdgfdgfd'
});

Validator.extend("minval", {
 
  validate(value, args) {
    if(value>=parseInt(args[0])){
      return true;
    }else{
      return false;
    }
  },
  params: ['length'],
  message: 'Minimum value {length} is required'
});

Validator.extend('strongpassword', {
  getMessage: field => `The password must contain at least: 1 uppercase, 1 lowercase, 1 number, and one special character`,
  validate: value => {
      var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{6,})");
      return strongRegex.test(value);
  }
});



Validator.extend('docsValidate', {
  getMessage: field => `${field} is required`,
  validate:  (value) => {


    try{

      if(value){
        

        let activeDocs = _.filter( value, { "status":true} )
        if(activeDocs.length >0){
          return true

        }else{
          return false;
        } 
        
      }else{
        return false;
      }
          
    }catch(e){

      return false;
    }
   

    
   
 

  }
},{ hasTarget: true }); 



Validator.extend('checkConformCaseNum', {
  getMessage: field => `The Conform Case Number confirmation does not match`,
  validate:  (value, [other]) => {

    try{

      if(other.trim() && (value.trim() == other.trim()) ){
        return true
      }else{
        return false

      }
    


    }catch(err){
     return false
    }
 

   
  }
},{ hasTarget: true }); 


Validator.extend('zipcodev', {
  getMessage: field => `Zip Code not valid`,
  validate:  (value, [other]) => {
    try{
      value = value.trim();
//zipcodeLength
     let returnVal =false
    if(_.has(other, 'minZipcodeLength') && _.has(other, 'zipcodeLength')){
      returnVal = value.length >= other['minZipcodeLength'] &&  value.length <= other['zipcodeLength']
      
      

    }else if( _.has(other, 'minZipcodeLength')){
    
      returnVal = value.length == other['minZipcodeLength'];

    }else if( _.has(other, 'zipcodeLength')){
    
      returnVal= value.length == other['zipcodeLength'];

    } else if(other && _.has(other, 'id') && other.id == 231){

      returnVal = value.length == 5;

    }else if(other && _.has(other, 'id')  && other.id == 101){
      returnVal = value.length == 6;


    }else{
      returnVal = value.length == 6;
    }

    // if( _.get(other, 'allowNumAndCharInZipcode' ,'')==true){
      
    //   strongRegex = new RegExp("^[0-9a-zA-Z]*$");
    //   returnVal = strongRegex.test(value);
    //   alert("UK")
    // }else{
      
    //   strongRegex = new RegExp("^[0-9]*$");
    //   returnVal = strongRegex.test(value);
    //   alert(returnVal)
      
    // }
    return returnVal;



    }catch(err){
      return value.length == 6;
    }
 

return true
  }
},{ hasTarget: true }); 

Validator.extend('allowNumAndCharInZipcode', {
  getMessage: field => `Zip Code not valid`,
  validate:  (value, [other]) => {
    try{
      value = value.trim();
    if( _.has(other, 'allowNumAndCharInZipcode')){
      
      strongRegex = new RegExp("^[0-9a-zA-Z]*$");
      return strongRegex.test(value);

    }else{
      
      strongRegex = new RegExp("^[0-9]*$");
      return strongRegex.test(value);
      
    }
   return true

    }catch(err){
      return true;
    }
 

return true
  }
},{ hasTarget: true });
Validator.extend('passport', {
  getMessage: field => `Passport number not valid`,
  validate:  (value, [other]) => {
    var strongRegex = new RegExp("^[0-9]|([0-9]+[a-zA-Z]+|[a-zA-Z]+[0-9]+)[0-9a-zA-Z]*$");
    if(other && other.id == 231){
      strongRegex = new RegExp("^[0-9]|([0-9]+[a-zA-Z]+|[a-zA-Z]+[0-9]+)[0-9a-zA-Z]*$");
      return strongRegex.test(value);

    }
    if(other && other.id == 101){
      strongRegex = new RegExp("[^\w\d]*(([0-9]+.*[A-Za-z]+.*)|[A-Za-z]+.*([0-9]+.*))");
      return strongRegex.test(value);


    }

return true
  }
},{ hasTarget: true });

// PrismJS
import 'prismjs'
import 'prismjs/themes/prism-tomorrow.css'

//Multiselect
import Multiselect from 'vue-multiselect-inv'
Vue.component('multiselect', Multiselect)
import VCalendar from "v-calendar";

Vue.use(VCalendar);

import VueTheMask from 'vue-the-mask'
Vue.use(VueTheMask)

import money from 'v-money'
 
// register directive v-money and component <money>
Vue.use(money, {precision: 4})


// Feather font icon
require('./assets/css/iconfont.css')

import './mixins/mixins.js'
import globalgonfig from './config';

Vue.config.productionTip = false
Vue.prototype.$globalgonfig = globalgonfig

new Vue({
    router,
    store,
    render: h => h(App),
  mounted() {
    this.$validator.localize('en', {
      messages: {
        required: (field) => '*' + field + ' is required',
        date_format: (field, args) => `Date must be a valid format (MM/DD/YYYY)`
      },
    })
  }
}).$mount('#app')
