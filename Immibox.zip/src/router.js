import Vue from 'vue'
import Router from 'vue-router'
import store from './store/store'

Vue.use(Router)

const router = new Router({
  base: process.env.BASE_URL,
  scrollBehavior() {
    return { x: 0, y: 0 }
  },
  mode: 'history',
  routes: [

    {
      path: '',
      component: () => import('./layouts/main/Main.vue'),
      children: [
        {
          path: '/doc-upload',
          name: 'doc-upload',
          meta: {
            title: 'Files',
            requiresAuth: true,
           
          },
          component: () => import('./views/documents/uploadBlock.vue')
        },
        {
          path: '/dropbox-config',
          name: 'dropbox',
          meta: {
            title: 'Drop Box Config',
            requiresAuth: true,
           
          },
          component: () => import('./views/documents/dropBoxConfig.vue')
        },
        {
          path: '/ms',
          name: 'oneDrive',
          meta: {
            title: 'One Drive Config',
            requiresAuth: true,
           
          },
          component: () => import('./views/documents/dropBoxConfig.vue')
        },
        {
          path: '/test-page',
          name: 'test-page',
          meta: {
            title: 'Test test',
          },
          component: () => import('./views/test.vue')
        }, 
        {
          path: '/bulkassignment',
          name: 'Bulk Assign',
          meta: {
            title: 'Bulk Assign',
          },
          component: () => import('./views/BulkAssignment.vue')
        },
        {
          path: '/',
          redirect: '/dashboard',
          meta: {
            title: 'Dashboard',
          },
        },
        {
          path: '/dashboard',
          name: 'dashboard',
          meta: {
            title: 'Dashboard',
            requiresAuth: true,
            sideBar: "small"
          },
          //  component: () => import('./views/DashboardLatest.vue');
          component: () => import('./views/dashboard/Dashboard.vue')
        },
        {
          path: '/dashboard-v2',
          name: 'dashboard',
          meta: {
            title: 'Dashboard',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/dashboard/Dashboard.vue')
        },
        {
          path: '/email-templates',
          name: 'emailTemplates',
          meta: {
            title: 'Email Templates',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/emailTemplates.vue')
        },
        {
          path: '/bulk-emails',
          name: 'bulk-emails',
          meta: {
            title: 'Bulk Emails',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/bulkEmails.vue')
        },
        {
          path: '/perm',
          name: 'perm',
          meta: {
            title: 'PERM',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/permList.vue')
        },
        {
          path: '/default-user',
          name: 'default-user',
          meta: {
            title: 'Default-user',
            requiresAuth: false,

          },
          component: () => import('./views/defaultUserAssignment.vue')
        },
        {
          path: '/paf-generation',
          name: 'paf-generation',
          meta: {
            title: 'PAF-Generation',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/pafGeneration.vue')
        },
        {
          path: '/individuals',
          name: '/individuals',
          meta: {
            title: 'Individuals',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/individuals.vue')
        },
        {
          path: '/individuals-details', meta: {
            title: 'Individuals Details',
          },
          name: 'individuals-details',
          component: () => import('./views/IndividualsDetails.vue')
        },
        {
          path: '/individuals-details/:itemId', meta: {
            title: 'Individuals Details',
          },
          name: 'individuals-details',
          component: () => import('./views/IndividualsDetails.vue')
        },
        {
          path: '/deadlines',
          name: 'deadlines',
          meta: {
            title: 'Deadlines',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/calendar/caseCalendar.vue')
        },
        {
          path: '/dashboard-V2',
          name: 'dashboard',
          meta: {
            title: 'Dashboard',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/DashboardLatest.vue')
        },
        {
          path: '/quickbook-settings',
          name: 'quickbook-settings',
          meta: {
            title: 'Settings',
          },
          component: () => import('./views/QuickbookConfigration.vue')
        },


        {
          path: '/google-drive',
          name: 'google-drive',
          meta: {
            title: 'Users',
            requiresAuth: true
          },
          component: () => import('./googleDrive.vue')
        },

        {
          path: '/users',
          name: 'users',
          meta: {
            title: 'Users',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/Users.vue')
        },
        //Global search
        {
          path: '/globalsearch',
          name: 'globalsearch',
          meta: {
            title: 'global-search',
            requiresAuth: true
          },
          component: () => import('./views/globalSearchh.vue')
        },
        //user-roles

        {
          path: '/user-roles',
          name: 'user-roles',
          meta: {
            title: 'User Roles',
            requiresAuth: true
          },
          component: () => import('./views/usersRoles.vue')
        },
        {
          path: '/quickbooks/status',
          name: 'quickbook-status',
          meta: {
            title: 'Quickbook Status',
            requiresAuth: true
          },
          component: () => import('./views/settings/QuickbookConfigrationStatus.vue')
        },
        {
          path: '/profile',
          name: 'profile',
          meta: {
            title: 'My Profile',
            requiresAuth: true
          },
          component: () => import('./views/Profile.vue')
        },
        {
          path: '/h1b-questionnaire-template/:id',
          name: 'QuestionnaireTemplate',
          meta: {

            title: 'Questionnaire Template',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/Questionnaire/QuestionnaireTemplate.vue')
        },
        {
          path: '/h1b-questionnaire-template-details/:id',
          name: 'QuestionnaireTemplate',
          meta: {

            title: 'Questionnaire Template Details',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/Questionnaire/QuestionnaireTemplateView.vue')
        },
        {
          path: '/perm-questionnaire-template/:id',
          name: 'PERMQuestionnaireTemplate',
          meta: {

            title: 'PERM Questionnaire Template',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/Questionnaire/PermQuestionnaireTemplate.vue')
        },
        {
          path: '/perm-questionnaire-template-details/:id',
          name: 'PERMQuestionnaireTemplate',
          meta: {

            title: 'PERM Questionnaire Template Details',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/Questionnaire/PermQuestionnaireTemplateView.vue')
        },

        {
          path: '/mytasks',
          name: 'mytasks',
          meta: {
            title: 'My Tasks',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/Mytasks.vue')
        },
        {
          path: '/cap-registrations',
          name: 'cap-registrations',
          meta: {
            title: 'Cap Registrations',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/cap/capList.vue')
        }, 
        {
          path: '/external-cases',
          name: 'external-cases',
          meta: {
            title: 'External Cases',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/externalCases/casesList.vue')
        },
        {
          path: '/pwd-list',
          name: 'pwd-list',
          meta: {
            title: 'PWD Library',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/pwd/casesList.vue')
        },
        {
          path: '/pwd-case-details/:itemId',
          name: 'pwd-case-details',
          meta: {
            title: 'PWD Case Details',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/pwd/caseDetails.vue')
        },
        {
          path: '/external-case-details/:itemId',
          name: 'external-case-details',
          meta: {
            title: 'Cases Details',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/externalCases/caseDetails.vue')
        },
        {
          path: '/cap-reports',
          name: 'cap',
          meta: {
            title: 'Cap Registrations',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/cap/capReports.vue')
        },
        {
          path: '/case-list-reports',
          name: 'Case List',
          meta: {
            title: 'Case List',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/reports/caseReports.vue')
        },
        {
          path: '/over-due-reports',
          name: 'Overdue Cases',
          meta: {
            title: 'Overdue Cases',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/reports/caseReports.vue')
        },
        {
          path: '/branchwise-case-summary',
          name: 'Branchwise Case Summary',
          meta: {
            title: 'Branchwise Case Summary',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/reports/caseReports.vue')
        },
        {
          path: '/cases-by-customer',
          name: 'Cases by Customer',
          meta: {
            title: 'Cases by Customer',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/reports/caseReports.vue')
        },
        {
          path: '/corporate-customer-reports',
          name: 'corporate-customer-reports',
          meta: {
            title: 'Corporate Customer Reports',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/cap/customerReports.vue')
        },
        {
          path: '/individual-customer-reports',
          name: 'individual-customer-reports',
          meta: {
            title: 'Individual Customer Reports',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/cap/individualReports.vue')
        },
        // {
        //   path: '/cap-reports',
        //   name: 'cap',
        //   meta: {
        //     title: 'Cap Registrations',
        //     requiresAuth: false,
        //     sideBar: "small",
        //   },
        //   component: () => import('./views/cap/capList.vue')
        // },

        {
          path: '/cap-registration-details/:itemId',
          name: 'cap-details',
          meta: {
            title: 'Cap Registration Details',
            requiresAuth: true,
            sideBar: "small",
          },
          component: () => import('./views/cap/CapDetails.vue')
        },
        {
          path: '/cap-registration-questionnaire/:itemId',
          name: 'Cap questionnaire',
          meta: {
            sideBar: "small",
            requiresAuth: true,
            title: 'Cap Questionnaire',
          },
          component: () => import('./views/cap/Questionnaire.vue')
        },
        {
          path: '/notifications',
          name: 'notifications',
          meta: {
            title: 'Notification',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/Notifications.vue')
        },

        {
          path: '/customers',
          name: 'tenants',
          meta: {
            title: 'Customers',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/tenantsList.vue')
        },
        //editTenantDetails.vue

        {
          path: '/basic-settings',
          name: 'basic-settings',
          meta: {
            title: 'Company Details & Settings',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/common/basicSettings.vue')
        },
        
        {
          path: '/basic-configuration',
          name: 'basic-configuration',
          meta: {
            title: 'Company Details & Settings',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/common/basicSettings.vue')
        },

        {
          path: '/customer-details/:itemId',
          name: 'tenantDetails',
          meta: {
            title: 'Customer Details',
            requiresAuth: true,
            parent: 'customers',
            sideBar: "small"
          },
          component: () => import('./views/tenantDetails.vue')
        },
        //forms-letters.vue
        {
          path: '/forms-letters',
          name: 'forms-letters',
          meta: {
            title: 'Forms and Letters',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/forms-letters.vue')
        },
        {
          path: '/support-tickets',
          name: 'support-tickets',
          meta: {
            title: 'Support Tickets',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/SupportTickets.vue')
        },
        {
          path: '/sent-emails-list',
          name: 'sent-emails-list',
          meta: {
            title: 'Sent Emails',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/sentEmailsList.vue')
        },
        {
          path: '/ticket-details/:itemId',
          meta: {
            title: 'Ticket Details',
            parent: 'support-tickets',
            requiresAuth: true,
            sideBar: "small"
          },
          name: 'ticket-details',
          component: () => import('./views/SupportTicketDetails.vue')
        },
        {
          path: '/notes-list',
          name: 'notes-list',
          meta: {
            title: 'Notes',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/notes.vue')
        },
        {
          path: '/notes-details/:itemId',
          name: 'notes-details',
          meta: {
            title: 'Notes Details',
            requiresAuth: false,
            sideBar: "small"
          },
          component: () => import('./views/notesDetails.vue')
        },
        {

          path: '/tasks-list',

          name: 'tasks-list',

          meta: {

            title: 'Tasks',

            requiresAuth: true,
            sideBar: "small"

          },

          component: () => import('./views/task/index.vue')

        },

        {

          path: '/tasks-details/:itemId',

          name: 'tasks-details',

          meta: {

            title: 'Task Details',

            requiresAuth: true,
            sideBar: "small"

          },

          component: () => import('./views/task/taskDetails.vue')

        },
        {
          path: '/messages',
          name: 'messages',
          meta: {
            title: 'Messages',
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/messages.vue')
        },
        {
          path: '/documents',
          name: 'documents',
          meta: {
            title: 'Documents',
            requiresAuth: true,
            parent: 'documents',
            sideBar: "small"
          },
          component: () => import('./views/documents/documentsList.vue')
        },
        {
          path: '/files',
          name: 'files',
          meta: {
            title: 'Files',
            requiresAuth: false,
            parent: 'files'
          },
          component: () => import('./views/documents/files.vue')
        },

        {
          path: '/petition-types',
          meta: {
            title: 'Case Types',
            requiresAuth: true,
            sideBar: "small"
          },
          name: 'petition-types',
          component: () => import('./views/petitiontypes/types.vue')
        },
        {
          path: '/petition-subtype-list/:id',
          meta: {
            title: 'Case Subtype',
            requiresAuth: true,
            parent: 'petition-types',
            sideBar: "small"
          },
          name: 'petition-types',
          component: () => import('./views/petitionSubTypeList.vue')
        },
        //petition-config/list
        {
          path: '/petition-config-list/:petitiontypeid/:petitionsubtypeid',
          meta: {
            title: 'Case Configuration',
            requiresAuth: true,
            sideBar: "small"
          },
          name: 'petition-config',
          component: () => import('./views/petitionConfigList.vue')
        },
        {
          path: '/petition-config-list',
          meta: {
            title: 'Case Configuration',
            requiresAuth: true,
            sideBar: "small"
          },
          name: 'petition-config',
          component: () => import('./views/petitionConfigList.vue')
        },
        ///questionnaireConfig.vue
        {
          path: '/questionnaire-templates-list',
          meta: {
            title: 'Questionnaire Templates',
            requiresAuth: true,
            sideBar: "small"
          },
          name: 'questionnairelist',
          component: () => import('./views/questionnaireTemplateList.vue')
        },
        ///questionnaireConfig.vue
        {
          path: 'h1b-:id',
          meta: {
            title: 'Questionnaire Template',
            requiresAuth: true
          },
          name: 'questionnairelist',
          component: () => import('./views/QuestionnaireTemplateCreate.vue')
        },
        {
          path: '/questionnaire-template-details/:id',
          meta: {
            title: 'Questionnaire Template Details',
            requiresAuth: false
          },
          name: 'questionnairelist',
          component: () => import('./views/questionnaireTemplateDetails.vue')
        },
        //workflowList.vue
        {
          path: '/workflow-list',
          meta: {
            title: 'Workflows',
            requiresAuth: true,
            sideBar: "small"
          },
          name: 'workflow-list',
          component: () => import('./views/workflowList.vue')
        },
        //workflow-config add

        {
          path: '/workflow-configV2',
          meta: {
            title: 'Workflow Config',
            requiresAuth: true
          },
          name: 'Workflow Config',
          component: () => import('./views/workflowConfigV2.vue')
        },

        //workflow-config edit
        {
          path: '/workflow-config/:id',
          meta: {
            title: 'Workflow Configuration',
            requiresAuth: true,
            parent: 'workflow-list'
          },
          name: 'workflow-list',
          component: () => import('./views/workflow/editWorkFlow.vue')
        },
        //workflow-config edit
        {
          path: '/workflow-config-view/:id',
          meta: {
            title: 'Workflow details',
            requiresAuth: false
          },
          name: 'workflow-list',
          component: () => import('./views/workflowConfigView.vue')
        },


        {
          path: '/branch-create',
          meta: {
            title: 'Branch Create',
            requiresAuth: true,
            parent: 'branch-list',
            sideBar: "small"
          },
          name: 'Branches',
          component: () => import('./views/branchCreate.vue')
        },
        {
          path: '/branch-edit/:id',
          meta: {
            title: 'Branch Edit',
            requiresAuth: true,
            parent: 'branch-list',
            sideBar: "small"
          },
          name: 'Branch Edit',
          component: () => import('./views/branchCreate.vue')
        },
        {
          path: '/branch-list',
          meta: {
            title: 'Branches',
            requiresAuth: true,
            sideBar: "small"
          },
          name: 'Branches',
          component: () => import('./views/branchList.vue')
        },
        //branch
        {
          path: '/branchdetails/:itemId',
          name: 'Branches',
          meta: {
            title: 'Branch Details',
            parent: 'branch-list',
            sideBar: "small"
          },
          component: () => import('./views/BranchDetails.vue')
        },
        {
          path: '/beneficiaries',
          name: 'beneficiaries',
          meta: {
            title: 'Beneficiaries',
            sideBar: "small"
          },
          component: () => import('./views/Beneficiaries.vue')
        },
        {
          path: '/beneficiaries-details', meta: {
            title: 'Beneficiary Details',
          },
          name: 'beneficiaries-details',
          component: () => import('./views/BeneficiariesDetails.vue')
        },
        {
          path: '/petitions',
          name: 'petitions-OLD',
          meta: {
            title: 'Cases',
            sideBar: "small"
          },

          component: () => import('./views/caseList.vue')
        },
        {
          path: '/cases',
          name: 'petitions',
          meta: {
            title: 'Cases',
            sideBar: "small"
          },
          component: () => import('./views/caseList.vue')
          // component: () => import('./views/Petitions-new-list.vue')
        },
        {
          path: '/ref-cases',
          name: 'ref-cases',
          meta: {
            title: 'RFE Cases',
            sideBar: "small"
          },
          //Petitions-new-list.vue
          component: () => import('./views/caseList.vue')
          //component: () => import('./views/Petitions-new-list.vue')
          //component: () => import('./views/RFEPetitions.vue')
        },
        {
          path: '/case-transfer',
          name: 'case-transfer',
          meta: {
            title: 'Bulk Assignment',
            parent: 'case-transfer',
            sideBar: "small"
          },
          component: () => import('./views/caseTransfer.vue')
        },
        {
          path: '/beneficiary-edit/:itemId',
          name: 'beneficiary-edit',
          meta: {
            title: 'Beneficiary Profile Edit',
            parent: 'petitions',
            sideBar: "small"
          },
          component: () => import('./views/beneficiaryProfile/benEditProfile.vue')
        },

        {
          path: '/petition-details/:itemId',
          meta: {
            title: 'Case Details',
            parent: 'petitions',
            sideBar: "small"
          },
          name: 'petition-details',
          component: () => import('./views/PetitionDetails.vue')
        },
        {
          path: '/GCEmployment',
          meta: {
            title: 'GC Employment',
            sideBar: "small"
          },
          name: 'GC Employment',
          component: () => import('./views/GCEmployment.vue')
        },
        {
          path: '/gc-employment-details/:itemId',
          meta: {
            title: 'PERM Application Details',
            parent: 'GCEmployment',
            sideBar: "small"
          },
          name: 'gc-employment-details',
          component: () => import('./views/GCEmploymentdetailes.vue')
        },
        // {
        //   path: '/gc-employment-details',
        //   meta: {
        //     title: 'GC Employment Detals',
        //     parent: 'GCEmployment',
        //     sideBar:"small"
        //   },
        //   name: 'gc-employment-details',
        //   component: () => import('./views/GCEmploymentdetailes.vue')
        // },
        {
          path: '/rfe-petition-details/:itemId',
          meta: {
            title: 'Case Details',
            parent: 'ref-cases',
            sideBar: "small"
          },
          name: 'rfe-petition-details',
          //component: () => import('./views/RFEPetitionDetails.vue')
          component: () => import('./views/PetitionDetails.vue')
        },
        {
          path: '/gcapplications',
          name: 'gcapplications',
          meta: {
            title: 'GC Applications',
            sideBar: "small"
          },
          component: () => import('./views/GcPetitions.vue')
        },

        {
          path: '/gcapplication/:itemId',
          meta: {
            title: 'GC Applications',
            parent: 'gcapplications',
            sideBar: "small"
          },
          name: 'gcapplication',
          component: () => import('./views/GCPetitionDetails.vue')
        },
        {
          path: '/gcpetitionDetails-template/:itemId',
          meta: {
            title: 'Case Details',
            parent: 'petitions',
            sideBar: "small"
          },
          name: 'petition-details',
          component: () => import('./views/GCPetitionDetailsTemplate.vue')
        },


        {
          path: '/beneficiaries-details/:itemId', meta: {
            title: 'Beneficiary Details',
          },
          name: 'beneficiaries-details',
          component: () => import('./views/BeneficiariesDetails.vue')
        },
        {
          path: '/petitioners',
          name: 'petitioners',

          meta: {
            title: 'Customers',
            sideBar: "small"
          },
          component: () => import('./views/CompanyList.vue')
        },

        /*
         //CompanyList.vue
         {
          path: '/company-list',
          name: 'companies',
          meta: {
            title: 'Petitioners',
            requiresAuth: true
            sideBar: "small"
          },
          component: () => import('./views/CompanyList.vue')
        },*/
        {
          path: '/company/details/:itemId',
          name: 'petitionerdetails', meta: {
            title: 'Customers',
            parent: 'petitioners'
          },
          component: () => import('./views/Petitionerdetails.vue')
        },
        {
          path: '/case-details',
          name: 'case-details',
          component: () => import('./views/CaseDetails.vue')
        },

        {
          path: '/Tabs',
          name: 'Tabs',
          component: () => import('./views/Tabs.vue')
        }, 
        {
          path: '/requestlca/:itemId',
          name: 'requestlca',
          meta: {
          
            requiresAuth: true,
            sideBar: "small"
          },
          component: () => import('./views/RequestLCA.vue')
        },
        {
          path: '/lcalist',
          name: 'lca',

          meta: {
            title: 'LCA Library',
            parent: '',
            sideBar: "small"
          },
          component: () => import('./views/LCAList.vue')
        },
        {
          path: '/lca-details/:itemId',
          name: 'lca-details', meta: {
            title: 'LCA Details',
            parent: 'lca',
            sideBar: "small"
          },
          component: () => import('./views/UpdateLCADocuments.vue')
        },

        {
          path: '/notifications',
          name: 'notifications',
          meta: {
            title: 'Notification',
            sideBar: "small"
          },
          component: () => import('./views/Notifications.vue')
        },
        {
          path: '/questionnaire/:itemId',
          name: 'questionnaire',
          meta: {
            sideBar: "small",
            title: 'Questionnaire',
          },
          component: () => import('./views/Questionnaire.vue')
        },
        {
          path: '/wage-determination',
          name: 'wage-determination',
          meta: {
            sideBar: "small",
            title: '',
          },
          component: () => import('./views/forms/P-100-19290-092846.vue')
        },
        {
          path: '/PERM_Certification',
          name: 'gcApplication',
          meta: {
            sideBar: "small",
            title: 'GC Application',
          },
          component: () => import('./views/forms/PERM_Certification.vue')
        },
        {
          path: '/perm-questionnaire/:itemId',
          name: 'perm-questionnaire',
          meta: {
            sideBar: "small",
            title: 'PERM Questionnaire',
          },
          component: () => import('./views/forms/permQuestionnaire.vue')
        },
        {
          path: '/permapplication-questionnaire/:itemId',
          name: 'permapplication-questionnaire',
          meta: {
            sideBar: "small",
            title: 'PERM Questionnaire',
          },
          component: () => import('./views/forms/permQuestionnaire.vue')
        },

        {
          path: '/permapplicationSuggession-questionnaire/:itemId',
          name: 'permapplicationSuggession-questionnaire',
          meta: {
            sideBar: "small",
            title: 'PERM Questionnaire',
          },
          component: () => import('./views/forms/permQuestionnaire.vue')
        },
        {
          path: '/I-140_Questionnaire',
          name: 'gcApplication',
          meta: {
            sideBar: "small",
            title: 'I-140 Questionnaire',
          },
          component: () => import('./views/forms/I-140_Questionnaire.vue')
        },
        {
          path: '/I-140_Questionnaire/:itemId',
          name: 'gcApplication',
          meta: {
            sideBar: "small",
            title: 'I-140 Questionnaire',
          },
          component: () => import('./views/forms/I-140_Questionnaire.vue')
        },

        {
          path: '/petitioner-details/:itemId',
          name: 'companydetails',
          meta: {
            sideBar: "small",
            parent: 'companyList',
            title: 'Petitioner Details',
          },
          component: () => import('./views/CompanyDetails.vue')
        },

        {
          path: '/petitioner-edit/:itemId',
          name: 'editcompanydetails',
          meta: {
            sideBar: "small",
            parent: 'companyList',
            title: 'Edit Company Details',
          },
          component: () => import('./views/petitioner/editProfile.vue')
        },

        {
          path: '/gcquestionnaire/:itemId',
          name: 'fillgcquestionnaire',
          meta: {
            sideBar: "small",
            title: '',
          },
          component: () => import('./views/GcQuestionnaire.vue')
        },
        {
          path: '/editgcquestionnaire/:itemId',
          name: 'editgcquestionnaire',
          meta: {
            sideBar: "small",
            title: '',
          },
          component: () => import('./views/GcQuestionnaire.vue')
        },
        {
          path: '/lca-inventory-details/:itemId',
          meta: {
            title: 'LCA Details',
            parent: 'petitions',
            sideBar: "small"
          },
          name: 'lca-details',
          component: () => import('./views/lca/LCAInventoryDetails.vue')
        },
      ],
    },

    {
      // =============================================================================
      // Without Sidebar Layouts
      // =============================================================================
      path: '',
      component: () => import('./layouts/no-sidebar/NoSidebar.vue'),
      children: [
        // =============================================================================
        // Theme Routes
        // =============================================================================



        {
          path: '/setpassword',
          name: 'setpassword',
          meta: {
            title: 'Set Password',
          },
          component: () => import('./views/SetPassword.vue')
        },

        {
          path: '/waiting-for-approval',
          name: 'waiting-for-approval',
          component: () => import('./views/WaitingApproval.vue')
        },
        {
          path: 'public/account-activation',
          name: 'account-activation',
          component: () => import('./views/public/AccountActivation.vue'),
          meta: {
            requiresAuth: false
          }
        },

        {
          path: 'public/account-activation-invite',
          name: 'account-activation-invite',
          component: () => import('./views/public/InviteAccountActivation.vue'),
          meta: {
            requiresAuth: false
          }
        },


      ],
    },

    // =============================================================================
    // FULL PAGE LAYOUTS
    // =============================================================================
    {
      path: '',
      component: () => import('@/layouts/full-page/FullPage.vue'),
      children: [
        // =============================================================================
        // PAGES
        // =============================================================================

        // anonymous login perm case
        {
          path: '/fill-perm-questionnaire/:itemId',
          name: 'fill-perm-questionnaire',
          meta: {
            sideBar: "small",
            title: 'PERM Questionnaire',
            "getTokenFromUrl": true,
            requiresAuth: false

          },
          component: () => import('./views/forms/permQuestionnaire.vue')
        },

        {
          path: '/filled-perm-case-details/:itemId',
          name: 'filled-perm-case-details',
          meta: {
            getTokenFromUrl: true,
            title: 'PERM Case Details',
            parent: 'case',
            sideBar: "small",
            requiresAuth: false
          },


          component: () => import('./views/GCEmploymentdetailes.vue')
        },
        // anonymous login cap registration
        {
          path: '/fill-cap-registration/:itemId',
          name: 'fill-cap-registration',
          meta: {
            sideBar: "small",
            title: 'CAP Registration',
            "getTokenFromUrl": true,
            requiresAuth: false

          },
          component: () => import('./views/cap/Questionnaire.vue')
        },
        {
          path: '/filled-cap-registration-details/:itemId',
          name: 'filled-cap-registration-details',
          meta: {
            getTokenFromUrl: true,
            title: 'CAP Registration Details',
            parent: 'case',
            sideBar: "small",
            requiresAuth: false
          },


          component: () => import('./views/cap/CapDetails.vue')
        },
        // anonymous login Normal case

        {
          path: '/fill-questionnaire/:itemId',
          name: 'fill-questionnaire',
          meta: {
            title: '',
            "getTokenFromUrl": true,
            requiresAuth: false
          },
          component: () => import('./views/Questionnaire.vue')
        },

        {
          path: '/filled-case-details/:itemId',
          name: 'filled-case-details',
          meta: {
            getTokenFromUrl: true,
            title: 'Case Details',
            parent: 'case',
            sideBar: "small",
            requiresAuth: false
          },

          component: () => import('./views/PetitionDetails.vue')
        },

        {
          path: '/fill-lca-anonymous-user/:itemId',
          name: 'fill-lca-anonymous-user',
          meta: {
            getTokenFromUrl: true,
            title: 'LCA Details',
            parent: 'case',
            sideBar: "small",
            requiresAuth: false
          },

          component: () => import('./views/PetitionDetails.vue')
        },


        {
          path: '/login',
          name: 'page-login',
          component: () => import('@/views/pages/Login.vue'),
          meta: {
            requiresAuth: false
          }
        },
        {
          path: '/register',
          name: 'page-register',
          component: () => import('@/views/common/registration.vue'),
          meta: {
            requiresAuth: false
          }
        },
        {
          path: '/forgot-password',
          name: 'page-forgot-password',
          component: () => import('@/views/pages/ForgotPassword.vue'),
          meta: {
            requiresAuth: false
          }
        },
        {
          path: '/resend-link',
          name: 'resend-activation-link',
          component: () => import('@/views/pages/resendActivationLink.vue'),
          meta: {
            requiresAuth: false
          }
        },
        // {
        //   path: '/resend-link2',
        //   name: 'resend-activation-link2',
        //   component: () => import('@/views/pages/resendActivationLink2.vue'),
        //   meta: {
        //     requiresAuth: false
        //   }
        // },
        //setForgetPassword.vue
        /*
        {
          //path: '/set-forgot-password',
          path: '/reset-password',
          name: 'set-forgot-password',
          component: () => import('@/views/pages/setForgetPassword.vue'),
          meta: {
            requiresAuth: false
          }
        },
        */
        {
          path: '/public/reset-password',
          name: 'reset-password',
          // component: () => import('@/views/pages/setForgetPassword.vue'),
          component: () => import('@/views/SetPassword.vue'),
          meta: {
            requiresAuth: false
          }
        },
        {
          path: '/public/confirm-sponsorship-questionnaire',
          name: 'confirm-sponsorship-questionnaire',
          component: () => import('@/views/pages/confirmSponsorshipQuestionnaire.vue'),

          meta: {
            requiresAuth: false
          }
        },
        {
          path: '/public/confirm-i140-creation', //approve-pwd-createI140',
          name: 'confirm-i140-creation',
          component: () => import('@/views/pages/ApprovePwdCreateI140.vue'),

          meta: {
            requiresAuth: false
          }
        },
        {
          path: '/public/communication/reply',
          name: 'Communication-Reply',
          component: () => import('@/views/messages/communicationReply.vue'),

          meta: {
            "getTokenFromUrl": true,
            requiresAuth: false
          }
        },
        {
          path: '/public/set-password',
          name: 'reset-password',
          component: () => import('@/views/SetPassword.vue'),
          meta: {
            requiresAuth: false
          }
        },
        {
          path: '/public/activate-user-account',
          name: 'reset-password',
          component: () => import('@/views/activateUserAccount.vue'),
          meta: {
            requiresAuth: false
          }
        },
        


        {
          path: '/verify-email',
          name: 'verify-email',
          component: () => import('@/views/pages/activateEmail.vue'),
          meta: {
            requiresAuth: false
          }
        },
        {
          path: '/error-404',
          name: 'page-error-404',
          component: () => import('@/views/pages/Error404.vue'),
          meta: {
            requiresAuth: false
          }
        },

      ]
    },
    // Redirect to 404 page, if no match found
    {
      path: '*',
      redirect: '/error-404'
    }
  ],
})

router.afterEach((to, from) => {
  // Remove initial loading
  const appLoading = document.getElementById('loading-bg')
  if (appLoading) {
    appLoading.style.display = "none";

  }
  
  window.scrollTo(0, 0)
  if (['fill-questionnaire', 'filled-case-details', 'perm-questionnaire'].indexOf(to.name) <= -1) {
    store.dispatch("common/authGaurdcb", {})
  }

  store.dispatch("common/setRoutes", { from: from, to: to })



})




router.beforeEach((to, from, next) => {


  const user = store.getters.getuser;
  const host = window.location.host;
  const parts = host.split('.');
  let tenantId = user.tenantId;
  let slug = null;
  let tenantExist = true;
  if (parts.length > 0) {
    if (['anyclap', 'immibox', '192.168.100.13:8080', 'www', 'app', 'localhost:8080', 'localhost:8081', '192', 'localhost:8083'].indexOf(parts[0].toLowerCase()) > -1) {
      tenantExist = false;
    } else {
      //alert(parts[0].toLowerCase())
      slug = parts[0].toLowerCase();
    }

  }

  //if you want to test any tenant (change the slug) uncomment bellow two lines to test in local
  // slug = "srinfotech";
  // tenantExist = true; 

  //this.$store.dispatch("setPetitionTab" , tab)

  if (!(to.path.includes('/petition-details/'))) {

    store.dispatch("setPetitionTab", 'Case Details')
  }

  let isCardExists = store.getters['subscription/getIsCardExists'];



  /* IF NO AUTHENTICATION REQUIRED ACCSES ROUTES DIRECTLY */
  if (to.matched.some(record => record.meta.requiresAuth == false)) {

    if (store.getters.isLoggedIn && to.path == "/login") {
      let profileCompleted = localStorage.getItem('isProfilecompleted')


      if (to.path != "/basic-settings" && (

        //|| (isCardExists == 'false' || isCardExists == false) 
        ((store.state.user['roleId'] == 3 && store.state.tenantProfileCompleted == false) || (localStorage.getItem('tenantProfilecompleted')=='false' && localStorage.getItem('loginuserRole') ==3 ))
        || ( (store.state.user['roleId'] == 50 && store.state.petitionerProfileCompleted == false )||  (localStorage.getItem('petProfilecompleted')=='false' && localStorage.getItem('loginuserRole') ==50 ) )
     
        )

      ) {
        next('/basic-settings')
        return

      } else {
        if (store.state.user['roleId'] == 51 && to.path == "/dashboard") {

          next('/cases')
          return
        } else {
          next('/dashboard')
          return

        }



      }

    }
    if (store.getters.isLoggedIn && to.path == "/register") {
      if (store.state.user['roleId'] == 51 && to.path == "/dashboard") {

        next('/cases')
        return
      } else {
        next('/dashboard')
        return

      }
    }

    if (tenantExist && to.path != "/error-404") {

      store.dispatch("common/getTenantdetails", { "slug": slug }).then(() => {
        tenantId = store.getters['common/getTenantId'];

        if (tenantId) {
          next()
        } else {

          next('/error-404')
          return

        }
      })

    } else {
      store.dispatch("common/getTenantdetails", { "slug": slug }).then(() => { })
      next()
    }




  } else {
    //alert("sdhf sdf")
    if (store.getters.isLoggedIn) {

      if (store.state.user['roleId'] == 51 && to.path == "/dashboard") {

        next('/cases')
        return
      }
      if (to.path != "/basic-settings" && (

   //|| (isCardExists == 'false' || isCardExists == false) 
   ((store.state.user['roleId'] == 3 && store.state.tenantProfileCompleted == false) || (localStorage.getItem('tenantProfilecompleted')=='false' && localStorage.getItem('loginuserRole') ==3 ))
   || ( (store.state.user['roleId'] == 50 && store.state.petitionerProfileCompleted == false )||  (localStorage.getItem('petProfilecompleted')=='false' && localStorage.getItem('loginuserRole') ==50 ) )

   )

      ) {


        next('/basic-settings')
        return

      }
      if (tenantExist) {
        store.dispatch("common/getTenantdetails", { "slug": slug }).then(() => {
          tenantId = store.getters['common/getTenantId'];
          if (tenantId) {
            next()
          } else {
            next('/error-404')
            return
          }


        })
      } else {
        next()


      }

    } else {

      next('/login')
      return

    }



  }

  if (store.getters.isLoggedIn && [1, 2, 3, 50].indexOf(store.state.user['roleId']) > -1
    && (to.path == "/basic-settings" || to.path == "/basic-configuration")) {
    if ([1].indexOf(store.state.user['roleId']) > -1) {
      to.meta.title = "Settings"
    } else {
      to.meta.title = "Company Details & Settings"
    }
  }


  next();
})



export default router
