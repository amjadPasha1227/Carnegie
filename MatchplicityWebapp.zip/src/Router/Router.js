import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Components from '../components/Components';
import Dashboard from '../views/Dashboard';
import Login from '../views/Login';
import Contact from '../views/Contact';
import Candidates from '../views/Candidates';
import Register from '../views/Register';
import Jobs from '../views/Jobs';
import SampleModal from '../components/simpleModal';
import ForgotPassword from '../views/forgotPassword';

import TalentDashboard from '../views/Talent/Dashboard';
import TalentRegister from '../views/Talent/Register';

import CommunityDashboard from '../views/Community/Dashboard';
import CommunityRegister from '../views/Community/Register';

function Router() {
    return(
        <React.Fragment>
            <Routes> 
                <Route path='/register' element={<Register/>}></Route>  
                <Route path='/' element={<Login/>}></Route>    
                <Route path='/forgotpassword' element={<ForgotPassword/>}></Route>
                <Route path='/components' element={<Components/>}></Route>            
                <Route path='/dashboard' element={<Dashboard/>}></Route>                
                <Route path='/contact' element={<Contact/>}></Route>
                <Route path='/candidates' element={<Candidates/>}></Route>
                <Route path='/jobs' element={<Jobs/>}></Route>
                <Route path='/modal' element={<SampleModal/>}></Route>


                <Route path='/talent-dashboard' element={<TalentDashboard/>}></Route>
                <Route path='/talent-register' element={<TalentRegister/>}></Route>

                <Route path='/community-dashboard' element={<CommunityDashboard/>}></Route>
                <Route path='/community-register' element={<CommunityRegister/>}></Route>

            </Routes>
        </React.Fragment>
    )
}
export default Router;