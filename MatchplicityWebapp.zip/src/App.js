 
import './App.css';
import React from 'react' 
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter} from 'react-router-dom';
import {UserProvider} from "./views/Utils.js"
import './Styles/scss/style.scss';

//import Sidenav from './components/Sidenav'; 
import Header from './components/Header'; 
import Footer from './components/Footer';  
import Router from './Router/Router' 

function App() {
  return (
    <React.Fragment>
     <UserProvider>
        <BrowserRouter>
          <div className="layout">
            <Header/>                    
            <div className='maincontent'>
              <Router/>            
            </div>               
            <Footer/>
          </div>
        </BrowserRouter>
     </UserProvider>
    </React.Fragment>
  );
}

export default App;
