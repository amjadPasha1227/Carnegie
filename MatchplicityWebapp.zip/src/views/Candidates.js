import { React, useState } from 'react';
import Form from 'react-bootstrap/Form';
import searchIcon from "@/../../public/images/main/search_icon.svg";
import locationIcon from "@/../../public/images/main/location.svg";
import suitcaseIcon from "@/../../public/images/main/suitcase.svg";
import profilePicIcon from "@/../../public/images/main/profile_pic.png";
import profilePicIcon2 from "@/../../public/images/main/profile_pic_2.png";
import messageIcon from "@/../../public/images/main/message.svg";
import scheduleIcon from "@/../../public/images/main/schedule.svg";
import locationIconWhite from "@/../../public/images/main/location_white.svg";
import ExpIcon from "@/../../public/images/main/clock.svg";
import JobtypeIcon from "@/../../public/images/main/house-laptop.svg";
import salaryRangeIcon from "@/../../public/images/main/coins.svg";
import mailIcon from "@/../../public/images/main/mail.svg";
import smartphoneIcon from "@/../../public/images/main/smartphone.svg";
import attachIcon from "@/../../public/images/main/attachments.svg";
import sentIcon from "@/../../public/images/main/sent.svg";
import '.././Styles/scss/candidates.scss';
import Offcanvas from 'react-bootstrap/Offcanvas';
import SimpleSelect from '../components/SimpleSelect';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';

const filterData = [
    {
    id: 0,
    category: 'Employment Type',
    checkList: ['Full-Time','Intern/Trainee','Part-Time']
    },
    {
    id: 1,
    category: 'Work Preference',
    checkList: ['On-site','Hybrid','Remote']
    },
    {
    id: 2,
    category: 'Status',
    checkList: ['Interviewed','Rejected','Hired']
    },
    {
    id: 3,
    category: 'Attachment',
    checkList: ['Resume']
    },
]

const jobMatchedData = [
    {
        id: 0,
        jobTitle: 'User Interface Architect',
        location: 'Eastern Europe • Central America • Remote',
        matchesCount: 25,
        matchesList: [
            {
                profileName: 'Aberash Hadiza',
                role: 'Senior Manager User Interface Design',
                experience: '10+',
                matchedPercentge: '87'
            },
            {
                profileName: 'Simbo Osoba',
                role: 'Manager - User Interface Design',
                experience: '8+',
                matchedPercentge: '86'
            },
            {
                profileName: 'Rickey Dandridge',
                role: 'UI Architect',
                experience: '14+',
                matchedPercentge: '71'
            }
        ]
    },
    {
        id: 1,
        jobTitle: 'Program Manager - Accounting, Kuiper Accounting',
        location: 'Eastern Europe • Central America • On-site/Hybrid',
        matchesCount: 42,
        matchesList: [
            {
                profileName: 'Minowa Melvin',
                role: 'Senior Manager User Interface Design',
                experience: '12+',
                matchedPercentge: '91'
            },
            {
                profileName: 'Tierra Chess',
                role: 'Manager - User Interface Design',
                experience: '17+',
                matchedPercentge: '85'
            },
            {
                profileName: 'Roz Llewellyn',
                role: 'UI Architect',
                experience: '6+',
                matchedPercentge: '85'
            }
        ]
    },
    {
        id: 2,
        jobTitle: 'International Tax Manager, U.S. Outbound Reporting & Compliance',
        location: 'Eastern Europe • Central America • Remote/Part-Time',
        matchesCount: 17,
        matchesList: [
            {
                profileName: 'Minowa Melvin',
                role: 'Senior Manager User Interface Design',
                experience: '12+',
                matchedPercentge: '91'
            },
            {
                profileName: 'Tierra Chess',
                role: 'Manager - User Interface Design',
                experience: '17+',
                matchedPercentge: '85'
            },
            {
                profileName: 'Roz Llewellyn',
                role: 'UI Architect',
                experience: '6+',
                matchedPercentge: '85'
            }
        ]
    }
]

const options = [
      { value: 1, label: 'React' },
      { value: 2, label: 'Angular' },
      { value: 3, label: 'Vue' },
      { value: 4, label: 'React Native' },
      { value: 5, label: 'Node' },
    ]

function Candidates() {
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    return (
        <div className='page_wrapper'>
            <div className='side_bar_filters'>
                <h4 className='page_heading'>Candidates</h4>
                <div className='filters_wrapper'>
                {filterData.map((item) => {
                    return (
                        <div className='filters_list' key={item.id}>
                            <span className='category_heading'>{item.category}</span>
                            <ul>
                                {item.checkList.map((list, i) => (
                                    <li key={i}>
                                        <Form.Check 
                                            label={list}
                                            id={list}
                                        />
                                    </li>
                                ))}
                            </ul>
                        </div>
                    );
                })}
                </div>
            </div>
            <div className='main_details_sec'>
                {/* <div className='search_sec'>
                    <div className='left_sec'>
                        <ul className='custom_tabs'>
                            <li className='active'>Matched</li>
                            <li>Interested</li>
                        </ul>
                        <div className='form_search'>
                            <Form.Control
                                type="text"
                                placeholder="Search..."
                            />
                            <img src={searchIcon} />
                        </div>
                        <div className='form_search location'>
                            <Form.Control
                                type="text"
                                placeholder=""
                            />
                            <img src={locationIcon} />
                        </div>
                    </div>
                    <div className='right_sec'>
                        <button>Export</button>
                        <button>Bulk Upload</button>
                        <button>Add Job</button>
                    </div>
                </div> */}
                <div className='details_list'>
                {jobMatchedData.map((item) => {
                     return (
                        <div className='details_list_item' key={item.id}>
                            <div className='job_header_sec'>
                                <div className='left_sec'>
                                    <figure>
                                        <img src={suitcaseIcon}/>
                                    </figure>
                                    <div className='job_title_sec'>
                                        <span className='job_title'>{item.jobTitle}</span>
                                        <span className='location'>{item.location}</span>
                                    </div>
                                </div>
                                <span className='matches'>{item.matchesCount} Matched</span>
                            </div>
                            {item.matchesList.map((list, i) => (
                                <div className='matched_profile_sec' key={i}>
                                    <div className='profile_sec'>
                                        <Form.Check label=''/>
                                        <div className='profile_icon'>
                                            <img src={profilePicIcon} />
                                        </div>
                                        <div className='profile_title_sec'>
                                            <span className='profile_name' onClick={handleShow}>{list.profileName}</span>
                                            <span className='role_exp'>{list.role} - {list.experience} yrs exp</span>
                                        </div>
                                    </div>
                                    <div className='action_sec'>
                                        <span className='matched'>{list.matchedPercentge}% Matched</span>
                                        {/* <SimpleSelect className='statusselect' options={options} isMulti={true}></SimpleSelect> */}
                                        <span><img src={messageIcon} /></span>
                                        <span><img src={scheduleIcon} /></span>
                                    </div>
                                </div>
                            ))}
                            <span className='view_all_btn'>View All Candidates</span>
                        </div>
                     );
                })}   
                </div>


                {/* off canvas // side popup */}
                {/* <button onClick={handleShow}>Offcanvas</button> */}
                <Offcanvas show={show} onHide={handleClose} placement={'end'}>
                    <Offcanvas.Header >
                        <div className='profile-info'>
                            <figure className='profile-img'>
                                <img src={profilePicIcon2} />
                            </figure>
                            <div className='profile-titles'>
                                <span className='profile-name'>Simbo Osoba</span>                   
                                <span className='profile-role'>Manager - User Interface Design</span>
                                <span className='profile-location'><img src={locationIconWhite}/>Eastern Europe • Central America</span>                                
                            </div>
                        </div> 
                        <div className='profile-actions'>
                            <div className='profile-top'>
                                <span className='profile-matched'>87% Matched</span>
                                {/* <SimpleSelect className='statusselect' options={options} isMulti={true}></SimpleSelect> */}
                            </div>
                            <span className='member-since'>Since Member Feb 2010</span>
                            
                        </div>
                     </Offcanvas.Header>
                    <Offcanvas.Body>
                        <div className='profile_exp_sec'>
                            <ul>
                                <li>
                                    <div className='icon_sec'>
                                        <img src={ExpIcon}/>
                                    </div>
                                    <div className='details_sec'>
                                        <span>8+ Years</span>
                                        <em>Experience</em>
                                    </div>
                                </li>
                                <li>
                                    <div className='icon_sec'>
                                        <img src={JobtypeIcon}/>
                                    </div>
                                    <div className='details_sec'>
                                        <span>Full-Time/Remote</span>
                                        <em>Job Type</em>
                                    </div>
                                </li>
                                <li>
                                    <div className='icon_sec'>
                                        <img src={salaryRangeIcon}/>
                                    </div>
                                    <div className='details_sec'>
                                        <span>$110,000 - $120,000</span>
                                        <em>Salary Range</em>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <Tabs defaultActiveKey="messages">
                            <Tab eventKey="messages" title="Messages">
                                <div className='messages'>
                                    <figure className='messages-img'>
                                            <img src={profilePicIcon} />
                                    </figure>
                                    <div className='messages-details'>
                                        <h5 className='messenger-name'>Victoria Mitchner - 3:35pm</h5>
                                        <div className='message-content'>
                                            <p>I’m reaching out to see if you’d be interested in a job opportunity. Please let me know if you are available to discuss.</p>
                                        </div>
                                    </div>
                                </div>
                                <div className='messages'>
                                    <figure className='messages-img'>
                                        <img src={profilePicIcon} />
                                    </figure>
                                    <div className='messages-details'>
                                    <h5 className='messenger-name'>Simbo Osoba - 4:41pm</h5>
                                    <div className='message-content'>
                                            <p>Thanks for the message, I am available to discuss further, Please call to (1 123 456 7890 ) any time. Please find the below Updated CV</p>
                                            <div className='pdf-content'>
                                                <figure>
                                                    <img src='' alt='' />
                                                </figure>
                                                <span className='pdf-name'>Updated CV.pdf</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className='messages'>
                                    <figure className='messages-img'>
                                        <img src={profilePicIcon} />
                                    </figure>
                                    <div className='messages-details'>
                                        <h5 className='messenger-name'>Victoria Mitchner - 3:35pm</h5>
                                        <div className='message-content'>
                                            <p>I got it. do u have exp in US clients and Stack holder Management , US project exp</p>
                                        </div>
                                    </div>
                                </div>
                                <div className='messages'>
                                    <figure className='messages-img'>
                                        <img src={profilePicIcon} />
                                    </figure>
                                    <div className='messages-details'>
                                        <h5 className='messenger-name'>Simbo Osoba - 4:41pm</h5>
                                        <div className='message-content'>
                                            <p>Yes senthil i worked with clients in some projects</p>
                                        </div>
                                    </div>
                                </div>
                                <div className='messages'>
                                    <figure className='messages-img'>
                                        <img src={profilePicIcon} />
                                    </figure>
                                    <div className='messages-details'>
                                        <h5 className='messenger-name'>Victoria Mitchner - 3:35pm</h5> 
                                        <div className='message-content'>
                                            <p>Great</p>
                                        </div>
                                    </div>
                                </div>
                            </Tab>
                            <Tab eventKey="notes" title="Notes">
                            <div className='notes'>
                                <figure className='notes-img'>
                                        <img src={profilePicIcon} />
                                </figure>
                                <div className='notes-details'>
                                    <h5 className='notes-name'>Victoria Mitchner - 3:35pm</h5> 

                                    <div className='notes-content'>
                                        <p>Hi Simbo Osoba, Please upload the resume along with you portfolio</p>
                                    </div>
                                </div>
                            </div>
                            <div className='notes'>
                                <figure className='notes-img'>
                                        <img src={profilePicIcon} />
                                </figure>
                                <div className='notes-details'>
                                    <h5 className='notes-name'>Victoria Mitchner - 3:35pm</h5>
                                    <div className='notes-content'>
                                        <p>Hi Simbo Osoba, We have shared task to your email and revert back to us by 25th September, Please keep these points for your task</p>
                                        <ul>
                                            <li>We have shared task to your email and revert back</li>
                                            <li>We have shared task to your email and revert back</li>
                                            <li>We have shared task to your email and revert back</li>
                                            <li>We have shared task to your email and revert back</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div className='notes'>
                                <figure className='notes-img'>
                                        <img src={profilePicIcon} />
                                </figure>
                                <div className='notes-details'>
                                    <h5 className='notes-name'>Mitchner Victoria - 3:35pm</h5> 

                                    <div className='notes-content'>
                                        <p>Hi Victoria Mitchner, I have seen the task lets proceed to next round of interview</p>
                                    </div>
                                </div>
                            </div>
                            </Tab>
                            <Tab eventKey="biography" title="Biography">
                                <div className='mail-contact-info'>
                                    <img src={mailIcon} alt="Email Icon" />
                                    <span>simboosoba@gmail.com</span>
                
                                    <img src={smartphoneIcon} alt="Phone Icon" />
                                    <span>+1 123 456 7890</span>
                
                                </div>
                                <p className='candidate-info'>My name is Simbo Osoba, and I am a passionate, service-oriented individual seeking a meaningful career experience in the business, finance and/or accounting industry. I love working with numbers, analyzing and problem solving, and leaving people/clients well served. My professional background is in public accounting, specifically in corporate tax compliance. I am an active CPA in 
                                the state of Virginia.</p>
                                <div className='certifications'>
                                    <h5 className='certificate-title'>Certifications</h5>
                                    <ul className='certification-list'>
                                        <li>Google UX Design</li>
                                        <li>NN/g UX Certification</li>
                                        <li>Interaction Design Foundation</li>
                                    </ul>
                                </div>
                                <div className='prefered-locations'>
                                    <h5 className='location-title'>Preferred Job Locations</h5>
                                    <ul className='location-list'>
                                        <li>Washington, D.C, United States</li>
                                        <li>Tampa, United States</li>
                                        <li>Boston, United States</li>
                                    </ul>
                                </div>
                            </Tab>
                            <Tab eventKey="skills" title="Skills">
                                <div className='skill_sec'>
                                    <div className='skill_header'>
                                        <div className='skill_left'><span>Skill Name</span></div>
                                        <div className='skill_right'>
                                            <span>Good</span>
                                            <span>Very Good</span>
                                            <span>Highly Skilled</span>
                                        </div>
                                    </div>
                                    <div className='skill_body'>
                                        <ul>
                                            <li>
                                                <div className='skill_body_left'>
                                                    <span>User interface design</span>
                                                </div>
                                                <div className='skill_body_right'>
                                                    <span className='skill_present'></span>
                                                    <span></span>
                                                    <span></span>
                                                </div>
                                            </li>
                                            <li>
                                                <div className='skill_body_left'>
                                                    <span>User experience design</span>
                                                </div>
                                                <div className='skill_body_right'>
                                                    <span></span>
                                                    <span></span>
                                                    <span className='skill_present'></span>
                                                </div>
                                            </li>
                                            <li>
                                                <div className='skill_body_left'>
                                                    <span>Interaction design</span>
                                                </div>
                                                <div className='skill_body_right'>
                                                    <span></span>
                                                    <span className='skill_present'></span>
                                                    <span></span>
                                                </div>
                                            </li>
                                            <li>
                                                <div className='skill_body_left'>
                                                    <span>Information architecture</span>
                                                </div>
                                                <div className='skill_body_right'>
                                                    <span></span>
                                                    <span></span>
                                                    <span className='skill_present'></span>
                                                </div>
                                            </li>
                                            <li>
                                                <div className='skill_body_left'>
                                                    <span>Research</span>
                                                </div>
                                                <div className='skill_body_right'>
                                                    <span className='skill_present'></span>
                                                    <span></span>
                                                    <span></span>
                                                </div>
                                            </li>
                                            <li>
                                                <div className='skill_body_left'>
                                                    <span>User research</span>
                                                </div>
                                                <div className='skill_body_right'>
                                                    <span></span>
                                                    <span className='skill_present'></span>
                                                    <span className='skill_present'></span>
                                                </div>
                                            </li>
                                            <li>
                                                <div className='skill_body_left'>
                                                    <span>Website wireframe</span>
                                                </div>
                                                <div className='skill_body_right'>
                                                    <span className='skill_present'></span>
                                                    <span></span>
                                                    <span></span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </Tab>
                            <Tab eventKey="experience" title="Work Experience">
                                <div className='work-experience'>
                                    <div className='previous-org-names'>
                                        <div className='previous-org-logo'>
                                            {/* <img src={amazonLogo} /> */}
                                        </div>

                                        <div className='previous-org-role'>
                                            <h5> Senior Manager - UI/UX Design</h5>
                                            <p>Amazon</p>
                                        </div>

                                    </div>
                                    <div className='duration-previous-org'>
                                        <p>October 2015 - Present (7 years 10 months)</p>
                                    </div>
                                </div>
                                <div className='work-experience'>
                                    <div className='previous-org-names'>
                                        <div className='previous-org-logo'>
                                            {/* <img src={amazonLogo} /> */}
                                        </div>

                                        <div className='previous-org-role'>
                                            <h5> UI/UX Designer</h5>
                                            <p>Facebook</p>
                                        </div>

                                    </div>

                                    <div className='duration-previous-org'>
                                        <p>August 2013 - October 2015 (2 years 2 months)</p>
                                    </div>
                                </div>
                                <div className='work-experience'>
                                    <div className='previous-org-names'>
                                        <div className='previous-org-logo'>
                                            {/* <img src={amazonLogo} /> */}
                                        </div>

                                        <div className='previous-org-role'>
                                            <h5> Intern Visual Designer</h5>
                                            <p>Apple</p>
                                        </div>

                                    </div>

                                    <div className='duration-previous-org'>
                                        <p>May 2010 - August 2013 (3 years 3 months)</p>
                                    </div>
                                </div>
                            </Tab>
                        </Tabs>
                    </Offcanvas.Body>
                    <div className='offcanvas_footer'>
                        <input type='text' placeholder='Write Messages…' />
                        <div className='actions'>
                            <img src={attachIcon} />
                            <span> <img src={sentIcon} /></span>
                        </div>
                    </div>
                </Offcanvas>
            </div>
        </div>
    )
}
export default Candidates;