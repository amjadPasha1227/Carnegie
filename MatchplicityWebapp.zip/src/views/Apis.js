//export const baseURl = "http://localhost:3000/"
export const baseURl = "http://localhost:8989/"
export const sigin = baseURl+"auth/login"