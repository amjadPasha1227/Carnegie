import React from "react";


function TalentDashboard(){
    return(
        <div>
            TalentDashboard
        </div>
    )
}
export default TalentDashboard;