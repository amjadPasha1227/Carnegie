import React, { useState, useEffect } from 'react';
import '../.././Styles/scss/register.scss';
import Logo from '@/../../public/images/logo.png';
import SimpleInput from '../../components/SimpleInput';
import SimpleSelect from '../../components/SimpleSelect';
import { Col, Form, Row } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import PasswordStrengthBar from '../../components/PasswordStrengthBar';
import EyeClose from "@/../../public/images/icons/eye_close.png";
import Eyeopen from "@/../../public/images/icons/eye_open.png";
function TalentRegister() {
  const { handleSubmit, formState: { errors }, register,clearErrors ,control} = useForm();
  const [formData, setFormData] = useState({
    companyName: '',
    firstName: '',
    lastName: '',
    jobTitle: '',
    department: '',
    emailAddress: '',
    phoneNumber: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  useEffect(() => {
    document.body.classList.add('before-login');
    return () => {
      document.body.classList.remove('before-login');
    }
  }, [])
 
  const handleInputChange = (event) => {
  //  setFormData({ ...formData, [fieldName]: event.target.value });
    const { name, value } = event.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
    if (value) {
        clearErrors(name);
    }
    console.log("handleInputChange");
    console.log("event", event);
  };
  const showPasswordIcon = () => {
    setShowPassword(!showPassword)
    };
  function onSubmit(e) {
    console.log("OnSubmit")
  };
  const onErrors = (errors) => {
    console.log("errors are ", errors)
  }

  return (
    <React.Fragment>
      <div className='register'>
        <div className='register_from'>
          <div className='register-head'>
            <img src={Logo} alt='Bizzell US' />
            <h4>Talent Register</h4>
          </div>
          <div className='form-container'>
            <Form>
              <Row>
                <Col>
                  <SimpleInput
                    label='Company Name'
                    type='text'
                    inputValue={formData.companyName}
                    onInputChange={handleInputChange}
                    errors={errors}
                    register={register}
                    isRequired={true}
                    errorText={"Company Name"}
                    fieldName={'companyName'}
                  />
                </Col>
              </Row>
              <Row>
                <Col>
                  <SimpleInput
                    label='First Name'
                    type='text'
                    inputValue={formData.firstName}
                    onInputChange={handleInputChange}
                    errors={errors}
                    register={register}
                    isRequired={true}
                    errorText={"First Name"}
                    fieldName={'firstName'}
                  />
                </Col>
                <Col>
                  <SimpleInput
                    label='Last Name'
                    type='text'
                    inputValue={formData.lastName}
                    onInputChange={handleInputChange}
                    errors={errors}
                    register={register}
                    isRequired={true}
                    errorText={"last Name"}
                    fieldName={'lastName'}
                  />
                </Col>
              </Row>
              <Row>
                <Col>
                  <SimpleInput
                    label='Job Title'
                    type='text'
                    inputValue={formData.jobTitle}
                    onInputChange={handleInputChange}
                    errors={errors}
                    register={register}
                    isRequired={true}
                    errorText={"Job Title"}
                    fieldName={'jobTitle'}
                  />
                </Col>
                <Col>
                  <SimpleSelect
                    label='Department'
                    options={[
                      { value: 1, label: 'React' },
                      { value: 2, label: 'Angular' },
                      { value: 3, label: 'Vue' },
                      { value: 4, label: 'React Native' },
                      { value: 5, label: 'Node' },
                    ]}
                    isMulti={false}
                    placeholder={'select'}
                    onInputChange={handleInputChange}
                    errors={errors}
                    register={register}
                    isRequired={true}
                    errorText={"Select"}
                    fieldName={'department'}
                    control={control}
                  />
                </Col>
              </Row>
              <Row>
                <Col>
                  <SimpleInput
                    label='Emai Address'
                    type='email'
                    inputValue={formData.emailAddress}
                    onInputChange={handleInputChange}
                    errors={errors}
                    register={register}
                    isRequired={true}
                    errorText={"Email"}
                    fieldName={'emailAddress'}
                  />
                </Col>
              </Row>
              <Row>
                <Col>
                  <SimpleInput
                    label='Phone Number'
                    type='phone number'
                    inputValue={formData.phoneNumber}
                    onInputChange={handleInputChange}
                    errors={errors}
                    register={register}
                    isRequired={true}
                    errorText={"Phone Number"}
                    fieldName={'phoneNumber'}
                  />
                </Col>
              </Row>
              <Row>
                <Col>
                  <SimpleInput
                    label='Password'
                    //type='password'
                    type={showPassword ? 'text' : 'password'}
                    inputValue={formData.password}
                    onInputChange={handleInputChange}
                    errors={errors}
                    register={register}
                    isRequired={true}
                    errorText={"Password"}
                    fieldName={'password'}
                    showIcon={true}
                    onClickIcon={showPasswordIcon}
                    showImageType={showPassword ? Eyeopen:EyeClose}
                  />
                </Col>
              </Row>
              <Row>
                  <Col>
                      <PasswordStrengthBar value={formData.password}/>
                    </Col> 
              </Row>
              <Row>
                <Col>
                  <Button variant='primary' type='submit' onClick={handleSubmit(onSubmit, onErrors)} >
                    Continue
                  </Button>
                </Col>
              </Row>
              <Row>
                <Col>
                  <p className='form-actions'>
                    <Link to='/register'></Link>
                    <Link to='/'>Sign In</Link>
                  </p>
                </Col>
              </Row>
            </Form>
          </div>
        </div>
        <div className='register-text'>
          <p>
            Any company looking to grow their<br /> workforce and connect with
            top talent.
          </p>
        </div>
      </div>
    </React.Fragment>
  );
}
export default TalentRegister;
