import React, { useState, useEffect } from 'react';
import '.././Styles/scss/register.scss'
import Logo from "@/../../public/images/logo.png";

import SimpleInput from '../components/SimpleInput';
import { Col, Form, Row } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';

function ForgotPassword() {
    const { handleSubmit, formState: { errors }, register } = useForm();
    const [formData, setFormData] = useState({
        email: '',
        password: ''
    })

    const handleInputChange = (event, fieldName) => {
        setFormData({ ...formData, [fieldName]: event.target.value });
    };

    function onSubmit(data) {
        console.log("OnSubmit")
    };

    const onErrors = (errors) => {
        console.log("errors are ", errors)
    }

    useEffect(() => {
        document.body.classList.add('before-login')
        return () => {
            document.body.classList.remove('before-login')
        }
    }, [])

    return (
        <React.Fragment>
            <div className='register'>
                <div className='register_from'>
                    <div className='register-head'>
                    <img src={Logo} alt='Bizzell US'/>
                        <h4>Forgot Password</h4>
                    </div>
                    <div className='form-container'>
                        <Form>
                            <Row>
                                <Col>
                                    <SimpleInput
                                        label='Emai Address'
                                        type='email'
                                        inputValue={formData.emailAddress}
                                        onInputChange={handleInputChange}
                                        errors={errors}
                                        register={register}
                                        isRequired={true}
                                        errorText={"Email"}
                                        fieldName={'emailAddress'}
                                    />
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <SimpleInput
                                        label='Password'
                                        type='password'
                                        inputValue={formData.password}
                                        onInputChange={handleInputChange}
                                        errors={errors}
                                        register={register}
                                        isRequired={true}
                                        errorText={"Password"}
                                        fieldName={'password'}
                                    />
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <Button variant="primary" type="submit" onClick={handleSubmit(onSubmit, onErrors)}>Sign In</Button>
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <p className='form-actions'>
                                        <Link to="/forgotpassword"></Link>
                                        <Link to="/register">Sign Up</Link>
                                    </p>
                                </Col>
                            </Row>
                        </Form>
                    </div>
                </div>
                <div className='register-text'>
                    <p>Any company looking to grow thier<br/> workforce and connect with top talent.</p>
                </div>
            </div>
        </React.Fragment>
    )
}
export default ForgotPassword;