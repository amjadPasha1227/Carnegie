import React ,{useState,useEffect} from 'react'; 
import '.././Styles/scss/register.scss'
import Logo from "@/../../public/images/logo.png";

import SimpleInput from '../components/SimpleInput';
import { Col, Form, Row } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import { Link } from 'react-router-dom';
import { useForm, Controller } from 'react-hook-form';
import {sigin} from "./Apis"
import Toaster, { showToast } from './Utils';
import 'react-toastify/dist/ReactToastify.css';
import EyeClose from "@/../../public/images/icons/eye_close.png";
import EyeOpen from "@/../../public/images/icons/eye_open.png";
function Login() { 
     const { handleSubmit,clearErrors, formState: { errors },register,control } = useForm();
    const[formData,setFormData]=useState({
        email:'',
        password:'',
        file:''
    })
    const [showPassword, setShowPassword] = useState(false);
    // const [showToast, setShowToast] = useState({
    //     show:false,
    //     message:"",
    //     status:""
    // });
    useEffect(() => {
        document.body.classList.add('before-login')
        return () => {
          document.body.classList.remove('before-login')
        }
    }, [])
  
  const showPasswordIcon = () => {
        setShowPassword(!showPassword)
    };
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
    if (value) {
        clearErrors(name);
    }
    };
  
    function onSubmit(data) {

      fetch(sigin, {
        method: 'POST',
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(data) 
    }).then(response => response.json())
        .then((responseJson) => {
        // setShowToast({
        //     show: false,
        //     message: responseJson.message, 
        //     status: responseJson.status 
        //   });
        if (responseJson.status === 'success') {
            // Show a success message using the showToast function
            showToast(responseJson.message, 'success');
          } else {
            // Show an error message using the showToast function
            showToast(responseJson.message, 'error');
          }
        })
        .catch((error) => {
            console.error(error);
             // Show an error message
        showToast('An error occurred', 'error');
        });

    };

    const onErrors = (errors) => {
        console.log("errors are ", errors)
    }
    return (
        <React.Fragment>
            <div className='register'> 
                <div className='register_from'>
                    <div className='register-head'>
                        <img src={Logo} alt='Bizzell US'/>
                        <h4>Employer Sign-In</h4>
                    </div>
                    <div className='form-container'>
                        <Form>
                            <Row>
                                <Col>
                                <SimpleInput
                                        label='Emai Address'
                                        type='email'
                                        inputValue={formData.email}
                                        onInputChange={handleInputChange}
                                        errors={errors}
                                        register={register}
                                        isRequired={true}
                                        errorText={"Email"}
                                        fieldName={'email'}
                                    />
                                </Col> 
                            </Row>
                            <Row>
                                <Col>
                                <SimpleInput
                                        label='Password'
                                        type='password'
                                        //type={showPassword ? 'text' : 'password'}
                                        inputValue={formData.password}
                                        onInputChange={handleInputChange}
                                        errors={errors}
                                        register={register}
                                        isRequired={true}
                                        errorText={"Password"}
                                        fieldName={'password'}
                                        showIcon={true}
                                        onClickIcon={showPasswordIcon}
                                        showImageType={showPassword ? EyeOpen :EyeClose}
                                    />
                                </Col> 
                            </Row> 
                            <Row>
                                <Col>
                                    <Button variant="primary" type="button" onClick={handleSubmit(onSubmit, onErrors)}>Sign In</Button>
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <p className='form-actions'>
                                        <Link to="/forgotpassword">Forgot Password?</Link>
                                        <Link to="/register">Sign Up</Link>
                                    </p>
                                </Col>
                            </Row>
                        </Form>
                    </div>
                </div>
                <div className='register-text'>
                    <p>Any company looking to grow thier<br/> workforce and connect with top talent.</p>
                </div> 
            </div>
            <Toaster />
            {/* <ShowToast showToast={showToast} handleClose={() => setShowToast({ ...showToast, show: false })} /> */}
        </React.Fragment>
    )
}
export default Login;
