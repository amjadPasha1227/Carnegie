import React from 'react';


function Contact() {
    return(
        <div className='maincontent aboutcontent'>
            <div className=''>
                
            </div>
            Contact
        </div>
    )
}
export default Contact;