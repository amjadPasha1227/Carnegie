import React from 'react';
import '.././Styles/scss/Jobs.scss' 

function Jobs() {
    return (
        <React.Fragment>
             
            jobs
        </React.Fragment>
    )
}
export default Jobs;