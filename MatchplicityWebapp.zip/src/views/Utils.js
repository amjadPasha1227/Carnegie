// import Toast from 'react-bootstrap/Toast';
// import ToastContainer from 'react-bootstrap/ToastContainer';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { createContext, useContext, useEffect, useState } from 'react';
//  export function ShowToast({showToast,handleClose}){
//      return (
//          <div
//            aria-live="polite"
//           aria-atomic="true"
//            style={{ minHeight: '240px' }}
//          >
//            <ToastContainer position="top-end" className="p-3" style={{ zIndex: 1 }}>
//              <Toast bg={"success"} onClose={handleClose} show={showToast.show} delay={3000} autohide>
//               <Toast.Header>
//                  <img
//                    src="holder.js/20x20?text=%20"
//                    className="rounded me-2"
//                    alt=""
//                  />
//                  <strong className="me-auto">{showToast.status}</strong>
//                </Toast.Header>
//                <Toast.Body>{showToast.message}</Toast.Body>
//             </Toast>
//           </ToastContainer>
//         </div>
//        );
//  }
function Toaster() {
  return (
    <ToastContainer
      position="top-right"
      autoClose={3000}
      hideProgressBar
      newestOnTop={false}
      closeOnClick
      rtl={false}
      pauseOnFocusLoss
      draggable
      pauseOnHover
       />
  );
}

export function showToast(message, type) {
  switch (type) {
    case 'success':
      toast.success(message);
      break;
    case 'error':
      toast.error(message);
      break;
    default:
      toast(message);
  }
}

 const UserContext = createContext();
 export function useUserData() {
   return useContext(UserContext);
 }

 export function UserProvider({ children }) {
   const [userData, setUserData] = useState({ username: 'staticUsername'});

   useEffect(() => {
     const storedUser = localStorage.getItem('user');
     if (storedUser) {
       setUserData(JSON.parse(storedUser));
     }
   }, []);

   return (
     <UserContext.Provider value={{ userData }}>
       {children}
     </UserContext.Provider>
   );
 }
export default Toaster
