import React from 'react'; 
import { Link } from 'react-router-dom';

import '.././Styles/scss/footer.scss'

function Footer() { 
    return (
        <div className='footer'> 
            <ul>
                <li>
                    <Link  to="/dashboard">Home</Link> 
                </li>
                <li>
                    <Link  to="/about">About</Link> 
                </li>
                <li>
                    <Link  to="/contact">Contact US</Link> 
                </li>
                <li>
                    <Link  to="/projects">Projects</Link>
                </li>
            </ul>
        </div>
    )

}
export default Footer;