import React,{useState,useRef} from 'react'
import Files from 'react-files'
import { Controller, } from 'react-hook-form';
function FileUploader({register,fieldName,isRequired,id,control,errorText,errors}) { 
    const [files, setFiles] = useState([])
    const [validationRequired, setValidationRequired] = useState(isRequired)
    const fileRef = useRef(id)
    const handleChange = (newFiles) => {
      
      setValidationRequired(false)
      setFiles(prevFiles => [...prevFiles, ...newFiles])
    }
    const handleFileRemove = (fileId) => {
      setFiles(prevFiles => prevFiles.filter(prevFile => prevFile.id !== fileId))
      if(files.length===0){
         setValidationRequired(true)
      }
 
    }
    const validateFile = (file) => {
      console.log('validateFile')
         if(files.length===0){
            setValidationRequired(true)
         }
      //return true;
  };
    return (
       <div>
       {/* <Controller
          control={control}
          name={fieldName}
          variant="outlined"
          rules={{ required: files&&files.length>0?false:validationRequired}}
          render={({ field }) => (
          <Files              
             className="files-dropzone-list"
             dragActiveClassName="files-dropzone-active"
             style={{ height: '100px' }}
             onChange={handleChange}
             multiple
             maxFiles={3}
             ref={fileRef}
            // accepts={['image/png']}
             maxFileSize={10000000}
             minFileSize={0}
             >
             Drop files here or click to upload
          </Files>
                        )}
                    /> */}
           <Files
             className="files-dropzone-list"
             dragActiveClassName="files-dropzone-active"
             style={{ height: '100px' }}
             onChange={handleChange}
             multiple
             maxFiles={3}
           //  ref={fileRef}
             control={control}
            // accepts={['image/png']}
             maxFileSize={10000000}
             minFileSize={0}
             ref={register(fieldName, { required: validationRequired, validate: validateFile, })}
             >
             Drop files here or click to upload
          </Files>
          {files.length > 0 && (
             <div className="files-list">
                <ul>
                   {files.map(file => (
                      <li key={file.id} className="files-list-item">
                         <div className="files-list-item-preview">
                            <button  onClick={() => handleFileRemove(file.id)}>Remove Files</button>
                         </div>
                         <div className="files-list-item-content">
                            <div className="files-list-item-content-item files-list-item-content-item-1">{file.name}</div>
                         </div>
                      </li>
                   ))}
                </ul>
             </div>
          )}
          {files.length===0&&errors?.[fieldName] && errors?.[fieldName].type && errors?.[fieldName].type === "required" &&
        <span>{errorText + ' is reqired'}</span>}
        {errors[fieldName] && (
        <span className='form_error'>{errors[fieldName].message}</span>
        )}  
       </div>
    )
 }
  export default FileUploader;