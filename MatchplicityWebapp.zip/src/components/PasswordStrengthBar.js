import React, { useState } from 'react';
import PasswordStrength from 'react-password-strength-bar';
import SimpleInput from './SimpleInput';
import { useForm } from 'react-hook-form';
function PasswordStrengthBar({value}) {
  const [password, setPassword] = useState('');
  const {formState: { errors }, register } = useForm();
  // Update the password state when the input value changes
  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  return (
    <React.Fragment>
      {/* <SimpleInput
      label='Password'
      type='password'
      inputValue={password}
      onInputChange={handlePasswordChange}
      errors={errors}
      register={register}
      isRequired={true}
      errorText={"Password"}
      fieldName={'password'}                
       /> */}
      <PasswordStrength className='strengthbar' password={value} />
    </React.Fragment>
  );
}

export default PasswordStrengthBar;
