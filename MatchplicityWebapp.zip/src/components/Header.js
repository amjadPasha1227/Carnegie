import React from 'react'; 
import { Link } from 'react-router-dom';

import '.././Styles/scss/header.scss';
import Logo from "@/../../public/images/logo.png";
import { Nav } from 'react-bootstrap';

function Header() { 
    return (
        <div className='header'> 
            <div className='logo'>
                <Link  to="/dashboard"><img src={Logo} alt='Bizzell US'/></Link> 
            </div>
            <Nav className='nav-menu'>
                <ul>
                    <li>
                        <Link  to="/dashboard">Home</Link> 
                    </li>
                    <li>
                        <Link  to="/about">About</Link> 
                    </li>
                    <li>
                        <Link  to="/contact">Contact US</Link> 
                    </li>
                    <li>
                        <Link  to="/projects">Projects</Link>
                    </li>
                </ul>
            </Nav>
            <div className='header-actions'>
                <ul>
                    <li>
                        Notifications
                    </li>
                    <li>
                        Profile
                    </li>
                </ul>
            </div>
        </div>
    )

}
export default Header;