import React ,{useState}from "react";
import ReactQuill from "react-quill";
import QuillEditorToolbar, { modules, formats } from "../components/QuillEditorToolbar";
import "react-quill/dist/quill.snow.css";
import { Controller } from 'react-hook-form';
export const QuillEditor = ({fieldName,isRequired,placeholder,theme,register,errors,errorText,control}) => {
  const [state, setState] = useState({ value: null });
  const handleChange = value => {
    setState({ value });
  };
  return (
    <div className="text-editor">
      <QuillEditorToolbar />
      {/* <ReactQuill
        theme={theme}
        value={state.value}
        onChange={handleChange}
        placeholder={placeholder}
        modules={modules}
        formats={formats}
        control={control}
        {...register(fieldName, { required: isRequired,})}
      /> */}
      <Controller
        name={fieldName}
        control={control}
        rules={{ required: isRequired }}
        render={({ field }) => (
        <ReactQuill
        {...field}
        theme={theme}
        value={state.value}
        onChange={handleChange}
        placeholder={placeholder}
        modules={modules}
        formats={formats}
        
      />
        )}
      />
       {errors[fieldName] && (
        <span className="text-danger">{errorText} is required</span>
      )}
    </div>
  );
};

export default QuillEditor;
