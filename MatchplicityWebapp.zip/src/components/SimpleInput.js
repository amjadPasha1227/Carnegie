import React, { useState } from 'react';
import Form from 'react-bootstrap/Form';
import '.././Styles/scss/sampleInput.scss';
function SimpleInput({ label, fieldName, errors, inputValue, onInputChange, type, register, isRequired, errorText, showIcon, onClickIcon, showImageType }) {
  const [isPasswordVisible, setPasswordVisibility] = useState(false);
  // Validation function based on the input type
  const validateField = (value, type) => {
    if (type === 'email') {
      return validateEmail(value);
    }
    else if (type === 'password') {
      return validatePassword(value);
    }
    else if (type === 'phone number') {
      return validatePhoneNumber(value);
    }
    else {
      return value.length > 0;
    }
  };

  const validateEmail = (value) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(value)) {
      return 'Email is not in a valid format.';

    }
    return true;
  };

  const validatePassword = (value) => {
    const hasUppercase = /[A-Z]/.test(value);
    const hasLowercase = /[a-z]/.test(value);
    const hasSpecialCharacter = /[!@#$%^&*()_+]/.test(value);
    const hasNumber = /\d/.test(value);
    if (!(hasUppercase)) {
      return errorText + ' must contain at least one uppercase letter.'
    }
    if (!(hasLowercase)) {
      return errorText + ' must contain at least one lowercase letter.';
    }
    if (!(hasSpecialCharacter)) {
      return errorText + ' must contain at least one special character.';
    }
    if (!(hasNumber)) {
      return errorText + ' must contain at least one number.';
    }
    return true;
  };
  const validatePhoneNumber = (value) => {
    const phoneRegex = /^[0-9]{10}$/;

    if (!phoneRegex.test(value)) {
      return errorText + ' must be a 10-digit number.';
    }

    return true;
  };
  return (
    <React.Fragment>
      <div className='form-group'>
        <Form.Label htmlFor="basic-url">{label}</Form.Label>
        <Form.Control
          name={fieldName}
          type={type === 'password' ? (isPasswordVisible ? 'text' : 'password') : 'text'}
          aria-label="Disabled input example"
          defaultValue={inputValue}
          //onChange={onInputChange}
          {...register(fieldName, { required: isRequired, validate: (value) => validateField(value, type), onChange: onInputChange, })}
        />
        {/*{showIcon&&inputValue.length>0&&
                <span className='password_view' onClick={onClickIcon}><img src={showImageType} alt='Hide'/></span>
              } */}
        {showIcon &&
          <span className='password_view' onClick={() => { onClickIcon(); setPasswordVisibility(!isPasswordVisible) }}>
            <img src={showImageType} alt={isPasswordVisible ? 'Hide' : 'Show'} />
          </span>
        }
        {errors?.[fieldName] && errors?.[fieldName].type && errors?.[fieldName].type === "required" &&
          <span className='form-error'>{errorText + ' is required'}</span>}
        {type === 'password' && errors[fieldName] && (
          <span className='form-error'>{errors[fieldName].message}</span>
        )}
        {type === 'email' && errors[fieldName] && (
          <span className='form-error'>{errors[fieldName].message}</span>
        )}
        {type === 'phone number' && errors[fieldName] && (
          <span className='form-error'>{errors[fieldName].message}</span>
        )}
      </div>
    </React.Fragment>
  );
}

export default SimpleInput;
