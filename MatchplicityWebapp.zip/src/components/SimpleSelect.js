 import React ,{useState}from 'react';  
//import Select from 'react-select' 
import { Controller } from 'react-hook-form';
 import CreatableSelect from 'react-select/creatable';
function SimpleSelect({options,isMulti,placeholder,control,onChange,label,isrequired,isValidationRequired,selectedOption,className, errors, register, isRequired, errorText, fieldName }) { 
  const [selectedOptions, setSelectedOptions] = useState([]);

  const handleChange = (selectedOptions) => {
    setSelectedOptions(selectedOptions);
    console.log("errors are ", errors)
  };
    // const options = [
    //   { value: 1, label: 'React' },
    //   { value: 2, label: 'Angular' },
    //   { value: 3, label: 'Vue' },
    //   { value: 4, label: 'React Native' },
    //   { value: 5, label: 'Node' },
    // ]
      
      return (
        <div className='simpleselect_container'>
        { label && <label>{label}</label> }

        {/* <CreatableSelect 
        options={options}
       // closeMenuOnSelect={false}
        isMulti={isMulti}
        //controlShouldRenderValue={false}
       // hideSelectedOptions={false}
        //isClearable={true}
        //placeholder={selectedOptions.length==0?"Select Users":selectedOptions.length +" Users Selected"}
        placeholder={placeholder}
        value={selectedOptions}
       // onChange={onChange}
      //  onChange={handleChange}
        className={className?'simpleselect '+className:'simpleselect'}
        classNamePrefix='simpleselect'
        {...register(fieldName, { required: isRequired,onChange: handleChange, })}
      /> */}
  <Controller
        name={fieldName}
        control={control}
        rules={{ required: isRequired }}
        render={({ field }) => (
          <CreatableSelect
            {...field}
            options={options}
            isMulti={true}
            placeholder="Select Users"
            onChange={(selectedOptions) => {
              field.onChange(selectedOptions);
              handleChange(selectedOptions);
            }}
            className={className?'simpleselect '+className:'simpleselect'}
            classNamePrefix='simpleselect'
          />
        )}
      />
  
      {errors[fieldName] && (
        <span className="text-danger">{errorText} is required</span>
      )}
    </div>)

 }
 export default SimpleSelect;


