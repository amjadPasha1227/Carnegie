

const state = {
    status:'',
    token: localStorage.getItem('token') || '',
    user : JSON.parse(localStorage.getItem('user')) || [],
    userRole: localStorage.getItem('userRole') || '',
    windowWidth: null,
    selectedRequestsMenu:'ALL',
    filterStatuses:[]
  
}

export default state
