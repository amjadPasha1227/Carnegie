import _ from "lodash"
const mutations = {
      
      auth_success(state, details){
        state.status = 'success'
        state.token = details.accessToken
        state.user = details.user
        state.role_id = details.role_id
      
      },
     logout(state){
        state.status = ''
        state.token = ''
        state.user = null
        state.role_id = null
      },
      setRequestsMenu(state  , menuId){
        state.selectedRequestsMenu = menuId
      },
      setFilters(state,filters){
        state.filterStatuses=filters
      }
}

export default mutations
