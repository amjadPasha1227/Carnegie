<template>
  <div class="db_page">
    <!-- <div class="page_header">
      <h3>Evaluation Templates</h3>
    </div> -->
    <div class="filter_sec">
      <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" />

      <simpleSelect :multiple="true" :wrapclass="'req_status'" :optionslist="statusList" :display="true"
        :place-holder="'Status'" :searchable="false" :required="false" :close-on-select="false" :clear-on-select="true"
        v-model="filterSelectedStatuses" :fieldName="'filterStatus'" :cid="'filterStatus'" :hideSelected="true"
        @input="applyFilters" :listContainsId="true" />

      <customSelect :multiple="true" :wrapclass="'req_status'" :optionslist="filterUsersList" :display="true"
        :place-holder="'Professor'" :searchable="false" :required="false" :close-on-select="false" :clear-on-select="true"
        v-model="filterSelectedProfessors" :fieldName="'filterStatus'" :cid="'filterStatus'" :hideSelected="true"
        @input="applyFilters" :listContainsId="true" />

      <button class="filter_btn" v-if="false"><span></span><em>Filters</em></button>
      <div class="filters_right">
        <button class="add_btn" @click="showAddTemplatePopup(false)"><span></span><em>Create Template</em></button>
      </div>
    </div>
    <div class="table-responsive">
      <template v-if="checkProperty(emailsList, 'length') <= 0">
        <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Emails' :loading="isListLoading" />
      </template>
      <table class="table" v-if="checkProperty(emailsList, 'length') > 0 && !isListLoading">
        <thead>
          <tr>
            <th>Template ID #</th>
            <th>Title</th>
            <th>Professor</th>
            <th>Documents</th>
            <th>Created Date</th>
            <th class="center">Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, index) in emailsList" v-bind:key="index">
            <td>
              <span>{{ checkProperty(item, 'requestId') }}</span>
            </td>
            <td>
              <span>{{ checkProperty(item, 'title') }}</span>
            </td>
            <td>
              <span v-if="checkProperty(item, 'professorDetails', 'name')">{{ checkProperty(item,
                'professorDetails', 'name') }}</span>
            </td>
            <td>
              <div v-if="checkProperty(item, 'documents', 'length') > 0" class="document_list">
                <DocumentsPreview v-if="checkProperty(item, 'documents', 'length') > 3" :type="'documents'"
                  :documentsList="checkProperty(item, 'documents').slice(0, 3)" :includeDownloadText="false"
                  @download_or_view="download_or_view" />

                <DocumentsPreview v-else :type="'documents'" :documentsList="checkProperty(item, 'documents')"
                  :includeDownloadText="false" @download_or_view="download_or_view" />

                <em class="count" :id="'popover-target-' + index" v-if="checkProperty(item, 'documents', 'length') > 3">{{
                  '+' + (checkProperty(item, 'documents',
                    'length') - 3) }}</em>
                <b-popover custom-class="document_list_wrap" :target="'popover-target-' + index" triggers="hover"
                  placement="top" fallback-placement="flip">
                  <template>
                    <DocumentsPreview :type="'documents'" :documentsList="checkProperty(item, 'documents').slice(3)"
                      :includeDownloadText="false" @download_or_view="download_or_view" />
                    <!-- <ul>
                      <li><img src="@/assets/images/pdf-file-format.svg"></li>
                      <li><img src="@/assets/images/pdf-file-format.svg"></li>
                      <li><img src="@/assets/images/pdf-file-format.svg"></li>
                      <li><img src="@/assets/images/pdf-file-format.svg"></li>
                    </ul> -->
                  </template>
                </b-popover>
              </div>
            </td>
            <td><span>{{ checkProperty(item, 'createdOn') | formatDate }}</span></td>
            <td class="center"><span class="status " v-bind:class="{
              'active': checkProperty(item, 'statusDetails', 'id') == 1,
              'inactive': checkProperty(item, 'statusDetails', 'id') == 2,
            }">{{ checkProperty(item, 'statusDetails', 'name') }}</span>
            </td>
            <td>
              <div class="actions">
                <dropdownHover>
                  <b-dropdown-item v-if="checkProperty(item, 'statusId') == 1"
                    @click="showDetailsPopup(item)">View</b-dropdown-item>
                  <b-dropdown-item @click="selectedTemplate = item; showAddTemplatePopup(true)">Edit</b-dropdown-item>
                  <b-dropdown-item @click="selectedTemplate = item; showStatusChangePopup = true">{{
                    checkProperty(item, 'statusId') == 1
                    ? 'Inactivate' : 'Activate'
                  }}</b-dropdown-item>
                </dropdownHover>
              </div>
            </td>
          </tr>

          <!-- <tr>
            <td>
              <span>T-5153</span>
            </td>
            <td>
              <span>Test Email Template</span>
            </td>
            <td>
              <div class="document_list">
                <ul>
                  <li><img src="@/assets/images/pdf-file-format.svg"></li>
                  <li><img src="@/assets/images/pdf-file-format.svg"></li>
                  <li><img src="@/assets/images/pdf-file-format.svg"></li>
                </ul>
                <em class="count" id="popover-target-2">+4</em>
                <b-popover custom-class="document_list_wrap" target="popover-target-2" triggers="hover" placement="top"
                  fallback-placement="flip">
                  <template>
                    <ul>
                      <li><img src="@/assets/images/pdf-file-format.svg"></li>
                      <li><img src="@/assets/images/pdf-file-format.svg"></li>
                      <li><img src="@/assets/images/pdf-file-format.svg"></li>
                      <li><img src="@/assets/images/pdf-file-format.svg"></li>
                    </ul>
                  </template>
                </b-popover>
              </div>
            </td>
            <td><span>3 Mar 2023</span></td>
            <td class="center"><span class="status inactive">Active</span></td>
            <td>
              <div class="actions">
                <dropdownHover>
                  <b-dropdown-item>Edit</b-dropdown-item>
                  <b-dropdown-item>Update Status</b-dropdown-item>
                </dropdownHover>
              </div>
            </td>
          </tr> -->
        </tbody>
      </table>
      <div class="pagination-sec" v-if="checkProperty(emailsList, 'length') > 0">
        <div class="per-page">
          <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) +
            emailsList.length) +
            ' of ' + totalCount + ' Results' }}</label>
        </div>
        <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
          @input="getEmailsList"></b-pagination>
      </div>
    </div>

    <!-- Create Template Modal -->
    <b-modal v-model="showAddTemplate" id="create_template" dialog-class="create_template" centered no-close-on-backdrop>
      <template #modal-header>
        <h6 class="modal-title">{{ isTemplateEdit ? 'Edit Template' : 'Create Template' }}</h6>
        <a class="close" @click="showAddTemplate = false; isFileUplading = false"></a>
      </template>
      <template>
        <div class="user_form create_temp">
          <div class="row">

            <div class="col-md-12">
              <customSelect :multiple="false" :wrapclass="'req_status mb-3'" :optionslist="usersList" :display="true"
                :place-holder="'Select Professor'" :searchable="false" :required="true" :close-on-select="true"
                :clear-on-select="false" class="mb-0 ass-eval" v-model="templateProfessor" :fieldName="'evaluator'"
                :cid="'evaluator'" :label="'Select Professor'" :vvas="'Professor'" :trackBy="'tempName'" />
            </div>

            <div class="col-md-12">
              <simpleInput :wrapclass="'mb20'" :fieldName="'title'" :cid="'title'" :label="'Title'" :placeHolder="'Title'"
                :vvas="'Title'" :display="true" :required="true" v-model="templateTitle" />
            </div>
            <div class="col-md-12 position-relative">
              <fileUploadDrag :label="'Template Document*'" :wrapclass="'mb-0'" :multiple="false" :required="true"
                :tplkey="'templateDocs'" v-model="templateDocuments" :tplsection="'templateDocs'" vvas="Template Document"
                :fieldName="'templateDocs'" :cid="'templateDocs'" @uploadingFile="checkFileUploading($event)" />
              <input type="hidden" class="form-control" v-validate="'required'" v-model="templateDocuments"
                data-vv-as="Template Document" :name="'templateDocument'" />
              <span v-show="errors.has('templateDocument')" class="form-error">{{
                errors.first('templateDocument')
              }}</span>
            </div>
            <div class="col-md-12" v-if="false">
              <textArea :label="'Content'" :wrapclass="'h80 mb10'" placeHolder="Content" v-model="templateContent"
                :fieldName="'emailContent'" :cid="'emailContent'"></textArea>
            </div>
          </div>
        </div>
      </template>
      <template #modal-footer>

        <button class="form-cancel" @click="showAddTemplate = false; isFileUplading = false">Cancel</button>
        <button class="primary_btn md" :disabled="isFileUplading" @click="submitEmailTemplate">{{ isTemplateEdit ?
          'Update' : 'Create' }}
          <span class="loader" v-if="isLoading"><img src="@/assets/images/loader.gif"></span>
        </button>
      </template>
    </b-modal>

    <!-- active inactive Modal -->
    <b-modal v-model="showStatusChangePopup" id="active_inactive_model" dialog-class="active_inactive_model" centered
      no-close-on-backdrop>
      <template #modal-header>
        <h6 class="modal-title">
          {{ checkProperty(selectedTemplate, 'statusId') == 1 ? 'Inactivate' : 'Activate' }}
        </h6>
        <a class="close" @click="showStatusChangePopup = false"></a>
      </template>
      <template>
        <p class="confirm_msg">Do you want to {{ checkProperty(selectedTemplate, 'statusId') == 1 ? 'Inactivate the template' :'Activate the template' }}?</p>
      </template>
      <template #modal-footer>
        <button class="form-cancel" @click="showStatusChangePopup = false">No</button>
        <button class="primary_btn" @click="changeStatus">Yes</button>
      </template>
    </b-modal>

    <!-- Details Modal -->
    <b-modal v-model="showTemplateDetails" id="create_template" dialog-class="create_template email_model" centered
      hide-footer no-close-on-backdrop>
      <template #modal-header>
        <h6 class="modal-title">{{ isTemplateEdit ? 'Edit Template' : 'View Template' }}</h6>
        <a class="close" @click="showTemplateDetails = false"></a>
      </template>
      <template>
        <div class="row">
          <div class="col-md-12">
            <div class="form_group" v-if="checkProperty(selectedTemplate, 'title')">
              <lable class="form_label">Title</lable>
              <p>{{ checkProperty(selectedTemplate, 'title') }}</p>
            </div>
            <div class="form_group" v-if="checkProperty(selectedTemplate, 'content')">
              <lable class="form_label">Content</lable>
              <p>{{ checkProperty(selectedTemplate, 'content') }}</p>
            </div>
            <div class="form_group" v-if="checkProperty(selectedTemplate, 'content')">
              <lable class="form_label">Documents</lable>
              <DocumentsPreview v-if="checkProperty(selectedTemplate, 'documents', 'length') > 0" :type="'documents'"
                :documentsList="checkProperty(selectedTemplate, 'documents')" :includeDownloadText="false"
                @download_or_view="download_or_view" />
            </div>
          </div>
        </div>
      </template>
    </b-modal>

    <b-modal id="preview_model" v-model="docPrivew" dialog-class="document_modal"
      :title="checkProperty(selectedFile, 'name')">
      <h2> <img :class="{
        pdf_view_download: docType == 'pdf',
        office_view_download: docType == 'office',
        image_view_download: docType == 'image',
      }" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>
      <div class="pdf_loader">
        <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/loader.gif" /></figure>

        <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
        <template v-if="docType == 'office'">
          <div style="height:90vh">

            <div id="placeholder" style="height:100%"></div>
          </div>
        </template>
        <template v-else-if="docType == 'image'">
          <img :src="docValue" />
        </template>
        <template v-else-if="docType == 'pdf'">
          <div class="pdf" style="height:90vh">

            <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%" width="100%">

            </iframe>
          </div>
        </template>
      </div>
    </b-modal>


  </div>
</template>

<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import dropdownHover from '@/views/forms/dropdownHover.vue';
import textArea from "@/views/forms/textarea.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDropDocs.vue";
import DocumentsPreview from './common/documentsPreview.vue';
import NoDataFound from "@/views/common/noData.vue";
import customSelect from '@/views/forms/customSelect.vue';


export default {
  name: 'emailtemplate-view',
  components: {
    searchInput,
    simpleSelect,
    dropdownHover,
    simpleInput,
    textArea,
    fileUploadDrag,
    DocumentsPreview,
    NoDataFound,
    customSelect
  },
  data: () => ({
    page: 1,
    perpage: 20,
    totalCount: 0,
    templateTypeList: [],
    templateType: null,
    templateTitle: '',
    templateContent: '',
    templateDocuments: null,
    templateProfessor: null,
    showAddTemplate: false,
    isLoading: false,
    emailsList: [],
    statusList: [],
    filterEmailTypes: [],
    filterSelectedStatuses: [],
    filterSelectedEmailTypes: [],
    filterSearch: '',
    selectedTemplate: null,
    isTemplateEdit: false,
    showStatusChangePopup: false,
    showTemplateDetails: false,
    docPrivew: false,
    docType: '',
    formSubmited: false,
    docPrivew: false,
    docType: '',
    selectedFile: null,
    isFileUplading: false,
    usersList: [],
    filterUsersList:[],
    filterSelectedProfessors: [],
  }),
  methods: {
    gotoPage(path = "/") {
      this.$router.push(path);
    },
    getMasterDataList(category) {
      this.$store.dispatch("getMasterData", category)
        .then((res) => {
          if (category == 'email_template_types') {
            this.templateTypeList = [...res]
            this.filterEmailTypes = [...res]
          }
          if (category == 'email_template_status') {
            this.statusList = [...res]
          }
        })
    },
    showAddTemplatePopup(isEdit = false) {
      this.templateType = null
      this.templateTitle = ''
      this.templateContent = ''
      this.templateDocuments = null
      this.isLoading = false
      this.isTemplateEdit = false
      this.templateProfessor = null
      if (isEdit) {
        this.isTemplateEdit = true
        this.templateType = this.selectedTemplate.typeDetails
        this.templateTitle = this.selectedTemplate.title
        this.templateContent = this.selectedTemplate.content
        if (this.checkProperty(this.selectedTemplate, 'professorDetails')) {
          this.templateProfessor = this.checkProperty(this.selectedTemplate, 'professorDetails')
        }
        if (this.checkProperty(this.selectedTemplate, 'documents', 'length') > 0) {
          this.templateDocuments = this.selectedTemplate.documents
        }
      }
      this.showAddTemplate = true
    },
    submitEmailTemplate() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          this.isLoading = true
          let postData = {
            "title": this.templateTitle,
            "content": this.templateContent,
            "professorId": this.templateProfessor['_id'],
            "documents": []
          }
          if (this.checkProperty(this.templateDocuments, "length")) {
            postData.documents = this.templateDocuments
          }

          if (this.isTemplateEdit) {
            postData.evaluationTempId = this.selectedTemplate._id
          }

          if (this.isTemplateEdit) {
            this.$store
              .dispatch("updateEvaluationTemplate", postData)
              .then((response) => {
                if (response.error) {
                  this.isLoading = false
                  this.showToster({ message: response.error.message, isError: true });
                } else {
                  this.isTemplateEdit = false
                  this.isLoading = false
                  this.showToster({ message: response.message, isError: false });
                  this.page = 1
                  this.getEmailsList()
                  this.showAddTemplate = false
                }
              })
              .catch((error) => {
                this.isLoading = false
                this.showToster({ message: error, isError: true });
              });

          } else {
            this.$store
              .dispatch("addEvaluationTemplate", postData)
              .then((response) => {
                if (response.error) {
                  this.isLoading = false
                  this.showToster({ message: response.error.message, isError: true });
                } else {
                  this.isLoading = false
                  this.showToster({ message: response.message, isError: false });
                  this.page = 1
                  this.getEmailsList()
                  this.showAddTemplate = false
                }
              })
              .catch((error) => {
                this.isLoading = false
                this.showToster({ message: error, isError: true });
              });
          }


        }
      })
    },
    getEmailsList() {

      let statusIds = []
      let typeIds = []
      let professorIds=[]
      if (this.filterSelectedStatuses && this.checkProperty(this.filterSelectedStatuses, 'length') > 0) {
        statusIds = this.filterSelectedStatuses.map((item) => item.id)
      }

      if (this.filterSelectedProfessors && this.checkProperty(this.filterSelectedProfessors, 'length') > 0) {
        professorIds = this.filterSelectedProfessors.map((item) => item['_id'])
      }
      if (this.filterSelectedEmailTypes && this.checkProperty(this.filterSelectedEmailTypes, 'length') > 0) {
        typeIds = this.filterSelectedEmailTypes.map((item) => item.id)
      }
      let postData = {
        "matcher": {
          "title": this.filterSearch,
          "statusIds": statusIds,
          "typeIds": typeIds,
          "professorIds":professorIds,
          "createdByIds": [],
          "createdDateRange": []
        },
        "sorting": {
          "path": "createdOn", //title, statusName, createdByName, updatedOn, 
          "order": -1
        },
        "page": this.page,
        "perpage": this.perpage
      }


      this.$store.dispatch("getEvaluationTemplatesList", postData)
        .then((res) => {
          this.emailsList = res.data.result.list
          if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
            this.totalCount = this.checkProperty(res.data.result, 'totalCount');
          }
          this.isListLoading = false
          setTimeout(() => {
            this.updateLoading(false);
          })
        })
        .catch((error) => {
          this.isListLoading = false
          setTimeout(() => {
            this.updateLoading(false);
          })
        })

    },
    applyFilters() {
      this.isListLoading = true
      this.updateLoading(true);
      this.page = 1
      this.getEmailsList()
    },
    applySearchFilters() {
      this.isListLoading = true
      this.updateLoading(true);
      this.page = 1
      if (this.filterSearch && this.filterSearch.length > 2) {
        this.getEmailsList()
      }
      if (this.filterSearch == '') {
        this.getEmailsList()
      }
    },
    changeStatus() {

      this.showLoader = true;
      let payload = {
        "evaluationTempId": "",
        "statusId": 2, // 3. Inactive, 4.Delete
        "comment": ''
      }
      payload['evaluationTempId'] = this.selectedTemplate['_id'];
      if ([1].indexOf(this.selectedTemplate.statusId) > -1) {
        payload['statusId'] = 2
      } else {
        payload['statusId'] = 1
      }
      this.$store.dispatch("commonAction", { data: payload, path: "evaluation-template/update-status", })
        .then((response) => {
          this.showToster({ message: response.message, isError: false })
          this.showLoader = false;
          this.showStatusChangePopup = false;
          this.applyFilters();

        }).catch((error) => {
          this.showToster({ message: error.message, isError: true })
          this.showLoader = false;
          this.showStatusChangePopup = false

        });

    },
    showDetailsPopup(emailTemplate) {
      this.selectedTemplate = emailTemplate
      this.showTemplateDetails = true


    },
    download_or_view(docItem) {

      let value = _.cloneDeep(docItem);
      // if (this.checkProperty(this.getPetitionDetails, 'caseNo') && this.checkProperty(value, 'name')) {
      //   let docName = _.cloneDeep(value['name']);
      //   value['name'] = this.checkProperty(this.getPetitionDetails, 'caseNo') + "_" + docName;
      // }


      var _self = this;
      this.formSubmited = false;
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }
      // value = Object.assign(value, { 'petitionId': this.petition['_id'] })
      // value = Object.assign(value, { 'subTypeDetails': this.petition['subTypeDetails'] })


      this.selectedFile = value;
      this.docValue = "";
      this.docPrivew = false;
      this.docType = false;
      this.docType = this.findmsDoctype(value["name"], value.mimetype);

      if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
        //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
          // "petitionId": value['petitionId'],

          // entityType:value['petitionId']
          "fileName": value.name ? value.name : ''
        };
        // if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
        //   postdata['entityType'] = 'perm'
        // } else {
        //   postdata['entityType'] = 'case'
        // }


        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;


          if (this.docType == "office") {
            this.docPrivew = true;
            setTimeout(() => {
              document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
              let _editing = false;

              // if ([3, 4].indexOf(this.getUserRoleId) > -1) {
              //   _editing = false;
              // }

              // if (value.viewmode) {
              //   _editing = false;
              // }
              var _ob = {}
              // if (value.editedDocument) {
              //   _ob = {

              //     evaluationId: this.evaluationDetails._id,
              //     name: value.name,
              //     _id: value._id,
              //     "extn": "docx",
              //     "formLetterType": "Letter",
              //     parentId: value.parentId
              //   }

              // } else {

              _ob = {

                name: value.name,
                _id: value._id,
                "extn": "docx",
                "formLetterType": "Letter",
                parentId: value._id

              }

              //  }


              window.docEditor = new DocsAPI.DocEditor("placeholder2",
                {

                  "document": {
                    "c": "forcesave",
                    "fileType": "docx",
                    "key": value._id,
                    "userdata": JSON.stringify(_ob),
                    "title": value.name,
                    "url": response.data.result.data,
                    permissions: {
                      edit: _editing,
                      download: true,
                      reader: false,
                      review: false,
                      comment: false
                    }
                  },

                  "documentType": "word",
                  "height": "100%",
                  "width": "100%",

                  "editorConfig": {
                    "userdata": JSON.stringify(_ob),
                    "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                    "customization": {
                      "logo": {
                        "image": "https://immibox.com/app/favicon.png",
                        "imageDark": "https://immibox.com/app/favicon.png",
                        "url": "https://immibox.com"
                      },
                      "anonymous": {
                        "request": false,
                        "label": "Guest"
                      },
                      "chat": false,
                      "comments": false,
                      "compactHeader": false,
                      "compactToolbar": true,
                      "compatibleFeatures": false,
                      "feedback": {
                        "visible": false
                      },
                      "forcesave": true,
                      "help": false,
                      "hideNotes": true,
                      "hideRightMenu": true,
                      "hideRulers": true,
                      layout: {
                        toolbar: {
                          "collaboration": false,
                        },
                      },
                      "macros": false,
                      "macrosMode": "warn",
                      "mentionShare": false,
                      "plugins": false,
                      "spellcheck": false,
                      "toolbarHideFileName": true,
                      "toolbarNoTabs": true,
                      "uiTheme": "theme-light",
                      "unit": "cm",
                      "zoom": 100
                    },
                  }, events: {
                    onReady: function () {

                    },
                    onDocumentStateChange: function (event) {
                      var url = event.data;
                      console.log(event)

                      if (!event.data) {

                        if (value.editedDocument) {

                        }

                      }
                    }

                  }
                });
              //this.docValue = encodeURIComponent(response.data.result.data);
            }, 100)
          }

          if (this.docType == "pdf") {

            // this.downloadFile(this.docValue, value.mimetype, value.name)

            // return
            var _vid = value._id;
            if (value.parentId) {
              _vid = value.parentId;
            }
            var viewmode = 1; // Enable edit
            viewmode = 0; //Disabled Edit
            if (value.viewmode) {
              viewmode = 0;
            }
            this.docValue = "https://carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
            console.log(this.docValue)
            this.docPrivew = true;
          }
          if (this.docType == "image") {
            this.docPrivew = true;
          }



        });
      } else {



        this.downloads3file(value);
      }

    },
    checkFileUploading() {
      let uploading = false
      let resultDocs = _.filter(this.templateDocuments, (docItem) => {
        return this.checkProperty(docItem, 'fileUploading') && docItem.fileUploading
      })
      console.log('resultDocs' + JSON.stringify(resultDocs))
      if (this.checkProperty(resultDocs, 'length') > 0) {
        if (!uploading) {
          uploading = true
        }
      }
      this.isFileUplading = uploading
    },
    getUsers() {
      let postData =
      {
        "matcher": {
          "title": '',
          "searchString": "",
          "statusList": [],
          "createdByIds": [],
          "createdDateRange": [],
          "roleIds": [9],
          "statusIds": [],
          "typeIds": [],
          "departmentIds": []
        },
        "sorting": {
          "path": "createdOn",
          "order": -1
        },
        "getMasterData": true,// if Masterdata required
        "page": 1,
        "perpage": 500,
      }
      this.$store.dispatch("getUsersList", postData)
        .then((res) => {
          // let lst = []
          // _.forEach(res.data.result.list, (item) => {
          //     item['tempName'] = item['name'];
          //     if (_.has(item, "name") && _.has(item, "roleName")) {
          //         item.tempName = item.name + " (" + item.roleName + ")";
          //         lst.push(item);
          //     }
          // });
          // this.usersList = lst;

          this.usersList = res.data.result.list
          this.filterUsersList=[...res.data.result.list]
        })
        .catch((error) => {
        })
    },
  },
  mounted() {
    // this.getMasterDataList('email_template_types')
    this.isListLoading = true
    this.updateLoading(true);
    this.getMasterDataList('email_template_status')
    this.getEmailsList()
    this.getUsers()
  },
  computed: {

  },
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },


}
</script>