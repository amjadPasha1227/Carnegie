<template>
  <div class="side_menu">
    <div class="logo">
      <a @click="gotoPage([5].indexOf(getUserRoleId) < 0 ? '/dashboard' : '/evaluations-list')">
        <img src="@/assets/images/logo_carne.png">
      </a>
    </div>
    <VuePerfectScrollbar>
      <ul class="menu">
        <li v-if="[5].indexOf(getUserRoleId) < 0" :class="{ 'active': currentRouteName == 'dashboardView' }"
          @click="gotoPage('/dashboard')" class="dashboard">
          <a href="javascript:;">Dashboard</a>
        </li>
        <li class="requests"
          :class="{ 'active': (currentRouteName == 'Evaluations' || currentRouteName == 'requestdetails' || currentRouteName == 'create-evaluation') }">
          <a @click="gotoSubMenuPage()"> Evaluations</a>
          <ul v-if="[3, 4, 7, 6, 8].indexOf(getUserRoleId) > -1">

            <li
              :class="{ 'active': ((currentRouteName == 'Evaluations' || currentRouteName == 'requestdetails' || currentRouteName == 'create-evaluation') && $store.state.selectedRequestsMenu == statusItem.id) }"
              v-for="(statusItem, indx) in statusList" v-on:click.stop.prevent="gotoSubMenuPage(statusItem)"
              v-if="!([6].indexOf(getUserRoleId) > -1 && statusItem.id == 1)">
              <a>{{ statusItem.name }}</a>
            </li>
          </ul>
        </li>
        <li class="reports" v-if="false">
          <a href="#">Reports</a>
          <ul>
            <li><a href="#">Weekly Stats</a></li>
            <li><a href="#">Source of Leads</a></li>
          </ul>
        </li>
        <!-- <li class="payments">
            <a href="#">Payments</a>
          </li> -->
        <li @click="gotoPage('/customerdetails')" class="customers"
          :class="{ 'active': currentRouteName == 'customerdetailsView' }">
          <a href="javascript:;">Client</a>
        </li>
        <li @click="gotoPage('/client-users')" class="customers"
          :class="{ 'active': currentRouteName == 'clientUsersList' }">
          <a href="javascript:;">Client Users</a>
        </li>
        <li v-if="[3, 4, 7, 8].indexOf(getUserRoleId) > -1" @click="gotoPage('/invoices')" class="invoices"
          :class="{ 'active': currentRouteName == 'invoices' }">
          <a href="javascript:;">Invoices </a>
        </li>
        <li v-if="[3].indexOf(getUserRoleId) > -1" @click="gotoPage('/userdetails')" class="users"
          :class="{ 'active': currentRouteName == 'userdetailsView' }">
          <a href="javascript:;">Users</a>
        </li>
        <li v-if="[3, 4, 7].indexOf(getUserRoleId) > -1" @click="gotoPage('/emailtemplate')" class="email_templates"
          :class="{ 'active': currentRouteName == 'emailtemplateView' }">
          <a href="javascript:;">Email Templates</a>
        </li>
        <li  @click="gotoPage('/evaltemplates')" class="evaluation_templates"
          :class="{ 'active': currentRouteName == 'evaluation-templates' }">
          <a href="javascript:;">Evaluation Templates</a>
        </li>
        <li  @click="gotoPage('/repository')" class="evaluation_templates"
          :class="{ 'active': currentRouteName == 'filesRepository' }">
          <a href="javascript:;">Repository</a>
        </li>
        <li @click="gotoPage('/emails')" class="emails" :class="{ 'active': currentRouteName == 'emailsView' }">
          <a href="javascript:;">Emails</a>
        </li>
      </ul>
    </VuePerfectScrollbar>
    <div v-if="false" class="bottom_cnt">
      <ul>
        <li class="help">
          <a href="#">Help</a>
        </li>
      </ul>
    </div>
  </div>
</template> 
<script>
import JQuery from "jquery";
import VuePerfectScrollbar from 'vue-perfect-scrollbar'
export default {
  name: 'side-bar',
  computed: {

    getCurrentUserPermissions() {

      return (itemId) => {


        let returnVal = false;
        if (_.has(this.$store.state, 'user')) {
          let user = _.cloneDeep(this.$store.state['user']);


          if (user && _.has(user, 'modules') && user['modules'].length > 0) {
            if (_.find(user['modules'], { '_id': itemId }) || user['role_id'] == 1) {
              returnVal = true;
            }

          } else {
            returnVal = true;
          }

        } else {
          returnVal = true;

        }
        return returnVal;
      }

    }
  },
  components: {
    VuePerfectScrollbar,

  },
  data: () => ({
    statusList: [
      {
        "_id": "64587b20224f0b4aa05fe65d",
        "id": 1,
        "name": "Requested",
        "sortName": "requested"
      },
      {
        "_id": "64587b20224f0b4aa05fe65e",
        "id": 3,
        "name": "Confirmed",
        "sortName": "confirmed"
      },
      {
        "_id": "64587b20224f0b4aa05fe664",
        "id": 9,
        "name": "Offshore",
        "sortName": "evaluator assigned"
      },
      {
        "_id": "64587b20224f0b4aa05fe666",
        "id": 10,
        "name": "Onsite",
        "sortName": "reviewer assigned"
      },
      {
        "_id": "64587b20224f0b4aa05fe667",
        "id": 12,
        "name": "With Professor",
        "sortName": "with professor"
      },
      {
        "_id": "64587b20224f0b4aa05fe667",
        "id": 14,
        "name": "Professor Approved",
        "sortName": "with professor"
      },
      {
        "_id": "64587b20224f0b4aa05fe667",
        "id": 15,
        "name": "Final Review",
        "sortName": "Final Review"
      },
      {
        "_id": "64587b20224f0b4aa05fe668",
        "id": 16,
        "name": "Delivered",
        "sortName": "delivered to client"
      },
    ],
    setRequestsMenu: "ALL",
    currentRouteName: 'dashboardView'
  }),
  methods: {
    gotoPage(path = '/') {
      this.$store.commit("setRequestsMenu", "ALL");
      this.$router.push(path)
    },
    gotoSubMenuPage(statusItem) {

      this.setRequestsMenu = "ALL";

      if (this.checkProperty(this.$router.currentRoute, 'name') == 'Evaluations') {
        if (this.checkProperty(statusItem, "id")) {
          this.$store.commit("setRequestsMenu", statusItem.id)
        } else {
          this.$store.commit("setRequestsMenu", "ALL")
        }
      } else {
        //  alert(this.$router.currentRoute.name)
        if (this.checkProperty(statusItem, "id")) {
          this.$store.commit("setRequestsMenu", statusItem.id)
          this.setRequestsMenu = statusItem.id;
        } else {
          this.$store.commit("setRequestsMenu", "ALL");
        }
        setTimeout(() => {
          this.$router.push({ name: 'Evaluations', params: { 'statusId': "" } })
        }, 500);

      }


    },
    getMasterDataList(category) {

      this.$store.dispatch("getMasterData", category)
        .then((res) => {
          if (category == 'evaluation_status') {
            this.statusList = res
          }
        })
    },

  },
  mounted() {
    const $ = JQuery;
    $("button").click(function () {
      $("p").toggleClass("main");
    });

    //  this.getMasterDataList('evaluation_status')
    this.$watch("$route", function (value) {

      if (this.checkProperty(this.$router.currentRoute, 'name') == 'requestdetails' || this.checkProperty(this.$router.currentRoute, 'name') == 'create-evaluation') {
        this.setRequestsMenu = localStorage.getItem('subMenuId')
      } else {
        localStorage.setItem('subMenuId', "ALL")
      }

      this.currentRouteName = this.checkProperty(this.$router.currentRoute, 'name')
      this.$store.commit("setRequestsMenu", this.setRequestsMenu);
    })
    if (this.checkProperty(this.$router.currentRoute, 'name')) {
      this.currentRouteName = this.checkProperty(this.$router.currentRoute, 'name')
    }
  },

}
</script>

