<template>
    <div class="list-elements">
        <!-- <h4>{{ type | formatdoctype }}</h4> -->

        <ul>
            <li class="download_view_v2" v-for="(item, ind ) in  documentsList"
                v-b-tooltip.hover="checkProperty(item, 'name')" v-b-tooltip="{ customClass: 'docs_tooltip' }">

                <figure v-if="!includeDownloadText">
                    <img v-if="checkFileFormat(item['mimetype']) == 'pdf'" src="@/assets/images/main/pdf.svg" />
                    <img v-else-if="checkFileFormat(item['mimetype']) == 'video_mime_types'"
                        src="@/assets/images/main/film.png" />
                    <img v-else-if="checkFileFormat(item['mimetype']) == 'msDoc'" src="@/assets/images/main/doc.svg" />
                    <img v-else-if="checkFileFormat(item['mimetype']) == 'zip'"
                        src="@/assets/images/main/zip-file-format.png" />
                    <img v-else-if="checkFileFormat(item['mimetype']) == 'msPpt'" src="@/assets/images/main/ppt.svg" />
                    <img v-else-if="checkFileFormat(item['mimetype']) == 'msXl'" src="@/assets/images/main/xls.svg" />
                    <img v-else-if="checkFileFormat(item['mimetype']) == 'image'" src="@/assets/images/main/image.svg" />
                    <img v-else src="@/assets/images/main/icon-img.svg" />
                    <!-- <span class="download_icon_v2">
                        <span class="d-flex">
                            <span  v-if="checkFileFormat(item['mimetype']) == 'pdf' && showconvert"
                                @click="pdftowordconvert(item, checkProperty(item, 'name'))"><img
                                    class="download_img doc_img" src="@/assets/images/main/doc_file.png"></span>
                            <span @click="downloadInteral(item)"><img class="download_img"
                                    src="@/assets/images/main/download.png"></span>
                        </span>
                        <span @click="downloadfile(item)"><img class="view_img"
                                src="@/assets/images/main/view_hover.svg"></span>
                    </span> -->
                </figure>
                <div class="download_icon_v2">
                        <div v-if="checkFileFormat(item['mimetype']) == 'pdf' && showconvert"
                                @click="pdftowordconvert(item, checkProperty(item, 'name'))">
                            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="38" viewBox="0 0 30 38" class="word_icon">
                                <g id="Group_5409" data-name="Group 5409" transform="translate(-3165.335 -5916)">
                                    <g id="google-docs" transform="translate(3104.335 5916)" opacity="0.5">
                                    <path id="Path_10030" data-name="Path 10030" d="M88.113,8.746,79.676.309A1.056,1.056,0,0,0,78.93,0H64.164A3.168,3.168,0,0,0,61,3.164V32.836A3.168,3.168,0,0,0,64.164,36H85.258a3.168,3.168,0,0,0,3.164-3.164V9.492A1.064,1.064,0,0,0,88.113,8.746ZM79.984,3.6l4.837,4.837H81.039a1.056,1.056,0,0,1-1.055-1.055Zm5.273,30.29H64.164a1.056,1.056,0,0,1-1.055-1.055V3.164a1.056,1.056,0,0,1,1.055-1.055H77.875V7.383a3.168,3.168,0,0,0,3.164,3.164h5.273V32.836A1.056,1.056,0,0,1,85.258,33.891Z" transform="translate(0)" fill="#8a8f8d"/>
                                    <path id="Path_10031" data-name="Path 10031" d="M164.751,212H152.058a1.051,1.051,0,1,0,0,2.1h12.693a1.051,1.051,0,1,0,0-2.1Z" transform="translate(-83.693 -197.091)" fill="#8a8f8d"/>
                                    <path id="Path_10032" data-name="Path 10032" d="M164.751,272H152.058a1.051,1.051,0,1,0,0,2.1h12.693a1.051,1.051,0,1,0,0-2.1Z" transform="translate(-83.693 -252.871)" fill="#8a8f8d"/>
                                    <path id="Path_10033" data-name="Path 10033" d="M164.751,332H152.058a1.051,1.051,0,1,0,0,2.1h12.693a1.051,1.051,0,1,0,0-2.1Z" transform="translate(-83.693 -308.651)" fill="#8a8f8d"/>
                                    <path id="Path_10034" data-name="Path 10034" d="M160.46,392h-8.409a1.051,1.051,0,1,0,0,2.1h8.409a1.051,1.051,0,1,0,0-2.1Z" transform="translate(-83.658 -364.432)" fill="#8a8f8d"/>
                                    </g>
                                    <rect id="Rectangle_2990" data-name="Rectangle 2990" width="24" height="12" rx="1" transform="translate(3171.335 5942)" fill="#5392d6"/>
                                    <text id="DOC" transform="translate(3175.335 5951)" fill="#fff" font-size="8" font-family="NiveauGroteskBold, Niveau Grotesk"><tspan x="0" y="0">DOC</tspan></text>
                                </g>
                                </svg>
                                <em>Word Conversion</em>
                        </div>
                        <div @click="downloadInteral(item)">
                            <svg xmlns="http://www.w3.org/2000/svg" class="download_icon" width="18" height="18" viewBox="0 0 22 19"><g class="a" transform="translate(-5 -8)"><path class="b" d="M7,18v7H25V18h2v9H5V18ZM17,8V18.584l2.293-2.291,1.414,1.414L16,22.414l-4.707-4.707,1.414-1.414L15,18.584V8Z" fill="#8a8f8d"/></g></svg>
                            <em>Download</em>
                        </div>
                        <div @click="downloadfile(item)">
                            <svg xmlns="http://www.w3.org/2000/svg" class="view_icon" xmlns:xlink="http://www.w3.org/1999/xlink" width="20" height="20" viewBox="0 0 24 24">
                            <defs>
                                <clipPath id="clip-path">
                                <rect id="Rectangle_24" data-name="Rectangle 24" width="24" height="24" transform="translate(0)" fill="#fff"/>
                                </clipPath>
                            </defs>
                            <g id="Mask_Group_18" data-name="Mask Group 18" clip-path="url(#clip-path)">
                                <path id="Union_6" data-name="Union 6" d="M.153,8.532a1,1,0,0,1,0-1.064C3.4,2.3,7.054,0,12,0s8.6,2.3,11.847,7.468a1,1,0,0,1,0,1.064C20.6,13.7,16.947,16,12,16S3.4,13.7.153,8.532ZM7,8a5,5,0,1,0,5-5A5,5,0,0,0,7,8ZM9,8a3,3,0,1,1,3,3A3,3,0,0,1,9,8Z" transform="translate(0 4)" fill="#9293a2"/>
                            </g>
                            </svg>
                            <em>View</em>
                        </div>
                    </div>
                <div v-if="includeDownloadText" class="download_sec">
                    <img src="@/assets/images/pdf-file-format.svg">
                    <a @click="downloadInteral(item)" class="link_btn">Download</a>
                </div>
            </li>
        </ul>

        <span class="loader" v-if="convertLoading"><img src="@/assets/images/loader.gif" /></span>
    </div>
</template>
<script>
export default {

    data: () => ({
        convertLoading: false

    }),
    methods: {
        downloadInteral(item){
            if(this.auth === false){
                item.authRequired = false;
            }
            this.downloads3file(item)
        },        
        downloadfile(item) {
              if(this.auth === false){
                item.authRequired = false;
            }
            this.$emit("download_or_view", item);
        },
        convertPdfToWord() {
            this.$emit("download_or_view", item);
        },

    },
    props: {
        showconvert:{
                 type: Boolean,
            default: false
        },
        documentsList: {
            type: Array,
            default: [],
        },
        petitionDetails: {
            type: Object,
            default: null,
        },
        type: {
            type: String,
            default: '',
        },
        auth: {
            type: Boolean,
            default: true
        },
        includeDownloadText: {
            type: Boolean,
            default: false
        }
    },
    mounted() {
        this.$on('convertLoading', (value) => {
            const body = document.getElementsByTagName('body')[0];

            if (value)
                body.classList.add("overflow-hidden");
            else
                body.classList.remove("overflow-hidden");
            this.convertLoading = value
            console.log(value)
        })
    }
}



</script>