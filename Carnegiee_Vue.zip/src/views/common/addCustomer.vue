<template>
    <b-modal v-model="showAddcustomer" id="addcustomers_model" dialog-class="addcustomers_model" centered
        no-close-on-backdrop>
        <template #modal-header>
            <h6 class="modal-title">{{isEdit?'Edit Client':'Add Client'}}</h6>
            <a class="close" @click="closePopup"></a>

        </template>

        <template>

            <span class="user_header">Client Type*</span>
            <div class="customer_type_list">

                <div class="user_type_list">

                    <template v-for="(customerItem, index ) in customerTypes">
                        <radioInput wrapclass="radio_group_v2" :elementId="customerItem + index" :label="customerItem.name"
                            :fieldName="'customerType'" v-model="customer.customerTypeDetails" :fieldValue="customerItem"
                            :disabled="isEdit" />
                    </template>
                </div>
                <!-- <radioInput wrapclass="radio_group_v2" :elementId="'Regular Corporate'" :label="'Regular Corporate'"
            :fieldName="'customertype'" v-model="customersTypes" :fieldValue="true" v-validate="'required'"
            :data-vv-name="'Regular Corporate'" type="submit-btn" />
          <radioInput wrapclass="radio_group_v2" :elementId="'Priority Corporate'" :label="'Priority Corporate'"
            type="submit-btn" :fieldName="'customertype'" v-model="customersTypes" :fieldValue="true"
            v-validate="'required'" :data-vv-name="'Priority Corporate'" />
          <radioInput wrapclass="radio_group_v2" :elementId="'Individual'" :label="'Individual'" type="submit-btn"
            :fieldName="'customertype'" v-model="customersTypes" :fieldValue="true" v-validate="'required'"
            :data-vv-name="'Individual Corporate'" /> -->
                <div class="user_type_list">
                    <input type="hidden" class="form-control" v-validate="'required'" v-model="customer.customerTypeDetails"
                        data-vv-as="Client Type" :name="'customerType'" />
                    <span v-show="errors.has('customerType')" class="form-error">{{ errors.first('customerType') }}</span>
                </div>
            </div>

            <div class="form_info">

                <div class="row">
                    <div v-if="checkProperty(customer, 'customerTypeDetails', 'id') != 2" class="col-md-12">
                        <simpleInput :wrapclass="'mb20'" :fieldName="'companyName'" :cid="'companyName'"
                            :label="'Company Name'" :placeHolder="'Company Name'" :vvas="'Company Name'" :display="true"
                            :required="true" v-model="customer.companyName" :allowAlphNum="true" />
                    </div>

                    <div class="col-md-6">
                        <simpleInput :wrapclass="'mb20'" :fieldName="'firstName'" :cid="'firstName'" :label="'First Name'"
                            :placeHolder="'First Name'" :vvas="'First Name'" :display="true" :required="true"
                            v-model="customer.firstName" :allowAlphNum="true" />
                    </div>
                    <div class="col-md-6">
                        <simpleInput :wrapclass="'mb20'" :fieldName="'lastName'" :cid="'lastName'" :label="'Last Name'"
                            :placeHolder="'Last Name'" :vvas="'Last Name'" :display="true" :required="true"
                            v-model="customer.lastName" :allowAlphNum="true" />
                    </div>
                    <div class="col-md-6">
                        <simpleInput :wrapclass="'mb20'" :fieldName="'email'" :cid="'email'" :label="'Email'"
                            :placeHolder="'Email'" :vvas="'Email'" :display="true" :required="true" v-model="customer.email"
                            :emailFormat="true" datatype="email" :disabled="isEdit" />
                    </div>
                    <div class="col-md-6">
                        <phoneInput :wrapclass="'mb20'" :display="true" @updatePhoneCountryCode="updatePhoneCountryCode"
                            :countrycode="customer.phoneCountryCode.countryCode" cid="phone" v-model="customer.phone"
                            :fieldName="'phone'" label="Phone Number (Optional)" placeHolder="Phone Number"
                            :formscope="'addcustomerform'" />
                    </div>
                </div>
                <addressFields :showaptType="true" :addFormContainerCls='false' :validationRequired="false"
                    :countries="countries" v-model="customer.address" :cid="'customerAddress'" :name="'customerAddress'"
                    :disableCountry="true" />
                <!-- <textArea :label="'Addrress'" :wrapclass="'h40 mb20'"></textArea> -->
            </div>

            <span class="user_header">Billing Type*</span>

            <div class="user_type_list">
                <template v-for="(billingItem, index ) in billingTypes">
                    <radioInput wrapclass="radio_group_v2" :elementId="'billingType' + index" :label="billingItem.name"
                        :fieldName="'billingType' + index" v-model="customer.billingTypeDetails" :fieldValue="billingItem"
                        :disabled="isEdit" />
                </template>
            </div>
            <!-- <radioInput wrapclass="radio_group_v2" :elementId="'Per Case Billing'" :label="'Per Case Billing'"
            :fieldName="'billingtype'" v-model="billingTypes" :fieldValue="true" />
          <radioInput wrapclass="radio_group_v2" :elementId="'Monthly'" :label="'Monthly'" :fieldName="'billingtype'"
            v-model="billingTypes" :fieldValue="true" />
          <radioInput wrapclass="radio_group_v2" :elementId="'Flexible'" :label="'Flexible'" :fieldName="'billingtype'"
            v-model="billingTypes" :fieldValue="true" /> -->
            <div class="user_type_list">
                <input type="hidden" class="form-control" v-validate="'required'" v-model="customer.billingTypeDetails"
                    data-vv-as="Billing Type" :name="'billingType'" />
                <span v-show="errors.has('billingType')" class="form-error">{{ errors.first('billingType') }}</span>
            </div>

            <div class="form_info">
                <div class="row">
                    <div class="col-md-12">
                        <simpleInput :wrapclass="'mb20 discount_input'" :fieldName="'discount'" :cid="'discount'" :label="'Discount %'"
                            :placeHolder="'Discount %'" :vvas="'Discount'" :display="true" :onlyNumbers="true"
                            :maxLength="2" :required="false" v-model="customer.discount" />
                    </div>
                </div>
            </div>

        </template>
        <template #modal-footer>
            <button class="form-cancel" @click="closePopup">Cancel</button>
            <button class="primary_btn md" @click="validateForm">{{ isEdit ? 'Update' : 'Add Client' }}</button>
        </template>

    </b-modal>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import radioInput from "@/views/forms/radioInput.vue";
import textArea from "@/views/forms/textarea.vue";
import addressFields from "@/views/forms/address.vue";
import phoneInput from "@/views/forms/phonenumber.vue";
export default {
    props: {
        isEdit: {
            type: Boolean,
            default: false
        },
        customerData: Object,
    },
    components: {
        simpleSelect,
        radioInput,
        simpleInput,
        textArea,
        addressFields,
        phoneInput,
    },
    data: () => ({
        showAddcustomer: true,
        customer: {
            companyName: "",
            firstName: "",
            lastName: "",
            email: "",
            customerTypeDetails: null,
            billingTypeDetails: null,
            phone: null,
            phoneCountryCode: {
                countryCode: '',
                countryCallingCode: ''
            },
            discount: '',
            address: {
                line1: "", line2: "", countryId: 231, countryDetails: { "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" }
                , stateId: '', stateDetails: null, locationId: '', locationDetails: null, zipcode: '', aptType: ''
            },
        },
        countries: [{
            _id: "61408c9ed01ea1248cdcf6b7",
            id: 231,
            name: "United States",
            phoneCode: 1,
            order: 1,
            currencySymbol: "$",
            currencyCode: "USD",
            zipcodeLength: 5,
            sortName: "united states",
        }],
        countryCode: "US",

    }),
    mounted() {
        this.getMasterDataList('customer_types')
        this.getMasterDataList('billing_types')
        this.getCountries()
        if (this.isEdit && this.checkProperty(this.customerData, "_id")) {
            let postData =
            {
                "customerId": this.checkProperty(this.customerData, "_id")
            }
            this.$store.dispatch("getCustomerDetails", postData)
                .then((res) => {
                    this.customer = res.data.result
                })
                .catch((error) => {

                })
        }
    },
    methods: {

        getMasterDataList(category) {
            this.$store.dispatch("getMasterData", category)
                .then((res) => {
                    if (category == 'customer_types') {
                        this.customerTypes = [...res]
                    }
                    if (category == 'billing_types') {
                        this.billingTypes = [...res]
                    }
                })
        },

        getCountries() {
            this.$store.dispatch("getMasterData", 'countries')
                .then((res) => {
                    this.countries = res
                })
        },

        updatePhoneCountryCode(data) {
            this.customer.phoneCountryCode = data;
        },

        gotoPage(path = "/") {
            this.$router.push(path);
        },
        showAddcustomerPopup(isEdit = false) {
            // this.customer = {
            //     name: "",
            //     firstName: '',
            //     lastName: '',
            //     email: '',
            //     phone: null,
            //     customerType: '',
            //     billingType: '',
            //     phoneCountryCode: {
            //         countryCode: '',
            //         countryCallingCode: ''
            //     },
            //     address: {
            //         line1: "", line2: "", countryId: 231, countryDetails: { "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" }
            //         , stateId: '', stateDetails: null, locationId: '', locationDetails: null, zipcode: '', aptType: ''
            //     },

            // }
            this.showAddcustomer = true
        },
        validateForm() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    //console.log(this.customersList=[this.customer])
                    // alert(JSON.stringify(this.customer))

                    let postData =
                    {
                        "name": this.customer.firstName + " " + this.customer.lastName,
                        "email": this.customer.email,
                        // "altEmail": "srcustomer@yopmail.com",
                        "firstName": this.customer.firstName,
                        "lastName": this.customer.lastName,
                        "phone": this.customer.phone,
                        "billingType": this.customer.billingTypeDetails.id,
                        "customerType": this.customer.customerTypeDetails.id,
                        "discount": this.customer.discount,
                        "phoneCountryCode": this.customer.phoneCountryCode,
                        "address": this.customer.address
                    }

                    if (this.checkProperty(this.customer, 'customerTypeDetails', 'id') != 2) {
                        postData['companyName'] = this.customer.companyName
                    }

                    if (this.isEdit) {
                        postData['customerId'] = this.checkProperty(this.customerData, "_id")
                        this.$store.dispatch("updateCustomer", postData)
                            .then((response) => {
                                if (response.error) {
                                    (response.error)
                                    Object.assign(this.formerrors, {
                                        msg: response.error.result
                                    });
                                } else {
                                    this.showToster({ message: response.message, isError: false });
                                    this.$emit('updateCustomer', response)
                                    this.closePopup()
                                }
                            })
                            .catch((error) => {
                                this.showAddcustomer = true
                                this.showToster({ message: error, isError: true });
                            })

                    } else {
                        this.$store.dispatch("createCustomer", postData)
                            .then((response) => {
                                if (response.error) {
                                    (response.error)
                                    Object.assign(this.formerrors, {
                                        msg: response.error.result
                                    });
                                } else {
                                    this.showToster({ message: response.message, isError: false });
                                    this.$emit('updateCustomer', response)
                                    this.closePopup()
                                }
                            })
                            .catch((error) => {
                                this.showAddcustomer = true
                                this.showToster({ message: error, isError: true });
                            })
                    }
                } else {

                }
            })
        },
        closePopup() {
            this.$emit('closeAddCustomer', this.value)
            this.showAddcustomer = false
        }

    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>