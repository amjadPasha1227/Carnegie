<template>
    <b-modal id="template_model" dialog-class="delivery_template_model professors" centered no-close-on-backdrop>
        <template #modal-header>
            <h6 class="modal-title">Preliminary Opinion Templates</h6>
            <div class="d-flex">
                <a class="close" @click="closeTemplatePopup"></a>
            </div>
        </template>
        <template>
            <form :data-vv-scope="'preliminaryTemplateForm'">
                <simpleSelect :multiple="false" :wrapclass="'mb-3'" :optionslist="preliminaryTemplates" :display="true"
                    :placeHolder="'Select Template'" :searchable="false" :required="true" :close-on-select="true"
                    :clear-on-select="true" v-model="popupTemplate" :fieldName="'preliminaryTemplate'"
                    :cid="'preliminaryTemplate'" :hideSelected="false" :listContainsId="true" :trackBy="'title'"
                    :label="'Select Template'" :formscope="'preliminaryTemplateForm'" />

                <!-- <textArea :wrapclass="'more_info'" :tplkey="'preliminaryTitle'" fieldName="preliminaryTitle"
                                placeHolder="Email subject here..." v-model="popupTemplate.title"></textArea>-->

                <textArea v-if="checkProperty(popupTemplate, 'title')" class="mb-3" :tplkey="'preliminaryContent'"
                    fieldName="preliminaryContent" placeHolder="Email content here..."
                    v-model="popupTemplate.content"></textArea>
            </form>
        </template>
        <template #modal-footer>
            <button class="form-cancel" @click="closeTemplatePopup">Cancel</button>
            <button class="primary_btn md" @click="onTemplateSubmit">Use Content</button>
        </template>
    </b-modal>
</template>



<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import textArea from "@/views/forms/textarea.vue";
export default {
    props: {
        isEdit: {
            type: Boolean,
            default: false
        },
        customerData: Object,
    },
    components: {
        simpleSelect,
        simpleInput,
        textArea,
    },
    data: () => ({
        showTemplatePopup: false,
        preliminaryTemplates: [],
        selectedTemplate: {
            title: "",
            content: ""
        },
        popupTemplate: null,


    }),
    mounted() {
        this.getTemplates()
        this.$bvModal.show('template_model')
    },
    methods: {
        getTemplates() {
            let postData = {
                "matcher": {
                    "title": "",
                    "statusIds": [],
                    "typeIds": [],
                    "createdByIds": [],
                    "createdDateRange": []
                },
                "sorting": {
                    "path": "createdOn", //title, statusName, createdByName, updatedOn, 
                    "order": -1
                },
                "getMasterData": true,
                "page": 1,
                "perpage": 500
            }
            this.$store.dispatch("getEmailsList", postData)
                .then((res) => {
                    this.preliminaryTemplates = res.data.result.list
                })
                .catch((error) => {
                })
        },
        closeTemplatePopup() {
            this.popupTemplate = null
            this.showTemplatePopup = false
            this.$bvModal.hide('template_model')
            this.$emit('closeTemplatePopup')
        },
        onTemplateSubmit() {

            this.$validator.validateAll('preliminaryTemplateForm').then((result) => {
                if (result) {
                    if (this.checkProperty(this.selectedTemplate, 'content')) {
                        let resultContent = this.selectedTemplate.content + this.popupTemplate.content
                        this.selectedTemplate.content = resultContent
                    } else {
                        this.selectedTemplate = this.popupTemplate
                    }
                    this.showTemplatePopup = false
                    this.$emit('updateTemplate', this.selectedTemplate)
                    this.$bvModal.hide('template_model')
                }
            })
        },
    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>