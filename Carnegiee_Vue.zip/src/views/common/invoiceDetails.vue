 
<template>
    <div>
        <span class="loader" v-if="isDetailsLoading"><img src="@/assets/images/loader.gif"></span>
        <div class="sidenav_header">
            <div class="invoice_name">
                <h3>{{ checkProperty(selectedInvoice, 'invoiceId') }}</h3>
            </div>

            <div class="invoice_activitys">
                <ul>
                    <li><button class="invoice_btn" @click="downloadInvoice(selectedInvoice, true)"><img
                                src="@/assets/images/vision.png"></button></li>
                                
                    <li><button class="invoice_btn" @click="downloadInvoice(selectedInvoice)"><img
                                src="@/assets/images/download.png"></button></li>
                    <li><button class="invoice_btn" v-if="checkProperty(selectedInvoice, 'statusDetails', 'id') == 1"
                            @click="sendSingleRemainder(selectedInvoice)"><img src="@/assets/images/reminder.png">&nbsp;
                            Send
                            Reminder</button></li>
                    <li><button class="invoice_btn status " v-if="checkProperty(selectedInvoice, 'statusDetails', 'name')"
                            v-bind:class="{
                                'pending_payment': checkProperty(selectedInvoice, 'statusDetails', 'id') == 1,
                                'confirmed': [2, 3].indexOf(checkProperty(selectedInvoice, 'statusDetails', 'id')) > -1,
                            }">{{ checkProperty(selectedInvoice, 'statusDetails', 'name') }}</button></li>
                </ul>
                <a href="#" class="close" block @click="hide"><img src="@/assets/images/close.svg"></a>
            </div>
        </div>
        
        <VuePerfectScrollbar>
            <div class="inv-table">
                <ul>
                    <li v-if="checkProperty(invoiceEvaluation, 'customersDetails', 'name')">
                        <span>CLIENT</span>
                        <p><a>{{ checkProperty(invoiceEvaluation, 'customersDetails', 'name') }}</a></p>
                    </li>
                    <li v-if="checkProperty(invoiceEvaluation, 'priorityDetails', 'id')">
                        <span>Priority</span>
                        <p v-if="checkProperty(invoiceEvaluation, 'priorityDetails', 'id') == 2"><img
                                src="@/assets/images/flash.png">{{ checkProperty(invoiceEvaluation,
                                    'priorityDetails', 'name') }}</p>
                        <p v-if="checkProperty(invoiceEvaluation, 'priorityDetails', 'id') != 2">{{
                            checkProperty(invoiceEvaluation, 'priorityDetails', 'name') }}</p>
                    </li>
                    <li
                        v-if="checkProperty(selectedInvoice, 'customerDetails', 'billingTypeDetails') && checkProperty(selectedInvoice.customerDetails.billingTypeDetails, 'name')">
                        <span>BILLING TYPE</span>
                        <p>{{ checkProperty(selectedInvoice.customerDetails, 'billingTypeDetails', 'name') }}</p>
                    </li>
                </ul>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>DATE</th>
                                <th>EVALUATIONS</th>
                                <th>PRIORITY</th>
                                <th>AMOUNT</th>
                            </tr>
                        </thead>
                        <tbody>


                            <tr v-for="(evaluationPrice, indx) in  checkProperty(invoiceEvaluation, 'quotaPrice', 'evaluationPrices') "
                                v-bind:key="indx">
                                <td><span>{{ checkProperty(invoiceEvaluation, 'createdOn') | formatDate }}</span>
                                </td>
                                <td>{{ checkProperty(evaluationPrice, 'evaluationTypeName') }}</td>
                                <td><span :class="{'rush':checkProperty(invoiceEvaluation, 'priorityDetails', 'id') == 2}">{{ checkProperty(invoiceEvaluation, 'priorityDetails', 'name') }}</span></td>
                                <td>{{ '$' + checkProperty(evaluationPrice, 'price') }}</td>
                            </tr>

                            <tr v-if="checkProperty(invoiceEvaluation, 'quotaPrice', 'total')">
                                <td colspan="4">
                                    <div class="total_amount">
                                        <p>{{ 'Discount ' + checkProperty(invoiceEvaluation, 'quotaPrice', 'discount') + ' Applied'}}
                                        </p>
                                        <span>Total Amount</span>{{ '$' + checkProperty(invoiceEvaluation,
                                            'quotaPrice',
                                            'total') }}
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </VuePerfectScrollbar>
    </div>
</template>

<script>

import searchInput from '@/views/forms/searchInput.vue';
import simpleSelect from '@/views/forms/simpleSelect.vue';
import dropdownHover from '@/views/forms/dropdownHover.vue';
import DatePicker from 'vue2-datepicker';
import 'vue2-datepicker/index.css';
import JQuery from "jquery";
import VuePerfectScrollbar from 'vue-perfect-scrollbar'
import NoDataFound from "@/views/common/noData.vue";


export default {
    name: 'invoice_details',
    components: {
        searchInput,
        simpleSelect,
        dropdownHover, DatePicker,
        VuePerfectScrollbar,
        NoDataFound,
    },
    props: {
        selectedInvoice: Object,
        evaluation: Object,
    },
    data: () => ({
        invoiceEvaluation: null,
        docPrivew: false,
        docType: '',
        docValue: '',
        selectedFile: null,
        archiving: false,
        selectedForArchiveList: [],
    }),
    methods: {
        toggleBodyScrollbar(visible) {
            const body = document.getElementsByTagName('body')[0];

            if (visible)
                body.classList.add("overflow-hidden");
            else
                body.classList.remove("overflow-hidden");
        },
        getEvaluationDetail() {
           // alert(JSON.stringify(this.selectedInvoice))
            if (this.checkProperty(this.selectedInvoice, 'evaluationId')) {
                let postData =
                {
                    "evaluationId": this.checkProperty(this.selectedInvoice, 'evaluationId'),
                }
                this.$store.dispatch("getEvaluationDetails", postData)
                    .then((res) => {
                        this.invoiceEvaluation = res.result
                    })
                    .catch((error) => {
                    })
            }
        },
        downloadInvoice(selectedItem, isView = false) {
            this.isDetailsLoading = true
            let postData =
            {
                "invoiceId": selectedItem['_id'],
                "download": true,
            }
            this.$store.dispatch("downloadInvoiceFile", postData)
                .then((response) => {
                    this.isDetailsLoading = false
                    if (response.error) {
                        (response.error)
                        Object.assign(this.formerrors, {
                            msg: response.error.result
                        });
                        this.showToster({ message: response.error.result, isError: true });
                    } else {
                        let downloadFilePath = response.result.s3UrlPath
                        let fileName = response.result.fileName
                        if (isView) {
                            let docItem = {
                                path: downloadFilePath,
                                name: fileName
                            }
                            this.selectedFile = docItem
                            setTimeout(() => {
                                this.viewInvoice(docItem)
                            })
                        } else {
                            this.downloads3file({ 'path': downloadFilePath })
                        }
                        this.isDetailsLoading = false

                    }
                })
                .catch((error) => {
                    this.isDetailsLoading = false
                    this.showToster({ message: error, isError: true });
                })



        },
        viewInvoice(docItem) {
            this.docValue = docItem.path;
            this.docType = this.findmsDoctype(docItem["path"], docItem.mimetype);
            let value = _.cloneDeep(docItem)
            var _self = this;
            this.formSubmited = false;
            if (_.has(value, "path")) {
                value["url"] = value["path"];
                value["document"] = value["path"];
            }

            if (_.has(value, "url")) {
                value["path"] = value["url"];
                value["document"] = value["url"];
            }

            if (_.has(value, "document")) {
                value["path"] = value["document"];
                value["url"] = value["document"];
            }
            this.docValue = "";
            this.docPrivew = false;
            this.docType = this.findmsDoctype(value["path"], value.mimetype);

            if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
                //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
                value.url = value.url.replace(this.$globalgonfig._S3URL, "");
                value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
                let postdata = {
                    keyName: value.url,
                    // "petitionId": value['petitionId'],

                    // entityType:value['petitionId']
                    "fileName": value.name ? value.name : ''
                };
                // if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
                //   postdata['entityType'] = 'perm'
                // } else {
                //   postdata['entityType'] = 'case'
                // }


                this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                    this.docValue = response.data.result.data;
                    if (this.docType == "office") {
                        this.docPrivew = true;
                        setTimeout(() => {
                            document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
                            let _editing = false;

                            // if ([3, 4].indexOf(this.getUserRoleId) > -1) {
                            //   _editing = false;
                            // }

                            // if (value.viewmode) {
                            //   _editing = false;
                            // }
                            var _ob = {}
                            // if (value.editedDocument) {
                            //   _ob = {

                            //     evaluationId: this.evaluationDetails._id,
                            //     name: value.name,
                            //     _id: value._id,
                            //     "extn": "docx",
                            //     "formLetterType": "Letter",
                            //     parentId: value.parentId
                            //   }

                            // } else {

                            _ob = {

                                name: value.name,
                                evaluationId: this.evaluationDetails._id,
                                _id: value._id,
                                "extn": "docx",
                                "formLetterType": "Letter",
                                parentId: value._id

                            }

                            //  }


                            window.docEditor = new DocsAPI.DocEditor("placeholder2",
                                {

                                    "document": {
                                        "c": "forcesave",
                                        "fileType": "docx",
                                        "key": value._id,
                                        "userdata": JSON.stringify(_ob),
                                        "title": value.name,
                                        "url": response.data.result.data,
                                        permissions: {
                                            edit: _editing,
                                            download: true,
                                            reader: false,
                                            review: false,
                                            comment: false
                                        }
                                    },

                                    "documentType": "word",
                                    "height": "100%",
                                    "width": "100%",

                                    "editorConfig": {
                                        "userdata": JSON.stringify(_ob),
                                        "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                                        "customization": {
                                            "logo": {
                                                "image": "https://immibox.com/app/favicon.png",
                                                "imageDark": "https://immibox.com/app/favicon.png",
                                                "url": "https://immibox.com"
                                            },
                                            "anonymous": {
                                                "request": false,
                                                "label": "Guest"
                                            },
                                            "chat": false,
                                            "comments": false,
                                            "compactHeader": false,
                                            "compactToolbar": true,
                                            "compatibleFeatures": false,
                                            "feedback": {
                                                "visible": false
                                            },
                                            "forcesave": true,
                                            "help": false,
                                            "hideNotes": true,
                                            "hideRightMenu": true,
                                            "hideRulers": true,
                                            layout: {
                                                toolbar: {
                                                    "collaboration": false,
                                                },
                                            },
                                            "macros": false,
                                            "macrosMode": "warn",
                                            "mentionShare": false,
                                            "plugins": false,
                                            "spellcheck": false,
                                            "toolbarHideFileName": true,
                                            "toolbarNoTabs": true,
                                            "uiTheme": "theme-light",
                                            "unit": "cm",
                                            "zoom": 100
                                        },
                                    }, events: {
                                        onReady: function () {

                                        },
                                        onDocumentStateChange: function (event) {
                                            var url = event.data;
                                            console.log(event)

                                            if (!event.data) {

                                                if (value.editedDocument) {

                                                }

                                            }
                                        }

                                    }
                                });
                            //this.docValue = encodeURIComponent(response.data.result.data);
                        }, 100)
                    }

                    if (this.docType == "pdf") {

                        // this.downloadFile(this.docValue, value.mimetype, value.name)

                        // return
                        var _vid = value._id;
                        if (value.parentId) {
                            _vid = value.parentId;
                        }
                        var viewmode = 1; // Enable edit
                        viewmode = 0; //Disabled Edit
                        if (value.viewmode) {
                            viewmode = 0;
                        }
                        this.docValue = "https://carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
                        console.log(this.docValue)
                        this.docPrivew = true;
                    }
                    if (this.docType == "image") {
                        this.docPrivew = true;
                    }



                });
            } else {
                this.downloads3file(value);
            }

        },

        sendRemainders() {
            this.isDetailsLoading = true
            let postData =
                { "invoiceIds": this.selectedForArchiveList, }
            this.$store.dispatch("sendInvoiceRemainders", postData)
                .then((response) => {
                    this.isDetailsLoading = false
                    if (response.error) {
                        (response.error)
                        Object.assign(this.formerrors, {
                            msg: response.error.result
                        });
                        this.showToster({ message: response.error.result, isError: true });
                    } else {
                        this.selectedForArchiveList = []
                        this.isDetailsLoading = false
                        this.selectedAllForArchive = false;
                        this.showToster({ message: response.message, isError: false });
                        this.applyFilters()
                    }
                })
                .catch((error) => {
                    this.isDetailsLoading = false
                    this.showToster({ message: error, isError: true });
                })
        },
        sendSingleRemainder(selectedItem) {
            this.selectedForArchiveList = []
            this.selectedForArchiveList.push(selectedItem['_id'])
            this.sendRemainders()
        },


    },
    mounted() {
        setTimeout(() => {
            //  this.getEvaluationDetail()
        })

    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    }
}
</script>