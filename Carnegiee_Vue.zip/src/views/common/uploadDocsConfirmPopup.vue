<template>
    <b-modal v-model="showAddcustomer" id="addcustomers_model" dialog-class="addcustomers_model" centered
        no-close-on-backdrop >
        <template #modal-header >
            <h6 class="modal-title">{{ 'Confirm Submission' }}</h6>
            <a class="close" @click="closePopup"></a>
        </template>

        <div class="row">
            <p class="confirm_msg msg">This action cannot be reversed. Please make sure to preview the documents before submitting them.</p>
        </div>
        <template>



        </template>
        <template #modal-footer>
            <button class="form-cancel" @click="closePopup">Cancel</button>
            <button class="primary_btn md" @click="submitPopup">{{ 'Proceed' }}</button>
        </template>

    </b-modal>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import radioInput from "@/views/forms/radioInput.vue";
import textArea from "@/views/forms/textarea.vue";
import phoneInput from "@/views/forms/phonenumber.vue";
export default {
    props: {
        isEdit: {
            type: Boolean,
            default: false
        },
        customerData: Object,
    },
    components: {
        simpleSelect,
        radioInput,
        simpleInput,
        textArea,
        phoneInput,
    },
    data: () => ({
        showAddcustomer: true,
    }),
    mounted() {

    },
    methods: {
        submitPopup() {
            this.$emit('submitAction',1)
            this.showAddcustomer = false
        },

        closePopup() {
             this.$emit('submitAction', 0)
            this.showAddcustomer = false
        }

    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>