import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import Essentials from '@ckeditor/ckeditor5-essentials/src/essentials';
import Paragraph from '@ckeditor/ckeditor5-paragraph/src/paragraph';
import Enter from "@ckeditor/ckeditor5-enter/src/enter";
import Highlight from '../../plugins/ck-highlight/highlight'; // Adjust the path to your highlight plugin

ClassicEditor.builtinPlugins = [
  Essentials,
  Enter,
  Paragraph,
  Highlight
];
ClassicEditor.defaultConfig = {
  ...ClassicEditor.defaultConfig,
  plugins: [
    ...ClassicEditor.defaultConfig.plugins,
    HighlightUI,
  ],
  enter: {
    forceSimpleAmpersand: false,
    shiftEnterMode: CKEditor.ENTER_BR,
  },
};

export default ClassicEditor;
