<template>
  <div class="pad20">
    <!-- <div class="page_header">
        <h3>Email Templates</h3>
      </div> -->
    <div class="filter_sec">
      <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" />

      <simpleSelect :multiple="true" :wrapclass="'req_status'" :optionslist="professorsList" :display="true"
        :place-holder="'Professors'" :searchable="false" :required="false" :close-on-select="false"
        :clear-on-select="true" v-model="filterSelectedProfessors" :fieldName="'filterProfessors'"
        :cid="'filterProfessors'" :hideSelected="true" @input="applyFilters" :listContainsId="true" />
      <simpleSelect v-if="false" :multiple="true" :wrapclass="'req_status'" :optionslist="filterEmailTypes"
        :display="true" :place-holder="'Type'" :searchable="false" :required="false" :close-on-select="false"
        :clear-on-select="true" v-model="filterSelectedEmailTypes" :fieldName="'filterTemplateType'"
        :cid="'filterTemplateType'" :hideSelected="true" @input="applyFilters" :listContainsId="true" />

      <button class="filter_btn" v-if="false"><span></span><em>Filters</em></button>
      <div class="filters_right">
        <button class="add_btn" @click="openAddFolderPopup(false)"><span></span><em>Create Folder</em></button>
      </div>
    </div>
    <div class="folders_count" v-if="checkProperty(baseFoldersList, 'length') > 0"> {{ checkProperty(baseFoldersList, 'length') ==
            1 ? checkProperty(baseFoldersList, 'length') + " folder" : checkProperty(baseFoldersList, 'length') + " folders" }}
        </div>

    <div class="files_wrapper">
      <div class="files_list">
        <ul>
          <li v-for="(baseFolder, index) in baseFoldersList" @click="goToSubFoldersPage(baseFolder)">
            <div class="file_icon"><img src="@/assets/images/folder.svg"></div>
            <div class="file_details">
              <label class="folder_name">{{ checkProperty(baseFolder, 'folderName') }}
                <!-- <span class="prof_name">{{
                checkProperty(baseFolder, 'professorDetails', 'name') }}</span> -->
              </label>
              <span class="updated_on">Created
                on:
                <b>{{ checkProperty(baseFolder, 'createdOn') | formatDateTime }}</b></span>
              <!-- <div class="folders_files"><span class="folders"><b>1</b> Folder(s)</span>|<span class="files"><b>14</b>
                  File(s)</span></div> -->
            </div>
          </li>
        </ul>
      </div>
    </div>
    
    <div class="table-responsive">
      <template v-if="checkProperty(baseFoldersList, 'length') <= 0">
        <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Emails' :loading="isListLoading" />
      </template>

    </div>

    <!-- Create Template Modal -->
    <addFolderOrDocument v-if="showAddFolderPopup" @onUpdate="onFolderOrFileCreated" @onClose="closeAddFolderPopup"
      :isRootFolder="true" :repoType="'1'">
    </addFolderOrDocument>





  </div>
</template>
  
<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import dropdownHover from '@/views/forms/dropdownHover.vue';
import textArea from "@/views/forms/textarea.vue";
import NoDataFound from "@/views/common/noData.vue";
import addFolderOrDocument from "@/views/mergedocuments/addFolderOrDocument.vue"

export default {
  name: 'emailtemplate-view',
  components: {
    searchInput,
    simpleSelect,
    dropdownHover,
    simpleInput,
    textArea,
    NoDataFound,
    addFolderOrDocument
  },
  data: () => ({
    isListLoading: false,
    showAddFolderPopup: false,
    filterSearch: '',
    filterSelectedProfessors: [],
    page: 1,
    perpage: 500,
    totalCount: 0,
    baseFoldersList: [],
    professorsList: [],

  }),
  methods: {
    getBaseFoldersList() {
      let professorIds = []

      if (this.filterSelectedProfessors && this.checkProperty(this.filterSelectedProfessors, 'length') > 0) {
        professorIds = this.filterSelectedProfessors.map((item) => item['_id'])
      }
      let postData = {
        "matcher": {
          "title": this.filterSearch,
          "professorIds": professorIds,
          "parentIds": [],
        },
        "sorting": {
          "path": "createdOn", //title, statusName, createdByName, updatedOn, 
          "order": -1
        },
        "type": 1,
        "baseFolder": true,
        "page": this.page,
        "perpage": this.perpage
      }


      this.$store.dispatch("getEvaluationTemplatesList", postData)
        .then((res) => {
          // this.baseFoldersList = _.filter(res.data.result.list, (item) => {
          //   return (this.checkProperty(item, 'professorId'))
          // })

          this.baseFoldersList = res.data.result.list
          if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
            this.totalCount = this.checkProperty(res.data.result, 'totalCount');
          }
          this.isListLoading = false
          setTimeout(() => {
            this.updateLoading(false);
          })
        })
        .catch((error) => {
          this.isListLoading = false
          setTimeout(() => {
            this.updateLoading(false);
          })
        })

    },
    applyFilters() {
      this.isListLoading = true
      this.updateLoading(true);
      this.page = 1
      this.getBaseFoldersList()
    },
    applySearchFilters() {
      this.isListLoading = true
      this.updateLoading(true);
      this.page = 1
      if (this.filterSearch && this.filterSearch.length > 2) {
        this.getBaseFoldersList()
      }
      if (this.filterSearch == '') {
        this.getBaseFoldersList()
      }
    },
    openAddFolderPopup() {
      this.showAddFolderPopup = true
    },
    closeAddFolderPopup() {
      this.showAddFolderPopup = false
    },
    onFolderOrFileCreated() {
      this.showAddFolderPopup = false
      this.baseFoldersList = []
      this.applyFilters()
    },

    goToSubFoldersPage(data) {
      if (this.checkProperty(data, '_id')) {
        localStorage.setItem('baseFolder', JSON.stringify(data))
        let routedId = this.checkProperty(data, '_id')
        let path = "/foldresAndFiles/" + routedId;
        this.$router.push(path);
      }
    },
    getUsers() {
      let postData =
      {
        "matcher": {
          "title": '',
          "searchString": "",
          "statusList": [],
          "createdByIds": [],
          "createdDateRange": [],
          "roleIds": [9],
          "statusIds": [],
          "typeIds": [],
          "departmentIds": []
        },
        "sorting": {
          "path": "createdOn",
          "order": -1
        },
        "getMasterData": true,// if Masterdata required
        "page": 1,
        "perpage": 500,
      }
      this.$store.dispatch("getUsersList", postData)
        .then((res) => {
          let lst = []
          _.forEach(res.data.result.list, (item) => {
            item['isSuggested'] = false;
            lst.push(item);
          });

          this.professorsList = lst
        })
        .catch((error) => {
        })
    },

  },
  mounted() {
    this.getUsers()
    this.getBaseFoldersList()
  },
  computed: {

  },
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },

}
</script>