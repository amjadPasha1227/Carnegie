<template>
    <div class="pad20" style="height: calc(100vh - 60px);">
        <div class="d-flex justify-content-between">
            <ul class="bredcumbs"
                v-if="!isFromEvaluation || (isFromEvaluation && checkProperty(breadCrumbs, 'length') > 1)">
                <li v-for="(breadCrumb, indx) in breadCrumbs" class="brecumb-item" @click="onFolderClick(breadCrumb)"> <span
                        v-if="indx > 0 && indx < checkProperty(breadCrumbs, 'length')">/</span>
                    <p>{{ checkProperty(breadCrumb, 'folderName') }}</p>
                </li>

            </ul>
            <div class="d-flex align-items-center" v-if="!isFromEvaluation">
                <button class="add_btn marr10" @click="openAddFolderPopup(false, false)"><span></span><em>Create
                        Folder</em></button>
                <button class="add_btn upload" @click="openAddFolderPopup(true, false)"><span></span><em>Upload
                        Files</em></button>
            </div>
        </div>

        <div class="folders_count">
            {{ getFoldersAndFilesCount }}
        </div>
        <div class="files_wrapper">
            <div class="files_list">
                <ul>
                    <li v-for="(folder, idx) in foldersList">
                        <div class="d-flex align-items-center w-full" @click="onFolderClick(folder)">
                            <div class="file_icon"><img src="@/assets/images/folder.svg"></div>
                            <div class="file_details"><span class="folder_name">{{ checkProperty(folder, 'folderName')
                            }}</span><span class="updated_on">Created
                                    on:
                                    <b>{{ checkProperty(folder, 'createdOn') | formatDateTime }}</b></span>
                                <!-- <div class="folders_files"><span class="folders"><b>{{ checkProperty(folder, 'folderCount')
                            }}</b>
                                    Folder(s)</span>|<span class="files"><b>{{ checkProperty(folder, 'fileCount') }}</b>
                                    File(s)</span></div> -->
                            </div>
                        </div>
                        <div v-if="!isFromEvaluation" class=" actions-drpdown folder_actions">
                            <dropdownHover>
                                <b-dropdown-item @click="openAddFolderPopup(false, true, folder)">Edit</b-dropdown-item>
                                <b-dropdown-item @click="openDeleteFilePopup(folder)">Delete</b-dropdown-item>
                            </dropdownHover>
                        </div>
                    </li>
                </ul>
            </div>
        </div>



        <div class="table-responsive" v-if="checkProperty(filesList, 'length') > 0">
            <table class="table">
                <thead>
                    <tr>
                        <th class="pt-10">Files</th>
                        <!-- <th class="pt-10">Size </th> -->
                        <th class="pt-10">Uploaded By</th>
                        <th class="pt-10">Last Updated</th>
                        <th v-if="!isFromEvaluation" class="actions pt-10">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(document, idx) in  filesList " v-if="checkProperty(document, 'documents', 'length') > 0">
                        <td>
                            <div class="title">
                                <!-- <figure class="files_img">
                                    <template>
                                        <img src="@/assets/images/files/pdf.svg" />
                                    </template>
                                </figure> -->

                                <DocumentsPreview v-if="checkProperty(document, 'documents', 'length') > 0"
                                    :type="'documents'" :documentsList="checkProperty(document, 'documents')"
                                    :includeDownloadText="false" @download_or_view="download_or_view" />

                                <figcaption @click="onFileSelect(document)" v-bind:class="{
                                    'template_caption': isFromEvaluation,
                                    '': !isFromEvaluation
                                }">{{ checkProperty(document.documents[0], 'name') }}</figcaption>
                            </div>
                        </td>
                        <!-- <td>
                            <span>30 kb</span>
                        </td> -->
                        <td class="td_label">
                            <span v-if="checkProperty(document, 'createdBy')">{{ checkProperty(document, 'createdBy')
                            }}</span>
                        </td>
                        <td>
                            <span class="due_date">{{ checkProperty(document, 'createdOn') | formatDateTime }}</span>
                        </td>
                        <td v-if="!isFromEvaluation">
                            <div class="actions actions-drpdown">
                                <dropdownHover>
                                    <b-dropdown-item v-if=false
                                        @click="openAddFolderPopup(true, true, document)">Edit</b-dropdown-item>
                                    <b-dropdown-item @click="download_or_view(document.documents[0])"
                                        v-if="checkProperty(document, 'documents', 'length') > 0">View</b-dropdown-item>
                                    <b-dropdown-item @click="downloads3file(document.documents[0])"
                                        v-if="checkProperty(document, 'documents', 'length') > 0">Download</b-dropdown-item>
                                    <b-dropdown-item @click="openDeleteFilePopup(document)">Delete</b-dropdown-item>
                                </dropdownHover>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>

            <!-- <template v-if="checkProperty(foldersList, 'length') <= 0 && checkProperty(filesList, 'length') <= 0">
                <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Emails'
                    :loading="isListLoading" />
            </template> -->
        </div>

        <template v-if="checkProperty(foldersList, 'length') <= 0 && checkProperty(filesList, 'length') <= 0">
            <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Emails' :loading="isListLoading" />
        </template>

        <!-- :canPostProfessorId="checkProperty(breadCrumbs, 'length') == 2 ? true : false"> -->
        <!-- {{ "repoType" +repoType }} -->
        <addFolderOrDocument v-if="showAddFolderPopup" @onUpdate="onFolderOrFileCreated" @onClose="closeAddFolderPopup"
            :isRootFolder="false" :isFilesUpload="isFilesUpload" :parentId="parentFolderId" :baseFolder=baseFolder
            :canPostProfessorId="true" :repoType="repoType" :isDocumentEdit="isFolderOrFileEdit"
            :selectedFolder="selectedFolderOrFile">

        </addFolderOrDocument>

        <b-modal id="preview_model" v-model="docPrivew" dialog-class="document_modal"
            :title="checkProperty(selectedFile, 'name')" hide-footer>
            <h2> <img :class="{
                pdf_view_download: docType == 'pdf',
                office_view_download: docType == 'office',
                image_view_download: docType == 'image',
            }" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>

            <div class="pdf_loader">
                <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/loader.gif" /></figure>

                <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
                <template v-if="docType == 'office'">
                    <div style="height:90vh">

                        <div id="placeholder" name="placeholder" style="height:100%"></div>
                    </div>
                </template>
                <template v-else-if="docType == 'image'">
                    <img :src="docValue" />
                </template>
                <template v-else-if="docType == 'pdf'">
                    <div class="pdf" style="height:90vh">

                        <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%"
                            width="100%">

                        </iframe>
                    </div>
                </template>
            </div>
        </b-modal>


        <b-modal id="remove_user_model" v-model="showDeleteFilePopup" dialog-class="addnotes_model" centered
            no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Delete File</h6>
                <a class="close" @click="closeDeleteFilePopup"></a>
            </template>
            <template>
                <div class="row">
                    <!-- <div class="col-md-12">
                        <textArea :tplkey="'cancelComments'" fieldName="cancelComments" placeHolder="Comments…"
                            v-model="cancelComments" :label="'Comments'" :required="true" :vvas="'Comments'"></textArea>
                    </div> -->
                    <p class="confirm_msg">Are you sure you
                        want to delete?</p>
                </div>
            </template>
            <template #modal-footer>
                <button class="form-cancel me-4" @click="closeDeleteFilePopup">No</button>
                <button class="primary_btn md" @click="deleteDocument">Yes
                    <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
            </template>
        </b-modal>

    </div>
</template>
  

<script>
import dropdownHover from '@/views/forms/dropdownHover.vue';
import addFolderOrDocument from "@/views/mergedocuments/addFolderOrDocument.vue"
import NoDataFound from "@/views/common/noData.vue";
import DocumentsPreview from '@/views/common/documentsPreview.vue';

export default {

    props: {
        isFromEvaluation: {
            type: Boolean,
            default: false
        },
        professorIds: {
            type: String,
            default: ''
        },
        evaltplfolderId: {
            type: String,
            default: ''
        },
        repoType: {
            type: String,
            default: "1"
        },
    },
    components: {
        dropdownHover,
        addFolderOrDocument,
        NoDataFound,
        DocumentsPreview,
    },
    data: () => ({
        parentFolderId: null,
        isFilesUpload: false,
        showAddFolderPopup: false,
        breadCrumbs: [],
        isListLoading: false,
        page: 1,
        perpage: 500,
        totalCount: 0,
        foldersList: [],
        filesList: [],
        baseFolder: null,
        docPrivew: false,
        showDeleteFilePopup: false,
        fileToDelete: null,
        isFolderOrFileEdit: false,
        selectedFolderOrFile: null,
    }),
    methods: {
        openAddFolderPopup(isAddFiles, isEdit = false, folder = null) {
            this.selectedFolderOrFile = folder
            this.isFolderOrFileEdit = isEdit
            this.isFilesUpload = isAddFiles
            this.showAddFolderPopup = true
        },
        closeAddFolderPopup() {
            this.showAddFolderPopup = false
        },
        onFolderOrFileCreated() {
            this.showAddFolderPopup = false
            this.foldersList = []
            this.filesList = []
            this.applyFilters()
        },

        applyFilters() {
            this.isListLoading = true
            this.updateLoading(true);
            this.page = 1
            this.getFoldersAndFiles()
        },
        applySearchFilters() {
            this.isListLoading = true
            this.updateLoading(true);
            this.page = 1
            if (this.filterSearch && this.filterSearch.length > 2) {
                this.getFoldersAndFiles()
            }
            if (this.filterSearch == '') {
                this.getFoldersAndFiles()
            }
        },
        getFoldersAndFiles() {
            let postData = null
            if (this.isFromEvaluation) {
                postData = {
                    "matcher": {
                        "title": this.filterSearch,
                        "professorIds": [],
                        "parentIds": [],
                    },
                    "sorting": {
                        "path": "createdOn", //title, statusName, createdByName, updatedOn, 
                        "order": -1
                    },
                    "baseFolder": false,
                    "page": this.page,
                    "perpage": this.perpage
                }
                if ((this.checkProperty(this.breadCrumbs, 'length') < 2)) {
                    postData.matcher.professorIds = [this.professorIds]
                    // Object.assign(postData, { 'professorIds': [] })
                }
                if (this.evaltplfolderId) {
                    postData.baseFolder = true;
                }
                if (this.parentFolderId) {
                    postData.matcher.parentIds = [this.parentFolderId]
                }
            } else {
                postData = {
                    "matcher": {
                        "title": this.filterSearch,
                        "parentIds": [this.parentFolderId],
                    },
                    "sorting": {
                        "path": "createdOn", //title, statusName, createdByName, updatedOn, 
                        "order": -1
                    },
                    // "type":  this.baseFolder.type,
                    "page": this.page,
                    "perpage": this.perpage
                }
            }

            this.$store.dispatch("getEvaluationTemplatesList", postData)
                .then((res) => {
                    //  this.foldersList =res.data.result.list
                    this.foldersList = _.filter(res.data.result.list, (item) => {
                        //  return (this.checkProperty(item, 'parentId') == this.parentFolderId && this.checkProperty(item, 'entityType') == 'Folder')
                        return (this.checkProperty(item, 'entityType') == 'Folder')

                    })

                    this.filesList = _.filter(res.data.result.list, (item) => {
                        // return (this.checkProperty(item, 'parentId') == this.parentFolderId && this.checkProperty(item, 'entityType') == 'Document')
                        return (this.checkProperty(item, 'entityType') == 'Document')

                    })
                    if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
                        this.totalCount = this.checkProperty(res.data.result, 'totalCount');
                    }
                    this.isListLoading = false
                    setTimeout(() => {
                        this.updateLoading(false);
                    })
                })
                .catch((error) => {
                    this.isListLoading = false
                    setTimeout(() => {
                        this.updateLoading(false);
                    })
                })

        },
        onFolderClick(selectedFolder) {
            if (selectedFolder.type == 'baseFolder') {
                if (this.checkProperty(this.baseFolder, 'type') == 2) {
                    this.$router.push('/repository');
                } else {
                    this.$router.push('/evaltemplates');
                }
            } else {
                let folder = {
                    folderName: selectedFolder.folderName,
                    type: "folder",
                    base_type: 'root',
                    _id: selectedFolder._id,
                    repoType: this.checkProperty(this.selectedFolder, 'type') == 2 ? '2' : '1'
                }

                if (this.checkProperty(this.breadCrumbs, 'length') > 0 && this.breadCrumbs[this.breadCrumbs.length - 1]._id == selectedFolder._id)
                    return
                if (this.checkProperty(folder, 'type') == 'folder') {
                    let breadCrumb = folder
                    let finalBreadCrumb = []
                    let isBreadCrumbFound = false;
                    _.forEach(this.breadCrumbs, (item) => {
                        if (!isBreadCrumbFound) {
                            if (item._id == selectedFolder._id) {
                                isBreadCrumbFound = true;
                            } else {
                                finalBreadCrumb.push(item)
                            }
                        }
                    })
                    finalBreadCrumb.push(breadCrumb)
                    this.breadCrumbs = finalBreadCrumb

                    this.parentFolderId = selectedFolder._id
                    this.foldersList = []
                    this.filesList = []
                    this.applyFilters()
                }
            }


            //    this.breadCrumbs.push(folder)

        },
        download_or_view(docItem) {

            let value = _.cloneDeep(docItem);
            var _self = this;
            this.formSubmited = false;
            if (_.has(value, "path")) {
                value["url"] = value["path"];
                value["document"] = value["path"];
            }

            if (_.has(value, "url")) {
                value["path"] = value["url"];
                value["document"] = value["url"];
            }

            if (_.has(value, "document")) {
                value["path"] = value["document"];
                value["url"] = value["document"];
            }

            this.selectedFile = value;
            this.docValue = "";
            this.docPrivew = false;
            this.docType = false;
            this.docType = this.findmsDoctype(value["name"], value.mimetype);

            if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
                //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
                value.url = value.url.replace(this.$globalgonfig._S3URL, "");
                value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
                let postdata = {
                    keyName: value.url,
                    "fileName": value.name ? value.name : ''
                };

                this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                    this.docValue = response.data.result.data;
                    if (this.docType == "office") {
                        this.docPrivew = true;
                        setTimeout(() => {
                            document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
                            let _editing = false;
                            var _ob = {}
                            _ob = {
                                name: value.name,
                                _id: value._id,
                                "extn": "docx",
                                "formLetterType": "Letter",
                                parentId: value._id

                            }
                            window.docEditor = new DocsAPI.DocEditor("placeholder2",
                                {

                                    "document": {
                                        "c": "forcesave",
                                        "fileType": "docx",
                                        "key": value._id,
                                        "userdata": JSON.stringify(_ob),
                                        "title": value.name,
                                        "url": response.data.result.data,
                                        permissions: {
                                            edit: _editing,
                                            download: true,
                                            reader: false,
                                            review: false,
                                            comment: false
                                        }
                                    },

                                    "documentType": "word",
                                    "height": "100%",
                                    "width": "100%",

                                    "editorConfig": {
                                        "userdata": JSON.stringify(_ob),
                                        "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                                        "customization": {
                                            "logo": {
                                                "image": "https://immibox.com/app/favicon.png",
                                                "imageDark": "https://immibox.com/app/favicon.png",
                                                "url": "https://immibox.com"
                                            },
                                            "anonymous": {
                                                "request": false,
                                                "label": "Guest"
                                            },
                                            "chat": false,
                                            "comments": false,
                                            "compactHeader": false,
                                            "compactToolbar": true,
                                            "compatibleFeatures": false,
                                            "feedback": {
                                                "visible": false
                                            },
                                            "forcesave": true,
                                            "help": false,
                                            "hideNotes": true,
                                            "hideRightMenu": true,
                                            "hideRulers": true,
                                            layout: {
                                                toolbar: {
                                                    "collaboration": false,
                                                },
                                            },
                                            "macros": false,
                                            "macrosMode": "warn",
                                            "mentionShare": false,
                                            "plugins": false,
                                            "spellcheck": false,
                                            "toolbarHideFileName": true,
                                            "toolbarNoTabs": true,
                                            "uiTheme": "theme-light",
                                            "unit": "cm",
                                            "zoom": 100
                                        },
                                    }, events: {
                                        onReady: function () {

                                        },
                                        onDocumentStateChange: function (event) {
                                            var url = event.data;
                                            console.log(event)

                                            if (!event.data) {

                                                if (value.editedDocument) {

                                                }

                                            }
                                        }

                                    }
                                });
                            //this.docValue = encodeURIComponent(response.data.result.data);
                        }, 100)
                    }

                    if (this.docType == "pdf") {

                        // this.downloadFile(this.docValue, value.mimetype, value.name)

                        // return
                        var _vid = value._id;
                        if (value.parentId) {
                            _vid = value.parentId;
                        }
                        var viewmode = 1; // Enable edit
                        viewmode = 0; //Disabled Edit
                        if (value.viewmode) {
                            viewmode = 0;
                        }
                        this.docValue = "https://carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
                        console.log(this.docValue)
                        this.docPrivew = true;
                    }
                    if (this.docType == "image") {
                        this.docPrivew = true;
                    }



                });
            } else {
                this.downloads3file(value);
            }

        },

        onFileSelect(selectedFile) {
            if (this.isFromEvaluation) {
                this.$emit('onFileSelect', selectedFile)

            }
        },

        openDeleteFilePopup(deleteFile) {
            this.fileToDelete = deleteFile
            this.showDeleteFilePopup = true
        },
        closeDeleteFilePopup() {
            this.fileToDelete = null
            this.showDeleteFilePopup = false
        },


        deleteDocument() {
            let postData = {
                "evaluationTempId": this.fileToDelete['_id']
            }
            this.$store.dispatch("deleteFolderOrDocument", postData)
                .then((response) => {
                    if (response.error) {
                        this.showToster({ message: response.error.message, isError: true });
                    } else {
                        this.closeDeleteFilePopup()
                        this.showToster({ message: response.message, isError: false });
                        this.foldersList = []
                        this.filesList = []
                        this.applyFilters()
                    }
                })
                .catch((error) => {

                })



        },




    },
    mounted() {

        if (this.isFromEvaluation) {

            let professorFolder = {
                folderName: "Root",
                type: "folder",
                base_type: 'folder',
                professorIds: this.professorIds,
                _id: this.parentFolderId
            }
            this.breadCrumbs.push(professorFolder)
            this.getFoldersAndFiles()
        } else {
            this.baseFolder = JSON.parse(localStorage.getItem('baseFolder'))
            console.log('baseFolder', this.baseFolder)
            this.parentFolderId = this.$route.params.itemId
            let baseFolder = {
                folderName: this.checkProperty(this.baseFolder, 'type') == 2 ? 'Repository' : 'Evaluation Templates',
                type: "baseFolder",
                base_type: 'root',
                _id: -1,
                repoType: this.checkProperty(this.baseFolder, 'type') == 2 ? '2' : '1'
            }
            this.breadCrumbs.push(baseFolder)
            if (this.checkProperty(this.baseFolder, 'type') == 2) {
                this.repoType = '2'
            }

            let professorFolder = {
                folderName: this.baseFolder['folderName'],
                type: "folder",
                base_type: 'folder',
                _id: this.parentFolderId,
                repoType: this.checkProperty(this.baseFolder, 'type') == 2 ? '2' : '1'
            }
            this.breadCrumbs.push(professorFolder)
            this.getFoldersAndFiles()
        }

    },
    computed: {

        getFoldersAndFilesCount() {
            let countsLable = ""
            if (this.checkProperty(this.foldersList, 'length') > 0) {
                countsLable = this.checkProperty(this.foldersList, 'length') + (this.checkProperty(this.foldersList, 'length') == 1 ? " folder " : " folders ")

            }
            if (this.checkProperty(this.filesList, 'length') > 0) {
                if (this.checkProperty(this.foldersList, 'length') > 0) {
                    countsLable = countsLable + "& " + this.checkProperty(this.filesList, 'length') + (this.checkProperty(this.filesList, 'length') == 1 ? " file " : " files ")
                } else {
                    countsLable = this.checkProperty(this.filesList, 'length') + (this.checkProperty(this.filesList, 'length') == 1 ? " file " : " files ")

                }
            }
            return countsLable
        }

    },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },


}
</script>