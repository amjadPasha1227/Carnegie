<template>
    <div class="pad20">
        <div class="d-flex justify-content-between">
            <ul class="bredcumbs">
                <li v-for="(breadCrumb, indx) in breadCrumbs" class="brecumb-item" @click="onFolderClick(breadCrumb)"> <span
                        v-if="indx > 0 && indx < checkProperty(breadCrumbs, 'length')">/</span>
                    <p>{{ checkProperty(breadCrumb, 'folderName') }}</p>
                </li>

            </ul>
            <div class="d-flex align-items-center">
                <button class="add_btn marr10" @click="openAddFolderPopup(false)"><span></span><em>Create
                        Folder</em></button>
                <button class="add_btn upload" @click="openAddFolderPopup(true)"><span></span><em>Upload Files</em></button>
            </div>
        </div>
        <div class="files_wrapper">
            <div class="files_list">
                <ul>
                    <li v-for="(folder, idx) in foldersList" @click="onFolderClick(folder)">
                        <div class="file_icon"><img src="@/assets/images/folder.svg"></div>
                        <div class="file_details"><span class="folder_name">{{ checkProperty(folder, 'folderName')
                        }}</span><span class="updated_on">Created
                                on:
                                <b>{{ checkProperty(folder, 'createdOn') | formatDateTime }}</b></span>
                            <div class="folders_files"><span class="folders"><b>{{ checkProperty(folder, 'folderCount')
                            }}</b>
                                    Folder(s)</span>|<span class="files"><b>{{ checkProperty(folder, 'fileCount') }}</b>
                                    File(s)</span></div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div class="table-responsive" v-if="checkProperty(filesList, 'length') > 0">
            <table class="table">
                <thead>
                    <tr>
                        <th class="pt-10">Files</th>
                        <th class="pt-10">Size </th>
                        <th class="pt-10">Uploaded By</th>
                        <th class="pt-10">Last Updated</th>
                        <th class="actions pt-10">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(document, idx) in filesList" v-if="checkProperty(document, 'documents', 'length') > 0">
                        <td>
                            <div class="title">
                                <!-- <figure class="files_img">
                                    <template>
                                        <img src="@/assets/images/files/pdf.svg" />
                                    </template>
                                </figure> -->

                                <DocumentsPreview v-if="checkProperty(document, 'documents', 'length') > 0" :type="'documents'"
                                    :documentsList="checkProperty(document, 'documents')" :includeDownloadText="false"
                                    @download_or_view="download_or_view" />

                                <figcaption>{{ checkProperty(document.documents[0], 'name') }}</figcaption>
                            </div>
                        </td>
                        <td>
                            <span>30 kb</span>
                        </td>
                        <td class="td_label">
                            <span>createdByName</span>
                        </td>
                        <td>
                            <span>createdByName</span>
                        </td>
                        <td>
                            <div class="actions actions-drpdown">
                                <dropdownHover>
                                    <b-dropdown-item>Edit</b-dropdown-item>
                                    <b-dropdown-item @click="download_or_view(document.documents[0])" v-if="checkProperty(document, 'documents', 'length') > 0">View</b-dropdown-item>
                                    <b-dropdown-item @click="downloads3file(document.documents[0])" v-if="checkProperty(document, 'documents', 'length') > 0">Download</b-dropdown-item>
                                    <b-dropdown-item v-if="false">Delete</b-dropdown-item>
                                </dropdownHover>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="table-responsive">
            <template v-if="checkProperty(foldersList, 'length') <= 0 && checkProperty(filesList, 'length') <= 0">
                <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Emails'
                    :loading="isListLoading" />
            </template>

        </div>

        <addFolderOrDocument v-if="showAddFolderPopup" @onUpdate="onFolderOrFileCreated" @onClose="closeAddFolderPopup"
            :isRootFolder="false" :isFilesUpload="isFilesUpload" :parentId="parentFolderId">
        </addFolderOrDocument>

    </div>
</template>
  

<script>
import dropdownHover from '@/views/forms/dropdownHover.vue';
import addFolderOrDocument from "@/views/mergedocuments/addFolderOrDocument.vue"
import NoDataFound from "@/views/common/noData.vue";
import DocumentsPreview from '@/views/common/documentsPreview.vue';

export default {

    components: {
        dropdownHover,
        addFolderOrDocument,
        NoDataFound,
        DocumentsPreview,
    },
    data: () => ({
        parentFolderId: null,
        isFilesUpload: false,
        showAddFolderPopup: false,
        breadCrumbs: [],
        isListLoading: false,
        page: 1,
        perpage: 20,
        totalCount: 0,
        foldersList: [],
        filesList: [],
    }),
    methods: {
        openAddFolderPopup(isAddFiles) {
            this.isFilesUpload = isAddFiles
            this.showAddFolderPopup = true
        },
        closeAddFolderPopup() {
            this.showAddFolderPopup = false
        },
        onFolderOrFileCreated() {
            this.showAddFolderPopup = false
            this.foldersList = []
            this.applyFilters()
        },

        applyFilters() {
            this.isListLoading = true
            this.updateLoading(true);
            this.page = 1
            this.getFoldersAndFiles()
        },
        applySearchFilters() {
            this.isListLoading = true
            this.updateLoading(true);
            this.page = 1
            if (this.filterSearch && this.filterSearch.length > 2) {
                this.getFoldersAndFiles()
            }
            if (this.filterSearch == '') {
                this.getFoldersAndFiles()
            }
        },
        getFoldersAndFiles() {

            let postData = {
                "matcher": {
                    "title": this.filterSearch,
                    "parentId": this.parentFolderId,
                },
                "sorting": {
                    "path": "createdOn", //title, statusName, createdByName, updatedOn, 
                    "order": -1
                },
                "page": this.page,
                "perpage": this.perpage
            }


            this.$store.dispatch("getEvaluationTemplatesList", postData)
                .then((res) => {
                    //  this.foldersList =res.data.result.list
                    this.foldersList = _.filter(res.data.result.list, (item) => {
                        return (this.checkProperty(item, 'parentId') == this.parentFolderId && this.checkProperty(item, 'entityType') == 'Folder')
                    })

                    this.filesList = _.filter(res.data.result.list, (item) => {
                        return (this.checkProperty(item, 'parentId') == this.parentFolderId && this.checkProperty(item, 'entityType') == 'Document')
                    })
                    if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
                        this.totalCount = this.checkProperty(res.data.result, 'totalCount');
                    }
                    this.isListLoading = false
                    setTimeout(() => {
                        this.updateLoading(false);
                    })
                })
                .catch((error) => {
                    this.isListLoading = false
                    setTimeout(() => {
                        this.updateLoading(false);
                    })
                })

        },
        onFolderClick(selectedFolder) {
            if (selectedFolder.type == 'baseFolder') {
                this.$router.push('/evaltemplates');
            } else {
                let folder = {
                    folderName: selectedFolder.folderName,
                    type: "folder",
                    base_type: 'root',
                    _id: selectedFolder._id
                }

                if (this.breadCrumbs[this.breadCrumbs.length - 1]._id == selectedFolder._id)
                    return
                if (this.checkProperty(folder, 'type') == 'folder') {
                    let breadCrumb = folder
                    let finalBreadCrumb = []
                    let isBreadCrumbFound = false;
                    _.forEach(this.breadCrumbs, (item) => {
                        if (!isBreadCrumbFound) {
                            if (item._id == selectedFolder._id) {
                                isBreadCrumbFound = true;
                            } else {
                                finalBreadCrumb.push(item)
                            }
                        }
                    })
                    finalBreadCrumb.push(breadCrumb)
                    this.breadCrumbs = finalBreadCrumb

                    this.parentFolderId = selectedFolder._id
                    this.foldersList = []
                    this.applyFilters()
                }
            }


            //    this.breadCrumbs.push(folder)

        },
        download_or_view(docItem) {

            let value = _.cloneDeep(docItem);
            var _self = this;
            this.formSubmited = false;
            if (_.has(value, "path")) {
                value["url"] = value["path"];
                value["document"] = value["path"];
            }

            if (_.has(value, "url")) {
                value["path"] = value["url"];
                value["document"] = value["url"];
            }

            if (_.has(value, "document")) {
                value["path"] = value["document"];
                value["url"] = value["document"];
            }
          
            this.selectedFile = value;
            this.docValue = "";
            this.docPrivew = false;
            this.docType = false;
            this.docType = this.findmsDoctype(value["name"], value.mimetype);

            if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
                //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
                value.url = value.url.replace(this.$globalgonfig._S3URL, "");
                value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
                let postdata = {
                    keyName: value.url,
                    "fileName": value.name ? value.name : ''
                };

                this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                    this.docValue = response.data.result.data;
                    if (this.docType == "office") {
                        this.docPrivew = true;
                        setTimeout(() => {
                           document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
                            let _editing = false;
                            var _ob = {}
                            _ob = {
                                name: value.name,
                                _id: value._id,
                                "extn": "docx",
                                "formLetterType": "Letter",
                                parentId: value._id

                            }
                            window.docEditor = new DocsAPI.DocEditor("placeholder2",
                                {

                                    "document": {
                                        "c": "forcesave",
                                        "fileType": "docx",
                                        "key": value._id,
                                        "userdata": JSON.stringify(_ob),
                                        "title": value.name,
                                        "url": response.data.result.data,
                                        permissions: {
                                            edit: _editing,
                                            download: true,
                                            reader: false,
                                            review: false,
                                            comment: false
                                        }
                                    },

                                    "documentType": "word",
                                    "height": "100%",
                                    "width": "100%",

                                    "editorConfig": {
                                        "userdata": JSON.stringify(_ob),
                                        "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                                        "customization": {
                                            "logo": {
                                                "image": "https://immibox.com/app/favicon.png",
                                                "imageDark": "https://immibox.com/app/favicon.png",
                                                "url": "https://immibox.com"
                                            },
                                            "anonymous": {
                                                "request": false,
                                                "label": "Guest"
                                            },
                                            "chat": false,
                                            "comments": false,
                                            "compactHeader": false,
                                            "compactToolbar": true,
                                            "compatibleFeatures": false,
                                            "feedback": {
                                                "visible": false
                                            },
                                            "forcesave": true,
                                            "help": false,
                                            "hideNotes": true,
                                            "hideRightMenu": true,
                                            "hideRulers": true,
                                            layout: {
                                                toolbar: {
                                                    "collaboration": false,
                                                },
                                            },
                                            "macros": false,
                                            "macrosMode": "warn",
                                            "mentionShare": false,
                                            "plugins": false,
                                            "spellcheck": false,
                                            "toolbarHideFileName": true,
                                            "toolbarNoTabs": true,
                                            "uiTheme": "theme-light",
                                            "unit": "cm",
                                            "zoom": 100
                                        },
                                    }, events: {
                                        onReady: function () {

                                        },
                                        onDocumentStateChange: function (event) {
                                            var url = event.data;
                                            console.log(event)

                                            if (!event.data) {

                                                if (value.editedDocument) {

                                                }

                                            }
                                        }

                                    }
                                });
                            //this.docValue = encodeURIComponent(response.data.result.data);
                        }, 100)
                    }

                    if (this.docType == "pdf") {

                        // this.downloadFile(this.docValue, value.mimetype, value.name)

                        // return
                        var _vid = value._id;
                        if (value.parentId) {
                            _vid = value.parentId;
                        }
                        var viewmode = 1; // Enable edit
                        viewmode = 0; //Disabled Edit
                        if (value.viewmode) {
                            viewmode = 0;
                        }
                        this.docValue = "https://carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
                        console.log(this.docValue)
                        this.docPrivew = true;
                    }
                    if (this.docType == "image") {
                        this.docPrivew = true;
                    }



                });
            } else {
                this.downloads3file(value);
            }

        },

    },
    mounted() {
        this.parentFolderId = this.$route.params.itemId
        let baseFolder = {
            folderName: 'Evaluation Templates',
            type: "baseFolder",
            base_type: 'root',
            _id: -1
        }
        this.breadCrumbs.push(baseFolder)

        let professorFolder = {
            folderName: localStorage.getItem('baseFolderName'),
            type: "folder",
            base_type: 'folder',
            _id: this.$route.params.itemId
        }
        this.breadCrumbs.push(professorFolder)
        this.getFoldersAndFiles()
    },
    computed: {

    },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },


}
</script>