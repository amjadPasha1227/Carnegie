<template>
    <b-modal v-model="showAddDocumet" id="create_template" dialog-class="create_template" centered no-close-on-backdrop>
        <template #modal-header>
            <h6 class="modal-title">{{ isFilesUpload ? 'Upload Files' : isDocumentEdit ? 'Edit Folder' : 'Create Folder' }}
            </h6>
            <a class="close" @click="onClosePopup"></a>
        </template>
        <template>
            <div class="user_form">
                <div class="row">
                    <div class="col-md-12" v-if="isRootFolder && repoType == 1">
                        <!-- <simpleInput :wrapclass="'mb20'" :label="'Title/Designation'" /> -->

                        <simpleSelect :label="'Select Professor'" :multiple="false" :wrapclass="'mb20'"
                            :optionslist="usersList" :display="true" :place-holder="'Select Professor'" :vvas="'Professor'"
                            :searchable="false" :required="true" :close-on-select="true" :clear-on-select="true"
                            v-model="selectedProfessor" :fieldName="'selectedProfessor'" :cid="'selectedProfessor'"
                            @input="onProfessorSelect" />
                    </div>
                    <div class="col-md-12" v-if="!isFilesUpload">
                        <simpleInput :wrapclass="'mb-0'" :fieldName="'folderName'" :cid="'folderName'"
                            :label="'Folder Name'" :placeHolder="'Folder Name'" :vvas="'Folder Name'" :display="true"
                            :required="true" v-model="folderName" />
                    </div>

                    <div class="col-md-12" v-if="isFilesUpload">
                        <fileUploadDrag :label="'Documents*'" :wrapclass="'mb-0'" :multiple="true" v-model="documents"
                            @uploadingFile="checkFileUploading($event)" :fileTypes="getUploadFileTypes" />
                        <input type="hidden" class="form-control" v-validate="'required'" v-model="documents"
                            data-vv-as="Documents" :name="'userroleRadio'" />
                        <span v-show="errors.has('userroleRadio')" class="form-error top_auto">{{
                            errors.first('userroleRadio')
                        }}</span>
                    </div>

                </div>
            </div>
        </template>
        <template #modal-footer>

            <button class="form-cancel" @click="onClosePopup">Cancel</button>
            <button class="primary_btn md" @click="onSubmitCreateFolderOrFile">{{ isDocumentEdit ? 'Update' : 'Create' }}
                <span class="loader" v-if="isFolderCreating"><img src="@/assets/images/loader.gif"></span>
            </button>
        </template>
    </b-modal>
</template>

<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import textArea from "@/views/forms/textarea.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";

export default {
    props: {
        isDocumentEdit: {
            type: Boolean,
            default: false
        },
        isRootFolder: {
            type: Boolean,
            default: false
        },
        isFilesUpload: {
            type: Boolean,
            default: false
        },
        parentId: {
            type: String,
            default: ''
        },
        repoType: {
            type: String,
            default: "1"
        },
        canPostProfessorId: {
            type: Boolean,
            default: false
        },


        selectedFolder: {
            type: Object,
            default: null
        },
        baseFolder: Object,


        customerData: Object,
    },
    components: {
        simpleSelect,
        simpleInput,
        fileUploadDrag,
    },
    data: () => ({
        showAddDocumet: false,
        usersList: [],
        selectedProfessor: null,
        folderName: '',
        isFolderCreating: false,
        documents: [],

    }),
    mounted() {
        this.getUsers()
        if (this.isDocumentEdit && this.checkProperty(this.selectedFolder, 'folderName')) {
            this.folderName = this.selectedFolder.folderName
        }
        this.$bvModal.show('create_template')
    },
    methods: {
        getUsers() {
            let postData =
            {
                "matcher": {
                    "title": '',
                    "searchString": "",
                    "statusList": [],
                    "createdByIds": [],
                    "createdDateRange": [],
                    "roleIds": [9],
                    "statusIds": [],
                    "typeIds": [],
                    "departmentIds": []
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": true,// if Masterdata required
                "page": 1,
                "perpage": 500,
            }
            this.$store.dispatch("getUsersList", postData)
                .then((res) => {
                    let lst = []
                    _.forEach(res.data.result.list, (item) => {
                        // let professorIndex = _.findIndex(this.checkProperty(this.evaluation, 'suggestProfessors'), (suggested) => {
                        //     return suggested["_id"] == item["_id"];
                        // })
                        item['isSuggested'] = false;
                        // if (professorIndex > -1) {
                        //     item['isSuggested'] = true;
                        // }
                        lst.push(item);
                    });

                    this.usersList = lst
                })
                .catch((error) => {
                })
        },
        onClosePopup() {
            this.$emit('onClose')
            this.$bvModal.hide('create_template')
        },
        onProfessorSelect(selectedValue) {
            if (!this.folderName) {
                this.folderName = this.checkProperty(selectedValue, 'name') ? this.checkProperty(selectedValue, 'name') : ''
            }
        },

        onSubmitCreateFolderOrFile() {
            if (this.isRootFolder) {
                this.$validator.validateAll().then((result) => {
                    if (result) {
                        this.isFolderCreating = true
                        if (this.isDocumentEdit) {
                            let postData = {
                                "title": this.folderName,
                                "evaluationTempId": this.selectedFolder['_id']
                            }

                            this.$store
                                .dispatch("updateTemplateFolder", postData)
                                .then((response) => {
                                    this.isFolderCreating = false
                                    if (response.error) {
                                        this.showToster({ message: response.error.message, isError: true });
                                    } else {
                                        this.showToster({ message: response.message, isError: false });
                                        this.$emit('onUpdate')
                                        this.$bvModal.hide('create_template')
                                    }
                                })
                                .catch((error) => {
                                    this.isFolderCreating = false
                                    this.showToster({ message: error, isError: true });
                                });
                        }
                        else {
                            let postData = {
                                "folderName": this.folderName,
                                "folderEntityType": 'Folder',
                                "type": this.repoType
                            }
                            if (this.repoType == 1) {
                                Object.assign(postData, { 'professorId': this.checkProperty(this.selectedProfessor, '_id') ? this.checkProperty(this.selectedProfessor, '_id') : '' })
                            }

                            this.$store
                                .dispatch("createTemplateFolder", postData)
                                .then((response) => {
                                    this.isFolderCreating = false
                                    if (response.error) {
                                        this.showToster({ message: response.error.message, isError: true });
                                    } else {
                                        this.showToster({ message: response.message, isError: false });
                                        this.$emit('onUpdate')
                                        this.$bvModal.hide('create_template')
                                    }
                                })
                                .catch((error) => {
                                    this.isFolderCreating = false
                                    this.showToster({ message: error, isError: true });
                                });
                        }
                    }
                })
            } else {
                this.$validator.validateAll().then((result) => {
                    if (result) {
                        this.isFolderCreating = true
                        if (this.isFilesUpload) {
                            _.forEach(this.documents, (dccFile, indx) => {
                                let postData = {
                                    "parentId": this.parentId,
                                    "type": this.repoType
                                }
                                if (this.canPostProfessorId) {
                                    Object.assign(postData, { 'professorId': this.baseFolder.professorId })
                                }

                                Object.assign(postData, { 'documents': [dccFile], "folderEntityType": 'Document' })
                                this.$store
                                    .dispatch("createTemplateFolder", postData)
                                    .then((response) => {
                                        if (indx == this.documents.length - 1) {
                                            this.isFolderCreating = false
                                        }

                                        if (response.error) {
                                            this.showToster({ message: response.error.message, isError: true });
                                        } else {
                                            if (indx == this.documents.length - 1) {
                                                this.showToster({ message: response.message, isError: false });
                                                this.$emit('onUpdate')
                                                this.$bvModal.hide('create_template')
                                            }
                                        }
                                    })
                                    .catch((error) => {
                                        this.isFolderCreating = false
                                        this.showToster({ message: error, isError: true });
                                    });
                            })

                        } else {
                            if (this.isDocumentEdit) {
                                let postData = {
                                    "title": this.folderName,
                                    "evaluationTempId": this.selectedFolder['_id']
                                }

                                this.$store
                                    .dispatch("updateTemplateFolder", postData)
                                    .then((response) => {
                                        this.isFolderCreating = false
                                        if (response.error) {
                                            this.showToster({ message: response.error.message, isError: true });
                                        } else {
                                            this.showToster({ message: response.message, isError: false });
                                            this.$emit('onUpdate')
                                            this.$bvModal.hide('create_template')
                                        }
                                    })
                                    .catch((error) => {
                                        this.isFolderCreating = false
                                        this.showToster({ message: error, isError: true });
                                    });
                            }
                            else {
                                let postData = {
                                    "parentId": this.parentId,
                                }
                                if (this.canPostProfessorId) {
                                    Object.assign(postData, { 'professorId': this.baseFolder.professorId })
                                }

                                // if (this.isFilesUpload) {
                                //     Object.assign(postData, { 'documents': this.documents, "folderEntityType": 'Document' })
                                // } else {
                                Object.assign(postData, { 'folderName': this.folderName, "folderEntityType": 'Folder' })
                                // }
                                this.$store
                                    .dispatch("createTemplateFolder", postData)
                                    .then((response) => {
                                        this.isFolderCreating = false
                                        if (response.error) {
                                            this.showToster({ message: response.error.message, isError: true });
                                        } else {
                                            this.showToster({ message: response.message, isError: false });
                                            this.$emit('onUpdate')
                                            this.$bvModal.hide('create_template')
                                        }
                                    })
                                    .catch((error) => {
                                        this.isFolderCreating = false
                                        this.showToster({ message: error, isError: true });
                                    });
                            }
                        }
                    }
                })
            }


        },
        checkFileUploading() {
            let uploading = false
            let resultDocs = _.filter(this.documents, (docItem) => {
                return this.checkProperty(docItem, 'fileUploading') && docItem.fileUploading
            })
            console.log('resultDocs' + JSON.stringify(resultDocs))
            if (this.checkProperty(resultDocs, 'length') > 0) {
                if (!uploading) {
                    uploading = true
                }
            }
            this.isFileUplading = uploading
        }

    },
    computed: {

        getUploadFileTypes() {

            if (this.repoType == 2) {
                return "image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            }
            return 'application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        }
    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>