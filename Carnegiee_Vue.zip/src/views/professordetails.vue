<template>
    <div class="professor_page">
        <header class="main_header header_professor">
            <div class="logo">
                <a href="#"><img src="@/assets/images/logo_carne.png"></a>
            </div>
            <div class="right">
                <div class="notification_sec" v-if="false">
                    <span class="notification_icon new_notification"><img src="@/assets/images/notification.png"></span>
                </div>
                <div class="profile_sec">
                    <b-dropdown size="lg" variant="link" right>
                        <template #button-content>
                            <div class="profile_icon">
                                <img src="@/assets/images/profile-user.png">
                            </div>
                            <div class="profile_text">
                                <p>{{ getUserData | formatFullname }}</p>
                                <small v-if="checkProperty(getUserData, 'roleName')">{{ checkProperty(getUserData,
                                    'roleName') }}</small>
                            </div>
                            <em class="profile_arrow">
                                <img src="@/assets/images/down-chevron.svg">
                            </em>
                        </template>
                        <b-dropdown-item
                            @click="openProfilePopup(), $bvModal.show('profile_model')">Profile</b-dropdown-item>
                        <b-dropdown-item @click="openChangePassword()">Change Password</b-dropdown-item>
                        <b-dropdown-item @click="logout()">Logout</b-dropdown-item>
                    </b-dropdown>
                </div>
            </div>
        </header>
        <div class="professor_inner">

            <div class="page_header">
                <h3>Evaluations</h3>
            </div>
            <div class="filter_sec">
                <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" />

                <simpleSelect :multiple="true" :wrapclass="'req_status'" :optionslist="statusList" :display="true"
                    :place-holder="'Status'" :searchable="false" :required="false" :close-on-select="false"
                    :clear-on-select="true" v-model="filterSelectedStatuses" :fieldName="'filterStatus'"
                    :cid="'filterStatus'" :hideSelected="true" @input="storeSelectedStatusAndApply" />
                <simpleSelect :multiple="true" :wrapclass="'priority'" :optionslist="priorityList" :display="true"
                    :place-holder="'Priority'" :searchable="false" :required="false" :close-on-select="false"
                    :clear-on-select="true" v-model="filterSelectedPriority" :fieldName="'filterPriority'"
                    :cid="'filterPriority'" :hideSelected="true" @input="applyFilters" />
                <simpleSelect :multiple="true" :wrapclass="'customer'" :optionslist="customerList" :display="true"
                    :place-holder="'Client'" :searchable="false" :required="false" :close-on-select="false"
                    :clear-on-select="true" v-model="filterSelectedcustomers" :fieldName="'filterCustomer'"
                    :cid="'filterCustomer'" :hideSelected="true" @input="applyFilters" />

                <button v-if="false" class="filter_btn"><span></span><em>Filters</em></button>

            </div>
            <div class="table-responsive">
                <template v-if="checkProperty(evaluationsList, 'length') <= 0">
                    <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users'
                        :loading="isListLoading" />
                </template>
                <table class="table" v-if="checkProperty(evaluationsList, 'length') > 0 && !isListLoading">
                    <thead>
                        <tr>
                            <th>Request Id</th>
                            <th>Type of Evaluations</th>
                            <th>Beneficiary</th>
                            <th>Priority</th>
                            <th>Due Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>

                        <tr v-for="(item, index) in evaluationsList" v-bind:key="index">
                            <td>
                                <span class="request_id" @click="openDetailsPopup(item)">{{ item.requestId
                                }}</span>
                            </td>
                            <td>
                                <div v-if="checkProperty(item, 'docsConfig', 'length') > 0" class="evalution_type">
                                    <span @click="openDetailsPopup(item)">{{
                                        item.docsConfig[0].evaluationTypeName
                                    }}</span>
                                    <em v-if="checkProperty(item, 'docsConfig', 'length') > 1" class="count"
                                        :id="'popover-target-' + index">{{ '+' + (checkProperty(item, 'docsConfig',
                                            'length') -
                                            1)
                                        }}</em>

                                    <b-popover custom-class="evalution_list_wrap" :target="'popover-target-' + index"
                                        triggers="hover" placement="top" fallback-placement="flip">
                                        <template>
                                            <ul>
                                                <li v-for="(evaluationItem, indx) in checkProperty(item, 'docsConfig')"
                                                    :key="indx" v-if="indx > 0">{{ evaluationItem.evaluationTypeName }}</li>
                                            </ul>
                                        </template>
                                    </b-popover>
                                </div>
                                <div v-else></div>
                            </td>
                            <td>
                                <div class="beneficiary_sec">
                                    <span class="icon"><img src="@/assets/images/profile-user.png"></span>
                                    <span>{{ checkProperty(item, 'beneficiaryInformation') | formatFullname }}</span>
                                </div>
                            </td>

                            <td><span :class="checkProperty(item, 'priorityId') == 2 ? 'rush' : ''">{{
                                checkProperty(item, 'priorityDetails', 'name') }}</span></td>
                            <td><span>{{ checkProperty(item, 'dueDate') | formatDate }}</span></td>
                            <td><span class="status " v-bind:class="{
                                'reviewed': [9, 12].indexOf(checkProperty(item, 'statusDetails', 'id')) > -1,
                                'waiting_for_invoice': [7, 13].indexOf(checkProperty(item, 'statusDetails', 'id')) > -1,
                                'delivered': [3, 15, 14].indexOf(checkProperty(item, 'statusDetails', 'id')) > -1,
                                'delivered': isActivityCompleted(item, 'SIGN_APPROVED'),
                            }">{{ getStatusName(item) }}</span></td>

                        </tr>
                    </tbody>
                </table>
                <div class="pagination-sec" v-if="checkProperty(evaluationsList, 'length') > 0">
                    <div class="per-page">
                        <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) +
                            evaluationsList.length) +
                            ' of ' + totalCount + ' Results' }}</label>
                    </div>
                    <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
                        @input="onPageChange"></b-pagination>
                </div>
            </div>
            <span class="loader" v-if="isDetailsLoading"><img src="@/assets/images/loader.gif"></span>
        </div>

        <!-- Evaluation Details Model -->
        <b-modal v-model="showDetailsPopup" id="request_detail_model" dialog-class="request_detail_model" centered
            hide-header hide-footer>
            <template>
                <div class="req_details_page">
                    <div class="req_details_inner">
                        <div class="rq_header rq-clients">
                            <div class="rq-select">
                                <div class="rq-number">
                                    <h5 v-if="checkProperty(evaluationDetails, 'requestId')">Evaluations /
                                        <a>{{ checkProperty(evaluationDetails, 'requestId') }}</a>
                                    </h5>
                                    <div v-if="checkProperty(evaluationDetails, 'docsConfig', 'length') > 0"
                                        class="evalution_type">
                                        <span v-if="checkProperty(evaluationDetails.docsConfig[0], 'evaluationTypeName')">{{
                                            evaluationDetails.docsConfig[0].evaluationTypeName }}</span>
                                        <div v-if="checkProperty(evaluationDetails, 'docsConfig', 'length') > 1"
                                            class="evalution_dropdown">
                                            <em class="count" id="popover-target-10000">{{ '+' +
                                                (checkProperty(evaluationDetails, 'docsConfig',
                                                    'length') - 1) }}</em>
                                            <b-popover custom-class="evalution_list_wrap" target="popover-target-10000"
                                                triggers="hover" placement="top" fallback-placement="flip">
                                                <template>
                                                    <ul>
                                                        <li v-for="(evaluationItem, indx) in checkProperty(evaluationDetails, 'docsConfig')"
                                                            :key="indx" v-if="indx > 0">{{ evaluationItem.evaluationTypeName
                                                            }}</li>
                                                    </ul>
                                                </template>
                                            </b-popover>
                                        </div>
                                    </div>
                                </div>
                                <div class="rq-review">
                                    <div class="due_date" v-if="checkProperty(evaluationDetails, 'dueDate')">
                                        <h4><span>Due by </span> {{ checkProperty(evaluationDetails, 'dueDate') | formatDate
                                        }}</h4>
                                        <figure class="due_date_icon bg-light"><img src="../assets/images/calender.png">
                                        </figure>
                                    </div>
                                    <div v-if="checkProperty(evaluationDetails, 'priorityDetails', 'name')"
                                        class="status rush bg-light"><img src="@/assets/images/clock.png"> {{
                                            checkProperty(evaluationDetails, 'priorityDetails', 'name') }}</div>
                                </div>
                            </div>
                            <a class="close" @click="$bvModal.hide('request_detail_model')"></a>
                        </div>
                        <section class="timeline tq_timeline" show-day-and-month="true">
                            <div class="wrapper-timeline">
                                <div v-if="isActivityCompleted(evaluationDetails, 'SIGN_APPROVED')" class="wrapper-item">
                                    <div class="section-year">
                                        <p> {{ checkProperty(getActivityLog(evaluationDetails, 'SIGN_APPROVED'),
                                            'updatedOn') | formatTime }}</p>
                                        <p> {{ checkProperty(getActivityLog(evaluationDetails, 'SIGN_APPROVED'),
                                            'updatedOn') | formatDate }}</p>
                                    </div>
                                    <section class="timeline-item">
                                        <div class="item">
                                            <span class="status_dot status_conform"></span>
                                            <div class="status-name conform_bg">Documents are Approved</div>
                                            <div class="submit_detailes">
                                                <h4>Documents are Approved</h4>
                                            </div>
                                        </div>
                                    </section>
                                </div>

                                <!-- <div v-if="isActivityCompleted(evaluationDetails, 'SIGN_REQUESTED') && (checkProperty(evaluationDetails, 'isRequested') && evaluationDetails.isRequested)"
                                    class="wrapper-item">

                                    <div class="wrapper-item">
                                        <actionApproveDocuments :evaluation="evaluationDetails"
                                            @updateDetails="updateListandDetails(evaluationDetails)" :activityLog="activity"
                                            :isLastDoneActivity="checkProperty(activity, '_id') == checkProperty(evaluationDetails, 'latestEvaluationLog', '_id') ? true : false"
                                            @download_or_view="download_or_view" :isCompletedActivity="false">
                                        </actionApproveDocuments>
                                    </div>

                                </div> -->

                                <div v-if="isActivityCompleted(evaluationDetails, 'SIGN_REQUESTED')" class="wrapper-item"
                                    v-for="( activity, index) in getRevisionLogs()">

                                    <!-- <div v-if="checkProperty(activity, 'action') == 'SIGN_REQUESTED'" class="wrapper-item"> -->
                                    <actionApproveDocuments
                                        v-if="!(index == 0 && ((checkProperty(evaluationDetails, 'isRequested') && evaluationDetails.isRequested)))"
                                        :evaluation="evaluationDetails"
                                        @updateDetails="updateListandDetails(evaluationDetails)" :activityLog="activity"
                                        :isLastDoneActivity="checkProperty(activity, '_id') == checkProperty(evaluationDetails, 'latestEvaluationLog', '_id') ? true : false"
                                        @download_or_view="download_or_view" :isCompletedActivity="true">
                                    </actionApproveDocuments>

                                    <actionApproveDocuments
                                        v-if="index == 0 && ((checkProperty(evaluationDetails, 'isRequested') && evaluationDetails.isRequested))"
                                        :evaluation="evaluationDetails"
                                        @updateDetails="updateListandDetails(evaluationDetails)" :activityLog="activity"
                                        :isLastDoneActivity="checkProperty(activity, '_id') == checkProperty(evaluationDetails, 'latestEvaluationLog', '_id') ? true : false"
                                        @download_or_view="download_or_view"
                                        :isCompletedActivity="isActivityCompleted(evaluationDetails, 'SIGN_APPROVED') ? true : false">
                                    </actionApproveDocuments>
                                    <!-- </div>
                                    <div v-if="checkProperty(activity, 'action') == 'SENT_FOR_REVISION'"
                                        class="wrapper-item">
                                        <actionApproveDocuments :evaluation="evaluationDetails" :activityLog="activity"
                                            @updateDetails="updateListandDetails(evaluationDetails)" :isRevisionSent="true"
                                            :isLastDoneActivity="checkProperty(activity, '_id') == checkProperty(evaluationDetails, 'latestEvaluationLog', '_id') == 0 ? true : false"
                                            @download_or_view="download_or_view" :isCompletedActivity="true">
                                        </actionApproveDocuments>
                                    </div> -->
                                </div>



                                <!-- <div class="wrapper-item">
                                    <div class="section-year">
                                        <p> 12:50PM </p>
                                        <p> 2 FEB 2023 </p>
                                    </div>
                                    <section class="timeline-item">
                                        <div class="item">
                                            <span class="status_dot status_req"></span>
                                            <div class="status-name req_bg">Case Requested</div>
                                            <div class="submit_detailes">
                                                <h4>Documents are ready for review
                                                </h4>
                                            </div>
                                        </div>
                                    </section>
                                </div> -->
                            </div>
                        </section>
                    </div>
                </div>
            </template>
        </b-modal>

        <!-- Add Notes Modal -->
        <b-modal id="addnotes_model" dialog-class="addnotes_model" centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Add Notes</h6>
                <a class="close" @click="$bvModal.hide('addnotes_model')"></a>
            </template>
            <template>
                <div class="row">
                    <div class="col-md-12">
                        <textArea :wrapclass="'mb-0'" :place-holder="'Type Here…'"></textArea>
                        <small>For minor changes, you may provide instructions into the text box above.<br /> Any major
                            changes, you are requested to upload document with your suggested changes.</small>
                    </div>
                </div>
            </template>
            <template #modal-footer>
                <div class="upload-file me-auto">
                    <input class="upload_input" ref="file" type="file">
                    <div class="upload_btn uploaded" @click="$bvModal.show('doc_model')">
                        <svg viewBox="0 0 24 24" width="15" height="15" stroke="currentColor" stroke-width="2" fill="none"
                            stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">
                            <polyline points="16 16 12 12 8 16"></polyline>
                            <line x1="12" y1="12" x2="12" y2="21"></line>
                            <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"></path>
                            <polyline points="16 16 12 12 8 16"></polyline>
                        </svg>
                        UPLOAD
                    </div>
                </div>
                <button class="form-cancel me-4" @click="$bvModal.hide('addnotes_model')">Cancel</button>
                <button class="primary_btn md">Submit</button>
            </template>
        </b-modal>

        <!-- Profile Modal -->
        <b-modal id="profile_model" dialog-class="profile_model" centered hide-header hide-footer no-close-on-backdrop>
            <template>
                <div class="profile_header">


                    <!-- <div class="profile_icon">
                        <img  v-if="checkProperty(profileData, 'details', 'profileURL')" :src=" checkProperty(profileData, 'details', 'profileURL') ">
            <img  v-else :src=" checkProperty(profileData, 'details', 'profileURL') ">
                        <figure><img src="@/assets/images/professors.svg"></figure>
                    </div> -->

                    <div class="profile_title">
                        <h6>{{ checkProperty(getUserData, 'name') }}</h6>
                        <p v-if="checkProperty(getUserData, 'roleName')">{{ checkProperty(getUserData, 'roleName') }}</p>
                        <p v-if="checkProperty(getUserData, 'details', 'designation')">{{ checkProperty(getUserData,
                            'details',
                            'designation') }}</p>
                    </div>
                    <a class="close" @click=" $bvModal.hide('profile_model')"></a>
                </div>
                <div class="profile_info">
                    <ul>
                        <li v-if="checkProperty(getUserData, 'details', 'email')">
                            <span class="info_header">Email</span>
                            <p class="desc">{{ checkProperty(getUserData, 'details', 'email') }}</p>
                        </li>
                        <li v-if="checkProperty(getUserData, 'details', 'phone')">
                            <span class="info_header">Phone</span>
                            <p class="desc">
                                {{ checkProperty(getUserData.phoneCountryCode, 'countryCallingCode') | countryFormatter }}
                                {{ checkProperty(getUserData, 'phone') | formatPhone }}
                            </p>
                        </li>
                        <li v-if="checkProperty(getUserData, 'details', 'userName')">
                            <span class="info_header">Username</span>
                            <p class="desc">{{ checkProperty(getUserData, 'details', 'userName') }}</p>
                        </li>
                        <li v-if="checkProperty(getUserData, 'departmentDetails', 'name')">
                            <span class="info_header">Department</span>
                            <p class="desc">{{ checkProperty(getUserData, 'departmentDetails', 'name') }}</p>
                        </li>
                        <li v-if="checkProperty(getUserData, 'details', 'profileURL')">
                            <span class="info_header">Profile URL</span>
                            <a href="#" class="link">{{ checkProperty(getUserData, 'details', 'profileURL') }}</a>
                        </li>
                        <li
                            v-if="checkProperty(getUserData, 'details', 'letterHead') && checkProperty(getUserData['details'], 'letterHead', 'length') > 0">
                            <span class="info_header">Copy of letterhead</span>
                            <!-- <div class="download_sec">
                <img src="@/assets/images/pdf-file-format.svg">
                <a href="#" class="link_btn">Download</a>
              </div> -->
                            <DocumentsPreview :type="'documents'"
                                :documentsList="checkProperty(getUserData, 'details', 'letterHead')"
                                :includeDownloadText="false" @download_or_view="download_or_view" />
                        </li>
                        <li v-if="(checkProperty(getUserData, 'details', 'bioAndResume') || (checkProperty(getUserData, 'details', 'documents') && checkProperty(getUserData['details'], 'documents', 'length') > 0))"
                            class="bio_resume">
                            <span v-if="checkProperty(getUserData, 'details', 'bioAndResume')"
                                class="info_header">Bio/Resume</span>
                            <p v-if="checkProperty(getUserData, 'details', 'bioAndResume')"
                                v-html="checkProperty(getUserData, 'details', 'bioAndResume')"></p>
                            <div
                                v-if="checkProperty(getUserData, 'details', 'documents') && checkProperty(getUserData['details'], 'documents', 'length') > 0">
                                <DocumentsPreview :type="'documents'"
                                    :documentsList="checkProperty(getUserData, 'details', 'documents')"
                                    :includeDownloadText="false" @download_or_view="download_or_view" />
                            </div>

                            <!-- <div v-if="checkProperty(getUserData, 'details', 'bioAndResume')" class="download_sec">
                <img src="@/assets/images/pdf-file-format.svg">
                <a href="#" class="link_btn">Download</a>
              </div> -->
                        </li>
                    </ul>
                </div>
            </template>
        </b-modal>

        <b-modal id="preview_model" v-model="docPrivew" dialog-class="document_modal"
            :title="checkProperty(selectedFile, 'name')">
            <h2> <img :class="{
                pdf_view_download: docType == 'pdf',
                office_view_download: docType == 'office',
                image_view_download: docType == 'image',
            }" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>
            <div class="pdf_loader">
                <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/loader.gif" /></figure>

                <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
                <template v-if="docType == 'office'">
                    <div style="height:90vh">

                        <div id="placeholder" style="height:100%"></div>
                    </div>
                </template>
                <template v-else-if="docType == 'image'">
                    <img :src="docValue" />
                </template>
                <template v-else-if="docType == 'pdf'">
                    <div class="pdf" style="height:90vh">

                        <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%"
                            width="100%">

                        </iframe>
                    </div>
                </template>
            </div>
        </b-modal>

        <!----updatePasswordPopUp-->
        <b-modal v-model="showPasswordChangePopup" id="changePassword" dialog-class="changePassword" centered
            no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Change Password </h6>
                <a class="close" @click="closeChangePassword"></a>
            </template>
            <template>
                <div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form_group">

                                <!-- <lable class="form_label">Current Password<em>*</em></lable> -->
                                <simpleInput :wrapclass="'mb20'" :required="true" :vvas="'Current Password'"
                                    :label="'Current Password'" v-model="conformPassword"
                                    :datatype="'min:5|max:15|strongpassword'" :placeHolder="'Current Password'"
                                    :cid="'currentPassword'" :fieldName="'currentpassword'" :isPassword="true" />
                                <!-- <div class="view_eye" :class="{ close: showCurrentPassword }" @click="showCurrentPassword != showCurrentPassword"> </div> -->
                                <!-- <span v-show="errors.has('currentpassword')" class="form-error">
                  {{ errors.first("currentpassword") }}
                </span> -->



                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form_group">
                                <!-- <lable class="form_label">New Password<em>*</em></lable>
                <input :wrapclass="'mb20'" ref="password" v-validate="'required|min:5|max:15|strongpassword'"
                  :data-vv-as="'Password'" v-model="password" :type="'password'" class="form-control"
                  placeholder="Password" id="inputNewPassword" name="newpassword" />
                <span v-show="errors.has('newpassword')" class="form-error">
                  {{ errors.first("newpassword") }}
                </span> -->
                                <simpleInput :wrapclass="'mb20'" :required="true" :vvas="'New Password'"
                                    :label="'New Password'" v-model="password" :datatype="'min:5|max:15|strongpassword'"
                                    :placeHolder="'New Password'" :cid="'newpassword'" :fieldName="'newpassword'"
                                    :isPassword="true" />

                            </div>
                        </div>
                    </div>
                </div>
            </template>
            <template #modal-footer>
                <!----showLoader-->
                <p class="password_note"><img src="@/assets/images/lock.svg"> Password must contain 6 to 15 characters</p>
                <button class="form-cancel" @click="closeChangePassword">Cancel</button>
                <button class="primary_btn md" @click="updatePassword">Update</button>
            </template>
        </b-modal>
    </div>
</template>


<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleSelect from '@/views/forms/simpleSelect.vue';
import NoDataFound from "@/views/common/noData.vue";
import textArea from "@/views/forms/textarea.vue";
import _ from "lodash";
import actionApproveDocuments from "@/views/evaluationactions/actionApproveDocuments.vue";
import JQuery from "jquery";
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import simpleInput from "@/views/forms/simpleInput.vue";


export default {
    name: 'dashboard-view',
    components: {
        searchInput,
        simpleSelect,
        NoDataFound,
        textArea,
        actionApproveDocuments,
        DocumentsPreview,
        simpleInput,
    },
    data: () => ({
        isListLoading: true,
        page: 1,
        perpage: 20,
        totalCount: 0,
        currentPage: 1,
        statusList: [],
        priorityList: [],
        customerList: [],
        evaluationsList: [],
        filterSelectedStatuses: [],
        filterSelectedPriority: [],
        filterSelectedcustomers: [],
        filterSearch: '',
        evaluationDetails: null,
        showDetailsPopup: false,
        isDetailsLoading: false,
        showProfilePopup: false,
        docPrivew: false,
        docType: '',
        formSubmited: false,
        selectedFile: null,
        showPasswordChangePopup: false,
        password: '',
        showPassword: false,
        conformPassword: '',
    }),
    methods: {

        getEvaluations() {
            let statusIds = []
            let priorityIds = []
            let customerIds = []
            if (this.filterSelectedStatuses && this.checkProperty(this.filterSelectedStatuses, 'length') > 0) {
                statusIds = this.filterSelectedStatuses.map((item) => item.id)
            }
            if (this.filterSelectedPriority && this.checkProperty(this.filterSelectedPriority, 'length') > 0) {
                priorityIds = this.filterSelectedPriority.map((item) => item.id)
            }
            if (this.filterSelectedcustomers && this.checkProperty(this.filterSelectedcustomers, 'length') > 0) {
                customerIds = this.filterSelectedcustomers.map((item) => item._id)
            }
            let postData =
            {
                "matcher": {
                    "searchString": this.filterSearch,
                    "evaluationTypeIds": [],
                    "statusIds": statusIds,
                    "locationIds": [],
                    "priorityIds": priorityIds,
                    "customerIds": customerIds,
                    "createdDateRange": []
                },
                "sorting": {
                    "path": "updatedOn",
                    "order": -1
                },
                "page": this.page,
                "perpage": this.perpage,
            }
            this.$store.dispatch("getIndividualEvaluationsList", postData)
                .then((res) => {
                    this.isListLoading = false
                    this.updateLoading(false);
                    this.evaluationsList = res.data.result.list
                    if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
                        this.totalCount = this.checkProperty(res.data.result, 'totalCount');
                    }
                    setTimeout(() => {
                        this.updateLoading(false);
                    })
                })
                .catch((error) => {
                    this.evaluationsList = []
                    this.isListLoading = false
                    this.updateLoading(false);
                })
        },
        applyFilters() {

            this.isListLoading = true
            this.updateLoading(true);
            this.page = 1
            this.getEvaluations()
        },
        applySearchFilters() {
            this.page = 1
            if (this.filterSearch && this.filterSearch.length > 2) {
                this.isListLoading = true
                this.updateLoading(true);
                this.getEvaluations()
            }
            if (this.filterSearch == '') {
                this.isListLoading = true
                this.updateLoading(true);
                this.getEvaluations()
            }
        },
        getMasterDataList(category) {
            this.$store.dispatch("getMasterData", category)
                .then((res) => {
                    if (category == 'evaluation_status') {
                        if (this.getUserRoleId == 9) {
                            this.statusList = _.filter(res, (item) => {
                                return (item.id == 12 || item.id == 13 || item.id == 14)
                            });
                        } else {
                            this.statusList = res;
                        }
                    }
                    if (category == 'evaluation_priority') {
                        this.priorityList = res
                    }
                })
        },
        getCustomersList() {
            let postData =
            {
                "matcher": {
                },
                "sorting": {
                    "path": "createdOn",
                    "order": 1
                },
                "getMasterData": true,// if Masterdata required
                "page": 1,
                "perpage": 500,
            }

            this.$store.dispatch("getcustomerList", postData)
                .then((res) => {
                    this.customerList = res.data.result.list
                })

        },
        openDetailsPopup(selectedItem) {
            // this.isDetailsLoading = true
            // this.evaluationDetails = null
            // this.getEvaluationDetails(selectedItem, true)

            if (this.checkProperty(selectedItem, '_id')) {
                let routedId = this.checkProperty(selectedItem, '_id')
                let path = "/requestdetails/" + routedId;
                // if (this.encodedString != '') {
                //     path = path + "?filter=" + this.encodedString;
                // }
                this.$router.push(path);
            }
        },
        closeDetailsPopup() {
            this.showDetailsPopup = false
        },
        getEvaluationDetails(item, showDetails) {
            let postData =
            {
                "evaluationId": item._id,
            }
            this.$store.dispatch("getEvaluationDetails", postData)
                .then((res) => {
                    this.isDetailsLoading = false
                    if (this.checkProperty(res, 'result') == null) {
                        this.showToster({ message: "Access denied!", isError: true });
                    } else {
                        this.evaluationDetails = res.result
                        this.showDetailsPopup = true
                    }
                })
                .catch((error) => {
                    this.isDetailsLoading = false
                })
        },
        logout() {
            this.$store.dispatch("logout").then(() => {
                this.$store.commit("setFilters", []);
                this.$router.push("/login");
            });
        },
        updateListandDetails(evaluation) {
            this.applyFilters()
            this.getEvaluationDetails(evaluation, true)
        },

        openProfilePopup() {
            this.showProfilePopup = true
            console.log(this.getUserData)
            //  this.$refs['success_model'].show();
            //  $bvModal.show('profile_model')
        },
        download_or_view(docItem) {


            let value = _.cloneDeep(docItem);
            // if (this.checkProperty(this.getPetitionDetails, 'caseNo') && this.checkProperty(value, 'name')) {
            //   let docName = _.cloneDeep(value['name']);
            //   value['name'] = this.checkProperty(this.getPetitionDetails, 'caseNo') + "_" + docName;
            // }


            var _self = this;
            this.formSubmited = false;
            if (_.has(value, "path")) {
                value["url"] = value["path"];
                value["document"] = value["path"];
            }

            if (_.has(value, "url")) {
                value["path"] = value["url"];
                value["document"] = value["url"];
            }

            if (_.has(value, "document")) {
                value["path"] = value["document"];
                value["url"] = value["document"];
            }
            // value = Object.assign(value, { 'petitionId': this.petition['_id'] })
            // value = Object.assign(value, { 'subTypeDetails': this.petition['subTypeDetails'] })


            this.selectedFile = value;
            this.docValue = "";
            this.docPrivew = false;
            this.docType = false;
            this.docType = this.findmsDoctype(value["name"], value.mimetype);

            if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
                //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
                value.url = value.url.replace(this.$globalgonfig._S3URL, "");
                value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
                let postdata = {
                    keyName: value.url,
                    // "petitionId": value['petitionId'],

                    // entityType:value['petitionId']
                    "fileName": value.name ? value.name : ''
                };
                // if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
                //   postdata['entityType'] = 'perm'
                // } else {
                //   postdata['entityType'] = 'case'
                // }


                this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                    this.docValue = response.data.result.data;


                    if (this.docType == "office") {
                        this.docPrivew = true;
                        setTimeout(() => {
                            document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
                            let _editing = false;

                            // if ([3, 4].indexOf(this.getUserRoleId) > -1) {
                            //   _editing = false;
                            // }

                            // if (value.viewmode) {
                            //   _editing = false;
                            // }
                            var _ob = {}
                            // if (value.editedDocument) {
                            //   _ob = {

                            //     evaluationId: this.evaluationDetails._id,
                            //     name: value.name,
                            //     _id: value._id,
                            //     "extn": "docx",
                            //     "formLetterType": "Letter",
                            //     parentId: value.parentId
                            //   }

                            // } else {

                            _ob = {

                                name: value.name,
                                evaluationId: this.evaluationDetails._id,
                                _id: value._id,
                                "extn": "docx",
                                "formLetterType": "Letter",
                                parentId: value._id

                            }

                            //  }


                            window.docEditor = new DocsAPI.DocEditor("placeholder2",
                                {

                                    "document": {
                                        "c": "forcesave",
                                        "fileType": "docx",
                                        "key": value._id,
                                        "userdata": JSON.stringify(_ob),
                                        "title": value.name,
                                        "url": response.data.result.data,
                                        permissions: {
                                            edit: _editing,
                                            download: true,
                                            reader: false,
                                            review: false,
                                            comment: false
                                        }
                                    },

                                    "documentType": "word",
                                    "height": "100%",
                                    "width": "100%",

                                    "editorConfig": {
                                        "userdata": JSON.stringify(_ob),
                                        "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                                        "customization": {
                                            "logo": {
                                                "image": "https://immibox.com/app/favicon.png",
                                                "imageDark": "https://immibox.com/app/favicon.png",
                                                "url": "https://immibox.com"
                                            },
                                            "anonymous": {
                                                "request": false,
                                                "label": "Guest"
                                            },
                                            "chat": false,
                                            "comments": false,
                                            "compactHeader": false,
                                            "compactToolbar": true,
                                            "compatibleFeatures": false,
                                            "feedback": {
                                                "visible": false
                                            },
                                            "forcesave": true,
                                            "help": false,
                                            "hideNotes": true,
                                            "hideRightMenu": true,
                                            "hideRulers": true,
                                            layout: {
                                                toolbar: {
                                                    "collaboration": false,
                                                },
                                            },
                                            "macros": false,
                                            "macrosMode": "warn",
                                            "mentionShare": false,
                                            "plugins": false,
                                            "spellcheck": false,
                                            "toolbarHideFileName": true,
                                            "toolbarNoTabs": true,
                                            "uiTheme": "theme-light",
                                            "unit": "cm",
                                            "zoom": 100
                                        },
                                    }, events: {
                                        onReady: function () {

                                        },
                                        onDocumentStateChange: function (event) {
                                            var url = event.data;
                                            console.log(event)

                                            if (!event.data) {

                                                if (value.editedDocument) {

                                                }

                                            }
                                        }

                                    }
                                });
                            //this.docValue = encodeURIComponent(response.data.result.data);
                        }, 100)
                    }

                    if (this.docType == "pdf") {

                        // this.downloadFile(this.docValue, value.mimetype, value.name)

                        // return
                        var _vid = value._id;
                        if (value.parentId) {
                            _vid = value.parentId;
                        }
                        var viewmode = 1; // Enable edit
                        viewmode = 0; //Disabled Edit
                        if (value.viewmode) {
                            viewmode = 0;
                        }
                        this.docValue = "https://carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
                        console.log(this.docValue)
                        this.docPrivew = true;
                    }
                    if (this.docType == "image") {
                        this.docPrivew = true;
                    }



                });
            } else {



                this.downloads3file(value);
            }

        },
        getRevisionLogs() {
            let completedLogs = []
            if (this.checkProperty(this.evaluationDetails, 'evaluationActivityInfoLogs', 'length') > 0) {
                completedLogs = _.filter(this.checkProperty(this.evaluationDetails, 'evaluationActivityInfoLogs'), (item) => {
                    return (item.action == 'SIGN_REQUESTED' || item.action == 'SENT_FOR_REVISION')
                });
            }
            return completedLogs;
        },
        openChangePassword() {
            this.password = ''
            this.conformPassword = ''
            this.showLoader = false;
            this.$validator.reset();
            setTimeout(() => {
                this.showPasswordChangePopup = true;
                this.$bvModal.show('changePassword')
            })
        },
        closeChangePassword() {
            this.password = ''
            this.conformPassword = ''
            this.showLoader = false;
            this.$validator.reset();
            setTimeout(() => {
                this.showPasswordChangePopup = false;
                this.$bvModal.hide('changePassword')
            })

        },
        updatePassword() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.showLoader = true;
                    let path = "auth/change-password";

                    let selectedUser = this.getUserData
                    let postData = {
                        newPassword: this.password.trim(),
                        currentPassword: this.conformPassword.trim(),
                        //'userId': selectedUser['_id'],
                        "action": 'update-password'
                    };
                    this.$store.dispatch("commonAction", { data: postData, path: path, })
                        .then((response) => {
                            this.showToster({ message: response.message, isError: false })
                            this.closeChangePassword()

                        }).catch((error) => {
                            // alert(JSON.stringify(error.message))
                            this.showToster({ message: error.message, isError: true })
                            this.showLoader = false;
                            // this.showPasswordChangePopup = false
                        });

                }
            })
        },
        storeSelectedStatusAndApply() {
            this.$store.commit("setFilters", this.filterSelectedStatuses);
            // this.setFilters(this.filterSelectedStatuses)

            this.applyFilters()

        },
        onPageChange() {
            this.evaluationsList = []
            this.isListLoading = true
            this.updateLoading(true)
            this.getEvaluations()
        },
        getStatusName(item) {
            if (this.isActivityCompleted(item, 'SIGN_APPROVED')) {
                return 'Professor Approved'
            }
            if (!this.isActivityCompleted(item, 'SIGN_APPROVED') &&
                (this.isActivityCompleted(item, 'EVALUATION_REVISED_DOCUMENTS_UPDATED') || this.isActivityCompleted(item, 'EVALUATION_REQUEST_DELIVERED'))) {
                if (this.checkProperty(item, 'completedActivities').lastIndexOf('SIGN_REQUESTED') > this.checkProperty(item, 'completedActivities').lastIndexOf('SENT_FOR_REVISION')) {
                    return 'With Professor'
                } else {
                    return 'Professor Revision'
                }
            }
            return this.checkProperty(item, 'statusDetails', 'name')
        }

    },
    mounted() {

        const $ = JQuery;
        $(".mobile_menu").click(function () {
            $(this).toggleClass("open");
            $(".side_menu").toggleClass("open");
            $("body").toggleClass("hidden");
        });
        $(window).scroll(function () {
            var scroll = $(window).scrollTop();
            if (scroll >= 60) {
                $('header').addClass("fixed");
            } else {
                $('header').removeClass("fixed");
            }
        });


        this.getMasterDataList('evaluation_status')
        this.getMasterDataList('evaluation_priority')
        this.getCustomersList()

        if (this.checkProperty(this.$route.params, 'statusId')) {
            this.filterSelectedStatuses = [this.checkProperty(this.$route.params, 'statusId')]
        }
        if (this.$store.state.filterStatuses) {
            this.filterSelectedStatuses = this.$store.state.filterStatuses
        }

        this.getEvaluations()
    },
    computed: {


    },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    created() {
        this.$watch(
            () => this.$route.params,
            (toParams, previousParams) => {
                //  alert(JSON.stringify(this.$route.params))
            }
        )
    },
}
</script>







<!-- 
<script>
    // @ is an alias to /src
    import searchInput from '@/views/forms/searchInput.vue';
    import simpleSelect from '@/views/forms/simpleSelect.vue';
    import textArea from "@/views/forms/textarea.vue";
    export default {
      name: 'dashboard-view',
      components: {
        searchInput,
        simpleSelect,
        textArea
      },
      data: () => ({
          rows: 100,
          perPage: 1,
          currentPage: 1,
          statusList: ['Awaiting Confirmation','Confirmed','Delivered to Client','In Process','Payment Status','Requested'],
          priorityList: ['Rush', 'Standard'],
          customerList: ['Alex Mecheal Alex Mecheal', 'Alex', 'Mecheal'],
          beneficiaryList: ['Alex Mecheal Alex Mecheal', 'Alex', 'Mecheal'],
      }),
      methods:{
        gotoPage(path = "/") {
          this.$router.push(path);
        },
      },

    }
    </script> -->