<template>
  <div class="professor_requests">

    <header v-if="false" class="main_header header_professor">
      <div class="logo">
        <a href="#"><img src="@/assets/images/logo_carne.png"></a>
        <a @click="gotoPage()"><img src="@/assets/images/left-chevron.svg" alt=""></a>
        <h5>Evaluation Details</h5>
      </div>
      <div class="right">
        <div class="notification_sec" v-if="false">
          <span class="notification_icon new_notification"><img src="@/assets/images/notification.png"></span>
        </div>
        <div class="profile_sec">
          <b-dropdown size="lg" variant="link" right>
            <template #button-content>
              <div class="profile_icon">
                <img src="@/assets/images/profile-user.png">
              </div>
              <em class="profile_arrow">
                <img src="@/assets/images/down-chevron.svg">
              </em>
            </template>
            <b-dropdown-item @click="openProfilePopup(), $bvModal.show('profile_model')">Profile</b-dropdown-item>
            <b-dropdown-item @click="logout()">Logout</b-dropdown-item>
          </b-dropdown>
        </div>
      </div>
    </header>
    <div class="req_details_page">
      <div class="req_details_inner">
        <div class="rq_header rq-clients rq_header_v2">
          <!-- <div v-if="getUserRoleId == 9">
            <a @click="gotoPage()"><img src="@/assets/images/left-chevron.svg" alt=""></a>
          </div> -->
          <div class="rq-select">

            <div class="rq-number">
              <h5 v-if="checkProperty(evaluationDetails, 'requestId')">Evaluations / <a>{{
                checkProperty(evaluationDetails,
                  'requestId') }}</a></h5>
            </div>
            <div class="rq-review">
              <div v-if="checkProperty(evaluationDetails, 'dueDate')" class="due_date">
                <h4><span>Due by </span> {{
                  checkProperty(evaluationDetails, 'dueDate') | formatDate }}</h4>
                <figure class="due_date_icon"><img src="../assets/images/calender.png"></figure>
              </div>
              <div v-if="checkProperty(evaluationDetails, 'priorityDetails', 'name')" class="status rush"><img
                  src="@/assets/images/clock.png">{{ checkProperty(evaluationDetails, 'priorityDetails', 'name') }}
              </div>
              <button class="req-cancel-btn" @click="openCancelPopup" v-if="[3, 4, 7, 8].indexOf(getUserRoleId) > -1 && !isActivityCompleted(evaluationDetails, 'EVALUATION_REQUEST_CANCELLED')
                && !isActivityCompleted(evaluationDetails, 'EVALUATION_REQUEST_DELIVERED')">Cancel Request</button>
            </div>
          </div>
          <div class="rq_header_v2 send_email">
            <div v-if="checkProperty(evaluationDetails, 'docsConfig', 'length') > 0"
              class="evalution_type evalution_type_v2">
              
               <span v-for="(evaluationItem, indx) in checkProperty(evaluationDetails, 'docsConfig')" :key="indx"
                       >{{ evaluationItem.evaluationTypeName }}</span>
   
            </div>
          </div>
          <div class="users_info_main">
            <div class="exp_users_info" v-if="[9].indexOf(getUserRoleId) < 0">
              <div v-if="checkProperty(evaluationDetails,
                'customersDetails', 'companyName') || (checkProperty(evaluationDetails, 'customersDetails', 'name'))"
                class="users-flex">
                <p>Client <span class="client"><img src="@/assets/images/business-and-trade.png"> {{
                  checkProperty(evaluationDetails, 'customersDetails', 'companyName') ? checkProperty(evaluationDetails,
                    'customersDetails', 'companyName') : checkProperty(evaluationDetails, 'customersDetails', 'name')
                }}</span></p>
              </div>
              <div v-if="checkProperty(evaluationDetails, 'beneficiaryInformation', 'firstName')" class="users-flex">
                <p>Beneficiary <span><img src="@/assets/images/profile-user.png">
                    <div class="beneficiary_dropdown">
                      <b-dropdown size="lg" variant="link" toggle-class="text-decoration-none">
                        <template #button-content>
                          {{ checkProperty(evaluationDetails, 'beneficiaryInformation') | formatFullname }}
                        </template>
                        <b-dropdown-form>
                          <div class="ev_doc beneficiary">
                            <div class="beneficiary_detailes">
                              <div class="profile">
                                <figure><img src="@/assets/images/user.svg"></figure>
                              </div>
                              <ul class="beneficiary_detailes_v2">
                                <li>
                                  <h5>{{ checkProperty(evaluationDetails, 'beneficiaryInformation') | formatFullname }}
                                  </h5>
                                  <h6 v-if="checkProperty(evaluationDetails, 'beneficiaryInformation', 'jobTitle')"><img
                                      src="@/assets/images/briefcase.svg"> {{ checkProperty(evaluationDetails,
                                        'beneficiaryInformation', 'jobTitle') }}</h6>
                                </li>
                                <li v-if="checkProperty(evaluationDetails, 'beneficiaryInformation', 'firm')">
                                  <label>Beneficiary's Firm</label>
                                  <h4>{{ checkProperty(evaluationDetails, 'beneficiaryInformation', 'firm') }}</h4>
                                </li>
                                <li v-if="checkProperty(evaluationDetails, 'beneficiaryInformation', 'degree')">
                                  <label>Beneficiary's Degree</label>
                                  <h4>{{ checkProperty(evaluationDetails, 'beneficiaryInformation', 'degree') }}</h4>
                                </li>
                                <li
                                  v-if="checkProperty(evaluationDetails, 'beneficiaryInformation', 'usEquivalentDegree')">
                                  <label>Desired US equivalent degree</label>
                                  <h4>{{ checkProperty(evaluationDetails, 'beneficiaryInformation', 'usEquivalentDegree')
                                  }}
                                  </h4>
                                </li>
                                <li v-if="checkProperty(evaluationDetails, 'beneficiaryInformation', 'gender')">
                                  <label>Beneficiary's Gender</label>
                                  <h4>{{ checkProperty(evaluationDetails, 'beneficiaryInformation', 'gender') }}</h4>
                                </li>
                                <li v-if="checkProperty(evaluationDetails, 'beneficiaryInformation', 'socCode')">
                                  <label>Occupation SOC code (Only needed for Expert Opinion)</label>
                                  <h4>{{ checkProperty(evaluationDetails, 'beneficiaryInformation', 'socCode') }}</h4>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </b-dropdown-form>
                      </b-dropdown>
                    </div>
                    <button class="edit_btn ben_edit_btn" v-if="[3, 4, 7, 15, 8].indexOf(getUserRoleId) > -1 && !isEvaluationCanceled &&
                      checkProperty(evaluationDetails, 'statusDetails', 'id') < 16"
                      @click="editBeneficiaryInfo">EDIT</button>
                  </span>
                </p>
              </div>
              <div class="users-flex"
                v-if="[9, 15].indexOf(getUserRoleId) < 0 && checkProperty(evaluationDetails, 'assignedToProfessorDetails', 'name')">
                <p>Professor <span><img src="@/assets/images/subtraction.svg"> {{ checkProperty(evaluationDetails,
                  'assignedToProfessorDetails', 'name') }} <button class="edit_btn"
                      v-if="[3, 4, 7, 8].indexOf(getUserRoleId) > -1 && !isActivityCompleted(evaluationDetails, 'SIGN_APPROVED') && !isEvaluationCanceled"
                      @click="changeProfessor">EDIT</button></span> </p>
              </div>
              <!-- <div class="users-flex" v-if="checkProperty(evaluationDetails, 'assignedToEvaluatorDetails', 'name')">
                <p>Evaluator <span> {{ checkProperty(evaluationDetails, 'assignedToEvaluatorDetails', 'name') }}</span>
                </p>
              </div>

              <div class="users-flex" v-if="checkProperty(evaluationDetails, 'assignedToReviewerDetails', 'name')">
                <p>Reviewer <span>{{ checkProperty(evaluationDetails, 'assignedToReviewerDetails', 'name') }}</span></p>
              </div> -->

            </div>
            <figure class="email_icon" title="Emails" v-if="[3, 4, 7, 8].indexOf(getUserRoleId) > -1"
              @click="openEmailsPopup">
              <img src="@/assets/images/email_black.png" alt="email">
            </figure>
            <div class="action_btns" v-if="[3, 4, 7, 8].indexOf(getUserRoleId) > -1">
              <b-dropdown id="send_email_dropdown" right text="Send Email" class="send_email_btn">
                <b-dropdown-item @click="openSendEmailPopup('Customer')">Send to Client</b-dropdown-item>
                <b-dropdown-item v-if="checkProperty(evaluationDetails, 'assignedToProfessorDetails', '_id')"
                  @click="openSendEmailPopup('Professor')">Send to Professor</b-dropdown-item>
              </b-dropdown>
            </div>
          </div>
        </div>
        <div class="info_msg" v-if="false">
          <p>We place a high priority on data protection. Therefore, evaluation requests that aren't complete or confirmed
            after 90 days will be deleted. The reports delivered will be available for you 90 days after delivery</p>

        </div>
      <div class="info_msg alert alert-warning"  v-if="canShowNotes && evaluationDetails && evaluationDetails.promocode != ''"> 
    Promo <strong>{{evaluationDetails.promocode}}</strong> applied
</div>

        <div class="notes_section" v-if="canShowNotes">
          <button class="addnotes_btn" @click="openAddNotesPopup(false)" v-if="checkProperty(evaluationDetails, 'carnegieNote', 'length') <= 0 && !isEvaluationCanceled && [3, 4, 6, 8].indexOf(getUserRoleId) > -1
            && !isEvaluationDelivered">
            Carnegie Notes</button>
          <div class="notes_details" v-if="checkProperty(evaluationDetails, 'carnegieNote', 'length') > 0">
            <p v-html="checkProperty(evaluationDetails, 'carnegieNote')" id="popover-notes"></p>
            <b-popover custom-class="notes_wrap" target="popover-notes" triggers="hover" placement="top"
              fallback-placement="flip">
              <template>
                <div v-html="checkProperty(evaluationDetails, 'carnegieNote')"></div>
              </template>
            </b-popover>
          </div>
          <div class="notes_actions" v-if="checkProperty(evaluationDetails, 'carnegieNote', 'length') > 0 && !isEvaluationCanceled && [3, 4, 6, 8].indexOf(getUserRoleId) > -1
            && !isEvaluationDelivered">
            <!-- <button class="view_btn">View</button> -->
            <button class="edit_btn" @click="openAddNotesPopup(true)">Carnegie Notes</button>
          </div>
        </div>
        <section class="timeline tq_timeline" show-day-and-month="true">
          <div class="wrapper-timeline" v-if="[9, 15].indexOf(getUserRoleId) < 0">
            <div v-if="checkEvalDeliveryPremissions" class="wrapper-item">
              <actionDeliverytoClient @download_or_view="download_or_view" :evaluation="evaluationDetails"
                @updateDetails="updateEvaluationDetails()">
              </actionDeliverytoClient>
            </div>
            <div v-if="checkEvalFinalReviewPremissions" class="wrapper-item">
              <actionRevisionByOnsite :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                @download_or_view="download_or_view">
              </actionRevisionByOnsite>
            </div>

            <div v-if="checkEvalRevisionPremissions" class="wrapper-item">
              <actionRevisedDocuments :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                @download_or_view="download_or_view">
              </actionRevisedDocuments>
            </div>

            <div v-if="([3, 4, 7, 8].indexOf(getUserRoleId) > -1 && [8, 9, 10, 15, 16].indexOf(checkProperty(evaluationDetails, 'statusDetails', 'id')) > -1
              && !isActivityCompleted(evaluationDetails, 'SIGN_APPROVED')
              && (!isActivityCompleted(evaluationDetails, 'SIGN_REQUESTED') || (isActivityCompleted(evaluationDetails, 'SENT_FOR_REVISION') && checkProperty(evaluationDetails, 'completedActivities').lastIndexOf('SIGN_REQUESTED') > checkProperty(evaluationDetails, 'completedActivities').lastIndexOf('SENT_FOR_REVISION')))
              //  ((isLastCompletedActivity(evaluationDetails, 'EVALUATION_TEMPLATE_ASSIGNED')&&isActivityCompleted(evaluationDetails, 'EVALUATION_DOCUMENTS_SAVED') )|| isLastCompletedActivity(evaluationDetails, 'EVALUATION_DOCUMENTS_SAVED')) 
              && !isEvaluationCanceled)" class="wrapper-item">
              <actionOnsiteReview :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                @download_or_view="download_or_view">
              </actionOnsiteReview>
            </div>
            <!-- <div
            v-if="([3, 4, 6].indexOf(getUserRoleId) < 0 && isActivityCompleted(evaluationDetails, 'EVALUATION_REVIEWER_ASSIGNED')) || ([3, 4, 6].indexOf(getUserRoleId) > -1 && isActivityCompleted(evaluationDetails, 'EVALUATION_DOCUMENTS_UPDATED'))"
            class="wrapper-item">
            <actionAssignReviewer :evaluation="evaluationDetails" :roleIds="[7]"
              @updateDetails="updateEvaluationDetails()">
            </actionAssignReviewer>
          </div> -->

            <div v-if="(([3, 4, 6, 7, 8].indexOf(getUserRoleId) > -1 || isAssignedConsultant) && [9, 8].indexOf(checkProperty(evaluationDetails, 'statusDetails', 'id')) > -1
              //  && (checkProperty(evaluationDetails, 'assignedToEvaluatorDetails', '_id') || checkProperty(evaluationDetails, 'assignedToConsultantDetails', '_id'))
              && !isEvaluationCanceled)" class="wrapper-item">
              <actionUploadDocuments :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                @download_or_view="download_or_view">
              </actionUploadDocuments>
            </div>
            <!-- v-if="([3, 4, 7].indexOf(getUserRoleId) > -1 && (isLastCompletedActivity(evaluationDetails, 'REVIEW_CONFIRMED') || isLastCompletedActivity(evaluationDetails, 'EVALUATION_PROFESSER_ASSIGNED') || isLastCompletedActivity(evaluationDetails, 'EVALUATION_TEMPLATE_ASSIGNED') || isLastCompletedActivity(evaluationDetails, 'EVALUATION_DOCS_GENERATED')) && !isEvaluationCanceled)" -->



            <div v-if="checkEvaluationTemplatePermission" class="wrapper-item">
              <actionEvaluationTemplate @download_or_view="download_or_view" :evaluation="evaluationDetails"
                @updateDetails="updateEvaluationDetails()">
              </actionEvaluationTemplate>
            </div>

            <div v-if="([3, 4, 7, 8].indexOf(getUserRoleId) > -1 && [3, 5, 8].indexOf(checkProperty(evaluationDetails, 'statusDetails', 'id')) > -1
              && ((!checkProperty(evaluationDetails, 'assignedToEvaluatorDetails', '_id') && checkProperty(evaluationDetails, 'assignedToEvaluator', 'length') < 1)
                && !checkProperty(evaluationDetails, 'assignedToConsultantDetails', '_id')) && !isEvaluationCanceled)"
              class="wrapper-item">
              <actionAssignEvaluator @download_or_view="download_or_view" :evaluation="evaluationDetails"
                :roleIds="[6, 5]" @updateDetails="updateEvaluationDetails()">
              </actionAssignEvaluator>
            </div>

            <div
              v-if="!isActivityCompleted(evaluationDetails, 'INVOICE_ISSUED') && ([8].indexOf(getUserRoleId) > -1 && isActivityCompleted(evaluationDetails, 'REVIEW_CONFIRMED') && !isEvaluationCanceled)"
              class="wrapper-item">
              <actionIssueInvoice :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                @showInvoice="getInvoiceDetails()" @download_or_view="download_or_view">
              </actionIssueInvoice>
            </div>

            <div
              v-if="evaluationDetails != null && showActionReview && [3, 4, 7, 8].indexOf(getUserRoleId) > -1 && !isEvaluationCanceled && (showReviewSection || isLastCompletedActivity(evaluationDetails, 'EVALUATION_REVIEWED'))">
              <actionReview :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                :isCompletedActivity="false" @download_or_view="download_or_view"></actionReview>
            </div>
            <div class="wrapper-item"
              v-if="[3, 4, 7, 8].indexOf(getUserRoleId) > -1 && checkProperty(evaluationDetails, 'paymentStatusDetails', 'id') !== 2 && (showReviewSection || (isActivityCompleted(evaluationDetails, 'EVALUATION_REVIEWED') && !isActivityCompleted(evaluationDetails, 'REVIEW_CONFIRMED'))) && !isActivityCompleted(evaluationDetails, 'PAYMENT_REQUESTED') && !isEvaluationCanceled">
              <actionSendPaymentLink :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                :isCompletedActivity="false">
              </actionSendPaymentLink>
            </div>
            <div class="wrapper-item"
              v-if="[3, 4, 7, 8].indexOf(getUserRoleId) > -1 && (showReviewSection || isLastCompletedActivity(evaluationDetails, 'EVALUATION_REVIEWED')) && !isEvaluationCanceled">
              <actionReviewConform :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                :isCompletedActivity="false">
              </actionReviewConform>
            </div>

            <div v-if="false">
              <actionMapwithClient :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                :hideReviewButton="showReviewSection" @showReviewAction="showReviewSection = true"></actionMapwithClient>
            </div>




            <div v-for="(item, index) in sortedEvaluationActivityInfoLogs" :key="index">

              <div v-if="item.action == 'EVALUATION_REQUEST_CANCELLED'">
                <actionEvaluationCanceled :evaluation="evaluationDetails" :isCompletedActivity="true" :activityLog="item">
                </actionEvaluationCanceled>
              </div>
              <div v-if="item.action == 'EVALUATION_EMAIL'">
                <actionEvaluationEmail @download_or_view="download_or_view" :evaluation="evaluationDetails"
                  @updateDetails="updateEvaluationDetails()" :isCompletedActivity="true" :activityLog="item">
                </actionEvaluationEmail>
              </div>
              <div v-if="item.action == 'EMAIL_SEND'">
                <actionSentEmail @download_or_view="download_or_view" :evaluation="evaluationDetails"
                  @updateDetails="updateEvaluationDetails()" :isCompletedActivity="true" :activityLog="item">
                </actionSentEmail>
              </div>
              <div v-if="item.action == 'EVALUATION_REQUEST_DELIVERED'">
                <actionDeliverytoClient @download_or_view="download_or_view" :evaluation="evaluationDetails"
                  @updateDetails="updateEvaluationDetails()" :isCompletedActivity="true" :activityLog="item">
                </actionDeliverytoClient>
              </div>
              <div v-if="item.action == 'EVALUATION_REVISED_DOCUMENTS_UPDATED'">
                <actionRevisionByOnsite :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  @download_or_view="download_or_view" :isCompletedActivity="true" :activityLog="item">
                </actionRevisionByOnsite>
              </div>

              <div v-if="item.action == 'SIGN_APPROVED'" class="wrapper-item">
                <div class="section-year">
                  <p> {{ checkProperty(item, 'updatedOn') | formatTime }}</p>
                  <p> {{ checkProperty(item, 'updatedOn') | formatDate }}</p>
                </div>
                <section class="timeline-item">
                  <div class="item">
                    <span class="status_dot status_conform"></span>
                    <div class="status-name conform_bg">Professor Approved</div>
                    <div class="submit_detailes">
                      <h4 v-if="checkProperty(item, 'updatedByName')">
                        Approved by <b>{{ checkProperty(item, 'updatedByName') }}</b></h4>
                      <h4>Professor Approved</h4>
                    </div>
                  </div>
                </section>
              </div>

              <div v-if="item.action == 'SENT_FOR_REVISION'">
                <actionRevisedDocuments :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  @download_or_view="download_or_view" :isCompletedActivity="true" :activityLog="item">
                </actionRevisedDocuments>
              </div>
              <div v-if="item.action == 'SIGN_REQUESTED'">
                <actionOnsiteReview :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  @download_or_view="download_or_view" :isCompletedActivity="true" :activityLog="item">
                </actionOnsiteReview>
              </div>

              <div
                v-if="(item.action == 'EVALUATION_DOCUMENTS_SAVED' || item.action == 'EVALUATION_DOCUMENTS_CONFIRMED')">
                <actionUploadDocuments :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  @download_or_view="download_or_view" :isCompletedActivity="true" :activityLog="item">
                </actionUploadDocuments>
              </div>
              <div
                v-if="item.action == 'EVALUATION_EVALUATOR_ASSIGNED' || item.action == 'EVALUATION_CONSULTANT_ASSIGNED'">
                <actionAssignEvaluator @download_or_view="download_or_view" :evaluation="evaluationDetails"
                  :roleIds="[6, 5]" @updateDetails="updateEvaluationDetails()" :isCompletedActivity="true"
                  :reviewDetails="item">
                </actionAssignEvaluator>
              </div>
              <div v-if="item.action == 'EVALUATION_TEMPLATE_ASSIGNED'">
                <actionEvaluationTemplate @download_or_view="download_or_view" :evaluation="evaluationDetails"
                  @updateDetails="updateEvaluationDetails()" :isCompletedActivity="true" :activityLog="item">
                </actionEvaluationTemplate>
              </div>
              <div v-if="item.action == 'EVALUATION_DUEDATE_UPDATED'">
                <actionSetDueDate :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  :isCompletedActivity="true" :reviewDetails="item">
                </actionSetDueDate>
              </div>
              <div v-if="item.action == 'INVOICE_ISSUED'">
                <actionIssueInvoice :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  @showInvoice="getInvoiceDetails()" :isCompletedActivity="true" :activityLog="item"
                  @download_or_view="download_or_view">
                </actionIssueInvoice>
              </div>
              <div v-if="item.action == 'INVOICE_SAVED'">
                <actionSaveInvoice :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  @showInvoice="getInvoiceDetails()" :isCompletedActivity="true" :activityLog="item">
                </actionSaveInvoice>
              </div>
              <div v-if="item.action == 'EVALUATION_PROFESSER_ASSIGNED'">
                <actionAssign :evaluation="evaluationDetails" :roleIds="[9]" @updateDetails="updateEvaluationDetails()"
                  :isCompletedActivity="true" :reviewDetails="item">
                </actionAssign>
              </div>
              <!-- <div v-if="item.action == 'PAYMENT_UPDATED'">
                <actionApprovePayment :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  :isCompletedActivity="true" :activityLog="item">
                </actionApprovePayment>
              </div>
              <div v-if="item.action == 'PAYMENT_REQUESTED'">
                <actionSendPaymentLink :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  :isCompletedActivity="true" :activityLog="item">
                </actionSendPaymentLink>
              </div>
              <div v-if="item.action == 'REVIEW_CONFIRMED'">
                <div class="wrapper-item"
                  v-if="[3, 4, 7, 8].indexOf(getUserRoleId) > -1 && !isActivityCompleted(evaluationDetails, 'PAYMENT_REQUESTED') && !isEvaluationCanceled">
                  <actionSendPaymentLink :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                    :isCompletedActivity="false">
                  </actionSendPaymentLink>
                </div>
                <actionReviewConform :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  :isCompletedActivity="true" :reviewDetails="item">
                </actionReviewConform>

              </div>
              <div v-if="item.action == 'EVALUATION_REVIEWED'">
                <actionReview :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  :isCompletedActivity="true" :reviewDetails="item" @download_or_view="download_or_view"></actionReview>
              </div>

              <div v-if="item.action == 'EVALUATION_REQUESTED'">
                <actionMapwithClient :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  :hideReviewButton="showReviewSection" @showReviewAction="showReviewSection = true">
                </actionMapwithClient>
              </div> -->

            </div>
            <div class="wrapper-item"
              v-if="[8].indexOf(getUserRoleId) > -1 && !isActivityCompleted(evaluationDetails, 'PAYMENT_UPDATED') && (isActivityCompleted(evaluationDetails, 'PAYMENT_REQUESTED') || isActivityCompleted(evaluationDetails, 'INVOICE_ISSUED')) && !isEvaluationCanceled">
              <actionApprovePayment :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()">
              </actionApprovePayment>
            </div>


            <div v-for="(item, index) in evaluationDetails.evaluationActivityInfoLogs" :key="'key-' + index">
              <div v-if="item.action == 'PAYMENT_UPDATED'">
                <actionApprovePayment :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  :isCompletedActivity="true" :activityLog="item">
                </actionApprovePayment>
              </div>
              <div v-if="item.action == 'PAYMENT_REQUESTED'">
                <actionSendPaymentLink :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  :isCompletedActivity="true" :activityLog="item">
                </actionSendPaymentLink>
              </div>
              <div v-if="item.action == 'REVIEW_CONFIRMED'">
                <div class="wrapper-item"
                  v-if="[3, 4, 7, 8].indexOf(getUserRoleId) > -1 && checkProperty(evaluationDetails, 'paymentStatusDetails', 'id') !== 2 && !isActivityCompleted(evaluationDetails, 'PAYMENT_REQUESTED') && !isEvaluationCanceled">
                  <actionSendPaymentLink :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                    :isCompletedActivity="false">
                  </actionSendPaymentLink>
                </div>
                <actionReviewConform :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  :isCompletedActivity="true" :reviewDetails="item">
                </actionReviewConform>

              </div>
              <div v-if="item.action == 'EVALUATION_REVIEWED'">
                <actionReview :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  :isCompletedActivity="true" :reviewDetails="item" @download_or_view="download_or_view"></actionReview>
              </div>

              <div v-if="item.action == 'EVALUATION_REQUESTED'">
                <actionMapwithClient :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  :hideReviewButton="showReviewSection" @showReviewAction="showReviewSection = true">
                </actionMapwithClient>
              </div>

            </div>

          </div>

          <div v-if="[9].indexOf(getUserRoleId) > -1">
            <section class="timeline tq_timeline" show-day-and-month="true">
              <div class="wrapper-timeline">
                <div v-if="isActivityCompleted(evaluationDetails, 'SIGN_APPROVED')" class="wrapper-item">
                  <div class="section-year">
                    <p> {{ checkProperty(getActivityLog(evaluationDetails, 'SIGN_APPROVED'),
                      'updatedOn') | formatTime }}</p>
                    <p> {{ checkProperty(getActivityLog(evaluationDetails, 'SIGN_APPROVED'),
                      'updatedOn') | formatDate }}</p>
                  </div>
                  <section class="timeline-item">
                    <div class="item">
                      <span class="status_dot status_conform"></span>
                      <div class="status-name conform_bg">Documents are Approved</div>
                      <div class="submit_detailes">
                        <h4 v-if="checkProperty(getActivityLog(evaluationDetails, 'SIGN_APPROVED'), 'updatedByName')">
                          Approved by <b>{{ checkProperty(getActivityLog(evaluationDetails, 'SIGN_APPROVED'),
                            'updatedByName') }}</b></h4>
                        <h4>Documents are Approved</h4>
                      </div>
                    </div>
                  </section>
                </div>

                <div v-if="isActivityCompleted(evaluationDetails, 'SIGN_REQUESTED')" class="wrapper-item"
                  v-for="( activity, index) in getRevisionLogs()">

                  <!-- <div v-if="checkProperty(activity, 'action') == 'SIGN_REQUESTED'" class="wrapper-item"> -->

                  <actionApproveDocuments
                    v-if="!(index == 0 && ((checkProperty(evaluationDetails, 'isRequested') && evaluationDetails.isRequested)))"
                    :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()" :activityLog="activity"
                    :isLastDoneActivity="checkProperty(activity, '_id') == checkProperty(evaluationDetails, 'latestEvaluationLog', '_id') ? true : false"
                    @download_or_view="download_or_view" :isCompletedActivity="true">
                  </actionApproveDocuments>

                  <actionApproveDocuments
                    v-if="index == 0 && ((checkProperty(evaluationDetails, 'isRequested') && evaluationDetails.isRequested))"
                    :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()" :activityLog="activity"
                    :isLastDoneActivity="checkProperty(activity, '_id') == checkProperty(evaluationDetails, 'latestEvaluationLog', '_id') ? true : false"
                    @download_or_view="download_or_view"
                    :isCompletedActivity="isActivityCompleted(evaluationDetails, 'SIGN_APPROVED') ? true : false">
                  </actionApproveDocuments>

                </div>
              </div>
            </section>

          </div>
          <div v-if="[15].indexOf(getUserRoleId) > -1">
            <div v-for="(item, index) in evaluationDetails.evaluationActivityInfoLogs" :key="'key-' + index">
              <div v-if="item.action == 'EVALUATION_REQUEST_DELIVERED'">
                <actionDeliverytoClient @download_or_view="download_or_view" :evaluation="evaluationDetails"
                  @updateDetails="updateEvaluationDetails()" :isCompletedActivity="true" :activityLog="item">
                </actionDeliverytoClient>
              </div>
              <div v-if="item.action == 'EVALUATION_REQUESTED'">
                <actionMapwithClient :evaluation="evaluationDetails" @updateDetails="updateEvaluationDetails()"
                  :hideReviewButton="showReviewSection" @showReviewAction="showReviewSection = true">
                </actionMapwithClient>
              </div>

            </div>
          </div>
        </section>
      </div>
      <div class="doc_list">
        <div class="action_tab">
          <b-tabs>
            <b-tab v-for="(item, index) in  getDocumentsArray() " @click="checkCurrentTabAndReload(item)">
              <template #title v-if="item.id==1">{{ item.name }} {{ getClientDocumentsCount!=0?(" ("+getClientDocumentsCount+") "):'' }} </template>
              <template #title v-else>{{ item.name }} </template>
              
              <div>
                <div v-if="item.id == 1">
                  <VuePerfectScrollbar>
                    <div class="side_doc client_docs d">
                      <div class="doc_files">
                        <div class="badge"
                          v-if="checkProperty(evaluationDetails, 'createdOn') || checkProperty(evaluationDetails, 'updatedOn')">
                          <span>Last Updated :</span>
                          {{ checkProperty(evaluationDetails, 'updatedOn') ? checkProperty(evaluationDetails,
                            'updatedOn') : checkProperty(evaluationDetails, 'createdOn') | formatDateTime }}
                        </div>
                        <div class="doc_files" v-if="isClientDocsExists">
                          <ul>
                            <li v-for="(evaluationItem, indx) in checkProperty(evaluationDetails, 'docsConfig')"
                              v-if="checkProperty(evaluationItem, 'subTypes', 'length') > 0">
                              <h6><b> {{ evaluationItem.evaluationTypeName }} </b></h6>
                              <div class="list-elements_wrap"
                                v-for="(subType, subIndx) in checkProperty(evaluationItem, 'subTypes')">
                                <p> {{ subType.subTypeName }} </p>
                                <DocumentsPreview showconvert="true" :type="'documents'" :documentsList="subType.documents"
                                  :includeDownloadText="false" @download_or_view="download_or_view" />
                              </div>
                            </li>
                            <li v-if="checkProperty(evaluationDetails, 'supportDocuments', 'length') > 0">
                              <!-- <p> Other Documents </p> -->
                              <h6><b> Other Documents </b></h6>
                              <DocumentsPreview :type="'documents'"
                                :documentsList="checkProperty(evaluationDetails, 'supportDocuments')"
                                :includeDownloadText="false" @download_or_view="download_or_view" />
                            </li>
                          </ul>
                        </div>
                        <div class="doc_files" v-else>
                          <ul>
                            <li class="nodocfound">
                              <p> No documents found! </p>
                            </li>
                          </ul>
                        </div>
                      </div>

                    </div>
                  </VuePerfectScrollbar>
                </div>
                <div v-if="item.id == 2">
                  <VuePerfectScrollbar>
                    <div class="side_doc client_docs">

                      <div class="doc_files">
                        <div class="badge"
                          v-if="checkProperty(evaluationDetails, 'createdOn') || checkProperty(evaluationDetails, 'updatedOn')">
                          <span>Last Updated :</span>
                          {{ checkProperty(evaluationDetails, 'updatedOn') ? checkProperty(evaluationDetails,
                            'updatedOn') : checkProperty(evaluationDetails, 'createdOn') | formatDateTime }}
                        </div>
                        <ul>
                          <li v-if="checkProperty(evaluationDetails, 'statusDetails', 'id') > 7 && checkProperty(evaluationDetails, 'statusDetails', 'id') < 15
                            && checkProperty(getCurrentDraftDocuments(), 'length') > 0">
                            <p> {{ getDocumentsTitle() }} </p>
                            <DocumentsPreview :type="'documents'" :documentsList="getCurrentDraftDocuments()"
                              :includeDownloadText="false" @download_or_view="download_or_view" />
                          </li>

                          <li v-if="[9].indexOf(getUserRoleId) < 0 && checkProperty(evaluationDetails, 'revisedDocuments', 'clientDocuments')
                            && checkProperty(evaluationDetails.revisedDocuments, 'clientDocuments', 'length') > 0">
                            <p> Client Copies </p>
                            <DocumentsPreview showconvert="true" :type="'documents'"
                              :documentsList="checkProperty(evaluationDetails, 'revisedDocuments', 'clientDocuments')"
                              :includeDownloadText="false" @download_or_view="download_or_view" />
                          </li>
                          <li v-if="[9].indexOf(getUserRoleId) < 0 && checkProperty(evaluationDetails, 'revisedDocuments', 'professorDocuments')
                            && checkProperty(evaluationDetails.revisedDocuments, 'professorDocuments', 'length') > 0">
                            <p> Professor Copies </p>
                            <DocumentsPreview :type="'documents'"
                              :documentsList="checkProperty(evaluationDetails, 'revisedDocuments', 'professorDocuments')"
                              :includeDownloadText="false" @download_or_view="download_or_view" />
                          </li>
                          <li v-if="[9].indexOf(getUserRoleId) > -1 && checkProperty(evaluationDetails, 'statusDetails', 'id') == 16
                            && checkProperty(evaluationDetails, 'revisedDocuments', 'professorDocuments')
                            && checkProperty(evaluationDetails.revisedDocuments, 'professorDocuments', 'length') > 0">
                            <p> Professor Copies </p>
                            <DocumentsPreview :type="'documents'"
                              :documentsList="checkProperty(evaluationDetails, 'revisedDocuments', 'professorDocuments')"
                              :includeDownloadText="false" @download_or_view="download_or_view" />
                          </li>

                          <li
                            v-if="(checkProperty(getCurrentDraftDocuments(), 'length') == 0 && checkProperty(evaluationDetails, 'revisedDocuments') && (checkProperty(evaluationDetails.revisedDocuments, 'clientDocuments', 'length') == 0 && checkProperty(evaluationDetails.revisedDocuments, 'professorDocuments', 'length') == 0))"
                            class="nodocfound">
                            <p> No documents found! </p>
                          </li>
                        </ul>
                      </div>


                    </div>
                  </VuePerfectScrollbar>

                </div>

              </div>
              <div class="tab-footer" v-if="[9].indexOf(getUserRoleId) < 0"
                v-bind:class="{ 'tab-footer_v2': [15].indexOf(getUserRoleId) < 0 && isClientDocsExists }">
                <!-- <div class="tab-footer tab-footer_v2" v-if="[9].indexOf(getUserRoleId) < 0"> -->
                <div class="upload-file">
                  <input class="upload_input" ref="file" type="file">
                  <div class="upload_btn uploaded" @click="openSupportedDocsPopup">
                    <svg viewBox="0 0 24 24" width="15" height="15" stroke="currentColor" stroke-width="2" fill="none"
                      stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">
                      <polyline points="16 16 12 12 8 16"></polyline>
                      <line x1="12" y1="12" x2="12" y2="21"></line>
                      <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"></path>
                      <polyline points="16 16 12 12 8 16"></polyline>
                    </svg>
                    UPLOAD
                  </div>
                </div>
                <button class="primary_btn download_btn" v-if="[15].indexOf(getUserRoleId) < 0 && isClientDocsExists"
                  @click="downloadAllFiles">
                  <svg width="13" height="13" viewBox="0 0 13 13">
                    <path class="a"
                      d="M84.738,10.207l4.18-4.175L87.525,4.639,85.667,6.5V0H83.809V6.5L81.951,4.639,80.558,6.031Z"
                      transform="translate(-78.238)" />
                    <path class="a" d="M0,386.667H13v1.856H0Z" transform="translate(0 -375.523)" />
                  </svg>
                  DOWNLOAD ALL
                </button>
              </div>
            </b-tab>



          </b-tabs>
        </div>
      </div>



      <b-modal id="professors_model" v-model="showEditProfessor" dialog-class="professors" centered no-close-on-backdrop>
        <template #modal-header>
          <h6 class="modal-title">Change Professor</h6>
          <a class="close" @click="showEditProfessor = false"></a>
        </template>
        <template>
          <div class="rq_header d-block">
            <!-- <div class="user_info_sec">
            <div class="user-flex">
              <div class="ben-info">
                <searchInput :place-holder="'Search…'" />
              </div>
              <button class="add_btn" @click="gotoPage('/create-evaluation')"><span></span><em>Add New</em></button>
            </div>
          </div> -->

            <div class="select_user mb-2">

              <customSelect :multiple="false" :optionslist="professorList" :display="true"
                :place-holder="'Assign Professor'" :searchable="false" :required="true" :close-on-select="true"
                :clear-on-select="false" class="mb-0 ass-eval" v-model="selectedProfessor" :fieldName="'user'"
                :cid="'user'" :vvas="'Professor'" />

            </div>
          </div>
        </template>
        <template #modal-footer>
          <button class="form-cancel" @click="showEditProfessor = false">Cancel</button>
          <button class="primary_btn sm" @click="updateProfessor"
            :disabled="checkProperty(evaluationDetails, 'assignedToProfessorDetails', '_id') == checkProperty(selectedProfessor, '_id')">Submit</button>
        </template>
      </b-modal>
      <!-- Add Notes Modal -->
      <b-modal v-model="showAddNotes" id="add_notes_modal" dialog-class="create_template" centered no-close-on-backdrop>
        <template #modal-header>
          <h6 class="modal-title">{{ "Carnegie Notes" }}</h6>
          <a class="close" @click="closeAddNotesPopup"></a>
        </template>
        <template>
          <form class="user_form create_temp" :data-vv-scope="'evalNotesForm'">
            <div class="row">
              <div class="col-md-12">
                <textArea :label="''" :wrapclass="'h80 mb-0'" placeHolder="Content" v-model="selectedNotes"
                  :fieldName="'noteComments'" :cid="'noteComments'" :required="true" :vvas="'Notes'"
                  :formscope="'evalNotesForm'"></textArea>
              </div>
            </div>
          </form>
        </template>
        <template #modal-footer>

          <button class="form-cancel" @click="closeAddNotesPopup">Cancel</button>
          <button class="primary_btn md" @click="submitNotes">{{ "Save" }}</button>
        </template>
      </b-modal>


      <!-- Send Email Modal -->
      <b-modal v-model="showSendEmail" id="send_email_modal" dialog-class="create_template send_email_popup" centered
        no-close-on-backdrop>
        <template #modal-header>
          <h6 class="modal-title">Send Email</h6>
          <a class="close" @click="closeSendEmaiPopup"></a>
        </template>
        <template>
          <form class="user_form create_temp" :data-vv-scope="'sendEmailForm'">
            <div class="row">
              <div class="col-md-12">
                <simpleInput :fieldName="'sendEmailSubject'" :cid="'sendEmailSubject'" :label="'Subject'"
                  :wrapclass="'mb20'" :placeHolder="'Subject'" :vvas="'Subject'" :display="true" :required="true"
                  v-model="sendEmailSubject" :formscope="'sendEmailForm'" />
              </div>
              <!-- <p class="mb-2">Content <a class="link ms-2" @click="openTemplatePopup">Select
                  Template</a>
              </p> -->

              <div class="col-md-12">
                <p class="form_group d-flex mb-0"><span class="form_label">Content </span><a class="link ms-2 mart2"
                    @click="openTemplatePopup">Select
                    Template</a>
                </p>
                <textArea :label="''" :wrapclass="'h80 mb20'" placeHolder="Content" v-model="sendEmailContent"
                  :fieldName="'sendEmailContent'" :cid="'sendEmailContent'" :formscope="'sendEmailForm'" :required="true"
                  ref="sendEmailParentRef"></textArea>
              </div>
              <div class="col-md-12 position-relative">
                <fileUploadDrag :label="'Documents'" :wrapclass="'mb-0'" :multiple="true" :required="false"
                  :tplkey="'templateDocs'" v-model="sendEmailDocs" :tplsection="'templateDocs'" vvas="Documents"
                  :fieldName="'templateDocs'" :cid="'templateDocs'" @uploadingFile="checkFileUploading($event)" />
                <!-- <input type="hidden" class="form-control" v-validate="'required'" v-model="sendEmailDocs"
                  data-vv-as="Template Document" :name="'templateDocument'" :formscope="'sendEmailForm'" />
                <span v-show="errors.has('templateDocument')" class="form-error">{{
                  errors.first('templateDocument')
                }}</span> -->
              </div>
            </div>
          </form>
        </template>
        <template #modal-footer>
          <button v-if="false" class="primary_btn sm" @click="openPreviewPopup"
            :disabled="sendEmailFilesUploading">Preview</button>
          <div class="right_actions ms-auto">
            <button class="form-cancel" @click="closeSendEmaiPopup">Cancel</button>
            <button class="primary_btn sm" @click="openPreviewPopup" :disabled="sendEmailFilesUploading">Preview &
              Send</button>
          </div>
        </template>
      </b-modal>

      <!-- Preview Email Modal -->
      <b-modal id="preview_email_modal" dialog-class="create_template preview_email_modal" centered no-close-on-backdrop>
        <template #modal-header>
          <h6 class="modal-title">Preview Email</h6>
          <a class="close" @click="$bvModal.hide('preview_email_modal')"></a>
        </template>
        <template>
          <form class="user_form create_temp bg-white" :data-vv-scope="'sendEmailForm'">
            <div class="subject"><strong>Subject:</strong>{{ sendEmailSubject }} </div>
            <div class="email_preview_wrapper">
              <div class="top_head">
                <div class="bg_white"></div>
              </div>
              <div class="main_cnt">
                <div class="main_inr">
                  <p>Dear <strong>{{ sendEmilType
                    == "Professors" ? checkProperty(evaluationDetails, 'assignedToProfessorDetails', 'name') :
                    getCustomerName()
                  }}</strong></p>
                  <p v-html="sendEmailContent"></p>
                  <!-- <div class="regards">
                    Regards,
                    <span>Carnegie Evaluations</span>
                  </div>
                  <div class="line_blue"></div> -->

                  <emailPreviewFooter></emailPreviewFooter>
                </div>
              </div>
            </div>
            <div class="doc_preview_wrapper" v-if="checkProperty(sendEmailDocs, 'length') > 0">
              <h6>Attachments:</h6>
              <ul class="doc_list_preview">

                <li v-for="(item, index) in sendEmailDocs" :key="index">
                  <div class="top">
                    <span></span>
                  </div>
                  <div class="bottom">
                    <img src="@/assets/images/gmail_file.png">
                    <span class="doc_name" :title="item.name">{{ item.name }}</span>
                    <div class="corner"></div>
                  </div>
                </li>
              </ul>
            </div>
          </form>

        </template>
        <template #modal-footer>
          <button class="form-cancel menustyle" @click="$bvModal.hide('preview_email_modal')">Cancel</button>
          <button class="primary_btn sm menustyle" @click="sendEmailToUser">Send</button>
        </template>

      </b-modal>


      <div v-if="showInvoiceModel">
        <b-sidebar id="sidebar-no-header" aria-labelledby="sidebar-no-header-title" sidebar-class="customer-sidenav"
          title="#INV-3066" right no-header backdrop shadow @change="toggleBodyScrollbar">
          <invoiceDetails :selectedInvoice="invoiceDetails" :evaluation="evaluationDetails">
          </invoiceDetails>
        </b-sidebar>
      </div>


      <b-modal id="preview_model" v-model="docPrivew" dialog-class="document_modal"
        :title="checkProperty(selectedFile, 'name')" hide-footer>
        <h2> <img :class="{
          pdf_view_download: docType == 'pdf',
          office_view_download: docType == 'office',
          image_view_download: docType == 'image',
        }" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>

        <div class="pdf_loader">
          <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/loader.gif" /></figure>

          <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
          <template v-if="docType == 'office'">
            <div style="height:90vh">

              <div id="placeholder" name="placeholder" style="height:100%"></div>
            </div>
          </template>
          <template v-else-if="docType == 'image'">
            <img :src="docValue" />
          </template>
          <template v-else-if="docType == 'pdf'">
            <div class="pdf" style="height:90vh">

              <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%" width="100%">

              </iframe>
            </div>
          </template>
        </div>
      </b-modal>

      <b-modal id="cancel_comments_model" v-model="showCancelPopup" dialog-class="addnotes_model" centered
        no-close-on-backdrop>
        <template #modal-header>
          <h6 class="modal-title">Cancel Evaluation</h6>
          <a class="close" @click="closeCancelPopup"></a>
        </template>
        <template>
          <div class="row">
            <div class="col-md-12">
              <textArea :tplkey="'cancelComments'" fieldName="cancelComments" placeHolder="Comments…"
                v-model="cancelComments" :label="'Comments'" :required="true" :vvas="'Comments'"
                :wrapclass="'mb20'"></textArea>
            </div>
          </div>
        </template>
        <template #modal-footer>
          <button class="form-cancel me-4" @click="closeCancelPopup">Cancel</button>
          <button class="primary_btn md" @click="submitEvaluationCancel">Submit
            <span class="loader" v-if="cancelLoading"><img src="@/assets/images/loader.gif"></span></button>
        </template>
      </b-modal>


      <b-modal id="benficiry_edit_model" v-model="showEditBenInfo" dialog-class="benficiry_edit_model" centered
        no-close-on-backdrop>
        <template #modal-header>
          <h6 class="modal-title">Edit Beneficiary</h6>
          <a class="close" @click="showEditBenInfo = false"></a>
        </template>
        <template>
          <form class="wizard-fieldset show" :data-vv-scope="'beneficiaryEdit'">
            <div class="form_info mt-0">
              <div class="row">
                <div class="col-md-6">
                  <simpleInput :fieldName="'beneficiaryFName'" :cid="'beneficiaryInfo'" :label="'First Name'"
                    :wrapclass="'mb20'" :placeHolder="'First Name'" :vvas="'First Name'" :display="true" :required="true"
                    v-model="beneficiaryInfo.firstName" :allowAlphNum="true" :formscope="'beneficiaryEdit'" />
                </div>
                <div class="col-md-6">
                  <simpleInput :fieldName="'beneficiaryLName'" :cid="'beneficiaryInfo'" :label="'Last Name'"
                    :wrapclass="'mb20'" :placeHolder="'Last Name'" :vvas="'Last Name'" :display="true" :required="true"
                    v-model="beneficiaryInfo.lastName" :allowAlphNum="true" :formscope="'beneficiaryEdit'" />
                </div>

                <div class="col-md-6">
                  <simpleInput :fieldName="'beneficiaryFirm'" :cid="'beneficiaryInfo'" :label="'Beneficiary\'s Firm'"
                    :wrapclass="'mb20'" :placeHolder="'Beneficiary\'s Firm'" :vvas="'Beneficiary\'s Firm'" :display="true"
                    :required="false" v-model="beneficiaryInfo.firm" :allowAlphNum="true"
                    :formscope="'beneficiaryEdit'" />
                </div>
                <div class="col-md-6">
                  <simpleInput :fieldName="'beneficiaryJobTitle'" :cid="'beneficiaryInfo'" :label="'Job Title'"
                    :wrapclass="'mb20'" :placeHolder="'Job Title'" :vvas="'Job Title'" :display="true" :required="false"
                    v-model="beneficiaryInfo.jobTitle" :allowAlphNum="true" :formscope="'beneficiaryEdit'" />
                </div>
                <div class="col-md-6">
                  <simpleInput :fieldName="'beneficiaryDegree'" :cid="'beneficiaryInfo'" :wrapclass="'mb20'"
                    :label="'Beneficiary\'s Degree'" :placeHolder="'Beneficiary\'s Degree'"
                    :vvas="'Beneficiary\'s Degree'" :display="true" :required="false" v-model="beneficiaryInfo.degree"
                    :allowAlphNum="true" :formscope="'beneficiaryEdit'" />
                </div>
                <div class="col-md-6">
                  <simpleInput :fieldName="'usEquivalentDegree'" :cid="'beneficiaryInfo'" :wrapclass="'mb20'"
                    :label="'Desired US equivalent degree'" :placeHolder="'Desired US equivalent degree'"
                    :vvas="'Desired US equivalent degree'" :display="true" :required="false"
                    v-model="beneficiaryInfo.usEquivalentDegree" :allowAlphNum="true" :formscope="'beneficiaryEdit'" />
                </div>
                <div class="col-md-6">
                  <simpleInput :fieldName="'socCode'" :cid="'beneficiaryInfo'" :label="'Occupation SOC code'"
                    :wrapclass="'mb20'" :placeHolder="'Occupation SOC code'" :vvas="'Occupation SOC code'" :display="true"
                    :required="false" v-model="beneficiaryInfo.socCode" :formscope="'beneficiaryEdit'" />
                </div>
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form_group m-0">
                        <label class="form_label">Gender*</label>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <radioInput wrapclass="m-0" :elementId="'male'" :label="'Male'" :fieldName="'gender'"
                        v-model="beneficiaryInfo.gender" :fieldValue="'Male'" :formscope="'beneficiaryEdit'" />
                    </div>
                    <div class="col-md-6">
                      <radioInput wrapclass="m-0" :elementId="'female'" :label="'Female'" :fieldName="'gender'"
                        v-model="beneficiaryInfo.gender" :fieldValue="'Female'" :formscope="'beneficiaryEdit'" />
                    </div>
                    <div class="col-md-12">
                      <div class="form_group m-0">
                        <input type="hidden" class="form-control" v-validate="'required'" v-model="beneficiaryInfo.gender"
                          data-vv-as="Gender" :name="'genderInput'" :formscope="'beneficiaryEdit'" />
                        <span v-show="errors.has('genderInput')" class="form-error">{{
                          errors.first('genderInput') }}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <simpleInput :fieldName="'alternateemail'" :cid="'alternateemail'" :label="'Alternate Emails'"
                    :placeHolder="'Alternate Emails'" :vvas="'Alternate Email'" :display="true" v-model="alternateEmails"
                    :formscope="'evaluationForm' + currentTabIndex"
                    :helpText="'You can enter a comma-separated(,) list of email addresses.'" :showHelpText="true" />
                </div>
              

                                        <div class="col-md-12">
                                        <div class="form_group m-0">
                                            <label class="form_label">Rush Priority</label>
                                        </div>
                                    </div>
                                    <template v-if="checkProperty(priorityList, 'length') > 0"
                                        v-for="(pItem, pIndex) in priorityList.slice().reverse()">
                                        <div class="col-md-6">
                                            <radioInput wrapclass="m-0" :elementId="pItem.name" :label="pItem.name"
                                                :fieldName="pItem.name" :formscope="'beneficiaryEdit'"  v-model="evaluationDetails.priorityRush"
                                                :fieldValue="pItem" />
                                        </div>
                                    </template>

                                   

                <div class="col-md-12">
                  <textArea :label="'Client Notes'" :wrapclass="'h80 mb20'" placeHolder="Client Notes"
                    v-model="specialNotes" :fieldName="'clientNotes'" :cid="'clientNotes'"
                    :formscope="'beneficiaryEdit'"></textArea>
                </div>
              </div>
            </div>
          </form>
        </template>
        <template #modal-footer>
          <button class="form-cancel" @click="showEditBenInfo = false">Cancel</button>
          <button class="primary_btn sm" @click="updateBeneficiaryInfo">Update</button>
        </template>
      </b-modal>

      <!-- side navbar1 -->
      <b-sidebar id="emails_sidebar" v-model="showEmailsPopup" aria-labelledby="sidebar-no-header-title"
        sidebar-class="customer-sidenav emails_sidebar" title="" right no-header backdrop shadow
        @change="toggleBodyScrollbar">
        <template #default="{ hide }">
          <!-- <span class="loader" v-if="isDetailsLoading"><img src="@/assets/images/loader.gif"></span> -->
          <div class="sidenav_header email_header">
            <h3>Emails</h3>
            <a class="close" block @click="hide"><img src="@/assets/images/close.svg"></a>
          </div>
          <div v-if="checkProperty(emailsList, 'length') > 0" class="emails_main">
            <VuePerfectScrollbar>
              <div class="emails_cnt left_cnt">
                <div v-for="(item, index) in emailsList" :key="item._id" class="emails_wrapper email_list"
                  @click="getEmailDetails(item)" :class="{ 'active': item['isSelected'] }">
                  <div class="subject_date" v-if="checkProperty(item, 'sentDate')">
                    <h5 class="from_email" v-if="checkProperty(item, 'fromEmail')">{{ checkProperty(item, 'fromEmail') |
                      formatEmail }}</h5>
                    <h6><img src="@/assets/images/main/clock.png">{{ checkProperty(item, 'sentDate') | formatDateTime }}
                    </h6>
                  </div>
                  <div v-if="checkProperty(item, 'subject')" class="subject_date">
                    <h5>{{ checkProperty(item, 'subject') }}</h5>
                    <h6> </h6>
                  </div>
                  <div class="content" @click.stop v-if="false">
                    <messageLabel :trimcontent="true" @updateLabels="updateLabels" @updateUserIds=""
                      @openCreateLabel="openCreateLabel" :labelsList="labelsList" :message="emailsList[index]" />

                  </div>
                </div>
                <template v-if="checkProperty(emailsList, 'length') <= 0">
                  <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users'
                    :loading="isListLoading" />
                </template>
              </div>
            </VuePerfectScrollbar>
            <div v-if="checkProperty(emailsList, 'length') > 0" class="emails_cnt right_cnt">
              <VuePerfectScrollbar>
                <div class="emails_wrapper" v-if="emailLoading">
                  <span class="loader loader_abs"><img src="@/assets/images/loader.gif" /></span>
                </div>
                <div class="emails_wrapper" v-if="selectedEmail">
                  <div class="subject_date">
                    <h5 v-if="checkProperty(selectedEmail, 'subject')">{{ checkProperty(selectedEmail, 'subject') }}</h5>
                    <div class="replay_area">
                      <!-- <img class="replay" src="@/assets/images/replay.png" @click="replayOpen = true"> -->
                      <h6><img src="@/assets/images/main/clock.png">{{ checkProperty(selectedEmail, 'sentDate') |
                        formatDateTime }}</h6>
                    </div>
                  </div>
                  <div class="content" v-if="checkProperty(selectedEmail, 'htmlContent')">
                    <p v-html="checkProperty(selectedEmail, 'htmlContent')"></p>
                  </div>
                  <!-- <div class="files" v-if="checkProperty(selectedEmail, 'attachments', 'length') > 0">
                    <h6>Files</h6>

                    <DocumentsPreview :type="'documents'" :documentsList="checkProperty(selectedEmail, 'attachments')"
                      :includeDownloadText="false" @download_or_view="download_or_view" />
                   
                  </div> -->
                </div>
                <div class="nodataTemplate" v-if="isFirstTimeLoading">
                  <div class="wrapTpl">
                    <h3>{{ "No item selected" }}</h3>
                  </div>
                </div>

              </VuePerfectScrollbar>
              <div class="email_replay_sec" :class="{ open: replayOpen }">
                <form class="row" :data-vv-scope="'replyEmailForm'">
                  <div class="col-md-12">
                    <simpleInput :wrapclass="'mb20'" :fieldName="'title'" :cid="'title'" :label="'Subject'"
                      :placeHolder="'Title'" :vvas="'Title'" :display="true" :required="true" v-model="templateTitle"
                      :formscope="'replyEmailForm'" />
                  </div>
                  <div class="col-md-12">
                    <textArea :label="'Content'" :wrapclass="'h80 mb10'" placeHolder="Content" v-model="replayContent"
                      :required="true" :fieldName="'emailContent'" :cid="'emailContent'"
                      :formscope="'replyEmailForm'"></textArea>
                  </div>
                  <div class="col-md-12 d-flex justify-content-end">
                    <button class="secondary_btn cancel_btn mt-2 me-2" @click="replayOpen = false">Cancel</button>
                    <button class="secondary_btn mt-2">Submit</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div class="emails_main" v-if="checkProperty(emailsList, 'length') <= 0">
            <!-- <template>
              <div class="nodataTemplate" v-if="isFirstTimeLoading">
                
                  <h3>{{ "No Data Found" }}</h3>
               
              </div>
            </template> -->
            <template v-if="checkProperty(emailsList, 'length') <= 0">
              <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users'
                :loading="isListLoading" />
            </template>
          </div>
        </template>
      </b-sidebar>


      <!-- Upload support docs Modal -->
      <b-modal v-model="showSupportDocs" id="support_docs_modal" dialog-class="create_template send_email_popup" centered
        no-close-on-backdrop>
        <template #modal-header>
          <h6 class="modal-title">Upload</h6>
          <a class="close" @click="closeSupportedDocsPopup"></a>
        </template>
        <template>
          <form class="user_form create_temp" :data-vv-scope="'supportedDocsForm'">
            <div class="row">
              <div class="col-md-12 position-relative">
                <fileUploadDrag :label="'Documents*'" :wrapclass="'mb-0'" :multiple="true" :tplkey="'supportedDocs'"
                  v-model="supportedDocs" :tplsection="'supportedDocs'" vvas="Documents" :fieldName="'supportedDocs'"
                  :cid="'supportedDocs'" @uploadingFile="checkSupportedDocsUploading($event)" />
                <input type="hidden" class="form-control" v-validate="'required'" v-model="supportedDocs"
                  data-vv-as="Documents" :name="'supportedDocsInput'" :formscope="'supportedDocsForm'" />
                <span v-show="errors.has('supportedDocsForm.supportedDocsInput')" class="form-error">{{
                  errors.first('supportedDocsForm.supportedDocsInput')
                }}</span>
              </div>
            </div>
          </form>
        </template>
        <template #modal-footer>

          <div class="right_actions ms-auto">
            <button class="form-cancel" @click="closeSupportedDocsPopup">Cancel</button>
            <button class="primary_btn sm" @click="submitSupportedDocs" :disabled="supportedDocsUploading">Submit</button>
          </div>
        </template>
      </b-modal>

      <b-modal id="createLabelFromListModal" classes="v-modal-sec createLabelModal" :min-width="200" :min-height="200"
        :scrollable="true" :reset="true" width="500px" height="auto" centered no-close-on-backdrop>
        <template #modal-header>
          <h6 class="modal-title">Create Label</h6>
          <a class="close" @click="$bvModal.hide('createLabelFromListModal')"></a>
        </template>

        <template>
          <form data-vv-scope="newLabelform">
            <div class="form-container">
              <div class="vx-row">
                <div class="vx-col w-full">
                  <div class="form_group">
                    <label class="form_label">Please enter a new label name</label>
                    <simpleInput :wrapclass="'w-full'" :fieldName="'labelname'" :cid="'labelname'" :label="''"
                      :placeHolder="'Label Name'" :vvas="'Label Name'" :display="true" :required="true"
                      v-model="labelName" :formscope="'newLabelform'" />
                    <!-- <input name="labelname" v-validate="'required'" class="w-full" data-vv-as="label name"
                    v-model="labelName" /> -->
                    <span class="text-danger text-sm" v-show="errors.has('newLabelform.labelname')">{{
                      errors.first("newLabelform.labelname") }}</span>
                  </div>
                </div>
              </div>
              <div class="vx-row">
                <simpleColorPicker v-model="selectColor" :formscope="'newLabelform'" :fieldName="'labelColor'"
                  :cid="'labelColor'" :name="'labelColor'" :label="'Select the label color'" :required="true" />
              </div>
              <div class="text-danger text-sm formerrors custom_margin" v-show="formerrors.msg">
                <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                  icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formerrors.msg
                  }}</vs-alert>
              </div>
            </div>
          </form>
        </template>

        <template #modal-footer>
          <span class="loader" v-if="loadingLabel"><img src="@/assets/images/loader.gif" /></span>
          <button color="success" :disabled="loadingLabel" class="primary_btn md" type="filled" @click="createLabel">
            Create
          </button>
        </template>

      </b-modal>

      <!-- <b-modal  id="template_model" dialog-class="delivery_template_model professors" centered
        no-close-on-backdrop>
        <template #modal-header>
          <h6 class="modal-title">Preliminary Opinion Templates</h6>
          <div class="d-flex">
            <a class="close" @click="closeTemplatePopup"></a>
          </div>
        </template>
        <template>
          <form :data-vv-scope="'preliminaryTemplateForm'">
            <simpleSelect :multiple="false" :wrapclass="'mb-3'" :optionslist="preliminaryTemplates" :display="true"
              :placeHolder="'Select Template'" :searchable="false" :required="true" :close-on-select="true"
              :clear-on-select="true" v-model="popupTemplate" :fieldName="'preliminaryTemplate'"
              :cid="'preliminaryTemplate'" :hideSelected="false" :listContainsId="true" :trackBy="'title'"
              :label="'Select Template'" :formscope="'preliminaryTemplateForm'" />

            <textArea v-if="checkProperty(popupTemplate, 'title')" class="mb-3" :tplkey="'preliminaryContent'"
              fieldName="preliminaryContent" placeHolder="Email content here..."
              v-model="popupTemplate.content"></textArea>
          </form>
        </template>
        <template #modal-footer>
          <button class="form-cancel" @click="closeTemplatePopup">Cancel</button>
          <button class="primary_btn md" @click="onTemplateSubmit">Use Content</button>
        </template>
      </b-modal> -->
      <div v-if="showTemplatePopup">
        <selectTemplate v-if="showTemplatePopup" @updateTemplate="onTemplateSubmit"
          @closeTemplatePopup="onTemplatePopupClose"></selectTemplate>

      </div>

      <span class="loader" v-if="detailsLoading"><img src="@/assets/images/loader.gif" /></span>
    </div>

  </div>
</template>
<script>
// @ is an alias to /src
import JQuery from "jquery";
import Timeline from 'timeline-vuejs';
import 'timeline-vuejs/dist/timeline-vuejs.css';
import simpleSelect from '@/views/forms/simpleSelect.vue';
import VTooltip from 'v-tooltip';
import searchInput from '@/views/forms/searchInput.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import textArea from "@/views/forms/textarea.vue";
import VuePerfectScrollbar from 'vue-perfect-scrollbar';
import DatePicker from 'vue2-datepicker';
import 'vue2-datepicker/index.css';
import radioInput from "@/views/forms/radioInput.vue";
import actionMapwithClient from "@/views/evaluationactions/actionMapwithClient.vue";
import actionReview from "@/views/evaluationactions/actionReview.vue";
import actionAssign from "@/views/evaluationactions/actionAssign.vue";
import actionPendingPayment from "@/views/evaluationactions/actionPendingPayment.vue";
import actionIssueInvoice from "@/views/evaluationactions/actionIssueInvoice.vue";
import actionSetDueDate from "@/views/evaluationactions/actionSetDueDate.vue";
import actionEvaluationTemplate from "@/views/evaluationactions/actionEvaluationTemplate.vue";
import actionAssignEvaluator from "@/views/evaluationactions/actionAssignEvaluator.vue";
import actionUploadDocuments from "@/views/evaluationactions/actionUploadDocuments.vue";
import actionAssignReviewer from "@/views/evaluationactions/actionAssignReviewer.vue";
import actionOnsiteReview from "@/views/evaluationactions/actionOnsiteReview.vue";
import actionRevisionByOnsite from "@/views/evaluationactions/actionRevisionByOnsite.vue";
import actionDeliverytoClient from "@/views/evaluationactions/actionDeliverytoClient.vue";
import actionApprovePayment from "@/views/evaluationactions/actionApprovePayment.vue";
import actionRevisedDocuments from "@/views/evaluationactions/actionRevisedDocuments.vue";
import actionReviewConform from "@/views/evaluationactions/actionReviewConform.vue";
import actionSaveInvoice from "@/views/evaluationactions/actionSaveInvoice.vue";
import actionApproveDocuments from "@/views/evaluationactions/actionApproveDocuments.vue";
import actionSentEmail from "@/views/evaluationactions/actionSentEmail.vue";
import actionSendPaymentLink from "@/views/evaluationactions/actionSendPaymentLink.vue";
import actionEvaluationEmail from "@/views/evaluationactions/actionEvaluationEmail.vue";
import actionEvaluationCanceled from "@/views/evaluationactions/actionEvaluationCanceled.vue";


import invoiceDetails from "@/views/common/invoiceDetails.vue";
import NoDataFound from "@/views/common/noData.vue";
import DocumentsPreview from './common/documentsPreview.vue';
import customSelect from '@/views/forms/customSelect.vue';
import messageLabel from "@/views/messages/messagesLabels.vue";
import moment from "moment";
import LabelCreatePopup from "@/views/messages/labelCreatePopup.vue";
import simpleColorPicker from "@/views/forms/simpleColorPicker.vue";
import emailPreviewFooter from "@/views/emailPreviewFooter.vue";
import selectTemplate from "@/views/common/selectTemplate.vue"


const { startOfWeek, addWeeks, format } = require('date-fns');

export default {
  data() {
    return {
      showActionReview: true,
      selecteds: null,
      showUploads: false,
      showUpload: false,
      files: [],
      files: null,
      selected: '',
      checked: true,
      time1: null,
      evaluatorList: ['Jacob Jones', 'Robert Fraczkiewicz', 'Assign one of the Evaluator either ', 'Charlie Duhor', 'Michael Taiwo'],
      templateList: ['Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'Nulla varius est sed ante iaculis, ut ullamcorper risus pulvinar.', 'Suspendisse euismod velit vel mauris sodales imperdiet vel a quam. ', 'Pellentesque malesuada elit ut est blandit, ac interdum tortor facilisis.', 'Nam lobortis sapien sed diam suscipit efficitur.'],
      evaluationDetails: null,
      currentDocumentsTab: 'client-documents',
      showReviewSection: false,
      clientDocuments: [],
      showInvoiceModel: false,
      invoiceDetails: { 'id': 1 },
      showDetailsPopup: false,
      showEditProfessor: false,
      professorList: [],
      selectedProfessor: null,
      loading: false,
      docPrivew: false,
      docType: '',
      formSubmited: false,
      selectedFile: null,
      docmentsTabs: [{ 'id': 1, 'name': 'Client Documents' }, { 'id': 2, 'name': 'Drafts' }],
      showCancelPopup: false,
      cancelComments: '',
      cancelLoading: false,
      showEditBenInfo: false,
      replayOpen: false,
      beneficiaryInfo: {
        firstName: '',
        middleName: '',
        lastName: '',
        jobTitle: '',
        gender: null,
        degree: '',
        usEquivalentDegree: '',
        socCode: '',
        firm: '',

      },
      specialNotes: "",
      alternateEmails: "",
      altEmailsList: [],
      showAddTemplate: false,
      showAddNotes: false,
      showSendEmail: false,
      selectedEmailAction: '',
      selectedNotes: "",
      isFromNoteEdit: false,
      sendEmailSubject: '',
      sendEmailContent: '',
      sendEmilType: '',
      sendEmailDocs: [],
      priorityList:[],
      sendEmailFilesUploading: false,
      replayContent: '',
      showSupportDocs: false,
      supportedDocs: [],
      supportedDocsUploading: false,
      showEmailsPopup: false,
      emailsList: [],
      selectedEmail: null,
      searchtxt: "",
      labelsList: [],
      loadingLabel: false,
      labelName: '',
      selectColor: '',
      formerrors: {
        msg: ''
      },
      showTemplatePopup: false,
      detailsLoading: false,
      emailLoading: false,
      isFirstTimeLoading: true,
    }
  },
  components: {
    Timeline,
    VTooltip,
    searchInput,
    simpleSelect,
    simpleInput,
    fileUploadDrag,
    textArea,
    VuePerfectScrollbar,
    DatePicker,
    radioInput,
    actionMapwithClient,
    actionReview,
    actionPendingPayment,
    NoDataFound,
    DocumentsPreview,
    actionAssign,
    actionIssueInvoice,
    actionSetDueDate,
    actionEvaluationTemplate,
    actionAssignEvaluator,
    actionUploadDocuments,
    actionAssignReviewer,
    actionOnsiteReview,
    actionRevisionByOnsite,
    actionDeliverytoClient,
    actionApprovePayment,
    actionRevisedDocuments,
    invoiceDetails,
    customSelect,
    actionReviewConform,
    actionSaveInvoice,
    actionApproveDocuments,
    actionSentEmail,
    actionSendPaymentLink,
    messageLabel,
    LabelCreatePopup,
    simpleColorPicker,
    emailPreviewFooter,
    selectTemplate,
    actionEvaluationEmail,
    actionEvaluationCanceled,
  },
  methods: {
    
        getPriorities() {
            this.$store.dispatch("getMasterData", 'evaluation_priority')
                .then((res) => {
                    this.priorityList = res
                })
        },
    onTemplatePopupClose() {
      this.showTemplatePopup = false
    },
    onTemplateSubmit(templateVal) {

      // const editorInstance = this.$refs.sendEmailParentRef.$refs.sendEmailContent.$_instance;
      // if (editorInstance) {
      //   const cursorPosition = editorInstance.model.document.selection.getFirstPosition();
      //   editorInstance.model.change((writer) => {
      //     writer.insertText(templateVal.content, cursorPosition);
      //   });
      //   this.sendEmailContent = editorInstance.getData();
      // } else {
      let resultContent = this.sendEmailContent + " " + (this.checkProperty(templateVal, 'content') ? this.checkProperty(templateVal, 'content') : '')
      this.sendEmailContent = resultContent
      //  }


      this.showTemplatePopup = false
    },
    openTemplatePopup() {
      // this.sendEmailContent = ''
      this.showTemplatePopup = true
    },

    toggleBodyScrollbar(visible) {
      const body = document.getElementsByTagName('body')[0];

      if (visible)
        body.classList.add("overflow-hidden");
      else
        body.classList.remove("overflow-hidden");
    },
    onClick() {
      // Close the menu and (by passing true) return focus to the toggle button
      this.$refs.dropdown.hide(true)
    },
    onChange: function () {
      checked = false;
    },
    clearFiles() {
      this.$refs['file-input'].reset()
    },
    selectFile() {
      let fileInputElement = this.$refs.file;
      fileInputElement.click();
      // ...
    },
    listUploads(e) {
      this.showUploads = true;
      let files = e.srcElement.files;

      if (files) {
        this.files = files;
      }

      let self = this;

      for (var index = 0; index < files.length; index++) {
        // generate a new FileReader object
        var reader = new FileReader();

        // inject an image with the src url
        reader.onload = function (event) {
          const imageUrl = event.target.result;
          const thumb = document.querySelectorAll('.thumb')[index];
          self.imageUrlArray.push(imageUrl);
        }

        // when the file is read it triggers the onload 
        // event above.
        reader.readAsDataURL(files[index]);
      }
    },
    deleteItem: function (e) {
      let currentFiles = app.files;
      let target = toString(e.srcElement.value);
      let parentCard = e.srcElement.parentNode.parentNode;

      parentCard.classList.toggle('hidden');
      setTimeout(() => {
        parentCard.style.display = 'none';
      }, 1000);
    },
    uploadFiles(e) {
      let cardArray = [];

      let fileCount = app.files.length;
      for (let i = 0; i < fileCount; i++) {
        cardArray.push(`card-${i}`);
      }

      let cardIdsArray = [];

      cardArray.forEach((ref) => {

        let currentCard = document.getElementById(app.$refs[ref][0].id);
        cardIdsArray.push(currentCard);
      });

      cardIdsArray.forEach((id) => {
        // check if card is ticked for upload

        console.log(app.checkboxes);

        // if checkbox for this card is checked, set flag
        const uploadFlag = id.querySelectorAll('[type="checkbox"]:checked');

        // if this card has upload flag, upload
        if (uploadFlag) {
          id.classList.toggle('is-uploading');

          setTimeout(() => {
            id.classList.toggle('hidden');

            setTimeout(() => {
              id.style.display = 'none';
            }, 1000);
          }, 1000);
        }
      });

      // clear files
      app.files = [];
    },

    resetFileField(e) {
      console.log('reset');
      const fileInput = app.$refs['file-input'];
      console.log(typeof (fileInput));
      fileInput.value = '';
      app.files = [];
    },

    getEvaluationDetails() {
      this.showActionReview = false;
      this.showReviewSection = false
      let postData =
      {
        "evaluationId": this.$route.params.itemId,
      }
      this.$store.dispatch("getEvaluationDetails", postData)
        .then((res) => {
        
          if (this.checkProperty(res, 'result') == null) {
            this.showToster({ message: "Access denied!", isError: true });
            this.$router.push('/evaluations-list');
          } else {
            this.evaluationDetails = null
            this.evaluationDetails = null
            this.evaluationDetails = res.result;
           
            this.evaluationDetails.priorityRush =  res.result.priorityId;
              this.getPriorities();
            const $ = JQuery;
            $("html, body").animate({ scrollTop: 0 }, 100);
          }
          setTimeout(() => {
            this.showActionReview = true;
          }, 5);
        })
        .catch((error) => {
          this.showActionReview = true;
        })
    },
    checkCurrentTabAndReload(tabName) {
      this.currentDocumentsTab = tabName
      if (tabName == 'client-documents') {

      } else {

      }
    },
    getEvaluationDocsByType(evaluationItem) {
      let docs = []
      if (this.checkProperty(evaluationItem, 'subTypes', 'length') > 0) {
        _.forEach(evaluationItem.subTypes, (subItem) => {
          let resultDocs = _.filter(subItem.documents, (docItem) => {
            return this.checkProperty(docItem, 'path', 'length') > 0
          })
          if (this.checkProperty(resultDocs, 'length') > 0) {
            docs = [...docs, ...resultDocs]
          }
        })
      }

      return docs
    },
    updateEvaluationDetails() {
      setTimeout(() => {
        this.getEvaluationDetails()
      }, 200)
    },
    getInvoiceDetails() {

      if (this.checkProperty(this.evaluationDetails, 'invoiceId')) {
        let postData =
        {
          "invoiceId": this.evaluationDetails.invoiceId,
        }
        this.$store.dispatch("getInvoiceDetails", postData)
          .then((res) => {
            this.invoiceDetails = res.result
            // setTimeout(() => {
            this.showInvoiceModel = true
            // })

          })
          .catch((error) => {

          })
      }

    },
    download_or_view(docItem) {
      let value = _.cloneDeep(docItem);
      var _self = this;
      this.formSubmited = false;
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }
      this.selectedFile = value;
      this.docValue = "";
      this.docPrivew = false;
      this.docType = false;
      this.docType = this.findmsDoctype(value["name"], value.mimetype);

      if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
          "fileName": value.name ? value.name : ''
        };
        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;
          if (this.docType == "office") {
            this.docPrivew = true;
            setTimeout(() => {
              document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
              let _editing = false;
              var _ob = {}
              _ob = {
                name: value.name,
                evaluationId: this.evaluationDetails._id,
                //  _id: value._id,
                "extn": "docx",
                "formLetterType": "Letter",
                //   parentId: value._id

              }
              window.docEditor = new DocsAPI.DocEditor("placeholder2",
                {

                  "document": {
                    "c": "forcesave",
                    "fileType": "docx",
                    // "key": value._id,
                    "userdata": JSON.stringify(_ob),
                    "title": value.name,
                    "url": response.data.result.data,
                    permissions: {
                      edit: _editing,
                      download: true,
                      reader: false,
                      review: false,
                      comment: false
                    }
                  },

                  "documentType": "word",
                  "height": "100%",
                  "width": "100%",

                  "editorConfig": {
                    "userdata": JSON.stringify(_ob),
                    "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                    "customization": {
                      "logo": {
                        "image": "https://immibox.com/app/favicon.png",
                        "imageDark": "https://immibox.com/app/favicon.png",
                        "url": "https://immibox.com"
                      },
                      "anonymous": {
                        "request": false,
                        "label": "Guest"
                      },
                      "chat": false,
                      "comments": false,
                      "compactHeader": false,
                      "compactToolbar": true,
                      "compatibleFeatures": false,
                      "feedback": {
                        "visible": false
                      },
                      "forcesave": true,
                      "help": false,
                      "hideNotes": true,
                      "hideRightMenu": true,
                      "hideRulers": true,
                      layout: {
                        toolbar: {
                          "collaboration": false,
                        },
                      },
                      "macros": false,
                      "macrosMode": "warn",
                      "mentionShare": false,
                      "plugins": false,
                      "spellcheck": false,
                      "toolbarHideFileName": true,
                      "toolbarNoTabs": true,
                      "uiTheme": "theme-light",
                      "unit": "cm",
                      "zoom": 100
                    },
                  }, events: {
                    onReady: function () {

                    },
                    onDocumentStateChange: function (event) {
                      var url = event.data;
                      console.log(event)

                      if (!event.data) {

                        if (value.editedDocument) {

                        }

                      }
                    }

                  }
                });
            }, 100)
          }

          if (this.docType == "pdf") {

            // return
            var _vid = value._id;
            if (value.parentId) {
              _vid = value.parentId;
            }
            var viewmode = 1; // Enable edit
            viewmode = 0; //Disabled Edit
            if (value.viewmode) {
              viewmode = 0;
            }
            this.docValue = "https://carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
            console.log(this.docValue)
            this.docPrivew = true;
          }
          if (this.docType == "image") {
            this.docPrivew = true;
          }
        });
      } else {
        this.downloads3file(value);
      }

    },
    changeProfessor() {

      this.selectedProfessor = this.checkProperty(this.evaluationDetails, 'assignedToProfessorDetails')
      let postData =
      {
        "matcher": {
          "roleIds": [9],
        },
        "sorting": {
          "path": "createdOn",
          "order": -1
        },
        "getMasterData": true,// if Masterdata required
        "page": 1,
        "perpage": 500,
      }
      this.$store.dispatch("getUsersList", postData)
        .then((res) => {
          let lst = []
          _.forEach(res.data.result.list, (item) => {
            let professorIndex = _.findIndex(this.checkProperty(this.evaluationDetails, 'suggestProfessors'), (suggested) => {
              return suggested["_id"] == item["_id"];
            })
            item['isSuggested'] = false;
            if (professorIndex > -1) {
              item['isSuggested'] = true;
            }
            lst.push(item);
          });

          this.professorList = lst
          // this.professorList = res.data.result.list
        })
        .catch((error) => {
        })

      this.showEditProfessor = true
    },
    updateProfessor() {

      // this.$validator.validateAll().then((result) => {
      //   if (result) {

      //   this.loading = true
      let postData = {
        "evaluationId": this.evaluationDetails._id,
        "userId": this.selectedProfessor._id,
        "content": this.getEmailContent,
        "reassign": true,
      }
      this.$store.dispatch("assignUser", postData)
        .then((response) => {
          //     this.loading = false
          this.showEditProfessor = false
          if (response.error) {
            (response.error)
            Object.assign(this.formerrors, {
              msg: response.error.result
            });
            this.showToster({ message: response.error.result, isError: true });
          } else {
            this.showToster({ message: response.message, isError: false });
            this.updateEvaluationDetails()
            //  this.selectedUser = null
          }
        })
        .catch((error) => {
          //     this.loading = false
          this.showEditProfessor = false
          this.showToster({ message: error, isError: true });
        })
      //   }
      // })
    },
    getRevisionLogs() {
      let completedLogs = []
      if (this.checkProperty(this.evaluationDetails, 'evaluationActivityInfoLogs', 'length') > 0) {
        let assignedProfessorLog = _.filter(this.checkProperty(this.evaluationDetails, 'evaluationActivityInfoLogs'), (item) => {
          return (item.action == 'EVALUATION_PROFESSER_ASSIGNED' || item.action == 'REVIEW_CONFIRMED') && (this.getAssignedToDetailsId(this.checkProperty(item, 'assignToDetails')) == this.checkProperty(this.getUserData, '_id'))
        })
        if (this.checkProperty(assignedProfessorLog, 'length') > 0) {
          let assigedAt = this.checkProperty(assignedProfessorLog[0], 'updatedOn')
          completedLogs = _.filter(this.checkProperty(this.evaluationDetails, 'evaluationActivityInfoLogs'), (item) => {
            return ((item.action == 'SIGN_REQUESTED' || item.action == 'SENT_FOR_REVISION') && (new Date(item.updatedOn).getTime() >= new Date(assigedAt).getTime()))
          });
        }
      }
      return completedLogs;
    },

    getDocumentsArray() {
      if ([15].indexOf(this.getUserRoleId) > -1) {
        return this.docmentsTabs.slice(0, 1)
      }
      else {
        if (this.checkProperty(this.evaluationDetails, 'statusDetails', 'id') > 9
          || (this.checkProperty(this.evaluationDetails, 'statusDetails', 'id') > 7 && (this.isActivityCompleted(this.evaluationDetails, 'EVALUATION_TEMPLATE_ASSIGNED') || this.isActivityCompleted(this.evaluationDetails, 'EVALUATION_EVALUATOR_ASSIGNED') || this.isActivityCompleted(this.evaluationDetails, 'EVALUATION_CONSULTANT_ASSIGNED')))) {
          return this.docmentsTabs.slice().reverse()
        } else {
          return this.docmentsTabs
        }
      }

    },

    getCurrentDraftDocuments() {

      let docs = []
      let previousActivity = this.checkProperty(this.evaluationDetails, 'previousActivity')
      if (previousActivity == 'EVALUATION_DOCUMENTS_CONFIRMED') {
        previousActivity = 'EVALUATION_DOCUMENTS_SAVED'
      }
      if (previousActivity == 'EVALUATION_DOCS_GENERATED') {
        previousActivity = 'EVALUATION_TEMPLATE_ASSIGNED'
      }

      let latestEvaluationLog = _.find(this.checkProperty(this.evaluationDetails, 'evaluationActivityInfoLogs'), function (item) {
        return item.action == previousActivity;
      });

      if (this.checkProperty(this.evaluationDetails, 'statusDetails', 'id') > 10 && this.checkProperty(latestEvaluationLog, 'documents')
        && this.checkProperty(latestEvaluationLog, 'documents', 'length') > 0) {
        docs = this.checkProperty(latestEvaluationLog, 'documents')
      }

      if (this.checkProperty(this.evaluationDetails, 'statusDetails', 'id') == 10 && this.checkProperty(latestEvaluationLog, 'documents')
        && this.checkProperty(latestEvaluationLog, 'documents', 'length') > 0) {
        if (this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('EVALUATION_TEMPLATE_ASSIGNED') > this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('EVALUATION_DOCUMENTS_SAVED')) {
          if (this.checkProperty(this.evaluationDetails, 'generatedDocuments', 'length') > 0) {
            docs = this.checkProperty(this.evaluationDetails, 'generatedDocuments')
          }
        } else {
          docs = this.checkProperty(latestEvaluationLog, 'documents')
        }
      } else if (this.checkProperty(this.evaluationDetails, 'statusDetails', 'id') > 7 && (this.checkProperty(latestEvaluationLog, 'action') == 'EVALUATION_TEMPLATE_ASSIGNED' || this.checkProperty(latestEvaluationLog, 'action') == 'EVALUATION_EVALUATOR_ASSIGNED' || this.checkProperty(latestEvaluationLog, 'action') == 'EVALUATION_CONSULTANT_ASSIGNED')) {
        // if (this.checkProperty(latestEvaluationLog, 'generateLogs', 'length') > 0
        //   && this.checkProperty(latestEvaluationLog.generateLogs[0], 'documents', 'length') > 0) {
        //   docs = this.checkProperty(latestEvaluationLog.generateLogs[0], 'documents')
        // } else
        if (this.checkProperty(latestEvaluationLog, 'documents', 'length') > 0) {
          docs = this.checkProperty(latestEvaluationLog, 'documents')
        }
      }
      else if (this.checkProperty(latestEvaluationLog, 'action') == 'SENT_FOR_REVISION'
        && this.checkProperty(latestEvaluationLog, 'revisedDocuments')
        && this.checkProperty(latestEvaluationLog, 'revisedDocuments', 'length') > 0) {
        docs = this.checkProperty(latestEvaluationLog, 'revisedDocuments')
      }


      // if (this.checkProperty(this.evaluationDetails, 'statusDetails', 'id') > 9 && this.checkProperty(this.evaluationDetails, 'latestEvaluationLog', 'documents')
      //   && this.checkProperty(this.evaluationDetails.latestEvaluationLog, 'documents', 'length') > 0) {
      //   docs = this.checkProperty(this.evaluationDetails, 'latestEvaluationLog', 'documents')
      // } else if (this.checkProperty(this.evaluationDetails, 'statusDetails', 'id') > 7 && (this.checkProperty(this.evaluationDetails, 'latestEvaluationLog', 'action') == 'EVALUATION_TEMPLATE_ASSIGNED' || this.checkProperty(this.evaluationDetails, 'latestEvaluationLog', 'action') == 'EVALUATION_EVALUATOR_ASSIGNED' || this.checkProperty(this.evaluationDetails, 'latestEvaluationLog', 'action') == 'EVALUATION_CONSULTANT_ASSIGNED')) {
      //   if (this.checkProperty(this.evaluationDetails.latestEvaluationLog, 'generateLogs', 'length') > 0
      //     && this.checkProperty(this.evaluationDetails.latestEvaluationLog.generateLogs[0], 'documents', 'length') > 0) {
      //     docs = this.checkProperty(this.evaluationDetails.latestEvaluationLog.generateLogs[0], 'documents')
      //   } else if (this.checkProperty(this.evaluationDetails.latestEvaluationLog, 'documents', 'length') > 0) {
      //     docs = this.checkProperty(this.evaluationDetails, 'latestEvaluationLog', 'documents')
      //   }
      // }
      // else if (this.checkProperty(this.evaluationDetails, 'latestEvaluationLog', 'action') == 'SENT_FOR_REVISION'
      //   && this.checkProperty(this.evaluationDetails, 'latestEvaluationLog', 'revisedDocuments')
      //   && this.checkProperty(this.evaluationDetails.latestEvaluationLog, 'revisedDocuments', 'length') > 0) {
      //   docs = this.checkProperty(this.evaluationDetails, 'latestEvaluationLog', 'revisedDocuments')
      // }

      return docs

    },

    openCancelPopup() {
      this.cancelComments = ''
      this.showCancelPopup = true
    },
    closeCancelPopup() {
      //this.cancelComments=''
      this.showCancelPopup = false
    },
    submitEvaluationCancel() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          this.cancelLoading = true
          let postData = {
            "evaluationId": this.evaluationDetails._id,
            "comment": this.cancelComments,
            "statusId": 17
          }
          this.$store.dispatch("evaluationCancel", postData)
            .then((response) => {
              this.cancelLoading = false
              if (response.error) {
                (response.error)
                Object.assign(this.formerrors, {
                  msg: response.error.result
                });
                this.showToster({ message: response.error.result, isError: true });
              } else {
                this.closeCancelPopup()
                this.showToster({ message: response.message, isError: false });
                this.updateEvaluationDetails()
                //  this.selectedUser = null
              }
            })
            .catch((error) => {
              this.cancelLoading = false
              this.closeCancelPopup()
              this.showToster({ message: error, isError: true });
            })
        }
      })

    },

    editBeneficiaryInfo() {
      this.specialNotes = this.evaluationDetails.specialNotes
      this.alternateEmails = this.evaluationDetails.alternateEmail
      this.beneficiaryInfo = { ...this.evaluationDetails.beneficiaryInformation }
      this.showEditBenInfo = true
    },
    updateBeneficiaryInfo() {
      this.$validator.validateAll('beneficiaryEdit').then((result) => {
        if (result) {
          //    this.loading = true
          let isEmailValid = true
          isEmailValid = this.isAltEmailValid
          if (!isEmailValid) {
            this.showToster({ message: "Alternate emails are not valid.", isError: true });
          } else {
            let postData = {
              "evaluationId": this.evaluationDetails._id,
              "beneficiaryInformation": this.beneficiaryInfo,
              "specialNotes": this.specialNotes,
              "alternateEmail": this.alternateEmails,
              "altEmailsList": this.altEmailsList
            }
            this.$store
              .dispatch("updateEvaluationDetails", postData)
              .then((response) => {
                if (response.error) {
                  this.showToster({ message: response.error.message, isError: true });
                } else {
                  this.showEditBenInfo = false
                  this.showToster({ message: response.message, isError: false });
                  this.updateEvaluationDetails()
                }
              })
              .catch((error) => {
                this.showToster({ message: error, isError: true });
                //    this.loading = false;
              });

          }

        }
      })
    },

    openAddNotesPopup(isNotesEdit = false) {
      if (isNotesEdit) {
        this.isFromNoteEdit = true
        if (this.checkProperty(this.evaluationDetails, 'carnegieNote', 'length') > 0) {
          this.selectedNotes = this.checkProperty(this.evaluationDetails, 'carnegieNote')
        }
      }
      this.showAddNotes = true
    },
    closeAddNotesPopup() {
      this.isFromNoteEdit = false
      this.selectedNotes = ""
      this.showAddNotes = false
    },
    openSendEmailPopup(emailType) {
      this.sendEmailFilesUploading = false
      this.sendEmilType = emailType
      this.sendEmailSubject = ''
      this.sendEmailContent = ''
      this.sendEmailDocs = []
      this.showSendEmail = true
    },
    closeSendEmaiPopup() {
      this.sendEmilType = ''
      this.sendEmailSubject = ''
      this.sendEmailContent = ''
      this.sendEmailDocs = []
      this.showSendEmail = false
    },
    openPreviewPopup() {
      this.$validator.validateAll("sendEmailForm").then((result) => {
        if (result) {
          this.$bvModal.show('preview_email_modal')
        }
      })
    },
    submitNotes() {
      this.$validator.validateAll("evalNotesForm").then((result) => {
        if (result) {
          //    this.loading = true
          let postData = {
            "evaluationId": this.evaluationDetails._id,
            "carnegieNote": this.selectedNotes,
          }
          if (this.isFromNoteEdit) {
            this.$store
              .dispatch("updateEvaluationNote", postData)
              .then((response) => {
                if (response.error) {
                  this.showToster({ message: response.error.message, isError: true });
                } else {
                  this.closeAddNotesPopup()
                  this.showToster({ message: response.message, isError: false });
                  this.updateEvaluationDetails()
                }
              })
              .catch((error) => {
                this.showToster({ message: error, isError: true });
                //    this.loading = false;
              });
          } else {
            this.$store
              .dispatch("createEvaluationNote", postData)
              .then((response) => {
                if (response.error) {
                  this.showToster({ message: response.error.message, isError: true });
                } else {
                  this.closeAddNotesPopup()
                  this.showToster({ message: response.message, isError: false });
                  this.updateEvaluationDetails()
                }
              })
              .catch((error) => {
                this.showToster({ message: error, isError: true });
                //    this.loading = false;
              });
          }


        }
      })
    },

    sendEmailToUser() {
      this.$validator.validateAll("sendEmailForm").then((result) => {
        if (result) {
          let postData = {
            "evaluationId": this.evaluationDetails._id,
            "subject": this.sendEmailSubject,
            "content": '',
            "documents": [],
            "sendEmailTo": this.sendEmilType
          }
          if (this.sendEmailContent) {
            postData['content'] = this.sendEmailContent
          }
          if (this.checkProperty(this.sendEmailDocs, 'length') > 0) {
            postData['documents'] = this.sendEmailDocs
          }

          this.$store
            .dispatch("sendEvaluationEmail", postData)
            .then((response) => {
              if (response.error) {
                this.showToster({ message: response.error.message, isError: true });
              } else {
                this.$bvModal.hide('preview_email_modal')
                this.closeSendEmaiPopup()
                this.showToster({ message: response.message, isError: false });
                this.updateEvaluationDetails()
              }
            })
            .catch((error) => {
              this.showToster({ message: error, isError: true });
              //    this.loading = false;
            });
        }
      })
    },
    checkFileUploading() {
      let uploading = false
      let resultDocs = _.filter(this.sendEmailDocs, (docItem) => {
        return this.checkProperty(docItem, 'fileUploading') && docItem.fileUploading
      })
      if (this.checkProperty(resultDocs, 'length') > 0) {
        if (!uploading) {
          uploading = true
        }
      }
      this.sendEmailFilesUploading = uploading
    },
    getCustomerName() {
      if (this.checkProperty(this.evaluationDetails, 'customersDetails', 'companyName')) {
        return this.checkProperty(this.evaluationDetails, 'customersDetails', 'companyName')
      } else if (this.checkProperty(this.evaluationDetails, 'customersDetails', 'name')) {
        return this.checkProperty(this.evaluationDetails, 'customersDetails', 'name')
      } else if (this.checkProperty(this.evaluationDetails, 'name')) {
        return this.checkProperty(this.evaluationDetails, 'name')
      }
      return ''
    },
    checkSupportedDocsUploading() {
      let uploading = false
      let resultDocs = _.filter(this.supportedDocs, (docItem) => {
        return this.checkProperty(docItem, 'fileUploading') && docItem.fileUploading
      })
      if (this.checkProperty(resultDocs, 'length') > 0) {
        if (!uploading) {
          uploading = true
        }
      }
      this.supportedDocsUploading = uploading
    },
    openSupportedDocsPopup() {
      this.supportedDocsUploading = false
      this.supportedDocs = []
      this.showSupportDocs = true
    },
    closeSupportedDocsPopup() {
      this.supportedDocsUploading = false
      this.supportedDocs = []
      this.showSupportDocs = false
    },
    submitSupportedDocs() {
      this.$validator.validateAll("supportedDocsForm").then((result) => {
        if (result) {

          let postData = {
            "evaluationId": this.evaluationDetails._id,
            "supportDocument": this.supportedDocs,
          }
          this.$store
            .dispatch("uploadEvaluationSupportedDocuments", postData)
            .then((response) => {
              if (response.error) {
                this.showToster({ message: response.error.message, isError: true });
              } else {
                this.closeSupportedDocsPopup()
                this.showToster({ message: response.message, isError: false });
                this.updateEvaluationDetails()
              }
            })
            .catch((error) => {
              this.showToster({ message: error, isError: true });
              //    this.loading = false;
            });


        }
      })
    },
    getDocumentsTitle() {

      if (this.checkProperty(this.evaluationDetails, 'statusId') == 8) {
        return "Template Documents"
      }
      if (this.checkProperty(this.evaluationDetails, 'statusId') == 10) {
        return "Offshore Completed Documents"
      }

      return "Draft Documents"
    },

    openEmailsPopup() {
      this.selectedEmail = null
      this.isFirstTimeLoading = true
      this.emailsList = []
      this.getLabelsList();
      this.getEvaluationEmails()
      this.showEmailsPopup = true
    },


    getEvaluationEmails() {
      this.$bvModal.show('emails_sidebar')
      let postData = {
        "matcher": {
          "searchString": this.checkProperty(this.evaluationDetails, 'requestId'),
          "createdDateRange": [],
          "evalLabelIds": [],
          "getLables": false
        },
        "sorting": {
          "path": "createdOn", //title, statusName, createdByName, updatedOn, 
          "order": -1
        },
        "page": 1,
        "perpage": 500
      }
      this.$store.dispatch("getInboxEmails", postData)
        .then((res) => {
          this.isListLoading = false
          this.updateLoading(false);
          this.emailsList = res.data.result.list

        })
        .catch((error) => {

        })

    },
    getEmailDetails(emailItem) {
      _.forEach(this.emailsList, (itm) => {
        if (itm['_id'] != emailItem['_id']) {
          itm['isSelected'] = false;
        }
        else {
          itm['isSelected'] = !itm['isSelected'];
        }
      })

      this.selectedEmail = null

      let postData = {
        "messageId": emailItem['_id'],
      }

      this.emailLoading = true
      this.isFirstTimeLoading = false
      this.$store.dispatch("getEmailDetails", postData)
        .then((res) => {
          this.selectedEmail = res.data.result
          this.emailLoading = false
          this.isFirstTimeLoading = false
        })
        .catch((error) => {
          this.emailLoading = false
          this.isFirstTimeLoading = false
        })



    },

    getLabelsList() {
      let payLoad = {
        matcher: {
          statusList: [],
          searchString: this.searchtxt
        },
        page: 1,
        perpage: 500,
        //  sorting: this.sortKey,
        today: moment().format('YYYY-MM-DD')
      };
      // this.isListLoading = true;
      //this.updateLoading(true);
      let path = '/message-label/list'
      this.$store.dispatch("getList", { "data": payLoad, "path": path }).then((response) => {
        if (response.list) {
          let list = response.list;
          let tempList = []
          _.forEach(list, (item) => {
            if (!_.has(item, 'id')) {
              item['id'] = item['_id'];
              tempList.push(item)
            }
          })
          if (this.checkProperty(tempList, 'length') > 0) {
            this.labelsList = tempList
          }
        }
      }).catch((err) => {

      })
    },
    openCreateLabel(val) {
      this.labelCreatedForMessage = val;
      this.callFromComponent = true;
      this.addNewLabel(true, true)
    },

    updateLabels(val) {
      let returnVal = val;
      _.map(this.emailsList, (itemI) => {
        if (itemI['_id'] == returnVal['messageId']) {
          itemI['evalLabelIds'] = returnVal['labels']
        }
      })
      this.emailsList = _.cloneDeep(this.emailsList);
      // this.applyFilters()
    },

    addNewLabel(action = false, callfromComp = false) {
      this.selectColor = '';
      this.labelName = '';
      this.formerrors.msg = '';
      if (action) {
        this.$bvModal.show('createLabelFromListModal');
      } else {
        this.$bvModal.hide('createLabelFromListModal');
      }
    },
    createLabel() {
      this.$validator.validateAll('newLabelform').then(result => {
        if (result) {
          let payLoad = {
            name: this.labelName,
            color: this.selectColor,
          }
          this.formerrors.msg = '';
          let path = '/message-label/create';
          this.loadingLabel = true;
          this.$store.dispatch("commonAction", { "data": payLoad, "path": path }).then((response) => {
            this.showToster({ message: response.message, isError: false });
            if (this.callFromComponent && this.labelCreatedForMessage && this.checkProperty(this.labelCreatedForMessage, '_id')) {
              let temp = {
                color: payLoad['color'],
                name: payLoad['name'],
                _id: response._id
              }
              _.map(this.emailsList, (itemI) => {
                if (itemI['_id'] == this.labelCreatedForMessage['_id']) {
                  if (_.has(itemI, 'evalLabelIds') && this.checkProperty(itemI, 'evalLabelIds', 'length') > 0) {
                    itemI['evalLabelIds'].push(temp)
                  } else {
                    itemI['evalLabelIds'] = [];
                    itemI['evalLabelIds'].push(temp)
                  }
                  if (itemI['evalLabelIds'] && this.checkProperty(itemI['evalLabelIds'], 'length') > 0) {
                    let payload = {
                      messageId: this.checkProperty(this.labelCreatedForMessage, '_id'),
                      labels: itemI['evalLabelIds'],
                    }
                    let path = '/mail-inbox/manage-labels'
                    this.$store.dispatch("commonAction", { 'data': payload, 'path': path }).then(response => { }).catch((err) => { })
                  }
                }
              })
              this.emailsList = _.cloneDeep(this.emailsList)
            }
            this.loadingLabel = false;
            this.addNewLabel(false);
            this.getLabelsList();
          }).catch((err) => {
            this.formerrors.msg = err;
            this.loadingLabel = false;
          })
        }
      })
    },


    downloadAllFiles() {
      if (this.checkProperty(this.getDownloadAllFiles, 'length') > 0) {
        this.detailsLoading = true
        this.toggleBodyScrollbar(true)
        let postData = {
          "keyNames": this.getDownloadAllFiles
        }
        this.$store.dispatch("downloadAllFiles", postData)
          .then((response) => {
            this.toggleBodyScrollbar(false)
            this.detailsLoading = false
            if (response.error) {
              this.showToster({ message: response.error.message, isError: true });
            } else {
              const blob = new Blob([response.data], { type: 'application/zip' }); // Corrected this line
              const url = window.URL.createObjectURL(blob); // Changed response to blob
              const a = document.createElement('a');
              a.style.display = 'none';
              a.href = url;
              a.download = this.checkProperty(this.evaluationDetails,
                'requestId') ? this.checkProperty(this.evaluationDetails,
                  'requestId') : Date.now() + '.zip';
              document.body.appendChild(a);
              a.click();
              window.URL.revokeObjectURL(url);
            }

          })
          .catch((error) => {
            this.toggleBodyScrollbar(false)
            this.detailsLoading = false
          })


      }

    },





    // getDateRangeForWeek(weekNumber, year) {
    //   // Calculate the first day of the week
    //   const firstDayOfWeek = startOfWeek(new Date(year, 0, 1)); // January 1st of the specified year

    //   // Add the number of weeks to get to the desired week
    //   const targetWeekStart = addWeeks(firstDayOfWeek, weekNumber - 1);

    //   // Calculate the end of the week (6 days later)
    //   const targetWeekEnd = addWeeks(targetWeekStart, 1);

    //   // Format the dates to your desired format (e.g., YYYY-MM-DD)
    //   const formattedStartDate = format(targetWeekStart, 'yyyy-MM-dd');
    //   const formattedEndDate = format(targetWeekEnd, 'yyyy-MM-dd');

    //   return { start: formattedStartDate, end: formattedEndDate };
    // }




  },
  mounted() {
    this.getEvaluationDetails()

    //  console.log(this.getDateRangeForWeek(32, 2023))


  },
  computed: {
        getEvaluationNames() {
            let evaluationName = ""
            if (this.checkProperty(this.evaluation, 'docsConfig', 'length') > 0) {
                _.forEach(this.checkProperty(this.evaluation, 'docsConfig'), (item, indx) => {

                    if (this.checkProperty(evaluationName, 'length') == 0) {
                        evaluationName = item.evaluationTypeName
                    } else {
                        evaluationName = evaluationName + ", " + item.evaluationTypeName
                    }
                })
            }
            if (this.checkProperty(this.evaluation, 'docsConfig', 'length') == 1) {
                evaluationName = "a <b>" + evaluationName + '</b>'
            } else {
                evaluationName = "<b>" + evaluationName + '</b>'
            }
            return evaluationName

        },
     getEmailContent() {

            return "We have just confirmed a case today for you. This case should be ready for you to review in the next " +
                '<b> ' + "2 " + '</b>' + " business days. The case is for " + '<b> ' + this.checkProperty(this.evaluation, 'beneficiaryInformation', 'firstName')
                + " " + this.checkProperty(this.evaluation, 'beneficiaryInformation', 'lastName') + '</b>' + " and it will be " + this.getEvaluationNames + "." +
                " There is no need to reply to this email as it is simply meant to be an alert on an upcoming case for you to review. However, if for some reason you will not be available for the review, please let us know immediately so we can let the client know and make alternate arrangements." +
                " You may email us back at <a href='eval@carnegieevaluations.com' target='_blank'>eval@carnegieevaluations.com</a> or speak to us at <a href='848-300-0099' target='_blank'>848-300-0099</a>."


            //  return "An upcoming evaluation " + '<b> ' + this.checkProperty(this.evaluation, 'requestId') + '</b>' + " has been assigned to you as part of our ongoing assessment process. This evaluation is a crucial aspect of our commitment to maintaining and enhancing the quality of our academic programs.<br><br> In the next few days, you can expect to receive an email from our evaluation team containing information about the assessment to proceed with the verification process. Your prompt attention to this matter would be greatly appreciated. "
        },
    sortedEvaluationActivityInfoLogs() {
      if (this.checkProperty(this.evaluationDetails, 'evaluationActivityInfoLogs', 'length') > 0) {
        return this.evaluationDetails.evaluationActivityInfoLogs.sort((a, b) => {
          return new Date(b.updatedOn) - new Date(a.updatedOn); // For descending order
          // return new Date(a.updatedOn) - new Date(b.updatedOn); // For ascending order
        });
      }
      return []

    },
    isClientDocsExists() {
      let valid = false
      if (this.checkProperty(this.evaluationDetails, 'docsConfig', 'length') > 0) {
        _.forEach(this.checkProperty(this.evaluationDetails, 'docsConfig'), (item) => {
          if (this.checkProperty(item, 'subTypes', 'length') > 0) {
            _.forEach(item.subTypes, (subItem) => {
              let resultDocs = _.filter(subItem.documents, (docItem) => {
                return this.checkProperty(docItem, 'path', 'length') > 0
              })
              if (this.checkProperty(resultDocs, 'length') > 0) {

                valid = true
              }
            })
          }
        });
      }
      if (!valid && this.checkProperty(this.evaluationDetails, 'supportDocuments', 'length') > 0) {
        valid = true
      }
      return valid
    },

    isEvaluationCanceled() {
      if (this.isActivityCompleted(this.evaluationDetails, 'EVALUATION_REQUEST_CANCELLED')) {
        return true
      }
      return false
    },

    isEvaluationDelivered() {
      if (this.isActivityCompleted(this.evaluationDetails, 'SIGN_APPROVED')
        && (this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('EVALUATION_REQUEST_DELIVERED') == (this.checkProperty(this.evaluationDetails, 'completedActivities', 'length') - 1))) {
        return true
      }
      // if (this.isActivityCompleted(this.evaluationDetails, 'EVALUATION_REQUEST_DELIVERED')) {
      //   return true
      // }
      return false
    },
    checkSaveInvoicePermission() {
      if ([3, 4, 7, 8].indexOf(this.getUserRoleId) > -1 && this.isActivityCompleted(this.evaluationDetails, 'EVALUATION_PROFESSER_ASSIGNED')
        && !this.isEvaluationCanceled && !this.isActivityCompleted(this.evaluationDetails, 'INVOICE_SAVED')) {
        if (this.isActivityCompleted(this.evaluationDetails, 'INVOICE_ISSUED') && !this.isActivityCompleted(this.evaluationDetails, 'INVOICE_SAVED')) {
          return false
        }
        return true
      }

      return false
    },

    isAssignedConsultant() {
      if ([5].indexOf(this.getUserRoleId) > -1) {
        if (Array.isArray(this.checkProperty(this.evaluationDetails, 'assignedToEvaluator'))) {
          if (this.checkProperty(this.evaluationDetails, 'assignedToEvaluator').indexOf(this.checkProperty(this.getUserData, "_id")) > -1) {
            return true
          }
        } else if (this.checkProperty(this.evaluationDetails, 'assignedToEvaluator', "_id") && this.checkProperty(this.evaluationDetails, 'assignedToConsultantDetails', "_id") == this.checkProperty(this.getUserData, "_id")) {
          return true
        }
      }
      return false
    },

    checkEvaluationTemplatePermission() {
      if ([3, 4, 7, 8].indexOf(this.getUserRoleId) > -1
        && [3, 5, 9].indexOf(this.checkProperty(this.evaluationDetails, 'statusDetails', 'id')) > -1
        && (this.checkProperty(this.evaluationDetails, 'generatedDocuments', 'length') == 0
          && this.checkProperty(this.evaluationDetails, 'evaluationDocuments', 'length') == 0)
        && !this.isEvaluationCanceled) {
        return true
      }

      return false
    },
    canShowNotes() {
      if (this.getUserRoleId == 9 && this.getUserRoleId == 15) {
        return false
      }

      // if ([3, 4, 7, 8].indexOf(this.getUserRoleId) < 0 && !this.checkProperty(this.evaluationDetails, 'carnegieNote')
      //   && (!this.isActivityCompleted(this.evaluationDetails, 'SIGN_APPROVED')
      //     || (this.isActivityCompleted(this.evaluationDetails, 'SIGN_APPROVED') && (this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('EVALUATION_REQUEST_DELIVERED') == (this.checkProperty(this.evaluationDetails, 'completedActivities', 'length') - 1))))) {
      //   return false
      // }



      if (this.checkProperty(this.evaluationDetails, 'carnegieNote', 'length') == 0
        && this.isEvaluationDelivered) {
        return false
      }

      if (([3, 4, 6, 8].indexOf(this.getUserRoleId) < 0 && this.checkProperty(this.evaluationDetails, 'carnegieNote', 'length') > 0)
        || [3, 4, 6, 8].indexOf(this.getUserRoleId) > -1) {
        return true
      }
      return false
    },


    getAlternateEmails() {
      let altEmailStr = ""
      if (this.checkProperty(this.evaluationDetails, 'altEmailsList', 'length') > 0) {
        this.checkProperty(this.evaluationDetails, 'altEmailsList').forEach((item, index) => {
          if (index == 0) {
            altEmailStr = item.email
          } else {
            altEmailStr = altEmailStr + "," + item.email
          }
        });
      } else if (this.checkProperty(this.evaluationDetails, 'alternateEmail')) {
        altEmailStr = this.checkProperty(this.evaluationDetails, 'alternateEmail')
      }
      return altEmailStr
    },
    isAltEmailValid() {
      this.altEmailsList = []
      let isAlternateEmailValid = true
      const validateEmail = (email) => {
        return String(email)
          .toLowerCase()
          .trim()
          .match(
            /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
          );
      };
      if (this.checkProperty(this.alternateEmails, 'length') > 0) {
        let emailsArray = this.alternateEmails.split(",")
        console.log("emailsArray" + emailsArray)
        if (emailsArray.length > 0) {
          _.forEach(emailsArray, (item) => {
            let splitEmails = item.split("<")
            //  console.log("splitEmails" + splitEmails)
            if (splitEmails.length > 1) {
              let resultEmail = splitEmails[1].replace(">", "")
              if (!validateEmail(resultEmail.trim())) {
                isAlternateEmailValid = false
              } else {
                let emailObj = { 'name': splitEmails[0].trim(), 'email': resultEmail.trim() }
                this.altEmailsList.push(emailObj)
              }
              // console.log("resultEmail" + resultEmail)
            } else if (splitEmails.length > 0) {
              let resultEmail = splitEmails[0]
              if (!validateEmail(resultEmail.trim())) {
                isAlternateEmailValid = false
              } else {
                let emailObj = { 'name': '', 'email': resultEmail.trim() }
                this.altEmailsList.push(emailObj)
              }
              //  console.log("resultEmail" + resultEmail)
            } else {
              isAlternateEmailValid = false
            }
          })
        }
      }
      return isAlternateEmailValid
    },
    getDownloadAllFiles() {
      let keyNames = []
      if (this.checkProperty(this.evaluationDetails, 'docsConfig', 'length') > 0) {
        _.forEach(this.checkProperty(this.evaluationDetails, 'docsConfig'), (item) => {
          if (this.checkProperty(item, 'subTypes', 'length') > 0) {
            _.forEach(item.subTypes, (subItem) => {
              let resultDocs = _.filter(subItem.documents, (docItem) => {
                return this.checkProperty(docItem, 'path', 'length') > 0
              })
              if (this.checkProperty(resultDocs, 'length') > 0) {
                keyNames = [...keyNames, ...resultDocs.map((item) => item.path)]
              }
            })
          }
        });
      }
      if (this.checkProperty(this.evaluationDetails, 'supportDocuments', 'length') > 0) {
        let resultDocs = _.filter(this.checkProperty(this.evaluationDetails, 'supportDocuments'), (docItem) => {
          return this.checkProperty(docItem, 'path', 'length') > 0
        })
        if (this.checkProperty(resultDocs, 'length') > 0) {
          keyNames = [...keyNames, ...resultDocs.map((item) => item.path)]
        }
      }
      return keyNames
    },
    checkEvalRevisionPremissions() {
      if ([3, 4, 7, 8].indexOf(this.getUserRoleId) > -1 && !this.isEvaluationCanceled) {
        if ([13].indexOf(this.checkProperty(this.evaluationDetails, 'statusDetails', 'id')) > -1) {
          return true
        }
        else if ([15, 16].indexOf(this.checkProperty(this.evaluationDetails, 'statusDetails', 'id')) > -1
          && !this.isActivityCompleted(this.evaluationDetails, 'SIGN_APPROVED')
          && (this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('SENT_FOR_REVISION') > this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('SIGN_REQUESTED'))) {
          return true
        }
      }
      return false
    },

    checkEvalFinalReviewPremissions() {
      if ([3, 4, 7, 8].indexOf(this.getUserRoleId) > -1 && !this.isEvaluationCanceled && this.checkProperty(this.evaluationDetails, 'statusDetails', 'id') > 9) {
        if (!this.isActivityCompleted(this.evaluationDetails, 'EVALUATION_REVISED_DOCUMENTS_UPDATED')) {
          return true
        }
        else if (!this.isActivityCompleted(this.evaluationDetails, 'SIGN_APPROVED') || (
          this.isActivityCompleted(this.evaluationDetails, 'SIGN_APPROVED')
          && ((this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('SIGN_APPROVED') > this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('EVALUATION_REVISED_DOCUMENTS_UPDATED'))))) {
          return true
        }
      }
      return false
    },


    checkEvalDeliveryPremissions() {
      if ([3, 4, 7, 8].indexOf(this.getUserRoleId) > -1 && !this.isEvaluationCanceled && this.isActivityCompleted(this.evaluationDetails, 'EVALUATION_REVISED_DOCUMENTS_UPDATED')) {
        if (!this.isActivityCompleted(this.evaluationDetails, 'EVALUATION_REQUEST_DELIVERED')) {
          return true
        }
        else if (!this.isActivityCompleted(this.evaluationDetails, 'SIGN_APPROVED') || (
          this.isActivityCompleted(this.evaluationDetails, 'SIGN_APPROVED')
          && ((this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('SIGN_APPROVED') > this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('EVALUATION_REQUEST_DELIVERED'))))) {
          return true
        }


        // else if (this.isActivityCompleted(this.evaluationDetails, 'SIGN_APPROVED')
        //   && (this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('SIGN_APPROVED') > this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('EVALUATION_REQUEST_DELIVERED'))) {
        //   return true
        // }
        // else if (this.isActivityCompleted(this.evaluationDetails, 'SIGN_APPROVED')
        //   && (this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('EVALUATION_REVISED_DOCUMENTS_UPDATED') > this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('EVALUATION_REQUEST_DELIVERED'))) {
        //   return true
        // }
        // else if (this.isActivityCompleted(this.evaluationDetails, 'SENT_FOR_REVISION')
        //   && (this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('EVALUATION_REVISED_DOCUMENTS_UPDATED') > this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('EVALUATION_REQUEST_DELIVERED'))) {
        //   return true
        // }
        // else if (this.isActivityCompleted(this.evaluationDetails, 'SIGN_REQUESTED')
        //   && (this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('EVALUATION_REVISED_DOCUMENTS_UPDATED') > this.checkProperty(this.evaluationDetails, 'completedActivities').lastIndexOf('EVALUATION_REQUEST_DELIVERED'))) {
        //   return true
        // }


      }
      return false
    },

    getClientDocumentsCount(){
      let docsCount = 0
      if (this.checkProperty(this.evaluationDetails, 'docsConfig', 'length') > 0) {
        _.forEach(this.checkProperty(this.evaluationDetails, 'docsConfig'), (item) => {
          if (this.checkProperty(item, 'subTypes', 'length') > 0) {
            _.forEach(item.subTypes, (subItem) => {
              let resultDocs = _.filter(subItem.documents, (docItem) => {
                return this.checkProperty(docItem, 'path', 'length') > 0
              })
              if (this.checkProperty(resultDocs, 'length') > 0) {
                docsCount=docsCount+this.checkProperty(resultDocs, 'length')
              }
            })
          }
        });
      }
      if (this.checkProperty(this.evaluationDetails, 'supportDocuments', 'length') > 0) {
        docsCount=docsCount+this.checkProperty(this.evaluationDetails, 'supportDocuments', 'length')
      }
      return docsCount
    },

  },
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
}
</script>