<template>
  <div class="db_page">
    <!-- <div class="page_header">
      <h3>Email Templates</h3>
    </div> -->
    <div class="filter_sec">
      <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" />

      <simpleSelect :multiple="true" :wrapclass="'req_status'" :optionslist="statusList" :display="true"
        :place-holder="'Status'" :searchable="false" :required="false" :close-on-select="false" :clear-on-select="true"
        v-model="filterSelectedStatuses" :fieldName="'filterStatus'" :cid="'filterStatus'" :hideSelected="true"
        @input="applyFilters" :listContainsId="true" />
      <simpleSelect v-if="false" :multiple="true" :wrapclass="'req_status'" :optionslist="filterEmailTypes" :display="true"
        :place-holder="'Type'" :searchable="false" :required="false" :close-on-select="false" :clear-on-select="true"
        v-model="filterSelectedEmailTypes" :fieldName="'filterTemplateType'" :cid="'filterTemplateType'"
        :hideSelected="true" @input="applyFilters" :listContainsId="true" />

      <button class="filter_btn" v-if="false"><span></span><em>Filters</em></button>
      <div class="filters_right">
        <button class="add_btn" @click="showAddTemplatePopup(false)"><span></span><em>Create Template</em></button>
      </div>
    </div>
    <div class="table-responsive">
      <template v-if="checkProperty(emailsList, 'length') <= 0">
        <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Emails' :loading="isListLoading" />
      </template>
      <table class="table" v-if="checkProperty(emailsList, 'length') > 0 && !isListLoading">
        <thead>
          <tr>
            <th>Template ID #</th>
            <th>Title</th>
            <th>Content</th>
            <!-- <th>Type</th> -->
            <th>Created Date</th>
            <th class="center">Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>


          <tr v-for="(item, index) in emailsList" v-bind:key="index">
            <td>
              <span>{{ checkProperty(item, 'requestId') }}</span>
            </td>
            <td>
              <span>{{ checkProperty(item, 'title') }}</span>
            </td>
            <td>
              <span>
                <p class="desc" v-html="checkProperty(item, 'content')"></p>
              </span>
            </td>
            <!-- <td><span>{{ checkProperty(item, 'typeDetails', 'name') }}</span></td> -->
            <td><span>{{ checkProperty(item, 'createdOn') | formatDate }}</span></td>
            <td class="center"><span class="status " v-bind:class="{
              'active': checkProperty(item, 'statusDetails', 'id') == 1,
              'inactive': checkProperty(item, 'statusDetails', 'id') == 2,
            }">{{ checkProperty(item, 'statusDetails', 'name') }}</span>
            </td>
            <td>
              <div class="actions">
                <dropdownHover>
                  <b-dropdown-item v-if="checkProperty(item, 'statusId') == 1"
                    @click="showDetailsPopup(item)">View</b-dropdown-item>
                  <b-dropdown-item @click="selectedTemplate = item; showAddTemplatePopup(true)">Edit</b-dropdown-item>
                  <b-dropdown-item @click="selectedTemplate = item; showStatusChangePopup = true">{{
                    checkProperty(item, 'statusId') == 1
                    ? 'Inactivate' : 'Activate'
                  }}</b-dropdown-item>
                </dropdownHover>
              </div>
            </td>
          </tr>

        </tbody>
      </table>
      <div class="pagination-sec" v-if="checkProperty(emailsList, 'length') > 0">
        <div class="per-page">
          <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) +
            emailsList.length) +
            ' of ' + totalCount + ' Results' }}</label>
        </div>
        <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
          @input="getEmailsList"></b-pagination>
      </div>
    </div>

    <!-- Create Template Modal -->
    <b-modal v-model="showAddTemplate" id="create_template" dialog-class="create_template" centered no-close-on-backdrop>
      <template #modal-header>
        <h6 class="modal-title">{{ isTemplateEdit ? 'Edit Template' : 'Create Template' }}</h6>
        <a class="close" @click="showAddTemplate = false"></a>
      </template>
      <template>
        <div class="user_form">
          <div class="row">
            <div class="col-md-6" v-if="false">
              <!-- <simpleInput :wrapclass="'mb20'" :label="'Title/Designation'" /> -->

              <simpleSelect :label="'Template Type'" :multiple="false" :wrapclass="'mb20'" :optionslist="templateTypeList"
                :display="true" :place-holder="'Select Type'"  :vvas="'Template Type'" :searchable="false" :required="true" :close-on-select="true"
                :clear-on-select="true" v-model="templateType" :fieldName="'templateType'" :cid="'templateType'" />
            </div>
            <div class="col-md-12">
              <simpleInput :wrapclass="'mb20'" :fieldName="'title'" :cid="'title'" :label="'Title'" :placeHolder="'Title'"
                :vvas="'Title'" :display="true" :required="true" v-model="templateTitle" />
            </div>
            <div class="col-md-12">
              <textArea :label="'Content'" :wrapclass="'h80 mb10'" placeHolder="Content" v-model="templateContent"
                :required="true" :fieldName="'emailContent'" :cid="'emailContent'"></textArea>
            </div>
          </div>
        </div>
      </template>
      <template #modal-footer>

        <button class="form-cancel" @click="showAddTemplate = false">Cancel</button>
        <button class="primary_btn md" @click="submitEmailTemplate">{{ isTemplateEdit ? 'Update' : 'Create' }}
          <span class="loader" v-if="isLoading"><img src="@/assets/images/loader.gif"></span>
        </button>
      </template>
    </b-modal>

    <!-- active inactive Modal -->
    <b-modal v-model="showStatusChangePopup" id="active_inactive_model" dialog-class="active_inactive_model" centered
      no-close-on-backdrop>
      <template #modal-header>
        <h6 class="modal-title">
          {{ checkProperty(selectedTemplate, 'statusId') == 1 ? 'Inactivate' : 'Activate' }}
        </h6>
        <a class="close" @click="showStatusChangePopup = false"></a>
      </template>
      <template>
        <p class="confirm_msg">Do you want to {{ checkProperty(selectedTemplate, 'statusId') == 1 ? "Inactivate the template" :
        "Activate the template" }}?</p>
      </template>
      <template #modal-footer>
        <button class="form-cancel" @click="showStatusChangePopup = false">No</button>
        <button class="primary_btn" @click="changeStatus">Yes</button>
      </template>
    </b-modal>

    <!-- Details Modal -->
    <b-modal v-model="showTemplateDetails" id="create_template" dialog-class="create_template email_model" centered
      hide-footer no-close-on-backdrop>
      <template #modal-header>
        <h6 class="modal-title">{{ isTemplateEdit ? 'View Template' : 'View Template' }}</h6>
        <a class="close" @click="showTemplateDetails = false"></a>
      </template>
      <template>
        <div class="row">
          <div class="col-md-12">
            <div class="form_group" v-if="checkProperty(selectedTemplate, 'title')">
              <lable class="form_label">Title</lable>
              <p>{{ checkProperty(selectedTemplate, 'title') }}</p>
            </div>
          </div>
          <div class="col-md-12">
            <div class="form_group email_template" v-if="checkProperty(selectedTemplate, 'content')">
              <lable class="form_label">Content</lable>
              <p v-html="checkProperty(selectedTemplate, 'content')"></p>
            </div>
          </div>
        </div>
      </template>
    </b-modal>


  </div>
</template>

<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import dropdownHover from '@/views/forms/dropdownHover.vue';
import textArea from "@/views/forms/textarea.vue";
import NoDataFound from "@/views/common/noData.vue";
export default {
  name: 'emailtemplate-view',
  components: {
    searchInput,
    simpleSelect,
    dropdownHover,
    simpleInput,
    textArea,
    NoDataFound
  },
  data: () => ({
    page: 1,
    perpage: 20,
    totalCount: 0,
    templateTypeList: [],
    templateType: null,
    templateTitle: '',
    templateContent: '',
    showAddTemplate: false,
    isLoading: false,
    emailsList: [],
    statusList: [],
    filterEmailTypes: [],
    filterSelectedStatuses: [],
    filterSelectedEmailTypes: [],
    filterSearch: '',
    selectedTemplate: null,
    isTemplateEdit: false,
    showStatusChangePopup: false,
    showTemplateDetails: false,
  }),
  methods: {
    gotoPage(path = "/") {
      this.$router.push(path);
    },
    getMasterDataList(category) {
      this.$store.dispatch("getMasterData", category)
        .then((res) => {
          if (category == 'email_template_types') {
            this.templateTypeList = [...res]
            this.filterEmailTypes = [...res]
          }
          if (category == 'email_template_status') {
            this.statusList = [...res]
          }
        })
    },
    showAddTemplatePopup(isEdit = false) {
      this.templateType = null
      this.templateTitle = ''
      this.templateContent = ''
      this.isLoading = false
      this.isTemplateEdit = false
      if (isEdit) {
        this.isTemplateEdit = true
        this.templateType = this.selectedTemplate.typeDetails
        this.templateTitle = this.selectedTemplate.title
        this.templateContent = this.selectedTemplate.content
      }
      this.showAddTemplate = true
    },
    submitEmailTemplate() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          this.isLoading = true
          let postData = {
            "title": this.templateTitle,
            "content": this.templateContent,
            "typeId": null
          }
          if (this.checkProperty(this.templateType, "id")) {
            postData.typeId = this.checkProperty(this.templateType, "id")
          }

          if (this.isTemplateEdit) {
            postData.emailTempId = this.selectedTemplate._id
          }

          if (this.isTemplateEdit) {
            this.$store
              .dispatch("updateEmailTemplate", postData)
              .then((response) => {
                if (response.error) {
                  this.isLoading = false
                  this.showToster({ message: response.error.message, isError: true });
                } else {
                  this.isTemplateEdit = false
                  this.isLoading = false
                  this.showToster({ message: response.message, isError: false });
                  this.page = 1
                  this.getEmailsList()
                  this.showAddTemplate = false
                }
              })
              .catch((error) => {
                this.isLoading = false
                this.showToster({ message: error, isError: true });
              });

          } else {
            this.$store
              .dispatch("addEmailTemplate", postData)
              .then((response) => {
                if (response.error) {
                  this.isLoading = false
                  this.showToster({ message: response.error.message, isError: true });
                } else {
                  this.isLoading = false
                  this.showToster({ message: response.message, isError: false });
                  this.page = 1
                  this.getEmailsList()
                  this.showAddTemplate = false
                }
              })
              .catch((error) => {
                this.isLoading = false
                this.showToster({ message: error, isError: true });
              });
          }


        }
      })
    },
    getEmailsList() {

      let statusIds = []
      let typeIds = []
      if (this.filterSelectedStatuses && this.checkProperty(this.filterSelectedStatuses, 'length') > 0) {
        statusIds = this.filterSelectedStatuses.map((item) => item.id)
      }
      if (this.filterSelectedEmailTypes && this.checkProperty(this.filterSelectedEmailTypes, 'length') > 0) {
        typeIds = this.filterSelectedEmailTypes.map((item) => item.id)
      }
      let postData = {
        "matcher": {
          "title": this.filterSearch,
          "statusIds": statusIds,
          "typeIds": typeIds,
          "createdByIds": [],
          "createdDateRange": []
        },
        "sorting": {
          "path": "createdOn", //title, statusName, createdByName, updatedOn, 
          "order": -1
        },
        "page": this.page,
        "perpage": this.perpage
      }


      this.$store.dispatch("getEmailsList", postData)
        .then((res) => {
          this.emailsList = res.data.result.list
          if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
            this.totalCount = this.checkProperty(res.data.result, 'totalCount');
          }
          this.isListLoading = false
          setTimeout(() => {
            this.updateLoading(false);
          })
        })
        .catch((error) => {
          this.isListLoading = false
          setTimeout(() => {
            this.updateLoading(false);
          })
        })

    },
    applyFilters() {
      this.isListLoading = true
      this.updateLoading(true);
      this.page = 1
      this.getEmailsList()
    },
    applySearchFilters() {
      this.isListLoading = true
      this.updateLoading(true);
      this.page = 1
      if (this.filterSearch && this.filterSearch.length > 2) {
        this.getEmailsList()
      }
      if (this.filterSearch == '') {
        this.getEmailsList()
      }
    },
    changeStatus() {

      this.showLoader = true;
      let payload = {
        "emailTempId": "",
        "statusId": 2, // 3. Inactive, 4.Delete
        "comment": ''
      }
      payload['emailTempId'] = this.selectedTemplate['_id'];
      if ([1].indexOf(this.selectedTemplate.statusId) > -1) {
        payload['statusId'] = 2
      } else {
        payload['statusId'] = 1
      }
      this.$store.dispatch("commonAction", { data: payload, path: "email-template/update-status", })
        .then((response) => {
          this.showToster({ message: response.message, isError: false })
          this.showLoader = false;
          this.showStatusChangePopup = false;
          this.applyFilters();

        }).catch((error) => {
          this.showToster({ message: error.message, isError: true })
          this.showLoader = false;
          this.showStatusChangePopup = false

        });

    },

    showDetailsPopup(emailTemplate) {
      this.selectedTemplate = emailTemplate
      this.showTemplateDetails = true


    },
  },
  mounted() {
    this.getMasterDataList('email_template_types')
    this.getMasterDataList('email_template_status')
    this.isListLoading = true
    this.updateLoading(true);
    this.getEmailsList()
  },
  computed: {

  },
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },

}
</script>