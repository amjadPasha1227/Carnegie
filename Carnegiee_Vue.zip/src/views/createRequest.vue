<template>
  <div class="create_req_page" id="scrollableques">
    <!-- <div class="page_header">
      <a @click="gotoPage('/evaluations-list')"><img src="@/assets/images/left-chevron.svg" alt=""></a>
      <h5>Create Request</h5>
    </div>  -->
    <div>
      <EvaluationRequest :showHeaderTitle="false" @input="afterEvaluationCreated" />
    </div>

    <!-- Success Modal -->
    <b-modal id="success_model" dialog-class="success_model" centered hide-header hide-footer no-close-on-backdrop>
      <template>
        <figure>
          <img src="@/assets/images/success_mdl_img.png" />
        </figure>
        <h5>Your Request has been Received!</h5>
        <p>You will get notification shortly for selecting your professor</p>
        <a class="primary_btn sm" @click="$bvModal.hide('success_model')">Ok!</a>
      </template>
    </b-modal>
  </div>
</template>

<script>
// @ is an alias to /src

import JQuery from "jquery";
import simpleInput from "@/views/forms/simpleInput.vue";
import fileUpload from "@/views/forms/fileupload.vue";
import radioInput from "@/views/forms/radioInput.vue";
import EvaluationRequest from "@/views/evaluationRequest.vue";
export default {
  name: 'create-evaluation',
  components: {
    simpleInput,
    fileUpload,
    radioInput,
    EvaluationRequest,
  },
  mounted() {
   // $('body').addClass('questionnairetpl')
 //   document.body.className += 'questionnairetpl'


  },
  // beforeDestroy() {
  //   const $ = JQuery;
  //   document.removeEventListener("click", this.reloadthePage);
  //   $('body').removeClass('questionnairetpl')
  // },
  methods: {
    gotoPage(path = "/") {
      this.$router.push(path);
    },
    afterEvaluationCreated() {
      this.gotoPage('/evaluations-list')
    },
  },
  data: () => ({
    proceedImmediately: false,

  })
}
</script>