<template>
    <div>
        <div class="profile_details_mail">
            <div class="profile_header">
                <div class="profile_title">
                    <h6 v-if="checkProperty(selectedUser, 'name')">{{ checkProperty(selectedUser, 'name') }}</h6>
                    <!-- <p v-if="checkProperty(selectedUser, 'roleName')">{{ checkProperty(selectedUser, 'roleName') }}</p> -->
                    <span v-if="checkProperty(selectedUser, 'details', 'designation')">{{ checkProperty(selectedUser,
                        'details',
                        'designation') }}</span>
                </div>
            </div>
            <div class="profile_info">
                <ul>
                    <!-- <li v-if="checkProperty(selectedUser, 'details', 'email')">
                        <span class="info_header">Email</span>
                        <p class="desc">{{ checkProperty(selectedUser, 'details', 'email') }}</p>
                    </li> -->
                    <!-- <li v-if="checkProperty(selectedUser, 'details', 'phone')">
                        <span class="info_header">Phone</span>
                        <p class="desc">
                            {{ checkProperty(selectedUser.details, 'phoneCountryCode', 'countryCallingCode') |
                                countryFormatter }}
                            {{ checkProperty(selectedUser, 'details', 'phone') | formatPhone }}
                        </p>
                    </li> -->
                    <!-- <li v-if="checkProperty(selectedUser, 'details', 'userName')">
                        <span class="info_header">Username</span>
                        <p class="desc">{{ checkProperty(selectedUser, 'details', 'userName') }}</p>
                    </li> -->
                    <li v-if="checkProperty(selectedUser, 'departmentDetails', 'name')">
                        <span class="info_header">Department</span>
                        <p class="desc">{{ checkProperty(selectedUser, 'departmentDetails', 'name') }}</p>
                    </li>
                    <li v-if="checkProperty(selectedUser, 'details', 'profileURL')">
                        <span class="info_header">Profile URL</span>
                        <a href="#" class="link">{{ checkProperty(selectedUser, 'details', 'profileURL') }}</a>
                    </li>
                    <!-- <li
                        v-if="checkProperty(selectedUser, 'details', 'letterHead') && checkProperty(selectedUser['details'], 'letterHead', 'length') > 0">
                        <span class="info_header">Copy of letterhead</span>
                        <DocumentsPreview :type="'documents'"
                            :documentsList="checkProperty(selectedUser, 'details', 'letterHead')"
                            :includeDownloadText="false" @download_or_view="download_or_view" />
                    </li> -->
                    <li v-if="(checkProperty(selectedUser, 'details', 'bioAndResume') || (checkProperty(selectedUser, 'details', 'documents') && checkProperty(selectedUser['details'], 'documents', 'length') > 0))"
                        class="bio_resume">
                        <span class="info_header">Bio/Resume</span>
                        <p v-if="checkProperty(selectedUser, 'details', 'bioAndResume')"
                            v-html="checkProperty(selectedUser, 'details', 'bioAndResume')"></p>
                        <div
                            v-if="checkProperty(selectedUser, 'details', 'documents') && checkProperty(selectedUser['details'], 'documents', 'length') > 0">
                            <DocumentsPreview :type="'documents'"
                                :documentsList="checkProperty(selectedUser, 'details', 'documents')"
                                :includeDownloadText="false" :auth="false"  @download_or_view="download_or_view" />
                        </div>

                        <!-- <div v-if="checkProperty(selectedUser, 'details', 'bioAndResume')" class="download_sec">
                <img src="@/assets/images/pdf-file-format.svg">
                <a href="#" class="link_btn">Download</a>
              </div> -->
                    </li>
                </ul>
            </div>
        </div>
        <b-modal id="preview_model" v-model="docPrivew" dialog-class="document_modal"
            :title="checkProperty(selectedFile, 'name')">
            <h2> <img :class="{
                pdf_view_download: docType == 'pdf',
                office_view_download: docType == 'office',
                image_view_download: docType == 'image',
            }" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>
            <div class="pdf_loader">
                <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/loader.gif" /></figure>

                <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
                <template v-if="docType == 'office'">
                    <div style="height:90vh">

                        <div id="placeholder" style="height:100%"></div>
                    </div>
                </template>
                <template v-else-if="docType == 'image'">
                    <img :src="docValue" />
                </template>
                <template v-else-if="docType == 'pdf'">
                    <div class="pdf" style="height:90vh">

                        <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%"
                            width="100%">

                        </iframe>
                    </div>
                </template>
            </div>
        </b-modal>
    </div>
</template>
    
<script>
import DocumentsPreview from '@/views/common/documentsPreview.vue';

export default {

    components: {
        DocumentsPreview,

    },
    data() {
        return {
            selectedUser: null,
            docPrivew: false,
            docType: '',
            formSubmited: false,
            docPrivew: false,
            docType: '',
            selectedFile: null,
        }
    },
    mounted() {
        this.getProfessorDetails()
    },
    methods: {
        getProfessorDetails() {
            let postData =
            {
                "userId": this.$route.params.itemId
            }
            this.$store.dispatch("getProfDetails", postData)
                .then((res) => {
                    this.selectedUser = res.result
                })
                .catch((error) => {

                })
        },
        download_or_view(docItem) {


            let value = _.cloneDeep(docItem);
            var _self = this;
            value["authRequired"] = false;
            this.formSubmited = false;
            if (_.has(value, "path")) {
                value["url"] = value["path"];
                value["document"] = value["path"];
            }

            if (_.has(value, "url")) {
                value["path"] = value["url"];
                value["document"] = value["url"];
            }

            if (_.has(value, "document")) {
                value["path"] = value["document"];
                value["url"] = value["document"];
            }
            this.selectedFile = value;
            this.docValue = "";
            this.docPrivew = false;
            this.docType = false;
            this.docType = this.findmsDoctype(value["name"], value.mimetype);

            if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
                //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
                value.url = value.url.replace(this.$globalgonfig._S3URL, "");
                value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
                let postdata = {
                    keyName: value.url,
                    // "petitionId": value['petitionId'],

                    // entityType:value['petitionId']
                    "fileName": value.name ? value.name : ''
                };
                // if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
                //   postdata['entityType'] = 'perm'
                // } else {
                //   postdata['entityType'] = 'case'
                // }


                this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                    this.docValue = response.data.result.data;


                    if (this.docType == "office") {
                        this.docPrivew = true;
                        setTimeout(() => {
                            document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
                            let _editing = false;

                            // if ([3, 4].indexOf(this.getUserRoleId) > -1) {
                            //   _editing = false;
                            // }

                            // if (value.viewmode) {
                            //   _editing = false;
                            // }
                            var _ob = {}
                            // if (value.editedDocument) {
                            //   _ob = {

                            //     evaluationId: this.evaluationDetails._id,
                            //     name: value.name,
                            //     _id: value._id,
                            //     "extn": "docx",
                            //     "formLetterType": "Letter",
                            //     parentId: value.parentId
                            //   }

                            // } else {

                            _ob = {

                                name: value.name,
                                evaluationId: this.evaluationDetails._id,
                                _id: value._id,
                                "extn": "docx",
                                "formLetterType": "Letter",
                                parentId: value._id

                            }

                            //  }


                            window.docEditor = new DocsAPI.DocEditor("placeholder2",
                                {

                                    "document": {
                                        "c": "forcesave",
                                        "fileType": "docx",
                                        "key": value._id,
                                        "userdata": JSON.stringify(_ob),
                                        "title": value.name,
                                        "url": response.data.result.data,
                                        permissions: {
                                            edit: _editing,
                                            download: true,
                                            reader: false,
                                            review: false,
                                            comment: false
                                        }
                                    },

                                    "documentType": "word",
                                    "height": "100%",
                                    "width": "100%",

                                    "editorConfig": {
                                        "userdata": JSON.stringify(_ob),
                                        "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                                        "customization": {
                                            "logo": {
                                                "image": "https://immibox.com/app/favicon.png",
                                                "imageDark": "https://immibox.com/app/favicon.png",
                                                "url": "https://immibox.com"
                                            },
                                            "anonymous": {
                                                "request": false,
                                                "label": "Guest"
                                            },
                                            "chat": false,
                                            "comments": false,
                                            "compactHeader": false,
                                            "compactToolbar": true,
                                            "compatibleFeatures": false,
                                            "feedback": {
                                                "visible": false
                                            },
                                            "forcesave": true,
                                            "help": false,
                                            "hideNotes": true,
                                            "hideRightMenu": true,
                                            "hideRulers": true,
                                            layout: {
                                                toolbar: {
                                                    "collaboration": false,
                                                },
                                            },
                                            "macros": false,
                                            "macrosMode": "warn",
                                            "mentionShare": false,
                                            "plugins": false,
                                            "spellcheck": false,
                                            "toolbarHideFileName": true,
                                            "toolbarNoTabs": true,
                                            "uiTheme": "theme-light",
                                            "unit": "cm",
                                            "zoom": 100
                                        },
                                    }, events: {
                                        onReady: function () {

                                        },
                                        onDocumentStateChange: function (event) {
                                            var url = event.data;
                                            console.log(event)

                                            if (!event.data) {

                                                if (value.editedDocument) {

                                                }

                                            }
                                        }

                                    }
                                });
                            //this.docValue = encodeURIComponent(response.data.result.data);
                        }, 100)
                    }

                    if (this.docType == "pdf") {

                        // this.downloadFile(this.docValue, value.mimetype, value.name)

                        // return
                        var _vid = value._id;
                        if (value.parentId) {
                            _vid = value.parentId;
                        }
                        var viewmode = 1; // Enable edit
                        viewmode = 0; //Disabled Edit
                        if (value.viewmode) {
                            viewmode = 0;
                        }
                        this.docValue = "https://carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
                        console.log(this.docValue)
                        this.docPrivew = true;
                    }
                    if (this.docType == "image") {
                        this.docPrivew = true;
                    }



                });
            } else {



                this.downloads3file(value);
            }

        },
    }

};
</script>
    