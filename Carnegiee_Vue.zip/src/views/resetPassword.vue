<template>
    <div class="login_area">
        <div class="login_sec reset_password_sec">
            <div class="logo">
                <img src="@/assets/images/logo_carne.png">
            </div>
            <h5 v-if="showMe">{{ title }}</h5>

            <div class="text-danger text-sm formerrors mb-3" v-show="formerrors.msg">
                <span v-if="errorCode == 'NOT_VERIFIED'">
                    You haven't set up the password. Please check your email and
                    set up the password. Not received the email.?
                    <router-link color="primary" to="/resend-link">Request again</router-link>
                </span>
                <div v-else class="text-danger text-sm formerrors mb-3">

                    <span class="text-center d-block" v-html="checkProperty(formerrors, 'msg')"></span>
                    <div v-if="!checkProperty(formerrors, 'msg').includes('previous 3 passwords')">
                        <p v-if="showResendLink"><router-link to="/forgot-password">Request again</router-link></p>
                        <p v-else class="signup_text "> Back to <router-link to="/login">Login In</router-link> </p>
                    </div>
                </div>
                <!--<p class="signup_text " > Back to <router-link to="/login">Sign In</router-link> </p>-->
            </div>

            <template v-if="showMe">
                <div class="form_group mb20">
                    <label>New Password</label>
                    <!-- <input type="text" class="form-control" placeholder=""> -->
                    <input ref="password" v-validate="'required|min:5|strongpassword'" :data-vv-as="'New Password'"
                        v-model="password" :type="'password'" class="form-control" placeholder="New Password" id="inputPassword"
                        name="password" />
                    <span v-show="errors.has('password')" class="form-error">
                        {{ errors.first("password") }}
                    </span>
                </div>
                <div class="form_group mb20 pt-2">
                    <label>Confirm Password</label>
                    <!-- <input type="text" class="form-control" placeholder=""> -->
                    <input v-validate="'required|confirmed:password'" :data-vv-as="'Confirm Password'"
                        v-model="conformPassword" :type="showPassword ? 'text' : 'password'" class="form-control eye"
                        placeholder="Confirm Password" id="inputPassword" name="cpassword" />


                    <span v-show="errors.has('cpassword')" class="form-error">
                        {{ errors.first("cpassword") }}
                    </span>
                </div>
                <button class="login_btn crt_btn" @click="updatePassword">Submit
                    <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
                <p>Back to <a @click="gotoPage('/login')" class="create_link" data-bs-toggle="modal"
                        data-bs-target="#login_reg_modal">Log In</a></p>
            </template>
        </div>
        <!-- <div class="guest_sec">
            <h6>Request an Evaluation as a Guest</h6>
            <a @click="gotoPage('/guest-request')" class="proceed_btn">Proceed</a>
        </div> -->
    </div>
</template>
<script>

import moment from "moment";
import { CheckCircleIcon } from "vue-feather-icons";
export default {
    name: "ResetPassword",
    provide() {
        return {

        };
    },
    data: () => ({
        password: '',
        conformPassword: '',
        showPassword: false,
        showCPassword: false,
        title: 'Set Password',
        showResendLink: false,
        showMe: false,
        errorCode: '',
        formerrors: {
            msg: "",
        },
        formmessage: {
            msg: "",
        },
        user: {
            email: "",
            password: "",

        },
        loading: false,
    }),
    components: {

    },
    methods: {
        goTopage(action, useData) {
            //this.$router.go("/");
            let self = this;
            const host = window.location.host;
            let protocol = location.protocol;
            let site = protocol + "//" + host;

            let href = window.location.href;
            let result = href.includes(site + "/app");
            if (result) {
                site = site + "/app";
            }

            // window.location =site+"/dashboard";

            if (action == "set-password" &&
                [51].indexOf(this.checkProperty(useData, 'roleId')) > -1
                && this.checkProperty(useData, 'capCaseCount')
                && useData.capCaseCount > 0) {
                this.$router.push("/cap-registrations");
            } else {
                this.$router.push("/");
            }
            //  self.$router.push("/");


            //   setTimeout(function(){
            //    self.$router.push("/dashboard").catch((err) => {

            //    alert(err);
            // } ,500);;

            // })
        },
        gotoPage(path = "/") {
            this.$router.push(path);
        },
        loginMe(action) {
            // this.$vs.loading();
            let _self = this;

            this.errorCode = "";
            Object.assign(this.formerrors, {
                msg: "",
            });
            Object.assign(this.formmessage, {
                msg: "",
            });

            if (
                this.checkProperty(this.user, "email") &&
                this.checkProperty(this.user, "password")
            ) {
                let _tid = this.$store.getters["common/getTenantId"];
                let obj;
                if (_tid != null) {
                    obj = {
                        apiKey: "FV$HSE@JUGUUGU$J5L@HE",
                        userName: this.user.email,
                        password: this.user.password,
                        tenantId: this.$store.getters["common/getTenantId"],
                    };
                } else {
                    obj = {
                        apiKey: "FV$HSE@JUGUUGU$J5L@HE",
                        userName: this.user.email,
                        password: this.user.password,
                    };
                }
                if (this.selectedTenant && _.has(this.selectedTenant, "id")) {
                    obj = Object.assign(obj, { tenantId: this.selectedTenant["id"] });
                } else {
                    this.tenantsList = [];
                }

                //  alert("Trying to login ---1");
                this.$store
                    .dispatch("login", obj)
                    .then((response) => {
                        // this.$vs.loading.close();
                        //alert(JSON.stringify(response));
                        if (response.error) {
                            this.showMe = false;
                            // alert(response.error+"---2");
                            this.tenantsList = [];
                            this.selectedTenant = null;
                            if (_.has(response.error, "message")) {
                                Object.assign(this.formerrors, {
                                    msg: response.error.message,
                                });
                            } else {
                                Object.assign(this.formerrors, {
                                    msg: response.error.error,
                                });
                            }
                            //this.errorCode ='';
                            //alert(JSON.stringify(response.error['code']))
                            if (_.has(response.error, "code")) {
                                this.errorCode = response.error["code"];
                            }
                        } else {
                            const user = response.data.result.data;

                            if (_.has(user, "accounts") && user.accounts.length > 0) {
                                this.tenantsList = user.accounts;
                            } else {
                                //  alert(response.data.message+"---3");
                                this.goTopage(action, user);
                            }
                        }
                    })
                    .catch((err) => {
                        //  this.$vs.loading.close();
                        // alert(err+"---4");
                        this.errorCode = "";
                        Object.assign(this.formerrors, {
                            msg: err,
                        });
                        this.tenantsList = [];
                        this.selectedTenant = null;

                        setTimeout(function () {
                            _self.$router.push("/login").catch(() => { });
                        }, 800);
                    });

                // if form have no errors
            } else {
                //alert("---5");
                setTimeout(function () {
                    _self.$router.push("/login").catch(() => { });
                }, 800);
            }
        },
        checkPinnValidation() {
            let postData = {
                pin: this.$route.query.key
                    ? this.$route.query.key
                    : this.$route.query.forgotPasswordPin,
            };
            //auth/get-token-details
            // this.$vs.loading();
            this.$store
                .dispatch("commonAction", {
                    data: postData,
                    path: "/auth/get-token-details",
                })
                .then((response) => {
                    //    this.$vs.loading.close();

                    if (!response.status) {
                        if (
                            _.has(response, "linkUsedMessage") &&
                            response.linkUsedMessage
                        ) {
                            Object.assign(this.formerrors, {
                                msg: response.linkUsedMessage,
                            });
                        } else {
                            Object.assign(this.formerrors, { msg: response.message });
                        }
                    } else {
                        let expireOn = moment(response.expireOn);
                        let now = moment();
                        if (now > expireOn) {
                            if (this.$route.path == "/public/reset-password") {
                                this.showResendLink = true;
                            }
                            if (
                                _.has(response, "linkExpiredMessage") &&
                                response.linkExpiredMessage
                            ) {
                                Object.assign(this.formerrors, {
                                    msg: response.linkExpiredMessage,
                                });
                            } else {
                                Object.assign(this.formerrors, { msg: response.message });
                            }
                        } else {
                            this.showMe = true;
                        }
                    }
                })
                .catch((error) => {
                    this.showResendLink = false;
                    //  this.$vs.loading.close();
                    Object.assign(this.formerrors, { msg: error });
                });
        },
        updatePassword() {
            Object.assign(this.formerrors, {
                msg: '',
            });
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.loading = true
                    let action = "set-password";
                    let actionPath = "updatePassword";
                    if (this.$route.path == "/public/reset-password") {
                        action = "forgot-password";
                        // actionPath = "auth/set_forgot_password";
                    }
                    let Payload = {
                        apiKey: "FV$HSE@JUGUUGU$J5L@HE",
                        //tenantId: this.$route.query.tenantId,
                        //forgotPasswordPin: this.$route.query.key?this.$route.query.key:this.$route.query.forgotPasswordPin,
                        pin: this.$route.query.key
                            ? this.$route.query.key
                            : this.$route.query.forgotPasswordPin,
                        newPassword: this.password,
                        confirmPassword: this.conformPassword,
                        userId: this.$route.query.userId,
                        action: action,
                    };
                    if (_.has(this.$route.query, "tenantId")) {
                        Payload = Object.assign(Payload, {
                            tenantId: this.$route.query.tenantId,
                        });
                    }

                    this.$store.dispatch(actionPath, Payload).then((response) => {
                        this.loading = false
                        if (response.data.status == "Failed") {
                            Object.assign(this.formerrors, {
                                msg: response.data.message,
                            });
                        } else {
                            // alert(action +" "+this.checkProperty(response.data ,"result" ,"email"))

                            if (
                                this.checkProperty(response.data, "result", "userName") &&
                                action == "set-password"
                            ) {
                                this.user = Object.assign(this.user, {
                                    email: this.checkProperty(response.data, "result", "userName"),
                                });
                                this.user = Object.assign(this.user, {
                                    password: this.confirm_password,
                                });
                                //alert(JSON.stringify(this.user));
                                this.loginMe(action);
                            } else {
                                this.showToster({
                                    message: response.data.message,
                                    isError: false,
                                });

                                this.SetPassword = false;
                                var _self = this;
                                setTimeout(function () {
                                    _self.$router.push("/login");
                                }, 800);
                            }
                        }
                    });

                }
            })
        },

    },
    mounted() {
        this.$store.dispatch("logout").then(() => {
            //this.$router.push("/login");
        });
        this.$store.dispatch("logout").then(() => { });
        if (this.$route.path == "/public/reset-password") {
            this.title = "Set Forgot Password";
        }
        this.checkPinnValidation();
    },
};
</script>