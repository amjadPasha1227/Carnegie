<template>
  <div class="db_page">
    <!-- <div class="page_header">
      <h3>Customers</h3>
    </div> -->
    <div class="filter_sec">
      <!-- <searchInput :place-holder="'Search…'" />-->
      <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" />
      <simpleSelect :multiple="true" :wrapclass="'req_status'" :optionslist="filterCustomerTypes" :display="true"
        :place-holder="'Client Type'" :searchable="false" :required="false" :close-on-select="false"
        :clear-on-select="true" v-model="filterSelectedCustomerTypes" :fieldName="'filtercustomerType'"
        :cid="'filtercustomerType'" :hideSelected="true" @input="applyFilters" />
      <!---<simpleSelect :multiple="true" :wrapclass="'req_status'" :optionslist="filterStatusList" :display="true"
        :place-holder="'Status'" :searchable="false" :required="false" :close-on-select="true"
        :clear-on-select="true" v-model="filterSelectedStatusList" :fieldName="'filterStatuses'" :cid="'filterStatuses'"
        :hideSelected="true" @input="applyFilters" />-->

      <simpleSelect v-if='false' :multiple="true" :wrapclass="'req_status'" :optionslist="filterStatusList"
        :display="true" :place-holder="'Status'" :searchable="false" :required="false" :close-on-select="true"
        :clear-on-select="true" v-model="filterSelectedStatuses" :fieldName="'filterStatuses'" :cid="'filterStatuses'"
        :hideSelected="true" @input="applyFilters" />

      <button class="filter_btn" v-if="false"><span></span><em>Filters</em></button>
      <div class="filters_right" v-if="canCreateCustomer(getUserRoleId)">
        <button class="add_btn" @click="showAddcustomerPopup"><span></span><em>Add Client</em></button>
      </div>
    </div>
    <div class="customers_tabs_sec">
      <b-tabs>


        <!-- <b-tab  active> -->
        <b-tab v-for="(item, index) in  tabBillingTypes " @click="onTabSelected(item)">
          <template #title> {{ item.name }}
          </template>
          <div class="table-responsive customers_table">
            <table class="table" v-if="checkProperty(customersList, 'length') > 0 && !isListLoading">
              <thead>
                <tr>
                  <th>Company Name/Name</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Email</th>
                  <th>Client Type</th>

                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(item, index) in  customersList " v-bind:key="index">
                  <td>
                    <div class="user_header">
                      <span>{{ checkProperty(item, 'companyName') ? item.companyName : item.name }}</span>
                    </div>
                    <!-- <span class="name">The Colin Brothers</span>-->
                  </td>
                  <td>
                    <span>{{ checkProperty(item, 'firstName') ? item.firstName : '' }}</span>
                  </td>
                  <td>
                    <span>{{ checkProperty(item, 'lastName') ? item.lastName : '' }}</span>
                  </td>
                  <td><span>{{ checkProperty(item, 'email') ? item.email : '' }}</span></td>
                  <td v-if="checkProperty(item, 'customerTypeDetails', 'id') == 3"><span class="rush">{{
                    checkProperty(item,
                      'customerTypeDetails', 'name') ?
                    item.customerTypeDetails.name : '' }}</span></td>
                  <td v-if="checkProperty(item, 'customerTypeDetails', 'id') != 3"><span>{{ checkProperty(item,
                    'customerTypeDetails', 'name') ?
                    item.customerTypeDetails.name : '' }}</span></td>
                  <!-- <td><span class="Standard">{{ checkProperty(item, 'billingTypeDetails', 'name') ?
                    item.billingTypeDetails.name : '' }}</span></td> -->

                  <!-- <td>
                    <div class="actions">
                      <span v-if="checkProperty(item, 'statusId') == 0" class="view_profile"
                        @click="showProfilePopup(item)">View
                        Profile</span>
                      <span v-if="checkProperty(item, 'statusId') == 3" class="inactive">Inactive</span>
                      <span v-if="checkProperty(item, 'statusId') == 1" class="inactive">Pending </span>
                      <dropdownHover aria-disabled="true" v-if="item._id != checkProperty(getUserData, '_id')">
                        <b-dropdown-item v-if="checkProperty(item, 'statusId') == 2"
                          @click="editUser(item)">Edit</b-dropdown-item>
                        <b-dropdown-item v-if="checkProperty(item, 'statusId') == 2"
                          @click="selectedUser = item; password = ''; conformPassword = ''; showPasswordChangePopup = true">{{
                          checkProperty(item, 'passwordUpdated') ? 'Reset Password' : 'Set Password' }}</b-dropdown-item>
                        <b-dropdown-item @click=" selectedUser = item; showStatusChangePopup = true ">{{
                          checkProperty(item, 'statusId') == 2
                          ? 'Inactivate' : 'Activate'
                          }}</b-dropdown-item>
                      </dropdownHover>
                    </div>
                  </td> -->
                  <td>
                    <div class="d-flex">
                      <span class="status approve">Approved</span>
                    </div>
                  </td>
                  <td>
                    <div class="actions">
                      <span class="invoice_btn" @click="showProfilePopup(item)"><img
                          src="@/assets/images/vision.png"></span>
                      <span class="view_profile" @click="showProfilePopup(item, true)">Edit
                        Profile</span>
                    </div>
                  </td>

                </tr>

              </tbody>
            </table>

            <div class="pagination-sec" v-if="checkProperty(customersList, 'length') > 0">
              <div class="per-page">
                <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) +
                  customersList.length) +
                  ' of ' + totalCount + ' Results' }}</label>
              </div>
              <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
                @input=" isListLoading = true, updateLoading(true), getCustomers()"></b-pagination>
            </div>
          </div>
        </b-tab>
      </b-tabs>
      <template v-if="checkProperty(customersList, 'length') <= 0">
        <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Customers' :loading="isListLoading" />
      </template>

    </div>

    <b-modal v-model="showProfile" id="create_template" dialog-class="profile_model" centered no-close-on-backdrop
      hide-footer hide-header>

      <template>
        <div class="profile_header">

          <div class="profile_title">
            <h6>{{ checkProperty(selectedCustomer,
              'companyName') ? selectedCustomer.companyName : checkProperty(selectedCustomer, 'name') }}</h6>

          </div>
          <a class="close" @click=" showProfile = false"></a>
        </div>
        <div class="profile_info">
          <ul>
            <li v-if="checkProperty(selectedCustomer, 'companyName')">
              <span class="info_header">Company Name</span>
              <p class="desc">{{ checkProperty(selectedCustomer, 'companyName') ? selectedCustomer.companyName : '' }}</p>
            </li>
            <li>
              <span class="info_header">Name</span>
              <p class="desc">{{ checkProperty(selectedCustomer, 'name') ? selectedCustomer.name : '' }}</p>
            </li>
            <li>
              <span class="info_header">Email</span>
              <p class="desc">{{ checkProperty(selectedCustomer, 'email') ? selectedCustomer.email : '' }}</p>
            </li>

            <li v-if="checkProperty(selectedCustomer, 'phone')">
              <span class="info_header">Phone</span>
              <p class="desc">
                {{ checkProperty(selectedCustomer, 'phoneCountryCode', 'countryCallingCode') | countryFormatter }}
                {{ checkProperty(selectedCustomer, 'phone') | formatPhone }}</p>
            </li>


            <li v-if="checkProperty(selectedCustomer, 'customerTypeDetails', 'name')">
              <span class="info_header">Customer Type</span>
              <p class="desc">{{ checkProperty(selectedCustomer, 'customerTypeDetails', 'name') ?
                checkProperty(selectedCustomer, 'customerTypeDetails', 'name') : '' }}
              </p>
            </li>
            <li v-if="checkProperty(selectedCustomer, 'billingTypeDetails', 'name')">
              <span class="info_header">Billing Type</span>
              <p class="desc">{{ checkProperty(selectedCustomer, 'billingTypeDetails', 'name') ?
                checkProperty(selectedCustomer, 'billingTypeDetails', 'name') : '' }}</p>
            </li>
            <li v-if="checkProperty(selectedCustomer, 'address', 'line1')">
              <span class="info_header">Address</span>
              <p class="desc">{{ selectedCustomer.address | addressformat }}</p>
            </li>
          </ul>
        </div>
      </template>
    </b-modal>

    <b-modal v-if="showAddcustomerSuccess" id="success_model" dialog-class="success_model customer_success" centered
      hide-header hide-footer>
      <template>
        <figure>
          <img src="@/assets/images/success_mdl_img.png" />
        </figure>
        <h5 class="m-0">Client added!</h5>
      </template>
    </b-modal>

    <AddCustomer v-if="showAddCustomerPopup" @closeAddCustomer="showAddCustomerPopup = false"
      @updateCustomer="updateWithNewCustomer" :isEdit="isCustomerEdit" :customerData="selectedCustomer"></AddCustomer>
  </div>
</template>

<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import fileUpload from "@/views/forms/fileupload.vue";
import simpleSelect from '@/views/forms/simpleSelect.vue';
import dropdownHover from '@/views/forms/dropdownHover.vue';
import radioInput from "@/views/forms/radioInput.vue";
import textArea from "@/views/forms/textarea.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import addressFields from "@/views/forms/address.vue";
import phoneInput from "@/views/forms/phonenumber.vue";
import NoDataFound from "@/views/common/noData.vue";
import AddCustomer from '@/views/common/addCustomer.vue';


export default {
  name: 'dashboard-view',
  components: {
    searchInput,
    simpleSelect,
    dropdownHover,
    radioInput,
    simpleInput,
    fileUpload,
    fileUploadDrag,
    textArea,
    addressFields,
    phoneInput,
    NoDataFound,
    AddCustomer
  },
  data: () => ({
    showAddTemplate: false,
    showAddcustomer: false,
    showProfile: false,
    showAddcustomerSuccess: false,
    isListLoading: true,
    rows: 100,
    page: 1,
    perpage: 25,
    totalCount: 61,
    currentPage: 1,
    filterCustomerRolesList: [],
    StatusList: [],
    priorityList: [],
    customerList: ['Alex Mecheal Alex Mecheal', 'Alex', 'Mecheal'],
    beneficiaryList: ['Alex Mecheal Alex Mecheal', 'Alex', 'Mecheal'],
    customersList: [],
    customerTypes: [],
    billingTypes: [],
    tabBillingTypes: [],
    tabCustomerTypes: [],
    filterCustomerTypes: [],
    filterBillingTypes: [],
    filterStatusList: [],
    selectedTab: null,
    SelectedStatuses: null,
    filterSelectedStatuses: null,
    filterSelectedCustomerTypes: [],
    filterSelectedStatusList: [],
    filterSearch: '',
    customer: {
      firstName: "",
      lastName: "",
      email: "",
      customerType: null,
      billingType: null,
      phone: null,
      phoneCountryCode: {
        countryCode: 'US',
        countryCallingCode: ''
      },
      discount: 30,
      details: '',

      address: {
        line1: "", line2: "", countryId: 231, countryDetails: { "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" }
        , stateId: '', stateDetails: null, locationId: '', locationDetails: null, zipcode: '', aptType: ''
      },
      selectedCustomer: null,
    },

    countries: [{
      _id: "61408c9ed01ea1248cdcf6b7",
      id: 231,
      name: "United States",
      phoneCode: 1,
      order: 1,
      currencySymbol: "$",
      currencyCode: "USD",
      zipcodeLength: 5,
      sortName: "united states",
    }],
    countryCode: "US",
    showAddCustomerPopup: false,
    isCustomerEdit: false,
  }),
  methods: {
    getCustomerTypes() {

      this.$store.dispatch("getMasterData", 'customer_types')
        .then((res) => {
          this.customerTypes = res
          this.tabCustomerTypes = res
          this.filterCustomerTypes = res

          // if (this.checkProperty(res, 'length') > 0) {
          //   this.selectedTab1 = res[0]

          // }

        })


    },
    getBillingsType() {
      this.$store.dispatch("getMasterData", 'billing_types')
        .then((res) => {
          this.billingTypes = res
          this.tabBillingTypes = res
          this.filterBillingTypes = res
          if (this.checkProperty(res, 'length') > 0) {
            this.selectedTab = res[0]
            this.getCustomers()
          }
        })
    },
    getCountries() {
      this.$store.dispatch("getMasterData", 'countries')
        .then((res) => {
          this.countries = res
        })
    },

    updatePhoneCountryCode(data) {
      this.customer.phoneCountryCode = data;
    },
    gotoPage(path = "/") {
      this.$router.push(path);
    },
    showAddcustomerPopup(isEdit = false) {
      this.isCustomerEdit = false
      this.customer = {

        name: "",
        firstName: '',
        lastName: '',
        email: '',
        phone: null,
        customerType: '',
        billingType: '',
        phoneCountryCode: {
          countryCode: 'US',
          countryCallingCode: ''
        },
        address: {
          line1: "", line2: "", countryId: 231, countryDetails: { "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" }
          , stateId: '', stateDetails: null, locationId: '', locationDetails: null, zipcode: '', aptType: ''
        },

      }
      this.showAddCustomerPopup = true
    },
    
    getCustomers() {
      let statusIds = []
      let customerTypes = []
      let billingTypes = []


      if (this.filterSelectedStatuses && this.checkProperty(this.filterSelectedStatuses, 'length') > 0) {
        statusIds = this.filterSelectedStatuses.map((item) => item._id)

      }
      if (this.checkProperty(this.filterSelectedCustomerTypes, 'length') > 0) {
        customerTypes = this.filterSelectedCustomerTypes.map((item) => item.id)
      }

      if (this.checkProperty(this.selectedTab, 'id')) {

        billingTypes.push(this.selectedTab['id'])
      }

      let postData =
      {
        "matcher": {
          "searchString": this.filterSearch,
          "statusList": '',
          "statusIds": statusIds,
          "countryIds": [],
          "stateIds": [],
          "locationIds": [],
          "billingType": billingTypes,
          "customerType": customerTypes,
          "createdDateRange": [],
          "totalCount": [],
        },
        "sorting": {
          "path": "createdOn",
          "order": -1
        },
        "getMasterData": false,// if Masterdata required
        "page": this.page,
        "perpage": this.perpage,
      }

      // if (this.checkProperty(this.selectedTab, 'id')) {
      // postData.matcher.customerType.push(this.checkProperty(this.selectedTab1, 'id'))
      // }
      this.$store.dispatch("getcustomerList", postData)
        .then((res) => {
          this.isListLoading = false
          this.customersList = res.data.result.list
          if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
            this.totalCount = this.checkProperty(res.data.result, 'totalCount');
          }
          if (this.checkProperty(this.selectedTab, 'id')) {
            postData.matcher.billingType.push(this.checkProperty(this.selectedTab, 'id'))
          }
          setTimeout(() => {
            this.updateLoading(false);
          })
        }).catch((error) => {
          this.isListLoading = false
          this.updateLoading(false);
        })

    },
    showProfilePopup(profileItem, isEdit = false) {

      if (isEdit) {
        this.isCustomerEdit = true
        this.selectedCustomer = profileItem
        this.showAddCustomerPopup = true
      } else {
        let postData =
        {
          "customerId": profileItem._id
        }
        this.$store.dispatch("getCustomerDetails", postData)
          .then((res) => {
            this.selectedCustomer = res.data.result
            this.showProfile = true
          })
          .catch((error) => {

          })
      }
    },

    onTabSelected(selectedItem) {
      this.selectedTab = selectedItem

      this.page = 1
      this.customersList = []
      this.getCustomers();
    },
    applyFilters() {
      this.page = 1
      this.customersList = []
      this.getCustomers()

    },
    applySearchFilters() {
      this.page = 1
      this.customersList = []
      if (this.filterSearch && this.filterSearch.length > 0) {
        this.getCustomers()
      }
      if (this.filterSearch == '') {
        this.getCustomers()
      }
    },
    getMasterDataList(category) {
      this.$store.dispatch("getMasterData", category)
        .then((res) => {

          if (category == 'user_statuses') {
            this.filterStatusList = [...res]
          }
        })


    },
    updateWithNewCustomer(customer) {
      this.applyFilters()
    }
  },

  mounted() {
    this.isListLoading = true
    this.updateLoading(true);
    this.getCustomerTypes();
    this.getBillingsType();
    this.getCountries();
    this.getMasterDataList('user_statuses')

  },

  provide() {
    return {
      parentValidator: this.$validator,
    };
  }
}

</script>