<template>
  <div class="login_area">
    <span class="loader" v-if="isApiLoading"><img src="@/assets/images/loader.gif"></span>
    <div class="login_sec">
      <div class="logo">
        <img src="@/assets/images/logo_carne.png">
      </div>
      <div v-if="!showForgotPassword">
        <h5>Log In</h5>
        <label>Email/Username*</label>
        <div class="input_group">
          <input v-on:keyup.enter="login" type="text" class="form-control" :data-vv-as="'Email/Username'"
            v-validate="'required'" v-model="username" placeholder="Email/Username" name="username" />
          <!-- <input type="text" class="form-control" placeholder="Ex: jacob@gmail.com"> -->
          <!-- <img src="@/assets/images/user.png" style="width: 16px;left: 14px;"> -->
          <p v-show="errors.has('username')" class="form-error">
            {{ errors.first("username") }}
          </p>
        </div>
        <label>Password*</label>
        <div class="input_group">
          <input v-on:keyup.enter="login()" v-validate="'required'" :data-vv-as="'Password'" v-model="password"
            :type="showPassword ? 'text' : 'password'" class="form-control eye" placeholder="Password" id="inputPassword"
            name="password" />
          <!-- <input type="password" class="form-control" placeholder="* * * * * * * *"> -->
          <!-- <img src="@/assets/images/lock.svg"> -->
          <div v-if="password" class="view_eye" :class="{ close: showPassword }" @click="toggleShow">
          </div>
          <p v-show="errors.has('password')" class="form-error">
            {{ errors.first("password") }}
          </p>
        </div>
        <div class="keep_logged_in">
          <div class="form-check">
            <input v-model="checkbox_remember_me" type="checkbox" class="form-check-input" id="keepMeLoggedIn" />
            <label class="form-check-label" for="keepMeLoggedIn">Remember me </label>
          </div>
          <a @click="showForgotPassword = true; disabledBtn = false" class="forgot_link"><img
              src="@/assets/images/forgot_pwd_img.svg">Forgot Password?</a>
        </div>
        <button class="login_btn" @click="login">Log In</button>
        <!-- <a @click="showForgotPassword = true ; disabledBtn = false" class="forgot_link"><img src="@/assets/images/forgot_pwd_img.svg">Forgot Password?</a> -->
        <!-- <p>Don't have an account? <a @click="gotoPage('/createaccount')" class="create_link">Create</a></p> -->
      </div>

      <div v-if="showForgotPassword" v-on:keyup.enter=" forgotPassword()">
        <h5>Forgot Password</h5>
        <label>Email/Username</label>
        <div class="input_group">
          <input type="text" class="form-control" :data-vv-as="'Email/Username'" v-validate="'required'" v-model="username"
            placeholder="Email/Username" name="username">
          <!-- <img src="@/assets/images/user.png" style="width: 16px;left: 14px;"> -->
          <p v-show="errors.has('username')" class="form-error">
            {{ errors.first("username") }}
          </p>
        </div>
        <button class="login_btn crt_btn" @click=" forgotPassword()">Send</button>
        <p>Back to <a @click=" showForgotPassword = false, disabledBtn = false" class="create_link" data-bs-toggle="modal"
            data-bs-target="#login_reg_modal">Log In</a></p>
      </div>
    </div>
    <div class="guest_sec">
      <h6>Request an Evaluation as a Guest</h6>
      <a @click=" gotoPage('/guest-request')" class="proceed_btn">Proceed</a>
      <h6></h6>
      <h6>OR</h6>
      <!-- <h6>Don't have an account?</h6> -->
      <a @click="gotoPage('/createaccount')" class="create_btn">Sign Up </a>
      <!-- <button class="login_btn" @click="gotoPage('/createaccount')">Log In</button> -->




    </div>
  </div>
</template>
<script>

import * as _ from "lodash";


export default {
  name: "LoginView",
  provide() {
    return {

    };
  },
  components: {

  },
  methods: {
   
    showPasswordToggle() {
      if (this.inputType == "password") {
      } else {
        this.inputType == "text";
      }
    },
    setCookie(cname = "", cvalue = "", exdays = 1) {
      const d = new Date();
      d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
      let expires = "expires=" + d.toUTCString();
      document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    },
    getCookie(cname) {
      let name = cname + "=";
      let decodedCookie = decodeURIComponent(document.cookie);
      let ca = decodedCookie.split(";");
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == " ") {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    },
    rememberMe(username = "", pwd = "") {
      console.log("------------------------------------");
      const timestamp = new Date().getTime(); // current time
      const exp = timestamp + 60 * 60 * 24 * 1000 * 7;

      if (username != "" && pwd != "") {
        //remember_me
        // this.$cookies.set("remember_me", true, exp);
        let userData = { username: username, pwd: pwd, rememberMe: true };
        let encoded = JSON.stringify(userData);
        let enc = window.btoa(encoded);
        this.setCookie("server_Js", enc, 7);
        //let tokenData = JSON.parse(atob(enc))
        //alert(JSON.parse(atob(enc)));
      } else {
        this.setCookie("server_Js", "", 7);
      }

      //let email =this.CryptoJS.AES.decrypt(this.$cookies.get("email"),"FV$HSEDEEPV@JUG" ).toString(this.CryptoJS.enc.Utf8);
    },
    setRemember() {
      let enc = this.getCookie("server_Js");

      if (enc) {
        let tokenData = JSON.parse(atob(enc));
        if (tokenData.username) {
          this.username = tokenData.username;
        }
        if (tokenData.pwd) {
          this.password = tokenData.pwd;
        }

        if (
          tokenData.pwd &&
          tokenData.pwd != "" &&
          tokenData.username &&
          tokenData.username != "" &&
          (tokenData.rememberMe == true || tokenData.rememberMe == "true")
        ) {
          this.checkbox_remember_me = true;
        } else {
          this.setCookie("server_Js", "", 7);
        }
      }
    },

    login() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          this.isApiLoading = true
          this.disabledBtn = true;
          let username = this.username;
          let password = this.password;
          this.$store
            .dispatch("login", { userName: username, password: password })
            .then((response) => {
              if (this.checkProperty(response, 'accessToken')) {
                let postData = { 'accessToken': '', 'userId': this.checkProperty(response, 'userId') };
                postData['accessToken'] = this.checkProperty(response, 'accessToken');
                this.$store.dispatch("loginFromAccessToken", postData).then((res) => {
                  if (this.checkbox_remember_me) {
                    this.rememberMe(this.username, this.password);
                  } else {
                    this.rememberMe("", "");
                  }
                  if (this.getUserRoleId == 9) {
                    this.$router.push("/professordetails");
                  } else if (this.getUserRoleId == 15) {
                    this.$router.push("/evaluationslist");
                  } else if ([5].indexOf(this.getUserRoleId) > -1) {
                    this.$router.push("/evaluations-list");
                  }
                  else {
                    this.$router.push("/dashboard");
                  }

                }).catch((err) => {
                  this.loadingLogin = false;
                  this.isApiLoading = false;
                });
              } else {
                //alert(JSON.stringify(response))
                this.isApiLoading = false
              }

              this.disabledBtn = false;
            })
            .catch((error) => {
              this.disabledBtn = false;
              this.isApiLoading = false;
              if (_.has(error, 'message')) {
                this.showToster({ message: error.message, isError: true });
              } else if (this.checkProperty(error, 'error', 'message')) {
                this.showToster({ message: error.error.message, isError: true });
              } else {
                this.showToster({ message: 'Something went wrong', isError: true });
                //Something went wrong
              }
            });

        }

      });

      return false;
    },
    forgotPassword() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          this.disabledBtn = true;
          this.isApiLoading = true
          let username = this.username.trim();
          this.$store
            .dispatch("commonAction", {
              data: { userName: username },
              path: "/auth/forgot-password",
            })
            .then((response) => {
              this.isApiLoading = false
              this.showToster({ message: response.message, isError: false });
              this.username = '';
              this.password='';
              this.checkbox_remember_me = false;
              this.disabledBtn = false;
              this.$validator.reset();
              this.showForgotPassword = false;
            //  this.setRemember();
            })
            .catch((error) => {
              this.disabledBtn = false;
              this.isApiLoading = false
              if (_.has(error, 'message')) {
                this.showToster({ message: error.message, isError: true });
              } else {
                this.showToster({ message: 'Something went wrong', isError: true });
                //Something went wrong
              }
            });
        }
      });
    },

    gotoPage(path = "/") {
      this.$router.push(path);
    },
    toggleShow() {
      this.showPassword = !this.showPassword;
    }
  },
  data: () => ({
    showForgotPassword: false,
    showPassword: false,
    checkbox_remember_me: false,
    initCount: 0,
    username: "",
    password: "",
    isApiLoading: false,
    // username: "",
    // password: "",
    formmessage: {
      msg: "",
    },
    formerrors: {
      msg: "",
    },
  }),
  mounted() {
    // if (this.checkProperty(this.$route, 'query', 'accessToken')) {
    //   this.loadingLogin = true;
    //   setTimeout(() => {
    //     let postData = { 'accessToken': '' };
    //     postData['accessToken'] = this.checkProperty(this.$route, 'query', 'accessToken');
    //     this.$store.dispatch("loginFromAccessToken", postData).then((res) => {
    //       this.$router.push("/dashboard");
    //     }).catch((err) => {
    //       this.loadingLogin = false;
    //     });

    //   }, 1)
    // } else {
    this.setRemember();
    // }

  },
  watch: {
    checkbox_remember_me: function (value) {

      if (this.initCount > 0 && !value) {
        this.rememberMe()
      }
      this.initCount++;
    }

  }



};
</script>