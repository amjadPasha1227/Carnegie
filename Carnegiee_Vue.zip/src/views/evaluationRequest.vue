
<template>
    <div>
        <div class="guest_req_cnt">
            <h3 v-if="showHeaderTitle">Request an Evaluation as a Guest</h3>
            <div class="guest_form form-wizard">
                <div class="wizard-header">
                    <ul class="nav nav-tabs form-wizard-steps">
                        <template v-for="(item, index) in tabsList">
                            <li :key="index" :class="{
                                'activated': (index < checkActiveTab),
                                'active': (index == checkActiveTab)
                            }" @click="">
                                <span>{{ index + 1 }}</span>{{ item.name }}
                            </li>
                        </template>
                    </ul>
                </div>
                <div v-if="checkActiveTab == 0" class="wizard-fieldset " :class="{ 'show': checkActiveTab == 0 }">
                    <form :data-vv-scope="'evaluationForm0'">
                        <div class="wizard_cnt">
                            <p class="des text-danger" :class="{ 'show': checkActiveTab == 0 }">Please use only Alphanumeric characters (No special characters like slash, greater\less than,
                                etc)</p>
                            <div class="form_info">
                                <div class="row">
                                    <div class="row"
                                        v-if="!this.getUserRoleId || (this.getUserRoleId && this.getUserRoleId == 15)">
                                        <div class="col-md-12">
                                            <div class="form_group m-0">
                                                <label class="form_label">Are you doing this?*</label>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <radioInput :elementId="'doing_YourSelf'" :label="'Your Self'"
                                                :fieldName="'doing_YourSelf'" v-model="evaluationInfo.isDoingYourSelf"
                                                :fieldValue="true" class="mb-0" />
                                        </div>
                                        <div class="col-md-6">
                                            <radioInput :elementId="'doing_ForOthers'" :label="'Behalf of Any Others'"
                                                :fieldName="'doing_ForOthers'" v-model="evaluationInfo.isDoingYourSelf"
                                                :fieldValue="false" class="mb-0" />
                                        </div>

                                        <div class="form_group">
                                            <input type="hidden" class="form-control" v-validate="'required'"
                                                v-model="evaluationInfo.isDoingYourSelf" data-vv-as="Decision"
                                                :name="'decision'" :formscope="'evaluationForm' + currentTabIndex" />
                                            <span
                                                v-show="errors.has(('evaluationForm' + currentTabIndex) + '.' + 'decision')"
                                                class="form-error">{{
                                                    errors.first(('evaluationForm' + currentTabIndex) + '.' + 'decision')
                                                }}</span>
                                        </div>
                                    </div>
                                    <div class="col-md-12" v-if="false">
                                        <div class="form_group m-0">
                                            <label class="form_label">Type*</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6" v-if="false">
                                        <radioInput :elementId="'proceed_immediately'" :label="'Proceed Immediately'"
                                            :fieldName="'process'" v-model="evaluationInfo.proceedImmediately"
                                            :fieldValue="true" class="mb-0" />
                                    </div>
                                    <div class="col-md-6" v-if="false">
                                        <radioInput :elementId="'contact_first'" :label="'Contact Me First'"
                                            :fieldName="'process'" v-model="evaluationInfo.proceedImmediately"
                                            :fieldValue="false" class="mb-0" />
                                    </div>
                                    <div class="form_group" v-if="false">
                                        <input type="hidden" class="form-control" v-validate="'required'"
                                            v-model="evaluationInfo.proceedImmediately" data-vv-as="Type"
                                            :name="'proceedImmediately'" :formscope="'evaluationForm' + currentTabIndex" />
                                        <span
                                            v-show="errors.has(('evaluationForm' + currentTabIndex) + '.' + 'proceedImmediately')"
                                            class="form-error">{{
                                                errors.first(('evaluationForm' + currentTabIndex) + '.' + 'proceedImmediately')
                                            }}</span>
                                    </div>
                                    <div class="col-md-6">
                                        <simpleInput :fieldName="'full_name'" :cid="'full_name'" :label="'Full Name'"
                                            :placeHolder="'Full Name'" :vvas="'Full Name'" :display="true" :required="true"
                                            v-model="evaluationInfo.name" :allowAlphNum="true"
                                            :formscope="'evaluationForm' + currentTabIndex" />
                                    </div>
                                    <div class="col-md-6">
                                        <!-- <simpleInput :fieldName="'phone'" :cid="'phone'" :label="'Phone'" :placeHolder="'Phone'"
                                    :vvas="'Phone'" :display="true" :required="true" v-model="evaluationInfo.phone"
                                                                                                                                                                                                :onlyNumbers="true" /> -->

                                        <phoneInput :display="true" @updatephoneCountryCode="updatePhoneCountryCode"
                                            :countrycode="evaluationInfo.phoneCountryCode.countryCode" cid="phoneNumber"
                                            v-model="evaluationInfo.phone" :fieldName="'phoneNumber'" label="Phone Number"
                                            placeHolder="Phone Number" :required="false"
                                            :formscope="'evaluationForm' + currentTabIndex" />
                                    </div>
                                    <div class="col-md-6">
                                        <simpleInput :fieldName="'email'" :cid="'email'" :label="'Email'"
                                            :placeHolder="'Email'" :vvas="'Email'" :display="true" :required="true"
                                            v-model="evaluationInfo.email" :emailFormat="true" :datatype="'email'"
                                            :formscope="'evaluationForm' + currentTabIndex" />

                                    </div>
                                    <div class="col-md-6">
                                        <simpleInput :fieldName="'alternateemail'" :cid="'alternateemail'"
                                            :label="'Alternate Emails'" :placeHolder="'Alternate Emails'"
                                            :vvas="'Alternate Email'" :display="true"
                                            v-model="evaluationInfo.alternateEmail"
                                            :formscope="'evaluationForm' + currentTabIndex"
                                            :helpText="'You can enter a comma-separated(,) list of email addresses.'"
                                            :showHelpText="true" />
                                    </div>
                                    <div class="col-md-12">
                                        <simpleInput :fieldName="'your_firm'" :cid="'your_firm'" :label="'Your Firm'"
                                            :placeHolder="'Your Firm'" :vvas="'Your Firm'" :display="true"
                                            v-model="evaluationInfo.firm" :allowAlphNum="true"
                                            :formscope="'evaluationForm' + currentTabIndex" />
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form_group">
                                            <label class="form_label">{{ isGuestRequest ? "Special Notes"
                                                : "Client Notes" }}</label>
                                            <textArea class="" :tplkey="'specialNotes'" fieldName="specialNotes"
                                                placeHolder="Write anything else our evaluators should know"
                                                v-model="evaluationInfo.specialNotes"></textArea>
                                        </div>
                                    </div>
                                    <div class="col-md-12" v-if="!isGuestRequest&&getUserRoleId!==15">
                                        <div class="form_group">
                                            <label class="form_label">{{ "First Email" }}</label>
                                            <textArea class="" :tplkey="'evalFirstEmail'" fieldName="evalFirstEmail"
                                                placeHolder="Email..."
                                                v-model="evaluationInfo.evalFirstEmail"></textArea>
                                        </div>
                                    </div>



                                    <div class="col-md-12">
                                        <div class="form_group m-0">
                                            <label class="form_label">Do you need Rush Priority?*</label>
                                        </div>
                                    </div>

                                    <template v-if="checkProperty(priorityList, 'length') > 0"
                                        v-for="(pItem, pIndex) in priorityList.slice().reverse()">
                                        <div class="col-md-6">
                                            <radioInput wrapclass="m-0" :elementId="pItem.name" :label="pItem.name"
                                                :fieldName="pItem.name" v-model="evaluationInfo.priorityRush"
                                                :fieldValue="pItem" />
                                        </div>
                                    </template>

                                    <div class="form_group m-0">
                                        <input type="hidden" class="form-control" v-validate="'required'"
                                            v-model="evaluationInfo.priorityRush" data-vv-as="Priority" :name="'priority'"
                                            :formscope="'evaluationForm' + currentTabIndex" />
                                        <span v-show="errors.has(('evaluationForm' + currentTabIndex) + '.' + 'priority')"
                                            class="form-error">{{
                                                errors.first(('evaluationForm' + currentTabIndex) + '.' + 'priority') }}</span>
                                    </div>
                                    <div class="col-md-12">
                                        <p class="des note">
                                            Note: RUSH option is not available for all types of services.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div v-if="checkActiveTab == 1" class="wizard-fieldset " :class="{ 'show': checkActiveTab == 1 }">
                    <form :data-vv-scope="'evaluationForm1'" v-if="checkActiveTab == 1">
                        <div class="wizard_cnt">
                            <p class="des">Enter exactly as you want it on the final evaluation (Proof Spelling)</p>
                            <div class="form_info">
                                <div class="row">
                                    <div class="col-md-6">
                                        <simpleInput :fieldName="'beneficiaryFName'" :cid="'beneficiaryInfo'"
                                            :label="'First Name'" :placeHolder="'First Name'" :vvas="'First Name'"
                                            :display="true" :required="true"
                                            v-model="evaluationInfo.beneficiaryInformation.firstName" :allowAlphNum="true"
                                            :formscope="'evaluationForm' + currentTabIndex" />
                                    </div>
                                    <div class="col-md-6">
                                        <simpleInput :fieldName="'beneficiaryLName'" :cid="'beneficiaryInfo'"
                                            :label="'Last Name'" :placeHolder="'Last Name'" :vvas="'Last Name'"
                                            :display="true" :required="true"
                                            v-model="evaluationInfo.beneficiaryInformation.lastName" :allowAlphNum="true"
                                            :formscope="'evaluationForm' + currentTabIndex" />
                                    </div>

                                    <div class="col-md-6" v-if="currentTabIndex == 1">
                                        <simpleInput :fieldName="'beneficiaryFirm'" :cid="'beneficiaryInfo'"
                                            :label="'Beneficiary\'s Firm'" :placeHolder="'Beneficiary\'s Firm'"
                                            :vvas="'Beneficiary\'s Firm'" :display="true" :required="false"
                                            v-model="evaluationInfo.beneficiaryInformation.firm" :allowAlphNum="true"
                                            :formscope="'evaluationForm' + currentTabIndex" />
                                    </div>
                                    <div class="col-md-6">
                                        <simpleInput :fieldName="'beneficiaryJobTitle'" :cid="'beneficiaryInfo'"
                                            :label="'Job Title'" :placeHolder="'Job Title'" :vvas="'Job Title'"
                                            :display="true" :required="false"
                                            v-model="evaluationInfo.beneficiaryInformation.jobTitle" :allowAlphNum="true"
                                            :formscope="'evaluationForm' + currentTabIndex" />
                                    </div>
                                    <div class="col-md-6">
                                        <simpleInput :fieldName="'beneficiaryDegree'" :cid="'beneficiaryInfo'"
                                            :label="'Beneficiary\'s Degree'" :placeHolder="'Beneficiary\'s Degree'"
                                            :vvas="'Beneficiary\'s Degree'" :display="true" :required="false"
                                            v-model="evaluationInfo.beneficiaryInformation.degree" :allowAlphNum="true"
                                            :formscope="'evaluationForm' + currentTabIndex" />
                                    </div>
                                    <div class="col-md-6">
                                        <simpleInput :fieldName="'usEquivalentDegree'" :cid="'beneficiaryInfo'"
                                            :label="'Desired US equivalent degree'"
                                            :placeHolder="'Desired US equivalent degree'"
                                            :vvas="'Desired US equivalent degree'" :display="true" :required="false"
                                            v-model="evaluationInfo.beneficiaryInformation.usEquivalentDegree"
                                            :allowAlphNum="true" :formscope="'evaluationForm' + currentTabIndex" />
                                    </div>
                                    <div class="col-md-6">
                                        <simpleInput :fieldName="'socCode'" :cid="'beneficiaryInfo'"
                                            :label="'Occupation SOC code'" :placeHolder="'Occupation SOC code'"
                                            :vvas="'Occupation SOC code'" :display="true" :required="false"
                                            v-model="evaluationInfo.beneficiaryInformation.socCode"
                                            :formscope="'evaluationForm' + currentTabIndex" :wrapclass="'m-0'" />
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form_group m-0">
                                                    <label class="form_label">Gender*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <radioInput wrapclass="m-0" :elementId="'male'" :label="'Male'"
                                                    :fieldName="'gender'"
                                                    v-model="evaluationInfo.beneficiaryInformation.gender"
                                                    :fieldValue="'Male'" />
                                            </div>
                                            <div class="col-md-6">
                                                <radioInput wrapclass="m-0" :elementId="'female'" :label="'Female'"
                                                    :fieldName="'gender'"
                                                    v-model="evaluationInfo.beneficiaryInformation.gender"
                                                    :fieldValue="'Female'" />
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form_group m-0">
                                                    <input type="hidden" class="form-control" v-validate="'required'"
                                                        v-model="evaluationInfo.beneficiaryInformation.gender"
                                                        data-vv-as="Gender" :name="'genderInput'"
                                                        :formscope="'evaluationForm' + currentTabIndex" />
                                                    <span
                                                        v-show="errors.has(('evaluationForm' + currentTabIndex) + '.' + 'genderInput')"
                                                        class="form-error">{{
                                                            errors.first(('evaluationForm' + currentTabIndex) + '.' +
                                                                'genderInput') }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">

                                        <p class="des note">
                                            <a href="https://carnegieevaluations.com/pricing/" target="_blank">See
                                                PRICING</a> page for turnaround - additional charges will
                                            apply
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="wizard-fieldset evalution-fieldset " :class="{ 'show': checkActiveTab == 2 }">
                    <form :data-vv-scope="'evaluationForm2'">
                        <div class="wizard_cnt evalution_cnt">
                            <p class="des">Check the checkbox with the evaluation(s) you would like to order.<br />
                                You will be prompted to upload the files associated with that report on the next page.</p>
                            <p class="des">Please provide translated copies in English, if the documents are in foreign language.</p>
                            <template v-for="(item, index) in evaluationTypes">
                                <div class="evalution_list">
                                    <div v-if="false" class="evalution_heading">
                                        <span>Combinations of these evaluations are available - Please check all that
                                            apply.</span>
                                    </div>
                                    <div v-if="false" class="evalution_heading">
                                        <span>Additional customization available for H1B cases</span>
                                    </div>
                                    <div v-if="false" class="evalution_heading">
                                        <span>You will be contacted by our staff via email with specific requests for
                                            supporting documents for any of the below evaluations</span>
                                    </div>
                                    <div class="accordion">
                                        <div class="accordion_item"
                                            v-bind:class="{ 'expanded': checkProperty(item, 'isSelected') }" :key="index">
                                            <h2 class="accordion_header">
                                                <input @input="updatedSelection(index)" class="form-check-input"
                                                    type="checkbox" v-model="evaluationTypes[index].isSelected"
                                                    v-b-toggle="'collapse-' + index">
                                                <span>{{ item.name }}</span>
                                            </h2>
                                            <b-collapse :id="'collapse-' + index">
                                                <div class="accordion_body">
                                                    <div v-if="checkProperty(item, 'isSelected')" class="input-group"
                                                        :key="index + '' + index1"
                                                        v-for="(docItem, index1) in evaluationTypes[index].subTypes">
                                                        <span class="input-group-text">{{ docItem.name }}</span>
                                                        <div v-if="docItem.id == 70 && showLevels == true"
                                                            class="upload_doc_list no_doc_name wage_level_wrapper">
                                                            <div class="wage_level_analysis"
                                                                v-for="(levelItem, levelIndex) in docItem.levels">
                                                                <b-form-checkbox class="table_check"
                                                                    :id="levelItem.id + '' + levelIndex"
                                                                    :name="levelItem.id + '' + levelIndex"
                                                                    v-model="docItem.levels[levelIndex].isSelected"
                                                                    @change="onWageLevelSelect(index, index1, levelItem.id, levelIndex)">
                                                                    {{ checkProperty(levelItem,
                                                                        'name') }}
                                                                </b-form-checkbox>
                                                            </div>

                                                            <!-- <input @input="onWageLevelSelect(index, index1, levelItem.id, levelIndex)" class="form-check-input"
                                                                type="checkbox" v-model="docItem.levels[levelIndex].isSelected"
                                                                > -->
                                                        </div>
                                                        <div v-if="docItem.id == 72"
                                                            class="upload_doc_list no_doc_name namesofthedisciplines">
                                                            <simpleInput :fieldName="'namesofthedisciplines'"
                                                                :cid="'namesofthedisciplines'"
                                                                :label="'Names of the Disciplines'"
                                                                :placeHolder="'Names of the Disciplines'"
                                                                :vvas="'Names of the Disciplines'" :display="true"
                                                                v-model="evaluationInfo.namesOfDisciplines"
                                                                :allowAlphNum="true"
                                                                :formscope="'evaluationForm' + currentTabIndex" />
                                                        </div>

                                                        <fileUpload v-if="docItem.id !== 70 && docItem.id !== 72"
                                                            :wrapclass="'no_doc_name'"
                                                            :tplkey="'document' + index + '' + index1"
                                                            v-model="evaluationTypes[index].subTypes[index1].documents"
                                                            :tplsection="'document' + index + '' + index1" label=""
                                                            vvas="Document" :fieldName="'document' + index + '' + index1"
                                                            :cid="'document' + index + '' + index1" :multiple="true"
                                                            :deleteDocPermenantly="true" :isGuestUpload="isGuestRequest"
                                                            @input="updateDocumets($event, index, index1)"
                                                            @uploadingFile="checkFileUploading($event)">
                                                        </fileUpload>
                                                    </div>
                                                </div>
                                            </b-collapse>
                                        </div>
                                    </div>
                                </div>
                            </template>
                            <p class="des mt-4">For files that could not be uploaded, please send them to <a
                                    href="eval@carnegieevaluations.com" target="_blank">eval@carnegieevaluations.com</a>,
                                with
                                the Request ID in the Subject line of your email. </p>
                        </div>
                    </form>
                </div>
                <div class="wizard-fieldset show">
                    <div class="wizard_actions">

                        <div v-if="checkActiveTab != 2" class="wizard_actions_innr">

                            <a v-if="checkActiveTab == 0" class="form-cancel"
                                @click="hasHistory ? $router.go(-1) : cancelRequest">Cancel</a>
                            <a v-if="checkActiveTab > 0" @click="moveToPreviousTab"
                                class="form-wizard-previous-btn primary_btn">Previous</a>
                            <a @click="submitForm" class="form-wizard-next-btn primary_btn">Next</a>
                        </div>

                        <div v-if="checkActiveTab == 2" class="wizard_actions_innr evalution_actions_innr">
                            <a @click="moveToPreviousTab" class="form-wizard-previous-btn primary_btn">Previous</a>
                            <!-- <a class="primary_btn" :disabled="isFileUplading" @click="submitForm">Submit
                                <span class="loader" v-if="isFileUplading"><img src="@/assets/images/loader.gif"></span></a> -->
                            <!-- <button class="primary_btn" :disabled="isFileUplading" @click="submitForm">Submit</button> -->
                            <button class="primary_btn" @click="submitForm">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Success Modal -->
        <b-modal v-model="showCreateSuccess" id="success_model" dialog-class="success_model" centered hide-header
            hide-footer no-close-on-backdrop>
            <template>
                <figure>
                    <img src="@/assets/images/success_mdl_img.png" />
                </figure>
                <h5>Your Request has been Received!</h5>
                <p>{{ successMsg }}</p>
                <a class="primary_btn sm" @click="createEvaluationSuccess">Okay</a>
            </template>
        </b-modal>
    </div>
</template>



<script>
// @ is an alias to /src

import JQuery from "jquery";
import simpleInput from "@/views/forms/simpleInput.vue";
import fileUpload from "@/views/forms/fileupload.vue";
import radioInput from "@/views/forms/radioInput.vue";
import phoneInput from "@/views/forms/phonenumber.vue";
import textArea from "@/views/forms/textarea.vue";
export default {
    watch: {
        evaluationInfo: function (value) {

        }
    },
    name: 'evaluation-request',
    props: {
        showHeaderTitle: {
            type: Boolean,
            default: true,
        },
        isGuestRequest: {
            type: Boolean,
            default: false,
        }
    },
    components: {
        simpleInput,
        fileUpload,
        radioInput,
        phoneInput,
        textArea,
    },

    mounted() {

        this.getEvaluationTypes()
        this.getPriorities()
        if (this.getUserRoleId && this.getUserRoleId == 15 && this.checkProperty(this.getUserData, 'details', 'companyName')) {
            this.evaluationInfo.firm = this.checkProperty(this.getUserData, 'details', 'companyName')
        }

    },
    methods: {
        gotoPage(path = "/") {
            this.$router.push(path);
        },
        submitForm() {
            // if (this.currentTabIndex < 2) {
            //     let index = this.currentTabIndex
            //     this.currentTabIndex = -1
            //     this.currentTabIndex = index + 1
            // }

            this.$validator.validateAll("evaluationForm" + this.currentTabIndex).then((result) => {
                if (result) {
                    const $ = JQuery;
                    $("html, body").animate({ scrollTop: 0 }, 100);
                    if (this.currentTabIndex < 2) {
                        let isEmailValid = true
                        if (this.currentTabIndex == 0) {
                            isEmailValid = this.isAltEmailValid()
                        }
                        if (isEmailValid) {
                            console.log("resultEmail" + JSON.stringify(this.evaluationInfo.altEmailsList))
                            setTimeout(() => {
                                this.$validator.reset();
                                let index = this.currentTabIndex
                                this.currentTabIndex = -1
                                this.currentTabIndex = index + 1
                            })
                        } else {
                            this.showToster({ message: "Alternate emails are not valid.", isError: true });
                        }
                    } else if (this.currentTabIndex == 2) {
                        let docsConfig = []
                        let isRequestValid = false
                        let isEvaluationSelected = false
                        _.forEach(this.evaluationTypes, (item, index) => {
                            if (this.checkProperty(item, 'isSelected')) {
                                isEvaluationSelected = true
                                isRequestValid = true
                                let evaluation = {
                                    "evaluationTypeId": null,
                                    "evaluationTypeName": "",
                                    "shortName": "",
                                    "subTypes": []
                                }
                                evaluation['evaluationTypeId'] = item.id
                                evaluation['evaluationTypeName'] = item.name
                                evaluation['shortName'] = item.shortName
                                evaluation['price'] = this.checkProperty(this.evaluationInfo, 'priorityRush', 'id') == 2 ? item.rush : item.price
                                evaluation['subTypes'] = []
                                let isValidConfig = true
                                if (this.checkProperty(item, 'subTypes', 'length') > 0) {
                                    _.forEach(item.subTypes, (subItem) => {
                                        let subTypeItem = {
                                            "subTypeId": null,
                                            "subTypeName": "",
                                            "documents": []
                                        }

                                        let resultDocs = _.filter(subItem.documents, (docItem) => {
                                            return this.checkProperty(docItem, 'path', 'length') > 0
                                        })

                                        if (subItem.id !== 70 && subItem.id !== 72) {
                                            if (this.checkProperty(resultDocs, 'length') > 0) {
                                                isRequestValid = true
                                                isValidConfig = true
                                                subTypeItem['subTypeId'] = subItem.id
                                                subTypeItem['subTypeName'] = subItem.name
                                                subTypeItem['documents'] = subItem.documents
                                                evaluation['subTypes'].push(subTypeItem)
                                            }
                                        } else if (subItem.id == 70) {
                                            let resultLevel = _.filter(subItem.levels, (docItem) => {
                                                return this.checkProperty(docItem, 'isSelected')
                                            })
                                            isRequestValid = true
                                            isValidConfig = true
                                            subTypeItem['subTypeId'] = subItem.id
                                            subTypeItem['subTypeName'] = subItem.name
                                            subTypeItem['documents'] = []
                                            subTypeItem['levels'] = resultLevel
                                            evaluation['subTypes'].push(subTypeItem)
                                        } else if (subItem.id == 72) {
                                            isRequestValid = true
                                            isValidConfig = true
                                            subTypeItem['subTypeId'] = subItem.id
                                            subTypeItem['subTypeName'] = subItem.name
                                            subTypeItem['documents'] = []
                                            subTypeItem['nameOfDisciplines'] = this.evaluationInfo.namesOfDisciplines
                                            evaluation['subTypes'].push(subTypeItem)
                                        }
                                    })
                                } else {
                                    isValidConfig = true
                                    isRequestValid = true
                                }

                                if (isValidConfig) {
                                    docsConfig.push(evaluation)
                                }
                            }
                        });
                        if (isEvaluationSelected) {
                            if (isRequestValid) {
                                this.evaluationInfo['today'] = new Date()
                                this.evaluationInfo['docsConfig'] = docsConfig
                                this.evaluationInfo['quotaPrice'] = this.getQuoteCalucatedPrice
                                if (this.isGuestRequest) {
                                    this.evaluationInfo['authRequired'] = false
                                }

                                this.evaluationInfo.priorityId = this.evaluationInfo.priorityRush.id
                                //  console.log(JSON.stringify(resultDocs))
                                this.$store
                                    .dispatch("createEvaluation", this.evaluationInfo)
                                    .then((response) => {
                                        if (response.error) {
                                            this.showToster({ message: response.error.message, isError: true });
                                        } else {
                                            this.successMsg = response.message
                                            this.showCreateSuccess = true
                                        }
                                    })
                                    .catch((error) => {
                                        this.showToster({ message: error, isError: true });
                                        this.loading = false;
                                    });
                            } else {
                                this.showToster({ message: "Please upload evaluation documents", isError: true });
                            }
                        } else {
                            this.showToster({ message: "Please select at least one evaluation", isError: true });
                        }
                    }
                } else {
                    this.validateandScroll()
                }
            })
        },
        moveToPreviousTab() {
            if (this.currentTabIndex > 0) {
                const $ = JQuery;
                $("html, body").animate({ scrollTop: 0 }, 100);
                this.currentTabIndex = this.currentTabIndex - 1
            }
        },

        getEvaluationTypes() {
            this.$store.dispatch("getMasterData", 'evaluation_types')
                .then((res) => {
                    // this.evaluationTypes = this.sortedArray(res)
                    this.evaluationTypes = res
                    //   console.log(JSON.stringify(res))
                    //    isSelected
                    this.$store.dispatch("getMasterData", 'evaluation_documents_types')
                        .then((response) => {
                            let evaluationDocuments = [...response]
                            //  console.log(JSON.stringify(evaluationDocuments))
                            _.forEach(this.evaluationTypes, (item, index) => {
                                let evaluation = { ...item }
                                let evaDocs = []
                                _.forEach(evaluationDocuments, (docItem, indx) => {
                                    if (docItem.typeIds.findIndex(v => v == item.id) > -1) {
                                        docItem['timestamp'] = index + '#' + new Date().getTime()
                                        // docItem['fileUploading'] = false
                                        evaDocs.push({ ...docItem })
                                    }
                                });
                                // let evaDocs =_.filter(evaluationDocuments, (docItem) => {
                                //     return docItem.typeIds.findIndex(v => v == item.id) > -1
                                // })

                                if (this.checkProperty(evaDocs, 'length') > 0) {
                                    _.forEach(evaDocs, (document) => {
                                        document['documents'] = null
                                        //document['documents'].push({ url: "", name: "", })
                                    })
                                }

                                evaluation['subTypes'] = [...evaDocs]
                                evaluation['isSelected'] = false
                                this.evaluationTypes.splice(index, 1, evaluation)
                                // this.evaluationTypes[index] = { ...evaluation }
                            });


                        })
                })
        },

        updateDocumets(value, index, index1) {
            let evaluationItem = { ...this.evaluationTypes[index] };
            evaluationItem.subTypes[index1].documents = value
            // this.evaluationTypes[index] = evaluationItem
            this.evaluationTypes.splice(index, 1, evaluationItem)
        },
        updatePhoneCountryCode(data) {

            this.evaluationInfo.phoneCountryCode = data;

            console.log(JSON.stringify(this.evaluationInfo.phoneCountryCode))

        },
        getPriorities() {
            this.$store.dispatch("getMasterData", 'evaluation_priority')
                .then((res) => {
                    this.priorityList = res
                })
        },
        createEvaluationSuccess() {
            this.showCreateSuccess = false
            this.currentTabIndex = 0
            this.evaluationInfo = {
                name: '',
                firstName: '',
                lastName: '',
                middleName: '',
                phone: '',
                email: '',
                alternateEmail: '',
                firm: '',
                phoneCountryCode: {
                    countryCode: "US",
                    countryCallingCode: "1"
                },
                beneficiaryInformation: {
                    firstName: '',
                    middleName: '',
                    lastName: '',
                    jobTitle: '',
                    gender: '',
                    degree: '',
                    usEquivalentDegree: '',
                    socCode: '',
                    firm: '',

                },
                docsConfig: [],
                priorityRush: null,
                priorityId: null,
                dueDate: null,
                howDoYouHere: '',
                proceedImmediately: null,
                firm: '',
                specialNotes: '',
            }
            // this.getEvaluationTypes()
            if (this.isGuestRequest) {
                window.location.href = "https://carnegieevaluations.com/"
                //  this.$router.push("/login");
            }
            this.$emit('input')

        },
        updatedSelection(index) {
            let evaluationItem = this.evaluationTypes[index]
            if (this.checkProperty(evaluationItem, 'isSelected')) {
                _.forEach(evaluationItem.subTypes, (subItem, subIndex) => {
                    let subTypeItem = subItem
                    subTypeItem.documents = null
                    this.evaluationTypes[index].subTypes.splice(subIndex, 1, subTypeItem)
                })
            }
            evaluationItem['isSelected'] = !this.checkProperty(evaluationItem, 'isSelected')
            this.evaluationTypes.splice(index, 1, evaluationItem)
        },
        sortedArray(array) {
            // return array.sort((a, b) => a.id - b.id);
            return array.sort((a, b) => a.name.localeCompare(b.name));

        },
        cancelRequest() {
            if (this.isGuestRequest) {
                window.location.href = "https://carnegieevaluations.com/"
            } else {
                this.$router.push('/evaluations-list');
            }
        },
        validateandScroll() {
            var $self = this;
            const $ = JQuery;
            var el = _.find(this.errors["items"], function (item) {
                return item.scope == "evaluationForm" + $self.currentTabIndex
            })
            console.log(el)
            // this.$el.querySelector('.scroll-wrapper')
            // this.$el.scrollTop=0
            //alert(JSON.stringify(el.field))
            if (el) {
                const ele = $("[name=" + el.field + "]").parents(".form_group");
                var _top = 0;
                if (ele) {
                    _top = ele.position().top;
                }

            }
            $("html, body").animate({ scrollTop: _top }, 100);


            // // this.$el.querySelector('.scroll-wrapper')
            // // this.$el.scrollTop=0
            // //alert(JSON.stringify(el.field))
            // if (el) {
            //     //   document.getElementById(el.field).scrollTop = 0;
            //     //   const ele = $("[name=" + el.field + "]").parents(".guest_form'");
            //     //alert(JSON.stringify(ele))
            //     // var _top = 0;
            //     // if (ele) {
            //     //     _top = ele.position().top;
            //     // }
            // }
            // // document.getElementById("scrollableques").scrollTo({
            // //     top: _top,
            // //     left: 0,
            // //     behavior: 'smooth'
            // // })

        },
        checkFileUploading() {
            let uploading = false
            _.forEach(this.evaluationTypes, (item, index) => {
                _.forEach(item.subTypes, (subItem, index2) => {
                    let resultDocs = _.filter(subItem.documents, (docItem) => {
                        //console.log('docItem' + JSON.stringify(docItem))
                        if (this.checkProperty(docItem, 'fileUploading')) {
                            return true
                        } else {
                            return false
                        }
                    })
                    //  console.log('resultDocs' + JSON.stringify(resultDocs))
                    if (this.checkProperty(resultDocs, 'length') > 0) {
                        if (!uploading) {
                            uploading = true
                        }
                    }
                })
                this.isFileUplading = uploading

            });
        },
        isAltEmailValid() {
            this.evaluationInfo.altEmailsList = []
            let isAlternateEmailValid = true
            const validateEmail = (email) => {
                return String(email)
                    .toLowerCase()
                    .trim()
                    .match(
                        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
                    );
            };
            if (this.checkProperty(this.evaluationInfo, 'alternateEmail', 'length') > 0) {
                let emailsArray = this.checkProperty(this.evaluationInfo, 'alternateEmail').split(",")
                // console.log("emailsArray" + emailsArray)
                if (emailsArray.length > 0) {
                    _.forEach(emailsArray, (item) => {
                        let splitEmails = item.split("<")
                        //  console.log("splitEmails" + splitEmails)
                        if (splitEmails.length > 1) {
                            let resultEmail = splitEmails[1].replace(">", "")
                            if (!validateEmail(resultEmail)) {
                                isAlternateEmailValid = false
                            } else {
                                let emailObj = { 'name': splitEmails[0].trim(), 'email': resultEmail.trim() }
                                this.evaluationInfo.altEmailsList.push(emailObj)
                            }
                            // console.log("resultEmail" + resultEmail)
                        } else if (splitEmails.length > 0) {
                            let resultEmail = splitEmails[0]
                            if (!validateEmail(resultEmail)) {
                                isAlternateEmailValid = false
                            } else {
                                let emailObj = { 'name': '', 'email': resultEmail.trim() }
                                this.evaluationInfo.altEmailsList.push(emailObj)
                            }
                            //  console.log("resultEmail" + resultEmail)
                        } else {
                            isAlternateEmailValid = false
                        }
                    })
                }
            }
            return isAlternateEmailValid
        },
        onWageLevelSelect(index, subIndex, id, levelIndex) {

            setTimeout(() => {
                this.showLevels = false
                if (this.checkProperty(this.evaluationTypes[index].subTypes[subIndex], 'levels', 'length') > 0) {
                    _.forEach(this.checkProperty(this.evaluationTypes[index].subTypes[subIndex], 'levels'), (item, idx) => {
                        if (item.id !== id) {
                            if (this.checkProperty(item, 'isSelected')) {
                                item.isSelected = false
                            } else {
                                item['isSelected'] = false
                            }

                            this.evaluationTypes[index].subTypes[subIndex].levels[idx] = item
                        }
                    })

                }
                this.showLevels = true

            })



        }


    },
    computed: {
        checkActiveTab() {
            return this.currentTabIndex;
        },

        getQuoteCalucatedPrice() {
            let quotaPrice = {
                total: 0,
                discount: 0,
                evaluationPrices: []
            }
            let evaluationQuates = []
            if (this.checkProperty(this.evaluationInfo, 'docsConfig', 'length') > 0) {
                _.forEach(this.evaluationInfo.docsConfig, (item) => {
                    let evaluationPrice = {
                        evaluationTypeId: '',
                        evaluationTypeName: '',
                        shortName: '',
                        price: 0,
                        subTypes: [],
                    }
                    evaluationPrice.evaluationTypeId = item.evaluationTypeId
                    evaluationPrice.evaluationTypeName = item.evaluationTypeName
                    evaluationPrice.shortName = item.shortName
                    evaluationPrice.price = item.price
                    evaluationPrice.subTypes = item.subTypes
                    evaluationQuates.push(evaluationPrice)
                })
            }
            quotaPrice.evaluationPrices = evaluationQuates
            let totalPrice = 0
            if (this.checkProperty(quotaPrice, 'evaluationPrices', 'length') > 0) {
                _.forEach(quotaPrice.evaluationPrices, (item) => {
                    if (this.checkProperty(item, 'price') > 0) {
                        totalPrice += parseInt(item.price)
                    }
                })
            }
            quotaPrice.total = totalPrice

            return quotaPrice
        },

    },

    data: () => ({
        rush: false,
        tabsList: [{
            key: "personalinfo",
            name: "Your Information"
        },
        {
            key: "beneficiaryinfo",
            name: "Beneficiary's Information"
        }, {
            key: "evaluationinfo",
            name: "Type of Evaluation Needed"
        },],
        currentTabIndex: 0,
        evaluationInfo: {
            name: '',
            firstName: '',
            lastName: '',
            middleName: '',
            phone: '',
            email: '',
            alternateEmail: '',
            altEmailsList: [],
            firm: '',
            phoneCountryCode: {
                countryCode: "US",
                countryCallingCode: "1"
            },
            beneficiaryInformation: {
                firstName: '',
                middleName: '',
                lastName: '',
                jobTitle: '',
                gender: '',
                degree: '',
                usEquivalentDegree: '',
                socCode: '',
                firm: '',

            },
            docsConfig: [],
            priorityRush: null,
            priorityId: null,
            dueDate: null,
            howDoYouHere: '',
            proceedImmediately: null,
            firm: '',
            specialNotes: '',
            isDoingYourSelf: null,
            quotaPrice: {
                total: 0,
                discount: 0,
                evaluationPrices: []
            },
            today: null,
            namesOfDisciplines: '',
            evalFirstEmail:'',
        },
        evaluationTypes: [],
        priorityList: [],
        showCreateSuccess: false,
        successMsg: '',
        temp: '',
        isFileUplading: false,
        showLevels: true,
    }),
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },

}
</script>
