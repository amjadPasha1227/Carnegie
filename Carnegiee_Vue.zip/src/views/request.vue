<template>
    <div class="db_page">
      <!-- <div class="page_header">
        <h3>Evaluations</h3>
      </div> -->
      <div class="filter_sec">
        <searchInput :place-holder="'Search…'"/>
        <simpleSelect 
         :multiple="false" :wrapclass="'req_status'"
          :optionslist="statusList" :display="true"
          :place-holder="'Status'" :searchable="false" :required="false"
          :close-on-select="true" :clear-on-select="true"  />
          <simpleSelect 
         :multiple="false" :wrapclass="'priority'"
          :optionslist="priorityList" :display="true"
          :place-holder="'Priority'" :searchable="false" :required="false"
          :close-on-select="true" :clear-on-select="true"  />
          <simpleSelect 
         :multiple="false" :wrapclass="'customer'"
          :optionslist="customerList" :display="true"
          :place-holder="'Client'" :searchable="false" :required="false"
          :close-on-select="true" :clear-on-select="true"  />
          <simpleSelect 
         :multiple="false" :wrapclass="'beneficiary'"
          :optionslist="beneficiaryList" :display="true"
          :place-holder="'Beneficiary'" :searchable="false" :required="false"
          :close-on-select="true" :clear-on-select="true"  />
          
      </div>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>Request #</th>
              <th>CLIENT</th>
              <th>Beneficiary</th>
              <th>Priority</th>
              <th>Due Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <span class="request_id"  @click="$bvModal.show('work_experience_model')">E-5153</span>
              </td>
              <td>
                <div class="evalution_type">
                  <span>Mecheal Alex</span>
                </div>
              </td>
              <td>
                <div class="beneficiary_sec">
                  <span>Alex Mecheal</span>
                </div>
              </td>
              <td><span>Standard</span></td>
              <td><span>3 Mar 2023</span></td>
              <td><span class="status newrequested">New Request</span></td>
            </tr>
            <tr>
              <td>
                <span class="request_id" >E-7618</span>
              </td>
              <td>
                <div class="evalution_type">
                  <span>Mecheal Alex</span>
                </div>
              </td>
              <td>
                <div class="beneficiary_sec">
                  <span>Alex Mecheal</span>
                </div>
              </td>
              <td><span class="rush">Rush</span></td>
              <td><span>3 Mar 2023</span></td>
              <td><span class="status newrequested">New Request</span></td>
            </tr>
            <tr>
              <td>
                <span class="request_id" >E-8426</span>
              </td>
              <td>
                <div class="evalution_type">
                  <span>Mecheal Alex</span>
                </div>
              </td>
              <td>
                <div class="beneficiary_sec">
                  <span>Alex Mecheal</span>
                </div>
              </td>
              <td><span class="rush">Rush</span></td>
              <td><span>3 Mar 2023</span></td>
              <td><span class="status sent_for_revision">Sent For Revision</span></td>
            </tr>
            <tr>
              <td>
                <span class="request_id" >E-4253</span>
              </td>
              <td>
                <div class="evalution_type">
                  <span>Mecheal Alex</span>
                </div>
              </td>
              <td>
                <div class="beneficiary_sec">
                  <span>Alex Mecheal</span>
                </div>
              </td>
              <td><span>Standard</span></td>
              <td><span>9 Mar 2023</span></td>
              <td><span class="status sent_for_revision">Sent For Revision</span></td>
            </tr>
            <tr>
              <td>
                <span class="request_id" >E-4253</span>
              </td>
              <td>
                <div class="evalution_type">
                  <span>Mecheal Alex</span>
                </div>
              </td>
              <td>
                <div class="beneficiary_sec">
                  <span>Alex Mecheal</span>
                </div>
              </td>
              <td><span>Standard</span></td>
              <td><span>9 Mar 2023</span></td>
              <td><span class="status sent_for_revision">Sent For Revision</span></td>
            </tr>
            <tr>
              <td>
                <span class="request_id" >E-4253</span>
              </td>
              <td>
                <div class="evalution_type">
                  <span>Mecheal Alex</span>
                </div>
              </td>
              <td>
                <div class="beneficiary_sec">
                  <span>Alex Mecheal</span>
                </div>
              </td>
              <td><span>Standard</span></td>
              <td><span>9 Mar 2023</span></td>
              <td><span class="status delivered_to_client">Delivered to Client</span></td>
            </tr>
            <tr>
              <td>
                <span class="request_id" >E-4253</span>
              </td>
              <td>
                <div class="evalution_type">
                  <span>Mecheal Alex</span>
                </div>
              </td>
              <td>
                <div class="beneficiary_sec">
                  <span>Alex Mecheal</span>
                </div>
              </td>
              <td><span>Standard</span></td>
              <td><span>9 Mar 2023</span></td>
              <td><span class="status delivered_to_client">Approved</span></td>
            </tr>
            <tr>
              <td>
                <span class="request_id" >E-4253</span>
              </td>
              <td>
                <div class="evalution_type">
                  <span>Mecheal Alex</span>
                </div>
              </td>
              <td>
                <div class="beneficiary_sec">
                  <span>Alex Mecheal</span>
                </div>
              </td>
              <td><span>Standard</span></td>
              <td><span>9 Mar 2023</span></td>
              <td><span class="status delivered_to_client">Approved</span></td>
            </tr>
          </tbody>
        </table>
        <div class="pagination-sec">
        <div class="per-page">
          <label class="page_label">1-20 of 50 Results</label>
        </div>
        <b-pagination v-model="currentPage"
      :total-rows="rows"
      :per-page="perPage"></b-pagination>
      </div>
      </div>

      <b-modal id="work_experience_model" dialog-class="work_experience_model" centered no-close-on-backdrop hide-footer>
        <template #modal-header> <div class="req_details_inner">
          <div class="rq_header rq-clients">
            <div class="rq-number">
              <h5>Evaluations / <a href="#">#E-5153</a></h5>
              <div class="evalution_type">
                <span>Work Experience Evaluation</span>
                <div class="evalution_dropdown">
                  <em class="count" id="popover-target-1">+4</em>
                    <b-popover custom-class="evalution_list_wrap" target="popover-target-1" triggers="hover" placement="top" fallback-placement="flip">
                        <template>
                          <ul>
                            <li>Specialty Occupation Expert Opinions (Position Evaluations)</li>
                            <li>Employment Based 2nd Preference (EB-2A/EB-2B) Expert Opinion</li>
                            <li>E-2 Treaty Employee Expert Opinion</li>
                            <li>Expert Opinion Letter, Academic Evaluation & Work Experience Evaluation Combined</li>
                          </ul>
                        </template>
                  </b-popover>
                </div>
              </div>
            </div>
            <div class="rq-review">
              <div class="due_date"><h4><span>Due by </span> 8 Feb 2023</h4><figure class="due_date_icon"><img src="../assets/images/calender.png" ></figure></div>
              <div class="status rush"><img src="@/assets/images/clock.png"> Rush</div>
            </div>
          </div>
        </div>
        <a class="close" @click="$bvModal.hide('work_experience_model')"></a>
      </template>
      <template>
            <div class="evalution-flex">
              <section  class="timeline tq_timeline" show-day-and-month="true">
                <div class="wrapper-timeline">
                  <div class="wrapper-item">
                      <div class="section-year">
                        <p> 6:30 PM </p>
                        <p>  4 FEB 2023 </p>
                      </div>
                    <section  class="timeline-item">
                      <div class="item">
                        <span class="status_dot status_conform"></span>
                        <div class="status-name conform_bg">Delivery to Client</div>
                        <div class="submit_detailes">
                          <p>Delivered to client. Please Review</p>
                          <div class="doc_files">
                              <ul>
                                <li class="IB_tooltip"><figure><img src="@/assets/images/pdf-file-format.svg"></figure>
                                </li>
                                <li class="IB_tooltip"><figure><img src="@/assets/images/doc-file-format.svg"></figure>
                                </li>
                              </ul>
                          </div>
                        </div>
                      </div>
                    </section>
                  </div>
                  <div class="wrapper-item">
                      <div class="section-year">
                        <p> 6:30 PM </p>
                        <p>  4 FEB 2023 </p>
                      </div>
                    <section  class="timeline-item">
                      <div class="item">
                        <span class="status_dot status_revision"></span>
                        <div class="status-name status sent_for_revision">Sent for Revision</div>
                        <div class="submit_detailes">
                          <p>Please follow the below document comments update the required documents</p>
                          <div class="doc_files">
                              <ul>
                                <li class="IB_tooltip"><figure><img src="@/assets/images/doc-file-format.svg"></figure>
                                </li>
                              </ul>
                          </div>
                        </div>
                      </div>
                    </section>
                  </div>
                  <div class="wrapper-item">
                      <div class="section-year">
                        <p> 6:30 PM </p>
                        <p>  4 FEB 2023 </p>
                      </div>
                    <section  class="timeline-item">
                      <div class="item">
                        <span class="status_dot status_review"></span>
                        <div class="status-name review_bg">Case Requested</div>
                        <div class="submit_detailes">
                          <p>Documents are ready for review</p>
                          <div class="doc_files mb-3">
                              <ul>
                                <li class="IB_tooltip"><figure><img src="@/assets/images/pdf-file-format.svg"></figure>
                                </li>
                                <li class="IB_tooltip"><figure><img src="@/assets/images/doc-file-format.svg"></figure>
                                </li>
                              </ul>
                          </div>
                          <div class="btn-flex mt-1">
                            <button class="primary_btn" @click="$bvModal.show('deliver_model')">Approve</button>
                            <button class="primary_btn sent_btn" @click="$bvModal.show('note_model')">Send for Revision</button>
                          </div>
                        </div>
                      </div>
                    </section>
                  </div>
                </div>
              </section>
              <div class="action_tab">
                <div class="doc_files">
                  <h4>Client Documents</h4>
                    <ul>
                      <li class="IB_tooltip">
                        <b-button id="popover-target-2">
                          <figure><img src="@/assets/images/pdf-file-format.svg"></figure>
                        </b-button>
                        <b-popover target="popover-target-2" triggers="hover" placement="top">
                          Academic Transcripts.pdf <span>Uploaded by </span> Admin
                        </b-popover>
                      </li>
                      <li class="IB_tooltip">
                        <b-button id="popover-target-3">
                          <figure><img src="@/assets/images/doc-file-format.svg"></figure>
                        </b-button>
                        <b-popover target="popover-target-3" triggers="hover" placement="top">
                          Academic Transcripts.pdf <span>Uploaded by </span> Admin
                        </b-popover>
                      </li>
                      <li class="IB_tooltip">
                        <b-button id="popover-target-4">
                          <figure><img src="@/assets/images/jpeg.svg"></figure>
                        </b-button>
                        <b-popover target="popover-target-4" triggers="hover" placement="top">
                          Academic Transcripts.pdf <span>Uploaded by </span> Admin
                        </b-popover>
                      </li>
                      <li class="IB_tooltip">
                        <b-button id="popover-target-5">
                          <figure><img src="@/assets/images/pdf-file-format.svg"></figure>
                        </b-button>
                        <b-popover target="popover-target-5" triggers="hover" placement="top">
                          Academic Transcripts.pdf <span>Uploaded by </span> Admin
                        </b-popover>
                      </li>
                      <li class="IB_tooltip">
                        <b-button id="popover-target-6">
                          <figure><img src="@/assets/images/pdf-file-format.svg"></figure>
                        </b-button>
                        <b-popover target="popover-target-6" triggers="hover" placement="top">
                          Academic Transcripts.pdf <span>Uploaded by </span> Admin
                        </b-popover>
                      </li>
                    </ul>
                </div> 
              </div>
            </div>
        </template>
      </b-modal>
      
      <b-modal id="note_model" dialog-class="note_model" centered no-close-on-backdrop>
        <template #modal-header> <div class="req_details_inner">
          <h6 class="modal-title">Note</h6>
        </div>
        <a class="close" @click="$bvModal.hide('note_model')"></a>
      </template>
      <template>
        <textArea class="form-control" :label="'Type Here…'" :wrapclass="'h40 mb20'" :place-holder="'Type Here…'"></textArea>
        <p>For minor changes, you may provide instructions into the text box above. Any major changes, you are requested to upload document with your suggested changes.</p>
      </template>
      <template #modal-footer>
        <div class="upload_flex">
          <div class="upload-file">
            <input class="upload_input" ref="file" type="file">
            <div class="upload_btn uploaded">
              <svg viewBox="0 0 24 24" width="15" height="15" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><polyline points="16 16 12 12 8 16"></polyline><line x1="12" y1="12" x2="12" y2="21"></line><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"></path><polyline points="16 16 12 12 8 16"></polyline></svg>
              UPLOAD
            </div>
          </div>
          <div class="d-flex">
            <button class="form-cancel" @click="$bvModal.hide('note_model')">Cancel</button>
            <button class="primary_btn md" @click="validateForm()" >Submit</button>
          </div>
        </div>
      </template>
      </b-modal>
    </div>
</template>

<script>
    // @ is an alias to /src
    import searchInput from '@/views/forms/searchInput.vue';
    import simpleSelect from '@/views/forms/simpleSelect.vue';
    export default {
      name: 'dashboard-view',
      components: {
        searchInput,
        simpleSelect
      },
      data: () => ({
          rows: 100,
          perPage: 1,
          currentPage: 1,
          statusList: ['Awaiting Confirmation','Confirmed','Delivered to Client','In Process','Payment Status','Requested'],
          priorityList: ['Rush', 'Standard'],
          customerList: ['Alex Mecheal Alex Mecheal', 'Alex', 'Mecheal'],
          beneficiaryList: ['Alex Mecheal Alex Mecheal', 'Alex', 'Mecheal'],
      }),
      methods:{
        gotoPage(path = "/") {
          this.$router.push(path);
        },
      },

    }
    </script>