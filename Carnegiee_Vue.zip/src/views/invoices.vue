<template>
  <div class="db_page">
    <!-- <div class="page_header">
        <h3>Invoices</h3>
      </div> -->
    <div class="payment_invoice">
      <div class="payment_update status pending_payment">
        <h4>Payments Pending</h4>
        <ul>
          <!-- {"pending":{"1":2,"2":0,"3":0,"undefined":null},"fullyPaid":{"1":3,"2":0,"3":0,"undefined":null}} -->
          <li>Per Case - {{ checkProperty(invoiceStats, 'pending', 'perCaseBilling') }}</li>
          <li>Monthly - {{ checkProperty(invoiceStats, 'pending', 'monthly') }}</li>
          <li>Flexible - {{ checkProperty(invoiceStats, 'pending', 'flexible') }}</li>
        </ul>
      </div>
      <div class="payment_update status confirmed">
        <h4>Payments Done</h4>
        <ul>
          <li>Per Case - {{ checkProperty(invoiceStats, 'fullyPaid', 'perCaseBilling') }}</li>
          <li>Monthly - {{ checkProperty(invoiceStats, 'fullyPaid', 'monthly') }}</li>
          <li>Flexible - {{ checkProperty(invoiceStats, 'fullyPaid', 'flexible') }}</li>
        </ul>
      </div>
    </div>
    <div class="filter_sec">
      <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" />
      <simpleSelect :multiple="true" :wrapclass="'req_status'" :optionslist="filterStatusList" :display="true"
        :place-holder="'Status'" :searchable="false" :required="false" :close-on-select="false" :clear-on-select="true"
        v-model="filterSelectedStatuses" :fieldName="'filterStatuses'" :cid="'filterStatuses'" :hideSelected="true"
        @input="applyFilters" />
      <simpleSelect :multiple="true" :wrapclass="'ev_type'" :optionslist="filterEvaluationsList" :display="true"
        :place-holder="'Evaluation Type'" :searchable="false" :required="false" :close-on-select="false"
        :clear-on-select="true" v-model="filterSelectedEvaluations" :fieldName="'filterEvaluations'"
        :cid="'filterEvaluations'" :hideSelected="true" @input="applyFilters" />
      <simpleSelect :multiple="true" :wrapclass="'customer'" :optionslist="filterCustomers" :display="true"
        :place-holder="'Clients'" :searchable="false" :required="false" :close-on-select="false" :clear-on-select="true"
        v-model="filterSelectedCustomers" :fieldName="'filterCustomers'" :cid="'filterCustomers'" :hideSelected="true"
        @input="applyFilters" />

      <button class="filter_btn" v-if="false"><span></span><em>Filters</em></button>
      <!-- <b-dropdown
            text="Filters"
            block
            variant="primary"
            class="filter_dropdown"
            menu-class="w-100" no-caret
          >
          <div class="cases_section">
            <div class="cases-flex">
              <div class="cases_card">
                <h4>Outstanding Cases</h4>
                <div class="cases-list">
                  <ul>
                    <li>
                      <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                      <label for="proceed" class="radio_btn">
                          <div class="check"></div>
                          <p>5 days ago</p>
                      </label>
                    </li>
                    <li>
                      <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                      <label for="proceed" class="radio_btn">
                          <div class="check"></div>
                          <p>4 days ago</p>
                      </label>
                    </li>
                    <li>
                      <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                      <label for="proceed" class="radio_btn">
                          <div class="check"></div>
                          <p>3 days ago</p>
                      </label>
                    </li>
                    <li>
                      <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                      <label for="proceed" class="radio_btn">
                          <div class="check"></div>
                          <p>2 days ago</p>
                      </label>
                    </li>
                    <li>
                      <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                      <label for="proceed" class="radio_btn">
                          <div class="check"></div>
                          <p>Yesterday</p>
                      </label>
                    </li>
                    <li>
                      <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                      <label for="proceed" class="radio_btn">
                          <div class="check"></div>
                          <p>Today</p>
                      </label>
                    </li>
                  </ul>
                  <ul>
                    <li>
                      <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                      <label for="proceed" class="radio_btn">
                          <div class="check"></div>
                          <p>Tomorrow</p>
                      </label>
                    </li>
                    <li>
                      <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                      <label for="proceed" class="radio_btn">
                          <div class="check"></div>
                          <p> 2 days from now</p>
                      </label>
                    </li>
                    <li>
                      <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                      <label for="proceed" class="radio_btn">
                          <div class="check"></div>
                          <p>3 days from now</p>
                      </label>
                    </li>
                    <li>
                      <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                      <label for="proceed" class="radio_btn">
                          <div class="check"></div>
                          <p>4 days from now</p>
                      </label>
                    </li>
                    <li>
                      <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                      <label for="proceed" class="radio_btn">
                          <div class="check"></div>
                          <p>5 days from now</p>
                      </label>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="cases_card">
                <h4>Date Due</h4>
                <div class="date_picker">
                  <p>For a Status (Must put 2 dates - can be the same for 1 day)</p>
                  <div class="d-flex">
                    <div class="start_date">
                      <label>Start Date</label>
                      <date-picker v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
                    </div>
                    <div class="end_date">
                      <label>End Date</label>
                      <date-picker v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
                    </div>
                  </div>
                  <simpleSelect 
                  :multiple="false" :wrapclass="'req_status'"
                  :optionslist="evaluatorList" :display="true"
                  :place-holder="'Select Status'" :searchable="false" :required="false"
                  :close-on-select="true" :clear-on-select="true"  class="mb-0 ass-eval w-100"/>
                </div>
              </div>
              <div class="cases_card">
                <h4>View by Confirmed Date</h4>
                <div class="date_picker">
                  <div class="d-flex">
                    <div class="start_date">
                      <label>Start Date</label>
                      <date-picker v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
                    </div>
                    <div class="end_date">
                      <label>End Date</label>
                      <date-picker v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button class="form-cancel" >Cancel</button>
              <button class="primary_btn md" WS>Submit</button>
            </div> 
          </div>
          </b-dropdown> -->
      <div class="filters_right" v-if="false">
        <button class="add_btn"><span></span><em>Add Invoice</em></button>
      </div>
    </div>
    <div class="invoice_tabs">
      <b-tabs>

        <b-tab v-for="(item, index) in  tabBillingTypes " @click="onTabSelected(item)">
          <template #title>{{ item.name }}</template>
          <div class="table-responsive tab_table invoice_table"
            :class="{ 'tbl_btm_pd': checkProperty(selectedForArchiveList, 'length') > 0 }">

            <table class="table" v-if="checkProperty(invoicesList, 'length') > 0 && !isListLoading">
              <thead>
                <tr>
                  <th>
                    <b-form-checkbox class="table_check" id="selecteAll" v-model="selectedAllForArchive"
                      @change="selectAllforArchive()" name="selecteAll">
                      INVOICE
                    </b-form-checkbox>
                  </th>
                  <th>CLIENT</th>
                  <th>AMOUNT</th>
                  <th>BILL DATE</th>
                  <th class="status_head">Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(item, index) in  invoicesList " v-bind:key="index">
                  <td>
                    <span class="request_id" v-if="checkProperty(item, 'invoiceNo')">
                      <b-form-checkbox :disabled="false && checkProperty(item, 'statusDetails', 'id') != 1"
                        class="table_check" :id="'selected_' + index" v-model="item.selectedForArchive"
                        :name="'selected_' + index" @change="selectForArchive(item)">{{ checkProperty(item, 'invoiceNo')
                        }} </b-form-checkbox></span>
                  </td>
                  <td>
                    <span v-if="checkProperty(item, 'customerDetails', 'name')" class="name">{{ checkProperty(item,
                      'customerDetails', 'name') }}</span>
                  </td>
                  <td>
                    <span
                      v-if="checkProperty(item, 'evaluationDetails', 'quotaPrice') && checkProperty(item.evaluationDetails.quotaPrice, 'total')">{{
                        '$' + checkProperty(item.evaluationDetails.quotaPrice,
                          'total') }}</span>
                  </td>
                  <td><span v-if="checkProperty(item, 'createdOn')">{{ checkProperty(item, 'createdOn') | formatDate
                  }}</span></td>
                  <td>
                    <div class="status-flex">
                      <span :class="checkProperty(item, 'evaluationDetails', 'priorityId') == 2 ? 'rush' : ''">
                        {{ checkProperty(item.evaluationDetails, 'priorityDetails', 'name') }}</span>
                      <span class="status " v-if="checkProperty(item, 'statusDetails', 'name')" v-bind:class="{
                        'pending_payment': checkProperty(item, 'statusDetails', 'id') == 1,
                        'confirmed': [2, 3].indexOf(checkProperty(item, 'statusDetails', 'id')) > -1,
                      }">{{ checkProperty(item, 'statusDetails', 'name') }}</span>

                    </div>
                  </td>
                  <td>
                    <div class="actions">
                      <dropdownHover>
                        <b-dropdown-item @click="getEvaluationDetails(item)">View</b-dropdown-item>
                        <b-dropdown-item @click="downloadInvoice(item)">Download</b-dropdown-item>
                        <b-dropdown-item v-if="checkProperty(item, 'statusDetails', 'id') == 1"
                          @click="updateStatus(item)">Update Status</b-dropdown-item>
                        <b-dropdown-item v-if="checkProperty(item, 'statusDetails', 'id') == 1"
                          @click="sendSingleRemainder(item)">Payment Remider</b-dropdown-item>
                      </dropdownHover>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
            <div class="pagination-sec" v-if="checkProperty(invoicesList, 'length') > 0">
              <div class="per-page">
                <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) +
                  invoicesList.length) +
                  ' of ' + totalCount + ' Results' }}</label>
              </div>
              <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
                @input=" isListLoading = true, updateLoading(true), getInvoices()"></b-pagination>
            </div>
          </div>
          <div v-if="checkProperty(selectedForArchiveList, 'length') > 0" class="footer-bar">
            <button class="primary_btn" :disabled="archiving" @click="sendRemainders">Send Payment Reminder</button>
          </div>
        </b-tab>

      </b-tabs>
      <template v-if="checkProperty(invoicesList, 'length') <= 0">
        <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Invoices' :loading="isListLoading" />
      </template>
    </div>
    <span class="loader" v-if="isDetailsLoading"><img src="@/assets/images/loader.gif"></span>
    <!-- side navbar1 -->
    <b-sidebar id="sidebar-no-header" v-model="showDetailsPopup" aria-labelledby="sidebar-no-header-title"
      sidebar-class="customer-sidenav" title="#INV-3066" right no-header backdrop shadow @change="toggleBodyScrollbar">
      <template #default="{ hide }">
        <span class="loader" v-if="isDetailsLoading"><img src="@/assets/images/loader.gif"></span>
        <div class="sidenav_header">
          <div class="invoice_name">
            <h3>{{ checkProperty(selectedInvoice, 'invoiceNo') }}</h3>
          </div>
          <div class="invoice_activitys">
            <ul>
              <li><button class="invoice_btn" @click="downloadInvoice(selectedInvoice, true)"><img
                    src="@/assets/images/vision.png"></button></li>
              <li><button class="invoice_btn" @click="downloadInvoice(selectedInvoice)"> <img
                    src="@/assets/images/download.png"></button></li>
              <li><button class="invoice_btn" v-if="checkProperty(selectedInvoice, 'statusDetails', 'id') == 1"
                  @click="sendSingleRemainder(selectedInvoice)"><img src="@/assets/images/reminder.png">&nbsp; Send
                  Reminder</button></li>
              <li><button class="invoice_btn status " v-if="checkProperty(selectedInvoice, 'statusDetails', 'name')"
                  v-bind:class="{
                    'pending_payment': checkProperty(selectedInvoice, 'statusDetails', 'id') == 1,
                    'confirmed': [2, 3].indexOf(checkProperty(selectedInvoice, 'statusDetails', 'id')) > -1,
                  }">{{ checkProperty(selectedInvoice, 'statusDetails', 'name') }}</button></li>
            </ul>
            <a class="close" block @click="hide"><img src="@/assets/images/close.svg"></a>
          </div>
        </div>
        <VuePerfectScrollbar>
          <div class="inv-table">
            <ul>
              <li
                v-if="checkProperty(invoiceEvaluation, 'customersDetails', 'companyName') || checkProperty(invoiceEvaluation, 'customersDetails', 'name')">
                <span>CLIENT</span>
                <p><a>{{ checkProperty(invoiceEvaluation, 'customersDetails',
                  'companyName') ? checkProperty(invoiceEvaluation, 'customersDetails',
                    'companyName') : checkProperty(invoiceEvaluation, 'customersDetails', 'name') }}</a></p>
              </li>
              <li v-if="checkProperty(invoiceEvaluation, 'priorityDetails', 'id')">
                <span>Priority</span>
                <p v-if="checkProperty(invoiceEvaluation, 'priorityDetails', 'id') == 2"><img
                    src="@/assets/images/flash.png">{{ checkProperty(invoiceEvaluation, 'priorityDetails', 'name') }}</p>
                <p v-if="checkProperty(invoiceEvaluation, 'priorityDetails', 'id') != 2">{{
                  checkProperty(invoiceEvaluation, 'priorityDetails', 'name') }}</p>
              </li>
              <li
                v-if="checkProperty(selectedInvoice, 'customerDetails', 'billingTypeDetails') && checkProperty(selectedInvoice.customerDetails.billingTypeDetails, 'name')">
                <span>BILLING TYPE</span>
                <p>{{ checkProperty(selectedInvoice.customerDetails, 'billingTypeDetails', 'name') }}</p>
              </li>
            </ul>
            <div class="table-responsive">
              <table class="table invoice_table">
                <thead>
                  <tr>
                    <th>DATE</th>
                    <th>EVALUATIONS</th>
                    <th>PRIORITY</th>
                    <th>AMOUNT</th>
                  </tr>
                </thead>
                <tbody>


                  <tr
                    v-for="(evaluationPrice, indx) in  checkProperty(invoiceEvaluation, 'quotaPrice', 'evaluationPrices') "
                    v-bind:key="indx">
                    <td><span>{{ checkProperty(invoiceEvaluation, 'createdOn') | formatDate }}</span></td>
                    <td>{{ checkProperty(evaluationPrice, 'evaluationTypeName') }}</td>
                    <td><span :class="{ 'rush': checkProperty(invoiceEvaluation, 'priorityDetails', 'id') == 2 }">{{
                      checkProperty(invoiceEvaluation, 'priorityDetails', 'name') }}</span></td>
                    <td>{{ '$' + checkProperty(evaluationPrice, 'price') }}</td>
                  </tr>

                  <tr v-if="checkProperty(invoiceEvaluation, 'quotaPrice', 'total')">
                    <td colspan="4">
                      <div class="total_amount">
                        <p>{{ 'Discount ' + checkProperty(invoiceEvaluation, 'quotaPrice', 'discount') + ' Applied' }}
                        </p>
                        <span>Total Amount</span>{{ '$' + checkProperty(invoiceEvaluation, 'quotaPrice',
                          'total') }}
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div
              v-if="checkProperty(invoiceEvaluation, 'invoiceDetails', 'documents') && checkProperty(invoiceEvaluation.invoiceDetails, 'documents', 'length') > 0">
              <spam style="padding: 20px; color: #272846;
                font-size: 14px;"> Invoice Documents</spam>
              <DocumentsPreview :type="'documents'"
                :documentsList="checkProperty(invoiceEvaluation, 'invoiceDetails', 'documents')"
                :includeDownloadText="false" @download_or_view="viewInvoice" />

            </div>

          </div>
        </VuePerfectScrollbar>
      </template>
    </b-sidebar>

    <b-modal id="update_invoice_modal" dialog-class="update_invoice_modal" centered no-close-on-backdrop>
      <template #modal-header>
        <h6 class="modal-title">
          Update Status
        </h6>
        <a class="close" @click=" $bvModal.hide('update_invoice_modal')"></a>
      </template>
      <template>
        <div class="row">
          <div class="col-md-12">
            <textArea class="mb10" :tplkey="'paymentDetails'" fieldName="paymentDetails" placeHolder="Payment Details"
              v-model="paymentComments" :required="true" :vvas="'Payment Details'"></textArea>
          </div>
        </div>
      </template>
      <template #modal-footer>
        <button class="form-cancel" @click=" $bvModal.hide('update_invoice_modal')">Cancel</button>
        <button class="primary_btn" @click="updatePaymentDetails">Payment Received
          <span class="loader" v-if="updateStatusLoading"><img src="@/assets/images/loader.gif"></span></button>
      </template>
    </b-modal>

    <b-modal id="preview_model" v-model="docPrivew" dialog-class="document_modal"
      :title="checkProperty(selectedFile, 'name')" hide-footer>
      <h2> <img :class="{
        pdf_view_download: docType == 'pdf',
        office_view_download: docType == 'office',
        image_view_download: docType == 'image',
      }" class="download-button" @click="downloads3file({ path: selectedFile.path })"
          src="@/assets/images/download.svg" /></h2>
      <div class="pdf_loader">
        <figure v-if="false" class="loader loader2"><img src="@/assets/images/loader.gif" /></figure>

        <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
        <template v-if="docType == 'office'">
          <div style="height:90vh">

            <div id="placeholder" name="placeholder" style="height:100%"></div>
          </div>
        </template>
        <template v-else-if="docType == 'image'">
          <img :src="docValue" />
        </template>
        <template v-else-if="docType == 'pdf'">
          <div class="pdf" style="height:90vh">

            <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%" width="100%">

            </iframe>
          </div>
        </template>
      </div>
    </b-modal>

  </div>
</template>

<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleSelect from '@/views/forms/simpleSelect.vue';
import dropdownHover from '@/views/forms/dropdownHover.vue';
import DatePicker from 'vue2-datepicker';
import 'vue2-datepicker/index.css';
import JQuery from "jquery";
import VuePerfectScrollbar from 'vue-perfect-scrollbar'
import NoDataFound from "@/views/common/noData.vue";
import textArea from "@/views/forms/textarea.vue";
import DocumentsPreview from '@/views/common/documentsPreview.vue';

export default {
  name: 'dashboard-view',
  components: {
    searchInput,
    simpleSelect,
    dropdownHover, DatePicker,
    VuePerfectScrollbar,
    NoDataFound,
    textArea,
    DocumentsPreview,
  },
  data: () => ({
    time1: null,
    page: 1,
    perpage: 20,
    totalCount: 0,
    currentPage: 1,
    tabBillingTypes: [],
    selectedTab: null,
    invoicesList: [],
    isListLoading: true,
    filterSearch: '',
    selectedInvoice: null,
    invoiceEvaluation: null,
    isDetailsLoading: false,
    showDetailsPopup: false,
    filterStatusList: [],
    filterEvaluationsList: [],
    filterCustomers: [],
    filterSelectedCustomers: null,
    filterSelectedEvaluations: null,
    filterSelectedStatuses: null,
    selectedAllForArchive: false,
    archiving: false,
    selectedForArchiveList: [],
    showUpdateInvoiceStatus: false,
    paymentComments: '',
    updateStatusLoading: false,
    invoiceStats: {
      "pending": { "perCaseBilling": 0, "monthly": 0, "flexible": 0 },
      "fullyPaid": { "perCaseBilling": 0, "monthly": 0, "flexible": 0 }
    },
    docPrivew: false,
    docType: '',
    docValue: '',
    selectedFile: null,
  }),
  methods: {
    toggleBodyScrollbar(visible) {
      const body = document.getElementsByTagName('body')[0];

      if (visible)
        body.classList.add("overflow-hidden");
      else
        body.classList.remove("overflow-hidden");
    },
    gotoPage(path = "/") {
      this.$router.push(path);
    },

    getBillingsType() {
      this.$store.dispatch("getMasterData", 'billing_types')
        .then((res) => {
          //  this.billingTypes = res
          this.tabBillingTypes = res.slice().reverse()
          //  this.filterBillingTypes = res
          if (this.checkProperty(this.tabBillingTypes, 'length') > 0) {
            this.selectedTab = this.tabBillingTypes[0]
            this.getInvoices()
          }
        })
    },

    getInvoices() {
      let statusIds = []
      let billingTypeIds = []
      let typeIds = []
      let customerIds = []

      if (this.filterSelectedStatuses && this.checkProperty(this.filterSelectedStatuses, 'length') > 0) {
        statusIds = this.filterSelectedStatuses.map((item) => item.id)
      }
      if (this.filterSelectedEvaluations && this.checkProperty(this.filterSelectedEvaluations, 'length') > 0) {
        typeIds = this.filterSelectedEvaluations.map((item) => item.id)
      }
      if (this.filterSelectedCustomers && this.checkProperty(this.filterSelectedCustomers, 'length') > 0) {
        customerIds = this.filterSelectedCustomers.map((item) => item._id)
      }
      if (this.checkProperty(this.selectedTab, 'id')) {
        billingTypeIds = [this.checkProperty(this.selectedTab, 'id')]
      }
      let postData =
      {
        "matcher": {
          "title": this.filterSearch,
          "statusIds": statusIds,
          "createdByIds": [],
          "billingTypes": billingTypeIds,
          "customerIds": customerIds,
          "dateRange": [],
          "typeIds": typeIds
        },
        "page": this.page,
        "perpage": this.perpage,
        "sorting": {
          "path": "",
          "order": -1
        }
      }
      this.$store.dispatch("getInvoicesList", postData)
        .then((res) => {
          this.isListLoading = false
          this.updateLoading(false);
          this.invoicesList = res.data.result.list
          if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
            this.totalCount = this.checkProperty(res.data.result, 'totalCount');
          }
          setTimeout(() => {
            this.updateLoading(false);
          })
        })
        .catch((error) => {
          this.invoicesList = []
          this.isListLoading = false
          this.updateLoading(false);
        })
    },
    onTabSelected(selectedItem) {

      this.selectedForArchiveList = [];
      this.selectedAllForArchive = false;

      this.selectedTab = selectedItem

      this.page = 1
      this.invoicesList = []
      this.isListLoading = true
      this.updateLoading(true);
      this.getInvoices();
    },
    applyFilters() {
      this.page = 1
      this.invoicesList = []
      this.isListLoading = true
      this.updateLoading(true);
      this.getInvoices()
    },
    applySearchFilters() {
      this.page = 1
      this.invoicesList = []
      this.isListLoading = true
      this.updateLoading(true);
      if (this.filterSearch && this.filterSearch.length > 0) {
        this.getInvoices()
      }
      if (this.filterSearch == '') {
        this.getInvoices()
      }
    },
    getEvaluationDetails(item, showDetails = true) {
      this.selectedInvoice = item
      if (this.checkProperty(item, 'evaluationDetails', '_id')) {
        let postData =
        {
          "evaluationId": this.checkProperty(item, 'evaluationDetails', '_id'),
        }
        this.$store.dispatch("getEvaluationDetails", postData)
          .then((res) => {
            this.invoiceEvaluation = res.result
            this.isDetailsLoading = false
            if (showDetails) {
              this.showDetailsPopup = true
            }
          })
          .catch((error) => {
            this.isDetailsLoading = false
          })
      }
    },
    getMasterDataList(category) {
      this.$store.dispatch("getMasterData", category)
        .then((res) => {
          if (category == 'payment_status') {
            this.filterStatusList = [...res]
          }
          if (category == 'evaluation_types') {
            this.filterEvaluationsList = [...res]
          }
        })
    },
    getCustomersList() {
      let postData =
      {
        "matcher": {
        },
        "sorting": {
          "path": "createdOn",
          "order": 1
        },
        "getMasterData": true,// if Masterdata required
        "page": 1,
        "perpage": 500,
      }

      this.$store.dispatch("getcustomerList", postData)
        .then((res) => {
          this.filterCustomers = res.data.result.list
        })

    },

    selectForArchive(caseItem) {
      // this.formerrors.msg = '';
      if (this.archiving) {
        return false
      } else {
        this.archiving = false
        if (this.checkProperty(caseItem, 'selectedForArchive')) {
          if (this.selectedForArchiveList.indexOf(caseItem['_id']) <= -1) {
            this.selectedForArchiveList.push(caseItem['_id'])
          }
        } else {
          this.selectedForArchiveList = _.filter(this.selectedForArchiveList, (item) => {
            return item != caseItem['_id']
          })
        }
      }

      this.selectedAllForArchive = false
      if (this.invoicesList.length == this.selectedForArchiveList.length && this.selectedForArchiveList.length > 0) {
        this.selectedAllForArchive = true
      }

    },
    selectAllforArchive() {
      // this.formerrors.msg ='';
      this.selectedForArchiveList = [];
      let isPendingInvoiceExists = false
      _.forEach(this.invoicesList, (item) => {
        item.selectedForArchive = false;
        if (this.selectedAllForArchive) {
          // if (this.checkProperty(item, 'statusDetails', 'id') == 1) {
          item.selectedForArchive = true;
          this.selectedForArchiveList.push(item._id)
          //  }
        }
      })
      if (this.invoicesList.length > 0 && this.invoicesList.length != this.selectedForArchiveList.length) {
        this.selectedAllForArchive = false;
      }
    },

    getInvoiceStats() {
      let postData =
      {
        "matcher": {
          "statusIds": [],
        }
      }
      this.$store.dispatch("getInvoiceStats", postData)
        .then((res) => {
          let stats = res.result
          this.invoiceStats['pending']['perCaseBilling'] = stats.pending[0]["Per Case Billing"]
          this.invoiceStats['fullyPaid']['perCaseBilling'] = stats.fullyPaid[0]["Per Case Billing"]

          this.invoiceStats['pending']['monthly'] = stats.pending[1]["Monthly"] > 0 ? stats.pending[1]["Monthly"] : 0
          this.invoiceStats['fullyPaid']['monthly'] = stats.fullyPaid[1]["Monthly"] > 0 ? stats.fullyPaid[1]["Monthly"] : 0

          this.invoiceStats['pending']['flexible'] = stats.pending[2]["Flexible"] > 0 ? stats.pending[2]["Flexible"] : 0
          this.invoiceStats['fullyPaid']['flexible'] = stats.fullyPaid[2]["Flexible"] > 0 ? stats.fullyPaid[2]["Flexible"] : 0

          // this.invoiceStats

        })
        .catch((error) => {
        })
    },
    sendRemainders() {
      this.isDetailsLoading = true
      let postData =
        { "invoiceIds": this.selectedForArchiveList, }
      this.$store.dispatch("sendInvoiceRemainders", postData)
        .then((response) => {
          this.isDetailsLoading = false
          if (response.error) {
            (response.error)
            Object.assign(this.formerrors, {
              msg: response.error.result
            });
            this.showToster({ message: response.error.result, isError: true });
          } else {
            this.selectedForArchiveList = []
            this.isDetailsLoading = false
            this.selectedAllForArchive = false;
            this.showToster({ message: response.message, isError: false });
            this.applyFilters()
          }
        })
        .catch((error) => {
          this.isDetailsLoading = false
          this.showToster({ message: error, isError: true });
        })
    },
    sendSingleRemainder(selectedItem) {
      this.selectedForArchiveList = []
      this.selectedForArchiveList.push(selectedItem['_id'])
      this.sendRemainders()
    },
    updateStatus(selectedItem) {
      this.selectedInvoice = selectedItem
      this.getEvaluationDetails(selectedItem, false)
      //  this.showUpdateInvoiceStatus = true
      this.$bvModal.show('update_invoice_modal')
    },
    updatePaymentDetails() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          this.updateStatusLoading = true
          let postData = {
            "evaluationId": this.invoiceEvaluation._id,
            "action": "PAYMENT_UPDATED",
            "comments": this.paymentComments,
            "transactionId": "",
            "paymentId": '',

          }
          if (this.checkProperty(this.invoiceEvaluation, 'paymentStatsDetails', '_id')) {
            postData.paymentId = this.checkProperty(this.invoiceEvaluation, 'paymentStatsDetails', '_id')
          }
          this.$store.dispatch("updatePayment", postData)
            .then((response) => {
              this.updateStatusLoading = false
              if (response.error) {
                (response.error)
                Object.assign(this.formerrors, {
                  msg: response.error.result
                });
                this.showToster({ message: response.error.result, isError: true });
              } else {
                this.$bvModal.hide('update_invoice_modal')
                this.showUpdateInvoiceStatus = false
                this.selectedInvoice = null
                this.showToster({ message: response.message, isError: false });
                this.applyFilters()
              }
            })
            .catch((error) => {
              this.updateStatusLoading = false
              this.showToster({ message: error, isError: true });
            })
        }
      })

    },
    downloadInvoice(selectedItem, isView = false) {
      // if (this.checkProperty(selectedItem, 'invoicePath')) {
      //   if (isView) {
      //     let docItem = {
      //       path: this.checkProperty(selectedItem, 'invoicePath'),
      //       name: this.checkProperty(selectedItem, 'fileName')
      //     }
      //     this.selectedFile = docItem
      //     setTimeout(() => {
      //       this.viewInvoice(docItem)
      //     })
      //   } else {
      //     this.downloads3file({ 'path': this.checkProperty(selectedItem, 'invoicePath') })
      //   }
      // }
      // else {
      this.isDetailsLoading = true
      let postData =
      {
        "invoiceId": selectedItem['_id'],
        "download": true,
      }
      this.$store.dispatch("downloadInvoiceFile", postData)
        .then((response) => {
          this.isDetailsLoading = false
          if (response.error) {
            (response.error)
            Object.assign(this.formerrors, {
              msg: response.error.result
            });
            this.showToster({ message: response.error.result, isError: true });
          } else {
            let downloadFilePath = response.result.s3UrlPath
            let fileName = response.result.fileName
            if (isView) {
              let docItem = {
                path: downloadFilePath,
                name: fileName
              }
              this.selectedFile = docItem
              setTimeout(() => {

                this.viewInvoice(docItem)
              })
            } else {
              this.downloads3file({ 'path': downloadFilePath })
            }
            this.applyFilters()
            this.isDetailsLoading = false

          }
        })
        .catch((error) => {
          this.isDetailsLoading = false
          this.showToster({ message: error, isError: true });
        })
      // }


    },
    viewInvoice(docItem) {
      this.docValue = docItem.path;
      this.docType = this.findmsDoctype(docItem["path"], docItem.mimetype);

      // if (this.docType == "office") {
      //   this.docPrivew = true;
      //   setTimeout(() => {
      //     document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
      //     let _editing = false;
      //     var _ob = {}
      //     _ob = {

      //       name: value.name,
      //       evaluationId: this.evaluationDetails._id,
      //       _id: value._id,
      //       "extn": "docx",
      //       "formLetterType": "Letter",
      //       parentId: value._id

      //     }
      //     window.docEditor = new DocsAPI.DocEditor("placeholder2",
      //       {

      //         "document": {
      //           "c": "forcesave",
      //           "fileType": "docx",
      //           "key": value._id,
      //           "userdata": JSON.stringify(_ob),
      //           "title": value.name,
      //           "url": response.data.result.data,
      //           permissions: {
      //             edit: _editing,
      //             download: true,
      //             reader: false,
      //             review: false,
      //             comment: false
      //           }
      //         },

      //         "documentType": "word",
      //         "height": "100%",
      //         "width": "100%",

      //         "editorConfig": {
      //           "userdata": JSON.stringify(_ob),
      //           "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
      //           "customization": {
      //             "logo": {
      //               "image": "https://immibox.com/app/favicon.png",
      //               "imageDark": "https://immibox.com/app/favicon.png",
      //               "url": "https://immibox.com"
      //             },
      //             "anonymous": {
      //               "request": false,
      //               "label": "Guest"
      //             },
      //             "chat": false,
      //             "comments": false,
      //             "compactHeader": false,
      //             "compactToolbar": true,
      //             "compatibleFeatures": false,
      //             "feedback": {
      //               "visible": false
      //             },
      //             "forcesave": true,
      //             "help": false,
      //             "hideNotes": true,
      //             "hideRightMenu": true,
      //             "hideRulers": true,
      //             layout: {
      //               toolbar: {
      //                 "collaboration": false,
      //               },
      //             },
      //             "macros": false,
      //             "macrosMode": "warn",
      //             "mentionShare": false,
      //             "plugins": false,
      //             "spellcheck": false,
      //             "toolbarHideFileName": true,
      //             "toolbarNoTabs": true,
      //             "uiTheme": "theme-light",
      //             "unit": "cm",
      //             "zoom": 100
      //           },
      //         }, events: {
      //           onReady: function () {

      //           },
      //           onDocumentStateChange: function (event) {
      //             var url = event.data;
      //             console.log(event)

      //             if (!event.data) {

      //               if (value.editedDocument) {

      //               }

      //             }
      //           }

      //         }
      //       });
      //   }, 100)
      // }

      // if (this.docType == "pdf") {

      //   // var _vid = value._id;
      //   // if (value.parentId) {
      //   //   _vid = value.parentId;
      //   // }
      //   var viewmode = 1; // Enable edit
      //   viewmode = 0; //Disabled Edit
      //   // if (value.viewmode) {
      //   //   viewmode = 0;
      //   // }
      //   this.docValue = "https://carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(docItem["path"]);
      //   this.docPrivew = true;
      // }
      // if (this.docType == "image") {
      //   this.docPrivew = true;
      // }



      let value = _.cloneDeep(docItem)
      var _self = this;
      this.formSubmited = false;
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }
      this.docValue = "";
      this.docPrivew = false;
      this.docType = this.findmsDoctype(value["path"], value.mimetype);

      if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
        //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
          // "petitionId": value['petitionId'],

          // entityType:value['petitionId']
          "fileName": value.name ? value.name : ''
        };
        // if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
        //   postdata['entityType'] = 'perm'
        // } else {
        //   postdata['entityType'] = 'case'
        // }


        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;
          if (this.docType == "office") {
            this.docPrivew = true;
            setTimeout(() => {
              document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
              let _editing = false;

              // if ([3, 4].indexOf(this.getUserRoleId) > -1) {
              //   _editing = false;
              // }

              // if (value.viewmode) {
              //   _editing = false;
              // }
              var _ob = {}
              // if (value.editedDocument) {
              //   _ob = {

              //     evaluationId: this.evaluationDetails._id,
              //     name: value.name,
              //     _id: value._id,
              //     "extn": "docx",
              //     "formLetterType": "Letter",
              //     parentId: value.parentId
              //   }

              // } else {

              _ob = {

                name: value.name,
                evaluationId: this.evaluationDetails._id,
                _id: value._id,
                "extn": "docx",
                "formLetterType": "Letter",
                parentId: value._id

              }

              //  }


              window.docEditor = new DocsAPI.DocEditor("placeholder2",
                {

                  "document": {
                    "c": "forcesave",
                    "fileType": "docx",
                    "key": value._id,
                    "userdata": JSON.stringify(_ob),
                    "title": value.name,
                    "url": response.data.result.data,
                    permissions: {
                      edit: _editing,
                      download: true,
                      reader: false,
                      review: false,
                      comment: false
                    }
                  },

                  "documentType": "word",
                  "height": "100%",
                  "width": "100%",

                  "editorConfig": {
                    "userdata": JSON.stringify(_ob),
                    "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                    "customization": {
                      "logo": {
                        "image": "https://immibox.com/app/favicon.png",
                        "imageDark": "https://immibox.com/app/favicon.png",
                        "url": "https://immibox.com"
                      },
                      "anonymous": {
                        "request": false,
                        "label": "Guest"
                      },
                      "chat": false,
                      "comments": false,
                      "compactHeader": false,
                      "compactToolbar": true,
                      "compatibleFeatures": false,
                      "feedback": {
                        "visible": false
                      },
                      "forcesave": true,
                      "help": false,
                      "hideNotes": true,
                      "hideRightMenu": true,
                      "hideRulers": true,
                      layout: {
                        toolbar: {
                          "collaboration": false,
                        },
                      },
                      "macros": false,
                      "macrosMode": "warn",
                      "mentionShare": false,
                      "plugins": false,
                      "spellcheck": false,
                      "toolbarHideFileName": true,
                      "toolbarNoTabs": true,
                      "uiTheme": "theme-light",
                      "unit": "cm",
                      "zoom": 100
                    },
                  }, events: {
                    onReady: function () {

                    },
                    onDocumentStateChange: function (event) {
                      var url = event.data;
                      console.log(event)

                      if (!event.data) {

                        if (value.editedDocument) {

                        }

                      }
                    }

                  }
                });
              //this.docValue = encodeURIComponent(response.data.result.data);
            }, 100)
          }

          if (this.docType == "pdf") {

            // this.downloadFile(this.docValue, value.mimetype, value.name)

            // return
            var _vid = value._id;
            if (value.parentId) {
              _vid = value.parentId;
            }
            var viewmode = 1; // Enable edit
            viewmode = 0; //Disabled Edit
            if (value.viewmode) {
              viewmode = 0;
            }
            this.docValue = "https://carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
            console.log(this.docValue)
            this.docPrivew = true;
          }
          if (this.docType == "image") {
            this.docPrivew = true;
          }



        });
      } else {
        this.downloads3file(value);
      }

    },
  },
  mounted() {
    this.isListLoading = true
    this.updateLoading(true);
    this.getBillingsType();
    this.getMasterDataList('payment_status')
    this.getMasterDataList('evaluation_types')
    this.getCustomersList()
    this.getInvoiceStats()
  },

  provide() {
    return {
      parentValidator: this.$validator,
    };
  }
}
</script>