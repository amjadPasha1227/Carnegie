<template>
    <div class="db_page">

        <!-- <div class="page_header">
            <h3>Requests</h3>
            {{ $route['params'] }}
        </div>
         <div class="page_header">
            <h3>Requests</h3>
        </div> -->
        <div class="filter_sec">
            <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" />

            <simpleSelect :multiple="true" :wrapclass="'req_status'" :optionslist="statusList" :display="true"
                :place-holder="'Status'" :searchable="false" :required="false" :close-on-select="false"
                :clear-on-select="true" v-model="filterSelectedStatuses" :fieldName="'filterStatus'" :cid="'filterStatus'"
                :hideSelected="true" @input="checkAndApplyFilters" />
            <simpleSelect :multiple="true" :wrapclass="'priority'" :optionslist="priorityList" :display="true"
                :place-holder="'Priority'" :searchable="false" :required="false" :close-on-select="false"
                :clear-on-select="true" v-model="filterSelectedPriority" :fieldName="'filterPriority'"
                :cid="'filterPriority'" :hideSelected="true" @input="applyFilters" />
            <simpleSelect :multiple="true" :wrapclass="'customer'" :optionslist="customerList" :display="true"
                :place-holder="'Client'" :searchable="false" :required="false" :close-on-select="false"
                :clear-on-select="true" v-model="filterSelectedcustomers" :fieldName="'filterCustomer'"
                :cid="'filterCustomer'" :hideSelected="true" @input="applyFilters" />
            <div class="fliter_area" v-if="false">
                <b-dropdown size="lg" variant="primary" right toggle-class="filter_btn text-decoration-none" no-caret>
                    <template #button-content>
                        <span></span><em>Filters</em>
                    </template>
                    <b-dropdown-form>
                        <div class="dropdown_wrapper">
                            <div class="drpdwn_cnt">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form_group m-0">
                                            <label class="form_label">Due Date</label>
                                            <date-range-picker :maxDate="new Date()" :autoApply="autoApply" :ranges="false"
                                                v-model="selected_createdDateRange"></date-range-picker>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <simpleSelect :multiple="true" :wrapclass="'m-0'" :optionslist="statusList"
                                            :display="true" :place-holder="'Status'" :searchable="false" :required="false"
                                            :close-on-select="false" :clear-on-select="true"
                                            v-model="filterSelectedStatuses" :fieldName="'filterStatus'"
                                            :cid="'filterStatus'" :hideSelected="true" @input="applyFilters"
                                            :label="'Type'" />
                                    </div>
                                </div>
                            </div>
                            <div class="drpdwn_footer">
                                <button class="form-cancel">Cancel</button>
                                <button class="primary_btn sm">Apply</button>
                            </div>
                        </div>
                    </b-dropdown-form>
                </b-dropdown>
            </div>
            <div class="fliter_area" v-if="false">
                <button v-b-toggle.collapse-1 variant="primary" menu-class="w-100"
                    class="filter_btn"><span></span><em>Filters</em></button>
                <b-collapse id="collapse-1" class="mt-2 custom_collapse">
                    <b-card>
                        <div class="cases_section">
                            <div class="cases-flex">

                                <div class="cases_card">
                                    <h4>Date Due</h4>
                                    <div class="d-flex">
                                        <div class="start_date">
                                            <!-- <date-picker v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker> -->
                                            <datepicker :required="true" v-model="dueDate" fieldName="startDate"
                                                label="Star Date" :dateEnableFrom="new Date()" />

                                        </div>
                                        <div class="end_date">
                                            <!-- <date-picker v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker> -->
                                            <datepicker :required="true" v-model="dueDate" fieldName="endDate"
                                                label="End Date" :dateEnableFrom="new Date()" />

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="modal-footer pb-3">
                                <button class="form-cancel me-4">Cancel</button>
                                <button class="primary_btn md" WS>Submit</button>
                            </div>
                        </div>
                    </b-card>
                </b-collapse>
            </div>
            <div class="filters_right" v-if="canCreateEvaluation(getUserRoleId)">
                <button class="add_btn" @click="gotoPage('/create-evaluation')"><span></span><em>Create
                        Request</em></button>
            </div>
        </div>
        <div class="table-responsive">
            <template v-if="checkProperty(evaluationsList, 'length') <= 0">
                <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users'
                    :loading="isListLoading" />
            </template>
            <table class="table accordian_table" v-if="checkProperty(evaluationsList, 'length') > 0 && !isListLoading">
                <thead>
                    <tr>
                        <th>
                            <!-- <th> -->
                            <b-form-checkbox v-if="getUserRoleId == 8" class="table_check inline" id="selecteAll"
                                v-model="selectedAllForArchive" @change="selectAllforArchive()" name="selecteAll">
                            </b-form-checkbox>

                            <b-form-checkbox v-if="[1, 3, 4].indexOf(getUserRoleId) > -1" class="table_check inline"
                                id="selectAllForCancel" v-model="selectedAllForCancel" @change="selectAllforCancel()"
                                name="selectAllForCancel">
                            </b-form-checkbox>

                            <span @click="sortMe('createdOn')"
                                v-bind:class="{ 'sort_ascending': sortKeys['createdOn'] == 1, 'sort_descending': sortKeys['createdOn'] != 1 }">Requested</span>

                            <!-- <span
                                v-bind:class="{ 'sort_ascending': sortKeys['createdOn'] == 1, 'sort_descending': sortKeys['createdOn'] != 1 }">Requested
                                Date</span> -->
                        </th>

                        <th v-if="canShowConfirmedDate" @click="sortMe('dateOfConfirmation')"><span
                                v-bind:class="{ 'sort_ascending': sortKeys['dateOfConfirmation'] == 1, 'sort_descending': sortKeys['dateOfConfirmation'] != 1 }">Confirmed</span>
                        </th>

                        <th @click="sortMe('requestId')"><span
                                v-bind:class="{ 'sort_ascending': sortKeys['requestId'] == 1, 'sort_descending': sortKeys['requestId'] != 1 }">Request
                                Id</span></th>
                        <th>Evaluations</th>
                        <th>Payment</th>
                        <th>Beneficiary</th>
                        <th v-if="canShowConfirmedDate" @click="sortMe('dueDate')"><span
                                v-bind:class="{ 'sort_ascending': sortKeys['dueDate'] == 1, 'sort_descending': sortKeys['dueDate'] != 1 }">Due
                                On</span></th>
                        <!-- <th v-if="[8].indexOf(getUserRoleId) < 0">Priority</th>
                        <th v-if="[8].indexOf(getUserRoleId) > -1">Client</th> -->
                        <th>Priority</th>
                        <th>Client</th>
                        <th>Status</th>
                        <!-- <th>Actions</th> -->
                    </tr>
                </thead>
                <tbody>
                    <template v-for="(item, index) in evaluationsList">
                        <!-- @click="toggleOpened(item)"  -->
<tr :class="{ 
    'open': item['isOpened'], 
    'paidtr': getUserRoleId == 8 && item['paymentStatusDetails'] && checkProperty(item, 'paymentStatusDetails', 'id') == 2, 
    'notpaidtr': getUserRoleId == 8 && (!item['paymentStatusDetails'] || checkProperty(item, 'paymentStatusDetails', 'id') != 2) ,
    'promotr':  (item['promocode'] && checkProperty(item, 'promocode') != '' && checkProperty(item, 'promocode') != ' ') 
}">                            <td>
                                <div class="d-flex">
                                    <b-form-checkbox v-if="getUserRoleId == 8"
                                        :disabled="checkProperty(item, 'paymentStatus') == 2" class="table_check"
                                        :id="'selected_' + index" v-model="item.selectedForArchive"
                                        :name="'selected_' + index" @change="selectForArchive(item)"></b-form-checkbox>

                                    <b-form-checkbox v-if="[1, 3, 4].indexOf(getUserRoleId) > -1"
                                        :disabled="[17, 16].indexOf(checkProperty(item, 'statusDetails', 'id')) > -1"
                                        class="table_check" :id="'cancelselected_' + index" v-model="item.selectedForCancel"
                                        :name="'cancelselected_' + index" @change="selectForCancel(item)"></b-form-checkbox>

                                    <span v-if="getUserRoleId == 8" @click="goToEvaluationDetaillPage(item)"> {{
                                        checkProperty(item,
                                            'createdOn') | formatListDate }}</span>
                                    <span v-else @click="goToEvaluationDetaillPage(item)">{{ checkProperty(item,
                                        'createdOn') | formatListDate }}</span>
                                </div>
                            </td>
                            <td v-if="canShowConfirmedDate"><span>{{ checkProperty(item, 'dateOfConfirmation') | formatListDate
                            }}</span></td>

                            <td>
                                <span class="request_id" @click="goToEvaluationDetaillPage(item)">{{ item.requestId
                                }}</span>
                            </td>
                            <td class="tw-90">
                            <div v-if="checkProperty(item, 'docsConfig', 'length') > 0" class="evalution_type">
                            <span 
                                v-for="(evaluationItem, indx) in checkProperty(item, 'docsConfig')" 
                                @click="goToEvaluationDetaillPage(item)"
                            >
                                <!-- Render comma before every item except the first one -->
                                <template v-if="indx > 0">, </template>

                                {{ getEvaluationShortName(evaluationItem) }}
                            </span>
                        </div>

                            </td>
                            <td>
                                <span v-if="checkProperty(item, 'paymentStatusDetails', 'name')" class="status "
                                    v-bind:class="{
                                        'pending_payment': checkProperty(item, 'paymentStatusDetails', 'id') == 1,
                                        'delivered': [2].indexOf(checkProperty(item, 'paymentStatusDetails', 'id')) > -1
                                    }">
                                    {{ checkProperty(item, 'paymentStatusDetails', 'name') }}</span>
                            </td>
                            <td>
                                <div class="beneficiary_sec">
                                    <span>{{ checkProperty(item, 'beneficiaryInformation') | formatFullname }}</span>
                                </div>
                            </td>
                            <td v-if="canShowConfirmedDate"><span>{{ checkProperty(item, 'dueDate') | formatListDate
                            }}</span></td>
                            <td>
                                <span :class="checkProperty(item, 'priorityId') == 2 ? 'rush' : ''">{{
                                    checkProperty(item, 'priorityDetails', 'name') }}</span>
                            </td>

                            <td>
                              <div class="beneficiary_sec">
                                <span>{{ checkProperty(item, 'customersDetails', 'companyName') ? checkProperty(item,
                                    'customersDetails', 'companyName')
                                    : checkProperty(item, 'firm') }}</span>
                                     </div> 
                            </td>

                            <td><span class="status " v-bind:class="{
                                'requested': [1, 10, 15].indexOf(checkProperty(item, 'statusDetails', 'id')) > -1,
                                'reviewed': [2, 5, 6, 8, 9, 12].indexOf(checkProperty(item, 'statusDetails', 'id')) > -1,
                                'pending_payment': checkProperty(item, 'statusDetails', 'id') == 4,
                                'waiting_for_invoice': checkProperty(item, 'statusDetails', 'id') == 7,
                                'delivered': [3, 16].indexOf(checkProperty(item, 'statusDetails', 'id')) > -1,
                                'canceled': [17].indexOf(checkProperty(item, 'statusDetails', 'id')) > -1
                            }">{{ checkProperty(item, 'statusDetails', 'name') }}</span></td>

                            <!-- <td>
                                <span v-if="[17, 16].indexOf(checkProperty(item, 'statusDetails', 'id')) < 0"
                                    class="status cancel_req" @click="openReqCancelPopup(item)"> Cancel</span>
                            </td> -->
                            <td class="td_plus " v-bind:class="{
                                'disabled': ([1, 2].indexOf(checkProperty(item, 'statusDetails', 'id')) > -1 && !checkProperty(item, 'specialNotes'))
                            }" @click="toggleOpened(item)">
                                <span><img src="@/assets/images/down-chevron.svg"></span>
                            </td>
                        </tr>
                        <!-- v-if="opened.includes(row.id)" -->
                        <tr class="expanded" v-if="item['isOpened']">
                            <td colspan="11">
                                <div class="table_accordian_cnt">
                                    <ul>
                                        <li v-if="checkProperty(item, 'assignedToProfessorDetails', 'name')">
                                            <label>Professor</label>
                                            <p>{{ checkProperty(item, 'assignedToProfessorDetails', 'name') }}</p>
                                        </li>
                                        <li v-if="checkProperty(item, 'invoiceNo')">
                                            <label>Invoice No</label>
                                            <p>{{ checkProperty(item, 'invoiceNo') }}</p>
                                        </li>

                                        <li v-if="checkProperty(item, 'specialNotes')" class="discription">
                                            <label>Client Notes</label>
                                            <p v-html="checkProperty(item, 'specialNotes')"></p>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    </template>
                </tbody>
            </table>
            <div class="pagination-sec" v-if="checkProperty(evaluationsList, 'length') > 0 && !isListLoading">
                <div class="per-page">
                    <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) +
                        evaluationsList.length) +
                        ' of ' + totalCount + ' Results' }}</label>
                </div>
                <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
                    @input="onPageChange"></b-pagination>
            </div>
        </div>
        <span class="loader" v-if="isDetailsLoading"><img src="@/assets/images/loader.gif"></span>
        <div v-if="checkProperty(selectedForArchiveList, 'length') > 0" class="footer-bar">
            <button class="primary_btn" :disabled="archiving" @click="updatePaymentStatus">Mark as Paid</button>
        </div>

        <div v-if="checkProperty(selectedForCancelList, 'length') > 0" class="footer-bar">
            <button class="req-cancel-btn cancel_all" :disabled="canceling" @click="openReqCancelPopup">Cancel
                Requests</button>
        </div>


        <b-modal id="cancel_comments_model" v-model="isShowReqCancelPopup" dialog-class="addnotes_model" centered
            no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Cancel Requests</h6>
                <a class="close" @click="closeReqCancelPopup"></a>
            </template>
            <template>
                <div class="row">
                    <!-- <p class="confirm_msg">Are you sure you
                        want to cancel the selected requests?</p> -->
                    <p class="confirm_msg">{{ 'Are you sure you want to cancel?' }}</p>
                </div>
            </template>
            <template #modal-footer>
                <button class="form-cancel me-4" @click="closeReqCancelPopup">No</button>
                <button class="primary_btn md" @click="onEvaluationRequestCancel">Yes
                    <span class="loader" v-if="cancelLoading"><img src="@/assets/images/loader.gif"></span></button>
            </template>
        </b-modal>
    </div>
</template>

<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleSelect from '@/views/forms/simpleSelect.vue';
import NoDataFound from "@/views/common/noData.vue";
import datepicker from '@/views/forms/datePicker.vue';
//import DatePicker from 'vue2-datepicker';
import 'vue2-datepicker/index.css';
import DateRangePicker from "vue2-daterange-picker";
import 'vue2-daterange-picker/dist/vue2-daterange-picker.css'
import textArea from "@/views/forms/textarea.vue";

import _ from "lodash";
import axios from 'axios'


export default {
    name: 'dashboard-view',
    components: {
        searchInput,
        simpleSelect,
        NoDataFound,
        datepicker,
        DateRangePicker,
        textArea,
    },
    data: () => ({
        isListLoading: true,
        page: 1,
        perpage: 20,
        totalCount: 0,
        currentPage: 1,
        statusList: [],
        priorityList: [],
        customerList: [],
        evaluationsList: [],
        filterSelectedStatuses: [],
        filterSelectedPriority: [],
        filterSelectedcustomers: [],
        filterSearch: '',
        filterStartDate: null,
        filterEndDate: null,
        sortKeys: {
            "evaluations.createdOn": -1,
            "evaluations.updatedOn": -1,
            "evaluations.requestId": 1,
            "evaluations.dueDate": 1,
            "evaluations.dueDate": 1,
            "evaluations.dateOfConfirmation":1,
        },
        sortKey: { "evaluations.updatedOn": -1 },
        autoApply: "",
        selected_createdDateRange: ["", ""],
        evaluationTypes: [],
        selectedAllForArchive: false,
        archiving: false,
        selectedForArchiveList: [],
        isDetailsLoading: false,
        cancelTokenSource: null,
        isShowReqCancelPopup: false,
        selectedEval: null,
        cancelLoading: false,
        cancelComments: '',
        selectedAllForCancel: false,
        canceling: false,
        selectedForCancelList: [],

    }),
    methods: {

        toggleOpened(val) {
            if (val) {
                if ([1, 2].indexOf(this.checkProperty(val, 'statusDetails', 'id')) > -1
                    && !this.checkProperty(val, 'specialNotes')) {
                    return

                }
                _.forEach(this.evaluationsList, (itm) => {
                    if (itm['_id'] != val['_id']) {
                        itm['isOpened'] = false;
                    }
                    else {
                        itm['isOpened'] = !itm['isOpened'];
                    }
                })
                //     }
            }
        },
        sortMe(sort_key = '') {
            if (sort_key != '') {
                this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1
                this.sortKey = {};
                this.sortKey = { "path": sort_key, "order": this.sortKeys[sort_key] }
                //  this.evaluationsList = []
                //  this.applyFilters();

                this.page = 1
                this.getEvaluations()
            }
        },
        gotoPage(path = "/") {
            localStorage.setItem('subMenuId', this.$store.state.selectedRequestsMenu)
            this.$router.push(path);
        },
        goToEvaluationDetaillPage(data) {
            if (this.checkProperty(data, '_id')) {
                localStorage.setItem('subMenuId', this.$store.state.selectedRequestsMenu)
                let routedId = this.checkProperty(data, '_id')
                let path = "/requestdetails/" + routedId;
                // if (this.encodedString != '') {
                //     path = path + "?filter=" + this.encodedString;
                // }
                this.$router.push(path);
            }
        },
        getEvaluations() {
            if (this.cancelTokenSource) {
                this.cancelTokenSource.abort()
            }

            let statusIds = []
            let priorityIds = []
            let customerIds = []

            if (this.filterSelectedStatuses && this.checkProperty(this.filterSelectedStatuses, 'length') > 0) {
                statusIds = this.filterSelectedStatuses.map((item) => item.id)
                if (statusIds.indexOf(3) > -1) {
                    if (statusIds.indexOf(5) < 0) {
                        statusIds.push(5)
                    }
                    // if (statusIds.indexOf(7) < 0) {
                    //     statusIds.push(7)
                    // }
                    if (statusIds.indexOf(8) < 0) {
                        statusIds.push(8)
                    }
                }

                if (statusIds.indexOf(1) > -1) {
                    if (statusIds.indexOf(2) < 0) {
                        statusIds.push(2)
                    }
                }
            }
            if (this.$store.state.selectedRequestsMenu == "ALL" && this.checkProperty(this.filterSelectedStatuses, 'length') == 0) {
                statusIds = this.getConfirmedStatusesList.map((item) => item.id)
            }

            if (this.filterSelectedPriority && this.checkProperty(this.filterSelectedPriority, 'length') > 0) {
                priorityIds = this.filterSelectedPriority.map((item) => item.id)
            }
            if (this.filterSelectedcustomers && this.checkProperty(this.filterSelectedcustomers, 'length') > 0) {
                customerIds = this.filterSelectedcustomers.map((item) => item._id)
            }

            let postData =
            {
                "matcher": {
                    "searchString": this.filterSearch,
                    "evaluationTypeIds": [],
                    "statusIds": statusIds,
                    "locationIds": [],
                    "priorityIds": priorityIds,
                    "customerIds": customerIds,
                    "createdDateRange": []
                },
                "sorting": {
                    "path": "updatedOn",
                    "order": -1
                },
                "page": this.page,
                "perpage": this.perpage,
            }
            postData['sorting'] = this.sortKey
            this.cancelTokenSource = new AbortController();
            const signal = this.cancelTokenSource.signal;

            this.$store.dispatch("getEvaluationsList", { postdata: postData, cancelTokenSource: signal })
                //  this.$store.dispatch("getEvaluationsList", postData)
                .then((res) => {
                    let list = res.data.result.list
                    _.forEach(list, (item) => {
                        item = Object.assign(item, { 'isOpened': false })
                    })
                    this.evaluationsList = list
                    this.isListLoading = false
                    this.updateLoading(false);
                    if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
                        this.totalCount = this.checkProperty(res.data.result, 'totalCount');
                    }
                    setTimeout(() => {
                        this.updateLoading(false);
                    })
                })
                .catch((error) => {
                    console.log('#######-------Request canceled:', error);
                    this.evaluationsList = []
                    if (error !== 'canceled') {
                        this.isListLoading = false
                        this.updateLoading(false);
                    }


                })
        },
        applyFilters() {
            this.selectedAllForArchive = false
            this.selectedAllForCancel = false
            this.isListLoading = true
            this.updateLoading(true);
            this.page = 1
            this.getEvaluations()
        },
        applySearchFilters() {
            this.page = 1
            this.selectedAllForArchive = false
            this.selectedAllForCancel = false
            if (this.filterSearch && this.filterSearch.length > 2) {
                this.isListLoading = true
                this.updateLoading(true);
                this.getEvaluations()
            }
            if (this.filterSearch == '') {
                this.isListLoading = true
                this.updateLoading(true);
                this.getEvaluations()
            }
        },
        getMasterDataList(category) {
            this.$store.dispatch("getMasterData", category)
                .then((res) => {
                    if (category == 'evaluation_status') {
                        this.statusList = _.filter(res, (item) => {
                            return ([4, 5, 6, 7, 11].indexOf(item.id) < 0)
                        });
                        if (this.$store.state.selectedRequestsMenu != "ALL") {
                            this.filterSelectedStatuses = [];
                            let statusId = parseInt(_.cloneDeep(this.$store.state.selectedRequestsMenu));

                            if (this.statusList.length > 0) {
                                this.filterSelectedStatuses = _.filter(this.statusList, { "id": statusId });
                            }

                        } else {
                            // this.filterSelectedStatuses = [];
                            // if (this.statusList.length > 0) {
                            //     this.filterSelectedStatuses = _.filter(this.statusList, { "id": 3 });
                            // }
                        }
                    }
                    if (category == 'evaluation_priority') {
                        this.priorityList = res
                    }
                })
        },
        getCustomersList() {
            let postData =
            {
                "matcher": {
                },
                "sorting": {
                    "path": "createdOn",
                    "order": 1
                },
                "getMasterData": true,// if Masterdata required
                "page": 1,
                "perpage": 500,
            }

            this.$store.dispatch("getcustomerList", postData)
                .then((res) => {
                    this.customerList = res.data.result.list
                })

        },
        checkAndApplyFilters() {
            setTimeout(() => {
                if (this.checkProperty(this.filterSelectedStatuses, 'length') == 1) {
                    let statusIds = this.filterSelectedStatuses.map((item) => item.id)
                    if (this.checkProperty(statusIds, 'length') > 0 && [1, 3, 9, 10, 12, 14, 15, 16].indexOf(statusIds[0]) > -1) {
                        this.$store.commit("setRequestsMenu", statusIds[0])
                    } else {
                        this.$store.commit("setRequestsMenu", statusIds[0])
                        // this.applyFilters()
                    }
                } else if (this.checkProperty(this.filterSelectedStatuses, 'length') == 0) {
                    this.$store.commit("setRequestsMenu", "ALL")
                    // this.applyFilters()
                } else {
                    this.applyFilters()
                }
            })
        },

        getEvaluationTypes() {
            this.$store.dispatch("getMasterData", 'evaluation_types')
                .then((res) => {
                    this.evaluationTypes = res
                })
        },
        getEvaluationShortName(evaluationItem) {
            if (this.checkProperty(this.evaluationTypes, 'length') > 0) {
                let shortName = ""
                _.filter(this.evaluationTypes, (evluation) => {
                    if (this.checkProperty(evluation, 'id') == evaluationItem.evaluationTypeId) {
                        shortName = evluation.shortName
                        return
                    }
                })
                if (this.checkProperty(shortName, 'length') == 0) {
                    shortName = evaluationItem.evaluationTypeName
                }
                return shortName
            }
            return evaluationItem.evaluationTypeName

        },
        selectForArchive(caseItem) {
            // this.formerrors.msg = '';
            if (this.archiving) {
                return false
            } else {
                this.archiving = false
                if (this.checkProperty(caseItem, 'selectedForArchive')) {
                    if (this.selectedForArchiveList.indexOf(caseItem['_id']) <= -1) {
                        this.selectedForArchiveList.push(caseItem['_id'])
                    }
                } else {
                    this.selectedForArchiveList = _.filter(this.selectedForArchiveList, (item) => {
                        return item != caseItem['_id']
                    })
                }
            }

            this.selectedAllForArchive = false
            let unpaidEvalList = _.filter(this.evaluationsList, (item) => {
                return this.checkProperty(item, 'paymentStatusDetails', 'id') !== 2
            })
            // if (this.evaluationsList.length == this.selectedForArchiveList.length && this.selectedForArchiveList.length > 0) {
            if (unpaidEvalList.length > 0 && unpaidEvalList.length == this.selectedForArchiveList.length) {
                this.selectedAllForArchive = true
            }

        },
        selectAllforArchive() {

            // this.formerrors.msg ='';
            this.selectedForArchiveList = [];
            let isPendingInvoiceExists = false
            _.forEach(this.evaluationsList, (item) => {
                item.selectedForArchive = false;
                if (this.selectedAllForArchive) {
                    if (this.checkProperty(item, 'paymentStatusDetails', 'id') !== 2) {
                        item.selectedForArchive = true;
                        this.selectedForArchiveList.push(item._id)
                    }
                }
            })

            let unpaidEvalList = _.filter(this.evaluationsList, (item) => {
                return this.checkProperty(item, 'paymentStatusDetails', 'id') !== 2
            })
            // if (this.evaluationsList.length > 0 && this.evaluationsList.length != this.selectedForArchiveList.length) {
            if (unpaidEvalList.length > 0 && unpaidEvalList.length != this.selectedForArchiveList.length) {
                this.selectedAllForArchive = false;
            }
        },

        updatePaymentStatus() {

            this.isDetailsLoading = true
            let postData =
                { "evaluationIds": this.selectedForArchiveList, }
            this.$store.dispatch("paymentStatusBulkUpdate", postData)
                .then((response) => {
                    this.isDetailsLoading = false
                    if (response.error) {
                        (response.error)
                        Object.assign(this.formerrors, {
                            msg: response.error.result
                        });
                        this.showToster({ message: response.error.result, isError: true });
                    } else {
                        this.selectedForArchiveList = []
                        this.evaluationsList = []
                        this.isDetailsLoading = false
                        this.selectedAllForArchive = false;
                        this.showToster({ message: response.message, isError: false });
                        this.applyFilters()
                    }
                })
                .catch((error) => {
                    this.isDetailsLoading = false
                    this.showToster({ message: error, isError: true });
                })




        },

        selectForCancel(caseItem) {
            // this.formerrors.msg = '';
            if (this.canceling) {
                return false
            } else {
                this.canceling = false
                if (this.checkProperty(caseItem, 'selectedForCancel')) {
                    if (this.selectedForCancelList.indexOf(caseItem['_id']) <= -1) {
                        this.selectedForCancelList.push(caseItem['_id'])
                    }
                } else {
                    this.selectedForCancelList = _.filter(this.selectedForCancelList, (item) => {
                        return item != caseItem['_id']
                    })
                }
            }

            this.selectedAllForCancel = false
            let unpaidEvalList = _.filter(this.evaluationsList, (item) => {
                return [17, 16].indexOf(this.checkProperty(item, 'statusDetails', 'id')) < 0
            })

            // if (this.evaluationsList.length == this.selectedForArchiveList.length && this.selectedForArchiveList.length > 0) {
            if (unpaidEvalList.length > 0 && unpaidEvalList.length == this.selectedForCancelList.length) {
                this.selectedAllForCancel = true
            }

        },
        selectAllforCancel() {

            // this.formerrors.msg ='';
            this.selectedForCancelList = [];
            _.forEach(this.evaluationsList, (item) => {
                item.selectedForCancel = false;
                if (this.selectedAllForCancel) {
                    if ([17, 16].indexOf(this.checkProperty(item, 'statusDetails', 'id')) < 0) {
                        item.selectedForCancel = true;
                        this.selectedForCancelList.push(item._id)
                    }
                }
            })

            let unpaidEvalList = _.filter(this.evaluationsList, (item) => {
                return [17, 16].indexOf(this.checkProperty(item, 'statusDetails', 'id')) < 0
            })
            // if (this.evaluationsList.length > 0 && this.evaluationsList.length != this.selectedForArchiveList.length) {
            if (unpaidEvalList.length > 0 && unpaidEvalList.length != this.selectedForCancelList.length) {
                this.selectedAllForCancel = false;
            }
        },
        openReqCancelPopup() {
            this.cancelLoading = false
            this.cancelComments = ""
            this.isShowReqCancelPopup = true
        },
        closeReqCancelPopup() {
            this.selectedEval = null
            this.cancelLoading = false
            this.isShowReqCancelPopup = false
        },
        onEvaluationRequestCancel() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.cancelLoading = true
                    let postData = {
                        "evaluationIds": this.selectedForCancelList,
                    }
                    this.$store.dispatch("cancelBulkRequests", postData)
                        .then((response) => {
                            this.cancelLoading = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                this.selectedForCancelList = []
                                this.evaluationsList = []
                                this.selectedAllForCancel = false;
                                this.closeReqCancelPopup()
                                this.showToster({ message: response.message, isError: false });
                                this.applyFilters()
                            }
                        })
                        .catch((error) => {
                            this.cancelLoading = false
                            this.closeReqCancelPopup()
                            this.showToster({ message: error, isError: true });
                        })
                }
            })
        },
        onPageChange() {
            this.selectedAllForCancel = false
            this.selectedAllForArchive = false
            this.selectedForCancelList = []
            this.selectedForArchiveList = []
            this.evaluationsList = []
            this.isListLoading = true
            this.updateLoading(true)
            this.getEvaluations()
        }

    },
    mounted() {
        this.sortKey = { "path": 'updatedOn', "order": -1 };

        this.getMasterDataList('evaluation_status')
        this.getMasterDataList('evaluation_priority')
        this.getCustomersList()
        this.getEvaluationTypes()


        // if (this.checkProperty(this.$route.params, 'statusId')) {
        //     this.filterSelectedStatuses = [this.checkProperty(this.$route.params, 'statusId')]
        // }
        let self = this;

        this.$watch("$store.state.selectedRequestsMenu", (newValue, oldValue) => {
            self.filterSelectedStatuses = [];
            if (self.$store.state.selectedRequestsMenu != "ALL") {
                self.filterSelectedStatuses = [];
                let statusId = parseInt(_.cloneDeep(self.$store.state.selectedRequestsMenu));
                if (self.checkProperty(self.statusList, 'length') < 1) {
                    self.statusList = self.getOfflineEvalStatusList
                }
                if (self.statusList.length > 0) {
                    self.filterSelectedStatuses = _.filter(self.statusList, { "id": statusId });
                }

            } else {
                // self.filterSelectedStatuses = [];
                // if (self.statusList.length > 0) {
                //     self.filterSelectedStatuses = _.filter(self.statusList, { "id": 3 });
                // }
            }
            self.evaluationsList = []
            self.isListLoading = true
            self.updateLoading(true);
            setTimeout(() => {
                self.sortKey = { "evaluations.updatedOn": -1 },
                    self.page = 1
                self.applyFilters()
            }, 500)
        })


        setTimeout(() => {
            if (this.$store.state.selectedRequestsMenu != "ALL") {
                this.filterSelectedStatuses = [];
                let statusId = parseInt(_.cloneDeep(this.$store.state.selectedRequestsMenu));
                if (this.checkProperty(this.statusList, 'length') < 1) {
                    this.statusList = this.getOfflineEvalStatusList
                }
                if (this.statusList.length > 0) {
                    this.filterSelectedStatuses = _.filter(self.statusList, { "id": statusId });
                }
            }
            this.applyFilters()
        }, 500)


        // self.getEvaluations()

    },
    computed: {
        getConfirmedStatusesList() {
            if (this.checkProperty(this.statusList, 'length') < 1) {
                this.statusList = this.getOfflineEvalStatusList
            }
            if (this.checkProperty(this.statusList, 'length') > 0) {
                let filerStatuses = _.filter(this.statusList, (status) => {
                    if (this.checkProperty(status, 'id') !== 1 && this.checkProperty(status, 'id') !== 2 && this.checkProperty(status, 'id') !== 17) {
                        return { "id": status.id }
                    }
                })
                return filerStatuses

            }
            return []
        },

        canShowConfirmedDate() {
            if (this.checkProperty(this.filterSelectedStatuses, 'length') == 1) {
                if (this.checkProperty(this.filterSelectedStatuses[0], 'id') == 1
                    || this.checkProperty(this.filterSelectedStatuses[0], 'id') == 2) {
                    return false
                }
            }

            if (this.checkProperty(this.filterSelectedStatuses, 'length') == 2) {
                let filerStatuses = this.filterSelectedStatuses.map((item) => item.id)
                if (filerStatuses.indexOf(1) > -1 && filerStatuses.indexOf(2) > -1) {
                    return false
                }
            }

            return true
        }



    },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    created() {

    },
}
</script>