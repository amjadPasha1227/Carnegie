<template>
  <div class="db_page">

    <div class="filter_sec">
      <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" />
      <!-- <b-dropdown  
          id="dropdown-form" 
          right 
          ref="dropdown"
          text="Filters"
          block
          variant="primary"
          class="filter_dropdown" no-caret
        >
        <b-dropdown-form>
      </b-dropdown-form> 
      </b-dropdown>-->
      <div class="filters_right">
        <div class="fliter_area">
          <button variant="primary" class="add_btn" @click="openAddLabelsPopup"><span></span> <em>Labels</em></button>
          <!-- <button v-if="false" v-b-toggle.collapse-1 variant="primary" class="filter_btn"><span></span><em>Filters</em></button>
          <b-collapse id="collapse-1" class="mt-2">
            <b-card>
              <div class="cases_section">
                <div class="cases-flex">
                  <div class="cases_card">
                    <h4>Outstanding Cases</h4>
                    <div class="cases-list">
                      <ul>
                        <li>
                          <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                          <label for="proceed" class="radio_btn">
                            <div class="check"></div>
                            <p>5 days ago</p>
                          </label>
                        </li>
                        <li>
                          <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                          <label for="proceed" class="radio_btn">
                            <div class="check"></div>
                            <p>4 days ago</p>
                          </label>
                        </li>
                        <li>
                          <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                          <label for="proceed" class="radio_btn">
                            <div class="check"></div>
                            <p>3 days ago</p>
                          </label>
                        </li>
                        <li>
                          <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                          <label for="proceed" class="radio_btn">
                            <div class="check"></div>
                            <p>2 days ago</p>
                          </label>
                        </li>
                        <li>
                          <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                          <label for="proceed" class="radio_btn">
                            <div class="check"></div>
                            <p>Yesterday</p>
                          </label>
                        </li>
                        <li>
                          <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                          <label for="proceed" class="radio_btn">
                            <div class="check"></div>
                            <p>Today</p>
                          </label>
                        </li>
                      </ul>
                      <ul>
                        <li>
                          <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                          <label for="proceed" class="radio_btn">
                            <div class="check"></div>
                            <p>Tomorrow</p>
                          </label>
                        </li>
                        <li>
                          <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                          <label for="proceed" class="radio_btn">
                            <div class="check"></div>
                            <p> 2 days from now</p>
                          </label>
                        </li>
                        <li>
                          <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                          <label for="proceed" class="radio_btn">
                            <div class="check"></div>
                            <p>3 days from now</p>
                          </label>
                        </li>
                        <li>
                          <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                          <label for="proceed" class="radio_btn">
                            <div class="check"></div>
                            <p>4 days from now</p>
                          </label>
                        </li>
                        <li>
                          <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                          <label for="proceed" class="radio_btn">
                            <div class="check"></div>
                            <p>5 days from now</p>
                          </label>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="cases_card">
                    <h4>Date Due</h4>
                    <div class="date_picker">
                      <p>For a Status (Must put 2 dates - can be the same for 1 day)</p>
                      <div class="d-flex">
                        <div class="start_date">
                          <label>Start Date</label>
                          <date-picker v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
                        </div>
                        <div class="end_date">
                          <label>End Date</label>
                          <date-picker v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
                        </div>
                      </div>
                      <simpleSelect :multiple="false" :wrapclass="'req_status'" :optionslist="evaluatorList"
                        :display="true" :place-holder="'Select Status'" :searchable="false" :required="false"
                        :close-on-select="true" :clear-on-select="true" class="mb-0 ass-eval w-100" />
                    </div>
                  </div>
                  <div class="cases_card">
                    <h4>View by Confirmed Date</h4>
                    <div class="date_picker">
                      <div class="d-flex">
                        <div class="start_date">
                          <label>Start Date</label>
                          <date-picker v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
                        </div>
                        <div class="end_date">
                          <label>End Date</label>
                          <date-picker v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button class="primary_btn md">Submit</button>
                  <button class="form-cancel">Cancel</button>
                </div>
              </div>
            </b-card>
          </b-collapse> -->
        </div>
      </div>
    </div>
   

    <div class="table-responsive">

      <template v-if="checkProperty(emailsList, 'length') <= 0">
        <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users' :loading="isListLoading" />
      </template>

      <table class="table" v-if="checkProperty(emailsList, 'length') > 0 && !isListLoading">
        <thead>
          <tr>
            <th>From</th>
            <th>subject </th>
            <th>Date </th>
            <th>Label </th>
            <!-- <th>Attachments</th> -->
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>

          <tr v-for="(item, index) in emailsList" v-bind:key="index">
            <td class="request_id">
              <span>{{ checkProperty(item, 'fromEmail') | formatEmail }}</span>
            </td>
            <td><span class="subject_info">{{ checkProperty(item, 'subject') }}</span></td>
            <td>
              <span>{{ checkProperty(item, 'sentDate') | formatDateTime }}</span>
            </td>
          
            <td>
              <messageLabel trimcontent="true" @updateLabels="updateLabels" @updateUserIds="updateUserIds"
                @openCreateLabel="openCreateLabel" :labelsList="labelsList" :message="item" />
            </td>
           
            <!-- <td>
              <div v-if="checkProperty(item, 'documents', 'length') > 0" class="document_list">
                <DocumentsPreview :type="'documents'" :documentsList="checkProperty(item, 'documents').slice(0, 1)"
                  :includeDownloadText="false" @download_or_view="download_or_view" />

                <em class="count" :id="'popover-target-' + index" v-if="checkProperty(item, 'documents', 'length') > 1">{{
                  '+' + (checkProperty(item, 'documents',
                    'length') - 1) }}</em>
                <b-popover custom-class="document_list_wrap" :target="'popover-target-' + index" triggers="hover"
                  placement="top" fallback-placement="flip">
                  <template>
                    <DocumentsPreview :type="'documents'" :documentsList="checkProperty(item, 'documents').slice(1)"
                      :includeDownloadText="false" @download_or_view="download_or_view" />

                  </template>
                </b-popover>
              </div>
            </td> -->
            <td>
              <span class="invoice_btn" @click="openEmailDetails(item)">View</span>
            </td>
          </tr>

        </tbody>
      </table>
      <div class="pagination-sec" v-if="checkProperty(emailsList, 'length') > 0 && !isListLoading">
        <div class="per-page">
          <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) +
            emailsList.length) +
            ' of ' + totalCount + ' Results' }}</label>
        </div>
        <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
          @input="getEmailsList"></b-pagination>
      </div>
    </div>



    <b-modal v-model="showTemplateDetails" id="create_template" dialog-class="create_template email_model" centered
      no-close-on-backdrop hide-footer>
      <template #modal-header>
        <h6 class="modal-title">{{ 'View Details' }}</h6>
        <a class="close" @click="showTemplateDetails = false"></a>
      </template>
      <template>
        <div class="row">
          <div class="col-md-12" v-if="checkProperty(selectedTemplate, 'sentDate')">
            <div class="form_group">
              <lable class="form_label">Date</lable>
              <p>{{ checkProperty(selectedTemplate, 'sentDate') }}</p>
            </div>
          </div>
          <div class="col-md-12" v-if="checkProperty(selectedTemplate, 'subject')">
            <div class="form_group">
              <lable class="form_label">Subject</lable>
              <p>{{ checkProperty(selectedTemplate, 'subject') }}</p>
            </div>
          </div>
          <div class="col-md-12" v-if="checkProperty(selectedTemplate, 'htmlContent')">
            <div class="form_group">
              <lable class="form_label">Content</lable>
              <p v-html="checkProperty(selectedTemplate, 'htmlContent')"></p>
            </div>
          </div>
          <!-- <div class="col-md-12">
            <div class="form_group">
              <lable class="form_label"> Attachments</lable>
              <ul class="doc_pdf_list">
                <li>
                  <figure><img src="@/assets/images/pdf-file.svg"></figure>
                </li>
                <li>
                  <figure><img src="@/assets/images/pdf-file.svg"></figure>
                </li>
                <li>
                  <figure><img src="@/assets/images/pdf-file.svg"></figure>
                </li>
                <li>
                  <figure><img src="@/assets/images/pdf-file.svg"></figure>
                </li>
                <li>
                  <figure><img src="@/assets/images/pdf-file.svg"></figure>
                </li>
                <li>
                  <figure><img src="@/assets/images/pdf-file.svg"></figure>
                </li>
                <li>
                  <figure><img src="@/assets/images/pdf-file.svg"></figure>
                </li>
                <li>
                  <figure><img src="@/assets/images/pdf-file.svg"></figure>
                </li>
                <li>
                  <figure><img src="@/assets/images/pdf-file.svg"></figure>
                </li>
                <li>
                  <figure><img src="@/assets/images/pdf-file.svg"></figure>
                </li>
                <li>
                  <figure><img src="@/assets/images/pdf-file.svg"></figure>
                </li>
                <li>
                  <figure><img src="@/assets/images/pdf-file.svg"></figure>
                </li>
                <li>
                  <figure><img src="@/assets/images/pdf-file.svg"></figure>
                </li>
              </ul>
            </div>
          </div> -->
        </div>
      </template>
    </b-modal>

    <b-modal id="preview_model" v-model="docPrivew" dialog-class="document_modal"
      :title="checkProperty(selectedFile, 'name')">
      <h2> <img :class="{
        pdf_view_download: docType == 'pdf',
        office_view_download: docType == 'office',
        image_view_download: docType == 'image',
      }" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>
      <div class="pdf_loader">
        <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/loader.gif" /></figure>

        <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
        <template v-if="docType == 'office'">
          <div style="height:90vh">

            <div id="placeholder" style="height:100%"></div>
          </div>
        </template>
        <template v-else-if="docType == 'image'">
          <img :src="docValue" />
        </template>
        <template v-else-if="docType == 'pdf'">
          <div class="pdf" style="height:90vh">

            <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%" width="100%">

            </iframe>
          </div>
        </template>
      </div>
    </b-modal>


    <LabelCreatePopup v-if="showAddLabelPopup" @openLabelPopup="openLabelPopup" />


    <b-modal id="createLabelFromListModal" classes="v-modal-sec createLabelModal" :min-width="200" :min-height="200"
      :scrollable="true" :reset="true" width="500px" height="auto" centered no-close-on-backdrop>
      <template #modal-header>
        <h6 class="modal-title">Create Label</h6>
        <a class="close" @click="$bvModal.hide('createLabelFromListModal')"></a>
      </template>

      <template>
        <form data-vv-scope="newLabelform">
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Please enter a new label name</label>
                  <simpleInput :wrapclass="'w-full'" :fieldName="'labelname'" :cid="'labelname'" :label="''"
                    :placeHolder="'Label Name'" :vvas="'Label Name'" :display="true" :required="true" v-model="labelName"
                    :formscope="'newLabelform'" />
                  <!-- <input name="labelname" v-validate="'required'" class="w-full" data-vv-as="label name"
                    v-model="labelName" /> -->
                  <span class="text-danger text-sm" v-show="errors.has('newLabelform.labelname')">{{
                    errors.first("newLabelform.labelname") }}</span>
                </div>
              </div>
            </div>
            <div class="vx-row">
              <simpleColorPicker v-model="selectColor" :formscope="'newLabelform'" :fieldName="'labelColor'"
                :cid="'labelColor'" :name="'labelColor'" :label="'Select the label color'" :required="true" />
            </div>
            <div class="text-danger text-sm formerrors custom_margin" v-show="formerrors.msg">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
                icon="IP-information-button" active="true">{{ formerrors.msg
                }}</vs-alert>
            </div>
          </div>
        </form>
      </template>

      <template #modal-footer>
        <span class="loader" v-if="loadingLabel"><img src="@/assets/images/loader.gif" /></span>
        <button color="success" :disabled="loadingLabel" class="primary_btn md" type="filled" @click="createLabel">
          Create
        </button>
      </template>

    </b-modal>

  </div>
</template>

<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import dropdownHover from '@/views/forms/dropdownHover.vue';
import textArea from "@/views/forms/textarea.vue";
import DatePicker from 'vue2-datepicker';
import 'vue2-datepicker/index.css';
import NoDataFound from "@/views/common/noData.vue";
import LabelCreatePopup from "@/views/messages/labelCreatePopup.vue";
import messageLabel from "@/views/messages/messagesLabels.vue";
import simpleColorPicker from "@/views/forms/simpleColorPicker.vue";
import moment from "moment";


export default {
  name: 'emailtemplate-view',
  components: {
    searchInput,
    simpleSelect,
    dropdownHover,
    simpleInput,
    textArea,
    DatePicker,
    NoDataFound,
    LabelCreatePopup,
    messageLabel,
    simpleColorPicker,
  },
  data: () => ({
    page: 1,
    perpage: 20,
    totalCount: 0,
    isLoading: false,
    isListLoading: true,
    emailsList: [],
    statusList: [],
    filterEmailTypes: [],
    filterSelectedStatuses: [],
    filterSelectedEmailTypes: [],
    filterSearch: '',
    selectedTemplate: null,
    showTemplateDetails: false,
    docPrivew: false,
    docType: '',
    selectedFile: null,
    formSubmited: false,
    showAddLabelPopup: false,
    labelsList: [],
    message: null,
    labelCreatedForMessage: null,
    callFromComponent: false,
    loadingLabel: false,
    labelName: '',
    selectColor: '',
    formerrors: {
      msg: ''
    }
  }),
  methods: {
    gotoPage(path = "/") {
      this.$router.push(path);
    },
    getMasterDataList(category) {
      this.$store.dispatch("getMasterData", category)
        .then((res) => {
          if (category == 'email_template_types') {
            this.templateTypeList = [...res]
            this.filterEmailTypes = [...res]
          }
          if (category == 'email_template_status') {
            this.statusList = [...res]
          }
        })
    },
    showAddTemplatePopup(isEdit = false) {
      this.templateType = null
      this.templateTitle = ''
      this.templateContent = ''
      this.isLoading = false
      this.isTemplateEdit = false
      if (isEdit) {
        this.isTemplateEdit = true
        this.templateType = this.selectedTemplate.typeDetails
        this.templateTitle = this.selectedTemplate.title
        this.templateContent = this.selectedTemplate.content
      }
      this.showAddTemplate = true
    },
    submitEmailTemplate() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          this.isLoading = true
          let postData = {
            "title": this.templateTitle,
            "content": this.templateContent,
            "typeId": null
          }
          if (this.checkProperty(this.templateType, "id")) {
            postData.typeId = this.checkProperty(this.templateType, "id")
          }

          if (this.isTemplateEdit) {
            postData.emailTempId = this.selectedTemplate._id
          }

          if (this.isTemplateEdit) {
            this.$store
              .dispatch("updateEmailTemplate", postData)
              .then((response) => {
                if (response.error) {
                  this.isLoading = false
                  this.showToster({ message: response.error.message, isError: true });
                } else {
                  this.isTemplateEdit = false
                  this.isLoading = false
                  this.showToster({ message: response.message, isError: false });
                  this.page = 1
                  this.getEmailsList()
                  this.showAddTemplate = false
                }
              })
              .catch((error) => {
                this.isLoading = false
                this.showToster({ message: error, isError: true });
              });

          } else {
            this.$store
              .dispatch("addEmailTemplate", postData)
              .then((response) => {
                if (response.error) {
                  this.isLoading = false
                  this.showToster({ message: response.error.message, isError: true });
                } else {
                  this.isLoading = false
                  this.showToster({ message: response.message, isError: false });
                  this.page = 1
                  this.getEmailsList()
                  this.showAddTemplate = false
                }
              })
              .catch((error) => {
                this.isLoading = false
                this.showToster({ message: error, isError: true });
              });
          }


        }
      })
    },
    getEmailsList() {

      let postData = {
        "matcher": {
          "searchString": this.filterSearch,
          "createdDateRange": [],
          "evalLabelIds":[],
          "getLables": false
        },
        "sorting": {
          "path": "createdOn", //title, statusName, createdByName, updatedOn, 
          "order": -1
        },
        "page": this.page,
        "perpage": this.perpage
      }
      this.$store.dispatch("getInboxEmails", postData)
        .then((res) => {
          this.isListLoading = false
          this.updateLoading(false);
          this.emailsList = res.data.result.list
          if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
            this.totalCount = this.checkProperty(res.data.result, 'totalCount');
          }
        })
        .catch((error) => {

        })

    },
    applyFilters() {
      this.emailsList=[]
      this.isListLoading = true
      this.updateLoading(true);
      this.page = 1
      this.getEmailsList()
    },
    applySearchFilters() {
      this.isListLoading = true
      this.updateLoading(true);
      this.page = 1
      if (this.filterSearch && this.filterSearch.length > 2) {
        this.getEmailsList()
      }
      if (this.filterSearch == '') {
        this.getEmailsList()
      }
    },
    changeStatus() {

      this.showLoader = true;
      let payload = {
        "emailTempId": "",
        "statusId": 2, // 3. Inactive, 4.Delete
        "comment": ''
      }
      payload['emailTempId'] = this.selectedTemplate['_id'];
      if ([1].indexOf(this.selectedTemplate.statusId) > -1) {
        payload['statusId'] = 2
      } else {
        payload['statusId'] = 1
      }
      this.$store.dispatch("commonAction", { data: payload, path: "email-template/update-status", })
        .then((response) => {
          this.showToster({ message: response.message, isError: false })
          this.showLoader = false;
          this.showStatusChangePopup = false;
          this.applyFilters();

        }).catch((error) => {
          this.showToster({ message: error.message, isError: true })
          this.showLoader = false;
          this.showStatusChangePopup = false

        });

    },

    openEmailDetails(emailTemplate) {
      this.getEmailDetails(emailTemplate)
      this.selectedTemplate = emailTemplate
      this.showTemplateDetails = true
    },
    download_or_view(docItem) {


      let value = _.cloneDeep(docItem);
      // if (this.checkProperty(this.getPetitionDetails, 'caseNo') && this.checkProperty(value, 'name')) {
      //   let docName = _.cloneDeep(value['name']);
      //   value['name'] = this.checkProperty(this.getPetitionDetails, 'caseNo') + "_" + docName;
      // }


      var _self = this;
      this.formSubmited = false;
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }
      // value = Object.assign(value, { 'petitionId': this.petition['_id'] })
      // value = Object.assign(value, { 'subTypeDetails': this.petition['subTypeDetails'] })


      this.selectedFile = value;
      this.docValue = "";
      this.docPrivew = false;
      this.docType = false;
      this.docType = this.findmsDoctype(value["name"], value.mimetype);

      if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
        //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
          // "petitionId": value['petitionId'],

          // entityType:value['petitionId']
          "fileName": value.name ? value.name : ''
        };
        // if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
        //   postdata['entityType'] = 'perm'
        // } else {
        //   postdata['entityType'] = 'case'
        // }


        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;


          if (this.docType == "office") {
            this.docPrivew = true;
            setTimeout(() => {
              document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
              let _editing = false;

              // if ([3, 4].indexOf(this.getUserRoleId) > -1) {
              //   _editing = false;
              // }

              // if (value.viewmode) {
              //   _editing = false;
              // }
              var _ob = {}
              // if (value.editedDocument) {
              //   _ob = {

              //     evaluationId: this.evaluationDetails._id,
              //     name: value.name,
              //     _id: value._id,
              //     "extn": "docx",
              //     "formLetterType": "Letter",
              //     parentId: value.parentId
              //   }

              // } else {

              _ob = {

                name: value.name,
                evaluationId: this.evaluationDetails._id,
                _id: value._id,
                "extn": "docx",
                "formLetterType": "Letter",
                parentId: value._id

              }

              //  }


              window.docEditor = new DocsAPI.DocEditor("placeholder2",
                {

                  "document": {
                    "c": "forcesave",
                    "fileType": "docx",
                    "key": value._id,
                    "userdata": JSON.stringify(_ob),
                    "title": value.name,
                    "url": response.data.result.data,
                    permissions: {
                      edit: _editing,
                      download: true,
                      reader: false,
                      review: false,
                      comment: false
                    }
                  },

                  "documentType": "word",
                  "height": "100%",
                  "width": "100%",

                  "editorConfig": {
                    "userdata": JSON.stringify(_ob),
                    "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                    "customization": {
                      "logo": {
                        "image": "https://immibox.com/app/favicon.png",
                        "imageDark": "https://immibox.com/app/favicon.png",
                        "url": "https://immibox.com"
                      },
                      "anonymous": {
                        "request": false,
                        "label": "Guest"
                      },
                      "chat": false,
                      "comments": false,
                      "compactHeader": false,
                      "compactToolbar": true,
                      "compatibleFeatures": false,
                      "feedback": {
                        "visible": false
                      },
                      "forcesave": true,
                      "help": false,
                      "hideNotes": true,
                      "hideRightMenu": true,
                      "hideRulers": true,
                      layout: {
                        toolbar: {
                          "collaboration": false,
                        },
                      },
                      "macros": false,
                      "macrosMode": "warn",
                      "mentionShare": false,
                      "plugins": false,
                      "spellcheck": false,
                      "toolbarHideFileName": true,
                      "toolbarNoTabs": true,
                      "uiTheme": "theme-light",
                      "unit": "cm",
                      "zoom": 100
                    },
                  }, events: {
                    onReady: function () {

                    },
                    onDocumentStateChange: function (event) {
                      var url = event.data;
                      console.log(event)

                      if (!event.data) {

                        if (value.editedDocument) {

                        }

                      }
                    }

                  }
                });
              //this.docValue = encodeURIComponent(response.data.result.data);
            }, 100)
          }

          if (this.docType == "pdf") {

            // this.downloadFile(this.docValue, value.mimetype, value.name)

            // return
            var _vid = value._id;
            if (value.parentId) {
              _vid = value.parentId;
            }
            var viewmode = 1; // Enable edit
            viewmode = 0; //Disabled Edit
            if (value.viewmode) {
              viewmode = 0;
            }
            this.docValue = "https://carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
            console.log(this.docValue)
            this.docPrivew = true;
          }
          if (this.docType == "image") {
            this.docPrivew = true;
          }



        });
      } else {



        this.downloads3file(value);
      }

    },
    openAddLabelsPopup() {
      this.showAddLabelPopup = true
    },

    openLabelPopup(val) {
      this.showAddLabelPopup = val;
      if (!val) {
        this.getLabelsList();
      }
    },
    openCreateLabel(val) {
      this.labelCreatedForMessage = val;
      this.callFromComponent = true;
      this.addNewLabel(true, true)
    },

    updateLabels(val) {
      let returnVal = val;
      _.map(this.emailsList,(itemI)=>{
        if(itemI['_id'] == returnVal['messageId'] ){
          itemI['evalLabelIds'] = returnVal['labels']
        }
      })
      this.emailsList = _.cloneDeep(this.emailsList);
    // this.applyFilters()
    },
    updateUserIds(val) {
      //this.$emit('updateUserIds', val)
    },

    addNewLabel(action = false, callfromComp = false) {
      this.selectColor = '';
      this.labelName = '';
      this.formerrors.msg = '';
      if (action) {
        this.$bvModal.show('createLabelFromListModal');
      } else {
        this.$bvModal.hide('createLabelFromListModal');
      }
    },
    createLabel() {
      this.$validator.validateAll('newLabelform').then(result => {
        if (result) {
          let payLoad = {
            name: this.labelName,
            color: this.selectColor,
          }
          this.formerrors.msg = '';
          let path = '/message-label/create';
          this.loadingLabel = true;
          this.$store.dispatch("commonAction", { "data": payLoad, "path": path }).then((response) => {
            this.showToster({ message: response.message, isError: false });
            if (this.callFromComponent && this.labelCreatedForMessage && this.checkProperty(this.labelCreatedForMessage, '_id')) {
              let temp = {
                color: payLoad['color'],
                name: payLoad['name'],
                _id: response._id
              }
              _.map(this.emailsList, (itemI) => {
                if (itemI['_id'] == this.labelCreatedForMessage['_id']) {
                  if (_.has(itemI, 'evalLabelIds') && this.checkProperty(itemI, 'evalLabelIds', 'length') > 0) {
                    itemI['evalLabelIds'].push(temp)
                  } else {
                    itemI['evalLabelIds'] = [];
                    itemI['evalLabelIds'].push(temp)
                  }
                  if (itemI['evalLabelIds'] && this.checkProperty(itemI['evalLabelIds'], 'length') > 0) {
                    let payload = {
                      messageId: this.checkProperty(this.labelCreatedForMessage, '_id'),
                      labels: itemI['evalLabelIds'],
                    }
                    let path = '/mail-inbox/manage-labels'
                    this.$store.dispatch("commonAction", { 'data': payload, 'path': path }).then(response => { }).catch((err) => { })
                  }
                }
              })
              this.emailsList = _.cloneDeep(this.emailsList)
            }
            this.loadingLabel = false;
            this.addNewLabel(false);
            this.getLabelsList();
          }).catch((err) => {
            this.formerrors.msg = err;
            this.loadingLabel = false;
          })
        }
      })
    },
    getLabelsList() {
      let payLoad = {
        matcher: {
          statusList: [],
          searchString: this.searchtxt
        },
        page: this.page,
        perpage: this.perpage,
        sorting: this.sortKey,
        today: moment().format('YYYY-MM-DD')
      };
     // this.isListLoading = true;
      //this.updateLoading(true);
      let path = '/message-label/list'
      this.$store.dispatch("getList", { "data": payLoad, "path": path }).then((response) => {
       // this.isListLoading = false;
       // this.updateLoading(false);
        setTimeout(() => {
        //  this.updateLoading(false);
        }, 5)
        if (response.list) {
          let list = response.list;
          let tempList = []
          _.forEach(list, (item) => {
            if (!_.has(item, 'id')) {
              item['id'] = item['_id'];
              tempList.push(item)
            }
          })
          if (this.checkProperty(tempList, 'length') > 0) {
            this.labelsList = tempList
          }
          this.totalpages = Math.ceil(response.totalCount / this.perpage);
        }
      }).catch((err) => {

      })
    },
    getEmailDetails(emailItem) {
      

      this.selectedTemplate = null

      let postData = {
        "messageId": emailItem['_id'],
      }
      this.$store.dispatch("getEmailDetails", postData)
        .then((res) => {
          this.selectedTemplate = res.data.result

        })
        .catch((error) => {

        })



    },
  },
  mounted() {
    // this.getMasterDataList('email_template_types')
    // this.getMasterDataList('email_template_status')
    this.getLabelsList();
    this.getEmailsList()

  },
  computed: {

  },
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },

}
</script>