<template>
    <div class="email_footer">
        <!-- <a href="https://carnegieevaluations.com/app/" target="_blank">
      <img src="@/assets/images/logo_carne.png" alt="Carnegie Evaluations">
      <img src="@/assets/images/email_footer_logo2.png" alt="Carnegie Evaluations">
    </a> -->

        <!-- <a href="mailto:eval@carnegieevaluations.com" target="_blank">eval@carnegieevaluations.com</a> -->
        <div>
            <!-- <p style="font-size:11pt;font-family:Calibri,sans-serif;margin:0;">
        <img data-imagetype="External"
          src="@/assets/images/logo_carne.png" id="x__x0000_i1026"
          style="width:138.99pt;height:56.49pt;">&nbsp;<img data-imagetype="External"
          src="@/assets/images/email_footer_logo2.png"
          id="x__x0000_i1025" style="width:72pt;height:59.99pt;"></p> -->
            <a href="https://carnegieevaluations.com/app/" target="_blank">
                <img src="@/assets/images/logo_carne.png" alt="Carnegie Evaluations">
                <img src="@/assets/images/email_footer_logo2.png" alt="Carnegie Evaluations">
                <img src="@/assets/images/taicep_logo2.png" alt="TAICEP">
            </a>
            <p
                style="font-size:10pt;font-family:Calibri,sans-serif;margin:0;background-repeat:initial;background-position:initial;background-image:initial;">
                <span style="color: black !important; font-family: &quot;Segoe UI&quot;, sans-serif;">315 East
                    High Street, Bound Brook, NJ 08805</span>
            </p>
            <p
                style="font-size:10pt;font-family:Calibri,sans-serif;margin:0;background-repeat:initial;background-position:initial;background-image:initial;">
                <span style="color: black !important; font-family: &quot;Segoe UI&quot;, sans-serif;"><a
                        href="https://carnegieevaluations.com/" target="_blank" rel="noopener noreferrer"
                        data-auth="NotApplicable" data-linkindex="0"><b>www.carnegieevaluations.com</b></a></span>
            </p>
            <p
                style="font-size:10pt;font-family:Calibri,sans-serif;margin:0;background-repeat:initial;background-position:initial;background-image:initial;">
                Email: <a href="mailto:eval@carnegieevaluations.com" target="_blank"
                    style="font-family: &quot;Segoe UI&quot;, sans-serif;">eval@carnegieevaluations.com</a>
            </p>
            <p
                style="font-size:10pt;font-family:Calibri,sans-serif;margin:0;background-repeat:initial;background-position:initial;background-image:initial;">
                <span style="color: black !important; font-family: &quot;Segoe UI&quot;, sans-serif;">Tel: (848)
                    300 0099</span>
            </p>
            <p
                style="font-size:10pt;font-family:Calibri,sans-serif;margin:0;background-repeat:initial;background-position:initial;background-image:initial;">
                <b><span style="font-family:Segoe UI,sans-serif;"><a
                            href="https://www.linkedin.com/in/carnegie-evaluations/" target="_blank"
                            rel="noopener noreferrer" data-auth="NotApplicable" data-linkindex="1"><span
                                style="font-size:12.5pt;">Connect with us on LinkedIn</span></a></span></b>
            </p>
            <p
                style="font-size:10pt;font-family:Calibri,sans-serif;margin:0;background-repeat:initial;background-position:initial;background-image:initial;">
                <b><i><span style="font-family:Segoe UI,sans-serif;">Mode of Delivery</span></i></b><i><span
                        style="font-family:Segoe UI,sans-serif;">:&nbsp;Digital.&nbsp;</span></i>
            </p>
            <p
                style="font-size:10pt;font-family:Calibri,sans-serif;margin:0;background-repeat:initial;background-position:initial;background-image:initial;">
                <b><i><span style="font-family:Segoe UI,sans-serif;">Revision Requests
                            Policy</span></i></b><i><span style="font-family:Segoe UI,sans-serif;">: Revision&nbsp;<span
                            style="color: rgb(51, 51, 51) !important; letter-spacing: 0.4pt;">Requests that involve the
                            analysis of additional evidence will be subject to an additional fee.</span></span></i>
            </p>
            <div>
                <p
                    style="font-size:10pt;font-family:Calibri,sans-serif;margin:0;background-repeat:initial;background-position:initial;background-image:initial;">
                    <b><i><span style="font-family:Segoe UI,sans-serif;">Rush
                                Services:&nbsp;&nbsp;</span></i></b><i><span style="font-family:Segoe UI,sans-serif;">Please
                            email for availability and
                            pricing.</span></i>
                </p>
                <p
                    style="font-size:10pt;font-family:Calibri,sans-serif;margin:0;background-repeat:initial;background-position:initial;background-image:initial;">
                    <b><i><span style="color: red !important; font-family: &quot;Segoe UI&quot;, sans-serif;">Delivery: We
                                deliver all the evaluations on or before the committed date.&nbsp;Please check your spam
                                folder since some attachments may be huge. If you still can't find our email, please drop
                                a note by 4.45 P.M EST on the committed delivery date.&nbsp;</span></i></b>
                </p>
            </div>
        </div>
    </div>
</template>

<script>
// @ is an alias to /src

import JQuery from "jquery";
export default {
    name: 'email-footer-vue',
    components: {

    },
    computed: {

    },
    methods: {

    },
    mounted() {

    },
}
</script>