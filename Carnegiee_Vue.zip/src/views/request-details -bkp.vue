<template>
    <div>
      <div class="rq-page_wrapper">
        <div class="rq_page">
          <div class="rq_header">
            <div class="rq-select">
              <div class="rq-number">
                <h5>Evaluations / <a href="#">#E-5153</a></h5>
                <vue-multi-select
                    class="opinion_select"
                    ref="multiSelect"
                    v-model="selected"
                    :multiple="true"
                    :optionsmain="optionsmain"
                    :btnLabel="btnLabel"
                    @open="open"
                    @close="close"
                    :selectOptions="optionsmain">
                </vue-multi-select>
              </div>
              <div class="rq-review">
                <div class="status waiting_for_review status_v2"><span></span> Waiting for review</div>
                <div class="due_date"><h4><span>Due Date</span> 17 Feb 2023</h4><figure class="css-img"><img src="../assets/images/calender.png" ></figure></div>
              </div>
            </div>
            <div class="invoice">
              <b-input-group prepend="Professor" class="professor_list">
                <vue-multi-select
                    class="select_checkbox"
                    ref="multiSelect"
                    v-model="values"
                    :multiple="true"
                    :options="mainoptions"
                    :btnLabel="btnLabel"
                    :placeholder="select"
                    @open="open"
                    @close="close"
                    :selectOptions="data">
                    <template v-slot:option="{option}">
                      <div><span>{{option.name}}</span> <p>{{option.value}}</p></div>
                      <input type="checkbox" :checked="option.selected" class="checkmark"/>
                    </template>
                </vue-multi-select>
              </b-input-group>
              <b-input-group prepend="Payment Status" class="professor_list payment">
                <div class="pyment-status">
                  <img src="@/assets/images/solid.svg">
                  <p>Waiting For Invoice</p>
                  <a href="#">View Details</a>
                </div>
                <!-- <div class="pyment-status">
                  <img src="@/assets/images/solid.svg">
                  <p>Pending</p>
                  <a href="#" class="pay_button">Pay Now</a>
                </div> -->
                <!-- <div class="pyment-status">
                  <img src="@/assets/images/subtraction.svg">
                  <p>Paid</p>
                  <a href="#">View Details</a>
                </div> -->
              </b-input-group>
            </div>
          </div>
          <div class="ev_doc">
              <div class="doc_header">
                <img src="@/assets/images/badge.svg">
                <h4>Evaluation Documents</h4>
              </div>
              <div class="doc_files">
                <ul>
                  <li  class="IB_tooltip"><figure><img src="@/assets/images/pdf-file-format.svg"></figure>
                    <div class="tooltip_cnt">Academic Transcripts.pdf <span>Uploaded by </span> Admin</div></li>
                  <li  class="IB_tooltip"><figure><img src="@/assets/images/doc-file-format.svg"></figure>
                    <div class="tooltip_cnt">Academic Transcripts.pdf <span>Uploaded by </span> Admin</div></li>
                  <li  class="IB_tooltip"><figure><img src="@/assets/images/jpeg.svg"></figure>
                    <div class="tooltip_cnt">Academic Transcripts.pdf <span>Uploaded by </span> Admin</div></li>
                  <li  class="IB_tooltip"><figure><img src="@/assets/images/pdf-file-format.svg"></figure>
                    <div class="tooltip_cnt">Academic Transcripts.pdf <span>Uploaded by </span> Admin</div></li>
                  <li  class="IB_tooltip"><figure><img src="@/assets/images/pdf-file-format.svg"></figure>
                    <div class="tooltip_cnt">Academic Transcripts.pdf <span>Uploaded by </span> Admin</div></li>
                  <li  class="IB_tooltip"><figure><img src="@/assets/images/pdf-file-format.svg"></figure>
                    <div class="tooltip_cnt">Academic Transcripts.pdf <span>Uploaded by </span> Admin</div></li>
                  <li  class="IB_tooltip"><figure><img src="@/assets/images/pdf-file-format.svg"></figure>
                    <div class="tooltip_cnt">Academic Transcripts.pdf <span>Uploaded by </span> Admin</div></li>
                  <li  class="IB_tooltip"><figure><img src="@/assets/images/pdf-file-format.svg"></figure>
                    <div class="tooltip_cnt">Academic Transcripts.pdf <span>Uploaded by </span> Admin</div></li>
                </ul>
              </div>
          </div>
          <div class="ev_doc review">
              <div class="doc_header">
                <img src="@/assets/images/solid-review.svg">
                <h4>Under Review</h4>
              </div>
              <div class="doc_files">
                <div class="badge">Education</div>
                <ul>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/doc-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/jpeg.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                </ul>
              </div>
              <div class="doc_files">
                <div class="badge">Employment</div>
                <ul>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/doc-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/jpeg.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                </ul>
              </div>
              <div class="doc_files">
                <div class="badge">Supported Files</div>
                <ul>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/doc-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/jpeg.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                  <li><figure><img src="@/assets/images/pdf-file-format.svg"></figure></li>
                </ul>
              </div>
          </div>
          <div class="ev_doc beneficiary">
              <div class="doc_header">
                <h4>Beneficiary Details</h4>
              </div>
              <div class="beneficiary_detailes">
                <div class="profile">
                  <figure><img src="@/assets/images/user.svg"></figure>
                </div>
                <div class="profile_detailes d-flex">
                  <div class="user-profile">
                    <h4>Michael Lawis-Andersen <span>Male</span></h4>
                    <p><img src="@/assets/images/briefcase.svg"> Sr. UX Manager</p>
                  </div>
                  <div class="user-profile">
                    <p>Beneficiary’s Firm</p>
                    <h4>Stetson Hat Legal Group</h4>
                  </div>
                  <div class="user-profile">
                    <p>Beneficiary’s Degree</p>
                    <h4>Bachelor Of Fine Arts (B.F.A.)</h4>
                  </div>
                  <div class="user-profile">
                    <p>Desired US equivalent degree</p>
                    <h4>10 years as UX Designing</h4>
                  </div>
                  <div class="user-profile">
                    <p>Beneficiary’s Firm</p>
                    <h4>Stetson Hat Legal Group</h4>
                  </div>
                  <div class="user-profile">
                    <p>Occupation SOC code (Only needed for Expert Opinion)</p>
                    <h4>35-3023</h4>
                  </div>
                </div>
              </div>
          </div>
        </div>
        <div class="review_list">
          <div class="badge">Yesturday</div>
          <div class="user-review">
            <div class="users-list">
              <figure><img src=""></figure>
              <div class="user_activity">
                <h4>Front Office User - <span>12:00 PM</span> </h4>
                <p>Request has been created successfully</p>
              </div>
            </div>
            <div class="users-list">
              <figure><img src=""></figure>
              <div class="user_activity">
                <h4>Admin - <span>3:36 PM</span> </h4>
                <p>Generated Forms & Letters</p>
              </div>
            </div>
            <div class="users-list">
              <figure><img src=""></figure>
              <div class="user_activity">
                <h4>Supervisor</h4>
                <p>Requested for choose the professor</p> 
              </div>
            </div>
            <div class="users-list">
              <figure><img src=""></figure>
              <div class="user_activity">
                <h4>Robert Fraczkiewicz -  <span>3:36 pm</span> </h4>
                <p>has been updated status as Under Review </p>
              </div>
            </div>
          </div>
          <div class="post">
            <p>Ask Question or Post Update</p>
            <ul>
              <li id="popover-reactive-1" variant="primary" ref="button"><svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path></svg>
              </li>
              <b-popover
              target="popover-reactive-1"
              triggers="click"
              :show.sync="popoverShow"
              placement="auto"
              ref="popover"
              @show="onShow"
              @shown="onShown"
              @hidden="onHidden"
            >
              <template #title>
                <ul>
                  <li><svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path></svg> Upload file</li>
                  <li><img src="@/assets/images/google-drive.png"> Google Drive</li>
                  <li><img src="@/assets/images/dropbox.png"> Dropbox</li>
                  <li><img src="@/assets/images/dropbox.png"> Box</li>
                  <li><img src="@/assets/images/onedrive.png"> OneDrive</li>
                </ul>
              </template>
        
              <b-card title="Returned values:" v-if="input1Return && input2Return">
                <p class="card-text" style="max-width: 20rem;">
                  Name: <strong>{{ input1Return }}</strong><br>
                  Color: <strong>{{ input2Return }}</strong>
                </p>
              </b-card>
            </b-popover>
              <li><svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><circle cx="12" cy="12" r="4"></circle><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.92 7.94"></path></svg></li>
              <li><svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><circle cx="12" cy="12" r="10"></circle><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" y1="9" x2="9.01" y2="9"></line><line x1="15" y1="9" x2="15.01" y2="9"></line></svg></li>
            </ul>
          </div>
        </div>
        </div>
      </div>
    </div>
</template>

<script>
    // @ is an alias to /src
import vueMultiSelect from 'vue-multi-select';
import 'vue-multi-select/dist/lib/vue-multi-select.css';
import VTooltip from 'v-tooltip'
    
    export default {
      name: 'requests',
      data() {
        return {
        popoverShow: false,
      btnLabel: values => values.length  ? values[0].name : 'Select',
      name: 'first group',
      values: [],
      data: [
        { name: 'Jacob Jones', value: 'Immigration attorney 20+ years' },
        { name: 'Robert Fraczkiewicz', value:'Ph.D. from University of Houston'},
        { name: 'Ajit Jamwal', value:'Master of Science from Biju Patnaik University of Technology' },
        { name: 'Charlie Duhor', value:'Worked at Corporate and Government Experience' },
        { name: 'Michael Taiwo', value:'Ph.D. in Chemistry, University of Missouri-Columbia' },
      ],
      options: {
        multi: true,
        groups: true,
      },
          selecteds: null,
          selected:[],
          optionsmain: [
            { value: null, name: 'Specialty Occupation Expert Opinions (Position Evaluations)' },
            { value: null, name: 'Default Selected Option' },
            { value: null, name: 'This is another option' },
            { value: null, name: 'This one is disabled', disabled: true }
          ],
          nameoptions:[
            { value: null, text: 'Select', sub:''},
          ]
        }
      },
      components: {
        vueMultiSelect,VTooltip
      },
      methods: {
      onClose() {
        this.popoverShow = false
      },
        openManually() {
          this.$refs.multiSelect.openMultiSelect();
        },
        open() {
          console.log('open');
        },
        close() {
          console.log('close');
        },
      },
    }
    </script>