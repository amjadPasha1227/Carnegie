<template>
    <div class="guest_req_sec p-0">
        <div class="header">
        <div class="container">
            <div class="header-one">
                <div class="left">
                    <a href="index.html"><img src="@/assets/images/logo.png" alt="logo"></a>
                </div>
                <div class="right">
                    <ul>
                        <li>
							<a v-if="false" href="https://beta.carnegieevaluations.com" class="click_btn free_btn"><img src="@/assets/images/speedometer.svg"> Request an Evaluation</a> 
						</li>
						<li>
							<a href="https://beta.carnegieevaluations.com/contact-us/" class="click_btn call_btn"><img src="@/assets/images/call.svg"> Contact Us</a> 
						</li>
						<li>
							<a href="https://beta.carnegieevaluations.com/app" class="click_btn login_btn"><img src="@/assets/images/user_login.svg">Login</a> 
						</li>
						<li>
							<a><img src="@/assets/images/aila-platinum2.png" /></a>
						</li>
                    </ul>
                </div>
            </div> 
        </div>
        <nav class="navbar sticky-top navbar-expand-lg">
            <div class="hamburger">
                <a href="index.html"><img src="@/assets/images/logo.png" alt="logo"></a>
                <span class="">
                    <div class="line1"></div>
                    <div class="line2"></div>
                    <div class="line3"></div>
                </span>
            </div>
        </nav>
        </div>
        <div class="container">
            <EvaluationRequest :isGuestRequest="true"/>
        </div>
        <footer class="footer">
<div class="container container-xl">
<div class="row">
<div class="col-md-4 col-md-3">
<div class="footer_logo">
<a href="https://beta.carnegieevaluations.com"><img src="https://beta.carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/footer_logo.png" ></a>
<p>Carnegie Evaluations is a leader in verification, authentication, and evaluation of international experience and education. We deliver fast and accurate results by retaining professors at universities across the U.S. who have industry experience from a wide range of specialty occupations.</p>
<img width="200" src="https://beta.carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/taicep_logo2.png" alt="logo">
</div>
</div>
<div class="col-md-8 col-md-8 padl-50">
<div class="row">
<div class="col-md-6 col-md-6">
<div class="widget">
<h4>Say Hello</h4>
<p>Carnegie Evaluations LLC, 1200 US Highway 22E, Suite 2000, Bridgewater, NJ 08807</p>
</div>
</div>
<div class="col-md-6 col-md-6">
<div class="widget">
<h4>Email</h4>
<p><a href="mailto:eval@carnegieevaluations.com">eval@carnegieevaluations.com</a></p>
</div>
</div>
<div class="col-md-6 col-md-6 bodtop">
<div class="widget">
<h4>Call Us</h4>
<p>(848) 300 0099</p>
</div>
</div>
<div class="col-md-6 col-md-6 bodtop">
<div class="widget">
<h4>Socials</h4>
<div class="social-icons">
<a href="https://www.facebook.com/people/Carnegie-Evaluations/100067473232721/" target="_blank"><img src="https://beta.carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/facebook.svg"></a>
<a href="https://www.instagram.com/explore/tags/carnegieevaluations/" target="_blank"><img src="https://beta.carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/insta.svg"></a>
<a href="https://www.linkedin.com/in/carnegie-evaluations/" target="_blank"><img src="https://beta.carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/linkdin.svg"></a>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-md-12 col-md-12 bodtop">
<div class="quick-links">
<!-- <ul>
<li><a href="https://beta.carnegieevaluations.com/services/" title="Services">Services</a></li>
<li><a href="https://beta.carnegieevaluations.com/our-strengths/" title="Our Strengths">Our Strengths</a></li>
<li><a href="https://beta.carnegieevaluations.com/specialties/" title="Specialties">Specialties</a></li>
<li><a href="https://beta.carnegieevaluations.com/pricing/" title="Pricing">Pricing</a></li>
<li><a href="https://beta.carnegieevaluations.com/contact-us/" title="Contact us">Contact us</a></li>
</ul> -->
<ul>
<li><a href="https://beta.carnegieevaluations.com/testimonials/" title="Testimonials">Testimonials</a></li>
<li><a href="https://beta.carnegieevaluations.com/document-checklist/" title="Document Checklist">Document Checklist</a></li>
</ul>
</div>
</div>
</div>
<div class="row d-none">
<div class="col-md-7 col-md-7">
<div class="widget">
<h4>Say Hello</h4>
<ul>
<li> Carnegie Evaluations LLC, 1200 US Highway 22E, Suite 2000, Bridgewater, NJ 08807</li>
</ul>
</div>
<div class="widget widgett">
<h4>Call Us</h4>
<ul>
<li>(848) 300 0099</li>
</ul>
</div>
<div class="row">
<!-- <div class="col-md-6 col-md-6">
<div class="widget">
<ul class="quick-links">
<li><a href="https://beta.carnegieevaluations.com/services/" title="Services">Services</a></li>
<li><a href="https://beta.carnegieevaluations.com/our-strengths/" title="Our Strengths">Our Strengths</a></li>
<li><a href="https://beta.carnegieevaluations.com/specialties/" title="Specialties">Specialties</a></li>
<li><a href="https://beta.carnegieevaluations.com/pricing/" title="Pricing">Pricing</a></li>
<li><a href="https://beta.carnegieevaluations.com/contact-us/" title="Contact us">Contact us</a></li>
</ul>
</div>
</div> -->
<div class="col-md-6 col-md-6">
<div class="widget">
<ul class="quick-links">
<li><a href="https://beta.carnegieevaluations.com/testimonials/" title="Testimonials">Testimonials</a></li>
<li><a href="https://beta.carnegieevaluations.com/document-checklist/" title="Document Checklist">Document Checklist</a></li>
</ul>

</div>
</div>
</div>
</div>
<div class="col-md-5 col-md-5">
<div class="widget">
<h4>Email</h4>
<ul>
<li><a href="mailto:eval@carnegieevaluations.com">eval@carnegieevaluations.com</a></li>
</ul>
</div>
<div class="widget widgett">
<h4>Socials</h4>
<div class="social-icons">
<a href="https://www.facebook.com/people/Carnegie-Evaluations/100067473232721/" target="_blank"><figure><img src="https://beta.carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/facebook.svg"></figure></a>
<a href="https://www.instagram.com/explore/tags/carnegieevaluations/" target="_blank"><figure><img src="https://beta.carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/insta.svg"></figure></a>
<a href="https://www.linkedin.com/in/carnegie-evaluations/" target="_blank"><figure><img src="https://beta.carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/linkdin.svg"></figure></a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="copyrights">
<div class="container">
<div class="row">
<div class="text-center">Copyright © 2023 Carnegie Evaluations. All rights reserved.</div>
</div>
</div>
</div>
</footer>

        <!-- Success Modal -->
        <b-modal id="success_model" dialog-class="success_model" centered hide-header hide-footer no-close-on-backdrop>
            <template>
                <figure>
                    <img src="@/assets/images/success_mdl_img.png" />
                </figure>
                <h5>Your Request has been Received!</h5>
                <p>You will get notification shortly for selecting your professor</p>
                <a class="primary_btn sm" @click="$bvModal.hide('success_model')">Ok!</a>
            </template>
        </b-modal>
    </div>
</template>

<script>
// @ is an alias to /src

import JQuery from "jquery";
import EvaluationRequest from "@/views/evaluationRequest.vue";


export default {
    name: 'guest-request',
    components: {
    EvaluationRequest
},
    mounted() {
        // const $ = JQuery;
        // //Wizard section script
        // $('.form-wizard-next-btn').click(function () {

        //     this.$validator.validateAll().then((result) => {
        //         if(result){
        //             var parentFieldset = $(this).parents('.wizard-fieldset');
        //     var currentActiveStep = $(this).parents('.form-wizard').find('.form-wizard-steps .active');
        //     var next = $(this);
        //     var nextWizardStep = true;
        //     if (nextWizardStep) {
        //         next.parents('.wizard-fieldset').removeClass("show", "400");
        //         currentActiveStep.removeClass('active').addClass('activated').next().addClass('active', "400");
        //         next.parents('.wizard-fieldset').next('.wizard-fieldset').addClass("show", "400");
        //         $(document).find('.wizard-fieldset').each(function () {
        //             if ($(this).hasClass('show')) {
        //                 var formAtrr = $(this).attr('data-tab-content');
        //                 $(document).find('.form-wizard-steps .form-wizard-step-item').each(function () {
        //                     if ($(this).attr('data-attr') == formAtrr) {
        //                         $(this).addClass('active');
        //                         var innerWidth = $(this).innerWidth();
        //                         var position = $(this).position();
        //                         $(document).find('.form-wizard-step-move').css({ "left": position.left, "width": innerWidth });
        //                     } else {
        //                         $(this).removeClass('active');
        //                     }
        //                 });
        //             }
        //         });
        //     }
        //         }else{

        //         }


        //     });

        // });
        // //click on previous button
        // $('.form-wizard-previous-btn').click(function () {
        //     var counter = parseInt($(".wizard-counter").text());;
        //     var prev = $(this);
        //     var currentActiveStep = $(this).parents('.form-wizard').find('.form-wizard-steps .active');
        //     prev.parents('.wizard-fieldset').removeClass("show", "400");
        //     prev.parents('.wizard-fieldset').prev('.wizard-fieldset').addClass("show", "400");
        //     currentActiveStep.removeClass('active').prev().removeClass('activated').addClass('active', "400");
        //     $(document).find('.wizard-fieldset').each(function () {
        //         if ($(this).hasClass('show')) {
        //             var formAtrr = $(this).attr('data-tab-content');
        //             $(document).find('.form-wizard-steps .form-wizard-step-item').each(function () {
        //                 if ($(this).attr('data-attr') == formAtrr) {
        //                     $(this).addClass('active');
        //                     var innerWidth = $(this).innerWidth();
        //                     var position = $(this).position();
        //                     $(document).find('.form-wizard-step-move').css({ "left": position.left, "width": innerWidth });
        //                 } else {
        //                     $(this).removeClass('active');
        //                 }
        //             });
        //         }
        //     });
        // });

        // //accordian script
        // $('.form-check-input').click(function (e) {
        //     let $this = $(this);
        //     if ($this.is(":checked")) {
        //         $this.parent().parent().addClass("expanded");
        //     } else {
        //         setTimeout(function () {
        //             $this.parent().parent().removeClass("expanded");
        //         }, 200);
        //     }
        //     if ($this.parent().parent().find('.accordion-body').hasClass('show')) {
        //         $this.parent().parent().find('.accordion-body').removeClass('show');
        //         $this.parent().parent().find('.accordion-body').slideUp(350);
        //     } else {
        //         $this.parent().parent().find('.accordion-body').slideToggle(350);
        //     }
        // });


    },
    methods: {



    },
    computed: {

    },
    data: () => ({

    }),
    provide() {
        // return {
        //     parentValidator: this.$validator,
        // };
    },
}
</script>