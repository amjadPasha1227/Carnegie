<template>
    <div class="wrapper-item">
        <div class="wrapper-item" v-if="!isCompletedActivity">
            <div class="section-year">
                <p> </p>
                <p></p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">For Onsite Review</div>
                    <div class="submit_detailes">
                        <div class="d-flex">
                            <button class="primary_btn" @click="openFileUploadPopup">Upload Documents</button>
                            <button v-if="false" class="primary_btn generate_btn ml-2">Generate Documents</button>
                        </div>
                        <!-- <fileUpload :wrapclass="'no_doc_name'" :tplkey="'evaluationdocuments'" v-model="documents"
                            :tplsection="'evaluationdocuments'" label="" vvas="Document" :fieldName="'evaluationdocuments'"
                            :cid="'evaluationdocuments'" :multiple="true" :deleteDocPermenantly="true">
                        </fileUpload> -->

                    </div>
                </div>
            </section>
        </div>
        <div class="wrapper-item" v-if="isCompletedActivity && activityLog.action == 'EVALUATION_DOCUMENTS_SAVED'">
            <div class="section-year">
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">For Onsite Review</div>
                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(activityLog, 'updatedByName')">
                            Uploaded by <b>{{ checkProperty(activityLog,
                                'updatedByName') }}</b></h4>
                        <div class="info_view" v-if="checkProperty(activityLog, 'comments')">
                            <p v-html="checkProperty(activityLog, 'comments')"></p>
                            <h3 class="mb-0"> {{ }}
                            </h3>
                        </div>
                        <div class="doc_files">
                            <!-- <ul>
                                <li v-for="(evaluationItem, indx) in checkProperty(evaluation, 'evaluationDocuments')"> -->
                            <!-- <p> {{ evaluationItem.name }} </p> -->
                            <h3> {{ 'Offshore Completed Documents' }}</h3>
                            <DocumentsPreview :type="'documents'" :documentsList="checkProperty(activityLog, 'documents')"
                                :includeDownloadText="false" @download_or_view="downloadFile" />
                            <!-- </li>
                            </ul> -->
                        </div>

                        <button
                            v-if="checkProperty(activityLog, 'subAction') != 'EVALUATION_DOCUMENTS_CONFIRMED' && [3, 4, 6, 7, 5].indexOf(getUserRoleId) > -1"
                            class="primary_btn mt-3"
                            @click="submitDocuments('EVALUATION_DOCUMENTS_CONFIRMED', true)">Confirm
                            Documents</button>

                    </div>
                </div>
            </section>
        </div>

        <div class="wrapper-item" v-if="isCompletedActivity && activityLog.action == 'EVALUATION_DOCUMENTS_CONFIRMED'">
            <div class="section-year">
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">For Onsite Review</div>
                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(activityLog, 'updatedByName')">
                            Uploaded by <b>{{ checkProperty(activityLog,
                                'updatedByName') }}</b></h4>
                        <div class="doc_files">
                            <!-- <ul>
                                <li v-for="(evaluationItem, indx) in checkProperty(evaluation, 'evaluationDocuments')"> -->
                            <!-- <p> {{ evaluationItem.name }} </p> -->
                            <h3> {{ 'Offshore Completed Documents' }}</h3>
                            <DocumentsPreview :type="'documents'" :documentsList="checkProperty(activityLog, 'documents')"
                                :includeDownloadText="false" @download_or_view="downloadFile" />
                            <!-- </li>
                            </ul> -->
                        </div>

                    </div>
                </div>
            </section>
        </div>

        <b-modal id="doc_model" v-model="showUploadDocsPopup" dialog-class="status-popup professors documents" centered
            no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Upload Documents</h6>
                <a class="close" @click="hideFileUploadTemplatePopup"></a>
            </template>
            <template>
                <div class="rq_header d-block">
                    <div class="user_info_sec" style="padding: 10px 20px;">
                        <div class="drop_files mb-0 position-relative">
                            <fileUploadDrag :label="'Documents*'" :wrapclass="'mb10'" :multiple="true" v-model="documents"
                                @uploadingFile="checkFileUploading($event)"  @download_or_view="downloadFile" :isShowPreview="true"/>
                            <input type="hidden" class="form-control" v-validate="'required'" v-model="documents"
                                data-vv-as="Documents" :name="'userroleRadio'" />
                            <span v-show="errors.has('userroleRadio')" class="form-error">{{
                                errors.first('userroleRadio')
                            }}</span>
                        </div>
                        <div>
                            <textArea class="mb-4 mt-3 comments-ck_editer" :tplkey="'reviewConfirm'"
                                fieldName="reviewConfirm" placeHolder="" v-model="comments" :required="false"
                                :vvas="'Comments'" label="Comments"></textArea>
                        </div>
                    </div>
                </div>

            </template>
            <template #modal-footer>
                <button class="form-cancel" @click="hideFileUploadTemplatePopup">Cancel</button>
                <!-- <button v-if="false" :disabled="isFileUplading" class="primary_btn sm border_btn"
                    @click="submitDocuments('EVALUATION_DOCUMENTS_SAVED', false)">Save
                    <span class="loader" v-if="saveLoading"><img src="@/assets/images/loader.gif"></span></button> -->
                <button :disabled="isFileUplading" class="primary_btn sm" @click="checkAndShowConfirmPopup">Submit
                    <span class="loader" v-if="confirmLoading"><img src="@/assets/images/loader.gif"></span></button>
            </template>
        </b-modal>

        <UploadDocsConfirmPopup v-if="showSubmitConfirmPopup" @submitAction="submitAction"></UploadDocsConfirmPopup>
    </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import fileUpload from "@/views/forms/fileupload.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import textArea from "@/views/forms/textarea.vue";
import UploadDocsConfirmPopup from '@/views/common/uploadDocsConfirmPopup.vue';


export default {
    props: {
        evaluation: Object,
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        activityLog: Object,
    },
    components: {
        simpleSelect,
        fileUpload,
        fileUploadDrag,
        DocumentsPreview,
        textArea,
        UploadDocsConfirmPopup,
    },
    data: () => ({
        documents: [],
        selectedUser: null,
        loading: false,
        showUploadDocsPopup: false,
        isFileUplading: false,
        comments: '',
        showSubmitConfirmPopup: false
    }),
    mounted() {

    },
    methods: {
        checkAndShowConfirmPopup() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.showSubmitConfirmPopup = true
                }
            })
        },
        submitAction(actionType) {
            this.showSubmitConfirmPopup = false
            if (actionType == 1) {
                this.submitDocuments('EVALUATION_DOCUMENTS_CONFIRMED', false)
            }
        },
        downloadFile(value) {
            this.$emit('download_or_view', value);
        },
        submitDocuments(action, isFromTimeline = fasle) {

            if (isFromTimeline) {
                if (this.checkProperty(this.getActivityLog(this.evaluation, 'EVALUATION_DOCUMENTS_SAVED'), 'documents', 'length') > 0) {
                    this.documents = this.checkProperty(this.getActivityLog(this.evaluation, 'EVALUATION_DOCUMENTS_SAVED'), 'documents')
                } else {
                    this.documents = this.checkProperty(this.evaluation, 'evaluationDocuments')
                }
            }

            this.$validator.validateAll().then((result) => {
                if (result) {
                    if (action == 'EVALUATION_DOCUMENTS_CONFIRMED') {
                        this.confirmLoading = true
                    } else {
                        this.saveLoading = true
                    }
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "evaluationDocuments": this.documents,
                        "comments": this.comments
                    }

                    if (action == 'EVALUATION_DOCUMENTS_CONFIRMED') {
                        // postData["docAction"]=
                        Object.assign(postData, { docAction: "confirm" });
                    }
                    if (this.checkProperty(this.activityLog, '_id')) {
                        Object.assign(postData, { logId: this.checkProperty(this.activityLog, '_id') });
                    }

                    this.$store.dispatch("uploadEvaluationDocuments", postData)
                        .then((response) => {
                            this.saveLoading = false
                            this.confirmLoading = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                this.hideFileUploadTemplatePopup()
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')
                            }
                        })
                        .catch((error) => {
                            this.loading = false
                            this.showToster({ message: error, isError: true });
                        })
                }
            })
        },

        openFileUploadPopup() {
            this.isFileUplading = false
            this.documents = []
            this.showUploadDocsPopup = true
        },
        hideFileUploadTemplatePopup() {
            this.documents = []
            this.showUploadDocsPopup = false
            this.isFileUplading = false
        },
        checkFileUploading() {
            let uploading = false
            let resultDocs = _.filter(this.documents, (docItem) => {
                return this.checkProperty(docItem, 'fileUploading') && docItem.fileUploading
            })
            console.log('resultDocs' + JSON.stringify(resultDocs))
            if (this.checkProperty(resultDocs, 'length') > 0) {
                if (!uploading) {
                    uploading = true
                }
            }
            this.isFileUplading = uploading
        }
    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>