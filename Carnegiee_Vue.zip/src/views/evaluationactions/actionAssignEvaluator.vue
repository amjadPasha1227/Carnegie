<template>
    <div class="wrapper-item">
        <div class="wrapper-item" v-if="(!isCompletedActivity)">
            <div class="section-year">
                <p> </p>
                <p></p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Offshore </div>
                    <div class="submit_detailes">
                        <!-- <h4>Assign Evaluator/Consultant either from Offshore or Onsite team*</h4>
                        <simpleSelect :multiple="false" :wrapclass="'req_status mb-3'" :optionslist="usersList"
                            :display="true" :place-holder="'Assign Evaluator/Consultant'" :searchable="false"
                            :required="true" :close-on-select="true" :clear-on-select="false" class="mb-0 ass-eval"
                            v-model="selectedUser" :fieldName="'evaluator'" :cid="'evaluator'"
                            :vvas="'Evaluator/Consultant'" :trackBy="'tempName'" />

                        <div class="generated_docs generated_docs_v2">
                            <div class="doc_files"
                                v-if="true || checkProperty(getActivityLog(evaluation, 'EVALUATION_TEMPLATE_ASSIGNED'), 'documents', 'length') > 0 || checkProperty(evaluation, 'evaluationDocuments', 'length') > 0">
                                <h4>Generated template documents</h4>
                                <DocumentsPreview :type="'documents'"
                                    :documentsList="checkProperty(getActivityLog(evaluation, 'EVALUATION_TEMPLATE_ASSIGNED'), 'documents', 'length') > 0 ? checkProperty(getActivityLog(evaluation, 'EVALUATION_TEMPLATE_ASSIGNED'), 'documents') : checkProperty(evaluation, 'evaluationDocuments')"
                                    :includeDownloadText="false" @download_or_view="downloadFile" />
                            </div>
                            <div class="or_text"
                                v-if="true || checkProperty(getActivityLog(evaluation, 'EVALUATION_TEMPLATE_ASSIGNED'), 'documents', 'length') > 0 || checkProperty(evaluation, 'evaluationDocuments', 'length') > 0">
                                <span><strong>OR</strong></span>
                            </div>
                            <div class="drop_files mb-0">
                                <fileUploadDrag :label="'Upload Documents'" :wrapclass="'mb-0'" :multiple="true"
                                    v-model="documents" @uploadingFile="checkFileUploading($event)" />
                            </div>
                        </div> -->
                        <button class="primary_btn" @click="openAssignEvaluatorPopup">Assign Evaluator/Consultant</button>
                        <!-- <button class="primary_btn edit_btn mt-1">Edit Evaluator</button> -->
                    </div>
                </div>
            </section>
        </div>
        <div class="wrapper-item" v-if="isCompletedActivity && reviewDetails.action == 'EVALUATION_EVALUATOR_ASSIGNED'">
            <div class="section-year">
                <p> {{ checkProperty(reviewDetails, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(reviewDetails, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Offshore</div>

                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(reviewDetails, 'updatedByName')">
                            Assigned by <b>{{ checkProperty(reviewDetails,
                                'updatedByName') }}</b></h4>

                        <h4 v-if="Array.isArray(checkProperty(reviewDetails, 'assignToDetails'))">
                            Assigned to
                            <div class="list-items">
                                <div class="sugg_prof_list"
                                    v-for="(assignTo, index) in checkProperty(reviewDetails, 'assignToDetails')">
                                    <span><b>{{ assignTo | formatFullname }} </b> ({{ assignTo.roleName }})</span>
                                    <div class="delete" v-if="checkProperty(reviewDetails, 'assignToDetails', 'length') > 1"
                                        @click="openRemoveUserPopup(assignTo)">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="13.061" height="13.061"
                                            viewBox="0 0 13.061 13.061">
                                            <g id="Group_42964" data-name="Group 42964"
                                                transform="translate(-1007.514 -124.514)">
                                                <line id="Line_604" data-name="Line 604" x2="12" y2="12"
                                                    transform="translate(1008.044 125.044)" fill="none" stroke="#5a5b5e"
                                                    stroke-width="1.5" />
                                                <line id="Line_605" data-name="Line 605" x1="12" y2="12"
                                                    transform="translate(1008.044 125.044)" fill="none" stroke="#5a5b5e"
                                                    stroke-width="1.5" />
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </h4>

                        <h4 class="mb-0"
                            v-if="!Array.isArray(checkProperty(reviewDetails, 'assignToDetails')) && checkProperty(reviewDetails, 'assignToDetails', 'name')">
                            <b>{{
                                checkProperty(reviewDetails, 'assignToDetails', 'name') }}</b> has
                            been
                            assigned as evaluator by <b>{{ checkProperty(reviewDetails, 'updatedByName') }}</b>
                        </h4>
                        <div class="doc_files" v-if="checkProperty(getLatestDocumentsSubmited, 'length') > 0">
                            <h3></h3>
                            <h3> {{ 'Draft Documents' }}</h3>
                            <DocumentsPreview :type="'documents'" :documentsList="getLatestDocumentsSubmited"
                                :includeDownloadText="false" @download_or_view="downloadFile" />
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <div class="wrapper-item" v-if="isCompletedActivity && reviewDetails.action == 'EVALUATION_CONSULTANT_ASSIGNED'">
            <div class="section-year">
                <p> {{ checkProperty(reviewDetails, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(reviewDetails, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Assigned Consultant</div>

                    <div class="submit_detailes">
                        <h4 v-if="false && checkProperty(reviewDetails, 'updatedByName')">
                            Assigned by <b>{{ checkProperty(reviewDetails,
                                'updatedByName') }}</b></h4>
                        <h4 class="mb-0" v-if="checkProperty(reviewDetails, 'assignToDetails', 'name')"><b>{{
                            checkProperty(reviewDetails, 'assignToDetails', 'name') }}</b> has
                            been
                            assigned as consultant by <b>{{ checkProperty(reviewDetails, 'updatedByName') }}</b></h4>

                        <div class="doc_files" v-if="checkProperty(getLatestDocumentsSubmited, 'length') > 0">
                            <h3></h3>
                            <h3> {{ 'Draft Documents' }}</h3>
                            <DocumentsPreview :type="'documents'" :documentsList="getLatestDocumentsSubmited"
                                :includeDownloadText="false" @download_or_view="downloadFile" />
                        </div>

                    </div>
                </div>
            </section>
        </div>

        <b-modal v-model="showAssignEvaluatorPopup" id="assign_evaluator_model" dialog-class="assign_eval_modal" centered
            no-close-on-backdrop>

            <template #modal-header>
                <h6 class="modal-title">Assign Evaluator/Consultant </h6>
                <a class="close" @click="closeAssignEvaluatorPopup"></a>
            </template>
            <template>
                <form>
                    <simpleSelect :multiple="true" :wrapclass="'req_status mb-3'" :optionslist="usersList" :display="true"
                        :place-holder="'Assign Evaluator/Consultant'" :searchable="false" :required="true"
                        :close-on-select="false" :clear-on-select="true" class="mb-0 ass-eval" v-model="selectedUser"
                        :fieldName="'evaluator'" :cid="'evaluator'" :hideSelected="true"
                        :label="'Assign Evaluator/Consultant either from Offshore or Onsite team'"
                        :vvas="'Evaluator/Consultant'" :trackBy="'tempName'" />

                    <div class="generated_docs generated_docs_v2">
                        <div class="doc_files form_group mb-0"
                            v-if="checkProperty(getDocumentsToSubmitProfessor, 'length') > 0">
                            <label class="form_label">Draft Documents</label>
                            <DocumentsPreview :type="'documents'" :documentsList="getDocumentsToSubmitProfessor"
                                :includeDownloadText="false" @download_or_view="downloadFile" />
                        </div>
                        <div class="or_text" v-if="checkProperty(getDocumentsToSubmitProfessor, 'length') > 0">
                            <span><strong>OR</strong></span>
                        </div>
                        <div class="drop_files mb-0">
                            <fileUploadDrag :label="'Upload Documents'" :wrapclass="'mb-0'" :multiple="true"
                                v-model="documents" @uploadingFile="checkFileUploading($event)" />
                        </div>
                    </div>
                </form>
            </template>
            <template #modal-footer>
                <button class="form-cancel" @click="closeAssignEvaluatorPopup">Cancel</button>
                <button class="primary_btn md" @click="assignEvaluationUser" :disabled="isFileUplading">Assign
                    <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
            </template>
        </b-modal>


        <b-modal id="remove_user_model" v-model="showRemoveUserPopup" dialog-class="addnotes_model" centered
            no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Delete</h6>
                <a class="close" @click="closeRemoveUserPopup"></a>
            </template>
            <template>
                <div class="row">
                    <!-- <div class="col-md-12">
                        <textArea :tplkey="'cancelComments'" fieldName="cancelComments" placeHolder="Comments…"
                            v-model="cancelComments" :label="'Comments'" :required="true" :vvas="'Comments'"></textArea>
                    </div> -->
                    <p class="confirm_msg">Are you sure you
                        want to delete?</p>
                </div>
            </template>
            <template #modal-footer>
                <button class="form-cancel me-4" @click="closeRemoveUserPopup">No</button>
                <button class="primary_btn md" @click="removeUser">Yes
                    <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
            </template>
        </b-modal>

        <UploadDocsConfirmPopup v-if="showSubmitConfirmPopup" @submitAction="submitAction"></UploadDocsConfirmPopup>

    </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import UploadDocsConfirmPopup from '@/views/common/uploadDocsConfirmPopup.vue';

export default {
    props: {
        evaluation: Object,
        roleIds: {
            type: Array,
            default: [],
        },
        actionCode: '',
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        reviewDetails: Object,
    },
    components: {
        simpleSelect,
        fileUploadDrag,
        DocumentsPreview,
        UploadDocsConfirmPopup,
    },
    data: () => ({
        usersList: [],
        selectedUser: null,
        loading: false,
        documents: [],
        isFileUplading: false,
        showAssignEvaluatorPopup: false,
        showRemoveUserPopup: false,
        userToRemove: null,
        showSubmitConfirmPopup: false
    }),
    mounted() {
        this.getUsers()
    },
    methods: {
        checkAndShowConfirmPopup() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.showSubmitConfirmPopup=true
                }
            })
        },
        submitAction(actionType){
            this.showSubmitConfirmPopup=false
            if(actionType==1){
                this.assignEvaluationUser()
            }
        },

        getUsers() {
            let postData =
            {
                "matcher": {
                    "title": '',
                    "searchString": "",
                    "statusList": [],
                    "createdByIds": [],
                    "createdDateRange": [],
                    "roleIds": this.roleIds,
                    "statusIds": [],
                    "typeIds": [],
                    "departmentIds": []
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": true,// if Masterdata required
                "page": 1,
                "perpage": 500,
            }
            this.$store.dispatch("getUsersList", postData)
                .then((res) => {
                    let lst = []
                    _.forEach(res.data.result.list, (item) => {
                        item['tempName'] = item['name'];
                        if (_.has(item, "name") && _.has(item, "roleName")) {
                            item.tempName = item.name + " (" + item.roleName + ")";
                            lst.push(item);
                        }
                    });
                    this.usersList = lst;

                    //  this.usersList = res.data.result.list
                })
                .catch((error) => {
                })
        },
        assignEvaluationUser() {
            //EVALUATION_PROFESSER_ASSIGNED
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.loading = true
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "userId": [],
                        "documents": [],
                    }

                    if (this.checkProperty(this.selectedUser, 'length') > 0) {
                        postData['userId'] = this.selectedUser.map((item) => item['_id'])
                    }
                    if (this.checkProperty(this.documents, 'length') > 0) {
                        postData['documents'] = this.documents
                    } else if (this.checkProperty(this.getDocumentsToSubmitProfessor, 'length') > 0) {
                        postData['documents'] = this.getDocumentsToSubmitProfessor
                    }

                    this.$store.dispatch("assignEvaluator", postData)
                        .then((response) => {
                            this.loading = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                // this.selectedUser = null
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')

                            }
                        })
                        .catch((error) => {
                            this.loading = false
                            this.showToster({ message: error, isError: true });
                        })


                }
            })
        },
        checkFileUploading() {
            let uploading = false
            let resultDocs = _.filter(this.documents, (docItem) => {
                return this.checkProperty(docItem, 'fileUploading') && docItem.fileUploading
            })
            console.log('resultDocs' + JSON.stringify(resultDocs))
            if (this.checkProperty(resultDocs, 'length') > 0) {
                if (!uploading) {
                    uploading = true
                }
            }
            this.isFileUplading = uploading
        },
        downloadFile(value) {
            this.$emit('download_or_view', value);
        },
        openAssignEvaluatorPopup() {
            this.documents = []
            this.selectedUser = null
            this.isFileUplading = false
            this.showAssignEvaluatorPopup = true
        },
        closeAssignEvaluatorPopup() {
            this.showAssignEvaluatorPopup = false
        },

        openRemoveUserPopup(selectedUser) {
            this.userToRemove = selectedUser
            this.showRemoveUserPopup = true
        },
        closeRemoveUserPopup() {
            this.userToRemove = null
            this.showRemoveUserPopup = false
        },

        removeUser() {

            this.loading = true
            let postData = {
                "evaluationId": this.evaluation._id,
                "userId": this.checkProperty(this.userToRemove, 'userId') ? [this.checkProperty(this.userToRemove, 'userId')] : []
            }
            if (this.checkProperty(this.reviewDetails, '_id')) {
                Object.assign(postData, { logId: this.checkProperty(this.reviewDetails, '_id') });
            }

            this.$store.dispatch("removeEvaluator", postData)
                .then((response) => {
                    this.loading = false
                    if (response.error) {
                        this.showToster({ message: response.error.result, isError: true });
                    } else {
                        // this.selectedUser = null
                        this.closeRemoveUserPopup()
                        this.showToster({ message: response.message, isError: false });
                        this.$emit('updateDetails')
                    }
                })
                .catch((error) => {
                    this.loading = false
                    this.showToster({ message: error, isError: true });
                })
        }

    },
    computed: {
        getDocumentsToSubmitProfessor() {
            let resultDocs = []
            if (this.isLastCompletedActivity(this.evaluation, 'EVALUATION_TEMPLATE_ASSIGNED')
                || (this.checkProperty(this.evaluation, 'completedActivities').lastIndexOf('EVALUATION_TEMPLATE_ASSIGNED') > this.checkProperty(this.evaluation, 'completedActivities').lastIndexOf('EVALUATION_DOCUMENTS_SAVED'))) {
                if (this.checkProperty(this.evaluation, 'latestEvaluationLog', 'task') == 'merge' && this.checkProperty(this.evaluation, 'generatedDocuments', 'length') > 0) {
                    return this.checkProperty(this.evaluation, 'generatedDocuments')
                }
                if (this.checkProperty(this.evaluation, 'latestEvaluationLog', 'task') == 'add' && this.checkProperty(this.evaluation, 'evaluationDocuments', 'length') > 0) {
                    return this.checkProperty(this.evaluation, 'evaluationDocuments')
                }

            } else {
                if (this.checkProperty(this.evaluation, 'evaluationDocuments', 'length') > 0) {
                    return this.checkProperty(this.evaluation, 'evaluationDocuments')
                }
            }

            return resultDocs
        },
        getLatestDocumentsSubmited() {
            let resultDocs = []
            if (this.checkProperty(this.evaluation, 'latestEvaluationLog', 'documents')
                && this.checkProperty(this.evaluation.latestEvaluationLog, 'documents', 'length') > 0) {
                return this.checkProperty(this.evaluation, 'latestEvaluationLog', 'documents')
            }
            return resultDocs
        }



    },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>