<template>
    <div class="wrapper-item">
        <div class="wrapper-item" v-if="!isCompletedActivity">
            <div class="section-year">
                <p> </p>
                <p></p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Assign Professor</div>
                    <div class="submit_detailes">
                        <!-- <h4>Assign one of the Evaluator either from Offshore or Onsite team.</h4> -->
                        <div class="d-flex">
                            <customSelect :multiple="false" :wrapclass="'req_status'" :optionslist="usersList"
                                :display="true" :place-holder="'Assign Professor'" :searchable="false" :required="true"
                                :close-on-select="true" :clear-on-select="false" class="mb-0 ass-eval"
                                v-model="selectedUser" :fieldName="'user'" :cid="'user'" :vvas="'Professor'" />
                            <button class="primary_btn" @click="assignEvaluationUser">Assign
                                <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
                        </div>
                        <!-- <button class="primary_btn edit_btn mt-1">Edit Evaluator</button> -->
                    </div>
                </div>
            </section>
        </div>
        <div class="wrapper-item" v-if="isCompletedActivity">
            <div class="section-year">
                <p> {{ checkProperty(reviewDetails, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(reviewDetails, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Assigned Professor</div>
                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(reviewDetails, 'updatedByName')">
                            Professor assigned by <b>{{ checkProperty(reviewDetails, 'updatedByName') }}</b></h4>
                        <div class="exp_users_info mt-3"
                            v-if="getAssignedToDetails(checkProperty(reviewDetails, 'assignToDetails'))">
                            <div class="users-flex">
                                <p>Professor <span><img src="@/assets/images/subtraction.svg"> {{
                                    getAssignedToDetails(checkProperty(reviewDetails, 'assignToDetails')) }}</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import customSelect from '@/views/forms/customSelect.vue';


export default {
    props: {
        evaluation: Object,
        roleIds: {
            type: Array,
            default: [],
        },
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        reviewDetails: Object,
    },
    components: {
        simpleSelect,
        customSelect,
    },
    data: () => ({
        usersList: [],
        selectedUser: null,
        loading: false,
    }),
    mounted() {
        this.getUsers()
    },
    methods: {
        getUsers() {
            let postData =
            {
                "matcher": {
                    "title": '',
                    "searchString": "",
                    "statusList": [],
                    "createdByIds": [],
                    "createdDateRange": [],
                    "roleIds": this.roleIds,
                    "statusIds": [],
                    "typeIds": [],
                    "departmentIds": []
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": true,// if Masterdata required
                "page": 1,
                "perpage": 500,
            }
            this.$store.dispatch("getUsersList", postData)
                .then((res) => {
                    let lst = []
                    _.forEach(res.data.result.list, (item) => {
                        let professorIndex = _.findIndex(this.checkProperty(this.evaluation, 'suggestProfessors'), (suggested) => {
                            return suggested["_id"] == item["_id"];
                        })
                        item['isSuggested'] = false;
                        if (professorIndex > -1) {
                            item['isSuggested'] = true;
                        }
                        lst.push(item);
                    });

                    this.usersList = lst
                })
                .catch((error) => {
                })
        },
        assignEvaluationUser() {
            //EVALUATION_PROFESSER_ASSIGNED
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.loading = true
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "userId": this.selectedUser._id
                    }
                    this.$store.dispatch("assignUser", postData)
                        .then((response) => {
                            this.loading = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')
                                //  this.selectedUser = null
                            }
                        })
                        .catch((error) => {
                            this.loading = false
                            this.showToster({ message: error, isError: true });
                        })


                }
            })
        }

    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>