<template>
    <div class="wrapper-item">
        <div class="wrapper-item">
            <div class="section-year" v-if="checkProperty(activityLog, 'updatedOn')">
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_conform"></span>
                    <div class="status-name conform_bg">Email to {{ checkProperty(activityLog, 'sendEmailTo') }}</div>
                    <div class="submit_detailes">
                        <h4
                            v-if="checkProperty(activityLog, 'updatedByName') && checkProperty(activityLog, 'sendEmailTo') == 'Professor' && checkProperty(activityLog, 'professorDetails', 'name')">
                            Sent by <b>{{ checkProperty(activityLog, 'updatedByName') }}</b>
                            to <b>{{ checkProperty(activityLog, 'professorDetails', 'name') }}</b> &lt; {{
                                checkProperty(activityLog, 'professorDetails', 'email') }} ></h4>

                        <h4
                            v-if="checkProperty(activityLog, 'updatedByName') && checkProperty(activityLog, 'sendEmailTo') == 'Customer' && checkProperty(activityLog, 'customerDetails', 'email')">
                            Sent to {{ getCustomerSentEmails() }}
                            by <b>{{ checkProperty(activityLog, 'updatedByName') }}</b>
                        </h4>

                        <div class="wrapper-timeline">
                            <div class="wrapper-item"
                                v-if="checkProperty(activityLog, 'subject') || checkProperty(activityLog, 'content')">
                                <section class="timeline-item">
                                    <div class="item mt-0 p-0">
                                        <div class="info_view">
                                            <h4 v-if="checkProperty(activityLog, 'subject')"> <b>{{
                                                checkProperty(activityLog, 'subject') }}</b></h4>
                                            <p v-if="checkProperty(activityLog, 'content')"
                                                v-html="checkProperty(activityLog, 'content')"></p>
                                        </div>
                                        <DocumentsPreview :type="'documents'"
                                            :documentsList="checkProperty(activityLog, 'documents')"
                                            :includeDownloadText="false" @download_or_view="downloadFile" />
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</template>


<script>
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import textArea from "@/views/forms/textarea.vue";
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import radioInput from "@/views/forms/radioInput.vue";

export default {
    props: {
        evaluation: Object,
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        activityLog: Object,
    },
    components: {
        textArea,
        simpleSelect,
        simpleInput,
        radioInput,
        DocumentsPreview
    },
    data: () => ({

    }),
    mounted() {
    },
    methods: {
        downloadFile(value) {
            this.$emit('download_or_view', value);
        },
        getCustomerSentEmails() {
            let emailStr = ''
            if (this.checkProperty(this.activityLog, 'customerDetails', 'email')) {
                // if (this.checkProperty(this.activityLog, 'customerDetails', 'name')) {
                //     emailStr = emailStr + this.checkProperty(this.activityLog, 'customerDetails', 'name')
                //         + "< " + this.checkProperty(this.activityLog, 'customerDetails', 'email') + " >"
                // } else {
                emailStr = emailStr + this.checkProperty(this.activityLog, 'customerDetails', 'email')
                //  }
            }
            if (this.checkProperty(this.activityLog, 'altEmailsList', 'length') > 0) {
                this.checkProperty(this.activityLog, 'altEmailsList').forEach((item, index) => {
                    if (!emailStr.includes(item.email)) {
                        if (!emailStr) {
                            emailStr = item.email
                        } else {
                            emailStr = emailStr + ", " + item.email
                        }
                    }
                });
            }
            return emailStr
        }
    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>