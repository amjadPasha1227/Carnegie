<template>
    <div class="wrapper-item">
        <!-- <div class="wrapper-item"
            v-if="!isCompletedActivity && isActivityCompleted(evaluation, 'SENT_FOR_REVISION') && checkProperty(evaluation, 'isSentForRevision') == false">
            <div class="section-year">
                <p> </p>
                <p> </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">With Professor</div>
                    <div class="submit_detailes">
                        <h4>Professor validating the documents.</h4>

                    </div>
                </div>
            </section>
        </div> -->
        <div class="wrapper-item"
            v-if="!isCompletedActivity && (!isActivityCompleted(evaluation, 'SENT_FOR_REVISION') || checkProperty(evaluation, 'isSentForRevision') == true)">
            <div class="section-year">
                <p> </p>
                <p> </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Professor Revision</div>
                    <div class="submit_detailes">
                        <!-- <h4>Please update education transcipts <a href="#">View Comments</a></h4> -->
                        <button class="primary_btn" @click="openFileUploadPopup">Upload Documents</button>
                    </div>
                </div>
            </section>
        </div>

        <div class="wrapper-item" v-if="isCompletedActivity">
            <div class="section-year">
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime }} </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_pending"></span>
                    <div class="status-name pending_bg">Professor Revision</div>
                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(activityLog, 'updatedByName')">
                            Revision sent by <b>{{ checkProperty(activityLog,
                                'updatedByName') }}</b></h4>
                        <h4 v-html="checkProperty(activityLog, 'comments')"></h4>
                        <div class="doc_files">
                            <DocumentsPreview :type="'documents'" :documentsList="checkProperty(activityLog, 'documents')"
                                :includeDownloadText="false" @download_or_view="downloadFileb" />
                        </div>
                    </div>
                </div>
            </section>
        </div>


        <b-modal id="doc_model" v-model="showUploadDocsPopup" dialog-class="status-popup professors documents" centered
            no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Upload Revised Documents</h6>
                <a class="close" @click="hideFileUploadTemplatePopup"></a>
            </template>
            <template>
                <div class="rq_header d-block">
                    <div class="user_info_sec sub_prof_sec generated_docs generated_docs_v2">

                        <div class="doc_files form_group mb-0"
                            v-if="checkProperty(getDocumentsToSubmitProfessor, 'length') > 0">
                            <label class="form_label">Draft Documents</label>
                            <DocumentsPreview :type="'documents'" :documentsList="getDocumentsToSubmitProfessor"
                                :includeDownloadText="false" @download_or_view="downloadFileb" />
                        </div>
                        <div class="or_text" v-if="checkProperty(getDocumentsToSubmitProfessor, 'length') > 0">
                            <span class="gray"><strong>OR</strong></span>
                        </div>
                        <div class="drop_files mb-2">
                            <fileUploadDrag :label="checkProperty(getDocumentsToSubmitProfessor, 'length') > 0 ? 'Documents' :'Documents*'" :wrapclass="'mb-0'" :multiple="true" v-model="documents"
                                :required="checkProperty(getDocumentsToSubmitProfessor,'length')>0?false:true" @uploadingFile="checkFileUploading($event)"
                                @download_or_view="downloadFileb" :isShowPreview="true" />
                        </div>
                        <input v-if="checkProperty(getDocumentsToSubmitProfessor, 'length') > 0 ? false : true"
                         type="hidden" class="form-control" v-validate="'required'" v-model="documents"
                            data-vv-as="Documents" :name="'userroleRadio'" />
                        <span v-show="errors.has('userroleRadio')" class="form-error top_auto">{{
                            errors.first('userroleRadio')
                        }}</span>
                    </div>
                </div>

            </template>
            <template #modal-footer>
                <button class="form-cancel" @click="hideFileUploadTemplatePopup">Cancel</button>
                <button class="primary_btn md" @click="checkAndShowConfirmPopup" :disabled="isRevisionUplading">Submit
                    <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
            </template>
        </b-modal>
        <UploadDocsConfirmPopup v-if="showSubmitConfirmPopup" @submitAction="submitAction"></UploadDocsConfirmPopup>
    </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import fileUpload from "@/views/forms/fileupload.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import UploadDocsConfirmPopup from '@/views/common/uploadDocsConfirmPopup.vue';

export default {
    props: {
        evaluation: Object,
        actionCode: '',
        isFromActivityLog: {
            type: Boolean,
            default: false,
        },
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        activityLog: Object,
    },
    components: {
        simpleSelect,
        fileUpload,
        fileUploadDrag,
        DocumentsPreview,
        UploadDocsConfirmPopup,
    },
    data: () => ({
        loading: false,
        documents: [],
        selectedUser: null,
        showUploadDocsPopup: false,
        isRevisionUplading: false,
        showSubmitConfirmPopup:false,
    }),
    mounted() {
    },
    methods: {
        checkAndShowConfirmPopup() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.showSubmitConfirmPopup = true
                }
            })
        },
        submitAction(actionType) {
            this.showSubmitConfirmPopup = false
            if (actionType == 1) {
                this.submitForProfessorReview()
            }
        },
        downloadFileb(value) {
            this.$emit('download_or_view', value);
        },
        submitForProfessorReview() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.loading = true
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "action": "SIGN_REQUESTED",
                        "professorId": this.evaluation.assignedToProfessor,
                        "comments": "",
                        "documents": this.documents
                    }
                    if (this.checkProperty(this.documents, 'length') == 0) {
                        postData['documents'] = this.getDocumentsToSubmitProfessor
                    }
                
                    this.$store.dispatch("submitToProfessor", postData)
                        .then((response) => {
                            this.loading = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                this.selectedUser = null
                                this.showUploadDocsPopup = false
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')

                            }
                        })
                        .catch((error) => {
                            this.loading = false
                            this.showToster({ message: error, isError: true });
                        })
                }
            })


        },
        submitDocuments() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.loading = true
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "evaluationDocuments": this.documents
                    }
                    this.$store.dispatch("uploadEvaluationDocuments", postData)
                        .then((response) => {
                            this.loading = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                this.hideFileUploadTemplatePopup()
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')
                            }
                        })
                        .catch((error) => {
                            this.loading = false
                            this.showToster({ message: error, isError: true });
                        })
                }
            })
        },

        openFileUploadPopup() {
            this.documents = []
            this.showUploadDocsPopup = true
        },
        hideFileUploadTemplatePopup() {
            this.documents = []
            this.showUploadDocsPopup = false
        },
        checkFileUploading() {
            let uploading = false
            let resultDocs = _.filter(this.documents, (docItem) => {
                return this.checkProperty(docItem, 'fileUploading') && docItem.fileUploading
            })
            console.log('resultDocs' + JSON.stringify(resultDocs))
            if (this.checkProperty(resultDocs, 'length') > 0) {
                if (!uploading) {
                    uploading = true
                }
            }
            this.isRevisionUplading = uploading
        },
    },
    computed: {
        getDocumentsToSubmitProfessor() {
            let resultDocs = []
            if (this.isLastCompletedActivity(this.evaluation, 'EVALUATION_TEMPLATE_ASSIGNED')
                || (this.checkProperty(this.evaluation, 'completedActivities').lastIndexOf('EVALUATION_TEMPLATE_ASSIGNED') > this.checkProperty(this.evaluation, 'completedActivities').lastIndexOf('EVALUATION_DOCUMENTS_SAVED'))) {
                if (this.checkProperty(this.evaluation, 'latestEvaluationLog', 'task') == 'merge' && this.checkProperty(this.evaluation, 'generatedDocuments', 'length') > 0) {
                    return this.checkProperty(this.evaluation, 'generatedDocuments')
                }
                if (this.checkProperty(this.evaluation, 'latestEvaluationLog', 'task') == 'add' && this.checkProperty(this.evaluation, 'evaluationDocuments', 'length') > 0) {
                    return this.checkProperty(this.evaluation, 'evaluationDocuments')
                }

            } 
            
            // else if (this.checkProperty(this.evaluation.latestEvaluationLog, 'documents', 'length') > 0) {
            //     return this.checkProperty(this.evaluation, 'latestEvaluationLog', 'documents')
            // } else {
            //     if (this.checkProperty(this.evaluation, 'evaluationDocuments', 'length') > 0) {
            //         return this.checkProperty(this.evaluation, 'evaluationDocuments')
            //     }
            // }

            return resultDocs
        },
        getLatestDocumentsSubmited() {
            let resultDocs = []
            if (this.checkProperty(this.evaluation, 'latestEvaluationLog', 'documents')
                && this.checkProperty(this.evaluation.latestEvaluationLog, 'documents', 'length') > 0) {
                return this.checkProperty(this.evaluation, 'latestEvaluationLog', 'documents')
            }
            return resultDocs
        }



    },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>