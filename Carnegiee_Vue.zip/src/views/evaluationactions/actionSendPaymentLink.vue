<template>
    <div class="wrapper-item">
        <div class="wrapper-item" v-if="!isCompletedActivity">
            <div class="section-year">
                <p> </p>
                <p> </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_pending"></span>
                    <div class="status-name pending_bg">Payment Link and Confirmation Email</div>
                    <div class="submit_detailes">
                        <!-- <div>
                            <h4>Preliminary Opinion <a class="link ms-2" @click="openTemplatePopup">Select
                                    Template</a>
                            </h4>
                            <textArea :tplkey="'preliminaryOption'" fieldName="preliminaryOption"
                                placeHolder="Template content ..." v-model="selectedTemplate.content"></textArea>

                        </div> -->


                        <div class="btn_flex">
                            <button class="primary_btn" @click="openPaymentEmailPopup">Send Payment Link
                            </button>

                        </div>
                    </div>
                </div>
            </section>
        </div>

        <div class="wrapper-item" v-if="isCompletedActivity">
            <div class="section-year">
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_pending"></span>
                    <div class="status-name pending_bg">Payment Link and Confirmation Email</div>
                    <div class="submit_detailes">
                        <div class="btn_flex">
                            <h4 class="mb-0"> Payment Link Sent by <b>{{ checkProperty(activityLog, 'updatedByName') }}</b>
                            </h4>
                            <div class="v_pay_details 2"
                                v-if="(checkProperty(evaluation, 'quotaPrice', 'evaluationPrices') && checkProperty(evaluation.quotaPrice, 'evaluationPrices', 'length') > 0)">

                                <b-dropdown size="lg" variant="link" toggle-class="text-decoration-none">
                                    <template #button-content>
                                        <b-button v-b-toggle.collapse-2 class="form-cancel">View Quote</b-button>
                                    </template>
                                    <b-dropdown-form>
                                        <div class="bill-card quote_card">
                                            <div class="bill-heading">
                                                <p>QUOTE</p>
                                            </div>
                                            <ul>
                                                <li v-for="(priceItem, indx) in checkProperty(evaluation, 'quotaPrice', 'evaluationPrices')"
                                                    :key="indx">
                                                    <div class="ammount">
                                                        {{ priceItem.evaluationTypeName }}
                                                    </div>
                                                    <span>${{ priceItem.price }}</span>
                                                </li>
                                                <li class="disc">
                                                    <p>{{ 'Discount ' + checkProperty(evaluation, 'quotaPrice', 'discount')
                                                        + ' Applied' }}
                                                    </p>
                                                    <p class="total"><span>Total</span>${{ checkProperty(evaluation,
                                                        'quotaPrice', 'total') }}</p>
                                                </li>
                                            </ul>

                                        </div>
                                    </b-dropdown-form>
                                </b-dropdown>
                            </div>
                        </div>
                        <!-- <div>
                            <p v-if="checkProperty(activityLog, 'contentData')"
                                v-html="checkProperty(activityLog, 'contentData')"></p>
                        </div> -->
                    </div>
                </div>
            </section>
        </div>

        <!-- Send Email Modal -->
        <b-modal v-model="showPaymentEmailPreview" ref="parentComponentRef" id="send_email_modal"
            dialog-class="create_template send_email_popup" centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Payment Link and Confirmation Email</h6>
                <a class="close" @click="closePaymentEmailPopup"></a>
            </template>
            <template>
                <form class="user_form create_temp" :data-vv-scope="'sendEmailForm'">
                    <div class="row">
                        <div class="col-md-12">
                            <div>
                                <h4 class="mb-3">Preliminary Opinion <a class="link ms-2" @click="openTemplatePopup">Select
                                        Template</a>
                                </h4>
                                <textArea :tplkey="'preliminaryOption'" fieldName="paymentPreliminaryContent"
                                    placeHolder="Template content ..." v-model="selectedTemplate.content"
                                    ref="paymentPreliminaryComponentRef"></textArea>

                            </div>
                        </div>

                    </div>
                </form>
            </template>
            <template #modal-footer>
                <div class="right_actions ms-auto">
                    <button class="form-cancel" @click="closePaymentEmailPopup">Cancel</button>
                    <button class="primary_btn sm" @click="$bvModal.show('payment_request')">Preview Email & Submit
                        <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
                </div>
            </template>
        </b-modal>


        <b-modal v-model="showTemplatePopup" id="template_model" dialog-class="delivery_template_model professors" centered
            no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Preliminary Opinion Templates</h6>
                <div class="d-flex">
                    <a class="close" @click="closeTemplatePopup"></a>
                </div>
            </template>
            <template>
                <form :data-vv-scope="'preliminaryTemplateForm'">
                    <simpleSelect :multiple="false" :wrapclass="'mb-3'" :optionslist="preliminaryTemplates" :display="true"
                        :placeHolder="'Select Template'" :searchable="false" :required="true" :close-on-select="true"
                        :clear-on-select="true" v-model="popupTemplate" :fieldName="'preliminaryTemplate'"
                        :cid="'preliminaryTemplate'" :hideSelected="false" :listContainsId="true" :trackBy="'title'"
                        :label="'Select Template'" :formscope="'preliminaryTemplateForm'" />

                    <!-- <textArea :wrapclass="'more_info'" :tplkey="'preliminaryTitle'" fieldName="preliminaryTitle"
                                placeHolder="Email subject here..." v-model="popupTemplate.title"></textArea>-->

                    <textArea v-if="checkProperty(popupTemplate, 'title')" class="mb-3" :tplkey="'paymentPreliminary'"
                        fieldName="paymentPreliminary" placeHolder="Email content here..."
                        v-model="popupTemplate.content"></textArea>
                </form>
            </template>
            <template #modal-footer>
                <button class="form-cancel" @click="closeTemplatePopup">Cancel</button>
                <button class="primary_btn md" @click="onTemplateSubmit">Use Content</button>
            </template>
        </b-modal>


        <!-- Preview Email Modal -->
        <b-modal id="payment_request" dialog-class="create_template payment_request" centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Preview Email</h6>
                <a class="close" @click="$bvModal.hide('payment_request')"></a>
            </template>
            <template>
                <form class="user_form create_temp bg-white">
                    <div class="subject">Subject: {{ checkProperty(evaluation, 'requestId') }}: Your Evaluation Request for
                        {{ getBeneficiaryName() }} is Confirmed.</div>
                    <div class="email_preview_wrapper">
                        <div class="top_head">
                            <div class="bg_white"></div>
                        </div>
                        <div class="main_cnt">
                            <div class="main_inr">
                                <p>Dear <strong>{{ getCustomerName() }}</strong>,</p>
                                <!-- <p>Carnegie evaluation requested for payment. Please find the payment link below.</p>
                                <p class="m-0">Total Amount: ${{ getEvaluationAmount() }}</p>
                                <p class="m-0" v-if="false">Created By: {{ checkProperty(getUserData, 'name') }}</p>
                                <p v-if="false">Time: Jun 22, 2023 7:58 AM CST</p> -->

                                <p v-html="selectedTemplate.content"></p>
                                <!-- <p><strong>Third-Party Payment Authorization Form</strong></p>
                                <p>
                                    To better serve our clients and simplify your billing experience, Carnegie Evaluations
                                    accepts payment via credit cards or e-checks for your convenience. We do not collect or
                                    store your personal details, credit card account information, or bank account details.
                                </p>
                                <p>By click on 'Proceed to Payment' I, <strong>{{ getCustomerName() }}</strong>, understand
                                    I am paying U.S
                                    <strong>${{ getEvaluationAmount() }}</strong> for the services (Credential
                                    Evaluations/Expert Opinions) sought from
                                    Carnegie Evaluations LLC. I also state that I am the account holder of the payment
                                    method, I use to make this payment. I understand I will receive no direct benefit from
                                    this transaction or the services provided. I also understand I am waiving my right to
                                    dispute this charge with my bank for claims of services not received by the account
                                    holder/ cardholder or other similar claims of non-service.
                                </p> -->
                                <div class="d-flex justify-content-center">
                                    <button class="primary_btn rounded-0 px-4 mb-3 hover_disabled" type="button">Proceed to
                                        Payment</button>
                                </div>
                                <!-- <div class="regards">
                                    Regards,
                                    <span>Carnegie Evaluations</span>
                                </div> -->
                                <div class="line_blue"></div>
                                <emailPreviewFooter></emailPreviewFooter>
                                <!-- <div class="email_footer">
                                    <a href="https://carnegieevaluations.com/app/" target="_blank">
                                        <img src="@/assets/images/logo_carne.png" alt="Carnegie Evaluations">
                                        <img src="@/assets/images/email_footer_logo2.png" alt="Carnegie Evaluations">
                                    </a>
                                    <a href="mailto:eval@carnegieevaluations.com"
                                        target="_blank">eval@carnegieevaluations.com</a>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </form>
            </template>
            <template #modal-footer>
                <button class="form-cancel menustyle" @click="$bvModal.hide('payment_request')">Cancel</button>
                <button class="primary_btn sm menustyle" @click="requestPayment">Submit</button>
            </template>
        </b-modal>
    </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import textArea from "@/views/forms/textarea.vue";
import emailPreviewFooter from "@/views/emailPreviewFooter.vue";


export default {
    props: {
        evaluation: Object,
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        activityLog: Object,
    },
    components: {
        simpleSelect,
        textArea,
        emailPreviewFooter,
    },
    data: () => ({
        loading: false,
        customerName: '',
        amount: 0,
        selectedTemplate: {
            title: "",
            content: ""
        },
        showTemplatePopup: false,
        preliminaryTemplates: [],
        showPaymentEmailPreview: false,
    }),
    mounted() {
        this.getTemplates()
        this.selectedTemplate.content = "<b>Third-Party Payment Authorization Form</b> </br> To better serve our clients and simplify your billing experience, Carnegie Evaluations accepts payment via credit cards or e-checks for your convenience. We do not collect or store your personal details, credit card account information, or bank account details.</br>By click on 'Proceed to Payment' I, <strong>" + this.getCustomerName() + "</strong>, understand I am paying U.S <strong>$" + this.getEvaluationAmount() + "</strong> for the services (Credential Evaluations/Expert Opinions) sought from Carnegie Evaluations LLC. I also state that I am the account holder of the payment method, I use to make this payment. I understand I will receive no direct benefit from this transaction or the services provided. I also understand I am waiving my right to dispute this charge with my bank for claims of services not received by the account holder/ cardholder or other similar claims of non-service."
    },
    methods: {
        getTemplates() {
            let postData = {
                "matcher": {
                    "title": "",
                    "statusIds": [],
                    "typeIds": [],
                    "createdByIds": [],
                    "createdDateRange": []
                },
                "sorting": {
                    "path": "createdOn", //title, statusName, createdByName, updatedOn, 
                    "order": -1
                },
                "getMasterData": true,
                "page": 1,
                "perpage": 500
            }
            this.$store.dispatch("getEmailsList", postData)
                .then((res) => {
                    this.preliminaryTemplates = res.data.result.list
                })
                .catch((error) => {
                })
        },
        requestPayment() {
            this.loading = true
            let postData = {
                "evaluationId": this.evaluation._id,
                "contentData": this.selectedTemplate.content
            }
            this.$store.dispatch("requestPayment", postData)
                .then((response) => {
                    this.loading = false
                    if (response.error) {
                        (response.error)
                        Object.assign(this.formerrors, {
                            msg: response.error.result
                        });
                        this.showToster({ message: response.error.result, isError: true });
                    } else {
                        this.selectedUser = null
                        this.showToster({ message: response.message, isError: false });
                        this.$emit('updateDetails')
                    }
                })
                .catch((error) => {
                    this.loading = false
                    this.showToster({ message: error, isError: true });
                })
        },
        getCustomerName() {
            return this.checkProperty(this.evaluation, 'name')
            // return this.checkProperty(this.evaluation, 'customersDetails', 'companyName') ? this.checkProperty(this.evaluation, 'customersDetails', 'companyName')
            //     : this.checkProperty(this.evaluation, 'customersDetails', 'name') ? this.checkProperty(this.evaluation, 'customersDetails', 'name')
            //         : this.checkProperty(this.evaluation, 'name')
        },

        getBeneficiaryName() {
            return this.checkProperty(this.evaluation, 'beneficiaryInformation', 'lastName') + " " + this.checkProperty(this.evaluation, 'beneficiaryInformation', 'firstName')
        },

        getEvaluationAmount() {
            return this.checkProperty(this.evaluation, 'quotaPrice', 'total')
        },
        openPaymentLink() {

        },
        openTemplatePopup() {
            if (this.checkProperty(this.selectedTemplate, 'title')
                && this.checkProperty(this.selectedTemplate, 'title') != '') {
                this.popupTemplate = this.selectedTemplate
            } else {
                this.popupTemplate = null
            }
            this.popupTemplate = null
            this.showTemplatePopup = true
        },
        closeTemplatePopup() {
            this.popupTemplate = null
            this.showTemplatePopup = false
        },
        onTemplateSubmit() {

            this.$validator.validateAll('preliminaryTemplateForm').then((result) => {
                if (result) {
                    // const editorInstance = this.$refs.paymentPreliminaryComponentRef.$refs.paymentPreliminaryContent.$_instance;
                    // if (editorInstance) {
                    //     const cursorPosition = editorInstance.model.document.selection.getFirstPosition();
                    //     editorInstance.model.change((writer) => {
                    //         writer.insertText(this.popupTemplate.content, cursorPosition);
                    //     });
                    //     this.selectedTemplate.content = editorInstance.getData();
                    // } else {
                    //     if (this.checkProperty(this.selectedTemplate, 'content')) {
                    //         let resultContent = this.popupTemplate.content + '</br></br>' + this.selectedTemplate.content
                    //         this.selectedTemplate.content = resultContent
                    //     } else {
                    //         this.selectedTemplate = this.popupTemplate
                    //     }
                    // }


                    if (this.checkProperty(this.selectedTemplate, 'content')) {
                        let resultContent =  this.selectedTemplate.content+""+this.popupTemplate.content
                        this.selectedTemplate.content = resultContent
                    } else {
                        this.selectedTemplate = this.popupTemplate
                    }

                    this.showTemplatePopup = false
                }
            })
        },
        openPaymentEmailPopup() {
            this.selectedTemplate.content = "<b>Third-Party Payment Authorization Form</b> </br> To better serve our clients and simplify your billing experience, Carnegie Evaluations accepts payment via credit cards or e-checks for your convenience. We do not collect or store your personal details, credit card account information, or bank account details.</br>By click on 'Proceed to Payment' I, <strong>" + this.getCustomerName() + "</strong>, understand I am paying U.S <strong>$" + this.getEvaluationAmount() + "</strong> for the services (Credential Evaluations/Expert Opinions) sought from Carnegie Evaluations LLC. I also state that I am the account holder of the payment method, I use to make this payment. I understand I will receive no direct benefit from this transaction or the services provided. I also understand I am waiving my right to dispute this charge with my bank for claims of services not received by the account holder/ cardholder or other similar claims of non-service."
            this.showPaymentEmailPreview = true
        },
        closePaymentEmailPopup() {
            this.showPaymentEmailPreview = false
        },
    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>