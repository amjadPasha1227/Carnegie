<template>
    <div class="wrapper-item">
        <div class="wrapper-item" v-if="!isCompletedActivity">
            <div class="section-year">
                <p></p>
                <p> </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_conform"></span>
                    <div class="status-name conform_bg">Confirm Evaluation</div>
                    <div class="submit_detailes new_confirm_review">
                        <div class="row">
                            <div class="col-md-12">
                                <customSelect :multiple="false" :wrapclass="'req_status'" :optionslist="usersList"
                                    :display="true" :place-holder="'Assign Professor'" :searchable="false" :required="true"
                                    :close-on-select="true" :clear-on-select="false" class="ass-eval" v-model="selectedUser"
                                    :fieldName="'user'" :cid="'user'" :vvas="'Professor'" :label="'Assign Professor'" />
                            </div>
                            <div class="col-md-6">
                                <datepicker :required="false" v-model="dueDate" fieldName="dueDate" label="Due Date"
                                    :dateEnableFrom="getCurrentDate()" />
                            </div>
                            <div class="col-md-6">
                                <simpleInput :fieldName="'invoiceNo'" :cid="'invoiceNo'" :label="'Invoice No'"
                                    :placeHolder="''" :vvas="'Invoice No'" :display="true" :required="false"
                                    v-model="invoiceId" />
                            </div>
                            <div class="col-md-6 checkbox_container" v-if="false">
                                <b-form-checkbox class="table_check quote_check" :id="''" :name="''">Send payment link
                                </b-form-checkbox>
                            </div>
                        </div>
                        <label class="editor-label">Comments</label>
                        <textArea class="mb-4 comments-ck_editer" :tplkey="'reviewConfirm'" fieldName="reviewConfirm"
                            placeHolder="" v-model="comments" :required="false" :vvas="'Comments'"></textArea>
                        <div class="d-flex justify-content-end">
                            <button class="primary_btn" @click="openEmailPopup">Preview Email & Confirm
                                <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
                        </div>
                        <!-- <p>Nulla semper interdum nunc, vitae ultricies leo commodo ut. Integer risus metus, rutrum nec nibh sit amet, hendrerit tempor nunc.</p> -->
                    </div>
                </div>
            </section>
        </div>
        <div class="wrapper-item" v-if="isCompletedActivity">
            <div class="section-year" v-if="checkProperty(reviewDetails, 'updatedOn')">
                <p> {{ checkProperty(reviewDetails, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(reviewDetails, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_conform"></span>
                    <div class="status-name conform_bg">Evaluation Confirmed</div>
                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(reviewDetails, 'updatedByName')">
                            Confirmed by <b>{{ checkProperty(reviewDetails,
                                'updatedByName') }}</b></h4>

                        <div class="exp_users_info mt-3"
                            v-if="getAssignedToDetails(checkProperty(reviewDetails, 'assignToDetails'))">
                            <div class="users-flex">
                                <p>Professor <span><img src="@/assets/images/subtraction.svg"> {{
                                    getAssignedToDetails(checkProperty(reviewDetails, 'assignToDetails')) }}</span></p>
                            </div>
                        </div>
                        <h4 class="mb-0 mt-2" v-if="checkProperty(reviewDetails, 'dueDate')">Due Date <b>{{
                            checkProperty(reviewDetails, 'dueDate') | formatDate }}</b></h4>
                        <h4 class="mt-2 mb-3" v-if="checkProperty(reviewDetails, 'invoiceNo')">Invoice No <b>{{
                            checkProperty(reviewDetails, 'invoiceNo') }}</b>
                        </h4>
                        <h4 v-if="checkProperty(reviewDetails, 'comments')">
                        </h4>
                        <!-- <h4>Comments</h4> -->
                        <div class="info_view" v-if="checkProperty(reviewDetails, 'comments')">

                            <p v-html="checkProperty(reviewDetails, 'comments')"></p>
                            <h3 class="mb-0"> {{ }}
                            </h3>
                        </div>

                    </div>
                </div>
            </section>
        </div>





        <!-- Send Email Modal -->
        <b-modal v-model="showEmailPreview" id="send_email_modal" ref="confirmProfessorParentRef"
            dialog-class="create_template send_email_popup" centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Email to Professor</h6>
                <a class="close" @click="closeEmailPopup"></a>
            </template>
            <template>
                <form class="user_form create_temp" :data-vv-scope="'sendEmailForm'">
                    <div class="row">
                        <div class="col-md-12">
                            <div>
                                <h4 class="mb-3">Preliminary Opinion <a class="link ms-2" @click="openTemplatePopup">Select
                                        Template</a>
                                </h4>
                                <textArea :tplkey="'confirmPreliminaryOptionRef'" fieldName="confirmPreliminaryOptionRef"
                                    placeHolder="Template content ..." v-model="selectedTemplate.content"
                                    ref="confirmPreliminaryComponentRef"></textArea>

                            </div>
                        </div>

                    </div>
                </form>
            </template>
            <template #modal-footer>
                <div class="right_actions ms-auto">
                    <button class="form-cancel" @click="closeEmailPopup">Cancel</button>
                    <button class="primary_btn sm" @click="openConfirmEmailPreview">Preview Email & Submit
                        <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
                </div>
            </template>
        </b-modal>

        <!-- Preview Email Modal -->
        <b-modal v-model="previewConfirmEmail" id="preview_modal_reviewed"
            dialog-class="create_template preview_modal_reviewed" centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Preview Email</h6>
                <a class="close" @click="previewConfirmEmail = false"></a>
            </template>
            <template>
                <form class="user_form create_temp bg-white">
                    <div class="subject">Subject:- {{ checkProperty(evaluation, 'requestId') }}: Upcoming Evaluation
                        Assignment and Verification Process.</div>

                    <div class="email_preview_wrapper">
                        <div class="top_head">
                            <div class="bg_white"></div>
                        </div>
                        <div class="main_cnt">
                            <div class="main_inr">
                                <p>Professor <strong>{{ checkProperty(selectedUser, 'lastName') }}</strong>,</p>
                                <p v-html="selectedTemplate.content"> </p>
                                <div class="line_blue mb-0 mt-2"></div>
                                <emailPreviewFooter></emailPreviewFooter>
                            </div>
                        </div>
                    </div>
                </form>
            </template>
            <template #modal-footer>
                <button class="form-cancel menustyle" @click="previewConfirmEmail = false">Cancel</button>
                <button class="primary_btn sm menustyle" @click="conformReview">Submit</button>
            </template>
        </b-modal>

        <div v-if="showTemplatePopup">
            <selectTemplate v-if="showTemplatePopup" @updateTemplate="onTemplateSubmit"
                @closeTemplatePopup="onTemplatePopupClose"></selectTemplate>

        </div>

    </div>
</template>


<script>
import textArea from "@/views/forms/textarea.vue";
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import radioInput from "@/views/forms/radioInput.vue";
import customSelect from '@/views/forms/customSelect.vue';
import datepicker from '@/views/forms/datePicker.vue';
import 'vue2-datepicker/index.css';
import moment from "moment";
import emailPreviewFooter from "@/views/emailPreviewFooter.vue";
import selectTemplate from "@/views/common/selectTemplate.vue"


export default {
    props: {
        evaluation: Object,
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        reviewDetails: Object,
    },
    components: {
        textArea,
        simpleSelect,
        simpleInput,
        radioInput,
        customSelect,
        datepicker,
        emailPreviewFooter,
        selectTemplate,
    },
    data: () => ({
        comments: '',
        loading: false,
        quotaPrice: {
            total: 0,
            discount: 0,
            evaluationPrices: []
        },
        usersList: [],
        selectedUser: null,
        dueDate: null,
        invoiceId: '',
        previewConfirmEmail: false,
        showEmailPreview: false,
        selectedTemplate: {
            title: "",
            content: ""
        },
        showTemplatePopup: false,
    }),
    mounted() {
        if (this.checkProperty(this.evaluation, 'customersDetails', 'discount')) {
            this.quotaPrice.discount = this.checkProperty(this.evaluation, 'customersDetails', 'discount')
        }
        this.assignAndCalucatePrices()
        this.getUsers()
    },
    methods: {
        onTemplatePopupClose() {
            this.showTemplatePopup = false
        },
        onTemplateSubmit(templateVal) {

            // const editorInstance = this.$refs.confirmPreliminaryComponentRef.$refs.confirmPreliminaryOptionRef.$_instance;
            // if (editorInstance) {
            //     const cursorPosition = editorInstance.model.document.selection.getFirstPosition();
            //     editorInstance.model.change((writer) => {
            //         writer.insertText(templateVal.content, cursorPosition);
            //     });
            //     this.selectedTemplate.content = editorInstance.getData();
            // } else {
                let resultContent = this.selectedTemplate.content+""+(this.checkProperty(templateVal, 'content') ? this.checkProperty(templateVal, 'content') : '')
                this.selectedTemplate.content = resultContent
            // }


            this.showTemplatePopup = false
        },
        openTemplatePopup() {
            // this.sendEmailContent = ''
            this.showTemplatePopup = true
        },
        getUsers() {
            let postData =
            {
                "matcher": {
                    "title": '',
                    "searchString": "",
                    "statusList": [],
                    "createdByIds": [],
                    "createdDateRange": [],
                    "roleIds": [9],
                    "statusIds": [],
                    "typeIds": [],
                    "departmentIds": []
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": true,// if Masterdata required
                "page": 1,
                "perpage": 500,
            }
            this.$store.dispatch("getUsersList", postData)
                .then((res) => {
                    let lst = []
                    _.forEach(res.data.result.list, (item) => {
                        let professorIndex = _.findIndex(this.checkProperty(this.evaluation, 'suggestProfessors'), (suggested) => {
                            return suggested["_id"] == item["_id"];
                        })
                        item['isSuggested'] = false;
                        if (professorIndex > -1) {
                            item['isSuggested'] = true;
                        }
                        lst.push(item);
                    });

                    this.usersList = lst
                })
                .catch((error) => {
                })
        },
        conformReview() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.loading = true
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "action": "REVIEW_CONFIRMED",
                        "comments": this.comments ? this.comments : '',
                        "assignedToProfessor": this.checkProperty(this.selectedUser, '_id') ? this.checkProperty(this.selectedUser, '_id') : '',
                        "dueDate": this.dueDate ? moment(this.dueDate).format('YYYY-MM-DD') : '',
                        "invoiceNo": this.invoiceId ? this.invoiceId : '',
                        "content": this.checkProperty(this.selectedTemplate, 'content') ? this.checkProperty(this.selectedTemplate, 'content') : '',
                    }
                    if (!this.isActivityCompleted(this.evaluation, 'EVALUATION_REVIEWED')) {
                        postData["quotaPrice"] = this.quotaPrice
                    }
                    this.$store.dispatch("evaluationReviewConfirm", postData)
                        .then((response) => {
                            this.loading = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                this.selectedUser = null
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')

                            }
                        })
                        .catch((error) => {
                            this.loading = false
                            this.showToster({ message: error, isError: true });
                        })
                }
            })
        },
        assignAndCalucatePrices() {
            let evaluationQuates = []
            if (this.checkProperty(this.evaluation, 'docsConfig', 'length') > 0) {
                _.forEach(this.evaluation.docsConfig, (item) => {
                    let evaluationPrice = {
                        evaluationTypeId: '',
                        evaluationTypeName: '',
                        price: 0,
                    }
                    evaluationPrice.evaluationTypeId = item.evaluationTypeId
                    evaluationPrice.evaluationTypeName = item.evaluationTypeName
                    evaluationPrice.price = item.price
                    evaluationQuates.push(evaluationPrice)
                })
            }
            this.quotaPrice.evaluationPrices = evaluationQuates
            this.updateTotalPrice()
        },
        updateTotalPrice() {

            let totalPrice = 0
            let discountAmount = 0
            if (this.checkProperty(this.quotaPrice, 'evaluationPrices', 'length') > 0) {
                _.forEach(this.quotaPrice.evaluationPrices, (item) => {
                    if (this.checkProperty(item, 'price') > 0) {
                        totalPrice += parseInt(item.price)
                    }
                })
            }
            if (this.checkProperty(this.quotaPrice, 'discount')) {
                discountAmount = ((totalPrice / 100) * this.checkProperty(this.quotaPrice, 'discount'))
            }
            if (totalPrice - discountAmount < 0) {
                this.quotaPrice.total = 0
            } else {
                this.quotaPrice.total = totalPrice - discountAmount
            }
        },
        getCurrentDate() {
            return moment().subtract(1, 'days')
        },
        openConfirmEmailPreview() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.previewConfirmEmail = true
                }
            })
        },
        getBeneficiaryName() {
            return this.checkProperty(this.evaluation, 'beneficiaryInformation', 'lastName') + " " + this.checkProperty(this.evaluation, 'beneficiaryInformation', 'firstName')
        },
        openEmailPopup() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.selectedTemplate.content = this.getEmailContent
                    this.showEmailPreview = true
                }
            })

        },
        closeEmailPopup() {
            this.showEmailPreview = false
        },


    },

    computed: {

        getEmailContent() {

            return "We have just confirmed a case today for you. This case should be ready for you to review in the next " +
                '<b> ' + "2 " + '</b>' + " business days. The case is for " + '<b> ' + this.checkProperty(this.evaluation, 'beneficiaryInformation', 'firstName')
                + " " + this.checkProperty(this.evaluation, 'beneficiaryInformation', 'lastName') + '</b>' + " and it will be " + this.getEvaluationNames + "." +
                " There is no need to reply to this email as it is simply meant to be an alert on an upcoming case for you to review. However, if for some reason you will not be available for the review, please let us know immediately so we can let the client know and make alternate arrangements." +
                " You may email us back at <a href='eval@carnegieevaluations.com' target='_blank'>eval@carnegieevaluations.com</a> or speak to us at <a href='848-300-0099' target='_blank'>848-300-0099</a>."


            //  return "An upcoming evaluation " + '<b> ' + this.checkProperty(this.evaluation, 'requestId') + '</b>' + " has been assigned to you as part of our ongoing assessment process. This evaluation is a crucial aspect of our commitment to maintaining and enhancing the quality of our academic programs.<br><br> In the next few days, you can expect to receive an email from our evaluation team containing information about the assessment to proceed with the verification process. Your prompt attention to this matter would be greatly appreciated. "
        },
        getEvaluationNames() {
            let evaluationName = ""
            if (this.checkProperty(this.evaluation, 'docsConfig', 'length') > 0) {
                _.forEach(this.checkProperty(this.evaluation, 'docsConfig'), (item, indx) => {

                    if (this.checkProperty(evaluationName, 'length') == 0) {
                        evaluationName = item.evaluationTypeName
                    } else {
                        evaluationName = evaluationName + ", " + item.evaluationTypeName
                    }
                })
            }
            if (this.checkProperty(this.evaluation, 'docsConfig', 'length') == 1) {
                evaluationName = "a <b>" + evaluationName + '</b>'
            } else {
                evaluationName = "<b>" + evaluationName + '</b>'
            }
            return evaluationName

        }
    },



    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>