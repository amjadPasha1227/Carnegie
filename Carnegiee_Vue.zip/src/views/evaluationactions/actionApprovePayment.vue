<template>
    <div class="wrapper-item">
        <div class="wrapper-item" v-if="!isCompletedActivity">
            <div class="section-year">
                <p> </p>
                <p> </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_paid"></span>
                    <div class="status-name paid_bg">Paid</div>
                    <div class="submit_detailes">
                        <textArea class="mb-4" :tplkey="'paymentDetails'" fieldName="paymentDetails"
                            placeHolder="Payment Details" v-model="paymentDetails" :required="true"
                            :vvas="'Payment Details'"></textArea>

                        <button class="primary_btn" @click="updatePaymentDetails">Payment Received
                            <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>

                    </div>
                </div>
            </section>
        </div>

        <div class="wrapper-item" v-if="isCompletedActivity">

            <div class="section-year">
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_paid"></span>
                    <div class="status-name paid_bg">Paid</div>
                    <div class="submit_detailes">
                        <div class="btn_flex">
                            <h4 class="mb-0"> Payment details updated by <b>{{ checkProperty(activityLog,'updatedByName') }}</b> </h4>
                        </div>

                        <h4 v-if="checkProperty(activityLog, 'comments')"></h4>
                        <div class="info_view"
                            v-if="checkProperty(activityLog, 'comments')">
                            <p v-html="checkProperty(activityLog, 'comments')"></p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import textArea from "@/views/forms/textarea.vue";
export default {
    props: {
        evaluation: Object,
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        activityLog: Object,
    },
    components: {
        simpleSelect,
        textArea,
    },
    data: () => ({
        loading: false,
        paymentDetails: '',
    }),
    mounted() {
    },
    methods: {
        updatePaymentDetails() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.loading = true
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "action": "PAYMENT_UPDATED",
                        "comments": this.paymentDetails,
                        "transactionId": "",
                        "paymentId": '',

                    }
                    if (this.checkProperty(this.evaluation, 'paymentStatsDetails', '_id')) {
                        postData.paymentId = this.checkProperty(this.evaluation, 'paymentStatsDetails', '_id')
                    }
                    this.$store.dispatch("updatePayment", postData)
                        .then((response) => {
                            this.loading = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                this.selectedUser = null
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')
                            }
                        })
                        .catch((error) => {
                            this.loading = false
                            this.showToster({ message: error, isError: true });
                        })
                }
            })

        },


    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>