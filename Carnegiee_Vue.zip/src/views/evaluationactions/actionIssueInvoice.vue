<template>
  <div class="wrapper-item">
    <div class="wrapper-item" v-if="!isCompletedActivity">
      <div class="section-year">
        <p></p>
        <p></p>
      </div>
      <section class="timeline-item">
        <div class="item">
          <span class="status_dot status_review"></span>
          <div class="status-name review_bg">Issue Invoice</div>
          <div class="submit_detailes">
            <div class="form_info">
              <div class="invoice-flex">
                <simpleInput :fieldName="'invoiceNo'" :cid="'invoiceNo'" :label="'Invoice No'" :placeHolder="''"
                  :vvas="'Invoice No'" :display="true" :required="true" v-model="invoiceId" />

                <simpleInput :fieldName="'invoiceComments'" :cid="'invoiceComments'" :label="'Comments'" :placeHolder="''"
                  :vvas="'Comments'" :display="true" :required="false" v-model="comments" />

              </div>
              <div class="mt-4">
                <h4>Quote Price</h4>
                <div class="bill-card">
                  <ul>
                    <li v-for="(evaluationItem, indx) in quotaPrice.evaluationPrices">
                      <div class="ammount">
                        {{ evaluationItem.evaluationTypeName }}
                      </div>
                      <simpleInput :fieldName="'evaluationAmount'" :cid="'evaluationAmount'" :label="''"
                        :placeHolder="'$000'" :vvas="'Amount'" :display="true" :required="false"
                        v-model="quotaPrice.evaluationPrices[indx].price" :onlyNumbers="true" @input="updateTotalPrice"
                        :maxLength="5" :disabled="isActivityCompleted(evaluation, 'PAYMENT_UPDATED')" />
                    </li>

                    <li class="discount">
                      <p>Discount</p>
                      <div class="form_group">
                        <simpleInput class="form-control" :fieldName="'evaluationDiscount'" :cid="'evaluationDiscount'"
                          :label="''" :placeHolder="'000'" :vvas="'Discount'" :display="true" :required="false"
                          :onlyNumbers="true" :maxLength="5" v-model="quotaPrice.discount" @input="updateTotalPrice"
                          :disabled="isActivityCompleted(evaluation, 'PAYMENT_UPDATED')" />
                      </div>
                      <em v-if="false" class="per_symb">%</em>
                    </li>
                    <li class="discount">
                      <p>Total</p>
                      <span>{{ '$' + quotaPrice.total }}</span>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="drop_files mb-0">
                <fileUploadDrag :label="'Documents'" :wrapclass="'mb10'" :multiple="true" v-model="documents"
                  @uploadingFile="checkFileUploading($event)" :fieldName="'uploadInvoiceDocs'" :display="'uploadInvoiceDocs'" />
                <input type="hidden" class="form-control" v-model="documents" data-vv-as="Documents"
                  :name="'userroleRadio'" />
                <span v-show="errors.has('userroleRadio')" class="form-error top_auto">{{
                  errors.first('userroleRadio')
                }}</span>
              </div>
              <div>

                <button :disabled="isFileUplading" class="primary_btn" @click="createInvoice">Issue Invoice
                  <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span>
                </button>
              </div>

            </div>
          </div>
        </div>
      </section>
    </div>
    <div v-if="isCompletedActivity" class="wrapper-item">
      <div class="section-year">
        <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime }} </p>
        <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate }} </p>
      </div>
      <section class="timeline-item">
        <div class="item">
          <span class="status_dot status_review"></span>
          <div class="status-name review_bg">Invoice Details</div>
          <div class="submit_detailes">
            <h4 v-if="checkProperty(activityLog, 'updatedByName')">Issued by <b>{{
              checkProperty(activityLog, 'updatedByName') }}</b></h4>

            <h3 class="mb-0" v-if="checkProperty(evaluation, 'invoiceDetails', 'invoiceNo')">Invoice No {{
              checkProperty(evaluation, 'invoiceDetails', 'invoiceNo') }} <a @click="showInvoiceDetails"
                class="link ms-2">View Invoice</a>
            </h3>
            <h4 class="mb-0" v-if="checkProperty(evaluation, 'invoiceDetails', 'comments')">{{ checkProperty(evaluation,
              'invoiceDetails', 'comments') }}</h4>

            <div class="doc_files mt-3">
              <DocumentsPreview :type="'documents'" :documentsList="checkProperty(activityLog, 'documents')"
                :includeDownloadText="false" @download_or_view="downloadFile" />

            </div>
          </div>
        </div>
      </section>
    </div>

    <!-- side navbar1 -->
    <b-sidebar id="sidebar-no-header" v-model="showDetailsPopup" aria-labelledby="sidebar-no-header-title"
      sidebar-class="customer-sidenav" title="#INV-3066" right no-header backdrop shadow @change="toggleBodyScrollbar">
      <template #default="{ hide }">
        <span class="loader" v-if="isDetailsLoading"><img src="@/assets/images/loader.gif"></span>
        <div class="sidenav_header">
          <div class="invoice_name">
            <h3>{{ checkProperty(invoiceInfo, 'invoiceNo') }}</h3>
          </div>
          <div class="invoice_activitys">
            <ul>
              <li><button class="invoice_btn" @click="downloadInvoice(invoiceInfo, true)"><img
                    src="@/assets/images/vision.png"></button></li>
              <li><button class="invoice_btn" @click="downloadInvoice(invoiceInfo)"><img
                    src="@/assets/images/download.png"></button></li>
              <li><button class="invoice_btn" v-if="checkProperty(invoiceInfo, 'statusDetails', 'id') == 1"
                  @click="sendRemainders"> <span class="loader" v-if="remainderSending"><img
                      src="@/assets/images/loader.gif"></span><img src="@/assets/images/reminder.png">&nbsp; Send Reminder
                </button></li>
              <li><button class="invoice_btn status " v-if="checkProperty(invoiceInfo, 'statusDetails', 'name')"
                  v-bind:class="{
                    'pending_payment': checkProperty(invoiceInfo, 'statusDetails', 'id') == 1,
                    'confirmed': [2, 3].indexOf(checkProperty(invoiceInfo, 'statusDetails', 'id')) > -1,
                  }">{{ checkProperty(invoiceInfo, 'statusDetails', 'name') }}</button></li>
            </ul>
            <a class="close" block @click="hide"><img src="@/assets/images/close.svg"></a>
          </div>
        </div>

        <VuePerfectScrollbar>
          <div class="inv-table">

            <ul>
              <li
                v-if="checkProperty(invoiceInfo, 'customerDetails', 'companyName') || checkProperty(invoiceInfo, 'customerDetails', 'name')">
                <span>CLIENT</span>
                <p><a>{{ checkProperty(invoiceInfo, 'customerDetails', 'companyName') ? checkProperty(invoiceInfo,
                  'customerDetails', 'companyName') : checkProperty(invoiceInfo, 'customerDetails', 'name') }}</a></p>
              </li>
              <li
                v-if="checkProperty(invoiceInfo, 'evaluationDetails', 'priorityDetails') && checkProperty(invoiceInfo.evaluationDetails, 'priorityDetails', 'id')">
                <span>Priority</span>
                <p v-if="checkProperty(invoiceInfo.evaluationDetails, 'priorityDetails', 'id') == 2"><img
                    src="@/assets/images/flash.png">{{ checkProperty(invoiceInfo.evaluationDetails, 'priorityDetails',
                      'name') }}</p>
                <p v-if="checkProperty(invoiceInfo.evaluationDetails, 'priorityDetails', 'id') != 2">{{
                  checkProperty(invoiceInfo.evaluationDetails, 'priorityDetails', 'name') }}</p>
              </li>
              <li
                v-if="checkProperty(invoiceInfo, 'customerDetails', 'billingTypeDetails') && checkProperty(invoiceInfo.customerDetails.billingTypeDetails, 'name')">
                <span>BILLING TYPE</span>
                <p>{{ checkProperty(invoiceInfo.customerDetails, 'billingTypeDetails', 'name') }}</p>
              </li>
            </ul>
            <div class="table-responsive"
              v-if="checkProperty(invoiceInfo, 'evaluationDetails', 'quotaPrice') && checkProperty(invoiceInfo.evaluationDetails, 'quotaPrice', 'evaluationPrices')">
              <table class="table invoice_table">
                <thead>
                  <tr>
                    <th>DATE</th>
                    <th>EVALUATIONS</th>
                    <th>PRIORITY</th>
                    <th>AMOUNT</th>
                  </tr>
                </thead>
                <tbody>


                  <tr
                    v-for="(evaluationPrice, indx) in  checkProperty(invoiceInfo.evaluationDetails, 'quotaPrice', 'evaluationPrices') "
                    v-bind:key="indx">
                    <td><span>{{ checkProperty(invoiceInfo, 'createdOn') | formatDate }}</span></td>
                    <td>{{ checkProperty(evaluationPrice, 'evaluationTypeName') }}</td>
                    <td><span
                        :class="{ 'rush': checkProperty(invoiceInfo.evaluationDetails, 'priorityDetails', 'id') == 2 }">{{
                          checkProperty(invoiceInfo.evaluationDetails, 'priorityDetails', 'name') }}</span></td>
                    <td>{{ '$' + checkProperty(evaluationPrice, 'price') }}</td>
                  </tr>

                  <tr
                    v-if="checkProperty(invoiceInfo, 'evaluationDetails', 'quotaPrice') && checkProperty(invoiceInfo.evaluationDetails, 'quotaPrice', 'total')">
                    <td colspan="4">
                      <div class="total_amount">
                        <p>{{ 'Discount ' + checkProperty(invoiceInfo.evaluationDetails, 'quotaPrice', 'discount') + ' Applied'}} </p>
                        <span>Total Amount</span>{{ '$' + checkProperty(invoiceInfo.evaluationDetails, 'quotaPrice',
                          'total') }}
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div
              v-if="checkProperty(evaluation, 'invoiceDetails', 'documents') && checkProperty(evaluation.invoiceDetails, 'documents', 'length') > 0">
              <spam style="padding: 20px; color: #272846;
                font-size: 14px;"> Invoice Documents</spam>
              <DocumentsPreview :type="'documents'"
                :documentsList="checkProperty(evaluation, 'invoiceDetails', 'documents')"
                :includeDownloadText="false" @download_or_view="downloadFile" />

            </div>
          </div>
        </VuePerfectScrollbar>
      </template>
    </b-sidebar>

    <b-modal id="preview_model" v-model="docPrivew" dialog-class="document_modal"
      :title="checkProperty(selectedFile, 'name')" hide-footer>
      <h2> <img :class="{
        pdf_view_download: docType == 'pdf',
        office_view_download: docType == 'office',
        image_view_download: docType == 'image',
      }" class="download-button" @click="downloads3file({ path: selectedFile.path })"
          src="@/assets/images/download.svg" /></h2>
      <div class="pdf_loader">
        <figure v-if="false" class="loader loader2"><img src="@/assets/images/loader.gif" /></figure>

        <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
        <template v-if="docType == 'office'">
          <div style="height:90vh">

            <div id="placeholder" name="placeholder" style="height:100%"></div>
          </div>
        </template>
        <template v-else-if="docType == 'image'">
          <img :src="docValue" />
        </template>
        <template v-else-if="docType == 'pdf'">
          <div class="pdf" style="height:90vh">

            <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%" width="100%">

            </iframe>
          </div>
        </template>
      </div>
    </b-modal>
  </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from '@/views/forms/simpleInput.vue';
import VuePerfectScrollbar from 'vue-perfect-scrollbar'
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import DocumentsPreview from '@/views/common/documentsPreview.vue';

export default {
  props: {
    evaluation: Object,
    isCompletedActivity: {
      type: Boolean,
      default: false
    },
    activityLog: Object,
  },
  components: {
    simpleSelect,
    simpleInput,
    VuePerfectScrollbar,
    fileUploadDrag,
    DocumentsPreview,
  },
  data: () => ({
    invoiceId: '',
    comments: '',
    loading: false,
    showDetailsPopup: false,
    invoiceInfo: null,
    remainderSending: false,
    docPrivew: false,
    docType: '',
    docValue: '',
    selectedFile: null,
    quotaPrice: {
      total: 0,
      discount: 0,
      evaluationPrices: []
    },
    documents: [],
    isFileUplading: false,
  }),
  mounted() {
    this.assignAndCalucatePrices()
    if (this.checkProperty(this.getActivityLog(this.evaluation, 'INVOICE_SAVED'), 'invoiceNo')) {
      this.invoiceId = this.checkProperty(this.getActivityLog(this.evaluation, 'INVOICE_SAVED'), 'invoiceNo')
    }

  },
  methods: {
    toggleBodyScrollbar(visible) {
      const body = document.getElementsByTagName('body')[0];

      if (visible)
        body.classList.add("overflow-hidden");
      else
        body.classList.remove("overflow-hidden");
    },

    createInvoice() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          this.loading = true
          let postData = {
            "evaluationId": this.evaluation._id,
            "invoiceNo": this.invoiceId,
            "comments": this.comments,
            "documents":[]
          }
          if (this.checkProperty(this.quotaPrice, 'total') > 0
            && this.checkProperty(this.quotaPrice, 'evaluationPrices', 'length') > 0) {
            postData["quotaPrice"] = this.quotaPrice
          }
          if (this.checkProperty(this.documents, 'length') > 0) {
            postData["documents"] = this.documents
          }

          this.$store.dispatch("createInvoice", postData)
            .then((response) => {
              this.loading = false
              if (response.error) {
                (response.error)
                Object.assign(this.formerrors, {
                  msg: response.error.result
                });
                this.showToster({ message: response.error.result, isError: true });
              } else {
                // this.selectedUser = null
                this.showToster({ message: response.message, isError: false });
                this.$emit('updateDetails')

              }
            })
            .catch((error) => {
              this.loading = false
              this.showToster({ message: error, isError: true });
            })


        }
      })
    },

    showInvoiceDetails() {

      if (this.checkProperty(this.evaluation, 'invoiceId')) {
        let postData =
        {
          "invoiceId": this.evaluation.invoiceId,
        }
        this.$store.dispatch("getInvoiceDetails", postData)
          .then((res) => {
            this.invoiceInfo = res.result
            // setTimeout(() => {
            this.showDetailsPopup = true
            // })

          })
          .catch((error) => {

          })
      }



      // this.$emit('showInvoice')
    },
    sendRemainders() {
      this.remainderSending = true
      let postData =
        { "invoiceIds": [this.evaluation.invoiceId], }
      this.$store.dispatch("sendInvoiceRemainders", postData)
        .then((response) => {
          this.remainderSending = false
          if (response.error) {
            (response.error)
            Object.assign(this.formerrors, {
              msg: response.error.result
            });
            this.showToster({ message: response.error.result, isError: true });
          } else {
            this.showToster({ message: response.message, isError: false });
          }
        })
        .catch((error) => {
          this.remainderSending = false
          this.showToster({ message: error, isError: true });
        })
    },
    downloadInvoice(selectedItem, isView = false) {

      // if (this.checkProperty(this.invoiceInfo, 'invoicePath')) {
      //   if (isView) {
      //     let docItem = {
      //       path: this.checkProperty(this.invoiceInfo, 'invoicePath'),
      //       name: this.checkProperty(this.invoiceInfo, 'fileName')
      //     }
      //     this.selectedFile = docItem
      //     setTimeout(() => {
      //       this.viewInvoice(docItem)
      //     })
      //   } else {
      //     this.downloads3file({ 'path': this.checkProperty(this.invoiceInfo, 'invoicePath') })
      //   }
      // }
      // else {
      this.remainderSending = true
      let postData =
      {
        "invoiceId": this.evaluation.invoiceId,
        "download": true,
      }
      this.$store.dispatch("downloadInvoiceFile", postData)
        .then((response) => {
          this.remainderSending = false
          if (response.error) {
            (response.error)
            Object.assign(this.formerrors, {
              msg: response.error.result
            });
            this.showToster({ message: response.error.result, isError: true });
          } else {
            let downloadFilePath = response.result.s3UrlPath
            let fileName = response.result.fileName
            if (isView) {
              let docItem = {
                path: downloadFilePath,
                name: fileName
              }
              this.selectedFile = docItem
              setTimeout(() => {
                this.viewInvoice(docItem)
              })
            } else {
              this.downloads3file({ 'path': downloadFilePath })
            }
            this.remainderSending = false

          }
        })
        .catch((error) => {
          this.remainderSending = false
          this.showToster({ message: error, isError: true });
        })
      //  }
    },
    viewInvoice(docItem) {
      this.docValue = docItem.path;
      this.docType = this.findmsDoctype(docItem["path"], docItem.mimetype);
      let value = _.cloneDeep(docItem)
      var _self = this;
      this.formSubmited = false;
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }
      this.docValue = "";
      this.docPrivew = false;
      this.docType = this.findmsDoctype(value["path"], value.mimetype);

      if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
        //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
          // "petitionId": value['petitionId'],

          // entityType:value['petitionId']
          "fileName": value.name ? value.name : ''
        };
        // if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
        //   postdata['entityType'] = 'perm'
        // } else {
        //   postdata['entityType'] = 'case'
        // }


        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;
          if (this.docType == "office") {
            this.docPrivew = true;
            setTimeout(() => {
              document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
              let _editing = false;

              // if ([3, 4].indexOf(this.getUserRoleId) > -1) {
              //   _editing = false;
              // }

              // if (value.viewmode) {
              //   _editing = false;
              // }
              var _ob = {}
              // if (value.editedDocument) {
              //   _ob = {

              //     evaluationId: this.evaluationDetails._id,
              //     name: value.name,
              //     _id: value._id,
              //     "extn": "docx",
              //     "formLetterType": "Letter",
              //     parentId: value.parentId
              //   }

              // } else {

              _ob = {

                name: value.name,
                evaluationId: this.evaluationDetails._id,
                _id: value._id,
                "extn": "docx",
                "formLetterType": "Letter",
                parentId: value._id

              }

              //  }


              window.docEditor = new DocsAPI.DocEditor("placeholder2",
                {

                  "document": {
                    "c": "forcesave",
                    "fileType": "docx",
                    "key": value._id,
                    "userdata": JSON.stringify(_ob),
                    "title": value.name,
                    "url": response.data.result.data,
                    permissions: {
                      edit: _editing,
                      download: true,
                      reader: false,
                      review: false,
                      comment: false
                    }
                  },

                  "documentType": "word",
                  "height": "100%",
                  "width": "100%",

                  "editorConfig": {
                    "userdata": JSON.stringify(_ob),
                    "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                    "customization": {
                      "logo": {
                        "image": "https://immibox.com/app/favicon.png",
                        "imageDark": "https://immibox.com/app/favicon.png",
                        "url": "https://immibox.com"
                      },
                      "anonymous": {
                        "request": false,
                        "label": "Guest"
                      },
                      "chat": false,
                      "comments": false,
                      "compactHeader": false,
                      "compactToolbar": true,
                      "compatibleFeatures": false,
                      "feedback": {
                        "visible": false
                      },
                      "forcesave": true,
                      "help": false,
                      "hideNotes": true,
                      "hideRightMenu": true,
                      "hideRulers": true,
                      layout: {
                        toolbar: {
                          "collaboration": false,
                        },
                      },
                      "macros": false,
                      "macrosMode": "warn",
                      "mentionShare": false,
                      "plugins": false,
                      "spellcheck": false,
                      "toolbarHideFileName": true,
                      "toolbarNoTabs": true,
                      "uiTheme": "theme-light",
                      "unit": "cm",
                      "zoom": 100
                    },
                  }, events: {
                    onReady: function () {

                    },
                    onDocumentStateChange: function (event) {
                      var url = event.data;
                      console.log(event)

                      if (!event.data) {

                        if (value.editedDocument) {

                        }

                      }
                    }

                  }
                });
              //this.docValue = encodeURIComponent(response.data.result.data);
            }, 100)
          }

          if (this.docType == "pdf") {

            // this.downloadFile(this.docValue, value.mimetype, value.name)

            // return
            var _vid = value._id;
            if (value.parentId) {
              _vid = value.parentId;
            }
            var viewmode = 1; // Enable edit
            viewmode = 0; //Disabled Edit
            if (value.viewmode) {
              viewmode = 0;
            }
            this.docValue = "https://carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
            console.log(this.docValue)
            this.docPrivew = true;
          }
          if (this.docType == "image") {
            this.docPrivew = true;
          }



        });
      } else {
        this.downloads3file(value);
      }

    },
    assignAndCalucatePrices() {
      // let evaluationQuates = []
      // if (this.checkProperty(this.evaluation, 'docsConfig', 'length') > 0) {
      //   _.forEach(this.evaluation.docsConfig, (item) => {
      //     let evaluationPrice = {
      //       evaluationTypeId: '',
      //       evaluationTypeName: '',
      //       price: 0,
      //     }
      //     evaluationPrice.evaluationTypeId = item.evaluationTypeId
      //     evaluationPrice.evaluationTypeName = item.evaluationTypeName
      //     evaluationPrice.price = item.price
      //     evaluationQuates.push(evaluationPrice)
      //   })
      // }
      // this.quotaPrice.evaluationPrices = evaluationQuates
      this.quotaPrice = this.evaluation.quotaPrice
      this.updateTotalPrice()
    },
    updateTotalPrice() {

      let totalPrice = 0
      let discountAmount = 0
      if (this.checkProperty(this.quotaPrice, 'evaluationPrices', 'length') > 0) {
        _.forEach(this.quotaPrice.evaluationPrices, (item) => {
          if (this.checkProperty(item, 'price') > 0) {
            totalPrice += parseInt(item.price)
          }
        })
      }
      if (this.checkProperty(this.quotaPrice, 'discount')) {
        discountAmount = this.checkProperty(this.quotaPrice, 'discount')
      }
      if (discountAmount > totalPrice) {
        discountAmount = 0
        this.quotaPrice.discount = 0
        this.quotaPrice.total = totalPrice
      } else {
        this.quotaPrice.total = totalPrice - discountAmount
      }
    },
    checkFileUploading() {
      let uploading = false
      let resultDocs = _.filter(this.documents, (docItem) => {
        return this.checkProperty(docItem, 'fileUploading') && docItem.fileUploading
      })
      console.log('resultDocs' + JSON.stringify(resultDocs))
      if (this.checkProperty(resultDocs, 'length') > 0) {
        if (!uploading) {
          uploading = true
        }
      }
      this.isFileUplading = uploading
    },
    downloadFile(value) {
      this.$emit('download_or_view', value);
    },
  },

  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
}
</script>