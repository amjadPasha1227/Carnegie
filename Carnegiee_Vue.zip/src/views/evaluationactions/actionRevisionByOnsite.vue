<template>
    <div class="wrapper-item">
        <div class="wrapper-item" v-if="!isCompletedActivity">
            <div class="section-year">
                <p> </p>
                <p></p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_req"></span>
                    <div class="status-name req_bg">Final Review</div>
                    <div class="submit_detailes">
                        <button class="primary_btn" @click="openFileUploadPopup">Upload Documents</button>
                        <!-- <fileUpload :wrapclass="'no_doc_name'" :tplkey="'evaluationdocuments'" v-model="documents"
                            :tplsection="'evaluationdocuments'" label="" vvas="Document" :fieldName="'evaluationdocuments'"
                            :cid="'evaluationdocuments'" :multiple="true" :deleteDocPermenantly="true">
                        </fileUpload> -->

                    </div>
                </div>
            </section>
        </div>
        <div class="wrapper-item" v-if="isCompletedActivity">
            <div class="section-year">
                <p> {{ checkProperty(activityLog, 'updatedOn') |
                    formatTime
                }} </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') |
                    formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_req"></span>
                    <div class="status-name req_bg">Final Review</div>
                    <div class="submit_detailes">
                        <h4
                            v-if="checkProperty(activityLog, 'updatedByName')">
                            Revision by <b>{{ checkProperty(activityLog,'updatedByName') }}</b></h4>
                        <div class="doc_files">
                            <!-- <ul>
                                <li v-for="(evaluationItem, indx) in checkProperty(evaluation, 'evaluationDocuments')"> -->
                            <h3 v-if="checkProperty(activityLog, 'revisedDocuments', 'clientDocuments')
                                && checkProperty(activityLog.revisedDocuments, 'clientDocuments', 'length') > 0">
                                Client Copies
                            </h3>
                            <DocumentsPreview :type="'documents'"
                                :documentsList="checkProperty(activityLog, 'revisedDocuments', 'clientDocuments')"
                                :includeDownloadText="false" @download_or_view="downloadFile" />
                            <h3 v-if="checkProperty(activityLog, 'revisedDocuments', 'professorDocuments')
                                && checkProperty(activityLog.revisedDocuments, 'professorDocuments', 'length') > 0">
                                Professor Copies </h3>
                            <DocumentsPreview :type="'documents'"
                                :documentsList="checkProperty(activityLog, 'revisedDocuments', 'professorDocuments')"
                                :includeDownloadText="false" @download_or_view="downloadFile" />

                            <!-- </li>
                            </ul> -->
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <b-modal id="doc_model" v-model="showUploadDocsPopup" dialog-class="status-popup professors documents" centered
            no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Final Review</h6>
                <a class="close" @click="hideFileUploadTemplatePopup"></a>
            </template>
            <template>
                <div class="rq_header d-block">
                    <div class="user_info_sec sub_prof_sec pb-0">
                        <div class="drop_files position-relative">
                            <fileUploadDrag :label="'Client Copy*'" :wrapclass="'mb20'" :multiple="true"
                                v-model="clientDocuments" :fieldName="'copyClient'" :cid="'copyClient'" :required="true"
                                @uploadingFile="checkFileUploading($event)"  :fileTypes="'application/pdf'"
                                @download_or_view="downloadFile" :isShowPreview="true"/>
                                <span v-show="errors.has('userroleRadio')" class="form-error">{{
                            errors.first('userroleRadio')
                        }}</span>
                        </div>
                        <input type="hidden" class="form-control" v-validate="'required'" v-model="clientDocuments"
                            data-vv-as="Client Copy" :name="'userroleRadio'" />
                        <div class="drop_files mb-0 pb-4">
                            <fileUploadDrag :label="'Professor Copy (Optional)'" :wrapclass="'mb-0'" :multiple="true"
                                v-model="professorDocuments" :fieldName="'copyProfessor'" :cid="'copyProfessor'"
                                @uploadingFile="checkFileUploading($event)" :fileTypes="'application/pdf'"  @download_or_view="downloadFile" :isShowPreview="true"/>
                        </div>
                    </div>
                </div>

            </template>
            <template #modal-footer>
                <button class="form-cancel" @click="hideFileUploadTemplatePopup">Cancel</button>
                <button :disabled="isFileUplading" class="primary_btn md" @click="checkAndShowConfirmPopup">Submit
                    <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
            </template>
        </b-modal>
        <UploadDocsConfirmPopup v-if="showSubmitConfirmPopup" @submitAction="submitAction"></UploadDocsConfirmPopup>

    </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import fileUpload from "@/views/forms/fileupload.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import UploadDocsConfirmPopup from '@/views/common/uploadDocsConfirmPopup.vue';

export default {
    props: {
        evaluation: Object,
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        activityLog: Object,
    },
    components: {
        simpleSelect,
        fileUpload,
        fileUploadDrag,
        DocumentsPreview,
        UploadDocsConfirmPopup,
    },
    data: () => ({
        clientDocuments: [],
        professorDocuments: [],
        selectedUser: null,
        loading: false,
        showUploadDocsPopup: false,
        comments: '',
        isFileUplading: false,
        showSubmitConfirmPopup:false,
    }),
    mounted() {

    },
    methods: {
        checkAndShowConfirmPopup() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.showSubmitConfirmPopup = true
                }
            })
        },
        submitAction(actionType) {
            this.showSubmitConfirmPopup = false
            if (actionType == 1) {
                this.submitDocuments()
            }
        },
        downloadFile(value) {
            this.$emit('download_or_view', value);
        },
        submitDocuments() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.loading = true
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "revisedDocuments": {
                            "professorDocuments": this.professorDocuments,
                            "clientDocuments": this.clientDocuments,
                        },
                        "comments": this.comments,
                    }
                    this.$store.dispatch("uploadRevisedDocuments", postData)
                        .then((response) => {
                            this.loading = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                this.hideFileUploadTemplatePopup()
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')
                            }
                        })
                        .catch((error) => {
                            this.loading = false
                            this.showToster({ message: error, isError: true });
                        })
                }
            })
        },

        openFileUploadPopup() {
            this.clientDocuments = []
            this.professorDocuments = []
            this.isFileUplading=false
            this.showUploadDocsPopup = true
        },
        hideFileUploadTemplatePopup() {
            this.clientDocuments = []
            this.professorDocuments = []
            this.isFileUplading=false
            this.showUploadDocsPopup = false
        },
        checkFileUploading() {
            let uploading = false
            let resultDocs = _.filter(this.clientDocuments, (docItem) => {
                return this.checkProperty(docItem, 'fileUploading') && docItem.fileUploading
            })
            console.log('resultDocs' + JSON.stringify(resultDocs))
            if (this.checkProperty(resultDocs, 'length') > 0) {
                if (!uploading) {
                    uploading = true
                }
            }
            if (!uploading) {
                let resultDocs = _.filter(this.professorDocuments, (docItem) => {
                    return this.checkProperty(docItem, 'fileUploading') && docItem.fileUploading
                })
                console.log('resultDocs' + JSON.stringify(resultDocs))
                if (this.checkProperty(resultDocs, 'length') > 0) {
                    if (!uploading) {
                        uploading = true
                    }
                }
            }

            this.isFileUplading = uploading
        }

    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>