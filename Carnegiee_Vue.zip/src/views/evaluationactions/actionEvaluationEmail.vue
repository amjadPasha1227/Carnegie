<template>
    <div class="wrapper-item">
        <div class="wrapper-item">
            <div class="section-year" v-if="checkProperty(activityLog, 'updatedOn')">
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_conform"></span>
                    <div class="status-name conform_bg">Email</div>
                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(activityLog, 'fromEmail')">
                            Received from <b>{{ checkProperty(activityLog, 'fromEmail') }}</b></h4>

                        <div class="wrapper-timeline">
                            <div class="wrapper-item" v-if="checkProperty(activityLog, 'subject')">
                                <section class="timeline-item">
                                    <div class="item mt-0 p-0">
                                        <div class="info_view info_view_v2">
                                            <h4 v-if="checkProperty(activityLog, 'subject')"> <b>{{
                                                checkProperty(activityLog, 'subject') }}</b></h4>
                                            <div class="actions">
                                                <span class="invoice_btn" @click="showEmailDetailsPopup = true"><img
                                                        src="@/assets/images/vision.png"></span>
                                            </div>
                                        </div>
                                        <!-- <DocumentsPreview :type="'documents'"
                                            :documentsList="checkProperty(activityLog, 'attachments')"
                                            :includeDownloadText="false" @download_or_view="downloadFile" /> -->
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <!-- side navbar1 -->
        <b-sidebar id="emails_sidebar" v-model="showEmailDetailsPopup" aria-labelledby="sidebar-no-header-title"
            sidebar-class="customer-sidenav emails_sidebar only_emails" title="" right no-header backdrop shadow
            @change="toggleBodyScrollbar">
            <template #default="{ hide }">
                <div class="sidenav_header email_header">
                    <h3>Email</h3>
                    <a class="close" block @click="hide"><img src="@/assets/images/close.svg"></a>
                </div>
                <div class="emails_main">
                    <div class="w-100">
                        <VuePerfectScrollbar>
                            <div class="emails_wrapper" v-if="activityLog">
                                <div class="subject_date">
                                    <h5 v-if="checkProperty(activityLog, 'subject')">{{ checkProperty(activityLog,
                                        'subject') }}</h5>
                                    <div class="replay_area">
                                        <!-- <img class="replay" src="@/assets/images/replay.png" @click="replayOpen = true"> -->
                                        <h6><img src="@/assets/images/main/clock.png">{{ checkProperty(activityLog,
                                            'sentDate') |
                                            formatDateTime }}</h6>
                                    </div>
                                </div>
                                <div class="content" v-if="checkProperty(activityLog, 'htmlContent')">
                                    <p v-html="checkProperty(activityLog, 'htmlContent')"></p>
                                </div>
                                <div class="files" v-if="checkProperty(activityLog, 'attachments', 'length') > 0">
                                    <h6>Files</h6>
                                    <ul class="doc_pdf_list">
                                        <li>
                                            <figure><img src="@/assets/images/pdf-file.svg"></figure>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                        </VuePerfectScrollbar>
                    </div>
                </div>
            </template>
        </b-sidebar>
    </div>
</template>


<script>
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import textArea from "@/views/forms/textarea.vue";
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import radioInput from "@/views/forms/radioInput.vue";
import VuePerfectScrollbar from 'vue-perfect-scrollbar'

export default {
    props: {
        evaluation: Object,
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        activityLog: Object,
    },
    components: {
        textArea,
        simpleSelect,
        simpleInput,
        radioInput,
        DocumentsPreview,
        VuePerfectScrollbar,
    },
    data: () => ({
        showEmailDetailsPopup: false,
    }),
    mounted() {
    },
    methods: {
        toggleBodyScrollbar(visible) {
            const body = document.getElementsByTagName('body')[0];

            if (visible)
                body.classList.add("overflow-hidden");
            else
                body.classList.remove("overflow-hidden");
        },
        downloadFile(value) {
            this.$emit('download_or_view', value);
        },
        getCustomerSentEmails() {
            let emailStr = ''
            if (this.checkProperty(this.activityLog, 'customerDetails', 'email')) {
                // if (this.checkProperty(this.activityLog, 'customerDetails', 'name')) {
                //     emailStr = emailStr + this.checkProperty(this.activityLog, 'customerDetails', 'name')
                //         + "< " + this.checkProperty(this.activityLog, 'customerDetails', 'email') + " >"
                // } else {
                emailStr = emailStr + this.checkProperty(this.activityLog, 'customerDetails', 'email')
                //  }
            }
            if (this.checkProperty(this.activityLog, 'altEmailsList', 'length') > 0) {
                this.checkProperty(this.activityLog, 'altEmailsList').forEach((item, index) => {
                    if (!emailStr.includes(item.email)) {
                        if (!emailStr) {
                            emailStr = item.email
                        } else {
                            emailStr = emailStr + ", " + item.email
                        }
                    }
                });
            }
            return emailStr
        }
    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>