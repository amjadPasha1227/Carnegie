<template>
    <div>
        <div class="wrapper-item" v-if="!isCompletedActivity">

            <div class="section-year">
                <p></p>
                <p> </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Review Request</div>
                    <div class="submit_detailes team_bg">

                        <div>
                            <div class="wrapper-timeline">
                                <div class="wrapper-item" v-if="false">
                                    <div class="section-year"></div>
                                    <section class="timeline-item">
                                        <div class="item mt-3">
                                            <span class="status_dot"></span>
                                            <h4>Ask for More Documents</h4>
                                            <textArea :wrapclass="'mb-0'" :tplkey="'moreDocs'" fieldName="moreDocs"
                                                placeHolder="Write here..." v-model="moreDocComments"></textArea>
                                        </div>
                                    </section>
                                </div>
                                <div class="wrapper-item">
                                    <div class="section-year"></div>
                                    <section class="timeline-item">
                                        <div class="item">
                                            <span class="status_dot"></span>
                                            <h4 class="mb-2">Preliminary Opinion <a class="link ms-2"
                                                    @click="openTemplatePopup">Select
                                                    Template</a>
                                            </h4>
                                            <!-- <simpleInput :tplkey="'preliminarySubject'" fieldName="preliminarySubject"
                                                placeHolder="Template title..." v-model="selectedTemplate.title" /> -->

                                            <textArea :tplkey="'preliminaryOption'" fieldName="preliminaryOption"
                                                placeHolder="Template content ..." cid="preliminaryOption"
                                                v-model="selectedTemplate.content" ref="childComponentRef"> </textArea>
                                            <!-- <div class="more_info">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas fringilla tellus
                                            vel nisl
                                            lobortis
                                        </div> -->
                                        </div>
                                    </section>
                                </div>

                                <div class="wrapper-item"
                                    v-if="checkProperty(quotaPrice, 'evaluationPrices', 'length') > 0">
                                    <div class="section-year"></div>
                                    <section class="timeline-item">
                                        <div class="item">
                                            <span class="status_dot">
                                                <b-form-checkbox class="table_check quote_check" :id="''" :name="''"
                                                    v-model="isQuoteRequired"></b-form-checkbox>

                                            </span>
                                            <h4>Quote Price</h4>
                                            <textArea v-if="isQuoteRequired" class="mb-4 comments-ck_editer"
                                                :tplkey="'reviewConfirm'" fieldName="reviewConfirm" placeHolder=""
                                                v-model="quoteComments" :required="true" :vvas="'Comments'"></textArea>
                                            <div class="bill-card">
                                                <!-- <div class="bill-heading">
                                    <p>BILL DETAILS</p>
                                </div> -->
                                                <ul>
                                                    <li v-for="(evaluationItem, indx) in quotaPrice.evaluationPrices">
                                                        <div class="ammount">
                                                            {{ evaluationItem.evaluationTypeName }}
                                                        </div>
                                                        <simpleInput :fieldName="'evaluationAmount'"
                                                            :disabled="!isQuoteRequired" :cid="'evaluationAmount'"
                                                            :label="''" :placeHolder="'$000'" :vvas="'Amount'"
                                                            :display="true" :required="false"
                                                            v-model="quotaPrice.evaluationPrices[indx].price"
                                                            :onlyNumbers="true" @input="updateTotalPrice(false)"
                                                            :maxLength="6" />
                                                        <!-- <input type="text" placeholder="$350" value="$350" > -->
                                                        <span class="delete"
                                                            v-if="isQuoteRequired && checkProperty(quotaPrice.evaluationPrices, 'length') > 1"
                                                            @click="deleteEvaluation(indx)"></span>
                                                    </li>

                                                    <li class="discount">
                                                        <span class="add_more" @click="openLineItemPopup"
                                                            v-if="isQuoteRequired">+ Add line
                                                            item</span>

                                                        <p>Discount</p>
                                                        <div class="form_group">
                                                            <simpleInput class="form-control" :disabled="!isQuoteRequired"
                                                                :fieldName="'evaluationDiscount'"
                                                                :cid="'evaluationDiscount'" :label="''" :placeHolder="'00'"
                                                                :vvas="'Discount'" :display="true" :required="false"
                                                                :onlyNumbers="true" :maxLength="6"
                                                                v-model="quotaPrice.discount"
                                                                @input="updateTotalPrice(false)" />
                                                            <!-- <input type="text" placeholder="30%" value="" class="form-control"> -->
                                                        </div>
                                                        <em class="per_symb"></em>
                                                    </li>
                                                    <li class="discount">
                                                        <p>Total</p>
                                                        <span>{{ '$' + quotaPrice.total }}</span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </section>
                                </div>

                                <div class="wrapper-item">
                                    <div class="section-year"></div>
                                    <section class="timeline-item">
                                        <div class="item">

                                            <!-----:optionItemLabel="'track-by'"-->
                                            <span class="status_dot"></span>
                                            <h4>Suggest Professors</h4>
                                            <customSelect :multiple="true" :wrapclass="'req_status'" class="mb-0 ass-eval"
                                                :trackBy="'name'" :optionItemLabel="'track-by'"
                                                :optionslist="professorsList" :display="true"
                                                :place-holder="'Suggest Professors'" :searchable="false" :required="false"
                                                :close-on-select="true" :clear-on-select="true"
                                                v-model="suggestedProfessors" :fieldName="'suggestProfessor'"
                                                :cid="'suggestProfessor'" :hideSelected="true" />
                                            <div class="radiocheck-flex mt-2">
                                                <radioInput v-for="(professor, rowNum) in suggestedProfessors"
                                                    wrapclass="radio_group_v2 professors_btn"
                                                    :elementId="'selectedProfessor' + professor._id" :label="professor.name"
                                                    :fieldName="'selectedProfessor' + rowNum"
                                                    v-model="suggestedProfessors[rowNum]" :fieldValue="true"
                                                    @input="removeSelectedProfessor" />

                                            </div>

                                            <!-- <simpleSelect :multiple="true" :wrapclass="'req_status'" :optionslist="evaluatorList"
                                            :display="true" :place-holder="'4 Selected'" :searchable="false" :required="false"
                                            :close-on-select="true" :clear-on-select="true"  /> -->
                                        </div>
                                    </section>
                                </div>


                            </div>
                            <div class="d-flex justify-content-end px-4">
                                <button class="primary_btn me-3" @click="openReviewEmailPreview">Preview
                                    Email & Submit</button>
                            </div>
                        </div>
                        <div>

                        </div>

                    </div>
                </div>
            </section>


        </div>

        <div class="wrapper-item" v-if="isCompletedActivity">
            <div class="section-year" v-if="checkProperty(reviewDetails, 'updatedOn')">
                <p> {{ checkProperty(reviewDetails, 'updatedOn') | formatTime }} </p>
                <p> {{ checkProperty(reviewDetails, 'updatedOn') | formatDate }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Reviewed</div>
                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(reviewDetails, 'updatedByName')">
                            Reviewed by <b>{{ checkProperty(reviewDetails, 'updatedByName') }} </b></h4>
                        <div class="wrapper-timeline">
                            <div class="wrapper-item" v-if="checkProperty(reviewDetails, 'moreDocComments')">
                                <section class="timeline-item">
                                    <div class="item p-0">
                                        <h4>Ask for More Documents</h4>
                                        <div class="info_view">
                                            <p v-html="checkProperty(reviewDetails, 'moreDocComments')"></p>
                                        </div>
                                    </div>
                                </section>
                            </div>

                            <div class="wrapper-item"
                                v-if="checkProperty(reviewDetails, 'preliminaryTemplate', 'title') || checkProperty(reviewDetails, 'preliminaryTemplate', 'content')">
                                <section class="timeline-item">
                                    <div class="item p-0">
                                        <h4>Preliminary Opinion</h4>
                                        <div class="info_view" v-if="false">
                                            {{ checkProperty(reviewDetails, 'preliminaryTemplate', 'title') }}
                                        </div>
                                        <h4></h4>
                                        <div class="info_view"
                                            v-if="checkProperty(reviewDetails, 'preliminaryTemplate', 'content')">
                                            <p v-html="checkProperty(reviewDetails, 'preliminaryTemplate', 'content')"></p>
                                        </div>
                                    </div>
                                </section>
                            </div>
                            <div class="wrapper-item"
                                v-if="checkProperty(reviewDetails, 'suggestProfessors', 'length') > 0">
                                <section class="timeline-item">
                                    <div class="item p-0">
                                        <h4>Suggest Professors</h4>
                                        <div v-if="false" class="radiocheck-flex radiochecked-flex mt-3">
                                            <radioInput
                                                v-for="(professor, indx) in checkProperty(reviewDetails, 'suggestProfessors')"
                                                :key="indx" wrapclass="radio_group_v2 professors_btn"
                                                :elementId="'Per Case Billing'" :label="checkProperty(professor, 'name')"
                                                :fieldName="'suggestedProfessor' + indx" :fieldValue="true"
                                                :disabled="true" />


                                        </div>
                                        <div class="sugg_prof_list"
                                            v-for="(professor, indx) in checkProperty(reviewDetails, 'suggestProfessors')"
                                            @click="openProfessorProfile(professor)">
                                            <span>{{ checkProperty(professor, 'name') }}</span>
                                            <div class="check"></div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                            <div class="wrapper-item"
                                v-if="checkProperty(reviewDetails, 'isQuoteRequired') && checkProperty(reviewDetails, 'quotaPrice', 'evaluationPrices')">
                                <div class="item p-0">
                                    <div class="info_view" v-if="checkProperty(reviewDetails, 'quoteComments')">
                                        <p v-html="checkProperty(reviewDetails, 'quoteComments')"></p>
                                    </div>
                                    <b-dropdown size="lg" variant="link" toggle-class="text-decoration-none">
                                        <template #button-content>
                                            <b-button v-b-toggle.collapse-2 class="m-1 dropdown-toggle form-cancel">View
                                                Quote</b-button>
                                        </template>
                                        <b-dropdown-form>
                                            <div class="bill-card quote_card">
                                                <div class="bill-heading">
                                                    <p>QUOTE</p>
                                                </div>
                                                <ul>
                                                    <li v-for="(priceItem, indx) in checkProperty(reviewDetails, 'quotaPrice', 'evaluationPrices')"
                                                        :key="indx">
                                                        <div class="ammount">
                                                            {{ priceItem.evaluationTypeName }}
                                                        </div>
                                                        <span>${{ priceItem.price }}</span>
                                                    </li>
                                                    <li class="disc">
                                                        <p>Discount {{ checkProperty(reviewDetails, 'quotaPrice',
                                                            'discount') ? checkProperty(reviewDetails, 'quotaPrice',
                                                                'discount') : 0 }} Applied
                                                        </p>
                                                        <p class="total"><span>Total</span>${{ checkProperty(reviewDetails,
                                                            'quotaPrice', 'total') }}</p>
                                                    </li>
                                                </ul>

                                            </div>
                                        </b-dropdown-form>
                                    </b-dropdown>



                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </section>
        </div>


        <b-modal v-model="showTemplatePopup" id="template_model123" dialog-class="delivery_template_model professors"
            centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Preliminary Opinion Templates</h6>
                <div class="d-flex">
                    <a class="close" @click="closeTemplatePopup"></a>
                </div>
            </template>
            <template>
                <form :data-vv-scope="'preliminaryTemplateForm'">
                    <simpleSelect :multiple="false" :wrapclass="'mb-3'" :optionslist="preliminaryTemplates" :display="true"
                        :placeHolder="'Select Template'" :searchable="false" :required="true" :close-on-select="true"
                        :clear-on-select="true" v-model="popupTemplate" :fieldName="'preliminaryTemplate'"
                        :cid="'preliminaryTemplate'" :hideSelected="false" :listContainsId="true" :trackBy="'title'"
                        :label="'Select Template'" :formscope="'preliminaryTemplateForm'" />

                    <!-- <textArea :wrapclass="'more_info'" :tplkey="'preliminaryTitle'" fieldName="preliminaryTitle"
                                placeHolder="Email subject here..." v-model="popupTemplate.title"></textArea>-->

                    <textArea v-if="checkProperty(popupTemplate, 'title')" class="mb-3" :tplkey="'preliminaryContent'"
                        fieldName="preliminaryContent" placeHolder="Email content here..."
                        v-model="popupTemplate.content"></textArea>
                </form>
            </template>
            <template #modal-footer>
                <button class="form-cancel" @click="closeTemplatePopup">Cancel</button>
                <button class="primary_btn md" @click="onTemplateSubmit">Use Content</button>
            </template>
        </b-modal>

        <b-modal v-model="showLineItemPopup" id="add_line_mdl" dialog-class="delivery_template_model professors" centered
            no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Add line item</h6>
                <div class="d-flex">
                    <a class="close" @click="closeLineItemPopup"></a>
                </div>
            </template>
            <template>
                <form :data-vv-scope="'addLineItemForm'">
                    <simpleInput :fieldName="'evaluationName'" :cid="'evaluationName'" :label="'Evaluation Name'"
                        :wrapclass="'mb20'" :placeHolder="'Evaluation Name'" :vvas="'Evaluation Name'" :display="true"
                        :required="true" v-model="evaluationName" :formscope="'addLineItemForm'" />
                    <!-- <ul class="evaluation_list">
                        <li>
                            <input class="form-check-input" type="checkbox" value="" id="academic">
                            <label class="form-check-label" for="academic">
                                ACADEMIC/EDUCATION EVALUATION
                            </label>
                        </li>
                        <li>
                            <input class="form-check-input" type="checkbox" value="" id="academic2">
                            <label class="form-check-label" for="academic2">
                                ACADEMIC/EDUCATION EVALUATION
                            </label>
                        </li>
                        <li>
                            <input class="form-check-input" type="checkbox" value="" id="academic3">
                            <label class="form-check-label" for="academic3">
                                ACADEMIC/EDUCATION EVALUATION
                            </label>
                        </li>
                    </ul> -->
                </form>
            </template>
            <template #modal-footer>
                <button class="form-cancel" @click="closeLineItemPopup">Cancel</button>
                <button class="primary_btn sm" @click="onAddLineItem">Add</button>
            </template>
        </b-modal>

        <!-- Preview Email Modal -->
        <b-modal v-model="previewReviewEmail" id="preview_modal_reviewed"
            dialog-class="create_template preview_modal_reviewed" centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Preview Email</h6>
                <a class="close" @click="previewReviewEmail = false"></a>
            </template>
            <template>
                <form class="user_form create_temp bg-white">
                    <div class="subject">Subject:- {{ checkProperty(evaluation, 'requestId') }}: Your Evaluation Request for
                        {{ getBeneficiaryName() }} is Reviewed.</div>

                    <div class="email_preview_wrapper">
                        <div class="top_head">
                            <div class="bg_white"></div>
                        </div>
                        <div class="main_cnt">
                            <div class="main_inr">
                                <p>Dear <strong>{{ customerName }}</strong>,</p>
                                <!-- <p v-if="checkProperty(evaluation, 'requestId')">Request ID:
                                    <strong>{{ checkProperty(evaluation, 'requestId') }}</strong>
                                </p> -->
                                <p class="email_content" v-if="checkProperty(selectedTemplate, 'content')"
                                    v-html="checkProperty(selectedTemplate, 'content')"></p>
                                <p class="mb-0" v-if="checkProperty(suggestedProfessors, 'length') > 0">Suggested
                                    Professors:
                                </p>
                                <table class="preview_modal_table" v-if="checkProperty(suggestedProfessors, 'length') > 0">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Designation</th>
                                            <th>Department</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="(professor, indx) in suggestedProfessors">
                                            <td @click="openProfessorProfile(professor)"><span class="sug_prof">{{
                                                professor.name }}</span></td>
                                            <td>{{ professor.designation }}</td>
                                            <td>{{ professor.departmentName }}</td>
                                        </tr>
                                    </tbody>
                                </table>

                                <p class="mb-0 mt-4"
                                    v-if="isQuoteRequired && checkProperty(quotaPrice, 'evaluationPrices', 'length') > 0">
                                    Quote:
                                </p>
                                <p v-if="isQuoteRequired && quoteComments" v-html="quoteComments"></p>

                                <table class="preview_modal_table"
                                    v-if="isQuoteRequired && checkProperty(quotaPrice, 'evaluationPrices', 'length') > 0">
                                    <thead>
                                        <tr>
                                            <th>Evaluation Type</th>
                                            <th>Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="(evalItem, indx) in checkProperty(quotaPrice, 'evaluationPrices')">
                                            <td>{{ evalItem.evaluationTypeName }}</td>
                                            <td>{{ evalItem.price }}</td>
                                        </tr>
                                    </tbody>
                                </table>


                                <!-- <div class="regards mb-0 mt-4">
                                    Regards,
                                    <span>Carnegie Evaluations</span>
                                </div> -->
                                <div class="line_blue mb-0 mt-2"></div>
                                <emailPreviewFooter></emailPreviewFooter>
                                <!-- <div class="email_footer">
                                    <a href="https://carnegieevaluations.com/app/" target="_blank">
                                        <img src="@/assets/images/logo_carne.png" alt="Carnegie Evaluations">
                                        <img src="@/assets/images/email_footer_logo2.png" alt="Carnegie Evaluations">
                                    </a>
                                    <a href="mailto:eval@carnegieevaluations.com"
                                        target="_blank">eval@carnegieevaluations.com</a>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </form>
            </template>
            <template #modal-footer>
                <button class="form-cancel menustyle" @click="previewReviewEmail = false">Cancel</button>
                <button class="primary_btn sm menustyle" @click="submitReviewForm">Submit</button>
            </template>
        </b-modal>


        <!-- Profile Modal -->
        <b-modal v-model="showProfile" id="profile_model" dialog-class="profile_model" centered hide-header hide-footer
            no-close-on-backdrop>
            <template>
                <div class="profile_header">
                    <div class="profile_title">
                        <h6 v-if="checkProperty(selectedUser, 'name')">{{ checkProperty(selectedUser, 'name') }}</h6>
                        <span v-if="checkProperty(selectedUser, 'details', 'designation')">{{ checkProperty(selectedUser,
                            'details',
                            'designation') }}</span>
                    </div>
                    <a class="close" @click="showProfile = false"></a>
                </div>
                <div class="profile_info">
                    <ul>

                        <li v-if="checkProperty(selectedUser, 'departmentDetails', 'name')">
                            <span class="info_header">Department</span>
                            <p class="desc">{{ checkProperty(selectedUser, 'departmentDetails', 'name') }}</p>
                        </li>
                        <li v-if="checkProperty(selectedUser, 'details', 'profileURL')">
                            <span class="info_header">Profile URL</span>
                            <a href="#" class="link">{{ checkProperty(selectedUser, 'details', 'profileURL') }}</a>
                        </li>
                        <!-- <li
                            v-if="checkProperty(selectedUser, 'details', 'letterHead') && checkProperty(selectedUser['details'], 'letterHead', 'length') > 0">
                            <span class="info_header">Copy of letterhead</span>
                            <DocumentsPreview :type="'documents'"
                                :documentsList="checkProperty(selectedUser, 'details', 'letterHead')"
                                :includeDownloadText="false" @download_or_view="downloadFileProfessor" />
                        </li> -->
                        <li v-if="(checkProperty(selectedUser, 'details', 'bioAndResume') || (checkProperty(selectedUser, 'details', 'documents') && checkProperty(selectedUser['details'], 'documents', 'length') > 0))"
                            class="bio_resume">
                            <span class="info_header">Bio/Resume</span>
                            <p v-if="checkProperty(selectedUser, 'details', 'bioAndResume')"
                                v-html="checkProperty(selectedUser, 'details', 'bioAndResume')"></p>
                            <div
                                v-if="checkProperty(selectedUser, 'details', 'documents') && checkProperty(selectedUser['details'], 'documents', 'length') > 0">
                                <DocumentsPreview :type="'documents'"
                                    :documentsList="checkProperty(selectedUser, 'details', 'documents')"
                                    :includeDownloadText="false" @download_or_view="downloadFileProfessor" />
                            </div>
                        </li>
                    </ul>
                </div>
            </template>
        </b-modal>

    </div>
</template>


<script>
import textArea from "@/views/forms/textarea.vue";
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import radioInput from "@/views/forms/radioInput.vue";
import customSelect from '@/views/forms/customSelect.vue';
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import emailPreviewFooter from "@/views/emailPreviewFooter.vue";

import _ from "lodash";
import JQuery from "jquery";


export default {
    props: {
        evaluation: Object,
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        reviewDetails: Object,
    },
    components: {
        textArea,
        simpleSelect,
        simpleInput,
        radioInput,
        customSelect,
        DocumentsPreview,
        emailPreviewFooter,
    },
    data: () => ({
        evaluationReviedwedLogs: [],
        moreDocComments: '',
        professorsList: [],
        suggestedProfessors: [],
        quotaPrice: {
            total: 0,
            discount: 0,
            evaluationPrices: []
        },
        showTemplatePopup: false,
        preliminaryTemplates: [],
        selectedTemplate: {
            title: "",
            content: ""
        },
        isQuoteRequired: false,
        popupTemplate: null,
        evaluationName: '',
        showLineItemPopup: false,
        customerName: '',
        previewReviewEmail: false,
        quoteComments: "",
        clientDiscount: 0,
        showProfile: false,
        selectedUser: null,
    }),
    mounted() {

        // this.customerName = this.checkProperty(this.evaluation, 'customersDetails', 'name') ? this.checkProperty(this.evaluation, 'customersDetails', 'name') : this.checkProperty(this.evaluation, 'name')
        this.customerName = this.checkProperty(this.evaluation, 'name')

        this.getProfessors()
        this.getTemplates()
        if (this.checkProperty(this.evaluation, 'customersDetails', 'discount')) {
            this.clientDiscount = this.checkProperty(this.evaluation, 'customersDetails', 'discount')
        }

        this.assignAndCalucatePrices(true)
        //  this.updateReviewedData()
        this.setWatchers();


        this.evaluationReviedwedLogs = [];  //EVALUATION_REVIEWED
        setTimeout(() => {

            if (this.checkProperty(this.evaluation, 'evaluationActivityInfoLogs', 'length') > -1) {
                this.evaluationReviedwedLogs = _.filter(this.evaluation["evaluationActivityInfoLogs"], { "action": "EVALUATION_REVIEWED" });
            }

        }, 10);




    },
    methods: {
        getProfessors() {
            let roleIds = [9]
            let postData =
            {
                "matcher": {
                    "title": "",
                    "searchString": "",
                    "statusList": [],
                    "createdByIds": [],
                    "createdDateRange": [],
                    "roleIds": roleIds,
                    "statusIds": [],
                    "typeIds": [],
                    "departmentIds": []
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": true,// if Masterdata required
                "page": 1,
                "perpage": 500,
            }
            this.$store.dispatch("getUsersList", postData)
                .then((res) => {
                    this.professorsList = res.data.result.list;
                    this.professorsList = _.map(this.professorsList, (item) => {
                        item['track-by'] = item['name'];
                        if (_.has(item, 'departmentName') && item['departmentName']) {
                            item['track-by'] = item['track-by'] + " " + item['departmentName'];
                        }
                        if (_.has(item, 'designation') && item['designation']) {
                            item['track-by'] = item['track-by'] + " " + item['designation'];
                        }

                        return item;
                    })

                })
                .catch((error) => {
                })
        },
        getTemplates() {
            let postData = {
                "matcher": {
                    "title": "",
                    "statusIds": [],
                    "typeIds": [],
                    "createdByIds": [],
                    "createdDateRange": []
                },
                "sorting": {
                    "path": "createdOn", //title, statusName, createdByName, updatedOn, 
                    "order": -1
                },
                "getMasterData": true,
                "page": 1,
                "perpage": 500
            }
            this.$store.dispatch("getEmailsList", postData)
                .then((res) => {
                    this.preliminaryTemplates = res.data.result.list
                })
                .catch((error) => {
                })
        },
        assignAndCalucatePrices(isFirstTime = false) {
            if (this.checkProperty(this.evaluation, 'quotaPrice', 'evaluationPrices')
                && this.checkProperty(this.evaluation.quotaPrice, 'evaluationPrices', 'length') > 0) {
                this.quotaPrice = { ...this.checkProperty(this.evaluation, 'quotaPrice') }
                //this.quotaPrice.discount = discountAmount
            } else {
                let evaluationQuates = []
                if (this.checkProperty(this.evaluation, 'docsConfig', 'length') > 0) {
                    _.forEach(this.evaluation.docsConfig, (item) => {
                        let evaluationPrice = {
                            evaluationTypeId: '',
                            evaluationTypeName: '',
                            price: 0,
                            subTypes: [],
                        }
                        evaluationPrice.evaluationTypeId = item.evaluationTypeId
                        evaluationPrice.evaluationTypeName = item.evaluationTypeName
                        evaluationPrice.price = item.price
                        evaluationPrice.subTypes = item.subTypes
                        evaluationQuates.push(evaluationPrice)
                    })
                }
                this.quotaPrice.evaluationPrices = evaluationQuates
            }
            this.updateTotalPrice(isFirstTime)
        },
        openTemplatePopup() {
            if (this.checkProperty(this.selectedTemplate, 'title')
                && this.checkProperty(this.selectedTemplate, 'title') != '') {
                this.popupTemplate = this.selectedTemplate
            } else {
                this.popupTemplate = null
            }
            this.popupTemplate = null
            this.showTemplatePopup = true
        },
        closeTemplatePopup() {
            this.popupTemplate = null
            this.showTemplatePopup = false
        },
        onTemplateSubmit() {

            this.$validator.validateAll('preliminaryTemplateForm').then((result) => {
                if (result) {
                    // const editorInstance = this.$refs.childComponentRef.$refs.preliminaryOption.$_instance;
                    // if (editorInstance) {
                    //     const cursorPosition = editorInstance.model.document.selection.getFirstPosition();


                    //     editorInstance.model.change((writer) => {
                    //         console.log("writer", writer)
                    //         writer.insertText(insertHtml, cursorPosition);
                    //     });

                    //     this.selectedTemplate.content = editorInstance.getData();

                    //     // console.log("cursorPosition", cursorPosition)
                    //     // if (this.checkProperty(cursorPosition, 'path', 'length') == 2) {
                    //     //     let cursorAt = this.checkProperty(cursorPosition, 'path')[1]
                    //     //     const firstPart = this.selectedTemplate.content.slice(0, cursorAt);
                    //     //     const secondPart = this.selectedTemplate.content.slice(cursorAt);
                    //     //     console.log("firstPart", firstPart)
                    //     //     console.log("secondPart", secondPart)
                    //     //     this.selectedTemplate.content = firstPart + this.popupTemplate.content + secondPart;
                    //     // } else if (this.checkProperty(cursorPosition, 'path', 'length') == 1) {
                    //     //     let cursorAt = this.checkProperty(cursorPosition, 'path')[0]
                    //     //     const firstPart = this.selectedTemplate.content.slice(0, cursorAt);
                    //     //     const secondPart = this.selectedTemplate.content.slice(cursorAt);
                    //     //     console.log("firstPart", firstPart)
                    //     //     console.log("secondPart", secondPart)
                    //     //     this.selectedTemplate.content = firstPart + this.popupTemplate.content + secondPart;
                    //     // } else {
                    //     //     if (this.checkProperty(this.selectedTemplate, 'content')) {
                    //     //         let resultContent = this.popupTemplate.content + '</br></br>' + this.selectedTemplate.content
                    //     //         this.selectedTemplate.content = resultContent
                    //     //     } else {
                    //     //         this.selectedTemplate = this.popupTemplate
                    //     //     }
                    //     // }
                    // } else {
                    //     if (this.checkProperty(this.selectedTemplate, 'content')) {
                    //         let resultContent = this.popupTemplate.content + '</br></br>' + this.selectedTemplate.content
                    //         this.selectedTemplate.content = resultContent
                    //     } else {
                    //         this.selectedTemplate = this.popupTemplate
                    //     }
                    // }

                    if (this.checkProperty(this.selectedTemplate, 'content')) {
                        let resultContent = this.selectedTemplate.content + this.popupTemplate.content
                        this.selectedTemplate.content = resultContent
                    } else {
                        this.selectedTemplate = this.popupTemplate
                    }
                    this.showTemplatePopup = false
                }
            })
        },
        updateTotalPrice(isFirstTime = false) {

            let totalPrice = 0
            let discountAmount = 0
            if (this.checkProperty(this.quotaPrice, 'evaluationPrices', 'length') > 0) {
                _.forEach(this.quotaPrice.evaluationPrices, (item) => {
                    if (this.checkProperty(item, 'price') > 0) {
                        totalPrice += parseInt(item.price)
                    }
                })
            }
            // if (this.clientDiscount &&isFirstTime) {
            //     discountAmount = ((totalPrice / 100) * this.checkProperty(this.quotaPrice, 'discount'))
            // }

            if (this.clientDiscount && this.clientDiscount > 0 && isFirstTime
                && isLastCompletedActivity(evaluationDetails, 'CUSTOMER_ASSIGNED')) {
                discountAmount = ((totalPrice / 100) * this.clientDiscount)
            } else {
                discountAmount = this.checkProperty(this.quotaPrice, 'discount')
            }
            this.quotaPrice.discount = discountAmount
            if (discountAmount > totalPrice) {
                discountAmount = 0
                this.quotaPrice.discount = 0
                this.quotaPrice.total = totalPrice
            } else {
                this.quotaPrice.total = totalPrice - discountAmount
            }
        },
        submitReviewForm() {

            let postData = {
                "evaluationId": this.evaluation._id,
                "moreDocComments": "",
                "suggestProfessors": [],
                "isQuoteRequired": this.isQuoteRequired,
                "quoteComments": "",
            }
            if (this.isQuoteRequired) {
                postData["quotaPrice"] = this.quotaPrice
            }

            // alert(JSON.stringify(this.selectedTemplate));
            if (this.checkProperty(this.selectedTemplate, '_id') || this.checkProperty(this.selectedTemplate, 'content')) {
                postData["preliminaryTemplate"] = this.selectedTemplate
            } else if (this.checkProperty(this.evaluation, 'preliminaryTemplate', 'content')
                && this.checkProperty(this.evaluation.preliminaryTemplate, 'content', 'length') > 0) {
                // postData["preliminaryTemplate"] = this.checkProperty(this.evaluation, 'preliminaryTemplate')
            }


            if (this.checkProperty(this.suggestedProfessors, 'length') > 0) {
                postData.suggestProfessors = this.suggestedProfessors
            }
            else if (this.checkProperty(this.evaluation, 'suggestProfessors', 'length') > 0) {
                // postData.suggestProfessors = this.checkProperty(this.evaluation, 'suggestProfessors')
            }
            if (this.quoteComments) {
                postData['quoteComments'] = this.quoteComments
            }
            postData['quoteComments'] = postData['quoteComments'].trim();
            // if (this.moreDocComments) {
            //     postData['moreDocComments'] = this.moreDocComments
            // } else if (this.checkProperty(this.evaluation, 'moreDocComments', 'length') > 0) {
            //     //postData['moreDocComments'] = this.checkProperty(this.evaluation, 'moreDocComments')
            // }
            // postData['moreDocComments'] = postData['moreDocComments'].trim();
            if (!postData['quoteComments'] && postData['suggestProfessors'].length <= 0 && !postData['isQuoteRequired'] && !postData["preliminaryTemplate"]) {
                this.showToster({ message: "Selecte atleast one review request", isError: true });
                return false
            }


            this.$store.dispatch("submitEvaluationReview", postData)
                .then((response) => {
                    if (response.error) {
                        (response.error)
                        Object.assign(this.formerrors, {
                            msg: response.error.result
                        });
                        this.showToster({ message: response.error.result, isError: true });
                    } else {
                        this.previewReviewEmail = false
                        this.selectedTemplate = { title: "", content: "" }
                        this.suggestedProfessors = []
                        this.moreDocComments = ""
                        this.showToster({ message: response.message, isError: false });
                        this.$emit('updateDetails')

                    }
                })
                .catch((error) => {
                    this.showToster({ message: error, isError: true });
                })



        },
        removeSelectedProfessor(value) {
            if (this.checkProperty(this.suggestedProfessors, 'length') > 0) {
                let resultProfessors = [..._.filter(this.suggestedProfessors, (suggested) => {
                    return suggested["_id"] !== value["_id"]
                })]
                this.suggestedProfessors = []
                this.suggestedProfessors = resultProfessors
                // this.suggestedProfessors.splice(index, 1);
            }
        },
        setWatchers() {
            this.$watch("evaluation", function () {
                //  this.updateReviewedData()
            })
        },
        updateReviewedData() {
            if (this.checkProperty(this.evaluation, 'moreDocComments')) {
                this.moreDocComments = this.checkProperty(this.evaluation, 'moreDocComments')
            }
            if (this.checkProperty(this.evaluation, 'suggestProfessors', 'length') > 0) {
                this.suggestedProfessors = this.checkProperty(this.evaluation, 'suggestProfessors')
            }
            if (this.checkProperty(this.evaluation, 'preliminaryTemplate')) {
                this.selectedTemplate = this.checkProperty(this.evaluation, 'preliminaryTemplate')
            }

            if (this.checkProperty(this.evaluation, 'quotaPrice', 'evaluationPrices')
                && this.checkProperty(this.evaluation.quotaPrice, 'evaluationPrices', 'length') > 0) {
                this.quotaPrice = this.checkProperty(this.evaluation, 'quotaPrice')
            }
            if (this.checkProperty(this.evaluation, 'isQuoteRequired')) {
                this.isQuoteRequired = this.evaluation.isQuoteRequired
            }



        },
        openLineItemPopup() {
            this.evaluationName = ""
            this.showLineItemPopup = true
        },
        closeLineItemPopup() {
            this.evaluationName = ""
            this.showLineItemPopup = false
        },
        onAddLineItem() {

            this.$validator.validateAll('addLineItemForm').then((result) => {
                if (result) {
                    let evalObj = {
                        evaluationTypeName: this.evaluationName,
                        price: '0'
                    }
                    this.quotaPrice.evaluationPrices.push(evalObj)
                    this.closeLineItemPopup()
                }
            })
        },
        deleteEvaluation(indx) {
            if (this.checkProperty(this.quotaPrice, 'evaluationPrices', 'length') > 0) {
                this.quotaPrice.evaluationPrices.splice(indx, 1);
                this.updateTotalPrice(false)
            }
        },
        openReviewEmailPreview() {
            let postData = {
                "evaluationId": this.evaluation._id,
                "moreDocComments": "",
                "suggestProfessors": [],
                "isQuoteRequired": this.isQuoteRequired,
                "quoteComments": "",
            }
            if (this.isQuoteRequired) {
                postData["quotaPrice"] = this.quotaPrice
            }
            if (this.checkProperty(this.selectedTemplate, '_id') || this.checkProperty(this.selectedTemplate, 'content')) {
                postData["preliminaryTemplate"] = this.selectedTemplate
            } else if (this.checkProperty(this.evaluation, 'preliminaryTemplate', 'content')
                && this.checkProperty(this.evaluation.preliminaryTemplate, 'content', 'length') > 0) {
            }
            if (this.checkProperty(this.suggestedProfessors, 'length') > 0) {
                postData.suggestProfessors = this.suggestedProfessors
            }
            if (this.quoteComments) {
                postData['quoteComments'] = this.quoteComments
            }
            postData['quoteComments'] = postData['quoteComments'].trim();
            if (postData['suggestProfessors'].length <= 0 && !postData['isQuoteRequired'] && !postData["preliminaryTemplate"]) {
                this.showToster({ message: "Selecte atleast one review request", isError: true });
                return false
            } else {
                this.previewReviewEmail = true
            }
        },
        openProfessorProfile(professorObj) {
            let postData =
            {
                "userId": professorObj._id
            }
            this.$store.dispatch("getUserDetails", postData)
                .then((res) => {
                    this.selectedUser = res.result
                    this.showProfile = true
                })
                .catch((error) => {

                })
        },
        downloadFileProfessor(value) {
            this.$emit('download_or_view', value);
        },
        getBeneficiaryName() {
            return this.checkProperty(this.evaluation, 'beneficiaryInformation', 'lastName') + " " + this.checkProperty(this.evaluation, 'beneficiaryInformation', 'firstName')
        },
    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>