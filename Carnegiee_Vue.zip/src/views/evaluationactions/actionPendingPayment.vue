<template>
    <div class="wrapper-item">
        <div class="wrapper-item" v-if="!isCompletedActivity">
            <div class="section-year">
                <p> </p>
                <p> </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_pending"></span>
                    <div class="status-name pending_bg">Pending Payment</div>
                    <div class="submit_detailes">
                        <div class="btn_flex">
                            <button class="primary_btn" @click="requestPayment">Request Payment
                                <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
                            <!-- <a href class="pay_btn">View Payment Details</a> -->
                            <div class="v_pay_details"
                                v-if="(checkProperty(evaluation, 'quotaPrice', 'evaluationPrices') && checkProperty(evaluation.quotaPrice, 'evaluationPrices', 'length') > 0)">
                                <!-- <b-button v-b-toggle.collapse-1 class="m-1 dropdown-toggle form-cancel">View Quote</b-button>
                            <b-collapse id="collapse-1" class="collapse-cnt quote_list">
                                <div class="bill-card quote_card">
                                    <div class="bill-heading">
                                        <p>QUOTE</p>
                                    </div>
                                    <ul>
                                        <li v-for="(priceItem, indx) in checkProperty(evaluation, 'quotaPrice', 'evaluationPrices')"
                                            :key="indx">
                                            <div class="ammount">
                                                {{ priceItem.evaluationTypeName }}
                                            </div>
                                            <span>{{ priceItem.price }}</span>
                                        </li>
                                        <li class="disc">
                                            <p>{{ 'Discount ' + checkProperty(evaluation, 'quotaPrice', 'discount') + ' Applied' }}
                                            </p>
                                            <p class="total"><span>Total</span>{{ checkProperty(evaluation, 'quotaPrice', 'total') }}</p>
                                        </li>
                                    </ul>
                                    

                                </div>
                            </b-collapse> -->

                                <b-dropdown size="lg" variant="link" toggle-class="text-decoration-none">
                                    <template #button-content>
                                        <b-button v-b-toggle.collapse-2 class="form-cancel">View Quote</b-button>
                                    </template>
                                    <b-dropdown-form>
                                        <div class="bill-card quote_card">
                                            <div class="bill-heading">
                                                <p>QUOTE</p>
                                            </div>
                                            <ul>
                                                <li v-for="(priceItem, indx) in checkProperty(evaluation, 'quotaPrice', 'evaluationPrices')"
                                                    :key="indx">
                                                    <div class="ammount">
                                                        {{ priceItem.evaluationTypeName }}
                                                    </div>
                                                    <span>${{ priceItem.price }}</span>
                                                </li>
                                                <li class="disc">
                                                    <p>{{ 'Discount ' + checkProperty(evaluation, 'quotaPrice', 'discount')
                                                        + ' Applied' }}
                                                    </p>
                                                    <p class="total"><span>Total</span>${{ checkProperty(evaluation,
                                                        'quotaPrice', 'total') }}</p>
                                                </li>
                                            </ul>


                                        </div>
                                    </b-dropdown-form>
                                </b-dropdown>


                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <div class="wrapper-item" v-if="isCompletedActivity">
            <div class="section-year">
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_pending"></span>
                    <div class="status-name pending_bg">Pending Payment</div>
                    <div class="submit_detailes">
                        <div class="btn_flex">
                            <h4 class="mb-0"> Payment Requested by <b>{{ checkProperty(activityLog, 'updatedByName') }}</b> </h4>
                            <div class="v_pay_details 2"
                                v-if="(checkProperty(evaluation, 'quotaPrice', 'evaluationPrices') && checkProperty(evaluation.quotaPrice, 'evaluationPrices', 'length') > 0)">
                                
                                <b-dropdown size="lg" variant="link" toggle-class="text-decoration-none">
                                    <template #button-content>
                                        <b-button v-b-toggle.collapse-2 class="form-cancel">View Quote</b-button>
                                    </template>
                                    <b-dropdown-form>
                                        <div class="bill-card quote_card">
                                            <div class="bill-heading">
                                                <p>QUOTE</p>
                                            </div>
                                            <ul>
                                                <li v-for="(priceItem, indx) in checkProperty(evaluation, 'quotaPrice', 'evaluationPrices')"
                                                    :key="indx">
                                                    <div class="ammount">
                                                        {{ priceItem.evaluationTypeName }}
                                                    </div>
                                                    <span>${{ priceItem.price }}</span>
                                                </li>
                                                <li class="disc">
                                                    <p>{{ 'Discount ' + checkProperty(evaluation, 'quotaPrice', 'discount')
                                                        + ' Applied' }}
                                                    </p>
                                                    <p class="total"><span>Total</span>${{ checkProperty(evaluation,
                                                        'quotaPrice', 'total') }}</p>
                                                </li>
                                            </ul>

                                        </div>
                                    </b-dropdown-form>
                                </b-dropdown>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';

export default {
    props: {
        evaluation: Object,
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        activityLog: Object,
    },
    components: {
        simpleSelect,
    },
    data: () => ({
        loading: false
    }),
    mounted() {
    },
    methods: {
        requestPayment() {
            this.loading = true
            let postData = {
                "evaluationId": this.evaluation._id,
            }
            this.$store.dispatch("requestPayment", postData)
                .then((response) => {
                    this.loading = false
                    if (response.error) {
                        (response.error)
                        Object.assign(this.formerrors, {
                            msg: response.error.result
                        });
                        this.showToster({ message: response.error.result, isError: true });
                    } else {
                        this.selectedUser = null
                        this.showToster({ message: response.message, isError: false });
                        this.$emit('updateDetails')
                    }
                })
                .catch((error) => {
                    this.loading = false
                    this.showToster({ message: error, isError: true });
                })
        },


    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>