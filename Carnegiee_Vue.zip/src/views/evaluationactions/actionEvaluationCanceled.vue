<template>
  <div v-if="isCompletedActivity" class="wrapper-item">
    <div class="section-year">
      <p> {{ checkProperty(activityLog,
        'updatedOn') | formatTime }}</p>
      <p> {{ checkProperty(activityLog,
        'updatedOn') | formatDate }}</p>
    </div>
    <section class="timeline-item">
      <div class="item">
        <span class="status_dot status_cancel"></span>
        <div class="status-name cancel_bg">Evaluation Cancelled</div>
        <div class="submit_detailes">
          <h4 v-if="checkProperty(activityLog, 'updatedByName')">
            Cancelled by <b>{{ checkProperty(activityLog,
              'updatedByName') }}</b></h4>

          <div class="info_view" v-if="checkProperty(activityLog, 'comments')">
            <p v-html="checkProperty(activityLog, 'comments')">
            </p>
          </div>

        </div>
      </div>
    </section>
  </div>
</template>


<script>


export default {
  props: {
    evaluation: Object,
    isCompletedActivity: {
      type: Boolean,
      default: false
    },
    activityLog: Object,
  },
  components: {
   
  },
  data: () => ({

  }),
  mounted() {
  },
  methods: {

  },

  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
}
</script>