<template>
    <div class="wrapper-item">

        <div class="wrapper-item" v-if="!isCompletedActivity">
            <div class="section-year">

            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_req"></span>
                    <div class="status-name req_bg">Set a Due Date</div>
                    <div class="submit_detailes">
                        <div class="form_info">
                            <div class="invoice-flex">
                                <!-- <div class="form_group" :class="wrapclass">
                        <date-picker v-model="time1" valueType="format" :format="'D/MM/YYYY'"
                          placeholder="D/MM/YYYY"></date-picker> -->

                                <datepicker :required="true" v-model="dueDate" fieldName="dueDate" label="Due Date"
                                    :dateEnableFrom="new Date()" />

                                <!-- </div> -->
                                <button class="primary_btn" @click="submitDueDate">Submit
                                    <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <div v-if="isCompletedActivity" class="wrapper-item">
            <div class="section-year">
                <p> {{ checkProperty(reviewDetails, 'updatedOn') | formatTime }}
                </p>
                <p> {{ checkProperty(reviewDetails, 'updatedOn') | formatDate }}
                </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_req"></span>
                    <div class="status-name req_bg">Set a Due Date</div>
                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(reviewDetails, 'updatedByName')">
                            Updated by <b>{{ checkProperty(reviewDetails,
                                'updatedByName') }}</b></h4>

                        <h4 class="mb-0">Due Date set to <b>{{ checkProperty(reviewDetails, 'dueDate') | formatDate }}</b></h4>
                    </div>
                </div>
            </section>
        </div>

    </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import datepicker from '@/views/forms/datePicker.vue';
//import DatePicker from 'vue2-datepicker';
import 'vue2-datepicker/index.css';

export default {
    props: {
        evaluation: Object,
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        reviewDetails:Object,
    },
    components: {
        simpleSelect,
        datepicker,
    },
    data: () => ({
        dueDate: null,
        loading: false,
    }),
    mounted() {

    },
    methods: {

        submitDueDate() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.loading = true
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "dueDate": this.dueDate,
                    }
                    this.$store.dispatch("setEvaluationDueDate", postData)
                        .then((response) => {
                            this.loading = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                this.selectedUser = null
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')

                            }
                        })
                        .catch((error) => {
                            this.loading = false
                            this.showToster({ message: error, isError: true });
                        })


                }
            })
        }

    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>