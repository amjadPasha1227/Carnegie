<template>
    <div class="wrapper-item">

        <div class="wrapper-item"
            v-if="!isCompletedActivity && (checkProperty(evaluation, 'isRequested') && evaluation.isRequested)">
            <div class="section-year">
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Case Requested</div>
                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(activityLog, 'updatedByName')">
                            Requested by <b>{{ checkProperty(activityLog, 'updatedByName') }}</b></h4>
                        <h4>Documents are ready for review</h4>
                        <div class="doc_files">
                            <DocumentsPreview :type="'documents'" :documentsList="getDocumentsToSubmitProfessor"
                                :includeDownloadText="false" @download_or_view="downloadFile" />
                        </div>
                        <div class="btn-flex mt-1">
                            <button class="primary_btn" @click="approveDocuments">Approve
                                <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
                            <button class="primary_btn sent_btn" @click="openFileUploadPopup">Send for Revision</button>
                        </div>


                    </div>
                </div>
            </section>
        </div>



        <div class="wrapper-item" v-if="isCompletedActivity && checkProperty(activityLog, 'action') == 'SIGN_REQUESTED'">
            <div class="section-year">
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Case Requested</div>
                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(activityLog, 'updatedByName')">
                            Requested by <b>{{ checkProperty(activityLog, 'updatedByName') }}</b></h4>
                        <div class="doc_files">
                            <h4>Documents are ready for review</h4>
                            <DocumentsPreview :type="'documents'" :documentsList="checkProperty(activityLog, 'documents')"
                                :includeDownloadText="false" @download_or_view="downloadFile" />

                        </div>
                    </div>
                </div>
            </section>
        </div>





        <div v-if="isCompletedActivity && checkProperty(activityLog, 'action') == 'SENT_FOR_REVISION'" class="wrapper-item">
            <div class="section-year">
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_req"></span>
                    <div class="status-name req_bg">Sent for Revision</div>
                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(activityLog, 'updatedByName')">
                            Revision sent by <b>{{ checkProperty(activityLog, 'updatedByName') }}</b></h4>
                        <p v-html="checkProperty(activityLog, 'comments')"></p>
                        <DocumentsPreview :type="'documents'" :documentsList="checkProperty(activityLog, 'documents')"
                            :includeDownloadText="false" @download_or_view="downloadFile" />
                    </div>
                </div>
            </section>
        </div>

        <b-modal id="addnotes_model" v-model="showUploadDocsPopup" dialog-class="addnotes_model" centered
            no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Add Notes</h6>
                <a class="close" @click="hideFileUploadTemplatePopup"></a>
            </template>
            <template>
                <div class="row">
                    <div class="col-md-12">
                        <textArea :tplkey="'revisionComments'" fieldName="moreDocs" placeHolder="Type Here…"
                            v-model="revisionComments"></textArea>
                        <small>For minor changes, you may provide instructions into the text box above.<br /> Any major
                            changes, you are requested to upload document with your suggested changes.</small>
                    </div>
                </div>
            </template>
            <template #modal-footer>
                <div class="upload-file me-auto">
                    <fileUpload :wrapclass="'no_doc_name'" :tplkey="'revisionDocuments'" v-model="documents"
                        :tplsection="'revisionDocuments'" label="" vvas="Document" :fieldName="'revisionDocuments'"
                        :cid="'revisionDocuments'" :multiple="true" :deleteDocPermenantly="true"
                        @uploadingFile="checkFileUploading($event)"></fileUpload>
                </div>
                <button class="form-cancel me-4" @click="hideFileUploadTemplatePopup">Cancel</button>
                <button class="primary_btn md" @click="sendDocumentsForRevision" :disabled="isFileUplading">Submit
                    <span class="loader" v-if="submitRevisionLoading"><img src="@/assets/images/loader.gif"></span></button>
            </template>
        </b-modal>


    </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import fileUpload from "@/views/forms/fileupload.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import textArea from "@/views/forms/textarea.vue";

export default {
    props: {
        evaluation: Object,
        activityLog: Object,
        actionCode: '',
        isRevisionSent: {
            type: Boolean,
            default: false,
        },
        isRequested: {
            type: Boolean,
            default: false,
        },
        isLastDoneActivity: {
            type: Boolean,
            default: false,
        },
        isCompletedActivity: {
            type: Boolean,
            default: false,
        },


    },
    components: {
        simpleSelect,
        fileUpload,
        fileUploadDrag,
        DocumentsPreview,
        textArea,
    },
    data: () => ({
        documents: null,
        revisionComments: '',
        loading: false,
        submitRevisionLoading: false,
        showUploadDocsPopup: false,
        isFileUplading: false,

    }),
    mounted() {

    },
    methods: {
        downloadFile(value) {
            this.$emit('download_or_view', value);
        },
        approveDocuments() {
            this.loading = true
            let postData = {
                "evaluationId": this.evaluation._id,
                "action": "SIGN_APPROVED",
                "professorId": this.evaluation.assignedToProfessor,
                "comments": "",
                "documents": this.checkProperty(this.activityLog, 'documents'),
            }
            this.$store.dispatch("submitToProfessor", postData)
                .then((response) => {
                    this.loading = false
                    if (response.error) {
                        (response.error)
                        Object.assign(this.formerrors, {
                            msg: response.error.result
                        });
                        this.showToster({ message: response.error.result, isError: true });
                    } else {
                        this.showUploadDocsPopup = false
                        this.selectedUser = null
                        this.showToster({ message: response.message, isError: false });
                        this.$emit('updateDetails')

                    }
                })
                .catch((error) => {
                    this.loading = false
                    this.showToster({ message: error, isError: true });
                })
        },

        sendDocumentsForRevision() {
            if (this.checkProperty(this.documents, 'length') <= 0 && this.revisionComments == '') {
                this.showToster({ message: "Either documents or notes are required", isError: true });
            } else {
                this.submitRevisionLoading = true
                let postData = {
                    "evaluationId": this.evaluation._id,
                    "action": "SENT_FOR_REVISION",
                    "professorId": this.evaluation.assignedToProfessor,
                    "comments": this.revisionComments,
                    "documents": this.documents,
                }
                this.$store.dispatch("submitToProfessor", postData)
                    .then((response) => {
                        this.submitRevisionLoading = false
                        if (response.error) {
                            (response.error)
                            Object.assign(this.formerrors, {
                                msg: response.error.result
                            });
                            this.showToster({ message: response.error.result, isError: true });
                        } else {
                            this.showUploadDocsPopup = false
                            this.selectedUser = null
                            this.showToster({ message: response.message, isError: false });
                            this.$emit('updateDetails')

                        }
                    })
                    .catch((error) => {
                        this.submitRevisionLoading = false
                        this.showToster({ message: error, isError: true });
                    })
            }


        },

        openFileUploadPopup() {
            this.documents = []
            this.isFileUplading = false
            this.showUploadDocsPopup = true
        },
        hideFileUploadTemplatePopup() {
            this.documents = []
            this.isFileUplading = false
            this.showUploadDocsPopup = false
        },
        checkFileUploading() {
            let uploading = false
            let resultDocs = _.filter(this.documents, (docItem) => {
                return this.checkProperty(docItem, 'fileUploading') && docItem.fileUploading
            })
            if (this.checkProperty(resultDocs, 'length') > 0) {
                if (!uploading) {
                    uploading = true
                }
            }
            this.isFileUplading = uploading
        }

    },
    computed: {
        getDocumentsToSubmitProfessor() {
            let resultDocs = []
            if (this.isLastCompletedActivity(this.evaluation, 'EVALUATION_TEMPLATE_ASSIGNED')) {
                if (this.checkProperty(this.evaluation, 'generatedDocuments', 'length') > 0) {
                    return this.checkProperty(this.evaluation, 'generatedDocuments')
                }
            } else if (this.checkProperty(this.evaluation.latestEvaluationLog, 'documents', 'length') > 0) {
                return this.checkProperty(this.evaluation, 'latestEvaluationLog', 'documents')
            }
            else {
                if (this.checkProperty(this.activityLog, 'documents', 'length') > 0) {
                    return this.checkProperty(this.documents, 'documents')
                }
            }

            return resultDocs
        },
    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>