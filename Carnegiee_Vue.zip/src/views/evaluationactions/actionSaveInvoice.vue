<template>
  <div class="wrapper-item">
    <div class="wrapper-item" v-if="!isCompletedActivity">
      <div class="section-year">
        <p></p>
        <p></p>
      </div>
      <section class="timeline-item">
        <div class="item">
          <span class="status_dot status_review"></span>
          <div class="status-name review_bg">Save Invoice</div>
          <div class="submit_detailes">
            <div class="form_info">
              <div class="invoice-flex">
                <!-- <div class="form_group" :class="wrapclass">
                                      <label class="form_label">Invoce No<em>*</em></label>
                                      <input :placeholder="placeHolder" class="form-control" :required="true" />
                                  </div> -->
                <simpleInput :fieldName="'invoiceNo'" :cid="'invoiceNo'" :label="'Invoice No'" :placeHolder="''"
                  :vvas="'Invoice No'" :display="true" :required="true" v-model="invoiceId" />

                <simpleInput :fieldName="'invoiceComments'" :cid="'invoiceComments'" :label="'Comments'" :placeHolder="''"
                  :vvas="'Comments'" :display="true" :required="false" v-model="comments" />
                <!-- <div class="form_group" :class="wrapclass">
                                      <label class="form_label">Comments</label>
                                      <input :placeholder="placeHolder" class="form-control" />
                                  </div> -->
                <button class="primary_btn" @click="createInvoice">Save Invoice
                  <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    <div v-if="isCompletedActivity" class="wrapper-item">
      <div class="section-year">
        <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime }} </p>
        <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate }} </p>
      </div>
      <section class="timeline-item">
        <div class="item">
          <span class="status_dot status_review"></span>
          <div class="status-name review_bg">Invoice Saved</div>
          <div class="submit_detailes">
            <h4 v-if="checkProperty(activityLog, 'updatedByName')">Issued by <b>{{
              checkProperty(activityLog, 'updatedByName') }}</b></h4>

            <h3 class="" v-if="checkProperty(activityLog, 'invoiceNo')">Invoice No {{
              checkProperty(activityLog, 'invoiceNo') }}
            </h3>
            <h4 class="mb-0" v-if="checkProperty(activityLog, 'invoiceComment')">{{
              checkProperty(activityLog,
                'invoiceComment') }}</h4>
          </div>
        </div>
      </section>
    </div>


    <b-modal id="preview_model" v-model="docPrivew" dialog-class="document_modal"
      :title="checkProperty(selectedFile, 'name')" hide-footer>
      <h2> <img :class="{
        pdf_view_download: docType == 'pdf',
        office_view_download: docType == 'office',
        image_view_download: docType == 'image',
      }" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>
      <div class="pdf_loader">
        <figure v-if="false" class="loader loader2"><img src="@/assets/images/loader.gif" /></figure>

        <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
        <template v-if="docType == 'office'">
          <div style="height:90vh">

            <div id="placeholder" name="placeholder" style="height:100%"></div>
          </div>
        </template>
        <template v-else-if="docType == 'image'">
          <img :src="docValue" />
        </template>
        <template v-else-if="docType == 'pdf'">
          <div class="pdf" style="height:90vh">

            <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%" width="100%">

            </iframe>
          </div>
        </template>
      </div>
    </b-modal>
  </div>
</template>
  
  
<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from '@/views/forms/simpleInput.vue';
import VuePerfectScrollbar from 'vue-perfect-scrollbar'

export default {
  props: {
    evaluation: Object,
    isCompletedActivity: {
      type: Boolean,
      default: false
    },
    activityLog: Object,
  },
  components: {
    simpleSelect,
    simpleInput,
    VuePerfectScrollbar,
  },
  data: () => ({
    invoiceId: '',
    comments: '',
    loading: false,
    showDetailsPopup: false,
    invoiceInfo: null,
    selectedForArchiveList: [],
    remainderSending: false,
    docPrivew: false,
    docType: '',
    docValue: '',
    selectedFile: null,
  }),
  mounted() {

  },
  methods: {
    toggleBodyScrollbar(visible) {
      const body = document.getElementsByTagName('body')[0];

      if (visible)
        body.classList.add("overflow-hidden");
      else
        body.classList.remove("overflow-hidden");
    },

    createInvoice() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          this.loading = true
          let postData = {
            "evaluationId": this.evaluation._id,
            "invoiceNo": this.invoiceId,
            "comments": this.comments,
          }
          this.$store.dispatch("saveInvoice", postData)
            .then((response) => {
              this.loading = false
              if (response.error) {
                (response.error)
                Object.assign(this.formerrors, {
                  msg: response.error.result
                });
                this.showToster({ message: response.error.result, isError: true });
              } else {
                // this.selectedUser = null
                this.showToster({ message: response.message, isError: false });
                this.$emit('updateDetails')

              }
            })
            .catch((error) => {
              this.loading = false
              this.showToster({ message: error, isError: true });
            })


        }
      })
    },

    showInvoiceDetails() {

      if (this.checkProperty(this.evaluation, 'invoiceId')) {
        let postData =
        {
          "invoiceId": this.evaluation.invoiceId,
        }
        this.$store.dispatch("getInvoiceDetails", postData)
          .then((res) => {
            this.invoiceInfo = res.result
            // setTimeout(() => {
            this.showDetailsPopup = true
            // })

          })
          .catch((error) => {

          })
      }



      // this.$emit('showInvoice')
    },
    sendRemainders() {
      this.remainderSending = true
      let postData =
        { "invoiceIds": [this.evaluation.invoiceId], }
      this.$store.dispatch("sendInvoiceRemainders", postData)
        .then((response) => {
          this.remainderSending = false
          if (response.error) {
            (response.error)
            Object.assign(this.formerrors, {
              msg: response.error.result
            });
            this.showToster({ message: response.error.result, isError: true });
          } else {
            this.showToster({ message: response.message, isError: false });
          }
        })
        .catch((error) => {
          this.remainderSending = false
          this.showToster({ message: error, isError: true });
        })
    },
    downloadInvoice(selectedItem, isView = false) {

      // if (this.checkProperty(this.invoiceInfo, 'invoicePath')) {
      //   if (isView) {
      //     let docItem = {
      //       path: this.checkProperty(this.invoiceInfo, 'invoicePath'),
      //       name: this.checkProperty(this.invoiceInfo, 'fileName')
      //     }
      //     this.selectedFile = docItem
      //     setTimeout(() => {
      //       this.viewInvoice(docItem)
      //     })
      //   } else {
      //     this.downloads3file({ 'path': this.checkProperty(this.invoiceInfo, 'invoicePath') })
      //   }
      // }
      // else {
      this.remainderSending = true
      let postData =
      {
        "invoiceId": this.evaluation.invoiceId,
        "download": true,
      }
      this.$store.dispatch("downloadInvoiceFile", postData)
        .then((response) => {
          this.remainderSending = false
          if (response.error) {
            (response.error)
            Object.assign(this.formerrors, {
              msg: response.error.result
            });
            this.showToster({ message: response.error.result, isError: true });
          } else {
            let downloadFilePath = response.result.s3UrlPath
            let fileName = response.result.fileName
            if (isView) {
              let docItem = {
                path: downloadFilePath,
                name: fileName
              }
              this.selectedFile = docItem
              setTimeout(() => {
                this.viewInvoice(docItem)
              })
            } else {
              this.downloads3file({ 'path': downloadFilePath })
            }
            this.remainderSending = false

          }
        })
        .catch((error) => {
          this.remainderSending = false
          this.showToster({ message: error, isError: true });
        })
      //  }
    },
    viewInvoice(docItem) {
      this.docValue = docItem.path;
      this.docType = this.findmsDoctype(docItem["path"], docItem.mimetype);
      let value = _.cloneDeep(docItem)
      var _self = this;
      this.formSubmited = false;
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }
      this.docValue = "";
      this.docPrivew = false;
      this.docType = this.findmsDoctype(value["path"], value.mimetype);

      if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
        //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
          // "petitionId": value['petitionId'],

          // entityType:value['petitionId']
          "fileName": value.name ? value.name : ''
        };
        // if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
        //   postdata['entityType'] = 'perm'
        // } else {
        //   postdata['entityType'] = 'case'
        // }


        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;
          if (this.docType == "office") {
            this.docPrivew = true;
            setTimeout(() => {
              document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
              let _editing = false;

              // if ([3, 4].indexOf(this.getUserRoleId) > -1) {
              //   _editing = false;
              // }

              // if (value.viewmode) {
              //   _editing = false;
              // }
              var _ob = {}
              // if (value.editedDocument) {
              //   _ob = {

              //     evaluationId: this.evaluationDetails._id,
              //     name: value.name,
              //     _id: value._id,
              //     "extn": "docx",
              //     "formLetterType": "Letter",
              //     parentId: value.parentId
              //   }

              // } else {

              _ob = {

                name: value.name,
                evaluationId: this.evaluationDetails._id,
                _id: value._id,
                "extn": "docx",
                "formLetterType": "Letter",
                parentId: value._id

              }

              //  }


              window.docEditor = new DocsAPI.DocEditor("placeholder2",
                {

                  "document": {
                    "c": "forcesave",
                    "fileType": "docx",
                    "key": value._id,
                    "userdata": JSON.stringify(_ob),
                    "title": value.name,
                    "url": response.data.result.data,
                    permissions: {
                      edit: _editing,
                      download: true,
                      reader: false,
                      review: false,
                      comment: false
                    }
                  },

                  "documentType": "word",
                  "height": "100%",
                  "width": "100%",

                  "editorConfig": {
                    "userdata": JSON.stringify(_ob),
                    "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                    "customization": {
                      "logo": {
                        "image": "https://immibox.com/app/favicon.png",
                        "imageDark": "https://immibox.com/app/favicon.png",
                        "url": "https://immibox.com"
                      },
                      "anonymous": {
                        "request": false,
                        "label": "Guest"
                      },
                      "chat": false,
                      "comments": false,
                      "compactHeader": false,
                      "compactToolbar": true,
                      "compatibleFeatures": false,
                      "feedback": {
                        "visible": false
                      },
                      "forcesave": true,
                      "help": false,
                      "hideNotes": true,
                      "hideRightMenu": true,
                      "hideRulers": true,
                      layout: {
                        toolbar: {
                          "collaboration": false,
                        },
                      },
                      "macros": false,
                      "macrosMode": "warn",
                      "mentionShare": false,
                      "plugins": false,
                      "spellcheck": false,
                      "toolbarHideFileName": true,
                      "toolbarNoTabs": true,
                      "uiTheme": "theme-light",
                      "unit": "cm",
                      "zoom": 100
                    },
                  }, events: {
                    onReady: function () {

                    },
                    onDocumentStateChange: function (event) {
                      var url = event.data;
                      console.log(event)

                      if (!event.data) {

                        if (value.editedDocument) {

                        }

                      }
                    }

                  }
                });
              //this.docValue = encodeURIComponent(response.data.result.data);
            }, 100)
          }

          if (this.docType == "pdf") {

            // this.downloadFile(this.docValue, value.mimetype, value.name)

            // return
            var _vid = value._id;
            if (value.parentId) {
              _vid = value.parentId;
            }
            var viewmode = 1; // Enable edit
            viewmode = 0; //Disabled Edit
            if (value.viewmode) {
              viewmode = 0;
            }
            this.docValue = "https://carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
            console.log(this.docValue)
            this.docPrivew = true;
          }
          if (this.docType == "image") {
            this.docPrivew = true;
          }



        });
      } else {
        this.downloads3file(value);
      }

    },
  },

  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
}
</script>