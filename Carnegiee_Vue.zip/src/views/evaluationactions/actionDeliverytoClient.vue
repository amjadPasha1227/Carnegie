<template>
    <div class="wrapper-item">
        <div class="wrapper-item" v-if="!isCompletedActivity">
            <div class="section-year">
                <p></p>
                <p> </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_conform"></span>
                    <div class="status-name conform_bg">Delivery to Client</div>
                    <div class="submit_detailes">
                        <label class="editor-label">Comments* <a class="link ms-2" @click="openTemplatePopup">Select Template</a></label>
                        <textArea class="mb-4" :tplkey="'deliveryOption'" fieldName="deliveryOption"
                            placeHolder="" v-model="selectedTemplate.content" :required="true" :vvas="'Comments'"
                            ref="deliveryComponentRef"></textArea>
                        <div class="doc_files"
                            v-if="checkProperty(evaluation, 'revisedDocuments', 'clientDocuments') && checkProperty(evaluation.revisedDocuments, 'clientDocuments', 'length') > 0">
                            <h3>Client Copies </h3>
                            <DocumentsPreview :type="'documents'"
                                :documentsList="checkProperty(evaluation, 'revisedDocuments', 'clientDocuments')"
                                :includeDownloadText="false" @download_or_view="downloadFile" />
                        </div>
                        <button class="primary_btn" @click="openEmailPreviewPopup">Preview Email & Deliver
                        </button>
                        <!-- <p>Nulla semper interdum nunc, vitae ultricies leo commodo ut. Integer risus metus, rutrum nec nibh sit amet, hendrerit tempor nunc.</p> -->
                    </div>
                </div>
        </section>
        </div>
        <div class="wrapper-item" v-if="isCompletedActivity">

            <div class="section-year" v-if="checkProperty(activityLog, 'updatedOn')">
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime
                }} </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate
                }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_conform"></span>
                    <div class="status-name conform_bg">Delivered</div>
                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(activityLog, 'updatedByName')">
                            Submitted by <b>{{ checkProperty(activityLog, 'updatedByName') }}</b></h4>
                        <div class="wrapper-timeline">
                            <div class="wrapper-item"
                                v-if="checkProperty(activityLog, 'deliveryTemplate', 'title') || checkProperty(activityLog, 'deliveryTemplate', 'content')">
                                <section class="timeline-item">
                                    <div class="item mt-0 p-0">
                                        <div class="info_view" v-if="false">
                                            {{ checkProperty(activityLog, 'deliveryTemplate', 'title') }}
                                        </div>
                                        <div class="info_view"
                                            v-if="checkProperty(activityLog, 'deliveryTemplate', 'content')">
                                            <p v-html="checkProperty(activityLog, 'deliveryTemplate', 'content')"></p>
                                        </div>
                                        <div class="doc_files"
                                            v-if="checkProperty(evaluation, 'revisedDocuments', 'clientDocuments') && checkProperty(evaluation.revisedDocuments, 'clientDocuments', 'length') > 0">
                                            <h3>Client Copies </h3>
                                            <DocumentsPreview :type="'documents'"
                                                :documentsList="checkProperty(evaluation, 'revisedDocuments', 'clientDocuments')"
                                                :includeDownloadText="false" @download_or_view="downloadFile" />
                                        </div>
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <b-modal v-model="showTemplatePopup" id="delivery_template_model" dialog-class="delivery_template_model professors"
            centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Delivery Comment Templates</h6>
                <div class="d-flex">
                    <a class="close" @click="closeTemplatePopup"></a>
                </div>
            </template>
            <template>
                <form :data-vv-scope="'deliveryTemplateForm'">
                    <simpleSelect :multiple="false" :wrapclass="'mb-3'" :optionslist="preliminaryTemplates" :display="true"
                        :placeHolder="'Select Template'" :searchable="false" :required="true" :close-on-select="true"
                        :clear-on-select="true" v-model="popupTemplate" :fieldName="'deliveryTemplate'"
                        :cid="'deliveryTemplate'" :hideSelected="false" :listContainsId="true" :trackBy="'title'"
                        :label="'Select Template'" :formscope="'deliveryTemplateForm'" />
                    <!-- <textArea v-if="checkProperty(popupTemplate, 'content')" class="mb-3" :tplkey="'deliveryContent'"
                        fieldName="deliveryContent" placeHolder="Delivery content here..."
                        v-model="popupTemplate.content"></textArea> -->
                </form>
            </template>
            <template #modal-footer>
                <button class="form-cancel" @click="closeTemplatePopup">Cancel</button>
                <button class="primary_btn md" @click="onDeliviryTemplateSubmit">Use Content</button>
            </template>
        </b-modal>

        <!-- Preview Email Modal -->
        <b-modal v-model="deliveryEmailPreview" id="submit_to_client" dialog-class="create_template submit_to_client" centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Preview Email</h6>
                <a class="close" @click="closeDeliveryEmailPreviewPopup()"></a>
            </template>
            <template>
                <form class="user_form create_temp bg-white">
                    <div class="subject">Subject: {{ checkProperty(evaluation, 'requestId') }}: Your Evaluation Request for
                        {{ getBeneficiaryName() }} is Delivered.</div>

                    <div class="email_preview_wrapper">
                        <div class="top_head">
                            <div class="bg_white"></div>
                        </div>
                        <div class="main_cnt">
                            <div class="main_inr">
                                <p>Dear <strong>{{ getCustomerName() }}</strong>,</p>
                                <p v-if="checkProperty(selectedTemplate, 'content')"
                                    v-html="checkProperty(selectedTemplate, 'content')"></p>
                                <!-- <p class="mb-0">Request ID: {{ checkProperty(evaluation, 'requestId') }}</p>
                                <p>Delivered On: July 7 2023</p> -->

                                <!-- <div class="regards">
                                    Regards,
                                    <span>Carnegie Evaluations</span>
                                </div> -->
                                <div class="line_blue"></div>
                                <emailPreviewFooter></emailPreviewFooter>
                                <!-- <div class="email_footer">
                                    <a href="https://carnegieevaluations.com/app/" target="_blank">
                                        <img src="@/assets/images/logo_carne.png" alt="Carnegie Evaluations">
                                        <img src="@/assets/images/email_footer_logo2.png" alt="Carnegie Evaluations">
                                    </a>
                                    <a href="mailto:eval@carnegieevaluations.com"
                                        target="_blank">eval@carnegieevaluations.com</a>
                                </div> -->
                            </div>
                        </div>
                    </div>
                    <div class="doc_preview_wrapper">
                        <h6>Attachments:</h6>
                        <ul class="doc_list_preview">
                            <li v-for="(item, index) in checkProperty(evaluation, 'revisedDocuments', 'clientDocuments')"
                                :key="index">
                                <div class="top">
                                    <span></span>
                                </div>
                                <div class="bottom">
                                    <img src="@/assets/images/gmail_file.png">
                                    <span class="doc_name" :title="item.name">{{ item.name }}</span>
                                    <div class="corner"></div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </form>
            </template>
            <template #modal-footer>
                <button class="form-cancel menustyle" @click="closeDeliveryEmailPreviewPopup()">Cancel</button>
                <button class="primary_btn sm menustyle" @click="submitToClient">Deliver
                    <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
            </template>
        </b-modal>
    </div>
</template>


<script>
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import textArea from "@/views/forms/textarea.vue";
import simpleSelect from '@/views/forms/simpleSelect.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import radioInput from "@/views/forms/radioInput.vue";
import emailPreviewFooter from "@/views/emailPreviewFooter.vue";

export default {
    props: {
        evaluation: Object,
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        activityLog: Object,
    },
    components: {
        textArea,
        simpleSelect,
        simpleInput,
        radioInput,
        DocumentsPreview,
        emailPreviewFooter,
    },
    data: () => ({
        comments: '',
        showTemplatePopup: false,
        preliminaryTemplates: [],
        selectedTemplate: {
            title: "",
            content: ""
        },
        popupTemplate: null,
        loading: false,
        reloadContent: true,
        deliveryEmailPreview: false

    }),
    mounted() {
        this.getTemplates()

    },
    methods: {
        downloadFile(value) {
            this.$emit('download_or_view', value);
        },

        getTemplates() {
            let postData = {
                "matcher": {
                    "title": "",
                    "statusIds": [],
                    "typeIds": [],
                    "createdByIds": [],
                    "createdDateRange": []
                },
                "sorting": {
                    "path": "createdOn", //title, statusName, createdByName, updatedOn, 
                    "order": -1
                },
                "getMasterData": true,
                "page": 1,
                "perpage": 500
            }
            this.$store.dispatch("getEmailsList", postData)
                .then((res) => {
                    this.preliminaryTemplates = res.data.result.list
                })
                .catch((error) => {
                })
        },

        openTemplatePopup() {
            // if (this.checkProperty(this.selectedTemplate, 'title')
            //     && this.checkProperty(this.selectedTemplate, 'title') != '') {
            //     this.popupTemplate = this.selectedTemplate
            // } else {
            //     this.popupTemplate = null
            // }
            this.popupTemplate = null
            this.showTemplatePopup = true
        },
        closeTemplatePopup() {
            this.popupTemplate = null
            this.showTemplatePopup = false
        },


        onDeliviryTemplateSubmit() {
            this.$validator.validateAll('deliveryTemplateForm').then((result) => {
                if (result) {
                    // const editorInstance = this.$refs.deliveryComponentRef.$refs.deliveryOption.$_instance;
                    // if (editorInstance) {
                    //     const cursorPosition = editorInstance.model.document.selection.getFirstPosition();
                    //     editorInstance.model.change((writer) => {
                    //         writer.insertText(this.popupTemplate.content, cursorPosition);
                    //     });
                    //     this.selectedTemplate.content = editorInstance.getData(); 
                    // } else {
                    //     if (this.checkProperty(this.selectedTemplate, 'content')) {
                    //         let resultContent = this.popupTemplate.content + '</br></br>' + this.selectedTemplate.content
                    //         this.selectedTemplate.content = resultContent
                    //     } else {
                    //         this.selectedTemplate = this.popupTemplate
                    //     }
                    // }



                    if (this.checkProperty(this.selectedTemplate, 'content')) {
                        let resultContent = this.selectedTemplate.content + this.popupTemplate.content
                        this.selectedTemplate.content = resultContent
                    } else {
                        this.selectedTemplate = this.popupTemplate
                    }

                    this.showTemplatePopup = false
                }
            })
        },
        submitToClient() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.loading = true
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "deliveryTemplate": this.selectedTemplate,
                    }
                    this.$store.dispatch("evaluationDeliveryToClient", postData)
                        .then((response) => {
                            this.loading = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                this.selectedTemplate = {
                                    title: "",
                                    content: ""
                                }
                                this.reloadContent = false
                                this.closeDeliveryEmailPreviewPopup()
                                this.selectedUser = null
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')
                                this.reloadContent = true

                            }
                        })
                        .catch((error) => {
                            this.loading = false
                            this.showToster({ message: error, isError: true });
                        })
                }
            })
        },
        getCustomerName() {
            return this.checkProperty(this.evaluation, 'name')
        },
        openEmailPreviewPopup() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.openDeliveryEmailPreviewPopup()
                }
            })
        },
        getBeneficiaryName() {
            return this.checkProperty(this.evaluation, 'beneficiaryInformation', 'lastName') + " " + this.checkProperty(this.evaluation, 'beneficiaryInformation', 'firstName')
        },
        openDeliveryEmailPreviewPopup() {
            this.deliveryEmailPreview = true
        },
        closeDeliveryEmailPreviewPopup() {
            this.selectedTemplate = {
                title: "",
                content: ""
            }
            this.deliveryEmailPreview = false
        },
    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>