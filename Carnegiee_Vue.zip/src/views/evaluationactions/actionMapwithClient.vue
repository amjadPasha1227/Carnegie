<template >
    <div class="wrapper-item">
        <div class="section-year">
            <p> {{ checkProperty(evaluation, 'createdOn') | formatTime }} </p>
            <p> {{ checkProperty(evaluation, 'createdOn') | formatDate }} </p>
        </div>
        <section class="timeline-item">
            <div class="item">
                <span class="status_dot status_req"></span>
                <div class="status-name req_bg">Requested</div>
                <div class="submit_detailes">
                    <h4 v-if="checkProperty(evaluation, 'name')" class="requested">Evaluation request recieved from <a>{{
                        checkProperty(evaluation, 'name') }}</a></h4>
                    <div v-if="checkProperty(evaluation, 'completedActivities').indexOf('CUSTOMER_ASSIGNED') > -1
                        && checkProperty(evaluation, 'customersDetails', 'name')" class="mapped_client">
                        <div class="exp_users_info">
                            <div class="users-flex">
                                <p class="m-0">Client <span class="client"><img
                                            src="@/assets/images/business-and-trade.png"> {{
                                                checkProperty(evaluation, 'customersDetails',
                                                    'companyName') ? checkProperty(evaluation,
                                                        'customersDetails', 'companyName') : checkProperty(evaluation, 'customersDetails',
                                                            'name') }}</span></p>
                            </div>
                        </div>
                    </div>
                    <!-- <h4 v-if="checkProperty(evaluation, 'completedActivities').indexOf('CUSTOMER_ASSIGNED') > -1
                        && checkProperty(evaluation, 'customersDetails', 'name')"><b>{{ checkProperty(evaluation,
        'customersDetails', 'name') }}</b> has been assigned as client</h4> -->
                    <div class="invoice-flex">
                        <button
                            v-if="(!hideReviewButton && (!isActivityCompleted(evaluation, 'EVALUATION_REVIEWED') && !isActivityCompleted(evaluation, 'REVIEW_CONFIRMED')) && [3, 4, 7, 8].indexOf(getUserRoleId) > -1) && !isActivityCompleted(evaluation, 'EVALUATION_REQUEST_CANCELLED')"
                            class="primary_btn" @click="onReviewButtonClick">Review</button>
                        <button
                            v-if="checkProperty(evaluation, 'completedActivities').indexOf('CUSTOMER_ASSIGNED') < 0 && [3, 4, 7, 8].indexOf(getUserRoleId) > -1 && !isActivityCompleted(evaluation, 'EVALUATION_REQUEST_CANCELLED')"
                            class="primary_btn edit_btn" @click="showMapWithClientPopup">Map with Client</button>
                    </div>
                    <ul class="beneficiary_detailes_v2">
                        <li>
                            <label>Doing this</label>
                            <h4>{{ checkProperty(evaluation, 'isDoingYourSelf') == null ? 'Intake Team':checkProperty(evaluation, 'isDoingYourSelf') && evaluation.isDoingYourSelf ?
                            'My self' : 'Behalf of others' }}</h4>
                        </li>
                        <li v-if="false">
                            <label>Type</label>
                            <h4>{{ checkProperty(evaluation, 'proceedImmediately') && evaluation.proceedImmediately ?
                                'Proceed Immediately' : 'Contact Me First' }}</h4>
                        </li>

                        <li v-if="checkProperty(evaluation, 'name')">
                            <label>Full Name</label>
                            <h4>{{ checkProperty(evaluation, 'name') }}</h4>
                        </li>
                        <li v-if="checkProperty(evaluation, 'phone')">
                            <label>Phone Number</label>
                            <h4>{{ checkProperty(evaluation.phoneCountryCode, 'countryCallingCode') | countryFormatter }}
                                {{ checkProperty(evaluation, 'phone') | formatPhone }}</h4>
                        </li>
                        <li v-if="checkProperty(evaluation, 'email')">
                            <label>Email</label>
                            <h4>{{ checkProperty(evaluation, 'email') }}</h4>
                        </li>
                        <li
                            v-if="checkProperty(evaluation, 'customersDetails', 'name') || checkProperty(evaluation, 'firm')">
                            <label>Client</label>
                            <h4>{{ checkProperty(evaluation, 'customersDetails', 'companyName') ?
                                checkProperty(evaluation, 'customersDetails', 'companyName')
                                : checkProperty(evaluation, 'customersDetails', 'name') ?
                                    checkProperty(evaluation, 'customersDetails', 'name')
                                    : checkProperty(evaluation, 'firm') }}</h4>
                        </li>
                        <!-- <li
                            v-if="checkProperty(evaluation, 'firm')">
                            <label>Client</label>
                            <h4>{{ checkProperty(evaluation, 'firm') }}</h4>
                        </li> -->
                        <li
                            v-if="checkProperty(evaluation, 'altEmailsList', 'length') > 0 || checkProperty(evaluation, 'alternateEmail')">
                            <label>Alternate Email(s)</label>
                            <!-- <h4>{{ checkProperty(evaluation, 'alternateEmail') }}</h4> -->
                            <!-- <table class="alternate_emails_table"
                                v-if="checkProperty(evaluation, 'altEmailsList', 'length') > 0">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(item, index) in checkProperty(evaluation, 'altEmailsList')"
                                        v-bind:key="index">
                                        <td>{{ checkProperty(item, 'name') }}</td>
                                        <td>{{ checkProperty(item, 'email') }}</td>
                                    </tr>
                                </tbody>
                            </table> -->
                            <h4>{{ getAlternateEmails }}</h4>
                        </li>

                        <li v-if="getWageLevelAnalysis()">
                            <label>Wage Level</label>
                            <h4>{{ getWageLevelAnalysis() }}</h4>
                        </li>
                        <li v-if="getWageLevelDisciplines()" class="alternate_emails">
                            <label>Names of the Disciplines</label>
                            <h4>{{ getWageLevelDisciplines() }}</h4>
                        </li>
                        <li v-if="checkProperty(evaluation, 'specialNotes')" class="alternate_emails">
                            <label>Client Notes</label>
                            <p v-html="checkProperty(evaluation, 'specialNotes')"></p>
                        </li>
                        <li v-if="getUserRoleId !== 15 && checkProperty(evaluation, 'evalFirstEmail')" class="alternate_emails">
                            <label>First Email</label>
                            <p v-html="checkProperty(evaluation, 'evalFirstEmail')"></p>
                        </li>
                    </ul>
                </div>
            </div>
        </section>

        <b-modal v-model="showMapClientPopup" id="client_model" dialog-class="status-popup professors client" centered
            no-close-on-backdrop>
            <template #modal-header v-if="!isActivityCompleted(evaluation, 'EVALUATION_REVIEWED')">
                <h6 class="modal-title">Map with Client</h6>
                <div class="d-flex align-items-center">
                    <button class="primary_btn add_btn add_client_btn me-2"
                        @click="showAddCustomerPopup = true"><span></span><em>Add
                            Client</em></button>
                    <a class="close" @click="hideMapWithClientPopup"></a>
                </div>
            </template>
            <template #modal-header v-else>
                <h6 class="modal-title">Map with Client</h6>
                <a class="close" @click="hideMapWithClientPopup"></a>
            </template>
            <template>
                <div class="rq_header d-block">
                    <div class="user_info_sec">
                        <simpleSelect :multiple="false" :wrapclass="'req_status'" :optionslist="customerList"
                            :display="true" :place-holder="'Select Client'" :searchable="false" :required="true"
                            :close-on-select="true" :clear-on-select="true" class="mb-0 ass-eval" v-model="selectedCustomer"
                            :fieldName="'client'" :cid="'client'" :vvas="'Client'" />
                    </div>


                </div>
            </template>
            <template #modal-footer>
                <button class="form-cancel" @click="hideMapWithClientPopup">Cancel</button>
                <button class="primary_btn md" @click="submitMapClient()">Submit</button>
            </template>
        </b-modal>

        <AddCustomer v-if="showAddCustomerPopup" @closeAddCustomer="showAddCustomerPopup = false"
            @updateCustomer="updateWithNewCustomer"></AddCustomer>
    </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import AddCustomer from '../common/addCustomer.vue';
import JQuery from "jquery";


export default {
    props: {
        evaluation: Object,
        hideReviewButton: {
            type: Boolean,
            default: false
        }
    },
    components: {
        simpleSelect,
        AddCustomer
    },
    data: () => ({
        customerList: [],
        selectedCustomer: null,
        showAddCustomerPopup: false,
        showMapClientPopup: false,

    }),
    mounted() {
        this.getCustomersList()

    },
    methods: {
        getCustomersList() {
            let postData =
            {
                "matcher": {
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": true,// if Masterdata required
                "page": 1,
                "perpage": 500,
            }

            this.$store.dispatch("getcustomerList", postData)
                .then((res) => {
                    this.customerList = res.data.result.list
                })

        },
        submitMapClient() {
            this.$validator.validateAll().then((result) => {
                if (result) {

                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "customerId": this.selectedCustomer._id
                    }

                    this.$store.dispatch("mapClientToEvaluation", postData)
                        .then((response) => {
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                this.hideMapWithClientPopup()
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')

                            }
                        })
                        .catch((error) => {
                            this.showToster({ message: error, isError: true });
                        })


                }
            })
        },
        updateWithNewCustomer(customer) {
            // alert(JSON.stringify(customer))
            if (this.checkProperty(customer, '_id')) {
                let object = { _id: this.checkProperty(customer, '_id'), name: this.checkProperty(customer, 'name') }
                this.selectedCustomer = object
            }
            this.showMapWithClientPopup()
        },
        showMapWithClientPopup() {
            this.customerList = []
            this.getCustomersList()
            this.showMapClientPopup = true
        },
        hideMapWithClientPopup() {
            this.showMapClientPopup = false
            this.selectedCustomer = null
        },
        onReviewButtonClick() {
            this.$emit('showReviewAction')
            const $ = JQuery;
            $("html, body").animate({ scrollTop: 0 }, 100);
        },

        getWageLevelAnalysis() {
            if (this.checkProperty(this.evaluation, 'docsConfig', 'length') > 0) {
                let wageEvaluaton = _.filter(this.evaluation.docsConfig, (evalItem) => {
                    return this.checkProperty(evalItem, 'evaluationTypeId') == 18
                })
                if (this.checkProperty(wageEvaluaton, 'length') > 0 &&
                    this.checkProperty(wageEvaluaton[0], 'subTypes', 'length') > 0) {
                    let wageEvaluatonSubType = _.filter(wageEvaluaton[0].subTypes, (subType) => {
                        return this.checkProperty(subType, 'subTypeId') == 70 && this.checkProperty(subType, 'levels', 'length') > 0
                    })
                    if (this.checkProperty(wageEvaluatonSubType, 'length') > 0
                        && this.checkProperty(wageEvaluatonSubType[0], 'levels', 'length') > 0) {
                        return wageEvaluatonSubType[0].levels[0].name
                    }
                }

            }

            return null
        },
        getWageLevelDisciplines() {
            if (this.checkProperty(this.evaluation, 'docsConfig', 'length') > 0) {
                let wageEvaluaton = _.filter(this.evaluation.docsConfig, (evalItem) => {
                    return this.checkProperty(evalItem, 'evaluationTypeId') == 18
                })
                if (this.checkProperty(wageEvaluaton, 'length') > 0 &&
                    this.checkProperty(wageEvaluaton[0], 'subTypes', 'length') > 0) {
                    let wageEvaluatonSubType = _.filter(wageEvaluaton[0].subTypes, (subType) => {
                        return this.checkProperty(subType, 'subTypeId') == 72
                    })
                    if (this.checkProperty(wageEvaluatonSubType, 'length') > 0
                        && this.checkProperty(wageEvaluatonSubType[0], 'nameOfDisciplines')) {
                        return this.checkProperty(wageEvaluatonSubType[0], 'nameOfDisciplines')
                    }
                }

            }

            return null
        },
    },
    computed: {
        getAlternateEmails() {
            let altEmailStr = ""
            if (this.checkProperty(this.evaluation, 'altEmailsList', 'length') > 0) {
                this.checkProperty(this.evaluation, 'altEmailsList').forEach((item, index) => {
                    if (index == 0) {
                        altEmailStr = item.email
                    } else {
                        altEmailStr = altEmailStr + "," + item.email
                    }
                });
            } else if (this.checkProperty(this.evaluation, 'alternateEmail')) {
                altEmailStr = this.checkProperty(this.evaluation, 'alternateEmail')
            }
            return altEmailStr
        }
    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>