<template>
    <div class="wrapper-item">

        <div class="wrapper-item" v-if="!isCompletedActivity">
            <div class="section-year">
                <p> </p>
                <p> </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Merge</div>
                    <div class="submit_detailes">
                        <div class="d-flex">
                            <button class="primary_btn" @click="openTemplatePopup">Merge Document</button>
                            <button class="primary_btn" @click="openUploadDocumentsPopup">Upload Documents</button>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <div v-if="isCompletedActivity" class="wrapper-item">
            <div class="section-year">
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatTime
                }}
                </p>
                <p> {{ checkProperty(activityLog, 'updatedOn') | formatDate
                }}
                </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Merge</div>
                    <div class="submit_detailes">
                        <h4 v-if="checkProperty(activityLog, 'updatedByName')">
                            Assigned by <b>{{ checkProperty(activityLog,
                                'updatedByName') }}</b></h4>
                        <div class="info_view" v-if="false">
                            {{ checkProperty(evaluation, 'evaluationTemplate', 'title') }}
                        </div>
                        <h4></h4>
                        <p class="info_view" v-if="checkProperty(evaluation, 'evaluationTemplate', 'title')"
                            v-html="checkProperty(evaluation, 'evaluationTemplate', 'title')">
                        </p>
                        <h4 v-html="checkProperty(activityLog, 'comments')"></h4>
                        <div class="doc_files" v-if="checkProperty(activityLog, 'documents', 'length') > 0">
                            <h3> {{ 'Template Documents' }}</h3>
                            <DocumentsPreview :type="'documents'" :documentsList="checkProperty(activityLog, 'documents')"
                                :includeDownloadText="false" @download_or_view="downloadFile" />

                        </div>

                        <div class="d-flex"
                            v-if="[3, 4, 7,8].indexOf(getUserRoleId) > -1 && canShowGenerateDocuments() && checkProperty(evaluation, 'statusDetails', 'id') < 14">
                            <button class="primary_btn" @click="openTemplatePopup">Merge Document</button>
                            <!-- <button
                                v-if="[3, 4, 7].indexOf(getUserRoleId) > -1 && (checkProperty(evaluation, 'assignedToEvaluatorDetails', '_id') || checkProperty(evaluation, 'assignedToConsultantDetails', '_id'))
                                &&checkProperty(evaluation, 'statusDetails', 'id') < 10"
                                class="primary_btn" @click="reAssignToEvaluator">Submit to Offshore</button> -->

                            <button class="primary_btn" @click="openUploadDocumentsPopup">Upload Documents</button>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <!-- <b-modal id="select_template_model" dialog-class="status-popup professors" centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Select Template</h6>
                <div class="d-flex">
                    <a class="close" :disabled="isDocumentsGenerating" @click="hideTemplatePopup"></a>
                </div>
            </template>
            <template>
                <div class="rq_header d-block">
                    <div class="user_type_list">
                        <div class="template_list" v-if="checkProperty(templatesList, 'length') > 0">
                            <VuePerfectScrollbar>
                                <radioInput v-for="(templateItem, index) in templatesList" wrapclass="mb10"
                                    :elementId="'Template ' + index" :label="templateItem.title"
                                    :fieldName="'email_template'" v-model="selectedTemplate" :fieldValue="templateItem"
                                    v-validate="'required'" :data-vv-name="'Template 1'" type="submit-btn"
                                    :showPreview="true" @download_or_view="downloadFile" />
                                <input type="hidden" class="form-control" v-validate="'required'" v-model="selectedTemplate"
                                    data-vv-as="Template" :name="'userroleRadio'" />
                                <span v-show="errors.has('userroleRadio')" class="form-error">{{
                                    errors.first('userroleRadio')
                                }}</span>
                            </VuePerfectScrollbar>
                        </div>
                        <div v-else class="template_nodata">
                            <h4>No templates found</h4>
                        </div>


                    </div>
                </div>
            </template>
            <template #modal-footer>
                <button :disabled="isDocumentsGenerating" class="form-cancel" @click="hideTemplatePopup">Cancel</button>
                <button class="primary_btn md" :disabled="checkProperty(templatesList, 'length') == 0"
                    @click="onTemplateSelect">Merge
                    <span class="loader" v-if="isDocumentsGenerating"><img src="@/assets/images/loader.gif"></span></button>
            </template>
        </b-modal> -->

        <b-modal id="doc_model" v-model="showUploadDocsPopup" dialog-class="status-popup professors documents" centered
            no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Upload Documents</h6>
                <a class="close" @click="hideUploadDocumentsPopup"></a>
            </template>
            <template>
                <div class="rq_header d-block">
                    <div class="user_info_sec" style="padding: 10px 20px;">
                        <div class="drop_files mb-0 position-relative">
                            <fileUploadDrag :label="'Documents*'" :wrapclass="'mb10'" :multiple="true" v-model="documents"
                                @uploadingFile="checkFileUploading($event)"  :fieldName="'uploadTemplateDocs'" :display="'uploadTemplateDocs'" />
                            <input type="hidden" class="form-control" v-validate="'required'" v-model="documents"
                                data-vv-as="Documents" :name="'userroleRadio'" />
                            <span v-show="errors.has('userroleRadio')" class="form-error">{{
                                errors.first('userroleRadio')
                            }}</span>
                        </div>
                        <div>
                            <textArea class="mb-4 mt-3 comments-ck_editer" :tplkey="'reviewConfirm'"
                                fieldName="reviewConfirm" placeHolder="" v-model="comments" :required="false"
                                :vvas="'Comments'" label="Comments"></textArea>
                        </div>
                    </div>
                </div>

            </template>
            <template #modal-footer>
                <button class="form-cancel" @click="hideUploadDocumentsPopup">Cancel</button>
                <button :disabled="isFileUplading" class="primary_btn sm"
                    @click="submitDocuments('EVALUATION_DOCUMENTS_CONFIRMED', false)">Submit
                    <span class="loader" v-if="submitDocsLoading"><img src="@/assets/images/loader.gif"></span></button>
            </template>
        </b-modal>



        <!-- side navbar1 -->
        <b-sidebar id="sidebar-no-header" v-model="showTemplatePopup" aria-labelledby="sidebar-no-header-title"
            sidebar-class="customer-sidenav" title="#INV-3066" right no-header backdrop shadow
            @change="toggleBodyScrollbar">
            <template #default="{ hide }">
                <span class="loader" v-if="isDetailsLoading"><img src="@/assets/images/loader.gif"></span>
                <div class="sidenav_header">
                    <div class="invoice_name">
                        <h3>{{ 'Merge Document' }}</h3>
                    </div>
                    <div class="invoice_activitys">
                        <a class="close" block @click="hide"><img src="@/assets/images/close.svg"></a>
                    </div>
                </div>
                <VuePerfectScrollbar>
                    <foldresAndFiles v-if="showTemplatePopup"
                        :professorIds="checkProperty(evaluation, 'assignedToProfessor')" :isFromEvaluation="true"
                        @onFileSelect="onTemplateFileSelect"
                        :evaltplfolderId="checkProperty(evaluation, 'assignedToProfessorDetails', 'evaltplfolderId')">
                    </foldresAndFiles>
                </VuePerfectScrollbar>
            </template>
        </b-sidebar>



        <b-modal v-model="showDocumentsConfirmPopup" id="select_template_model"
            dialog-class="status-popup professors active_inactive_model " centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">Confirm Merge Documents</h6>
                <div class="d-flex">
                    <a class="close" :disabled="isDocumentsGenerating" @click="hideDocumentsConfirmPopup"></a>
                </div>
            </template>
            <template>
                <p class="confirm_msg" v-if="checkProperty(selectedTemplate, 'documents', 'length') > 0">Are you sure you
                    want to merge the selected documents?</p>
            </template>
            <template #modal-footer>
                <button :disabled="isDocumentsGenerating" class="form-cancel"
                    @click="hideDocumentsConfirmPopup">Cancel</button>
                <button class="primary_btn md" :disabled="checkProperty(selectedTemplate, 'documents', 'length') == 0"
                    @click="onTemplateSelect">Confirm
                    <span class="loader" v-if="isDocumentsGenerating"><img src="@/assets/images/loader.gif"></span></button>
            </template>
        </b-modal>


    </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';
import datepicker from '@/views/forms/datePicker.vue';
import radioInput from "@/views/forms/radioInput.vue";
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import VuePerfectScrollbar from 'vue-perfect-scrollbar'
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import textArea from "@/views/forms/textarea.vue";
import foldresAndFiles from "@/views/mergedocuments/foldresAndFiles.vue"


export default {
    props: {
        evaluation: Object,
        isCompletedActivity: {
            type: Boolean,
            default: false
        },
        activityLog: Object,
    },
    components: {
        DocumentsPreview,
        simpleSelect,
        datepicker,
        radioInput,
        fileUploadDrag,
        textArea,
        VuePerfectScrollbar,
        foldresAndFiles,
    },
    data: () => ({
        dueDate: null,
        loading: false,
        showTemplatePopup: false,
        templatesList: [],
        selectedTemplate: null,
        isDocumentsGenerating: false,
        documents: [],
        isFileUplading: false,
        showUploadDocsPopup: false,
        submitDocsLoading: false,
        comments: "",
        showDocumentsConfirmPopup: false,
    }),
    mounted() {
        this.getEvaluationTemplates()
    },
    methods: {
        toggleBodyScrollbar(visible) {
            const body = document.getElementsByTagName('body')[0];

            if (visible)
                body.classList.add("overflow-hidden");
            else
                body.classList.remove("overflow-hidden");
        },
        downloadFile(value) {
            this.$emit('download_or_view', value);
        },
        onTemplateSelect() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.isDocumentsGenerating = true
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "evaluationTemplate": this.selectedTemplate,
                        "task": "merge"
                    }
                    if (this.checkProperty(this.activityLog, '_id')) {
                        Object.assign(postData, { logId: this.checkProperty(this.activityLog, '_id') });
                    }

                    this.$store.dispatch("assignEvaluationTemplate", postData)
                        .then((response) => {
                            this.isDocumentsGenerating = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                this.selectedUser = null
                                this.showTemplatePopup = false
                                this.hideDocumentsConfirmPopup()
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')
                            }
                        })
                        .catch((error) => {
                            this.isDocumentsGenerating = false
                            this.showToster({ message: error, isError: true });
                        })
                }
            })
        },

        getEvaluationTemplates() {
            let professorIds = []
            if (this.checkProperty(this.evaluation, 'assignedToProfessor')) {
                professorIds = [this.checkProperty(this.evaluation, 'assignedToProfessor')]
            }
            let postData = {
                "matcher": {
                    "title": "",
                    "statusIds": [1],
                    "createdByIds": [],
                    "createdDateRange": [],
                    "professorIds": professorIds,
                    // "professorIds": ['cvkjnfdjnofjd']
                },
                "sorting": {
                    "path": "createdOn", //title, statusName, createdByName, updatedOn, 
                    "order": -1
                },
                "getMasterData": true,
                "page": 1,
                "perpage": 500
            }




            this.$store.dispatch("getEvaluationTemplatesList", postData)
                .then((res) => {
                    this.templatesList = res.data.result.list
                })
                .catch((error) => {
                })
        },
        openTemplatePopup() {
            this.selectedTemplate = null
            this.showTemplatePopup = true
        },
        hideTemplatePopup() {
            this.showTemplatePopup = false
            this.selectedTemplate = null
        },
        generateDocuments() {
            this.isDocumentsGenerating = true
            let payload = {
                "evaluationId": this.evaluation._id,
            }
            if (this.checkProperty(this.activityLog, '_id')) {
                Object.assign(payload, { logId: this.checkProperty(this.activityLog, '_id') });
            }

            this.$store.dispatch("commonAction", { data: payload, path: "evaluation/generate-evaluation-template", })
                .then((response) => {
                    this.showToster({ message: response.message, isError: false })
                    this.isDocumentsGenerating = false;
                    this.$emit('updateDetails')
                }).catch((error) => {
                    this.showToster({ message: error.message, isError: true })
                    this.isDocumentsGenerating = false;
                });

        },
        canShowGenerateDocuments() {

            if (this.checkProperty(this.activityLog, 'documents', 'length') > 0
                && (this.checkProperty(this.activityLog, 'generateLogs', 'length') == 0)) {

                if ((this.checkProperty(this.evaluation, 'generatedDocuments', 'length') == 0
                    || (this.checkProperty(this.evaluation, 'generatedDocuments', 'length') > 0
                        && this.checkProperty(this.activityLog.documents[0], 'name')
                        != this.checkProperty(this.evaluation.generatedDocuments[0], 'name')))
                    && (this.checkProperty(this.evaluation, 'evaluationDocuments', 'length') == 0
                        || (this.checkProperty(this.evaluation, 'evaluationDocuments', 'length') > 0
                            && this.checkProperty(this.activityLog.documents[0], 'name')
                            != this.checkProperty(this.evaluation.evaluationDocuments[0], 'name')))
                ) {
                    return false
                }
                return true
            }
            // else if (this.checkProperty(this.activityLog, 'documents', 'length') > 0
            //     && this.checkProperty(this.activityLog, 'generateLogs', 'length') == 0) {

            //     if (this.checkProperty(this.evaluation, 'evaluationDocuments', 'length') == 0
            //         || (this.checkProperty(this.evaluation, 'evaluationDocuments', 'length') > 0
            //             && this.checkProperty(this.activityLog.documents[0], 'name')
            //             != this.checkProperty(this.evaluation.evaluationDocuments[0], 'name'))) {
            //         return false
            //     }
            //     return true
            // }


            else if (this.checkProperty(this.activityLog, 'documents', 'length') > 0
                && (this.checkProperty(this.evaluation, 'generatedDocuments', 'length') > 0
                    || this.checkProperty(this.evaluation, 'evaluationDocuments', 'length') > 0)) {
                if (this.checkProperty(this.activityLog.documents[0], 'name')
                    == this.checkProperty(this.evaluation.generatedDocuments[0], 'name')) {
                    return true
                }
                if (this.checkProperty(this.activityLog.documents[0], 'name')
                    == this.checkProperty(this.evaluation.evaluationDocuments[0], 'name')) {
                    return true
                }
            }

            return false
        },
        reAssignToEvaluator() {
            let userId = this.checkProperty(this.evaluation, 'assignedToEvaluatorDetails', '_id') ? this.checkProperty(this.evaluation, 'assignedToEvaluatorDetails', '_id')
                : this.checkProperty(this.evaluation, 'assignedToConsultantDetails', '_id')
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.loading = true
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "userId": userId,
                        "documents": [],
                    }

                    if (this.checkProperty(this.documents, 'length') > 0) {
                        postData['documents'] = this.documents
                    } else if (this.checkProperty(this.evaluation, 'generatedDocuments', 'length') > 0) {
                        postData['documents'] = this.checkProperty(this.evaluation, 'generatedDocuments')
                    }

                    if (this.getAssignedUserLogId()) {
                        Object.assign(postData, { logId: this.getAssignedUserLogId() });
                    }

                    this.$store.dispatch("assignUser", postData)
                        .then((response) => {
                            this.loading = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                // this.selectedUser = null
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')

                            }
                        })
                        .catch((error) => {
                            this.loading = false
                            this.showToster({ message: error, isError: true });
                        })


                }
            })
        },

        getAssignedUserLogId() {
            let logId = ''
            let isLogFound = false
            _.forEach(this.checkProperty(this.evaluation, 'evaluationActivityInfoLogs'), (activitylog, index) => {

                if (!isLogFound && activitylog.action == 'EVALUATION_CONSULTANT_ASSIGNED' || activitylog.action == 'EVALUATION_EVALUATOR_ASSIGNED') {
                    isLogFound = true
                    logId = activitylog['_id']
                }

            })
            return logId
        },
        openUploadDocumentsPopup() {
            this.isFileUplading = false
            this.documents = []
            this.showUploadDocsPopup = true
        },
        hideUploadDocumentsPopup() {
            this.documents = []
            this.showUploadDocsPopup = false
            this.isFileUplading = false
        },
        checkFileUploading() {
            let uploading = false
            let resultDocs = _.filter(this.documents, (docItem) => {
                return this.checkProperty(docItem, 'fileUploading') && docItem.fileUploading
            })
            if (this.checkProperty(resultDocs, 'length') > 0) {
                if (!uploading) {
                    uploading = true
                }
            }
            this.isFileUplading = uploading
        },
        submitDocuments(action, isFromTimeline = fasle) {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.isDocumentsGenerating = true
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "evaluationTemplate": this.selectedTemplate,
                        "task": "add",
                        "generatedDocuments": this.documents,
                        "comments": this.comments,
                        "docAction": "confirm"
                    }
                    if (this.checkProperty(this.activityLog, '_id')) {
                        Object.assign(postData, { logId: this.checkProperty(this.activityLog, '_id') });
                    }

                    this.$store.dispatch("assignEvaluationTemplate", postData)
                        .then((response) => {
                            this.isDocumentsGenerating = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                                this.hideUploadDocumentsPopup()
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')
                            }
                        })
                        .catch((error) => {
                            this.isDocumentsGenerating = false
                            this.showToster({ message: error, isError: true });
                        })
                }
            })

        },

        onTemplateFileSelect(selectedFile) {
            this.selectedTemplate = selectedFile
            setTimeout(() => {
                this.showDocumentsConfirmPopup = true
            }, 100)

        },

        hideDocumentsConfirmPopup() {
            setTimeout(() => {
                this.showDocumentsConfirmPopup = false
            }, 100)
            this.showDocumentsConfirmPopup = false
        },

    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>