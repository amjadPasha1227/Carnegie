<template>
    <div class="wrapper-item" >
        <div class="wrapper-item" v-if="!isActivityCompleted(evaluation, 'EVALUATION_REVIEWER_ASSIGNED')">
            <div class="section-year">
                <p> </p>
                <p></p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Review Team </div>
                    <div class="submit_detailes">
                        <h4>Documents are prepared by either Offshore or Onsite team.</h4>
                        <div class="d-flex">
                            <simpleSelect :multiple="false" :wrapclass="'req_status'" :optionslist="usersList"
                                :display="true" :place-holder="'Assign Reviewer'" :searchable="false" :required="true"
                                :close-on-select="true" :clear-on-select="false" class="mb-0 ass-eval"
                                v-model="selectedUser" :fieldName="'reviewer'" :cid="'reviewer'" :vvas="'Reviewer'" />
                            <button class="primary_btn" @click="assignEvaluationUser">Assign
                                <span class="loader" v-if="loading"><img src="@/assets/images/loader.gif"></span></button>
                        </div>
                        <!-- <button class="primary_btn edit_btn mt-1">Edit Evaluator</button> -->
                    </div>
                </div>
            </section>
        </div>
        <div class="wrapper-item" v-if="isActivityCompleted(evaluation, 'EVALUATION_REVIEWER_ASSIGNED')">
            <div class="section-year">
                <p> {{ checkProperty(getActivityLog(evaluation, 'EVALUATION_REVIEWER_ASSIGNED'), 'updatedOn') | formatTime }} </p>
                <p> {{ checkProperty(getActivityLog(evaluation, 'EVALUATION_REVIEWER_ASSIGNED'), 'updatedOn') | formatDate }} </p>
            </div>
            <section class="timeline-item">
                <div class="item">
                    <span class="status_dot status_review"></span>
                    <div class="status-name review_bg">Reviewer Assigned</div>
                    <div class="submit_detailes" >
                        <h4
                            v-if="checkProperty(getActivityLog(evaluation, 'EVALUATION_REVIEWER_ASSIGNED'), 'updatedByName')">
                            Assigned by <b>{{ checkProperty(getActivityLog(evaluation, 'EVALUATION_REVIEWER_ASSIGNED'),
                                'updatedByName') }}</b></h4>
                        <h4 class="mb-0" v-if="checkProperty(evaluation,'assignedToReviewerDetails','name')"><b>{{checkProperty(evaluation,'assignedToReviewerDetails','name')}}</b>  has been assigned as Reviewer</h4>
                        
                    </div>
                </div>
            </section>
        </div>
    </div>
</template>


<script>
import simpleSelect from '@/views/forms/simpleSelect.vue';

export default {
    props: {
        evaluation: Object,
        roleIds: {
            type: Array,
            default: [],
        },
        actionCode:'',
    },
    components: {
        simpleSelect,
    },
    data: () => ({
        usersList: [],
        selectedUser: null,
        loading: false,
    }),
    mounted() {
        this.getUsers()
    },
    methods: {
        getUsers() {
            let postData =
            {
                "matcher": {
                    "title": '',
                    "searchString": "",
                    "statusList": [],
                    "createdByIds": [],
                    "createdDateRange": [],
                    "roleIds": this.roleIds,
                    "statusIds": [],
                    "typeIds": [],
                    "departmentIds": []
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": true,// if Masterdata required
                "page": 1,
                "perpage": 500,
            }
            this.$store.dispatch("getUsersList", postData)
                .then((res) => {
                    this.usersList = res.data.result.list
                })
                .catch((error) => {
                })
        },
        assignEvaluationUser() {
            //EVALUATION_PROFESSER_ASSIGNED
            this.$validator.validateAll().then((result) => {
                if (result) {
                    this.loading = true
                    let postData = {
                        "evaluationId": this.evaluation._id,
                        "userId": this.selectedUser._id
                    }
                    this.$store.dispatch("assignUser", postData)
                        .then((response) => {
                            this.loading = false
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                                this.showToster({ message: response.error.result, isError: true });
                            } else {
                              //  this.selectedUser = null
                                this.showToster({ message: response.message, isError: false });
                                this.$emit('updateDetails')

                            }
                        })
                        .catch((error) => {
                            this.loading = false
                            this.showToster({ message: error, isError: true });
                        })


                }
            })
        }

    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>