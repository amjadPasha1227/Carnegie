<template>
    <div class="guest_req_sec whfs_page p-0">
        <div class="header">
            <div class="container">
                <div class="header-one">
                    <div class="left">
                        <a href="index.html"><img src="@/assets/images/logo.png" alt="logo"></a>
                    </div>
                    <div class="right">
                        <ul>
                            <li>
                                <a v-if="false" href="https://carnegieevaluations.com" class="click_btn free_btn"><img
                                        src="@/assets/images/speedometer.svg"> Request an Evaluation</a>
                            </li>
                            <!-- <li>
							<a href="https://carnegieevaluations.com/contact-us/" class="click_btn call_btn"><img src="@/assets/images/call.svg"> Contact Us</a> 
						</li>
						<li>
							<a href="https://carnegieevaluations.com/app" class="click_btn login_btn"><img src="@/assets/images/user_login.svg">Login</a> 
						</li> -->
                            <li>
                                <a><img src="@/assets/images/wwhealth.png" /></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <nav class="navbar sticky-top navbar-expand-lg">
                <div class="hamburger">
                    <a href="index.html"><img src="@/assets/images/logo.png" alt="logo"></a>
                    <span class="">
                        <div class="line1"></div>
                        <div class="line2"></div>
                        <div class="line3"></div>
                    </span>
                </div>
            </nav>
        </div>
        <div class="container">
            <!-- <EvaluationRequest :isGuestRequest="true"/> -->

            <div>
                <div class="guest_req_cnt">
                    <h4 class="mb-0">Exclusively for WorldWide HealthStaff Solutions</h4>
                    <h3>REQUEST AN EVALUATION</h3>
                    <h4>APPLYING FOR ACADEMIC EVALUATION - NURSING POSITION($85)</h4>

                    <div class="guest_form form-wizard ">
                        <!-- <div class="wizard-header">
                    <ul class="nav nav-tabs form-wizard-steps">
                        <template v-for="(item, index) in tabsList">
                            <li :key="index" :class="{
                                'activated': (index < checkActiveTab),
                                'active': (index == checkActiveTab)
                            }" @click="">
                                <span>{{ index + 1 }}</span>{{ item.name }}
                            </li>
                        </template>
                    </ul>
                </div> -->

                        <div class="wizard-fieldset show">
                            <form :data-vv-scope="'evaluationForm'">
                                <div class="wizard_cnt">

                                    <p>1. While submitting a request, please upload all your academic documents - award
                                        certificate/diploma & transcripts of all years of study. If the documents are in a
                                        foreign language, please submit certified English translations along with the
                                        originals.</p>
                                    <p>2. After reviewing the documents submitted, if your foreign education is found
                                        equivalent to at least a year of university level study, our evaluator will provide
                                        you with an 'Academic Evaluation'. If your foreign education is found equivalent
                                        only to a High School Diploma (Grade XII) or less, then you will receive an
                                        'Academics Analysis Report'. The ‘Academic Evaluation’ and the ‘Academic Analysis
                                        Report’ will be based on AACRAO Edge, the Electronic Database for Global Education,
                                        which is a recommended U.S resource referred to while evaluating foreign educational
                                        credentials.</p>
                                    <p>3. When you submit a request successfully, you will receive an email with a unique
                                        reference number along with the list of documents you uploaded. If you feel
                                        that any of your documents didn’t upload, please reply to that email with the
                                        missing document/s. Kindly check your spam folder as well for the email.</p>
                                    <p>4. Please remit the payment for $85 referring to the last 7-digit reference number
                                        (Invoice Number) you received at the secured link provided in the email and you will
                                        receive a ‘payment receipt’. Please email us the ‘payment receipt’ and we will
                                        proceed with the ‘Academic evaluation’ or ‘Academic Analysis Report’, which will be
                                        delivered within 4 business days. If there is any clarification required regarding
                                        your academics, a team member will reach out to you.</p>

                                    <p>Enter exactly as you want it on the final evaluation (Proof Spelling)</p>
                                    <p class="des text-danger mb-0">Please use only Alphanumeric characters (No special characters like slash, greater\less than,
                                etc)</p>
                                    <div class="form_info pt-4">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <simpleInput :fieldName="'beneficiaryFName'" :cid="'beneficiaryInfo'"
                                                    :label="'First Name'" :placeHolder="'First Name'" :vvas="'First Name'"
                                                    :display="true" :required="true"
                                                    v-model="evaluationInfo.beneficiaryInformation.firstName"
                                                    :allowAlphNum="true" :formscope="'evaluationForm'" />
                                            </div>
                                            <div class="col-md-6">
                                                <simpleInput :fieldName="'beneficiaryLName'" :cid="'beneficiaryInfo'"
                                                    :label="'Last Name'" :placeHolder="'Last Name'" :vvas="'Last Name'"
                                                    :display="true" :required="true"
                                                    v-model="evaluationInfo.beneficiaryInformation.lastName"
                                                    :allowAlphNum="true" :formscope="'evaluationForm'" />
                                            </div>

                                            <!-- <div class="col-md-6" v-if="currentTabIndex == 1">
                                        <simpleInput :fieldName="'beneficiaryFirm'" :cid="'beneficiaryInfo'"
                                            :label="'Beneficiary\'s Firm'" :placeHolder="'Beneficiary\'s Firm'"
                                            :vvas="'Beneficiary\'s Firm'" :display="true" :required="false"
                                            v-model="evaluationInfo.beneficiaryInformation.firm" :allowAlphNum="true"
                                            :formscope="'evaluationForm' + currentTabIndex" />
                                    </div> -->
                                            <!-- <div class="col-md-6">
                                        <simpleInput :fieldName="'beneficiaryJobTitle'" :cid="'beneficiaryInfo'"
                                            :label="'Job Title'" :placeHolder="'Job Title'" :vvas="'Job Title'"
                                            :display="true" :required="false"
                                            v-model="evaluationInfo.beneficiaryInformation.jobTitle" :allowAlphNum="true"
                                            :formscope="'evaluationForm' + currentTabIndex" />
                                    </div> -->
                                            <div class="col-md-6">
                                                <simpleInput :fieldName="'beneficiaryDegree'" :cid="'beneficiaryInfo'"
                                                    :label="'Your Degree'" :placeHolder="'Your Degree'"
                                                    :vvas="'Your Degree'" :display="true" :required="false"
                                                    v-model="evaluationInfo.beneficiaryInformation.degree"
                                                    :allowAlphNum="true" :formscope="'evaluationForm'" />
                                            </div>
                                            <div class="col-md-6">
                                                <simpleInput :fieldName="'email'" :cid="'email'" :label="'Email'"
                                                    :placeHolder="'Email'" :vvas="'Email'" :display="true" :required="true"
                                                    v-model="evaluationInfo.email" :emailFormat="true" :datatype="'email'"
                                                    :formscope="'evaluationForm'" />

                                            </div>
                                            <!-- <div class="col-md-6">
                                        <simpleInput :fieldName="'usEquivalentDegree'" :cid="'beneficiaryInfo'"
                                            :label="'Desired US equivalent degree'"
                                            :placeHolder="'Desired US equivalent degree'"
                                            :vvas="'Desired US equivalent degree'" :display="true" :required="false"
                                            v-model="evaluationInfo.beneficiaryInformation.usEquivalentDegree"
                                            :allowAlphNum="true" :formscope="'evaluationForm' + currentTabIndex" />
                                    </div> -->
                                            <!-- <div class="col-md-6">
                                        <simpleInput :fieldName="'socCode'" :cid="'beneficiaryInfo'"
                                            :label="'Occupation SOC code'" :placeHolder="'Occupation SOC code'"
                                            :vvas="'Occupation SOC code'" :display="true" :required="false"
                                            v-model="evaluationInfo.beneficiaryInformation.socCode"
                                            :formscope="'evaluationForm' + currentTabIndex" :wrapclass="'m-0'" />
                                    </div> -->
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form_group m-0">
                                                            <label class="form_label">Gender*</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <radioInput wrapclass="m-0" :elementId="'male'" :label="'Male'"
                                                            :fieldName="'gender'"
                                                            v-model="evaluationInfo.beneficiaryInformation.gender"
                                                            :fieldValue="'Male'" />
                                                    </div>
                                                    <div class="col-md-6">
                                                        <radioInput wrapclass="m-0" :elementId="'female'" :label="'Female'"
                                                            :fieldName="'gender'"
                                                            v-model="evaluationInfo.beneficiaryInformation.gender"
                                                            :fieldValue="'Female'" />
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form_group m-0">
                                                            <input type="hidden" class="form-control"
                                                                v-validate="'required'"
                                                                v-model="evaluationInfo.beneficiaryInformation.gender"
                                                                data-vv-as="Gender" :name="'genderInput'"
                                                                :formscope="'evaluationForm'" />
                                                            <span
                                                                v-show="errors.has(('evaluationForm') + '.' + 'genderInput')"
                                                                class="form-error">{{
                                                                    errors.first(('evaluationForm') + '.' +
                                                                        'genderInput') }}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                        <simpleInput :fieldName="'promocode'" :cid="'beneficiaryInfo'"
                                            :label="'Promo Code'"
                                            :placeHolder="'Promo Code'"
                                            :vvas="'Promo Code'" :display="true" :required="false"
                                            v-model="evaluationInfo.promocode"
                                            :allowAlphNum="true" :formscope="'evaluationForm' + currentTabIndex" />
                                    </div>

                                            <!-- <div class="col-md-12">

                                        <p class="des note">
                                            <a href="https://carnegieevaluations.com/pricing/" target="_blank">See
                                                PRICING</a> page for turnaround - additional charges will
                                            apply
                                        </p>
                                    </div> -->

                                            <div class="col-md-12">
                                                <div class="form_group mt20">
                                                    <label class="form_label">{{ "Special Notes" }}</label>
                                                    <textArea class="" :tplkey="'specialNotes'" fieldName="specialNotes"
                                                        placeHolder="Write anything else our evaluators should know"
                                                        v-model="evaluationInfo.specialNotes"></textArea>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    
                                </div>
                            </form>

                        </div>

                        <div class="wizard-fieldset evalution-fieldset show">
                            <form :data-vv-scope="'evaluationForm'">
                                <div class="wizard_cnt evalution_cnt">
                                    <p class="des">All requests will be confirmed based on the documents provided and
                                        availability of the professor</p>
                                    <p class="des">Check the checkbox with the evaluation(s) you would like to order.<br />
                                        You will be prompted to upload the files associated with that report on the next
                                        page.</p>
                                    <p class="des">Please provide translated copies in English, if the documents are in
                                        foreign language.</p>

                                    <!-- <div class="info_msg alert alert-warning">
                                        <p>Upload multiple files as necessary.</p>
                                    </div> -->
                                    <span class="info_text info_text_v2 mb-2">
                                        <img src="@/assets/images/info_icon.png">
                                        <p>Upload multiple files as necessary.</p> 
                                    </span>
                                    <p class="des text-danger">Please use only Alphanumeric characters (No special characters like slash, greater\less than,
                                etc)</p>
                                    <template v-for="(item, index) in evaluationTypes">
                                        <div class="evalution_list">
                                            <div v-if="false" class="evalution_heading">
                                                <span>Combinations of these evaluations are available - Please check all
                                                    that
                                                    apply.</span>
                                            </div>
                                            <div v-if="false" class="evalution_heading">
                                                <span>Additional customization available for H1B cases</span>
                                            </div>
                                            <div v-if="false" class="evalution_heading">
                                                <span>You will be contacted by our staff via email with specific requests
                                                    for
                                                    supporting documents for any of the below evaluations</span>
                                            </div>
                                            <div class="accordion">
                                                <div class="accordion_item"
                                                    v-bind:class="{ 'expanded': checkProperty(item, 'isSelected') }"
                                                    :key="index">
                                                    <h2 class="accordion_header">
                                                        <!-- <input @input="updatedSelection(index)" class="form-check-input"
                                                            type="checkbox" v-model="evaluationTypes[index].isSelected"
                                                            v-b-toggle="'collapse-' + index"> -->
                                                        <span>{{ item.name }}</span>
                                                    </h2>
                                                    <!-- <b-collapse  class="collapse show" :id="'collapse-' + index"> -->
                                                    <div class="accordion_body">
                                                        <div class="input-group" :key="index + '' + index1"
                                                            v-for="(docItem, index1) in evaluationTypes[index].subTypes">
                                                            <span class="input-group-text">{{ docItem.name }}</span>

                                                            <fileUpload :wrapclass="'no_doc_name'"
                                                                :tplkey="'document' + index + '' + index1"
                                                                v-model="evaluationTypes[index].subTypes[index1].documents"
                                                                :tplsection="'document' + index + '' + index1" label=""
                                                                vvas="Document"
                                                                :fieldName="'document' + index + '' + index1"
                                                                :cid="'document' + index + '' + index1" :multiple="true"
                                                                :deleteDocPermenantly="true" :isGuestUpload="true"
                                                                @input="updateDocumets($event, index, index1)"
                                                                @uploadingFile="checkFileUploading($event)">
                                                            </fileUpload>
                                                        </div>
                                                    </div>
                                                    <!-- </b-collapse> -->
                                                </div>
                                            </div>
                                        </div>
                                    </template>
                                    <p class="des mt-4">For files that could not be uploaded, please send them to <a
                                            href="mailto:eval@carnegieevaluations.com" 
                                            target="_blank">eval@carnegieevaluations.com</a>,
                                        with
                                        the Request ID in the Subject line of your email. </p>
                                </div>
                            </form>
                        </div>
                        <div class="wizard-fieldset show">
                            <div class="wizard_actions">

                                <!-- <div v-if="checkActiveTab != 2" class="wizard_actions_innr">

                                    <a v-if="checkActiveTab == 0" class="form-cancel"
                                        @click="hasHistory ? $router.go(-1) : cancelRequest">Cancel</a>
                                    <a v-if="checkActiveTab > 0" @click="moveToPreviousTab"
                                        class="form-wizard-previous-btn primary_btn">Previous</a>
                                    <a @click="submitForm" class="form-wizard-next-btn primary_btn">Next</a>
                                </div> -->

                                <div v-if="checkActiveTab == 2" class="wizard_actions_innr evalution_actions_innr">
                                    <a></a>

                                    <button class="primary_btn" @click="submitForm">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>



        </div>
        <footer class="footer">
            <div class="container container-xl">
                <div class="row">
                    <div class="col-md-4 col-md-3">
                        <div class="footer_logo">
                            <a href="https://carnegieevaluations.com"><img
                                    src="https://carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/footer_logo.png"></a>
                            <p>Carnegie Evaluations is a leader in verification, authentication, and evaluation of
                                international experience and education. We deliver fast and accurate results by retaining
                                professors at universities across the U.S. who have industry experience from a wide range of
                                specialty occupations.</p>
                                <img width="200" src="https://carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/taicep_logo2.png" alt="logo">
                        </div>
                    </div>
                    <div class="col-md-8 col-md-8 padl-50">
                        <div class="row">
                            <div class="col-md-6 col-md-6">
                                <div class="widget">
                                    <h4>Say Hello</h4>
                                    <p>Carnegie Evaluations LLC, 1200 US Highway 22E, Suite 2000, Bridgewater, NJ 08807</p>
                                </div>
                            </div>
                            <div class="col-md-6 col-md-6">
                                <div class="widget">
                                    <h4>Email</h4>
                                    <p><a href="mailto:eval@carnegieevaluations.com">eval@carnegieevaluations.com</a></p>
                                </div>
                            </div>
                            <div class="col-md-6 col-md-6 bodtop">
                                <div class="widget">
                                    <h4>Call Us</h4>
                                    <p>(848) 300 0099</p>
                                </div>
                            </div>
                            <div class="col-md-6 col-md-6 bodtop">
                                <div class="widget">
                                    <h4>Socials</h4>
                                    <div class="social-icons">
                                        <a href="https://www.facebook.com/people/Carnegie-Evaluations/100067473232721/"
                                            target="_blank"><img
                                                src="https://carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/facebook.svg"></a>
                                        <a href="https://www.instagram.com/explore/tags/carnegieevaluations/"
                                            target="_blank"><img
                                                src="https://carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/insta.svg"></a>
                                        <a href="https://www.linkedin.com/in/carnegie-evaluations/" target="_blank"><img
                                                src="https://carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/linkdin.svg"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-md-12 bodtop">
                                <div class="quick-links">
                                    <!-- <ul>
<li><a href="https://carnegieevaluations.com/services/" title="Services">Services</a></li>
<li><a href="https://carnegieevaluations.com/our-strengths/" title="Our Strengths">Our Strengths</a></li>
<li><a href="https://carnegieevaluations.com/specialties/" title="Specialties">Specialties</a></li>
<li><a href="https://carnegieevaluations.com/pricing/" title="Pricing">Pricing</a></li>
<li><a href="https://carnegieevaluations.com/contact-us/" title="Contact us">Contact us</a></li>
</ul> -->
                                    <ul>
                                        <li><a href="https://carnegieevaluations.com/testimonials/"
                                                title="Testimonials">Testimonials</a></li>
                                        <li><a href="https://carnegieevaluations.com/document-checklist/"
                                                title="Document Checklist">Document Checklist</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="row d-none">
                            <div class="col-md-7 col-md-7">
                                <div class="widget">
                                    <h4>Say Hello</h4>
                                    <ul>
                                        <li> Carnegie Evaluations LLC, 1200 US Highway 22E, Suite 2000, Bridgewater, NJ
                                            08807</li>
                                    </ul>
                                </div>
                                <div class="widget widgett">
                                    <h4>Call Us</h4>
                                    <ul>
                                        <li>(848) 300 0099</li>
                                    </ul>
                                </div>
                                <div class="row">
                                    <!-- <div class="col-md-6 col-md-6">
<div class="widget">
<ul class="quick-links">
<li><a href="https://carnegieevaluations.com/services/" title="Services">Services</a></li>
<li><a href="https://carnegieevaluations.com/our-strengths/" title="Our Strengths">Our Strengths</a></li>
<li><a href="https://carnegieevaluations.com/specialties/" title="Specialties">Specialties</a></li>
<li><a href="https://carnegieevaluations.com/pricing/" title="Pricing">Pricing</a></li>
<li><a href="https://carnegieevaluations.com/contact-us/" title="Contact us">Contact us</a></li>
</ul>
</div>
</div> -->
                                    <div class="col-md-6 col-md-6">
                                        <div class="widget">
                                            <ul class="quick-links">
                                                <li><a href="https://carnegieevaluations.com/testimonials/"
                                                        title="Testimonials">Testimonials</a></li>
                                                <li><a href="https://carnegieevaluations.com/document-checklist/"
                                                        title="Document Checklist">Document Checklist</a></li>
                                            </ul>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5 col-md-5">
                                <div class="widget">
                                    <h4>Email</h4>
                                    <ul>
                                        <li><a href="mailto:eval@carnegieevaluations.com">eval@carnegieevaluations.com</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="widget widgett">
                                    <h4>Socials</h4>
                                    <div class="social-icons">
                                        <a href="https://www.facebook.com/people/Carnegie-Evaluations/100067473232721/"
                                            target="_blank">
                                            <figure><img
                                                    src="https://carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/facebook.svg">
                                            </figure>
                                        </a>
                                        <a href="https://www.instagram.com/explore/tags/carnegieevaluations/"
                                            target="_blank">
                                            <figure><img
                                                    src="https://carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/insta.svg">
                                            </figure>
                                        </a>
                                        <a href="https://www.linkedin.com/in/carnegie-evaluations/" target="_blank">
                                            <figure><img
                                                    src="https://carnegieevaluations.com/wp-content/themes/carnegieevaluations/images/linkdin.svg">
                                            </figure>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyrights">
                <div class="container">
                    <div class="row">
                        <div class="text-center">Copyright © 2023 Carnegie Evaluations. All rights reserved.</div>
                    </div>
                </div>
            </div>
        </footer>

        <!-- Success Modal -->
        <!-- <b-modal id="success_model" dialog-class="success_model" centered hide-header hide-footer no-close-on-backdrop>
            <template>
                <figure>
                    <img src="@/assets/images/success_mdl_img.png" />
                </figure>
                <h5>Your Request has been Received!</h5>
                <p>You will get notification shortly for selecting your professor</p>
                <a class="primary_btn sm" @click="$bvModal.hide('success_model')">Ok!</a>
            </template>
        </b-modal> -->
       
        <b-modal v-model="showCreateSuccessalt" modal-class="custom-modal" id="success_modelalt" dialog-class="success_model submit_modal"
            centered hide-header hide-footer no-close-on-backdrop> <template>
                <figure>
                    <img src="@/assets/images/success_mdl_img.png" />
                </figure>
                <h5>Your Request has been Received!</h5>
                <div class="des text-danger mb-0" v-if="promoerror!=null">{{promoerror}}</div>
                <p>Your reference number is: {{ requestId ? requestId : '' }}</p>
                <p><strong>Thank you for submitting your request. We will validate the Promo Code with WWHSS and get back to you at the earliest.</strong></p>
                <p>You can email us at <a href="mailto:eval@carnegieevaluations.com">eval@carnegieevaluations.com</a></p>
                <p>Please email us with any other relevant documents that you were not able to submit through this system.
                    We appreciate your business.</p>

                <div class="d-flex justify-content-between w-full mt-4">
                    <div class="d-flex">
                        <a class="primary_btn marr10 edit_btn" @click="createEvaluationSuccess(1)">Return to WorldWide HealthStaff
                            Solutions</a>
        
                        <a class="primary_btn edit_btn" @click="createEvaluationSuccess(2)">Go to Carnegie Evaluation's Full
                            Website</a>
                    </div>
                    <div class="d-flex">
                        <a class="primary_btn marr10" @click="createEvaluationSuccess(3)">Request Another Evaluation</a>

                    </div>
                </div>

            </template>
        </b-modal>

        <!-- Success Modal -->
        <b-modal v-model="showCreateSuccess" modal-class="custom-modal" id="success_model" dialog-class="success_model submit_modal"
            centered hide-header hide-footer no-close-on-backdrop>
            <template>
                 
                    <figure>
                        <img src="@/assets/images/success_mdl_img.png" />
                    </figure>
                    <h5>Request Submitted! Your Request ID is {{ requestId ? requestId : '' }}</h5> 
                                <span class="des text-danger" style="margin-bottom:10px" v-if="promoerror!=null">{{promoerror}} <strong>Kindly proceed to PAYMENT.</strong></span>  

                
                <p>PLEASE MAKE THE PAYMENT OF $85 REFERRING TO THIS INVOICE NUMBER: {{ requestId ? requestId : '' }} AT THE
                    SECURED PAYMENT LINK VIA
                    CREDIT CARD
                    <a href="https://carnegieevaluations.com/termsconditionsorder/"
                        target="_blank">https://carnegieevaluations.com/termsconditionsorder</a> and EMAIL US THE
                    PAYMENT RECEIPT at <a href="mailto:eval@camegieevaluations.com">eval@camegieevaluations.com</a>
                    
                </p>
                <p>If you happen to get any of the following error codes while remitting the payment – please correct as
                    noted below:
                </p>
                <p>U83 - Authorizer Decline - The transaction was declined by the authorizer. To determine the reason for
                    the declination, please contact the number on the back of the card.</p>
                <p>U20- Invalid Credit Card Number- The provided credit card number is invalid. Re-enter it and try again.
                </p>
                <p>U19- Invalid Transaction - The provided Bank Routing Number is invalid. Ensure you entered the correct
                    routing number and try again.</p>
                <p>We will PROCEED with the evaluation ONLY UPON receiving the payment receipt via email – Please use
                    Invoice Number in the subject line of the email.</p>

                <p>Upon receiving the payment receipt the evaluation will be delivered within 4 business days. If there are
                    any questions, a team member will reach out to you.</p>

                <p>Please email us with any other relevant documents that you were not able to submit through this system
                    along with the payment receipt. We
                    appreciate your business. Your invoice number is:{{ requestId ? requestId : '' }} (note: if there is NO
                    Number here something
                    went wrong) When contacting us, please
                    use this invoice number:{{ requestId ? requestId : '' }}</p>
                <p>You can email us at <a href="mailto:eval@carnegieevaluations.com">eval@carnegieevaluations.com</a></p>
                <p>Please email us with any other relevant documents that you were not able to submit through this system.
                    We appreciate your business.</p>

                <div class="d-flex justify-content-between w-full mt-4">
                    <div class="d-flex">
                        <a class="primary_btn marr10 edit_btn" @click="createEvaluationSuccess(1)">Return to WorldWide HealthStaff
                            Solutions</a>
        
                        <a class="primary_btn edit_btn" @click="createEvaluationSuccess(2)">Go to Carnegie Evaluation's Full
                            Website</a>
                    </div>
                    <div class="d-flex">
                        <a class="primary_btn marr10" @click="createEvaluationSuccess(3)">Request Another Evaluation</a>

                        <a class="primary_btn" href="https://carnegieevaluations.com/termsconditionsorder/"
                            target="_blank">Continue to Payment</a>
                    </div>
                </div>

                
                
            </template>
        </b-modal>
    </div>
</template>



<script>
// @ is an alias to /src

import JQuery from "jquery";
import simpleInput from "@/views/forms/simpleInput.vue";
import fileUpload from "@/views/forms/fileupload.vue";
import radioInput from "@/views/forms/radioInput.vue";
import phoneInput from "@/views/forms/phonenumber.vue";
import textArea from "@/views/forms/textarea.vue";
export default {
    watch: {
        evaluationInfo: function (value) {

        }
    },
    name: 'evaluation-request',
    props: {
        showHeaderTitle: {
            type: Boolean,
            default: true,
        },
        isGuestRequest: {
            type: Boolean,
            default: false,
        }
    },
    components: {
        simpleInput,
        fileUpload,
        radioInput,
        phoneInput,
        textArea,
    },

    mounted() {

        this.getEvaluationTypes()
        this.getPriorities()
        if (this.getUserRoleId && this.getUserRoleId == 15 && this.checkProperty(this.getUserData, 'details', 'companyName')) {
            this.evaluationInfo.firm = this.checkProperty(this.getUserData, 'details', 'companyName')
        }

    },
    methods: {
        gotoPage(path = "/") {
            this.$router.push(path);
        },
        submitForm() {
            // if (this.currentTabIndex < 2) {
            //     let index = this.currentTabIndex
            //     this.currentTabIndex = -1
            //     this.currentTabIndex = index + 1
            // }
            this.promoerror = null;
            this.$validator.validateAll("evaluationForm").then((result) => {
                if (result) {
                    const $ = JQuery;
                    $("html, body").animate({ scrollTop: 0 }, 100);
                    let docsConfig = []
                    let isRequestValid = false
                    let isEvaluationSelected = false
                    _.forEach(this.evaluationTypes, (item, index) => {
                        if (this.checkProperty(item, 'isSelected')) {
                            isEvaluationSelected = true
                            isRequestValid = true
                            let evaluation = {
                                "evaluationTypeId": null,
                                "evaluationTypeName": "",
                                "shortName": "",
                                "subTypes": []
                            }
                            evaluation['evaluationTypeId'] = item.id
                            evaluation['evaluationTypeName'] = item.name
                            evaluation['shortName'] = item.shortName
                            evaluation['price'] = item.price
                            evaluation['subTypes'] = []
                            let isValidConfig = true
                            if (this.checkProperty(item, 'subTypes', 'length') > 0) {
                                _.forEach(item.subTypes, (subItem) => {
                                    let subTypeItem = {
                                        "subTypeId": null,
                                        "subTypeName": "",
                                        "documents": []
                                    }

                                    let resultDocs = _.filter(subItem.documents, (docItem) => {
                                        return this.checkProperty(docItem, 'path', 'length') > 0
                                    })

                                    if (subItem.id !== 70 && subItem.id !== 72) {
                                        if (this.checkProperty(resultDocs, 'length') > 0) {
                                            isRequestValid = true
                                            isValidConfig = true
                                            subTypeItem['subTypeId'] = subItem.id
                                            subTypeItem['subTypeName'] = subItem.name
                                            subTypeItem['documents'] = subItem.documents
                                            evaluation['subTypes'].push(subTypeItem)
                                        }
                                    }
                                })
                            } else {
                                isValidConfig = true
                                isRequestValid = true
                            }

                            if (isValidConfig) {
                                docsConfig.push(evaluation)
                            }
                        }
                    });
                    if (isEvaluationSelected) {
                        if (isRequestValid) {
                            this.evaluationInfo['today'] = new Date()
                            this.evaluationInfo['docsConfig'] = docsConfig
                            this.evaluationInfo['quotaPrice'] = this.getQuoteCalucatedPrice
                            this.evaluationInfo['authRequired'] = false

                            this.evaluationInfo.priorityId = 1
                            //  console.log(JSON.stringify(resultDocs))
                            this.$store
                                .dispatch("createEvaluation", this.evaluationInfo)
                                .then((response) => {
                                    if (response.error) {
                                        this.showToster({ message: response.error.message, isError: true });
                                    } else {
                                        this.successMsg = response.message
                                        this.requestId = response.requestId
                                        if(response.nopayment){
                                            this.showCreateSuccessalt = true
                                        }else{

                                          this.showCreateSuccess = true

                                        }
                                        if(response.promoerror!=null){
                                            this.promoerror = response.promoerror;
                                        }
                                    }
                                })
                                .catch((error) => {
                                    this.showToster({ message: error, isError: true });
                                    this.loading = false;
                                });
                        } else {
                            this.showToster({ message: "Please upload evaluation documents", isError: true });
                        }
                    } else {
                        this.showToster({ message: "Please select at least one evaluation", isError: true });
                    }

                } else {
                    this.validateandScroll()
                }
            })
        },
        moveToPreviousTab() {
            if (this.currentTabIndex > 0) {
                const $ = JQuery;
                $("html, body").animate({ scrollTop: 0 }, 100);
                this.currentTabIndex = this.currentTabIndex - 1
            }
        },

        getEvaluationTypes() {
            this.$store.dispatch("getMasterData", 'evaluation_types')
                .then((res) => {
                    // this.evaluationTypes = this.sortedArray(res)
                    this.evaluationTypes = _.filter(res, (item) => {
                        return ([1].indexOf(item.id) > -1)
                    });

                    //   console.log(JSON.stringify(res))
                    //    isSelected
                    this.$store.dispatch("getMasterData", 'evaluation_documents_types')
                        .then((response) => {
                            let evaluationDocuments = [...response]
                            //  console.log(JSON.stringify(evaluationDocuments))
                            _.forEach(this.evaluationTypes, (item, index) => {
                                let evaluation = { ...item }
                                let evaDocs = []
                                _.forEach(evaluationDocuments, (docItem, indx) => {
                                    if (docItem.id != 28) {
                                        if (docItem.typeIds.findIndex(v => (v == item.id)) > -1) {
                                            docItem['timestamp'] = index + '#' + new Date().getTime()
                                            // docItem['fileUploading'] = false
                                            evaDocs.push({ ...docItem })
                                        }
                                    }
                                });
                                // let evaDocs =_.filter(evaluationDocuments, (docItem) => {
                                //     return docItem.typeIds.findIndex(v => v == item.id) > -1
                                // })

                                if (this.checkProperty(evaDocs, 'length') > 0) {
                                    _.forEach(evaDocs, (document) => {
                                        document['documents'] = null
                                        //document['documents'].push({ url: "", name: "", })
                                    })
                                }

                                evaluation['subTypes'] = [...evaDocs]
                                evaluation['isSelected'] = false
                                this.evaluationTypes.splice(index, 1, evaluation)
                                // this.evaluationTypes[index] = { ...evaluation }
                            });

                            this.updatedSelection(0)
                        })
                })
        },

        updateDocumets(value, index, index1) {
            let evaluationItem = { ...this.evaluationTypes[index] };
            evaluationItem.subTypes[index1].documents = value
            // this.evaluationTypes[index] = evaluationItem
            this.evaluationTypes.splice(index, 1, evaluationItem)
        },
        updatePhoneCountryCode(data) {

            this.evaluationInfo.phoneCountryCode = data;

            console.log(JSON.stringify(this.evaluationInfo.phoneCountryCode))

        },
        getPriorities() {
            this.$store.dispatch("getMasterData", 'evaluation_priority')
                .then((res) => {
                    this.priorityList = res
                })
        },
        createEvaluationSuccess(type) {
            this.showCreateSuccess = false
             this.showCreateSuccessalt = false
            // this.currentTabIndex = 2
            this.evaluationInfo = {
                wwhs: true,
                name: 'WWHS',
                firstName: '',
                lastName: '',
                middleName: '',
                phone: '',
                email: '',
                alternateEmail: '',
                promocode:'',
                firm: '',
                phoneCountryCode: {
                    countryCode: "US",
                    countryCallingCode: "1"
                },
                beneficiaryInformation: {
                    firstName: '',
                    middleName: '',
                    lastName: '',
                    jobTitle: '',
                    gender: '',
                    degree: '',
                    usEquivalentDegree: '',
                    socCode: '',
                    firm: '',

                },
                docsConfig: [],
                priorityRush: null,
                priorityId: null,
                dueDate: null,
                howDoYouHere: '',
                proceedImmediately: null,
                firm: '',
                specialNotes: '',
            }

            if (type == 1) {
                window.location.href = "https://healthstaff.org/payment"
            } else if (type == 2) {
                window.location.href = "https://carnegieevaluations.com/"
            }
            else {

            }

            //  this.$emit('input')

        },
        updatedSelection(index) {
            let evaluationItem = this.evaluationTypes[index]
            if (this.checkProperty(evaluationItem, 'isSelected')) {
                _.forEach(evaluationItem.subTypes, (subItem, subIndex) => {
                    let subTypeItem = subItem
                    subTypeItem.documents = null
                    this.evaluationTypes[index].subTypes.splice(subIndex, 1, subTypeItem)
                })
            }
            // evaluationItem['isSelected'] = !this.checkProperty(evaluationItem, 'isSelected')
            evaluationItem['isSelected'] = true
            this.evaluationTypes.splice(index, 1, evaluationItem)
        },
        sortedArray(array) {
            // return array.sort((a, b) => a.id - b.id);
            return array.sort((a, b) => a.name.localeCompare(b.name));

        },
        cancelRequest() {
            if (this.isGuestRequest) {
                window.location.href = "https://carnegieevaluations.com/"
            } else {
                this.$router.push('/evaluations-list');
            }
        },
        validateandScroll() {
            var $self = this;
            const $ = JQuery;
            var el = _.find(this.errors["items"], function (item) {
                return item.scope == "evaluationForm"
            })
            if (el) {
                const ele = $("[name=" + el.field + "]").parents(".form_group");
                var _top = 0;
                if (ele) {
                    _top = ele.position().top;
                }

            }
            $("html, body").animate({ scrollTop: _top }, 100);

        },
        checkFileUploading() {
            let uploading = false
            _.forEach(this.evaluationTypes, (item, index) => {
                _.forEach(item.subTypes, (subItem, index2) => {
                    let resultDocs = _.filter(subItem.documents, (docItem) => {
                        //console.log('docItem' + JSON.stringify(docItem))
                        if (this.checkProperty(docItem, 'fileUploading')) {
                            return true
                        } else {
                            return false
                        }
                    })
                    //  console.log('resultDocs' + JSON.stringify(resultDocs))
                    if (this.checkProperty(resultDocs, 'length') > 0) {
                        if (!uploading) {
                            uploading = true
                        }
                    }
                })
                this.isFileUplading = uploading

            });
        },

        onWageLevelSelect(index, subIndex, id, levelIndex) {

            setTimeout(() => {
                this.showLevels = false
                if (this.checkProperty(this.evaluationTypes[index].subTypes[subIndex], 'levels', 'length') > 0) {
                    _.forEach(this.checkProperty(this.evaluationTypes[index].subTypes[subIndex], 'levels'), (item, idx) => {
                        if (item.id !== id) {
                            if (this.checkProperty(item, 'isSelected')) {
                                item.isSelected = false
                            } else {
                                item['isSelected'] = false
                            }

                            this.evaluationTypes[index].subTypes[subIndex].levels[idx] = item
                        }
                    })

                }
                this.showLevels = true

            })



        }


    },
    computed: {
        checkActiveTab() {
            return this.currentTabIndex;
        },

        getQuoteCalucatedPrice() {
            let quotaPrice = {
                total: 0,
                discount: 0,
                evaluationPrices: []
            }
            let evaluationQuates = []
            if (this.checkProperty(this.evaluationInfo, 'docsConfig', 'length') > 0) {
                _.forEach(this.evaluationInfo.docsConfig, (item) => {
                    let evaluationPrice = {
                        evaluationTypeId: '',
                        evaluationTypeName: '',
                        shortName: '',
                        price: 0,
                        subTypes: [],
                    }
                    evaluationPrice.evaluationTypeId = item.evaluationTypeId
                    evaluationPrice.evaluationTypeName = item.evaluationTypeName
                    evaluationPrice.shortName = item.shortName
                    evaluationPrice.price = item.price
                    evaluationPrice.subTypes = item.subTypes
                    evaluationQuates.push(evaluationPrice)
                })
            }
            quotaPrice.evaluationPrices = evaluationQuates
            let totalPrice = 0
            if (this.checkProperty(quotaPrice, 'evaluationPrices', 'length') > 0) {
                _.forEach(quotaPrice.evaluationPrices, (item) => {
                    if (this.checkProperty(item, 'price') > 0) {
                        totalPrice += parseInt(item.price)
                    }
                })
            }
            quotaPrice.total = totalPrice

            return quotaPrice
        },

    },

    data: () => ({
        promoerror:null,
        rush: false,
        tabsList: [{
            key: "personalinfo",
            name: "Your Information"
        },
        {
            key: "beneficiaryinfo",
            name: "Beneficiary's Information"
        }, {
            key: "evaluationinfo",
            name: "Type of Evaluation Needed"
        },],
        currentTabIndex: 2,
        evaluationInfo: {
            wwhs: true,
            name: 'WWHS',
            firstName: '',
            lastName: '',
            middleName: '',
            phone: '',
            email: '',
            alternateEmail: '',
            altEmailsList: [],
            firm: '',
            phoneCountryCode: {
                countryCode: "US",
                countryCallingCode: "1"
            },
            beneficiaryInformation: {
                firstName: '',
                middleName: '',
                lastName: '',
                jobTitle: '',
                gender: '',
                degree: '',
                usEquivalentDegree: '',
                socCode: '',
                firm: '',

            },
            docsConfig: [],
            priorityRush: null,
            priorityId: null,
            dueDate: null,
            howDoYouHere: '',
            proceedImmediately: null,
            firm: '',
            specialNotes: '',
            isDoingYourSelf: true,
            quotaPrice: {
                total: 0,
                discount: 0,
                evaluationPrices: []
            },
            today: null,
            namesOfDisciplines: '',
            evalFirstEmail: '',
        },
        evaluationTypes: [],
        priorityList: [],
        showCreateSuccess: false,
        showCreateSuccessalt:false,
        successMsg: '',
        temp: '',
        isFileUplading: false,
        showLevels: true,
        requestId: '',
    }),
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },

}
</script>








<!-- <script>
// @ is an alias to /src

import JQuery from "jquery";
import EvaluationRequest from "@/views/evaluationRequest.vue";


export default {
    name: 'guest-request',
    components: {
    EvaluationRequest
},
    mounted() {
    
    },
    methods: {



    },
    computed: {

    },
    data: () => ({

    }),
    provide() {
        // return {
        //     parentValidator: this.$validator,
        // };
    },
}
</script> -->

<style>
.custom-modal .modal-dialog.success_model {
    max-width: 90%;
}

.custom-modal .modal-body p {
    max-width: 90% !important;
    padding: 0px;
    margin: 0px 0px 10px 0px;
}
</style>