<template>
    <div class="form_group" :class="wrapclass">
        <label v-if="label" class="form_label">{{ label }}<em v-if="required">*</em></label>
        <div class="form_select">
            <!-- <multiselect :name="fieldName+cid" v-model="value"
                    :data-vv-as="vvas?vvas:placeHolder" 
                    :placeholder="placeHolder" 
                    :options="optionslist" 
                    :disabled="isDisabled"
                    :searchable="true" 
                    :allow-empty="!required"
                    :multiple="multiple"
                    :close-on-select="closeOnSelect"
                    :clear-on-select="clearOnSelect"
                    :hide-selected="hideSelected"
                    :preserve-search="preserveSearch"
                    >
                    <template slot="selection" slot-scope="{ values, isOpen }">
                              <span
                              class="multiselect__selectcustom"
                              v-if="values.length && !isOpen"
                              >{{ values.length }} Selected</span
                              >
                              <span
                              class="multiselect__selectcustom"
                              v-if="values.length && isOpen"
                              ></span>
                          </template>
                    
                </multiselect> -->
            <multiselect v-if="listContainsId" @input=updateData() :name="fieldName + cid"
                v-validate="required ? 'required|' + datatype : datatype" v-model="value" :show-labels="false"
                :label="optionItemLabel" :track-by="trackBy ? trackBy : 'name'" :data-vv-as="vvas ? vvas : placeHolder"
                :placeholder="placeHolder" :options="optionslist" :disabled="isDisabled" :searchable="true"
                :allow-empty="!required" :multiple="multiple" :close-on-select="closeOnSelect"
                :clear-on-select="clearOnSelect" :hide-selected="hideSelected" :preserve-search="preserveSearch">
                <template slot="selection" slot-scope="{ values, isOpen }">
                    <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                        Selected</span>
                    <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                </template>
                <template slot="option" slot-scope="props">
                    <div class="option__desc">
                        <span class="option__title">{{ props.option.name }}</span>
                        <span v-if="checkProperty(props.option, 'designation')" class="option__small">{{
                            props.option.designation }}</span>
                        <span v-if="checkProperty(props.option, 'departmentName')" class="option__small">{{
                            props.option.departmentName }}</span>
                        <span v-if="checkProperty(props.option, 'isSuggested') && props.option.isSuggested"
                            class="suggested">Suggested</span>
                    </div>

                </template>

            </multiselect>

            <multiselect v-else @input=updateData() :name="fieldName + cid"
                v-validate="required ? 'required|' + datatype : datatype" v-model="value" :show-labels="false"
                :disabled="isDisabled" :data-vv-as="vvas ? vvas : placeHolder" :placeholder="placeHolder"
                :options="optionslist" :searchable="searchable" :allow-empty="!required" :close-on-select="closeOnSelect"
                :clear-on-select="clearOnSelect" :hide-selected="hideSelected" :preserve-search="preserveSearch">
                <template slot="selection" slot-scope="{ values, isOpen }">
                    <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                        Selected</span>
                    <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                </template>
                <template slot="option" slot-scope="props">
                    <div class="option__desc">
                        <span class="option__title">{{ props.option.name }}</span>
                        <span v-if="checkProperty(props.option, 'designation')" class="option__small">{{
                            props.option.designation }}</span>
                        <span v-if="checkProperty(props.option, 'departmentName')" class="option__small">{{
                            props.option.departmentName }}</span>
                        <span v-if="checkProperty(props.option, 'isSuggested') && props.option.isSuggested"
                            class="suggested">Suggested</span>
                    </div>
                </template>
            </multiselect>

        </div>

        <template v-if="formscope">
            <span v-show="errors.has(formscope + '.' + fieldName + cid)" class="form-error">{{
                errors.first(formscope + '.' + fieldName + cid) }}</span>
        </template>
        <template v-else>
            <span v-show="errors.has(fieldName + cid)" class="form-error">{{ errors.first(fieldName + cid) }}</span>
        </template>

    </div>
</template>
    
<script>
import multiselect from "vue-multiselect-inv";
export default {
    inject: ["parentValidator"],
    components: {
        multiselect,
    },

    props: {
        /*
        closeOnSelect:true,
                clearOnSelect:false
                hideOnSelected:false
                hideSelected:false
        */
        multiple: {
            type: Boolean,
            default: false,
        },
        searchable: {
            type: Boolean,
            default: false,
        },
        closeOnSelect: {
            type: Boolean,
            default: true,
        },
        clearOnSelect: {
            type: Boolean,
            default: false,
        },
        hideSelected: {
            type: Boolean,
            default: false,
        },
        preserveSearch: {
            type: Boolean,
            default: false,
        },
        isDisabled: {
            type: Boolean,
            default: false,
        },
        listContainsId: {
            type: Boolean,
            default: true,
        },
        display: {
            type: Boolean,
            default: false,
        },
        fieldsArray: Array,
        vvas: {
            type: String,
            default: ""
        },
        optionslist: {
            type: Array,
            default() {
                return []
            }
        },
        wrapclass: {
            type: String,
            default: ""
        },
        helpText: {
            type: String,
            default: ""
        },
        datatype: {
            type: String,
            default: ""
        },
        cid: {
            type: String,
            default: null,
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        },
        loaded: {
            type: Boolean,
            default: false,
        },
        trackBy: {
            type: String,
            default: null,
        },
        optionItemLabel:{
            type: String,
            default: 'name',
        },
    },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {

        this.setWatchers();
    },
    methods: {
        updateData() {
            this.$emit('input', this.value)
        },
        setWatchers() {
            this.$watch('value', function () {
                if (this.loaded) {
                  //  this.$emit('input', this.value)
                    this.$emit('changeselect', this.value)
                } else {

                    this.loaded = true
                }

            });

            if (this.value == null) {
                this.loaded = true
            }
        }

    }
};
</script>
    