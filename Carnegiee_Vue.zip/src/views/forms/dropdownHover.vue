<template>
    <div @mouseover="onOver" @mouseleave="onLeave">
      <b-dropdown right class="settings-drpdown" offset="15"
        text="dropdown"
        ref="dropdown"
      >
        <slot></slot>
      </b-dropdown>
    </div>
  </template>
  
  <script>
  export default {
    name: "b-dropdown-hover",
    methods: {
      onOver() {
        this.$refs.dropdown.visible = true;
      },
      onLeave() {
        this.$refs.dropdown.visible = false;
      },
    },
  };
  </script>