<template>
    <div class="radio_group" :class="wrapclass"  >
        <input type="radio" :id="elementId" :name="fieldName" v-model="value" :value="fieldValue" @click="updateData" :disabled="disabled">
        <label :for="elementId" class="radio_btn">
            <div class="check"></div>
            <span>{{ label }}</span>
        </label>
        <span  v-if="showPreview&&checkProperty(fieldValue,'documents','length')>0" class="preview_link" @click="downloadfile(fieldValue)">Preview</span>
    </div>
</template>
<script>
export default {
    name: 'radio-input',
    props: {
        elementId: {
            type: String,
            default: null,
        },
        label: {
            type: String,
            default: '',
        },
        wrapclass: {
            type: String,
            default: ''
        },
        fieldName: {
            type: String,
            default: '',
        },
        checked: {
            type: Boolean,
            default: false,
        },
        value: Object,
        fieldValue:Object,
        disabled: {
            type: Boolean,
            default: false,
        },
        showPreview:{
            type: Boolean,
            default: false,
        }
    },
    methods: {
        setValue(val) {
            this.$emit("input", val);
        },
        updateData() {
           // alert(this.fieldValue)
            this.$emit("input", this.fieldValue);
        },
        downloadfile(item) {
            this.$emit("download_or_view", item.documents[0]);
        },
    },
    mounted(){
//alert(JSON.stringify(this.value))

    },
}
</script>