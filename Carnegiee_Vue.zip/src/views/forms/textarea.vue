<template>
    <div class="text_editor" :class="wrapclass">
        <label v-if="label" class="editor-label">{{ label }}<em v-if="required">*</em></label>


        <quill-editor @keydown.native.enter="handleEnterKey" :name="fieldName + cid" :ref="fieldName" @input="updateData()"
            :data-vv-as="vvas ? vvas : placeHolder" :placeholder="placeHolder" v-validate="checkFieldIsRequired({
                'key': tplkey, 'section': tplsection, 'fieldsArray': fieldsArray,
                'required': required
            }) ? 'required|' + datatype : datatype" v-model="value" :options="editorOptions"></quill-editor>

        <template v-if="formscope">
            <span v-show="errors.has(formscope + '.' + fieldName + cid)" class="form-error">{{
                errors.first(formscope + '.' + fieldName + cid) }}</span>
        </template>
        <template v-else>
            <span v-show="errors.has(fieldName + cid)" class="form-error">{{ errors.first(fieldName + cid) }}</span>
        </template>
    </div>
</template>
<script>
import { quillEditor } from 'vue-quill-editor';
import 'quill/dist/quill.snow.css';
import 'quill/dist/quill.bubble.css';
import 'quill/dist/quill.core.css';
import Quill from 'quill';

const highlightBackgroundColor = '#fffb8e'; // Yellow background color
// Configure Quill to use <div> instead of <p>
let Block = Quill.import('blots/block');
Block.tagName = 'DIV';
Quill.register(Block, true);

export default {
    inject: ["parentValidator"],
    props: {
        display: {
            type: Boolean,
            default: false,
        },
        fieldsArray: Array,
        vvas: {
            type: String,
            default: ""
        },
        wrapclass: {
            type: String,
            default: ""
        },
        datatype: {
            type: String,
            default: ""
        },
        cid: {
            type: String,
            default: null,
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: 'editor_' + Date.now(),
        },
        tplsection: {
            type: String,
            default: null,
        },
        tplkey: {
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        cid: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        }
    },
    components: {
        quillEditor,
    },
    created() {
        this.$validator = this.parentValidator;
    },

    methods: {
        handleEnterKey(event) {

        },
        updateData() {
            if (this.value && this.value == '<div><br></div>') {
                this.value = ""
            }
            this.$emit('input', this.value)
        },
    },
    data: () => ({
        editorOptions: {

            modules: {
                toolbar: [
                    ['bold', 'italic', 'underline', 'strike', 'highlight'],
                    [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                    [{ 'color': ['#fffb8e', '#ff0000', '#fff','#000'] }, { 'background': ['#fffb8e', '#ff0000', '#fff'] }], // Add color and background options
                ],
            },
            // placeholder: "Type something in here!",
        },

    }),

    mounted() {

    },
    computed: {

    }
};
</script>

<style>
.ql-editor div {
    line-height: 20px;
    /* &.ql-primary{
        
    } */
}
.ql-picker-item{ border-color:#000 !important}
</style>
