<template>
    <div class="form_group" :class="wrapclass">
        <label v-if="label" class="form_label">{{ label }}<em v-if="required">*</em>
            <span class="info_text" v-if="showHelpText">
                <img src="@/assets/images/info_icon.png">
                <div class="info_dropdown">{{ helpText }} </div>
            </span>
        </label>
        <!-- <input type="text" class="form-control"> -->
        <template v-if="onlyNumbers == true">
            <template v-if="allowFloatingPoint">
                <input :placeholder="placeHolder" class="form-control" @keyup.enter.native="$emit('keyEnter')"
                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                    :disabled="disabled" :name="fieldName + cid" v-on="listeners" v-model="value"
                    v-validate="required ? 'required|decimal:2' : 'decimal:2|'" :maxLength="maxLength"
                    :data-vv-as="vvas ? vvas : placeHolder" />
            </template>
            <template v-else>
                <input :placeholder="placeHolder" class="form-control" @keyup.enter.native="$emit('keyEnter')"
                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                    :disabled="disabled" :name="fieldName + cid" v-on="listeners" v-model="value"
                    v-validate="required ? 'required|' + datatype : datatype" :maxLength="maxLength"
                    :data-vv-as="vvas ? vvas : placeHolder" />
            </template>
        </template>
        <template v-else-if="allowAlphNum">
            <input oninput="this.value = this.value.replace(/[^ 0-9 a-z A-Z ]/g, '').replace(/(\..*)\./g, '$1');"
                :placeholder="placeHolder" class="form-control" @keyup.enter.native="$emit('keyEnter')" :disabled="disabled"
                :name="fieldName + cid" v-on="listeners" v-model="value"
                v-validate="required ? 'required|' + datatype : datatype" :data-vv-as="vvas ? vvas : placeHolder"
                :maxLength="maxCharacters"/>

        </template>
        <template v-else-if="emailFormat">
            <input 
                :placeholder="placeHolder" class="form-control" @keyup.enter.native="$emit('keyEnter')" :disabled="disabled"
                :name="fieldName + cid" v-on="listeners" v-model="value"
                v-validate="required ? 'required|' + datatype : datatype" :data-vv-as="vvas ? vvas : placeHolder"
                :maxLength="maxCharacters" />

        </template>
        <template v-else-if="isPassword">
            <template v-if="fieldName=='password'">
                <input :placeholder="placeHolder" class="form-control" @keyup.enter.native="$emit('keyEnter')"
                :disabled="disabled" :name="fieldName + cid" v-on="listeners" v-model="value"
                v-validate="required ? 'required|' + datatype : datatype" :data-vv-as="vvas ? vvas : placeHolder"
                :maxLength="maxCharacters" :type="showPassword ? 'text' : 'password'" id="inputPassword" ref="password" />
            </template>
            <template v-else>
                <input :placeholder="placeHolder" class="form-control" @keyup.enter.native="$emit('keyEnter')"
                :disabled="disabled" :name="fieldName + cid" v-on="listeners" v-model="value"
                v-validate="required ? 'required|' + datatype : datatype" :data-vv-as="vvas ? vvas : placeHolder"
                :maxLength="maxCharacters" :type="showPassword ? 'text' : 'password'" id="inputPassword"/>
            </template>
           
            <!-- <div v-if="showEyeIcon" class="view_eye" :class="{ close: showPassword }" @click="showPassword = !showPassword">
            </div> -->
        </template>
        <template v-else>
            <input :placeholder="placeHolder" class="form-control" @keyup.enter.native="$emit('keyEnter')"
                :disabled="disabled" :name="fieldName + cid" v-on="listeners" v-model="value"
                v-validate="required ? 'required|' + datatype : datatype" :data-vv-as="vvas ? vvas : placeHolder"
                :maxLength="maxCharacters" />

        </template>
        <template v-if="formscope">
            <span v-show="errors.has(formscope + '.' + fieldName + cid)" class="form-error">{{
                errors.first(formscope + '.' + fieldName + cid) }}</span>
        </template>
        <template v-else>
            <span v-show="errors.has(fieldName + cid)" class="form-error">{{ errors.first(fieldName + cid) }}</span>
        </template>
    </div>
</template>
    
<script>

export default {
    name: 'simpleInput',
    inject: ["parentValidator"],
    props: {
        emailFormat: {
            type: Boolean,
            default: false,
        },
        allowAlphNum: {
            type: Boolean,
            default: false,
        },
        helpText: {
            type: String,
            default: '',
        },
        maxCharacters: {
            type: Number,
            default: 200,
        },
        maxLength: {
            type: Number,
            default: 25,
        },
        display: {
            type: Boolean,
            default: false,
        },
        disabled: {
            type: Boolean,
            default: false,
        },
        allowFloatingPoint: {
            type: Boolean,
            default: true,
        },
        fieldsArray: Array,
        vvas: {
            type: String,
            default: ""
        },
        wrapclass: {
            type: String,
            default: ""
        },
        datatype: {
            type: String,
            default: ""
        },
        cid: {
            type: String,
            default: null,
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        },
        onlyNumbers: {
            type: Boolean,
            default: false,
        },
        isPassword: {
            type: Boolean,
            default: false,
        },
        showEyeIcon: {
            type: Boolean,
            default: false,
        },
        showHelpText: {
            type: Boolean,
            default: false,
        },
        helpText: {
            type: String,
            default: null,
        },


    },
    created() {
        this.$validator = this.parentValidator;
    },
    data: () => ({
        showPassword: false
    }),
    methods: {

    },
    components: {

    },
    computed: {
        listeners() {
            return {
                ...this.$listeners,
                input: (evt) => {
                    this.$emit('input', evt.target.value)
                },
                focus: (evt) => {
                    this.$emit('focus', evt)
                    // this.changeFocus(true)
                },
                blur: (evt) => {
                    this.$emit('blur', evt)
                    //this.changeFocus(false)
                }
            }
        },

    }
};
</script>
    