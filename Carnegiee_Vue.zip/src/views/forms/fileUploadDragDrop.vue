<template>
    <div class="form_group" :class="wrapclass">
        <label class="form_label">{{ label }}</label>
        <div class="upload_dragdrop">
            <img src="@/assets/images/fileuploaddrag.png">
            Drop your files here or <em>Browse</em>
            <!-- <input type="file" title="" accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" multiple="multiple" @change="previewMultiList" class="form-control-file"> -->
            <file-upload :ref="fieldName + cid"
                v-validate="checkFieldIsRequired({ 'key': tplkey, 'section': tplsection, 'fieldsArray': fieldsArray, 'required': required }) ? 'required' : datatype"
                :hideSelected="true" v-model="fvalue" class="form-control-file" :name="fieldName + cid"
                :data-vv-as="vvas ? vvas : placeHolder" :multiple="multiple" :accept=fileTypes @input="upload(fvalue)"
                :drop="true">
            </file-upload>
            <span class="loader" v-if="filesUploading"><img src="@/assets/images/loader.gif"></span>
        </div>
        <div class="form_label">Upload multiple files as necessary.</div>
        <template v-if="fvalue.length">
            <div class="uploaded_files">
                <div v-for="item, index in fvalue" :key="index" class="file_list" v-if="checkProperty(item, 'path') != ''">
                    <span class="file_text" :title="fvalue[index].name">{{ fvalue[index].name }}</span>
                    <span v-if="isShowPreview" class="view_file view_file-V2" @click="previewFile(item)"></span>

                    <span class="remove_file" @click="remove(index)"></span>
                </div>
            </div>
        </template>
    </div>
</template>



<script>
import FileUpload from "vue-upload-component/src";
import { InfoIcon } from 'vue-feather-icons'
import { CheckIcon } from 'vue-feather-icons'
import _ from "lodash";
export default {
    inject: ["parentValidator"],
    props: {
        tplsection: {
            type: String,
            default: null,
        },
        tplkey: {
            type: String,
            default: null,
        },
        deleteDocPermenantly: {
            type: Boolean,
            default: false
        },
        tooltip: {
            type: String,
            default: null,
        },
        display: {
            type: Boolean,
            default: false,
        },
        fieldsArray: Array,
        multiple: {
            type: Boolean,
            default: false
        },
        vvas: {
            type: String,
            default: ""
        },
        wrapclass: {
            type: String,
            default: "md:w-1/2"
        },
        datatype: {
            type: String,
            default: ""
        },
        cid: {
            type: String,
            default: '',
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        },
        fileTypes: {
            type: String,
                       default: "image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/zip, 'application/x-rar-compressed','application/octet-stream','application/zip','application/octet-stream','application/x-zip-compressed','multipart/x-zip'",
        },
        isShowPreview: {
            type: Boolean,
            default: false,
        },


    }, data() {
        return {
            fvalue: [],
            filesUploading: false,

        };
    },
    mounted() {

        if (this.value) {
            this.fvalue = _.cloneDeep(this.value);
            // alert(JSON.stringify(this.fvalue))
        }

    },
    created() {
        this.$validator = this.parentValidator;
    },

    computed: {
        getLabel() {
            let label = _.cloneDeep(this.label);
            if (this.checkFieldIsRequired({ 'key': this.tplkey, 'section': this.tplsection, 'fieldsArray': this.fieldsArray, 'required': this.required })) {
                label = label + "<em>*</em>";
            }

            return label;

        },
        getlist() {

            return _.filter(this.fvalue, function (item) {

                return item.status == true
            })

        }
    },
    methods: {
        getFileExtension(filePath) {
            // Split the file path by the dot (.)
            const parts = filePath.split('.');
            // Take the last element of the array, which will be the file extension
            const fileExtension = parts[parts.length - 1];

            return fileExtension;
        },
        upload(model) {
            let isDocFile = true
            _.forEach(model, (item) => {
                item.type = item.type ? item.type : item.mimetype
                let mineType = item.type;
                if (item.type == 'image/png' || item.type == 'image/jpeg' || item.type == 'image/jpg') {
                    mineType = "image/*"
                }
                if (!this.fileTypes.includes(mineType)) {
                    if (isDocFile) {
                        isDocFile = false
                    }
                }
            })

            console.log(model)
            if (!isDocFile) {
                let existingFiles = model.filter(doc => this.checkProperty(doc.path, 'length') > 0);
                // model = existingFiles
                this.fvalue = existingFiles
                this.showToster({ message: 'Please select a valid file to upload', isError: true });
                console.log("Result " + this.fvalue)
            } else {
                let mapper = model.map(
                    (item) =>
                    (item = {
                        name: item.name,
                        file: item.file ? item.file : null,
                        url: item.url ? item.url : "",
                        path: item.path ? item.path : "",
                        isNew: item.isNew ? item.isNew : false,
                        status: item.status === false || item.status === true ? item.status : true,
                        mimetype: item.type ? item.type : item.mimetype,
                        uploadedBy: item.uploadedBy ? item.uploadedBy : this.checkProperty(this.getUserData, '_id') != '' ? this.checkProperty(this.getUserData, '_id') : null,
                        uploadedByName: item.uploadedByName ? item.uploadedByName : this.checkProperty(this.getUserData, 'name') != '' ? this.checkProperty(this.getUserData, 'name') : '',
                        uploadedByRoleId: item.uploadedByRoleId ? item.uploadedByRoleId : this.getUserRoleId ? this.getUserRoleId : null,
                        uploadedByRoleName: item.uploadedByRoleName ? item.uploadedByRoleName : this.checkProperty(this.getUserData, 'roleName'),
                        fileUploading: item.path ? false : true,
                    })
                );

                // _.forEach(mapper, (item) => {
                //     alert(this.fileTypes.includes(item.mimetype))
                //     if (!this.fileTypes.includes(item.mimetype)) {
                //         if (isDocFile) {
                //             isDocFile = false
                //         }
                //     }
                // })
                // if (!isDocFile) {
                //     this.showToster({ message: 'Please select a valid file to upload', isError: true });
                // } else {
                this.value = mapper

                if (mapper.length > 0) {
                    setTimeout(() => {
                        this.$emit('uploadingFile')
                    })
                    this.filesUploading = true;
                    let count = 0;
                    mapper.forEach((doc, index) => {
                        if (doc.file) {
                            let formData = new FormData();
                            formData.append("files", doc.file);
                            formData.append("secureType", "private");
                            this.$store.dispatch("uploadS3File", formData).then((response) => {
                                if (this.checkProperty(response, 'data', 'result') && this.checkProperty(response.data, 'result', 'length') > 0) {
                                    response.data.result.forEach((urlGenerated) => {
                                        doc.isNew = true;
                                        doc.url = urlGenerated;
                                        doc.path = urlGenerated;
                                        doc.fileUploading = false
                                        delete doc.file;
                                        mapper[index] = doc;
                                    });

                                    count = count + 1;
                                    if (mapper.length >= count) {
                                        this.filesUploading = false;
                                        setTimeout(() => {
                                            this.$emit('uploadingFile')
                                        })
                                    } else {
                                        this.filesUploading = false;
                                        this.$delete(this.value, index)
                                        setTimeout(() => {
                                            this.$emit('uploadingFile')
                                        })
                                    }
                                }
                            });
                        }
                    });
                    model.splice(0, mapper.length, ...mapper);
                }

                this.updateData()
                //  }
            }



        },
        remove(index) {
            this.fvalue[index].status = false;

            // if (this.deleteDocPermenantly) {
            //     this.fvalue.splice(index, 1);
            //     this.$emit('input', this.fvalue)
            // }
            // else {
            this.fvalue.splice(index, 1);
            //this.fvalue[index].status = false;
            this.$emit('input', this.fvalue)
            //  }

        },
        updateData() {
            this.fvalue = _.filter(this.fvalue, function (item) { return item.status == true })
            this.$emit('input', this.fvalue)
        },

        previewFile(item) {
            this.$emit("download_or_view", item);
        }
    },
    components: {
        FileUpload,
        InfoIcon
    }
};
</script>
    