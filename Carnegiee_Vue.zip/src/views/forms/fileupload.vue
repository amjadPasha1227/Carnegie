<template>
    <div class="upload_doc_list" :class="wrapclass">
        <div class="upload_doc_name">

            <input v-if="checkProperty(fvalue, 'length') > 0 && checkProperty(fvalue[0], 'name')" type="text"
                class="form-control" placeholder="Name of the Document" v-model="fvalue[0].name">
            <input v-else type="text" class="form-control" placeholder="Name of the Document">

            <div class="upload_file">
                <img src="@/assets/images/upload_cloud.png">
                <span>Upload</span>
                <span class="loader" :id="fieldName + cid + 'loading'" v-if="filesUploading"><img
                        src="@/assets/images/loader.gif"></span>
                <!-- <input type="file" title=""
                    accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    class="form-control" @change="onFileUpload"> -->
                <file-upload :ref="fieldName + cid"
                    v-validate="checkFieldIsRequired({ 'key': tplkey, 'section': tplsection, 'fieldsArray': fieldsArray, 'required': required }) ? 'required' : datatype"
                    :hideSelected="true" v-model="fvalue" class="form-control" :name="fieldName + cid"
                    :data-vv-as="vvas ? vvas : placeHolder" :multiple="multiple" 
                    accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    @input="upload(fvalue)">
                    <img class="file-icon" src="@/assets/images/upload_cloud.png" />
                    Upload
                    <span v-if="filesUploading"><img src="@/assets/images/loader.gif"></span>
                </file-upload>
            </div>
            <div v-if="showDeleteIcon" class="delete_row" @click="removeCompleteDocument()"><span>Delete</span></div>
        </div>
        <template v-if="fvalue.length > 0">
            <div class="uploaded_files">
                <div v-for="item, index in fvalue" :key="index" class="file_list" v-if="checkProperty(item, 'path') != ''">
                    <span class="file_text">{{ item.name }}</span>
                    <span class="remove_file" @click="remove(index)"></span>
                </div>
            </div>
        </template>
    </div>
    <!-- <div class="vx-col  w-full" :class="wrapclass" v-if="fieldName !=null && canRenderField(tplkey,fieldsArray, display,tplsection,fieldName)">
     
        
        <div class="form_group">
            <label class="form_label" ><span v-html="getLabel" style="display:inline"></span>      <div class="IB_tooltip" v-if="tooltip!=null">
                        <span>
                          <info-icon size="1.5x" class="custom-class"></info-icon>
                        </span>
                        <div class="tooltip_cnt">
                          <p>
                            {{tooltip}}
                          </p>
                                        </div>
                                      </div></label>
                            <file-upload  :ref="fieldName+cid"  v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required })? 'required': datatype " :hideSelected="true" v-model="fvalue" class="file-upload-input file-upload-input-cs" :name="fieldName+cid"  :data-vv-as="vvas?vvas:placeHolder" :multiple="multiple" accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" @input="upload(fvalue)">
                                <img class="file-icon" src="@/assets/images/upload_cloud.png" />
                
                                Upload
                                <span class="loader" v-if="filesUploading" ><img src="@/assets/images/loader.gif"></span>
                            </file-upload>
    
                            <p v-show="errors.has((formscope!=''?formscope+'.':'')+fieldName+cid)" class="text-danger text-sm-doc">{{ errors.first((formscope!=''?formscope+'.':'')+fieldName+cid) }}</p>
                            <ul class="uploaded-list">
                                <template v-for="(item, index) in getlist">
                                    <vs-chip v-if="item.status" @click="item.status=false;remove(index)"  :key="index" closable>
                                        <img src="@/assets/images/down-arrow2.svg" @click="downloads3file(item)" />
                                        {{ item.name }}
                                    </vs-chip>
                   
                                </template>
                            </ul>
                        </div>
                    </div> -->
</template>
    
<script>
import FileUpload from "vue-upload-component/src";
import { InfoIcon, CheckIcon } from 'vue-feather-icons'
import _ from "lodash";
export default {
    inject: ["parentValidator"],
    props: {
        tplsection: {
            type: String,
            default: null,
        },
        tplkey: {
            type: String,
            default: null,
        },
        deleteDocPermenantly: {
            type: Boolean,
            default: false
        },
        tooltip: {
            type: String,
            default: null,
        },
        display: {
            type: Boolean,
            default: false,
        },
        fieldsArray: Array,
        multiple: {
            type: Boolean,
            default: false
        },
        vvas: {
            type: String,
            default: ""
        },
        wrapclass: {
            type: String,
            default: ""
        },
        datatype: {
            type: String,
            default: ""
        },
        cid: {
            type: String,
            default: '',
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        },
        showDeleteIcon: {
            type: Boolean,
            default: false,
        },
        isGuestUpload: {
            type: Boolean,
            default: false,
        },
        fileTypes: {
            type: String,
            default: "image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        }



    }, data() {
        return {
            fvalue: [],
            filesUploading: false,

        };
    },
    mounted() {

        if (this.value) {
            this.fvalue = _.cloneDeep(this.value);
            // alert(JSON.stringify(this.fvalue))
        }

    },
    created() {
        this.$validator = this.parentValidator;
    },

    computed: {
        getLabel() {
            let label = _.cloneDeep(this.label);
            if (this.checkFieldIsRequired({ 'key': this.tplkey, 'section': this.tplsection, 'fieldsArray': this.fieldsArray, 'required': this.required })) {
                label = label + "<em>*</em>";
            }

            return label;

        },
        getlist() {

            return _.filter(this.fvalue, function (item) {

                return item.status == true
            })

        }
    },
    methods: {
        upload(model) {
            let self = this;
            let mapper = model.map(
                (item) =>
                (item = {
                    name: item.name,
                    file: item.file ? item.file : null,
                    url: item.url ? item.url : "",
                    path: item.path ? item.path : "",
                    isNew: item.isNew ? item.isNew : false,
                    status: item.status === false || item.status === true ? item.status : true,
                    mimetype: item.type ? item.type : item.mimetype,
                    uploadedBy: item.uploadedBy?item.uploadedBy:this.checkProperty(this.getUserData, '_id') != '' ? this.checkProperty(this.getUserData, '_id') : null,
                    uploadedByName: item.uploadedByName?item.uploadedByName:this.checkProperty(this.getUserData, 'name') != '' ? this.checkProperty(this.getUserData, 'name') : '',
                    uploadedByRoleId: item.uploadedByRoleId?item.uploadedByRoleId:this.getUserRoleId ? this.getUserRoleId : null,
                    uploadedByRoleName: item.uploadedByRoleName?item.uploadedByRoleName:this.checkProperty(this.getUserData, 'roleName'),
                    fileUploading: item.path ? false : true,
                })
            );
            // model.splice(0, mapper.length, ...mapper);
            //  this.updateData()
            this.value = mapper
            // console.log(JSON.stringify(mapper))
            if (mapper.length > 0) {
                this.filesUploading = true;
                setTimeout(() => {
                    this.$emit('uploadingFile')
                })

                let count = 0;
                mapper.forEach((doc, index) => {
                    if (doc.file) {
                        let formData = new FormData();
                        formData.append("files", doc.file);
                        formData.append("secureType", "private");
                        if (this.isGuestUpload) {
                            formData.append("authRequired", false);
                        }
                        this.$store.dispatch("uploadS3File", formData).then((response) => {
                            if (this.checkProperty(response, 'data', 'result') && this.checkProperty(response.data, 'result', 'length') > 0) {
                                response.data.result.forEach((urlGenerated) => {
                                    doc.isNew = true;
                                    doc.url = urlGenerated;
                                    doc.path = urlGenerated;
                                    doc.fileUploading = false
                                    delete doc.file;
                                    mapper[index] = doc;
                                });

                                // console.log("after:-" +JSON.stringify(mapper))
                                count = count + 1;

                                if (mapper.length >= count) {
                                    this.filesUploading = false;
                                    //  this.value.fileUploading = false
                                    setTimeout(() => {
                                        this.$emit('uploadingFile')
                                    })
                                }
                            } else {
                                this.filesUploading = false;
                                this.$delete(this.value, index)
                                setTimeout(() => {
                                    this.$emit('uploadingFile')
                                })
                            }
                        }).catch((error) => {
                            this.showToster({ message: error, isError: true });
                            this.filesUploading = false;
                            this.$delete(mapper, index)
                            setTimeout(() => {
                                this.$emit('uploadingFile')
                            })
                        });
                    }
                });
                model.splice(0, mapper.length, ...mapper);
            }

            this.updateData()

        },
        remove(index) {
            this.fvalue[index].status = false;

            if (this.deleteDocPermenantly) {
                this.fvalue.splice(index, 1);
                this.$emit('input', this.fvalue)
                this.$emit('deleteDocument')
                this.filesUploading = false;
            }
            else {
                this.fvalue.splice(index, 1);
                //this.fvalue[index].status = false;
                this.$emit('input', this.fvalue)
                this.$emit('deleteDocument')
                this.filesUploading = false;
            }

        },
        updateData() {
            this.fvalue = _.filter(this.fvalue, function (item) { return item.status == true })
            // alert(JSON.stringify(this.fvalue))
            this.$emit('input', this.fvalue)
        },
        removeCompleteDocument() {
            // if(this.checkProperty(this.fvalue,'length')>0){
            // this.fvalue.splice(0, 1);
            // }
            this.$emit('deleteDocument')
        }
    },
    components: {
        FileUpload,
        InfoIcon
    }
};
</script>
    