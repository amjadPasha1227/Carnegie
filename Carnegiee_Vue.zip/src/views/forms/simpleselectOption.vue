<template>
    <div class="vx-col  w-full" :class="wrapclass" v-if="canRenderField(tplkey,fieldsArray,display ,tplsection,fieldName)">
        <div class="form_group option_multi_select">
            <label class="form_label">{{label}}<em v-if="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required,'notRequired':notRequired })">*</em></label>
            <div class="con-select w-full">
    
                <multiselect v-if="listContainsId" @input=updateData() :name="fieldName+cid"
                    v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required ,'notRequired':notRequired })? 'required':'' "
                     v-model="value" :show-labels="false"
                      track-by="id" label="name"
                    :data-vv-as="vvas?vvas:placeHolder" 
                    :placeholder="placeHolder" 
                    :options="optionslist" 
                    :disabled="isDisabled"
                    :searchable="true" 
                    :allow-empty="!required"
                    :multiple="multiple"
                    :close-on-select="false"
                    :clear-on-select="false"
                    :preserve-search="true"
                    >
                    <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Assignees Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                    </template>
                </multiselect>
            </div>
            <p v-show="errors.has((formscope!=''?formscope+'.':'')+fieldName+cid)" class="text-danger text-sm">{{ errors.first((formscope!=''?formscope+'.':'')+fieldName+cid) }}</p>
        </div>
    </div>
    </template>
    
    <script>
    export default {
        inject: ["parentValidator"],
       
        props: {
            multiple:{
                type: Boolean,
                default: false,
            },
            isDisabled:{
                type: Boolean,
                default: false,
            },
            listContainsId: {
                type: Boolean,
                default: true,
            },
              display: {
                type: Boolean,
                default: false,
            },
            notRequired:{
                type: Boolean,
                default: false,
            },
             fieldsArray:Array,
            vvas: {
                type: String,
                default: ""
            },
            optionslist: {
                type: Array,
                default () {
                    return []
                }
            },
            wrapclass: {
                type: String,
                default: ""
            },
            datatype: {
                type: String,
                default: ""
            },
            cid: {
                type: String,
                default: null,
            },
            formscope: {
                type: String,
                default: null
            },
            value: null,
            label: {
                type: String,
                default: null,
            },
            fieldName: {
                type: String,
                default: null,
            },
            tplsection:{
                type: String,
                default: null,
            },
            tplkey:{
                type: String,
                default: null,
            },
            placeHolder: {
                type: String,
                default: null,
            },
            required: {
                type: Boolean,
                default: false,
            },
            loaded: {
                type: Boolean,
                default: false,
            }
        },
        created() {
            this.$validator = this.parentValidator;
        },
        mounted() {
    
            this.setWatchers();
        },
        methods: {
    updateData(){
    
          this.$emit('input', this.value)
    
    },
            setWatchers() {
                this.$watch('value', function () {
                    if (this.loaded) {
                        this.$emit('input', this.value)
                        this.$emit('changeselect', this.value)
                    } else {
    
                        this.loaded = true
                    }
    
                });
    
                if (this.value == null) {
                    this.loaded = true
                }
            }
    
        }
    };
    </script>
    