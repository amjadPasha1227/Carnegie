<template>
    <div>
        <b-modal id="createLabelPopupModal" dialog-class="create_template add_label_modal" centered no-close-on-backdrop
            hide-footer>
            <template #modal-header>
                <h6 class="modal-title">Labels</h6>
                <a class="close" @click="$bvModal.hide('createLabelPopupModal'); openLabelPopup(false)"></a>
            </template>
            <template>
                <form data-vv-scope="newLabelForm" @submit.prevent @keydown.enter.prevent>
                    <div class="new_label_form" @click="formErrors = ''">
                        <div class="label_create_header">
                            <simpleInput :wrapclass="'mb20 me-4'" :fieldName="'labelname'" :cid="'labelname'"
                                :label="'Please enter a new label name'" :placeHolder="'Label Name'" :vvas="'Label Name'"
                                :display="true" :required="true" v-model="labelName" :formscope="'newLabelForm'" />
                            <simpleColorPicker v-model="selectColor" :formscope="'newLabelForm'" :fieldName="'labelColor'"
                                :cid="'labelColor'" :name="'labelColor'" :label="'Select the label color'"
                                :required="true" />
                            <button :disabled="loadingLabel" class="primary_btn ms-4 mt-3"
                                @click="createLabel">Create</button>
                            <div class="text-danger text-sm formerrors custom_margin" v-show="formerrors.msg">
                                <!-- <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                                icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formerrors.msg
                                }}</vs-alert> -->
                            </div>
                        </div>
                        <div class="form-container pad0">
                            <div class="table-responsive">
                                <NoDataFound ref="NoDataFoundRef" :loading="isListLoading" v-if="labelsList.length == 0"
                                    content="" :heading="callFromSerch ? 'No Results Found' : 'No Results Found'"
                                    type='petitions' />

                                <div v-if="labelsList.length > 0 && !isListLoading">
                                    <table class="table" :data="labelsList">

                                        <thead v-if="labelsList.length > 0">
                                            <tr>
                                                <th>
                                                    <span @click="sortMe('name')"
                                                        v-bind:class="{ 'sort_ascending': sortKeys['name'] == 1, 'sort_descending': sortKeys['name'] != 1 }">Name
                                                    </span>
                                                </th>
                                                <th> <span>Color
                                                    </span>
                                                </th>
                                                <th> <span @click="sortMe('createdByName')"
                                                        v-bind:class="{ 'sort_ascending': sortKeys['createdByName'] == 1, 'sort_descending': sortKeys['createdByName'] != 1 }">Created
                                                        By
                                                    </span>
                                                </th>
                                                <th> <span @click="sortMe('createdOn')"
                                                        v-bind:class="{ 'sort_ascending': sortKeys['createdOn'] == 1, 'sort_descending': sortKeys['createdOn'] != 1 }">
                                                        Created On</span>
                                                </th>
                                                <th> <span @click="sortMe('updatedOn')"
                                                        v-bind:class="{ 'sort_ascending': sortKeys['updatedOn'] == 1, 'sort_descending': sortKeys['updatedOn'] != 1 }">
                                                        Updated On</span>
                                                </th>

                                                <th class="actions">Actions</th>
                                            </tr>


                                        </thead>
                                        <tbody>
                                            <tr v-for="(messge, index) in labelsList" v-bind:key="index"
                                                class="vs-table--tr">
                                                <td> <span>{{ checkProperty(messge, 'name') }}</span> </td>
                                                <td> <span class="color_span"
                                                        :style="{ 'background-color': messge['color'] }">{{
                                                            checkProperty(messge, 'color') }}</span> </td>
                                                <td class="td_label">
                                                    <span>
                                                        {{ checkProperty(messge, 'createdByName') }} <br />
                                                        <small> {{ checkProperty(messge, 'createdByRoleName') }} </small>
                                                    </span>
                                                </td>

                                                <td> <span> {{ messge.createdOn | formatDate }} </span> </td>
                                                <td> <span> {{ messge.updatedOn | formatDate }} </span> </td>
                                                <td>
                                                    <span class="invoice_btn" @click="editLabel(messge, true)">Edit</span>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <div class="pagination-sec"
                                        v-if="checkProperty(labelsList, 'length') > 0 && !isListLoading">
                                        <div class="per-page">
                                            <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) *
                                                perpage) +
                                                labelsList.length) +
                                                ' of ' + totalCount + ' Results' }}</label>
                                        </div>
                                        <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount"
                                            :per-page="perpage"
                                            @input="isListLoading = true, updateLoading(true), getLabelsList()"></b-pagination>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </template>
        </b-modal>
        <messageCreateLabel v-if="showCreate" :callFromEdit="callFromEdit" :callFromList="true" :editItem="selectedItem"
            @hideMe="hideMe" />
    </div>
</template>
<script>

import simpleInput from "@/views/forms/simpleInput.vue";
import simpleColorPicker from "@/views/forms/simpleColorPicker.vue";
import messageCreateLabel from "@/views/messages/messageCreateLabel.vue";
import NoDataFound from "@/views/common/noData.vue"
import { XIcon, MoreVerticalIcon } from 'vue-feather-icons'
import moment from "moment";
import multiselect from "vue-multiselect-inv";
export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    data: () => ({
        callFromSerch: false,
        labelName: '',
        selectColor: '',
        searchtxt: '',
        labelsList: [],
        page: 1,
        perpage: 15,
        totalpages: 0,
        searchtxt: '',
        debounce: null,
        sortKeys: {},
        sortKey: {},
        isListLoading: false,
        perPeges: [10, 25, 50, 75, 100],
        showCreate: false,
        selectedItem: null,
        callFromEdit: false,
        formerrors: {
            msg: "",
        },
        loadingLabel: false,
        totalCount:0,

    }),
    components: {
        simpleColorPicker,
        messageCreateLabel,
        NoDataFound,
        MoreVerticalIcon,
        XIcon,
        simpleInput,
    },
    methods: {
        sortMe(sort_key = '') {
            if (sort_key != '') {
                this.page = 1;
                this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1
                this.sortKey = {};
                this.sortKey = { "path": sort_key, "order": this.sortKeys[sort_key] }
                localStorage.setItem('petitions_sort_key', sort_key);
                localStorage.setItem('petitions_sort_value', this.sortKey[sort_key]);
                this.getLabelsList();
            }
        },
        pageNate(pageNum) {
            this.page = pageNum;
            this.getLabelsList();
        },
        openLabelPopup() {
            this.$bvModal.hide('createLabelPopupModal');
            this.$emit('openLabelPopup', false)
        },
        getLabelsList() {
            let payLoad = {
                matcher: {
                    statusList: [],
                    searchString: this.searchtxt
                },
                page: this.page,
                perpage: this.perpage,
                sorting: this.sortKey,
                today: moment().format('YYYY-MM-DD')
            };
            this.isListLoading = true;
            this.updateLoading(true);
            let path = '/message-label/list'
            this.$store.dispatch("getList", { "data": payLoad, "path": path }).then((response) => {
                this.isListLoading = false;
                this.updateLoading(false);
                setTimeout(() => {
                    this.updateLoading(false);
                }, 5)
                if (response.list) {
                    let list = response.list;
                    let tempList = []
                    _.forEach(list, (item) => {
                        if (!_.has(item, 'id')) {
                            item['id'] = item['_id'];
                            tempList.push(item)
                        }
                    })
                    if (this.checkProperty(tempList, 'length') > 0) {
                        this.labelsList = tempList
                    }
                    this.totalCount=response.totalCount
                    this.totalpages = Math.ceil(response.totalCount / this.perpage);
                }
            }).catch((err) => {

            })
        },
        editLabel(item = null, callFromedit = false) {

            this.callFromEdit = callFromedit;

            if (this.callFromEdit) {
                this.selectedItem = item;
            }
            this.showCreate = true;
        },
        hideMe() {
            this.showCreate = false;
            this.getLabelsList();
        },
        createLabel() {
            this.$validator.validateAll('newLabelForm').then(result => {
                if (result) {
                    let payLoad = {
                        name: this.labelName,
                        color: this.selectColor,
                        tenantId: this.checkProperty(this.getUserData['tenantDetails'], '_id')
                    }
                    this.formerrors.msg = '';
                    let path = '/message-label/create';
                    this.loadingLabel = true;
                    this.$store.dispatch("commonAction", { "data": payLoad, "path": path }).then((response) => {
                        this.loadingLabel = false;
                        this.getLabelsList();
                        this.labelName = '';
                        this.selectColor = '';
                        this.$validator.reset();
                        this.showToster({ message: response.message, isError: false });
                    }).catch((err) => {
                        this.formerrors.msg = err;
                        this.loadingLabel = false;
                    })
                }
            })
        },
    },
    mounted() {
        this.$bvModal.show('createLabelPopupModal')
        // this.labelsList = [
        //     {
        //         "_id": "64c0006b9b8865a20a18431a",
        //         "name": "USCIS",
        //         "color": "#D6ECD2",
        //         "createdByName": "Thomas V Allen",
        //         "createdBy": "6257ebae1b1a45cb4490ec66",
        //         "createdByRoleId": 3,
        //         "createdByRoleName": "Admin",
        //         "createdOn": "2023-07-25T17:03:39.627Z",
        //         "sortName": "uscis",
        //         "sortCreatedByName": "thomas v allen"
        //     },
        //     {
        //         "_id": "64bfff349550e0a1090150a7",
        //         "name": "ADMIN LABEL",
        //         "color": "#E2B1A8",
        //         "createdByName": "Thomas V Allen",
        //         "createdBy": "6257ebae1b1a45cb4490ec66",
        //         "createdByRoleId": 3,
        //         "createdByRoleName": "Admin",
        //         "createdOn": "2023-07-25T16:58:28.260Z",
        //         "updatedOn": "2023-07-25T16:58:42.877Z",
        //         "sortName": "admin label",
        //         "sortCreatedByName": "thomas v allen"
        //     },
        //     {
        //         "_id": "64bfcc917a83bb9429415dd4",
        //         "name": "Response",
        //         "color": "#D6ECD2",
        //         "createdByName": "Thomas V Allen",
        //         "createdBy": "6257ebae1b1a45cb4490ec66",
        //         "createdByRoleId": 3,
        //         "createdByRoleName": "Admin",
        //         "createdOn": "2023-07-25T13:22:25.628Z",
        //         "updatedOn": "2023-07-25T15:52:54.078Z",
        //         "sortName": "response",
        //         "sortCreatedByName": "thomas v allen"
        //     },
        //     {
        //         "_id": "64beafc002d650393d6babdb",
        //         "name": "Checks",
        //         "color": "#C2E5A0",
        //         "createdByName": "Thomas V Allen",
        //         "createdBy": "6257ebae1b1a45cb4490ec66",
        //         "createdByRoleId": 3,
        //         "createdByRoleName": "Admin",
        //         "createdOn": "2023-07-24T17:07:12.848Z",
        //         "updatedOn": "2023-07-24T18:03:56.878Z",
        //         "sortName": "checks",
        //         "sortCreatedByName": "thomas v allen"
        //     },
        //     {
        //         "_id": "64beafb402d650393d6babca",
        //         "name": "PLAN",
        //         "color": "#F4D3CE",
        //         "createdByName": "Thomas V Allen",
        //         "createdBy": "6257ebae1b1a45cb4490ec66",
        //         "createdByRoleId": 3,
        //         "createdByRoleName": "Admin",
        //         "createdOn": "2023-07-24T17:07:00.201Z",
        //         "updatedOn": "2023-07-25T16:59:17.594Z",
        //         "sortName": "plan",
        //         "sortCreatedByName": "thomas v allen"
        //     },
        //     {
        //         "_id": "64be925f08681e2f1ef4716d",
        //         "name": "Revisit",
        //         "color": "#C1C7D0",
        //         "createdByName": "Thomas V Allen",
        //         "createdBy": "6257ebae1b1a45cb4490ec66",
        //         "createdByRoleId": 3,
        //         "createdByRoleName": "Admin",
        //         "createdOn": "2023-07-24T15:01:51.418Z",
        //         "sortName": "revisit",
        //         "sortCreatedByName": "thomas v allen"
        //     },
        //     {
        //         "_id": "64be924608681e2f1ef47156",
        //         "name": "Urgent Requests",
        //         "color": "#FFBABA",
        //         "createdByName": "Thomas V Allen",
        //         "createdBy": "6257ebae1b1a45cb4490ec66",
        //         "createdByRoleId": 3,
        //         "createdByRoleName": "Admin",
        //         "createdOn": "2023-07-24T15:01:26.035Z",
        //         "sortName": "urgent requests",
        //         "sortCreatedByName": "thomas v allen"
        //     },
        //     {
        //         "_id": "64be922108681e2f1ef470f4",
        //         "name": "Need to Work",
        //         "color": "#F4D3CE",
        //         "createdByName": "Thomas V Allen",
        //         "createdBy": "6257ebae1b1a45cb4490ec66",
        //         "createdByRoleId": 3,
        //         "createdByRoleName": "Admin",
        //         "createdOn": "2023-07-24T15:00:49.567Z",
        //         "sortName": "need to work",
        //         "sortCreatedByName": "thomas v allen"
        //     }
        // ]
        this.getLabelsList();
        this.sortKeys = {
            'name': 1,
            'createdByName': 1,
            'createdOn': 1,
            'updatedOn': 1,
        };
        this.labelName = '';
        this.selectColor = '';
    }
}
</script>