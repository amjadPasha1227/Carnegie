<template>
    <b-modal id="createLabelModal" dialog-class="create_template email_model" :min-width="200" :min-height="200"
        :scrollable="true" :reset="true" width="500px" height="auto" centered no-close-on-backdrop>
       
        <template #modal-header>
            <h6 class="modal-title" v-if="callFromEdit && callFromList && editItem && checkProperty(editItem, '_id')">
                Edit Label</h6>
            <h6 class="modal-title" v-else>Create Label</h6>
            <a class="close" @click="hideMe"></a>
        </template>

        <template>
            <form @submit.prevent data-vv-scope="newLabelform">
                <div class="form-container" @click="formerrors.msg = ''">
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">Please enter a new label name</label>
                                <simpleInput :wrapclass="'mb20'" :fieldName="'labelname'" :cid="'labelname'"
                                        :label="''" :placeHolder="'Label Name'" :vvas="'Label Name'"
                                        :display="true" :required="true" v-model="labelName" :formscope="'newLabelform'"/>
                                <!-- <vs-input name="labelname" v-validate="'required'" class="w-full" data-vv-as="label name"
                                    v-model="labelName" /> -->
                                    <!-- {{ errors }}
                                <span class="text-danger text-sm" v-show="errors.has('newLabelform.labelname')">{{
                                    errors.first("newLabelform.labelname") }}</span> -->
                            </div>
                        </div>
                    </div>
                    <div class="vx-row">
                        <simpleColorPicker v-model="selectColor" :formscope="'newLabelform'" :fieldName="'labelColor'"
                            :cid="'labelColor'" :name="'labelColor'" :label="'Select the label color'" :required="true" />
                    </div>
                    <div class="text-danger text-sm formerrors custom_margin" v-show="formerrors.msg">
                        <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                            icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formerrors.msg
                            }}</vs-alert>
                    </div>
                </div>
            </form>
        </template>

        <template #modal-footer>
            <span class="loader" v-if="loadingLabel"><img src="@/assets/images/loader.gif" /></span>
            <button color="success" :disabled="loadingLabel" @click="createLabel" class="primary_btn md" type="filled">
                <template v-if="callFromEdit && callFromList && editItem && checkProperty(editItem, '_id')">
                    Update
                </template>
                <template v-else>
                    Create
                </template>
            </button>
        </template>
    </b-modal>
</template>

<script>
import simpleColorPicker from "@/views/forms/simpleColorPicker.vue";
import simpleInput from "@/views/forms/simpleInput.vue";
export default {
    components: {
        simpleColorPicker,
        simpleInput
    },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    data: () => ({
        labelName: '',
        selectColor: '',
        loadingLabel: false,
        formerrors: {
            msg: ''
        }
    }),
    props: {
        message: {
            type: Object,
            default: null
        },
        callFromEdit: {
            type: Boolean,
            default: false
        },
        callFromList: {
            type: Boolean,
            default: false
        },
        editItem: {
            type: Object,
            default: null
        }
    },
    methods: {
        createLabel() {

            this.$validator.validateAll('newLabelform').then(result => {
                if (result) {
                    let payLoad = {
                        name: this.labelName,
                        color: this.selectColor,
                    }
                    this.formerrors.msg = '';
                    let path = '/message-label/create';
                    if (this.callFromEdit && this.callFromList && this.editItem && this.checkProperty(this.editItem, '_id')) {
                        payLoad['messageLabelId'] = this.checkProperty(this.editItem, '_id');
                        path = '/message-label/update'
                    }

                    this.loadingLabel = true;
                    this.$store.dispatch("commonAction", { "data": payLoad, "path": path }).then((response) => {
                        this.showToster({ message: response.message, isError: false });
                        if (this.checkProperty(this.message, '_id') && !this.callFromEdit && !this.callFromList) {
                            let temp = {
                                color: payLoad['color'],
                                name: payLoad['name'],
                                _id: response._id
                            }
                            if (_.has(this.message, 'labels') && this.checkProperty(this.message, 'labels', 'length') > 0) {
                                this.message['labels'].push(temp)
                            } else {
                                this.message['labels'] = [];
                                this.message['labels'].push(temp)
                            }
                            if (this.message['labels'] && this.checkProperty(this.message['labels'], 'length') > 0) {
                                let payload = {
                                    messageId: this.checkProperty(this.message, '_id'),
                                    labels: this.message['labels'],
                                }
                                let path = '/mail-inbox/manage-labels'
                                this.$store.dispatch("commonAction", { 'data': payload, 'path': path }).then(response => { }).catch((err) => { })
                            }
                        }
                        this.loadingLabel = false;
                        this.hideMe()
                    }).catch((err) => {
                        this.formerrors.msg = err;
                        this.loadingLabel = false;
                    })
                }
            })
        },
        hideMe() {
            this.$bvModal.hide('createLabelModal');
            this.$emit('hideMe')
        }
    },
    mounted() {
        this.labelName = '',
            this.selectColor = '',
            this.loadingLabel = false,
            this.formerrors = {
                msg: ''
            }
        if (this.callFromEdit && this.callFromList && this.editItem && this.checkProperty(this.editItem, '_id')) {
            this.labelName = this.checkProperty(this.editItem, 'name');
            this.selectColor = this.checkProperty(this.editItem, 'color');
        }
        this.$bvModal.show('createLabelModal');
    }
}


</script>