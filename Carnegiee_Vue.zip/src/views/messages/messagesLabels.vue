<template>
    <!-- <div class="message_sec">
                <template v-if="!callFromDetails">
                      <span class="message_info" v-if="trimcontent">
                  <p>{{ getTrimmedContent(message.message) }}</p>
                  </span>
                   <span class="message_info" v-if="!trimcontent"  v-html="checkProperty(message,'message')">
                
                  </span>
                </template>
                  <div class="message_lables"  @click="processLabels()">
                    <div class="new_label_as">
                        <ul class="label_list" >
                        <li class="label_new">Labels</li>
                        <template v-if="checkProperty(message,'labels') && checkProperty(message,'labels','length')>0"> 
                            <template v-for="item in message['labels'] ">
                                <li :style="{'background-color':item['color']}">
                                    {{checkProperty(item,'name')}} <em  v-if="!checkProperty(message,'completed')" @click="deleteLabel(item)">x</em>
                                </li>
                            </template>
                        </template>
                        <li class="p-0 add_li">
                                <vs-dropdown vs-custom-content vs-trigger-click class="cursor-pointer add_new_label" v-if="!checkProperty(message,'completed')">  
                                    <span>+</span>
                                    <div class="tooltip_cnt">
                                        <p>Add Label</p>
                                    </div>
                                <vs-dropdown-menu color="#fff" class="vx-navbar-dropdown actions-dropdown profileDropdown add_lebel_drpdwn"  >
                                    <span class="drpdwn_label">Label as:</span>
                                    <div class="search">
                                    <vs-input icon-pack="feather" @input="filterLabels" icon="icon-search" v-model.lazy="searchtxt" placeholder="Search"
                                        class="is-label-placeholder" />
                                    </div>
                                    <VuePerfectScrollbar>
                                    <ul style="min-width: 9rem" class="profileMenu" >
                                        <template v-for="colr in filteredList">
                                            <li :style="{'background-color':colr['color']}">
                                                <vs-checkbox v-model="colr.selectedColor" @input="manageLabel">
                                                    {{checkProperty(colr,'name')}}
                                                </vs-checkbox>
                                            </li>
                                        </template>
                                    </ul>
                                    </VuePerfectScrollbar>
                                    <div class="btn_wrap">
                                        <vs-button color="success" :disabled="loadingLabel" @click="openCreateLabel" class="save" type="filled"><img src="@/assets/images/main/create_label.svg"> Create New</vs-button>
                                    </div>
                                </vs-dropdown-menu>
                                </vs-dropdown>
                        </li>
                        </ul>
                        
                    </div>
                    <messageAssign :actionCompleted="actionCompleted" :petition="petition" :callFromDetails="callFromDetails" @updateUserIds="updateUserIds" :message="message" />
                  </div>

      </div> -->

    <div class="message_sec">
        <div class="message_lables">
            <div class="new_label_as">
                <ul class="label_list">
                    <li class="label_new">Labels</li>
                    <template
                        v-if="checkProperty(message, 'evalLabelIds') && checkProperty(message, 'evalLabelIds', 'length') > 0">
                        <template v-for="item in message['evalLabelIds'] ">
                            <li :style="{ 'background-color': item['color'] }">{{ checkProperty(item, 'name') }}<em
                                    @click="deleteLabel(item)">x</em>
                            </li>
                        </template>
                    </template>
                    <li class="add_li">
                        <b-dropdown size="lg" variant="link" right no-caret>
                            <template #button-content>
                                <span @click="processLabels()">+</span>
                                <div class="tooltip_cnt">
                                    <p>Add Label</p>
                                </div>
                            </template>
                            <b-dropdown-form>
                                <span class="drpdwn_label">Label as:</span>
                                <div class="search_area">
                                    <input type="text" class="form-control" :placeholder="'Search'" v-model="searchtxt"
                                        v-on="listeners" @input="filterLabels">
                                    <img src="@/assets/images/search.svg" class="search_icon" alt="search">
                                </div>
                                <VuePerfectScrollbar>
                                    <ul class="checklist">
                                        <template v-for="(colr, indx) in filteredList">
                                            <li :style="{ 'background-color': colr['color'] }" :key="colr._id">
                                                <b-form-checkbox class="table_check" v-model="colr.selectedColor"
                                                    @input="manageLabel" :id="message._id + colr['_id'] + '' + indx"
                                                    :name="colr['_id'] + '' + indx">
                                                    {{ checkProperty(colr, 'name') }}
                                                </b-form-checkbox>
                                            </li>
                                        </template>
                                    </ul>
                                </VuePerfectScrollbar>

                            </b-dropdown-form>
                            <template>
                                <div class="btn_wrap">
                                    <button class="primary_btn" type="filled" @click="openCreateLabel">
                                        <!-- <img src="@/assets/images/main/create_label.svg">  -->
                                        Create New
                                    </button>
                                </div>
                            </template>
                        </b-dropdown>
                    </li>
                </ul>

            </div>
            <!-- <messageAssign /> -->
        </div>
    </div>
</template>
<script>
import selectField from "@/views/forms/simpleselectOption.vue";
import messageAssign from "@/views/messages/messageAssign.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    props: {
        actionCompleted: {
            type: Boolean,
            default: false
        },
        trimcontent: false,
        message: {
            type: Object,
            default: null
        },
        labelsList: {
            type: Array,
            default: []
        },
        callFromDetails: {
            type: Boolean,
            dafault: false
        },
        petition: {
            type: Object,
            default: null
        }
    },
    components: {
        messageAssign,
        selectField,
        VuePerfectScrollbar
    },
    data: () => ({
        openAssignPopup: false,
        assignedUser: null,
        textLabelsList: [],
        loadingLabel: false,
        filteredList: [],
        searchtxt: ''
    }),
    mounted() {
        this.searchtxt = ''
    },
    methods: {
        getTrimmedContent(content) {
            // Strip HTML tags using a temporary element
            const tempElement = document.createElement("div");
            tempElement.innerHTML = content;
            const plainText = tempElement.textContent || tempElement.innerText || "";

            // Trim the content to 200 characters and add "..." if needed
            const trimmedText = plainText.length > 100 ? plainText.slice(0, 100) + "..." : plainText;

            return trimmedText;
        },
        deleteLabel(val) {
            let payload = {
                messageId: this.checkProperty(this.message, '_id'),
                labels: [],
                //updateRemoveLabel:true
            }
            let selectedList = [];
            selectedList = _.filter(this.message['evalLabelIds'], (labeItd) => {
                return labeItd['_id'] != val['_id']
            });
            payload['labels'] = selectedList;
            let path = '/mail-inbox/manage-labels'
            this.$store.dispatch("commonAction", { 'data': payload, 'path': path }).then(response => {
                let obj = {
                    labels: payload['labels'],
                    messageId: this.checkProperty(this.message, '_id')
                }
                this.$emit('updateLabels', obj);
                this.showToster({ message: response.message, isError: false });
            }).catch((err) => { })

        },
        filterLabels() {
            this.filteredList = [];
            setTimeout(() => {
                this.filteredList = _.filter(this.textLabelsList, (item) => {
                    return item['name'].includes(this.searchtxt)
                })
            })

        },
        updateUserIds(val) {
            this.$emit('updateUserIds', val)
        },
        manageLabel(callFrom = false) {
            let payload = {
                messageId: this.checkProperty(this.message, '_id'),
                labels: [],
            }
            let selectedList = []
            if (this.checkProperty(this.filteredList, 'length') > 0) {
                selectedList = _.filter(this.filteredList, (item) => {
                    return item['selectedColor'] == true
                })
            }
            payload['labels'] = selectedList;
            let path = '/mail-inbox/manage-labels'
            this.$store.dispatch("commonAction", { 'data': payload, 'path': path }).then(response => {
                let obj = {
                    labels: payload['labels'],
                    messageId: this.checkProperty(this.message, '_id')
                }
                this.$emit('updateLabels', obj);
                this.showToster({ message: response.message, isError: false });
            }).catch((err) => { })
        },
        openCreateLabel() {
            this.$emit('openCreateLabel', this.message)
        },
        processLabels() {
            this.textLabelsList = [];
            this.filteredList = [];
            if (this.checkProperty(this.labelsList, 'length') > 0) {
                let tempList = [];
                if (this.checkProperty(this.message, 'evalLabelIds') && this.checkProperty(this.message, 'evalLabelIds', 'length') > 0) {
                    _.forEach(this.labelsList, (obj) => {
                        obj = Object.assign(obj, { 'selectedColor': false });
                        _.forEach(this.message['evalLabelIds'], (labelId) => {
                            if (labelId['_id'] == obj['_id']) {
                                obj['selectedColor'] = true;
                            }
                        })
                        tempList.push(obj);
                    })
                } else {
                    _.forEach(this.labelsList, (obj) => {
                        obj = Object.assign(obj, { 'selectedColor': false });
                        tempList.push(obj);
                    })
                }
                if (tempList && this.checkProperty(tempList, 'length') > 0) {
                    this.textLabelsList = _.cloneDeep(tempList);
                    this.filteredList = _.cloneDeep(tempList);
                }
            }
        }
    }
}
</script>