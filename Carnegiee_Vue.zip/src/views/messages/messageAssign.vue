<template>
<!-- <div class="assigning_wraper"  >
    <vs-dropdown vs-custom-content vs-trigger-click class="cursor-pointer">
        <div class="add_lebel_drpdwn_wrapper">
            <span class="assigned_label">Assigned To</span>
            <template v-if="checkProperty(assignedUserName,'length')>0">
                <span  class="assigned_list">{{assignedUserName[0]}}
                     <template v-if="checkProperty(assignedUserName,'length')>1" > ..</template> 
                    <em v-if="checkProperty(assignedUserName,'length')>1">+{{checkProperty(assignedUserName,'length') - 1}}</em>
                </span>
            </template>
            <template v-else>
                <span class="assigned_list">--</span>
            </template>
        </div>
        <vs-dropdown-menu color="#fff" class="vx-navbar-dropdown actions-dropdown profileDropdown add_lebel_drpdwn add_assign_drpdwn" >
        <span class="drpdwn_label">Assigned to</span>
        <div class="search">
            <vs-input icon-pack="feather" icon="icon-search" @input="filterUser" v-model.lazy="searchString" placeholder="Search"
            class="is-label-placeholder" />
        </div>
        <template v-if="checkProperty(usersList,'length')>0">
            <VuePerfectScrollbar>
                <ul style="min-width: 9rem" class="profileMenu"  >
                    <template v-for="item in usersList ">
                        <li>
                        <vs-checkbox v-model="item.assigneSelected" :disabled="checkProperty(message,'completed')" @input="assignUserToMessage">
                            {{checkProperty(item,'name')}}
                        </vs-checkbox>
                        </li>
                    </template>
                </ul>
            </VuePerfectScrollbar>
        </template>
        </vs-dropdown-menu>
    </vs-dropdown>
     <selectField  :display="true" :multiple="true"   :fieldsArray="[]"   :optionslist="usersList" v-model="assignedUser" :tplsection="''"  :fieldName="'assignedUser'"   placeHolder="Assigned To" />
</div> -->
    <div class="assigning_wraper">
        <b-dropdown size="lg" variant="link" right no-caret>
            <template #button-content>
                <div class="add_lebel_drpdwn_wrapper">
                    <span class="assigned_label">Assigned To</span>
                    <span class="assigned_list">Assigner Name <em>+1</em></span>
                </div>
            </template>
            <b-dropdown-form>
                <span class="drpdwn_label">Assigned to</span>
                <div class="search_area">
                    <input type="text" class="form-control" :placeholder="'Search'" v-model="value" v-on="listeners" >
                    <img src="@/assets/images/search.svg" class="search_icon" alt="search">
                </div>
                <VuePerfectScrollbar>
                    <ul class="checklist">
                        <li>
                            <b-form-checkbox class="table_check">Case</b-form-checkbox>
                        </li>
                        <li>
                            <b-form-checkbox class="table_check">Case</b-form-checkbox>
                        </li>
                        <li>
                            <b-form-checkbox class="table_check">Case</b-form-checkbox>
                        </li>
                    </ul>
                </VuePerfectScrollbar>
            </b-dropdown-form>
        </b-dropdown>
    </div>
</template>
<script>
import selectField from "@/views/forms/simpleselectOption.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    components: {
        selectField,
        VuePerfectScrollbar
    },
    data: ()=>({
        usersList:[],
        assignedUser:null,
        assignedUserName:[],
        debounce:null,
        searchString:'',
    }),
    props:{
        actionCompleted:{
            type:Boolean,
            default:false
        },
        message:{
            type:Object,
            default:null
        },
        callFromDetails:{
            type:Boolean,
            default:false
        },
        petition:{
            type:Object,
            default:null
        }
    },
    methods:{
        filterUser(){
            clearTimeout(this.debounce)
            this.debounce = setTimeout(() => {
                this.getusers()
            }, 900)
        },
        getusers() {
            this.assignedUserName = [];
            this.usersList = [];
            this.filteredList = [];
            let postdata = {
                petitionId: this.checkProperty(this.message,'petitionId'),
                petitionType:"NORMAL",  //"GC" // 'RFE', 'NORMAL' ,'PERM'
                filters:{
                    searchString: this.searchString,
                },
            };
            if(( [3].indexOf(this.checkProperty(this.message['petitionDetails'],'type'))>-1 && [15].indexOf(this.checkProperty(this.message['petitionDetails'],'subType'))>-1)){
                postdata['petitionType'] = 'PERM'
            }
            this.$store.dispatch("getcommunicationuserslist", postdata).then(response => {
                let ignoreUsers =[]
                if([3,4,5,6,7,8,9,10,11,12,13,14].indexOf(this.getUserRoleId) >-1){
                    //ignoreUsers =[51];
                }else if([50].indexOf(this.getUserRoleId) >-1){
                    ignoreUsers =[];
                }else if([51].indexOf(this.getUserRoleId) >-1){
                    ignoreUsers =[3,4,5,6,7,8,9,10,11,12,13,14];
                }
                if(ignoreUsers.length>0 && response.length>0){
                    response  = _.filter(response , (usr)=>{
                        return ignoreUsers.indexOf(usr['roleId'] )<=-1
                    })
                }
                let modifiedList = [];
                let tempList  = response
                if(this.checkProperty(this.message,'petitionDetails','type') && this.callFromDetails){
                    if([50,51].indexOf(this.getUserRoleId) <=-1){
                        let lawOffice = { _id: "Law_Firm", roleId: 65, branchId: "Law_Firm", userId: "Law_Firm", name: "Law Firm",
                            value: "Law Firm", roleName: "Law Firm", tempName: "Law Firm"
                        };
                        modifiedList.push(lawOffice);
                        let removedList = [];
                        let petitionerObj = _.find(tempList,{'roleId':50});
                        if(petitionerObj && _.has(petitionerObj,'name')){
                        petitionerObj['name'] = 'Petitioner';
                        petitionerObj['tempName'] = 'Petitioner';
                        removedList =  _.filter(tempList,(item)=>{
                            return item['roleId'] != 50
                        });
                        modifiedList.push(petitionerObj);
                        }
                        if((this.checkCHildH4 || this.checkSPouseH4) && this.checkProperty(this.message,'petitionDetails','subType') != 15 ){
                            let benObj = _.find(tempList,{'roleId':51});
                            if(benObj && _.has(benObj,'name')){
                            benObj['name'] = 'Applicant';
                            benObj['tempName'] = 'Applicant';
                            removedList =  _.filter(removedList,(item)=>{
                                return item['roleId'] != 51
                            });
                            modifiedList.push(benObj);
                            }
                        }
                        else{
                            if(removedList && this.checkProperty(removedList,'length')>0){
                                removedList =  _.filter(removedList,(item)=>{
                                return item['roleId'] != 51
                                });
                            }else{
                                removedList =  _.filter(tempList,(item)=>{
                                return item['roleId'] != 51
                                });
                            }
                        
                        }
                        if(removedList && this.checkProperty(removedList,'length')>0){
                        tempList = _.cloneDeep(removedList)
                        }
                    }
                    if([50].indexOf(this.getUserRoleId) >-1){
                        let lawOffice = {
                        _id: "Law Firm", roleId: 65, branchId: "Law_Firm", userId: "Law_Firm", name: "Law Firm", value: "Law Firm", roleName: "Law Firm", tempName: "Law Firm"
                        };
                        modifiedList.push(lawOffice);
                        let removedList = [];
                        if((this.checkCHildH4 || this.checkSPouseH4) && this.checkProperty(this.message,'petitionDetails','subType') != 15){
                            let benObj = _.find(tempList,{'roleId':51});
                            if(benObj && _.has(benObj,'name')){
                            benObj['name'] = 'Applicant';
                            benObj['tempName'] = 'Applicant';
                            removedList =  _.filter(tempList,(item)=>{
                                return item['roleId'] != 51
                            });
                            modifiedList.push(benObj);
                            }
                        }else{
                        if(removedList && this.checkProperty(removedList,'length')>0){
                            removedList =  _.filter(removedList,(item)=>{
                            return item['roleId'] != 51
                            });
                        }else{
                            removedList =  _.filter(tempList,(item)=>{
                            return item['roleId'] != 51
                            });
                        }
                        
                        }
                        if(removedList && this.checkProperty(removedList,'length')>0){
                        tempList = _.cloneDeep(removedList)
                        }
                    }
                    if(this.checkProperty(this.message,'toUserIds') && this.checkProperty(this.message,'toUserIds','length')>0){
                        this.assignedUserName= []
                    _.map(modifiedList ,(obj)=>{
                        obj = Object.assign(obj,{'assigneSelected':false});
                        if(this.message['toUserIds'].indexOf(obj['_id'])>-1 && [50,51].indexOf(this.getUserRoleId) <=-1){
                            if(obj['roleId'] == 50){
                                obj['name'] ='Petitioner'
                            }
                            obj['assigneSelected'] = true;
                            this.assignedUserName.push(obj['name'])
                        }
                    })
                    _.forEach(tempList ,(obj)=>{
                        obj = Object.assign(obj,{'assigneSelected':false});
                        if(this.message['toUserIds'].indexOf(obj['_id'])>-1){
                            obj['assigneSelected'] = true;
                            if(obj['roleId'] != 50){
                                this.assignedUserName.push(obj['name'])
                            }
                            
                        }
                        modifiedList.push(obj);
                    })
                    }else{
                        _.forEach(tempList ,(obj)=>{
                            obj = Object.assign(obj,{'assigneSelected':false});
                            modifiedList.push(obj);
                        })
                    }
                    this.usersList = modifiedList;
                }else{
                    tempList=[]
                    if(this.checkProperty(this.message,'toUserIds') && this.checkProperty(this.message,'toUserIds','length')>0){
                    _.forEach(response ,(obj)=>{
                        obj = Object.assign(obj,{'assigneSelected':false});
                        if(this.message['toUserIds'].indexOf(obj['_id'])>-1){
                            obj['assigneSelected'] = true;
                            this.assignedUserName.push(obj['name'])
                        }
                        tempList.push(obj);
                    })
                    }else{
                        _.forEach(response ,(obj)=>{
                            obj = Object.assign(obj,{'assigneSelected':false});
                            tempList.push(obj);
                        })
                    }
                    this.usersList = tempList;
                }
                

                // let modifiedList = [];
                // if([50].indexOf(this.getUserRoleId) <=-1){
                //     _.forEach(tempList,(item)=>{
                //         modifiedList.push(item)
                //     })
                // }
                
                //this.filteredList = tempList
            });
        },
        assignUserToMessage(){
            this.assignedUserName = [];
            let payload ={
                messageId:this.checkProperty(this.message,'_id'),
                userIds:[],
                notifyNow:true,
            }
            if( this.callFromDetails && this.usersList && this.checkProperty(this.usersList,'length')>0){
                let findOb = _.filter(this.usersList,{'_id':'Law_Firm' ,"assigneSelected":true})
                if(findOb && findOb.length>0){
                    let tempUsersList =[];
                  
                     let uList = _.cloneDeep(this.usersList);
                     this.usersList =[];
                    _.forEach(uList,(itm)=>{
                        if(itm['_id'] == 'Law_Firm'){
                            itm['assigneSelected'] = true;
                        }else{
                            itm['assigneSelected'] = false;
                        }
                        tempUsersList.push(itm);   
                    })
                    setTimeout(()=>{
                        this.usersList = _.cloneDeep(tempUsersList);
                    },0)
                }
            }
            let selectedList = []
            if(this.checkProperty(this.usersList,'length')>0){
                selectedList = _.filter(this.usersList,(item)=>{
                    return item['assigneSelected'] == true
                })
            }
            let tempList = []
            if(selectedList && this.checkProperty(selectedList,'length')>0){
                _.forEach(selectedList,(itm)=>{
                    if(this.callFromDetails && [50,51].indexOf(this.getUserRoleId) <=-1 && itm['roleId'] == 50){
                        itm['name'] = 'Petitioner'
                    }
                    this.assignedUserName.push(itm['name'])
                })
                tempList  = _.map(selectedList,'_id')
            }
            
            payload['userIds'] = tempList;
            let path='/communication/assign-to-user'
            this.$store.dispatch("commonAction", {'data':payload,'path':path}).then(response => {
                let obj={
                    toUserList:selectedList,
                    userIds:payload['userIds'],
                    messageId:this.checkProperty(this.message,'_id')
                }
                this.$emit('updateUserIds',obj);
                this.showToster({message:response.message ,isError:false});
            }).catch((err)=>{ })
        },
        PrepopulateUsers(){
            this.assignedUserName = [];
            if(this.checkProperty(this.message,'toUserList') && this.checkProperty(this.message,'toUserList','length')>0){
                let list = [];
                _.forEach(this.message['toUserList'],(obj)=>{
                    if(obj['roleId'] == 50 && this.checkProperty(this.message,'petitionDetails','type') && this.callFromDetails && [50,51].indexOf(this.getUserRoleId) <=-1){
                        obj['name'] = 'Petitioner'
                    }
                    list.push(obj['name'])
                })
                this.assignedUserName = list;
            }
        }
    },
    mounted(){
        this.PrepopulateUsers()
        //this.getusers()
    },
    computed:{
        checkCHildH4(){
      let returnVal = false;
      if(this.checkProperty(this.petition,'dependentsInfo','childrens') && this.checkProperty(this.petition['dependentsInfo'],'childrens','length')>0 ){
        _.forEach(this.petition['dependentsInfo']['childrens'],(item)=>{
          if(_.has(item,'h4Required') && this.checkProperty(item,'h4Required') && _.has(item,'h4EADRequired') && this.checkProperty(item,'h4EADRequired') ){
            returnVal = true;
            return returnVal;
          }else if (this.checkProperty(item,'h4Required')){
            returnVal = true;
            return returnVal;
          }else if (this.checkProperty(item,'h4EADRequired')){
            returnVal = true;
            return returnVal;
          }
        })
      }
      return returnVal;
    },
    checkSPouseH4(){
      let returnVal = false;
      if(this.checkProperty(this.petition,'dependentsInfo','spouse')){
        if(this.checkProperty(this.petition['dependentsInfo'],'spouse','h4Required') && this.checkProperty(this.petition['dependentsInfo'],'spouse','h4EADRequired')){
          returnVal = true;
          return returnVal;
        }else if(this.checkProperty(this.petition['dependentsInfo'],'spouse','h4Required')){
          returnVal = true;
          return returnVal;
        }else if(this.checkProperty(this.petition['dependentsInfo'],'spouse','h4EADRequired')){
          returnVal = true;
          return returnVal;
        }
      }
      return returnVal;
    },
    }
}
</script>