<template>
  <div class="account_page">
    <header class="header_customer">
      <div class="container">
        <div class="header_inner">
            <div class="logo">
                <a href="#"><img src="@/assets/images/logo_carne.png"></a>
            </div>
            <div class="right">
                <figure class="support_logo"><img src="@/assets/images/Platinum_Supporter_Logo.png"></figure>
            </div>
        </div>
      </div>
    </header>
    <div class="inner_banner">
      <h2>My Account</h2>
    </div>
    <div class="account_tabs">
      <div class="container">
        <div class="action_tab">
          <b-tabs>
            <b-tab active>
              <template #title>
                <img src="@/assets/images/requests.svg" class="in"> <img src="@/assets/images/requests-white.svg" class="out"> Evaluations
              </template>
              <div class="filter_sec">
                <div class="filter-flex">
                  <searchInput :place-holder="'Search…'"/>
                  <simpleSelect 
                  :multiple="false" :wrapclass="'priority'"
                    :optionslist="priorityList" :display="true"
                    :place-holder="'Priority'" :searchable="false" :required="false"
                    :close-on-select="true" :clear-on-select="true"  />
                    <simpleSelect 
                    :multiple="false" :wrapclass="'priority'"
                      :optionslist="priorityList" :display="true"
                      :place-holder="'Status'" :searchable="false" :required="false"
                      :close-on-select="true" :clear-on-select="true"  />
                </div>
                <div class="filters_right">
                  <button class="add_btn" @click="gotoPage('/create-request')"><span></span><em>Create Request</em></button>
                </div>
              </div>
              <div class="table-responsive mb-5">
                <table class="table account_table">
                  <thead>
                    <tr>
                      <th>Request #</th>
                      <th>Type of Evaluations</th>
                      <th>Beneficiary</th>
                      <th>Priority</th>
                      <th>Due Date</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <span class="request_id"><a @click="isShowing ^= true">E-5153</a></span>
                      </td>
                      <td>
                        <div class="evalution_type">
                          <span>Work Experience Evaluation</span>
                          <div class="evalution_dropdown">
                            <em class="count" id="popover-target-1">+4</em>
                              <b-popover custom-class="evalution_list_wrap" target="popover-target-1" triggers="hover" placement="top" fallback-placement="flip">
                                  <template>
                                    <ul>
                                      <li>Specialty Occupation Expert Opinions (Position Evaluations)</li>
                                      <li>Employment Based 2nd Preference (EB-2A/EB-2B) Expert Opinion</li>
                                      <li>E-2 Treaty Employee Expert Opinion</li>
                                      <li>Expert Opinion Letter, Academic Evaluation & Work Experience Evaluation Combined</li>
                                    </ul>
                                  </template>
                            </b-popover>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div class="beneficiary_sec">
                          <span class="icon"><img src="@/assets/images/profile-user.png"></span>
                          <span>Alex Mecheal</span>
                        </div>
                      </td>
                      <td><span>Standard</span></td>
                      <td><span class="due-date">3 Mar 2023</span></td>
                      <td><span class="status requested">Requested</span></td>
                    </tr>
                    <tr>
                      <td>
                        <span class="request_id">E-7618</span>
                      </td>
                      <td>
                        <div class="evalution_type">
                          <span>Expert Opinion Letter, Academic Evaluation & Work Experience Evaluation Combined</span>
                        </div>
                      </td>
                      <td>
                        <div class="beneficiary_sec">
                          <span class="icon"><img src="@/assets/images/profile-user.png"></span>
                          <span>Alex Mecheal</span>
                        </div>
                      </td>
                      <td><span class="rush">Rush</span></td>
                      <td><span>9 Mar 2023</span></td>
                      <td><span class="status pending">Pending</span></td>
                    </tr>
                    <tr>
                      <td>
                        <span class="request_id">E-8426</span>
                      </td>
                      <td>
                        <div class="evalution_type">
                          <span>Employment Based 2nd Preference (EB-2A/EB-2B) Expert Opinion</span>
                        </div>
                      </td>
                      <td>
                        <div class="beneficiary_sec">
                          <span class="icon"><img src="@/assets/images/profile-user.png"></span>
                          <span>Alex Mecheal</span>
                        </div>
                      </td>
                      <td><span class="rush">Rush</span></td>
                      <td><span>9 Mar 2023</span></td>
                      <td><span class="status confirmed">Confirmed</span></td>
                    </tr>
                    <tr>
                      <td>
                        <span class="request_id">E-4253</span>
                      </td>
                      <td>
                        <div class="evalution_type">
                          <span>Employment Based 2nd Preference (EB-2A/EB-2B) Expert Opinion</span>
                        </div>
                      </td>
                      <td>
                        <div class="beneficiary_sec">
                          <span class="icon"><img src="@/assets/images/profile-user.png"></span>
                          <span>Alex Mecheal</span>
                        </div>
                      </td>
                      <td><span>Standard</span></td>
                      <td><span>9 Mar 2023</span></td>
                      <td>
                        <div class="d-flex">
                          <button class="primary_btn pay_btn">Pay</button>
                          <span class="status pending_payment">Pending Payment</span>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <span class="request_id">E-4253</span>
                      </td>
                      <td>
                        <div class="evalution_type">
                          <span>Employment Based 2nd Preference (EB-2A/EB-2B) Expert Opinion</span>
                        </div>
                      </td>
                      <td>
                        <div class="beneficiary_sec">
                          <span class="icon"><img src="@/assets/images/profile-user.png"></span>
                          <span>Alex Mecheal</span>
                        </div>
                      </td>
                      <td><span>Standard</span></td>
                      <td><span>9 Mar 2023</span></td>
                      <td><span class="status inprocess">In Process</span></td>
                    </tr>
                    <tr>
                      <td>
                        <span class="request_id">E-4253</span>
                      </td>
                      <td>
                        <div class="evalution_type">
                          <span>Employment Based 2nd Preference (EB-2A/EB-2B) Expert Opinion</span>
                        </div>
                      </td>
                      <td>
                        <div class="beneficiary_sec">
                          <span class="icon"><img src="@/assets/images/profile-user.png"></span>
                          <span>Alex Mecheal</span>
                        </div>
                      </td>
                      <td><span>Standard</span></td>
                      <td><span>9 Mar 2023</span></td>
                      <td><span class="status delivered">Delivered</span></td>
                    </tr>
                  </tbody>
                </table>
                <div class="pagination-sec">
                  <div class="per-page">
                    <label class="page_label">1-20 of 50 Results</label>
                  </div>
                  <b-pagination 
                    v-model="currentPage"
                    :total-rows="rows"
                      :per-page="perPage">
                  </b-pagination>
                </div>
              </div> 
              
              <div class="back" v-show="isShowing">
                <a @click="isShowing ^= true"><img src="@/assets/images/chevron-left.svg">Back</a>
              <div class="work_exp">
                <div class="rq_header">
                  <div class="rq-number">
                    <h5>Evaluations / <a href="#">#E-5153</a></h5>
                    <div class="evalution_type">
                      <span>Work Experience Evaluation</span>
                      <div class="evalution_dropdown">
                        <em class="count" id="popover-target-5">+4</em>
                          <b-popover custom-class="evalution_list_wrap" target="popover-target-5" triggers="hover" placement="top" fallback-placement="flip">
                              <template>
                                <ul>
                                  <li>Specialty Occupation Expert Opinions (Position Evaluations)</li>
                                  <li>Employment Based 2nd Preference (EB-2A/EB-2B) Expert Opinion</li>
                                  <li>E-2 Treaty Employee Expert Opinion</li>
                                  <li>Expert Opinion Letter, Academic Evaluation & Work Experience Evaluation Combined</li>
                                </ul>
                              </template>
                        </b-popover>
                      </div>
                    </div>
                  </div>
                  <div class="rq-review">
                    <div class="due_date">
                      <h4><span>Due Date</span> 17 Feb 2023</h4>
                      <figure class="due_date_icon"><img src="@/assets/images/calender.png"></figure>
                    </div>
                    <div class="status rush"><img src="@/assets/images/clock.png"> Rush</div>
                    <div class="status waiting_for_review status_v2"><span></span> Waiting for review</div>
                  </div>
                </div>
                <section class="timeline" show-day-and-month="true">
                  <div class="wrapper-timeline">
                    <div class="wrapper-item">
                      <div class="section-year">
                        <p> 5:24 PM </p>
                        <p>2 FEB 2023 </p>
                      </div>
                      <section  class="timeline-item">
                        <div class="item">
                          <span class="status_dot"><img src="@/assets/images/comment.png"> </span>
                          <div class="drop_files">
                            <h4>Admin requested to select the professor</h4>
                            <fileUploadDrag :wrapclass="'mb20'" :multiple="true"/> 
                          </div>
                          <div class="select_user">
                            <p>Select Professor</p>
                            <div class="d-flex select_user_flex">
                                <div class="check_user">
                                  <div class="radio_group" :class="wrapclass">
                                      <input type="radio" id="proceed" :name="fieldName" v-model="proceed">
                                      <label for="proceed" class="radio_btn">
                                          <div class="check"></div>
                                          <p>Jacob Jones <span>Master of Science from Biju Patnaik</span></p>
                                          <a @click="$bvModal.show('profile_model')">View Profile</a>
                                      </label>
                                  </div>
                                </div>
                                <div class="check_user">
                                  <div class="radio_group">
                                      <input type="radio" id="proceed1" :name="process" v-model="proceed1">
                                      <label for="proceed1" class="radio_btn">
                                          <div class="check"></div>
                                          <p>Jacob Jones <span>Master of Science from Biju Patnaik…</span></p>
                                          <a @click="$bvModal.show('profile_model')">View Profile</a>
                                      </label>
                                  </div>
                                </div>
                                <div class="check_user">
                                  <div class="radio_group">
                                      <input type="radio" id="process2" :name="process" v-model="process2">
                                      <label for="process2" class="radio_btn">
                                          <div class="check"></div>
                                          <p>Jacob Jones <span>Master of Science from Biju Patnaik…</span></p>
                                          <a @click="$bvModal.show('profile_model')">View Profile</a>
                                      </label>
                                  </div>
                                </div>
                                <div class="check_user">
                                  <div class="radio_group" :class="wrapclass">
                                      <input type="radio" id="process" :name="process" v-model="process3">
                                      <label for="process" class="radio_btn">
                                          <div class="check"></div>
                                          <p>Jacob Jones <span>Master of Science from Biju Patnaik…</span></p>
                                          <a @click="$bvModal.show('profile_model')">View Profile</a>
                                      </label>
                                  </div>
                                </div>
                            </div>
                            <button class="primary_btn md">Submit</button>
                          </div>
                        </div>
                      </section>
                    </div>
                    <div  class="wrapper-item unique-timeline">
                      <div  class="section-year">
                        <p> 12:50PM</p>
                        <p > 2 FEB 2023 </p>
                      </div>
                      <section  class="timeline-item">
                        <div class="item">
                          <span class="dot"><img src="@/assets/images/comment.png"> </span>
                          <h4>Admin requested for payment</h4>
                          <button class="primary_btn md">Pay now</button>
                        </div>
                      </section>
                    </div>
                    <div  class="wrapper-item unique-timeline">
                      <div  class="section-year">
                        <p> 12:50PM</p>
                        <p > 2 FEB 2023 </p>
                      </div>
                      <section  class="timeline-item">
                        <div class="item">
                          <span class="dot"><img src="@/assets/images/comment.png"> </span>
                          <h4>Payment Status</h4>
                          <div class="paid-sec">
                            <p><img src="@/assets/images/subtraction.svg"> Paid</p>
                            <button class="form-cancel">View Details</button>
                          </div>
                        </div>
                      </section>
                    </div>
                    <div  class="wrapper-item unique-timeline">
                      <div  class="section-year">
                        <p> 12:50PM</p>
                        <p > 2 FEB 2023 </p>
                      </div>
                      <section  class="timeline-item">
                        <div class="item">
                          <span class="dot"><img src="@/assets/images/comment.png"> </span>
                          <h4>You have selected</h4>
                          <div class="paid-sec">
                            <div class="d-flex"><img src="@/assets/images/subtraction.svg"></div> <div><p>Jones <span>Master of Science from Biju Patnaik University of Technology</span></p>   </div>
                          </div>
                        </div>
                      </section>
                    </div>
                    <div  class="wrapper-item unique-timeline">
                      <div  class="section-year">
                        <p> 12:50PM</p>
                        <p > 2 FEB 2023 </p>
                      </div>
                      <section  class="timeline-item">
                        <div class="item">
                          <span class="dot"><img src="@/assets/images/badge.svg"> </span>
                          <h4>Evaluation Documents</h4>
                            <div class="doc_files">
                              <ul>
                                <li class="">
                                  <b-button id="popover-target-4">
                                    <figure><img src="@/assets/images/pdf-file-format.svg"></figure>
                                  </b-button>
                                  <b-popover target="popover-target-4" triggers="hover" placement="top">
                                    Academic Transcripts.pdf <span>Uploaded by </span> Admin
                                  </b-popover>
                                </li>
                                <li >
                                  <b-button id="popover-target-6">
                                    <figure><img src="@/assets/images/pdf-file-format.svg"></figure>
                                  </b-button>
                                  <b-popover target="popover-target-6" triggers="hover" placement="top">
                                    Academic Transcripts.pdf <span>Uploaded by </span> Admin
                                  </b-popover>
                                </li>
                              </ul>
                            </div>
                        </div>
                      </section>
                    </div>
                  </div>
                </section>
                <div class="rq_header mt-5">
                  <div class="rq-select">
                    <div class="rq-number">
                      <h5>Beneficiary</h5>
                    </div>
                  </div>
                </div>
                <div class="ev_doc beneficiary mb-5">
                  <div class="beneficiary_detailes">
                    <div class="profile">
                      <figure><img src="@/assets/images/user.svg"></figure>
                    </div>
                    <div class="profile_detailes d-flex">
                      <div class="user-profile">
                        <h4 class="mb-0">Michael Lawis-Andersen</h4>
                        <p><img src="@/assets/images/briefcase.svg" class="me-1"> Sr. UX Manager</p>
                      </div>
                      <div class="user-profile">
                        <p>Beneficiary’s Firm</p>
                        <h4>Stetson Hat Legal Group</h4>
                      </div>
                      <div class="user-profile">
                        <p>Beneficiary’s Degree</p>
                        <h4>Bachelor Of Fine Arts (B.F.A.)</h4>
                      </div>
                      <div class="user-profile">
                        <p>Desired US equivalent degree</p>
                        <h4>10 years as UX Designing</h4>
                      </div>
                      <div class="user-profile">
                        <p>Beneficiary’s Firm</p>
                        <h4>Stetson Hat Legal Group</h4>
                      </div>
                      <div class="user-profile">
                        <p>Occupation SOC code (Only needed for Expert Opinion)</p>
                        <h4>35-3023</h4>
                      </div>
                    </div>
                  </div>
                </div>
                </div>
              </div>
            </b-tab>
            <b-tab>
              <template #title>
                <img src="@/assets/images/payment.svg" class="in"> <img src="@/assets/images/payment-white.svg" class="out">Payment
              </template>
              <div class="filter_sec">
                <div class="filter-flex">
                  <searchInput :place-holder="'Search…'"/>
                  <simpleSelect 
                  :multiple="false" :wrapclass="'priority'"
                    :optionslist="priorityList" :display="true"
                    :place-holder="'Priority'" :searchable="false" :required="false"
                    :close-on-select="true" :clear-on-select="true"  />
                    <simpleSelect 
                    :multiple="false" :wrapclass="'priority'"
                      :optionslist="priorityList" :display="true"
                      :place-holder="'Status'" :searchable="false" :required="false"
                      :close-on-select="true" :clear-on-select="true"  />
                </div>
                <div class="filters_right">
                  <button class="add_btn" @click="gotoPage('/create-request')"><span></span><em>Create Request</em></button>
                </div>
              </div>
              <div class="table-responsive mb-5">
                <table class="table account_table">
                  <thead>
                    <tr>
                      <th>Request #</th>
                      <th>Type of Evaluations</th>
                      <th>Amount</th>
                      <th>Priority</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <span class="request_id">E-5153</span>
                      </td>
                      <td>
                        <div class="evalution_type">
                          <span>Work Experience Evaluation</span>
                          <div class="evalution_dropdown">
                            <em class="count" id="popover-target-2">+4</em>
                              <b-popover custom-class="evalution_list_wrap evalution_payment_list" target="popover-target-2" triggers="hover" placement="top" fallback-placement="flip">
                                  <template>
                                    <ul>
                                      <li><span>$350</span> Specialty Occupation Expert Opinions (Position Evaluations)</li>
                                      <li><span>$350</span> Employment Based 2nd Preference (EB-2A/EB-2B) Expert Opinion</li>
                                      <li><span>$350</span> E-2 Treaty Employee Expert Opinion</li>
                                      <li><span>$350</span> Expert Opinion Letter, Academic Evaluation & Work Experience Evaluation Combined</li>
                                    </ul>
                                  </template>
                            </b-popover>
                          </div>
                        </div>
                      </td>
                      <td>
                        <span>$350</span>
                      </td>
                      <td><span>Standard</span></td>
                      <td><span class="status waiting_for_invoice">Waiting for Invoice</span></td>
                    </tr>
                    <tr>
                      <td>
                        <span class="request_id">E-7618</span>
                      </td>
                      <td>
                        <div class="evalution_type">
                          <span>Expert Opinion Letter, Academic Evaluation & Work Experience Evaluation Combined</span>
                        </div>
                      </td>
                      <td>
                        <div class="beneficiary_sec">
                          <span>$650</span>
                        </div>
                      </td>
                      <td><span class="rush">Rush</span></td>
                      <td>
                        <div class="d-flex">
                          <button class="primary_btn pay_btn">Pay</button>
                          <span class="status pending_payment">Pending Payment</span>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <span class="request_id">E-8426</span>
                      </td>
                      <td>
                        <div class="evalution_type">
                          <span>Employment Based 2nd Preference (EB-2A/EB-2B) Expert Opinion</span>
                        </div>
                      </td>
                      <td>
                        <div class="beneficiary_sec">
                          <span>$350</span>
                        </div>
                      </td>
                      <td><span class="rush">Rush</span></td>
                      <td><span class="status paid">Paid</span></td>
                    </tr>
                    <tr>
                      <td>
                        <span class="request_id">E-4253</span>
                      </td>
                      <td>
                        <div class="evalution_type">
                          <span>Employment Based 2nd Preference (EB-2A/EB-2B) Expert Opinion</span>
                        </div>
                      </td>
                      <td>
                        <div class="beneficiary_sec">
                          <span>$350</span>
                        </div>
                      </td>
                      <td><span>Standard</span></td>
                      <td>
                          <span class="status paid">Paid</span>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <span class="request_id">E-4253</span>
                      </td>
                      <td>
                        <div class="evalution_type">
                          <span>Employment Based 2nd Preference (EB-2A/EB-2B) Expert Opinion</span>
                        </div>
                      </td>
                      <td>
                        <div class="beneficiary_sec">
                          <span>$350</span>
                        </div>
                      </td>
                      <td><span>Standard</span></td>
                      <td>
                        <div class="d-flex">
                          <button class="primary_btn pay_btn">Pay</button>
                          <span class="status pending_payment">Pending Payment</span>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <span class="request_id">E-4253</span>
                      </td>
                      <td>
                        <div class="evalution_type">
                          <span>Employment Based 2nd Preference (EB-2A/EB-2B) Expert Opinion</span>
                        </div>
                      </td>
                      <td>
                        <div class="beneficiary_sec">
                          <span>$350</span>
                        </div>
                      </td>
                      <td><span>Standard</span></td>
                      <td><span class="status paid">Paid</span></td>
                    </tr>
                  </tbody>
                </table>
                <div class="pagination-sec">
                  <div class="per-page">
                    <label class="page_label">1-20 of 50 Results</label>
                  </div>
                  <b-pagination 
                    v-model="currentPage"
                    :total-rows="rows"
                    :per-page="perPage">
                  </b-pagination>
                </div>
              </div>
            </b-tab>
            <b-tab>
              <template #title>
                <img src="@/assets/images/account.png"> My Account
              </template>
              <div class="account_detailes">
                <div class="account_holder">
                  <img src="@/assets/images/my-account.png">
                  <h4>Olivia Emma</h4>
                  <p>David Raft has twenty seven years of practical experience representing employers and individuals with respect to the complexities of the immigration law procedures. He is a Senior Managing Attorney with Global Immigration Partners)</p>
                </div>
                <div class="account_holder account_form">
                  <p>Change Password</p>
                  <div class="form_group mt-3 mb-0">
                    <div class="row">
                      <div class="col-md-6  mt-2 mb-4">
                        <label  class="form_label">Change Password
                        </label>
                        <input type="text" class="form-control">
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                      <label  class="form_label">New Password
                      </label>
                      <input type="text" class="form-control">
                      </div>
                      <div class="col-md-6">
                      <label  class="form_label">Confirm Password
                      </label>
                      <input type="text" class="form-control">
                      </div>
                    </div>
                    <button class="primary_btn mt-4 md">Update</button>
                  </div>
                </div>
              </div>
            </b-tab>
          </b-tabs>
        </div>
      </div>
    </div>

    <!-- Profile Modal -->
    <b-modal id="profile_model" dialog-class="profile_model" centered hide-header hide-footer no-close-on-backdrop> 
      <template>
            <div class="profile_header">
              <div class="profile_icon">
                <img src="@/assets/images/professor.svg">
              </div>
              <div class="profile_title">
                <h6>Robert Fraczkiewicz</h6>
                <p>Ph.D. from University of Houston</p>
              </div>
              <a class="close" @click="$bvModal.hide('profile_model')"></a>
            </div>
            <div class="profile_info">
              <span class="list_header">Documents</span>
              <ul>
                <li>
                  <span class="info_header">
                    <img src="@/assets/images/pdf-file-format.svg">
                    Resume
                  </span>
                  <a href="#" class="link_btn">Download</a>
                </li>
                <li>
                  <span class="info_header">
                    <img src="@/assets/images/pdf-file-format.svg">
                    Awards
                  </span>
                  <a href="#" class="link_btn">Download</a>
                </li>
                <li>
                  <span class="info_header">
                    <img src="@/assets/images/pdf-file-format.svg">
                    Achievements
                  </span>
                  <a href="#" class="link_btn">Download</a>
                </li>
              </ul>
            </div>
      </template>
    </b-modal>
  </div>
</template>

<script>
    // @ is an alias to /src
    import vueMultiSelect from 'vue-multi-select';
    import 'vue-multi-select/dist/lib/vue-multi-select.css';
    import searchInput from '@/views/forms/searchInput.vue';
    import Timeline from 'timeline-vuejs';
    import 'timeline-vuejs/dist/timeline-vuejs.css';
    import VTooltip from 'v-tooltip'
    import radioInput from "@/views/forms/radioInput.vue";
    import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
    import simpleSelect from '@/views/forms/simpleSelect.vue';

    export default {
      name: 'requests',
      data() {
        return {
          isShowing:false,
          proceed:false,
          proceed1:false,
          proceed2:false,
          proceed3:false,
          files: [],
          showUploads: false,
          removeCard: [],
          files: null,
          messageWhenNoItems: "There arent items",
          btnLabel: values => values.length  ? values[0].name : 'Priority',
          btnLabels: values => values.length  ? values[0].name : 'Status',
          options: {
              multi: true,
              groups: true,
          },
          selected:[],
          optionsmain: [ 'Priority', 'Default Selected Option', 'This is another option', 'This one is disabled'
          ],
          selecte:[],
          statusoptions: ['Specialty Occupation Expert Opinions (Position Evaluations)', 'Default Selected Option','This is another option','This one is disabled'
          ],
          values:[],
          data: [
            { name: 'Jacob Jones', value: 'Immigration attorney 20+ years' },
            { name: 'Robert Fraczkiewicz', value:'Ph.D. from University of Houston'},
            { name: 'Ajit Jamwal', value:'Master of Science from Biju Patnaik University of Technology' },
            { name: 'Charlie Duhor', value:'Worked at Corporate and Government Experience' },
            { name: 'Michael Taiwo', value:'Ph.D. in Chemistry, University of Missouri-Columbia' },
          ],
        }
      },
      components: {
        searchInput,
        vueMultiSelect,VTooltip,
        Timeline,
        radioInput,
        fileUploadDrag,
        simpleSelect,
      },
      filters: {
        addOne(val) {
          let output = Number(val);
          output += 1;
          return output;
        },
        formatBytes(a, b) {
          if (0 == a) return "0 Bytes";
          var c = 1024,
              d = b || 2,
              e = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"],
              f = Math.floor(Math.log(a) / Math.log(c));
          return parseFloat((a / Math.pow(c, f)).toFixed(d)) + " " + e[f]
        }
      },
      methods:{
          gotoPage(path = "/") {
            this.$router.push(path);
          },
          clearFiles() {
            this.$refs['file-input'].reset()
          },
          selectFile(){
            let fileInputElement = this.$refs.file;
            fileInputElement.click();
            // ...
          },
          listUploads(e) {
            this.showUploads = true;
            let files = e.srcElement.files;

            if(files) {
              this.files = files;
            }
            
            let self = this;
                        
            for (var index = 0; index < files.length; index++) {
              // generate a new FileReader object
              var reader = new FileReader();

              // inject an image with the src url
              reader.onload = function(event) {
                const imageUrl = event.target.result;
                const thumb = document.querySelectorAll('.thumb')[index];
                self.imageUrlArray.push(imageUrl);
              }

              // when the file is read it triggers the onload 
              // event above.
              reader.readAsDataURL(files[index]);
            }
          },
          deleteItem: function(e) {
            let currentFiles = app.files;
            let target = toString(e.srcElement.value);
            let parentCard = e.srcElement.parentNode.parentNode;
            
            parentCard.classList.toggle('hidden');
            setTimeout(() => {
              parentCard.style.display = 'none';
            }, 1000);
          },
          uploadFiles(e) {
            let cardArray = [];
            
            let fileCount = app.files.length;
            for(let i = 0; i < fileCount; i++) {
              cardArray.push(`card-${i}`);
            }
            
            let cardIdsArray = [];
            
            cardArray.forEach((ref) => {

              let currentCard = document.getElementById(app.$refs[ref][0].id);
              cardIdsArray.push(currentCard);
            });
            
            cardIdsArray.forEach((id) => {
              // check if card is ticked for upload
              
              console.log(app.checkboxes);
              
              // if checkbox for this card is checked, set flag
              const uploadFlag = id.querySelectorAll('[type="checkbox"]:checked');

              // if this card has upload flag, upload
              if(uploadFlag) {
                id.classList.toggle('is-uploading');

                setTimeout(() => {
                  id.classList.toggle('hidden');

                  setTimeout(() => {
                    id.style.display = 'none';
                  }, 1000);
                }, 1000);
              }
            });

            // clear files
            app.files = [];  
          },  
          
          resetFileField(e) {
            console.log('reset');
            const fileInput = app.$refs['file-input'];
            console.log(typeof(fileInput));
            fileInput.value = '';
            app.files = [];
          },
      }
    }
</script>