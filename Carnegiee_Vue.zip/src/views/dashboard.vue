<template>
  <div class="db_page">
    <ul class="db_top_list" v-if="[1, 3].indexOf(getUserRoleId) > -1">
      <li class="top_list_cnt">
        <div class="cnt_left">
          <span class="list_heading">Pending</span>
          <span class="list_count">{{ "$" + (checkProperty(statsCount, 'pending', 'revenue') ?
            checkProperty(statsCount, 'pending', 'revenue') : '0') }} </span>
          <span class="evaluation_count">{{ checkProperty(statsCount, 'pending', 'evaluationCount') ?
            checkProperty(statsCount, 'pending', 'evaluationCount') : '0'
          }} Evaluations</span>
        </div>
        <img src="@/assets/images/db1.jpg">
      </li>
      <li class="top_list_cnt">
        <div class="cnt_left">
          <span class="list_heading">Revenue</span>
          <span class="list_count">{{ "$" + (checkProperty(statsCount, 'paid', 'revenue') ? checkProperty(statsCount,
            'paid', 'revenue') : '0') }} </span>
          <span class="evaluation_count">{{ checkProperty(statsCount, 'paid', 'evaluationCount') ?
            checkProperty(statsCount, 'paid', 'evaluationCount') : '0' }} Evaluations</span>
        </div>
        <img src="@/assets/images/db2.jpg">
      </li>
      <li class="top_list_cnt">
        <div class="cnt_left">
          <span class="list_heading">Total Evaluations</span>
          <span class="list_count">{{ checkProperty(statsCount, 'totalEvaluations') ?
            checkProperty(statsCount, 'totalEvaluations') : '0' }}</span>
          <!-- <span class="evaluation_count">{{ checkProperty(statsCount,'pending', 'evaluationCount') ? checkProperty(statsCount,'pending', 'evaluationCount') : '' }} Evaluations
      </span>-->
        </div>
        <img src="@/assets/images/db4.png">
      </li>
      <li v-if="canCreateEvaluation(getUserRoleId)" class="top_list_cnt creat_req"
        @click="gotoPage('/create-evaluation')">
        <img src="@/assets/images/plus.svg"> <span>Create Request</span>
      </li>
    </ul>
    <div class="filters_right" v-if="[4, 7].indexOf(getUserRoleId) > -1">
      <button class="add_btn ms-auto mb-3" @click="gotoPage('/create-evaluation')"><span></span><em>Create
          Request</em></button>
    </div>

    <div class="widgets_row"  v-if="[1, 2, 3, 4, 5, 6, 7, 8].indexOf(getUserRoleId) > -1">
      <div class="widget_column w-100">
        <div class="widget_wrapper pb-0">
          <div class="widget_header">
            <h6>Evaluations</h6>

            <!-- <div class="user_type_list days_filter">
              <template v-for="(customerItem, index ) in filterDaysList">
                <radioInput wrapclass="radio_group_v2" :elementId="customerItem + index" :label="customerItem.name"
                  :fieldName="'customerType'" v-model="selectedDayFilter" :fieldValue="customerItem" :disabled="isEdit"
                  @input="getFilteredChartStatsData" />
              </template>

              <customSelect v-if="false" @input="changeDaysCount" :multiple="false" :optionslist="daysCountData"
                :display="true" :place-holder="'Days'" :searchable="false" :required="false" :close-on-select="true"
                :clear-on-select="false" class="mb-0 last_n_days pl-" v-model="statsChartView" :fieldName="'user'"
                :cid="'user'" :name="'user'" />
              <customSelect @input="filterByEvaluationType" :multiple="true" :optionslist="evaluationTypesList"
                :display="true" :place-holder="'Status '" :searchable="false" :required="false" :close-on-select="true"
                :clear-on-select="false" class="mb-0 last_n_daysdash pl-10 form_selectdash"
                v-model="filterSelectedEvaluation" :hideSelected="true" :fieldName="'evaluationType'"
                :cid="'evaluationType'" :name="'user'" />
            </div> -->
              <div class="custom-datepicker eval_date_picker">
                <date-range-picker :maxDate="new Date()" :autoApply="autoApply" @update="getEvaluationstats"
                  :placeholder="'dd/mm/yyyy'" :ranges="false" :opens="'left'"
                  :locale-data="{ format: 'mmm dd, yyyy', customRangeLabel: 'Custom Range', }"
                  v-model="evlstatsDateRange"></date-range-picker>
                <span class="clear" @click="clearDateRange()"
                  v-if="checkProperty(evlstatsDateRange, 'startDate') && checkProperty(evlstatsDateRange, 'endDate')"><img
                    src="@/assets/images/close.svg"></span>
              </div>
          </div>
          <!-- <div class="widget_cnt highcharts">
            <highcharts v-if="showChart && chartLoading == false" :options="chartOptions"></highcharts>
            <NoDataFound v-else ref="NoDatacharts" content="" heading="No Data Found" type='Users'
              :loading="chartLoading" />

          </div> -->

          
          <div class="widget_cnt new_case_eve_count" >
            <div class="case_eve case_count_sec">
              <div class="item total">
                <span class="count" v-if="evalstats.total[0]">{{evalstats.total[0].totalCount}}</span>
                <span class="count" v-else>0</span>

                <span class="heading">Total</span>
                <div class="case_eve evalutions_list_sec" v-if="evalstats.total[0]">
                  <ul v-if="evalstats.total[0]">
                      <li v-for="(item, index) in evalstats.total[0].groups" v-bind:key="index">
                        <span class="eval_count">{{ checkProperty(item, 'count') ? item.count : '' }}</span>
                        <span class="eval_type">{{ checkProperty(item, 'evaluationTypeName') ? item.evaluationTypeName : '' }}</span>
                      </li>
                  </ul>
                </div>
              </div>
              <div class="item confirmed">
                 <span class="count" v-if="evalstats.confirmed[0]">{{evalstats.confirmed[0].totalCount}}</span>
                <span class="count" v-else>0</span>

                <span class="heading">Confirmed</span>
                <div class="case_eve evalutions_list_sec" v-if="evalstats.confirmed[0]">
                  <ul v-if="evalstats.confirmed[0]">
                      <li v-for="(item, index) in evalstats.confirmed[0].groups" v-bind:key="index">
                        <span class="eval_count">{{ checkProperty(item, 'count') ? item.count : '' }}</span>
                        <span class="eval_type">{{ checkProperty(item, 'evaluationTypeName') ? item.evaluationTypeName : '' }}</span>
                      </li>
                  </ul>
                </div>
              </div>
              <div class="item due">
                       <span class="count" v-if="evalstats.due[0]">{{evalstats.due[0].totalCount}}</span>
                <span class="count" v-else>0</span>

                <span class="heading">Due</span>
                <div class="case_eve evalutions_list_sec"  v-if="evalstats.due[0]">
                  <ul v-if="evalstats.due[0]">
                      <li v-for="(item, index) in evalstats.due[0].groups" v-bind:key="index">
                        <span class="eval_count">{{ checkProperty(item, 'count') ? item.count : '' }}</span>
                        <span class="eval_type">{{ checkProperty(item, 'evaluationTypeName') ? item.evaluationTypeName : '' }}</span>
                      </li>
                  </ul>
                </div>
              </div>
              <div class="item paid">

                <span class="count" v-if="evalstats.paid[0]">{{evalstats.paid[0].totalCount}}</span>
                <span class="count" v-else>0</span>

                <span class="heading">Paid</span>
                <div class="case_eve evalutions_list_sec" v-if="evalstats.paid[0]">
                  <ul v-if="evalstats.paid[0]">
                      <li v-for="(item, index) in evalstats.paid[0].groups" v-bind:key="index">
                        <span class="eval_count">{{ checkProperty(item, 'count') ? item.count : '' }}</span>
                        <span class="eval_type">{{ checkProperty(item, 'evaluationTypeName') ? item.evaluationTypeName : '' }}</span>
                      </li>
                  </ul>
                </div>
              </div>
              <div class="item overdue">
                              <span class="count" v-if="evalstats.overdue[0]">{{evalstats.overdue[0].totalCount}}</span>
                <span class="count" v-else>0</span>

                <span class="heading">Overdue</span>
                <div class="case_eve evalutions_list_sec" v-if="evalstats.overdue[0]">
                  <ul v-if="evalstats.overdue[0]">
                      <li v-for="(item, index) in evalstats.overdue[0].groups" v-bind:key="index">
                        <span class="eval_count">{{ checkProperty(item, 'count') ? item.count : '' }}</span>
                        <span class="eval_type">{{ checkProperty(item, 'evaluationTypeName') ? item.evaluationTypeName : '' }}</span>
                      </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="widgets_row widgets_row_wrap">
      <div class="widget_column" v-if="[1, 3, 8, 6, 5].indexOf(getUserRoleId) < 0">
        <div class="widget_wrapper">
          <div class="widget_header">
            <h6>New Evaluations</h6>
            <date-picker v-if="false" v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
          </div>
          <div class="widget_cnt">
            <VuePerfectScrollbar>
              <div class="table-responsive" v-if="checkProperty(newRequests, 'length') > 0">
                <table class="table most_cases_table">
                  <thead>
                    <tr>
                      <th>Request Id</th>
                      <th>Type of Evaluations</th>
                      <th>Beneficiary</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(item, index) in newRequests" v-bind:key='index' @click="goToEvaluationDetaillPage(item)">
                      <td><span>{{ checkProperty(item, 'requestId') ? item.requestId : '' }}</span></td>

                      <td>
                        <div v-if="checkProperty(item, 'docsConfig', 'length') > 0" class="evalution_type">
                          <span>{{ item.docsConfig[0].evaluationTypeName
                          }}</span>
                          <em v-if="checkProperty(item, 'docsConfig', 'length') > 1" class="count"
                            :id="'new_popover-target-' + index">{{ '+' + (checkProperty(item, 'docsConfig', 'length') -
                              1)
                            }}</em>

                          <b-popover custom-class="evalution_list_wrap" :target="'new_popover-target-' + index"
                            triggers="hover" placement="top" fallback-placement="flip">
                            <template>
                              <ul>
                                <li v-for="(evaluationItem, indx) in checkProperty(item, 'docsConfig')" :key="indx"
                                  v-if="indx > 0">{{ evaluationItem.evaluationTypeName }}</li>
                              </ul>
                            </template>
                          </b-popover>
                        </div>
                        <div v-else></div>
                      </td>
                      <td>
                        <span>{{ checkProperty(item, 'beneficiaryInformation') | formatFullname }}</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <NoDataFound v-else ref="newRequestsNoDataFoundRef" content="" heading="No Data Found" type='Users'
                :loading="newRequestsLoading" />
            </VuePerfectScrollbar>
          </div>
        </div>
      </div>

      <div class="widget_column" v-if="[1, 3, 5].indexOf(getUserRoleId) < 0">
        <div class="widget_wrapper">
          <div class="widget_header">
            <h6>Cases Due Today</h6>
            <date-picker v-if="false" v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
          </div>
          <div class="widget_cnt">
            <VuePerfectScrollbar>
              <div class="table-responsive" v-if="checkProperty(dueRequests, 'length') > 0">
                <table class="table most_cases_table">
                  <thead>
                    <tr>
                      <th>Request Id</th>
                      <th>Type of Evaluations</th>
                      <th>Beneficiary</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(item, index) in dueRequests" v-bind:key='index' @click="goToEvaluationDetaillPage(item)">
                      <td><span>{{ checkProperty(item, 'requestId') ? item.requestId : '' }}</span></td>
                      <td>
                        <div v-if="checkProperty(item, 'docsConfig', 'length') > 0" class="evalution_type">
                          <span>{{ item.docsConfig[0].evaluationTypeName
                          }}</span>
                          <em v-if="checkProperty(item, 'docsConfig', 'length') > 1" class="count"
                            :id="'confirmed_popover-target-' + index">{{ '+' + (checkProperty(item, 'docsConfig',
                              'length')
                              -
                              1)
                            }}</em>

                          <b-popover custom-class="evalution_list_wrap" :target="'confirmed_popover-target-' + index"
                            triggers="hover" placement="top" fallback-placement="flip">
                            <template>
                              <ul>
                                <li v-for="(evaluationItem, indx) in checkProperty(item, 'docsConfig')" :key="indx"
                                  v-if="indx > 0">{{ evaluationItem.evaluationTypeName }}</li>
                              </ul>
                            </template>
                          </b-popover>
                        </div>
                        <div v-else></div>
                      </td>
                      <td>
                        <span>{{ checkProperty(item, 'beneficiaryInformation') | formatFullname }}</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <NoDataFound v-else ref="dueRequestsNoDataFoundRef" content="" heading="No Data Found" type='Users'
                :loading="dueRequestsLoading" />
            </VuePerfectScrollbar>
          </div>
        </div>
      </div>

      <div class="widget_column" v-if="[1, 3, 5].indexOf(getUserRoleId) < 0">
        <div class="widget_wrapper">
          <div class="widget_header">
            <h6>Cases Overdue</h6>
            <!-- <date-picker v-if="false" v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker> -->
          </div>
          <div class="widget_cnt">
            <VuePerfectScrollbar>
              <div class="table-responsive" v-if="checkProperty(overdueRequests, 'length') > 0">
                <table class="table most_cases_table">
                  <thead>
                    <tr>
                      <th>Request Id</th>
                      <th>Type of Evaluations</th>
                      <th>Beneficiary</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(item, index) in overdueRequests" v-bind:key='index'
                      @click="goToEvaluationDetaillPage(item)">
                      <td><span>{{ checkProperty(item, 'requestId') ? item.requestId : '' }}</span></td>
                      <td>
                        <div v-if="checkProperty(item, 'docsConfig', 'length') > 0" class="evalution_type">
                          <span>{{ item.docsConfig[0].evaluationTypeName
                          }}</span>
                          <em v-if="checkProperty(item, 'docsConfig', 'length') > 1" class="count"
                            :id="'confirmed_popover-target-' + index">{{ '+' + (checkProperty(item, 'docsConfig',
                              'length')
                              -
                              1)
                            }}</em>

                          <b-popover custom-class="evalution_list_wrap" :target="'confirmed_popover-target-' + index"
                            triggers="hover" placement="top" fallback-placement="flip">
                            <template>
                              <ul>
                                <li v-for="(evaluationItem, indx) in checkProperty(item, 'docsConfig')" :key="indx"
                                  v-if="indx > 0">{{ evaluationItem.evaluationTypeName }}</li>
                              </ul>
                            </template>
                          </b-popover>
                        </div>
                        <div v-else></div>
                      </td>
                      <td>
                        <span>{{ checkProperty(item, 'beneficiaryInformation') | formatFullname }}</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <NoDataFound v-else ref="ovueDueRequestsNoDataFoundRef" content="" heading="No Data Found" type='Users'
                :loading="overdueRequestsLoading" />
            </VuePerfectScrollbar>
          </div>
        </div>
      </div>
      <div class="widget_column" v-if="[1, 3, 5].indexOf(getUserRoleId) < 0">
        <div class="widget_wrapper">
          <div class="widget_header">
            <h6>Confirmed Cases</h6>
            <date-picker v-if="false" v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
          </div>
          <div class="widget_cnt">
            <VuePerfectScrollbar>
              <div class="table-responsive" v-if="checkProperty(confirmedRequests, 'length') > 0">
                <table class="table most_cases_table">
                  <thead>
                    <tr>
                      <th>Request Id</th>
                      <th>Type of Evaluations</th>
                      <th>Beneficiary</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(item, index) in confirmedRequests" v-bind:key='index'
                      @click="goToEvaluationDetaillPage(item)">
                      <td><span>{{ checkProperty(item, 'requestId') ? item.requestId : '' }}</span></td>
                      <td>
                        <div v-if="checkProperty(item, 'docsConfig', 'length') > 0" class="evalution_type">
                          <span>{{ item.docsConfig[0].evaluationTypeName
                          }}</span>
                          <em v-if="checkProperty(item, 'docsConfig', 'length') > 1" class="count"
                            :id="'confirmed_popover-target-' + index">{{ '+' + (checkProperty(item, 'docsConfig',
                              'length')
                              -
                              1)
                            }}</em>

                          <b-popover custom-class="evalution_list_wrap" :target="'confirmed_popover-target-' + index"
                            triggers="hover" placement="top" fallback-placement="flip">
                            <template>
                              <ul>
                                <li v-for="(evaluationItem, indx) in checkProperty(item, 'docsConfig')" :key="indx"
                                  v-if="indx > 0">{{ evaluationItem.evaluationTypeName }}</li>
                              </ul>
                            </template>
                          </b-popover>
                        </div>
                        <div v-else></div>
                      </td>
                      <td>
                        <span>{{ checkProperty(item, 'beneficiaryInformation') | formatFullname }}</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <NoDataFound v-else ref="confirmedRequestsNoDataFoundRef" content="" heading="No Data Found" type='Users'
                :loading="confirmedRequestsLoading" />
            </VuePerfectScrollbar>
          </div>
        </div>
      </div>
      <div class="widget_column" v-if="[1, 3, 5].indexOf(getUserRoleId) < 0">
        <div class="widget_wrapper">
          <div class="widget_header">
            <h6>To Offshore Cases</h6>
            <date-picker v-if="false" v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
          </div>
          <div class="widget_cnt">
            <VuePerfectScrollbar>
              <div class="table-responsive" v-if="checkProperty(toOffshoreRequests, 'length') > 0">
                <table class="table most_cases_table">
                  <thead>
                    <tr>
                      <th>Request Id</th>
                      <th>Type of Evaluations</th>
                      <th>Beneficiary</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(item, index) in toOffshoreRequests" v-bind:key='index'
                      @click="goToEvaluationDetaillPage(item)">
                      <td><span>{{ checkProperty(item, 'requestId') ? item.requestId : '' }}</span></td>
                      <td>
                        <div v-if="checkProperty(item, 'docsConfig', 'length') > 0" class="evalution_type">
                          <span>{{ item.docsConfig[0].evaluationTypeName
                          }}</span>
                          <em v-if="checkProperty(item, 'docsConfig', 'length') > 1" class="count"
                            :id="'tooffshore_popover-target-' + index">{{ '+' + (checkProperty(item, 'docsConfig',
                              'length')
                              -
                              1)
                            }}</em>

                          <b-popover custom-class="evalution_list_wrap" :target="'tooffshore_popover-target-' + index"
                            triggers="hover" placement="top" fallback-placement="flip">
                            <template>
                              <ul>
                                <li v-for="(evaluationItem, indx) in checkProperty(item, 'docsConfig')" :key="indx"
                                  v-if="indx > 0">{{ evaluationItem.evaluationTypeName }}</li>
                              </ul>
                            </template>
                          </b-popover>
                        </div>
                        <div v-else></div>
                      </td>
                      <td>
                        <span>{{ checkProperty(item, 'beneficiaryInformation') | formatFullname }}</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <NoDataFound v-else ref="toOffshoreNoDataFoundRef" content="" heading="No Data Found" type='Users'
                :loading="toOffshoreLoading" />
            </VuePerfectScrollbar>
          </div>
        </div>
      </div>
      <div class="widget_column" v-if="[1, 3, 5].indexOf(getUserRoleId) < 0">
        <div class="widget_wrapper">
          <div class="widget_header">
            <h6>Review Offshore Cases</h6>
            <date-picker v-if="false" v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
          </div>
          <div class="widget_cnt">
            <VuePerfectScrollbar>
              <div class="table-responsive" v-if="checkProperty(reviewOffshoreRequests, 'length') > 0">
                <table class="table most_cases_table">
                  <thead>
                    <tr>
                      <th>Request Id</th>
                      <th>Type of Evaluations</th>
                      <th>Beneficiary</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(item, index) in reviewOffshoreRequests" v-bind:key='index'
                      @click="goToEvaluationDetaillPage(item)">
                      <td><span>{{ checkProperty(item, 'requestId') ? item.requestId : '' }}</span></td>
                      <td>
                        <div v-if="checkProperty(item, 'docsConfig', 'length') > 0" class="evalution_type">
                          <span>{{ item.docsConfig[0].evaluationTypeName
                          }}</span>
                          <em v-if="checkProperty(item, 'docsConfig', 'length') > 1" class="count"
                            :id="'reviewoffshore_popover-target-' + index">{{ '+' + (checkProperty(item, 'docsConfig',
                              'length') -
                              1)
                            }}</em>

                          <b-popover custom-class="evalution_list_wrap" :target="'reviewoffshore_popover-target-' + index"
                            triggers="hover" placement="top" fallback-placement="flip">
                            <template>
                              <ul>
                                <li v-for="(evaluationItem, indx) in checkProperty(item, 'docsConfig')" :key="indx"
                                  v-if="indx > 0">{{ evaluationItem.evaluationTypeName }}</li>
                              </ul>
                            </template>
                          </b-popover>
                        </div>
                        <div v-else></div>
                      </td>
                      <td>
                        <span>{{ checkProperty(item, 'beneficiaryInformation') | formatFullname }}</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <NoDataFound v-else ref="reviewOffshoreNoDataFoundRef" content="" heading="No Data Found" type='Users'
                :loading="reviewOffshoreLoading" />
            </VuePerfectScrollbar>
          </div>
        </div>
      </div>
      <div class="widget_column" v-if="[1, 3, 5].indexOf(getUserRoleId) < 0">
        <div class="widget_wrapper">
          <div class="widget_header">
            <h6>With Professor</h6>
            <date-picker v-if="false" v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
          </div>
          <div class="widget_cnt">
            <VuePerfectScrollbar>
              <div class="table-responsive" v-if="checkProperty(withProfessorRequests, 'length') > 0">
                <table class="table most_cases_table">
                  <thead>
                    <tr>
                      <th>Request Id</th>
                      <th>Type of Evaluations</th>
                      <th>Beneficiary</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(item, index) in withProfessorRequests" v-bind:key='index'
                      @click="goToEvaluationDetaillPage(item)">
                      <td><span>{{ checkProperty(item, 'requestId') ? item.requestId : '' }}</span></td>
                      <td>
                        <div v-if="checkProperty(item, 'docsConfig', 'length') > 0" class="evalution_type">
                          <span>{{ item.docsConfig[0].evaluationTypeName
                          }}</span>
                          <em v-if="checkProperty(item, 'docsConfig', 'length') > 1" class="count"
                            :id="'professor_popover-target-' + index">{{ '+' + (checkProperty(item, 'docsConfig',
                              'length')
                              -
                              1)
                            }}</em>

                          <b-popover custom-class="evalution_list_wrap" :target="'professor_popover-target-' + index"
                            triggers="hover" placement="top" fallback-placement="flip">
                            <template>
                              <ul>
                                <li v-for="(evaluationItem, indx) in checkProperty(item, 'docsConfig')" :key="indx"
                                  v-if="indx > 0">{{ evaluationItem.evaluationTypeName }}</li>
                              </ul>
                            </template>
                          </b-popover>
                        </div>
                        <div v-else></div>
                      </td>
                      <td>
                        <span>{{ checkProperty(item, 'beneficiaryInformation') | formatFullname }}</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <NoDataFound v-else ref="withProfessorNoDataFoundRef" content="" heading="No Data Found" type='Users'
                :loading="withProfessorLoading" />
            </VuePerfectScrollbar>
          </div>
        </div>
      </div>
      <div class="widget_column" v-if="[1, 3, 5].indexOf(getUserRoleId) < 0">
        <div class="widget_wrapper">
          <div class="widget_header">
            <h6>Delivered Cases</h6>
            <date-picker v-if="false" v-model="time1" valueType="format" placeholder="dd/mm/yyyy"></date-picker>
          </div>
          <div class="widget_cnt">
            <VuePerfectScrollbar>
              <div class="table-responsive" v-if="checkProperty(deliveredRequests, 'length') > 0">
                <table class="table most_cases_table">
                  <thead>
                    <tr>
                      <th>Request Id</th>
                      <th>Type of Evaluations</th>
                      <th>Beneficiary</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(item, index) in deliveredRequests" v-bind:key='index'
                      @click="goToEvaluationDetaillPage(item)">
                      <td><span>{{ checkProperty(item, 'requestId') ? item.requestId : '' }}</span></td>
                      <td>
                        <div v-if="checkProperty(item, 'docsConfig', 'length') > 0" class="evalution_type">
                          <span>{{ item.docsConfig[0].evaluationTypeName
                          }}</span>
                          <em v-if="checkProperty(item, 'docsConfig', 'length') > 1" class="count"
                            :id="'delivered_popover-target-' + index">{{ '+' + (checkProperty(item, 'docsConfig',
                              'length')
                              -
                              1)
                            }}</em>

                          <b-popover custom-class="evalution_list_wrap" :target="'delivered_popover-target-' + index"
                            triggers="hover" placement="top" fallback-placement="flip">
                            <template>
                              <ul>
                                <li v-for="(evaluationItem, indx) in checkProperty(item, 'docsConfig')" :key="indx"
                                  v-if="indx > 0">{{ evaluationItem.evaluationTypeName }}</li>
                              </ul>
                            </template>
                          </b-popover>
                        </div>
                        <div v-else></div>
                      </td>
                      <td>
                        <span>{{ checkProperty(item, 'beneficiaryInformation') | formatFullname }}</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <NoDataFound v-else ref="deliveredNoDataFoundRef" content="" heading="No Data Found" type='Users'
                :loading="deliveredLoading" />
            </VuePerfectScrollbar>
          </div>
        </div>
      </div>




    </div>

    <div class="widgets_row" v-if="[1, 3].indexOf(getUserRoleId) > -1">
      <div class="widget_column">
        <div class="widget_wrapper">
          <div class="widget_header">
            <h6>Top 5 Evaluation Types Received</h6>
            <div class="custom-datepicker">

              <date-range-picker :maxDate="new Date()" :autoApply="autoApply" @update="getTopEvaluations"
                :placeholder="'dd/mm/yyyy'" :ranges="false" :opens="'right'"
                :locale-data="{ format: 'mmm dd, yyyy', customRangeLabel: 'Custom Range', }"
                v-model="topFiveDateRange"></date-range-picker>
              <span class="clear" @click="clearDateRange()"
                v-if="checkProperty(topFiveDateRange, 'startDate') && checkProperty(topFiveDateRange, 'endDate')"><img
                  src="@/assets/images/close.svg"></span>
            </div>
            <!---  <date-picker v-model="time1.topFiveEvaluations" valueType="format" placeholder="dd/mm/yyyy"></date-picker>-->
          </div>
          <div class="widget_cnt">
            <ul class="evaluation_types_list" v-if="checkProperty(topFiveEvaluations, 'length') > 0">
              <li v-for="(item, index) in topFiveEvaluations" v-bind:key="index">
                <span class="count">{{ checkProperty(item, 'count') ? item.count : '' }}</span>
                <span class="desc">{{ checkProperty(item, 'evaluationTypeName') ? item.evaluationTypeName : '' }}</span>
              </li>
            </ul>
            <NoDataFound v-else ref="NoDatatopFiveEvaluations" content="" heading="No Data Found" type='Users'
              :loading="loadingTopFiveData" />

          </div>
        </div>
      </div>

      <div class="widget_column">
        <div class="widget_wrapper">
          <div class="widget_header">
            <h6>Most Cases Handled </h6>
            <date-picker v-if="false" v-model="time1.MostHandledCases" valueType="format"
              placeholder="dd/mm/yyyy"></date-picker>
          </div>
          <div class="widget_cnt">
            <VuePerfectScrollbar>
              <div class="table-responsive" v-if="checkProperty(MostHandledCases, 'length') > 0">
                <table class="table most_cases_table">
                  <thead>
                    <tr>
                      <th>NAME</th>
                      <th>TEAM</th>
                      <th>NO. CASES</th>
                      <th>REVENUE</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(item, index) in MostHandledCases" v-bind:key='index'>
                      <td><span>{{ checkProperty(item, 'name') ? item.name : '' }}</span></td>
                      <td><span>{{ checkProperty(item, 'team') ? item.team : '' }}</span></td>
                      <td><span>{{ checkProperty(item, 'noCases') ? item.noCases : '' }}</span></td>
                      <td><span>{{ checkProperty(item, 'revenue') > 0 ? '$' + item.revenue : '$0' }}</span></td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <NoDataFound v-else ref="NoDatamostHandled" content="" heading="No Data Found" type='Users'
                :loading="mostHandledLoading" />
            </VuePerfectScrollbar>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
//import simpleSelect from '@/views/forms/simpleSelect.vue';

import customSelect from '@/views/forms/customSelect.vue';

import DatePicker from 'vue2-datepicker';
import 'vue2-daterange-picker/dist/vue2-daterange-picker.css'
import 'vue2-datepicker/index.css';
import NoDataFound from '@/views/common/noData.vue';
import _ from "lodash";
import DateRangePicker from "vue2-daterange-picker";
import moment from 'moment';
import dropdownHover from "@/views/forms/dropdownHover.vue"
import radioInput from "@/views/forms/radioInput.vue";
import VuePerfectScrollbar from 'vue-perfect-scrollbar'
export default {
  name: 'dashboard-view',
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  components: {
    searchInput,
    //simpleSelect,
    customSelect,
    DatePicker,
    NoDataFound,
    DateRangePicker,
    dropdownHover,
    radioInput,
    VuePerfectScrollbar
  },
  data: () => ({
    showChart: false,
    evalstats:{},
    chartLoading: true,
    loadingTopFiveData: false,
    mostHandledLoading: false,
    isListLoading: false,
    rows: 100,
    perPage: 1,
    currentPage: 1,
    statusList: ['Awaiting Confirmation', 'Confirmed', 'Delivered to Client', 'In Process', 'Payment Status', 'Requested'],
    priorityList: ['Rush', 'Standard'],
    customerList: ['Alex Mecheal Alex Mecheal', 'Alex', 'Mecheal'],
    beneficiaryList: ['Alex Mecheal Alex Mecheal', 'Alex', 'Mecheal'],
    autoApply: "",
    evlstatsDateRange: {
      startDate: null,
      endDate: null
    },
    topFiveDateRange: {
      startDate: null,
      endDate: null
    },
    time1: [],
    statsCount: {
    },
    topFiveEvaluations: {

    },
    MostHandledCases: {

    },
    statsChartView: {
      _id: 7,
      name: "Last 7 Days"
    },
    daysCountData: [
      {
        _id: 7,
        name: "Last 7 Days"
      },
      {
        _id: 15,
        name: "Last 15 Days"
      },
      {
        _id: 30,
        name: "Last 30 Days"
      },
      {
        _id: 60,
        name: "Last 60 Days"
      },
    ],
    chartOptions: {
      chart: {
        type: 'column',
        style: {
          fontFamily: 'InterMedium',
          fontSize: 13,
        }
      },
      title: {
        text: ''
      },
      subtitle: {
        text: ''
      },
      xAxis: {
        categories: [
          '6 Feb - 12 Feb',
          '13 Feb - 19 Feb',
          '20 Feb - 26 Feb',
          '27 Feb - 5 Mar',
          '5 Mar - 12 Mar',
          '13 Mar - 19 Mar'
        ],
        crosshair: true,
        borderWidth: 0.2,
        borderColor: "#eee"
      },
      yAxis: {
        min: 0,
        max: 20,
        tickInterval: 2,
        title: {
          text: ''
        }
      },
      tooltip: {
        shadow: {
          color: '#0000001A', offsetX: 0, offsetY: 10, opacity: 1, width: 20
        },
        padding: 15,
        headerFormat: '<table >',
        pointFormat: '<tr><td style="color:#272846;padding:0 10px 10px 0;text-align:left;">{series.name}: </td>' +
          '<td style="padding:0 0 10px 10px; text-align: right;"><b>{point.y}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true,
        followPointer: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0,
          borderRadius: 0,
          ignoreHiddenSeries: false,
        }
      },
      legend: {
        symbolRadius: 0,
        symbolWidth: 12,
        symbolHeight: 12,
        fontSize: 12
      },
      series: [{
        name: 'Requested',
        data: [20, 3, 18, 25, 17, 18],
        color: '#F2D89E',
        opacity: 0.9,
      }, {
        name: 'Confirmed',
        data: [20, 3, 18, 25, 17, 18],
        color: '#6AC437',
        opacity: 0.9,

      }, {
        name: 'Assigned',
        data: [20, 3, 18, 25, 17, 18],
        color: '#39C4AF',
        opacity: 0.9,

      },
      {
        name: 'Offshore',
        data: [20, 3, 18, 25, 17, 18],
        color: '#9A60CC',
        opacity: 0.9,

      },
      {
        name: 'Onsite',
        data: [20, 3, 18, 25, 17, 18],
        color: '#C860CC',
        opacity: 0.9,

      },
      {
        name: 'Professor',
        data: [20, 3, 18, 25, 17, 18],
        color: '#4991F4',
        opacity: 0.9,

      },
      {
        name: 'Returned',
        data: [20, 3, 18, 25, 17, 18],
        color: '#F48449',
        opacity: 0.9,

      }
      ]
    },
    newRequests: [],
    newRequestsLoading: false,
    confirmedRequests: [],
    confirmedRequestsLoading: false,
    toOffshoreRequests: [],
    toOffshoreLoading: false,
    reviewOffshoreRequests: [],
    reviewOffshoreLoading: false,


    withProfessorRequests: [],
    withProfessorLoading: false,
    deliveredRequests: [],
    deliveredLoading: false,
    filterDaysList: [{ id: 1, name: 'Daily', key: 'daily' }, { id: 2, name: 'Weekly', key: 'weekly' }, { id: 3, name: 'Monthly', key: 'monthly' }, { id: 4, name: 'Yearly', key: 'yearly' }],
    selectedDayFilter: null,
    evaluationTypesList: [],
    filterSelectedEvaluation: null,
    dueRequests: [],
    dueRequestsLoading: false,
    overdueRequests: [],
    overdueRequestsLoading: false,

  }),
  methods: {
    clearDateRange() {
      //alert()
      this.topFiveDateRange = {
        startDate: null,
        endDate: null
      }
      this.getTopEvaluations()
    },
    getChartStatsData() {
      this.showChart = false
      this.chartLoading = true;
      let postdata = {
        days: 6,
        filters: { statusIds: [] }
      }
      if (this.checkProperty(this.statsChartView, '_id') > 0) {
        postdata['days'] = this.statsChartView['_id'];
      }
      if (this.checkProperty(this.filterSelectedEvaluation, 'length') > 0) {
        postdata.filters.statusIds = this.filterSelectedEvaluation.map((item) => item.id)
      }
      this.chartOptions['xAxis']['categories'] = [];
      this.chartOptions['series'] = [];
      let chartCount = 0
      this.updateLoading(true, 'NoDatacharts');
      this.$store.dispatch('getStatsChartView', postdata).then((response) => {
        console.log(response)

        if (this.checkProperty(response, 'result', 'length') > 0) {
          // let canceledItems = {
          //   "name": "Cancelled",
          //   data: [],
          //   "color": "#F79999",
          //   "opacity": 0.9

          // }
          let deliveredItems = {
            "name": "Delivered",
            data: [],
            "color": "#46C620",
            "opacity": 0.9
          }

          let requestedItems = {
            "name": "Requested",
            data: [],
            "color": "#9EA5BC",
            "opacity": 0.9
          }
          let toOffshoreItems = {
            "name": "Offshore",
            data: [],
            "color": "#9A60CC",
            "opacity": 0.9
          }
          let confirmedItems = {
            "name": "Confirmed",
            data: [],
            "color": "#39C4AF",
            "opacity": 0.9
          }
          let reviewOffshoreItems = {
            "name": "Onsite",
            data: [],
            "color": "#C860CC",
            "opacity": 0.9
          }
          let withProfessorItems = {
            "name": "With Professor",
            data: [],
            "color": "#4991F4",
            "opacity": 0.9
          }
          let professorApprovedItems = {
            "name": "Professor Approved",
            data: [],
            "color": "#73B9D8",
            "opacity": 0.9
          }
          let finalReviewItems = {
            "name": "Final Review",
            data: [],
            "color": "#fdeca9",
            "opacity": 0.9
          }

          let yAxisMaxNumber = 0
          _.forEach(response['result'], (item) => {
            let dt = moment(item.date).format("MMM DD, YYYY")
            this.chartOptions['xAxis']['categories'].push(dt);

            // if (_.has(item, 'cancel')) {
            //   canceledItems['data'].push(item['cancel']);
            //   chartCount = chartCount + item['cancel'];
            //   if (yAxisMaxNumber < item['cancel']) {
            //     yAxisMaxNumber = item['cancel']
            //   }
            // }
            if (_.has(item, 'delivered')) {
              deliveredItems['data'].push(item['delivered']);
              chartCount = chartCount + item['delivered'];
              if (yAxisMaxNumber < item['delivered']) {
                yAxisMaxNumber = item['delivered']
              }
            }
            if (_.has(item, 'toOffshore')) {
              toOffshoreItems['data'].push(item['toOffshore'])
              chartCount = chartCount + item['toOffshore'];
              if (yAxisMaxNumber < item['toOffshore']) {
                yAxisMaxNumber = item['toOffshore']
              }
            }
            if (_.has(item, 'requested')) {
              requestedItems['data'].push(item['requested'])
              chartCount = chartCount + item['requested'];
              if (yAxisMaxNumber < item['requested']) {
                yAxisMaxNumber = item['requested']
              }
            }
            if (_.has(item, 'confirmed')) {
              confirmedItems['data'].push(item['confirmed'])
              chartCount = chartCount + item['confirmed'];
              if (yAxisMaxNumber < item['confirmed']) {
                yAxisMaxNumber = item['confirmed']
              }
            }
            if (_.has(item, 'reviewOffshore')) {
              reviewOffshoreItems['data'].push(item['reviewOffshore'])
              chartCount = chartCount + item['reviewOffshore'];
              if (yAxisMaxNumber < item['reviewOffshore']) {
                yAxisMaxNumber = item['reviewOffshore']
              }
            }
            if (_.has(item, 'withProfessor')) {
              withProfessorItems['data'].push(item['withProfessor'])
              chartCount = chartCount + item['withProfessor'];
              if (yAxisMaxNumber < item['withProfessor']) {
                yAxisMaxNumber = item['withProfessor']
              }
            }

            if (_.has(item, 'professorApproved')) {
              professorApprovedItems['data'].push(item['professorApproved'])
              chartCount = chartCount + item['professorApproved'];
              if (yAxisMaxNumber < item['professorApproved']) {
                yAxisMaxNumber = item['professorApproved']
              }
            }
            if (_.has(item, 'finalReview')) {
              finalReviewItems['data'].push(item['finalReview'])
              chartCount = chartCount + item['finalReview'];
              if (yAxisMaxNumber < item['finalReview']) {
                yAxisMaxNumber = item['finalReview']
              }
            }


          });
          this.chartOptions['series'] = [];
          this.chartOptions['series'].push(requestedItems);
          this.chartOptions['series'].push(confirmedItems);
          this.chartOptions['series'].push(toOffshoreItems);
          this.chartOptions['series'].push(reviewOffshoreItems);
          this.chartOptions['series'].push(withProfessorItems);
          this.chartOptions['series'].push(professorApprovedItems);
          this.chartOptions['series'].push(finalReviewItems);
          this.chartOptions['series'].push(deliveredItems);
          //  this.chartOptions['series'].push(canceledItems);

          this.chartOptions['yAxis']['max'] = yAxisMaxNumber

          if (chartCount > 0) {
            this.showChart = true
          }


        }

        this.chartLoading = false;
        //chartOptions
        //response.data
        this.updateLoading(false, 'NoDatacharts');
        setTimeout(() => {
          this.updateLoading(false, 'NoDatacharts');
          setTimeout(() => {
            this.updateLoading(false, 'NoDatacharts');
          }, 100);
        }, 100);
      }).catch((error) => {
        console.log(error)
        this.showChart = false
        this.chartLoading = false;
      })

    },
    changeDaysCount(data) {
      this.selectedDayFilter = null
      this.filterSelectedEvaluation = null
      this.getChartStatsData();

    },
    gotoPage(path = "/") {
      this.$router.push(path);
    },
    getstatsCount() {
      let postdata = {

      }
      this.$store.dispatch('getStatsCount', postdata).then((response) => {
        console.log(response)
        // alert(response.data)
        this.statsCount = response.result
        // if (this.checkProperty(response, 'data', 'result') && this.checkProperty(response.result, 'statsCount')) {
        //   this.statsCount = this.checkProperty(res.data.result, 'statsCount');
        // }
      }).catch((error) => {
        console.log(error)
      })
    },
    getEvaluationstats(){

      let postdata = {
        dateRange: {}
      }
      if (this.checkProperty(this.evlstatsDateRange, "startDate") && this.checkProperty(this.evlstatsDateRange, "endDate")) {
        let startDate = moment(this.evlstatsDateRange['startDate']).format("YYYY-MM-DD");
        let endDate = moment(this.evlstatsDateRange['endDate']).format("YYYY-MM-DD");
        postdata['dateRange'] = [startDate, endDate]
      }
      this.$store.dispatch('getEvaluationsstats', postdata).then((response) => {
        console.log("-----------------------------")
        console.log(response.result);
        this.evalstats = response.result;
       
      }).catch((error) => {
   

      })

    },
    getTopEvaluations() {
      this.updateLoading(true, 'NoDatatopFiveEvaluations');
      let postdata = {
        dateRange: {}
      }
      if (this.checkProperty(this.topFiveDateRange, "startDate") && this.checkProperty(this.topFiveDateRange, "endDate")) {
        let startDate = moment(this.topFiveDateRange['startDate']).format("YYYY-MM-DD");
        let endDate = moment(this.topFiveDateRange['endDate']).format("YYYY-MM-DD");
        postdata['dateRange'] = [startDate, endDate]
      }
      this.loadingTopFiveData = true;
      //NoDatatopFiveEvaluations
      this.$store.dispatch('getTopFiveEvaluations', postdata).then((response) => {
        // alert(response.data)
        if (this.checkProperty(this.topFiveEvaluations, 'length') > 0) {
          this.topFiveEvaluations = this.topFiveEvaluations.map((item) => item.evaluationTypeId);
        }
        this.topFiveEvaluations = response.result
        this.loadingTopFiveData = false;

        this.updateLoading(false, 'NoDatatopFiveEvaluations');
        setTimeout(() => {
          this.updateLoading(false, 'NoDatatopFiveEvaluations');
        }, 10);
      }).catch((error) => {
        this.loadingTopFiveData = false;
        console.log(error);
        setTimeout(() => {
          this.updateLoading(false, 'NoDatatopFiveEvaluations');
        }, 10);

      })
    },
    getMostHandledCases() {
      //mostHandledLoading NoDatamostHandled
      this.updateLoading(true, 'NoDatamostHandled');
      let postdata = {

      }
      this.mostHandledLoading = true;
      this.$store.dispatch('showMostHandledCases', postdata).then((response) => {
        console.log(response)
        // alert(response.data)  
        if (this.checkProperty(this.MostHandledCases, 'length') > 0) {
          this.MostHandledCases = this.MostHandledCases.map((item) => item.id)
        }
        this.MostHandledCases = response.result;
        this.mostHandledLoading = false;
        this.updateLoading(false, 'NoDatamostHandled');
        setTimeout(() => {
          this.updateLoading(false, 'NoDatamostHandled');
        }, 10);
      }).catch((error) => {
        console.log(error)
        this.mostHandledLoading = false;
      })
    },

    getEvaluations(statusId) {
      let statusIds = [statusId]
      let postData =
      {
        "matcher": {
          "searchString": "",
          "evaluationTypeIds": [],
          "statusIds": statusIds,
          "locationIds": [],
          "priorityIds": [],
          "customerIds": [],
          "createdDateRange": []
        },
        "sorting": {
          "path": "updatedOn",
          "order": -1
        },
        "page": 1,
        "perpage": 5,
      }
      this.$store.dispatch("getIndividualEvaluationsList", postData)
        .then((res) => {
          if (statusId == 1) {
            this.newRequests = res.data.result.list
            setTimeout(() => {
              this.newRequestsLoading = false
              this.updateLoading(false, 'newRequestsNoDataFoundRef');
            }, 10)
          } else if (statusId == 3) {
            this.confirmedRequests = res.data.result.list
            setTimeout(() => {
              this.confirmedRequestsLoading = false
              this.updateLoading(false, 'confirmedRequestsNoDataFoundRef');
            }, 10)
          }
          else if (statusId == 9) {
            this.toOffshoreRequests = res.data.result.list
            setTimeout(() => {
              this.toOffshoreLoading = false
              this.updateLoading(false, 'toOffshoreNoDataFoundRef');
            }, 10)
          }
          else if (statusId == 10) {
            this.reviewOffshoreRequests = res.data.result.list
            setTimeout(() => {
              this.reviewOffshoreLoading = false
              this.updateLoading(false, 'reviewOffshoreNoDataFoundRef');
            }, 10)
          }
          else if (statusId == 12) {
            this.withProfessorRequests = res.data.result.list
            setTimeout(() => {
              this.withProfessorLoading = false
              this.updateLoading(false, 'withProfessorNoDataFoundRef');
            }, 10)
          }
          else if (statusId == 15) {
            this.deliveredRequests = res.data.result.list
            setTimeout(() => {
              this.deliveredLoading = false
              this.updateLoading(false, 'deliveredNoDataFoundRef');
            }, 10)
          }


        })
        .catch((error) => {

        })
    },
    goToEvaluationDetaillPage(data) {
      if (this.checkProperty(data, '_id')) {
        let routedId = this.checkProperty(data, '_id')
        let path = "/requestdetails/" + routedId;
        // if (this.encodedString != '') {
        //     path = path + "?filter=" + this.encodedString;
        // }
        this.$router.push(path);
      }
    },

    getFilteredChartStatsData(isFromStatus = false) {
      setTimeout(() => {
        //  this.statsChartView = null

        if (!this.checkProperty(this.selectedDayFilter, 'key') || (this.checkProperty(this.selectedDayFilter, 'key') && this.selectedDayFilter.key == 'daily')) {
          if (this.checkProperty(this.selectedDayFilter, 'key')) {
            this.statsChartView = {
              _id: 15,
              name: "Last 15 Days"
            }
          }
          this.getChartStatsData();
        } else {
          this.showChart = false
          this.chartLoading = true;
          let postdata = {
            summaryType: this.selectedDayFilter.key,
            filters: { statusIds: [] }
          }
          if (this.checkProperty(this.filterSelectedEvaluation, 'length') > 0) {
            postdata.filters.statusIds = this.filterSelectedEvaluation.map((item) => item.id)
          }
          this.chartOptions['xAxis']['categories'] = [];
          this.chartOptions['series'] = [];
          let chartCount = 0
          this.updateLoading(true, 'NoDatacharts');

          this.$store.dispatch('getFilteredStatsChartView', postdata).then((response) => {
            console.log(response)

            if (this.checkProperty(response, 'result', 'length') > 0) {
              // let canceledItems = {
              //   "name": "Cancelled",
              //   data: [],
              //   "color": "#F79999",
              //   "opacity": 0.9

              // }
              let deliveredItems = {
                "name": "Delivered",
                data: [],
                "color": "#46C620",
                "opacity": 0.9
              }

              let requestedItems = {
                "name": "Requested",
                data: [],
                "color": "#9EA5BC",
                "opacity": 0.9
              }
              let toOffshoreItems = {
                "name": "To Offshore",
                data: [],
                "color": "#9A60CC",
                "opacity": 0.9
              }
              let confirmedItems = {
                "name": "Confirmed",
                data: [],
                "color": "#39C4AF",
                "opacity": 0.9
              }
              let reviewOffshoreItems = {
                "name": "Review Offshore",
                data: [],
                "color": "#C860CC",
                "opacity": 0.9
              }
              let withProfessorItems = {
                "name": "With Professor",
                data: [],
                "color": "#4991F4",
                "opacity": 0.9
              }
              let professorApprovedItems = {
                "name": "Professor Approved",
                data: [],
                "color": "#73B9D8",
                "opacity": 0.9
              }
              let finalReviewItems = {
                "name": "Final Review",
                data: [],
                "color": "#fdeca9",
                "opacity": 0.9
              }

              let yAxisMaxNumber = 0
              let statsResult = []
              // if (this.checkProperty(this.selectedDayFilter, 'key') == 'weekly')
              // {
              statsResult = response.result[0]['summary'].slice().reverse()
              // }
              // else{
              //   statsResult=response.result[0]['summary']
              // }
              console.log("this.chartOptions['xAxis']['categories']", statsResult)

              _.forEach(statsResult, (item, index) => {
                let dt = item.name
                if (this.checkProperty(this.selectedDayFilter, 'key') == 'weekly') {
                  let endDate = item.endDate.split("T")[0] + 'T00:00:00.000Z'
                  dt = moment(item.startDate).format("MMM DD, YYYY") + " - " + moment(endDate).format("MMM DD, YYYY")
                }
                // if (this.checkProperty(this.selectedDayFilter, 'key') == 'weekly'
                //   && ((this.checkProperty(response.result[0]['summary'], 'length') > 4 &&index == 0)
                //   || ( this.checkProperty(response.result[0]['summary'], 'length') > 5 &&index == 1))
                // ) {


                // } else {
                this.chartOptions['xAxis']['categories'].push(dt);

                let statsArray = item.stats


                if (statsArray.find(stat => stat.statusId == 16)) {
                  let statItem = statsArray.find(stat => stat.statusId == 16)
                  deliveredItems['data'].push(statItem.total);
                  chartCount = chartCount + statItem.total;
                  if (yAxisMaxNumber < statItem.total) {
                    yAxisMaxNumber = statItem.total
                  }
                }
                if (statsArray.find(stat => stat.statusId == 9)) {
                  let statItem = statsArray.find(stat => stat.statusId == 9)
                  toOffshoreItems['data'].push(statItem.total)
                  chartCount = chartCount + statItem.total;
                  if (yAxisMaxNumber < statItem.total) {
                    yAxisMaxNumber = statItem.total
                  }
                }
                if (statsArray.find(stat => stat.statusId == 1)) {
                  let statItem = statsArray.find(stat => stat.statusId == 1)
                  requestedItems['data'].push(statItem.total)
                  chartCount = chartCount + statItem.total;
                  if (yAxisMaxNumber < statItem.total) {
                    yAxisMaxNumber = statItem.total
                  }
                }
                if (statsArray.find(stat => stat.statusId == 3)) {
                  let statItem = statsArray.find(stat => stat.statusId == 3)
                  confirmedItems['data'].push(statItem.total)
                  chartCount = chartCount + statItem.total;
                  if (yAxisMaxNumber < statItem.total) {
                    yAxisMaxNumber = statItem.total
                  }
                }
                if (statsArray.find(stat => stat.statusId == 10)) {
                  let statItem = statsArray.find(stat => stat.statusId == 10)
                  reviewOffshoreItems['data'].push(statItem.total)
                  chartCount = chartCount + statItem.total;
                  if (yAxisMaxNumber < statItem.total) {
                    yAxisMaxNumber = statItem.total
                  }
                }
                if (statsArray.find(stat => stat.statusId == 12)) {
                  let statItem = statsArray.find(stat => stat.statusId == 12)
                  withProfessorItems['data'].push(statItem.total)
                  chartCount = chartCount + statItem.total;
                  if (yAxisMaxNumber < statItem.total) {
                    yAxisMaxNumber = statItem.total
                  }
                }

                if (statsArray.find(stat => stat.statusId == 14)) {
                  let statItem = statsArray.find(stat => stat.statusId == 14)
                  professorApprovedItems['data'].push(statItem.total)
                  chartCount = chartCount + statItem.total;
                  if (yAxisMaxNumber < statItem.total) {
                    yAxisMaxNumber = statItem.total
                  }
                }
                if (statsArray.find(stat => stat.statusId == 15)) {
                  let statItem = statsArray.find(stat => stat.statusId == 15)
                  finalReviewItems['data'].push(statItem.total)
                  chartCount = chartCount + statItem.total;
                  if (yAxisMaxNumber < statItem.total) {
                    yAxisMaxNumber = statItem.total
                  }
                }
                //               }
              });
              this.chartOptions['series'] = [];
              this.chartOptions['series'].push(requestedItems);
              this.chartOptions['series'].push(confirmedItems);
              this.chartOptions['series'].push(toOffshoreItems);
              this.chartOptions['series'].push(reviewOffshoreItems);
              this.chartOptions['series'].push(withProfessorItems);
              this.chartOptions['series'].push(professorApprovedItems);
              this.chartOptions['series'].push(finalReviewItems);
              this.chartOptions['series'].push(deliveredItems);
              //  this.chartOptions['series'].push(canceledItems);

              this.chartOptions['yAxis']['max'] = yAxisMaxNumber



              if (chartCount > 0) {
                this.showChart = true
              }


            }

            this.chartLoading = false;
            //chartOptions
            //response.data
            this.updateLoading(false, 'NoDatacharts');
            setTimeout(() => {
              this.updateLoading(false, 'NoDatacharts');
              setTimeout(() => {
                this.updateLoading(false, 'NoDatacharts');
              }, 100);
            }, 100);
          }).catch((error) => {
            console.log(error)
            this.showChart = false
            this.chartLoading = false;
          })
        }
      }, 5)


    },

    filterByEvaluationType(data) {
      this.getFilteredChartStatsData(true);
    },
    getEvaluationTypes() {
      this.$store.dispatch("getMasterData", 'evaluation_status')
        .then((res) => {
          this.evaluationTypesList = _.filter(res, (item) => {
            return ([2, 4, 5, 6, 7, 8, 11, 13].indexOf(item.id) < 0)
          });

        })
    },

    getTodayDueEvaluations() {
      let postData =
      {
        "dueDate": moment(new Date()).format('YYYY-MM-DD')
      }

      this.$store.dispatch("getDueTodayEvaluations", postData)
        .then((res) => {
          this.dueRequests = res.data.result
          setTimeout(() => {
            this.dueRequestsLoading = false
            this.updateLoading(false, 'dueRequestsNoDataFoundRef');
          }, 10)
        })
        .catch((error) => {

        })
    },

    getOverDueEvaluations() {
      let postData =
      {
        // "dueDate": moment(new Date()).format('YYYY-MM-DD'),
        "overDue": true
      }

      this.$store.dispatch("getDueTodayEvaluations", postData)
        .then((res) => {
          this.overdueRequests = res.data.result
          setTimeout(() => {
            this.overdueRequestsLoading = false
            this.updateLoading(false, 'ovueDueRequestsNoDataFoundRef');
          }, 10)
        })
        .catch((error) => {

        })
    },
  },
  mounted() {
     let today = moment().format("YYYY-MM-DD");
     
    this.evlstatsDateRange =  {
      startDate: today,
      endDate: today
    }

    if ([1, 3, 4, 5, 6, 7, 8].indexOf(this.getUserRoleId) > -1) {
      this.getEvaluationTypes()
      this.getstatsCount();
      this.getTopEvaluations();
      this.getEvaluationstats();
      this.getMostHandledCases();
      this.getChartStatsData()
    }
    if ([4, 7].indexOf(this.getUserRoleId) > -1) {
      this.updateLoading(true, 'newRequestsNoDataFoundRef');
      this.getEvaluations(1);
    }

    if ([1, 2, 3].indexOf(this.getUserRoleId) < 0) {
      this.updateLoading(true, 'confirmedRequestsNoDataFoundRef');
      this.getEvaluations(3);
      this.updateLoading(true, 'toOffshoreNoDataFoundRef');
      this.getEvaluations(9);
      this.updateLoading(true, 'reviewOffshoreNoDataFoundRef');
      this.getEvaluations(10);
      this.updateLoading(true, 'withProfessorNoDataFoundRef');
      this.getEvaluations(12);
      this.updateLoading(true, 'deliveredNoDataFoundRef');
      this.getEvaluations(15);
      this.updateLoading(true, 'dueRequestsNoDataFoundRef');
      this.getTodayDueEvaluations();
      this.updateLoading(true, 'ovueDueRequestsNoDataFoundRef');
      this.getOverDueEvaluations()
    }



  }

}
</script>