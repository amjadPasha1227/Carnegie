<template>
  <header class="main_header">
    <div class="mobile_menu">
      <span></span>
      <span></span>
      <span></span>
    </div>
    <div class="left">
      <div class="page_header">
        <a v-if="!showOrHideBackButton" @click="hasHistory ? $router.go(-1) : gotoPage()">
          <img src="@/assets/images/left-chevron.svg" alt=""></a>
        <h5>{{ getPageTitle }}</h5>
      </div>
      <!--<div class="rq-select">
          <div class="rq-number">
            <h5>Evaluations / <a href="#">#E-5153</a></h5>
            <div class="evalution_type">
              <span>Work Experience Evaluation</span>
              <div class="evalution_dropdown">
                <em class="count" id="popover-target-1">+4</em>
                  <b-popover custom-class="evalution_list_wrap" target="popover-target-1" triggers="hover" placement="top" fallback-placement="flip">
                      <template>
                        <ul>
                          <li>Specialty Occupation Expert Opinions (Position Evaluations)</li>
                          <li>Employment Based 2nd Preference (EB-2A/EB-2B) Expert Opinion</li>
                          <li>E-2 Treaty Employee Expert Opinion</li>
                          <li>Expert Opinion Letter, Academic Evaluation & Work Experience Evaluation Combined</li>
                        </ul>
                      </template>
                </b-popover>
              </div>
            </div>
          </div>
          <div class="rq-review">
            <div class="due_date"><h4><span>Due by </span> 8 Feb 2023</h4><figure class="due_date_icon"><img src="../assets/images/calender.png" ></figure></div>
            <div class="status rush"><img src="@/assets/images/clock.png"> Rush</div>
          </div>
        </div> -->
    </div>
    <div class="right">
      <div class="notification_sec" v-if="false">
        <span class="notification_icon new_notification"><img src="@/assets/images/notification.png"></span>
      </div>
      <div class="profile_sec">
        <b-dropdown size="lg" variant="link" right>
          <template #button-content>
            <div class="profile_icon">
              <img src="@/assets/images/profile-user.png">
            </div>
            <div class="profile_text">
              <p>{{ getUserData | formatFullname}}</p>
              <small v-if="checkProperty(getUserData,'roleName')">{{checkProperty(getUserData,'roleName')}}</small>
            </div>
            <em class="profile_arrow">
              <img src="@/assets/images/down-chevron.svg">
            </em>
          </template>
          <b-dropdown-item @click="openProfilePopup(), $bvModal.show('profile_model_headed')">Profile</b-dropdown-item>
          <b-dropdown-item @click="openChangePassword()">Change Password</b-dropdown-item>
          <b-dropdown-item @click="logout()">Logout</b-dropdown-item>
        </b-dropdown>
      </div>
    </div>

    <!-- Profile Modal -->
    <b-modal id="profile_model_headed" dialog-class="profile_model" centered hide-header hide-footer no-close-on-backdrop>
      <template>
        <div class="profile_header">


          <!-- <div class="profile_icon">
             <img  v-if="checkProperty(profileData, 'details', 'profileURL')" :src=" checkProperty(profileData, 'details', 'profileURL') ">
            <img  v-else :src=" checkProperty(profileData, 'details', 'profileURL') "> 
            <figure><img src="@/assets/images/professors.svg"></figure>
          </div> -->

          <div class="profile_title">
            <h6 v-if="checkProperty(getUserData, 'name')">{{ checkProperty(getUserData, 'name') }}</h6>
            <p v-if="checkProperty(getUserData, 'roleName')">{{ checkProperty(getUserData, 'roleName') }}</p>
            <p v-if="checkProperty(getUserData, 'details', 'designation')">{{ checkProperty(getUserData, 'details',
              'designation') }}</p>
          </div>
          <a class="close" @click=" $bvModal.hide('profile_model_headed')"></a>
        </div>
        <div class="profile_info">
          <ul>
            <li v-if="checkProperty(getUserData, 'details', 'email')">
              <span class="info_header">Email</span>
              <p class="desc">{{ checkProperty(getUserData, 'details', 'email') }}</p>
            </li>
            <li v-if="checkProperty(getUserData, 'details', 'phone')">
              <span class="info_header">Phone</span>
              <p class="desc">
                {{ checkProperty(getUserData.phoneCountryCode, 'countryCallingCode') | countryFormatter }}
                {{ checkProperty(getUserData, 'phone') | formatPhone }}
              </p>
            </li>
            <li v-if="checkProperty(getUserData, 'details', 'userName')">
              <span class="info_header">Username</span>
              <p class="desc">{{ checkProperty(getUserData, 'details', 'userName') }}</p>
            </li>
            <li v-if="checkProperty(getUserData, 'departmentDetails', 'name')">
              <span class="info_header">Department</span>
              <p class="desc">{{ checkProperty(getUserData, 'departmentDetails', 'name') }}</p>
            </li>
            <li v-if="checkProperty(getUserData, 'details', 'profileURL')">
              <span class="info_header">Profile URL</span>
              <a href="#" class="link">{{ checkProperty(getUserData, 'details', 'profileURL') }}</a>
            </li>
            <li
              v-if="checkProperty(getUserData, 'details', 'letterHead') && checkProperty(getUserData['details'], 'letterHead', 'length') > 0">
              <span class="info_header">Copy of letterhead</span>
              <!-- <div class="download_sec">
                <img src="@/assets/images/pdf-file-format.svg">
                <a href="#" class="link_btn">Download</a>
              </div> -->
              <DocumentsPreview :type="'documents'" :documentsList="checkProperty(getUserData, 'details', 'letterHead')"
                :includeDownloadText="true" @download_or_view="download_or_view" />
            </li>
            <li
              v-if="(checkProperty(getUserData, 'details', 'bioAndResume') || (checkProperty(getUserData, 'details', 'documents') && checkProperty(getUserData['details'], 'documents', 'length') > 0))"
              class="bio_resume">
              <span v-if="checkProperty(getUserData, 'details', 'bioAndResume')" class="info_header">Bio/Resume</span>
              <p v-if="checkProperty(getUserData, 'details', 'bioAndResume')"
                v-html="checkProperty(getUserData, 'details', 'bioAndResume')"></p>
              <div
                v-if="checkProperty(getUserData, 'details', 'documents') && checkProperty(getUserData['details'], 'documents', 'length') > 0">
                <DocumentsPreview :type="'documents'" :documentsList="checkProperty(getUserData, 'details', 'documents')"
                  :includeDownloadText="true" @download_or_view="download_or_view" />
              </div>

              <!-- <div v-if="checkProperty(getUserData, 'details', 'bioAndResume')" class="download_sec">
                <img src="@/assets/images/pdf-file-format.svg">
                <a href="#" class="link_btn">Download</a>
              </div> -->
            </li>
          </ul>
        </div>
      </template>
    </b-modal>

    <!----updatePasswordPopUp-->
    <b-modal v-model="showPasswordChangePopup" id="headerChangePassword" dialog-class="changePassword" centered
      no-close-on-backdrop>
      <template #modal-header>
        <h6 class="modal-title">Change Password </h6>
        <a class="close" @click="closeChangePassword"></a>
      </template>
      <template>
        <div>
          <div class="row">
            <div class="col-md-12">
              <div class="form_group">
          
                <!-- <lable class="form_label">Current Password<em>*</em></lable> -->
                <simpleInput :wrapclass="'mb20'" :required="true" :vvas="'Current Password'" :label="'Current Password'"
                  v-model="conformPassword" :datatype="'min:5|max:15|strongpassword'" 
                  :placeHolder="'Current Password'" :cid="'currentPassword'" :fieldName="'currentpassword'" :isPassword="true"/>
                <!-- <div class="view_eye" :class="{ close: showCurrentPassword }" @click="showCurrentPassword != showCurrentPassword"> </div> -->
                <!-- <span v-show="errors.has('currentpassword')" class="form-error">
                  {{ errors.first("currentpassword") }}
                </span> -->



              </div>
            </div>
            <div class="col-md-12">
              <div class="form_group">
                <!-- <lable class="form_label">New Password<em>*</em></lable>
                <input :wrapclass="'mb20'" ref="password" v-validate="'required|min:5|max:15|strongpassword'"
                  :data-vv-as="'Password'" v-model="password" :type="'password'" class="form-control"
                  placeholder="Password" id="inputNewPassword" name="newpassword" />
                <span v-show="errors.has('newpassword')" class="form-error">
                  {{ errors.first("newpassword") }}
                </span> -->
                <simpleInput :wrapclass="'mb20'" :required="true" :vvas="'New Password'" :label="'New Password'"
                  v-model="password" :datatype="'min:5|max:15|strongpassword'"
                  :placeHolder="'New Password'" :cid="'newpassword'" :fieldName="'newpassword'" :isPassword="true"/>

              </div>
            </div>
          </div>
        </div>
      </template>
      <template #modal-footer>
        <!----showLoader-->
        <p class="password_note"><img src="@/assets/images/lock.svg"> Password must contain 6 to 15 characters</p>
        <button class="form-cancel" @click="closeChangePassword">Cancel</button>
        <button class="primary_btn md" @click="updatePassword">Update</button>
      </template>
    </b-modal>
  </header>
</template>
<script>
// @ is an alias to /src

import JQuery from "jquery";
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import simpleInput from "@/views/forms/simpleInput.vue";

export default {
  name: 'header-vue',
  components: {
    DocumentsPreview,
    simpleInput,
  },
  data: () => ({
    showLoader: false,
    showPasswordChangePopup: false,
    password: '',
    showCurrentPassword: false,
    conformPassword: '',
    routeTitle: '',
    hideBackArrow: true,
    showProfilePopup: false,
    docPrivew: false,
    docType: '',
    selectedFile: null,
  }),
  computed: {

    getPageTitle() {
      this.routeTitle = this.$route.meta.title;
      return this.routeTitle
    },
    showOrHideBackButton() {
      this.hideBackArrow = this.$route.meta.hideBackButton;
      return this.hideBackArrow
    },
    getRoutePath() {
      if (this.routeTitle == 'Create Request') {
        return '/evaluations-list'
      }
      if (this.routeTitle == 'Evaluation Details' && [9].indexOf(this.getUserRoleId) > -1) {
        return '/professordetails'
      }
      if (this.routeTitle == 'Evaluation Details') {
        return '/evaluations-list'
      }
      return '/'
    },

  },
  methods: {
    updatePassword() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          this.showLoader = true;
          let path = "auth/change-password";

          let selectedUser = this.getUserData
          let postData = {
            newPassword: this.password.trim(),
            currentPassword: this.conformPassword.trim(),
            //'userId': selectedUser['_id'],
            "action": 'update-password'
          };
          this.$store.dispatch("commonAction", { data: postData, path: path, })
            .then((response) => {
              this.closeChangePassword()
              this.showToster({ message: response.message, isError: false })
            }).catch((error) => {
              // alert(JSON.stringify(error.message))
              this.showToster({ message: error.message, isError: true })
              this.showLoader = false;
              // this.showPasswordChangePopup = false
            });

        }
      })
    },
    openChangePassword() {
      this.password = ''
      this.conformPassword = ''
      this.showLoader = false;
     // this.$validator.reset();
      setTimeout(() => {
        this.showPasswordChangePopup = true;
        this.$bvModal.show('headerChangePassword')
      })
    },
    closeChangePassword() {
      this.password = ''
      this.conformPassword = ''
      this.showLoader = false;
     // this.$validator.reset();
      setTimeout(() => {
        this.showPasswordChangePopup = false;
        this.$bvModal.hide('headerChangePassword')
      })

    },
    gotoPage(path = "/") {
      path = this.getRoutePath
      this.$router.push(path);
    },
    logout() {
      this.$store.dispatch("logout").then(() => {
        this.$router.push("/login");
      });
    },

    openProfilePopup() {
      this.showProfilePopup = true
      //  this.$refs['success_model'].show();
      //  $bvModal.show('profile_model')
    },
    download_or_view(docItem) {


      let value = _.cloneDeep(docItem);
      // if (this.checkProperty(this.getPetitionDetails, 'caseNo') && this.checkProperty(value, 'name')) {
      //   let docName = _.cloneDeep(value['name']);
      //   value['name'] = this.checkProperty(this.getPetitionDetails, 'caseNo') + "_" + docName;
      // }


      var _self = this;
      this.formSubmited = false;
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }
      // value = Object.assign(value, { 'petitionId': this.petition['_id'] })
      // value = Object.assign(value, { 'subTypeDetails': this.petition['subTypeDetails'] })


      this.selectedFile = value;
      this.docValue = "";
      this.docPrivew = false;
      this.docType = false;
      this.docType = this.findmsDoctype(value["name"], value.mimetype);

      if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
        //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
          // "petitionId": value['petitionId'],

          // entityType:value['petitionId']
          "fileName": value.name ? value.name : ''
        };
        // if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
        //   postdata['entityType'] = 'perm'
        // } else {
        //   postdata['entityType'] = 'case'
        // }


        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;


          if (this.docType == "office") {
            this.docPrivew = true;
            setTimeout(() => {
              document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
              let _editing = false;

              // if ([3, 4].indexOf(this.getUserRoleId) > -1) {
              //   _editing = false;
              // }

              // if (value.viewmode) {
              //   _editing = false;
              // }
              var _ob = {}
              // if (value.editedDocument) {
              //   _ob = {

              //     evaluationId: this.evaluationDetails._id,
              //     name: value.name,
              //     _id: value._id,
              //     "extn": "docx",
              //     "formLetterType": "Letter",
              //     parentId: value.parentId
              //   }

              // } else {

              _ob = {

                name: value.name,
                evaluationId: this.evaluationDetails._id,
                _id: value._id,
                "extn": "docx",
                "formLetterType": "Letter",
                parentId: value._id

              }

              //  }


              window.docEditor = new DocsAPI.DocEditor("placeholder2",
                {

                  "document": {
                    "c": "forcesave",
                    "fileType": "docx",
                    "key": value._id,
                    "userdata": JSON.stringify(_ob),
                    "title": value.name,
                    "url": response.data.result.data,
                    permissions: {
                      edit: _editing,
                      download: true,
                      reader: false,
                      review: false,
                      comment: false
                    }
                  },

                  "documentType": "word",
                  "height": "100%",
                  "width": "100%",

                  "editorConfig": {
                    "userdata": JSON.stringify(_ob),
                    "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                    "customization": {
                      "logo": {
                        "image": "https://immibox.com/app/favicon.png",
                        "imageDark": "https://immibox.com/app/favicon.png",
                        "url": "https://immibox.com"
                      },
                      "anonymous": {
                        "request": false,
                        "label": "Guest"
                      },
                      "chat": false,
                      "comments": false,
                      "compactHeader": false,
                      "compactToolbar": true,
                      "compatibleFeatures": false,
                      "feedback": {
                        "visible": false
                      },
                      "forcesave": true,
                      "help": false,
                      "hideNotes": true,
                      "hideRightMenu": true,
                      "hideRulers": true,
                      layout: {
                        toolbar: {
                          "collaboration": false,
                        },
                      },
                      "macros": false,
                      "macrosMode": "warn",
                      "mentionShare": false,
                      "plugins": false,
                      "spellcheck": false,
                      "toolbarHideFileName": true,
                      "toolbarNoTabs": true,
                      "uiTheme": "theme-light",
                      "unit": "cm",
                      "zoom": 100
                    },
                  }, events: {
                    onReady: function () {

                    },
                    onDocumentStateChange: function (event) {
                      var url = event.data;
                      console.log(event)

                      if (!event.data) {

                        if (value.editedDocument) {

                        }

                      }
                    }

                  }
                });
              //this.docValue = encodeURIComponent(response.data.result.data);
            }, 100)
          }

          if (this.docType == "pdf") {

            // this.downloadFile(this.docValue, value.mimetype, value.name)

            // return
            var _vid = value._id;
            if (value.parentId) {
              _vid = value.parentId;
            }
            var viewmode = 1; // Enable edit
            viewmode = 0; //Disabled Edit
            if (value.viewmode) {
              viewmode = 0;
            }
            this.docValue = "https://carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
            console.log(this.docValue)
            this.docPrivew = true;
          }
          if (this.docType == "image") {
            this.docPrivew = true;
          }



        });
      } else {



        this.downloads3file(value);
      }

    },

  },
  mounted() {
    const $ = JQuery;
    $(".mobile_menu").click(function () {
      $(this).toggleClass("open");
      $(".side_menu").toggleClass("open");
      $("body").toggleClass("hidden");
    });
    $(window).scroll(function () {
      var scroll = $(window).scrollTop();
      if (scroll >= 1) {
        $('header').addClass("fixed");
      } else {
        $('header').removeClass("fixed");
      }
    });


    this.routeTitle = this.$route.meta.title;
    this.hideBackArrow = this.$route.meta.hideBackButton;
    this.profileData = this.getUserData

  },
  watch: {
    $route() {
      //  this.$store.commit('updatedNewLogo', { "url": null, 'type': 'favicon' });
      // this.$store.commit('updatedNewLogo', { "url": null, 'type': 'logo' });
      //  var elemenet = document.getElementById("tooltipcal");
      //  elemenet.style.display = "none"

      this.routeTitle = this.$route.meta.title;
      this.hideBackArrow = this.$route.meta.hideBackButton;
      var _s = this;

      let nonfloatPage = _.find(this.settingsItems, function (o) {
        return o.slug == _s.$route.name;
      });
      if (!nonfloatPage) {

      }
    },

  },
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
}
</script>