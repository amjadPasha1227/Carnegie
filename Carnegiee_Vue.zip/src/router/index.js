import Vue from 'vue'
import VueRouter from 'vue-router'
import _ from "lodash"
import store from '@/store'
import axios from 'axios';

Vue.use(VueRouter)

const routes = [

  {
    path: '/',
    name: 'login',
    component: () => import('@/layouts/Login.vue'),
    children: [

      {
        path: '/',
        name: 'Login View',
        meta: {
          title: 'Login',
          requiresAuth: false,

        },
        component: () => import('@/views/login.vue')
      },
      {
        path: '/login',
        name: 'Login View',
        meta: {
          title: 'Login',
          requiresAuth: false,

        },
        component: () => import('@/views/login.vue')
      },
      {
        path: '/forgotpassword',
        name: 'Forgotpassword View',
        meta: {
          title: 'Forgot Password',
          requiresAuth: false,

        },
        component: () => import('@/views/forgotPassword.vue')
      },
      {
        path: '/resetpassword',
        name: 'Resetpassword View',
        meta: {
          title: 'Reset Password',
          requiresAuth: false,

        },
        component: () => import('@/views/resetPassword.vue')
      },
      {
        path: '/public/set-password',
        name: 'Resetpassword View',
        meta: {
          title: 'Set Password',
          requiresAuth: false,

        },
        component: () => import('@/views/resetPassword.vue')
      },
      {
        path: '/createaccount',
        name: 'createaccount View',
        meta: {
          title: 'Create Account',
          requiresAuth: false,

        },
        component: () => import('@/views/createAccount.vue')
      },
      {
        path: '/guest-request',
        name: 'guest-request',
        meta: {
          title: 'Guest Request',
          requiresAuth: false,

        },
        component: () => import('@/views/guestRequest.vue')
      },
      {
        path: '/public/reset-password',
        name: 'reset-password',
        // component: () => import('@/views/pages/setForgetPassword.vue'),
        component: () => import('@/views/resetPassword.vue'),
        meta: {
          requiresAuth: false
        }
      },
      {
        path: '/professor_profile/:itemId',
        name: 'Professor Profile',
        meta: {
          title: 'Professor Profile',
          requiresAuth: false,

        },
        component: () => import('@/views/professorDetailsMail.vue')
      },
      {
        path: '/wwhs',
        name: 'wwhs-request',
        meta: {
          title: 'WWHS Request',
          requiresAuth: false,

        },
        component: () => import('@/views/evaluationRequestWHS.vue')
      },
    ]
  },

  //  After Login Layout
  {
    path: '/',
    name: 'dataview',
    component: () => import('@/layouts/Main.vue'),
    children: [

      {
        path: '/dashboard',
        name: 'dashboardView',
        meta: {
          title: 'Dashboard',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/dashboard.vue')
      },
      {
        path: '/evaluations-list',
        name: 'Evaluations',
        meta: {
          title: 'Evaluations',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/evaluationsList.vue')
      },
      {
        path: '/emailtemplate',
        name: 'emailtemplateView',
        meta: {
          title: 'Email Templates',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/emailTemplate.vue')
      },
      {
        path: '/emails',
        name: 'emailsView',
        meta: {
          title: 'Emails',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/emails.vue')
      },
      {
        path: '/evaluationtemplate',
        name: 'evaluationTemplateView',
        meta: {
          title: 'Evaluation Templates',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/evaluationTemplate.vue')
      },
      {
        path: '/userdetails',
        name: 'userdetailsView',
        meta: {
          title: 'Users',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/userDetails.vue')
      },
      {
        path: '/customerdetails',
        name: 'customerdetailsView',
        meta: {
          title: 'Customers',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/customerDetails.vue')
      },
      {
        path: '/requests',
        name: 'requests',
        meta: {
          title: 'Evaluations',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/request.vue')
      },
      {
        path: '/requestdetails/:itemId',
        name: 'requestdetails',
        meta: {
          title: 'Evaluation Details',
          requiresAuth: true,
          hideBackButton: false,
        },
        component: () => import('@/views/requestdetails.vue')
      },
      {
        path: '/invoices',
        name: 'invoices',
        meta: {
          title: 'Invoices',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/invoices.vue')
      },
      // {
      //   path: '/account',
      //   name: 'account',
      //   meta: {
      //     title: 'Account',
      //     requiresAuth: false,

      //   },
      //   component: () => import('@/views/account.vue')
      // },
      {
        path: '/evaluationslist',
        name: 'customer-requests',
        meta: {
          title: 'Customer Requests',
          requiresAuth: true,

        },
        component: () => import('@/views/customerRequestsList.vue')
      },
      {
        path: '/create-evaluation',
        name: 'create-evaluation',
        meta: {
          title: 'Create Request',
          requiresAuth: true,
          hideBackButton: false,
        },
        component: () => import('@/views/createRequest.vue')
      },
      {
        path: '/evaltemplates',
        name: 'evaluation-templates',
        meta: {
          title: 'Evaluation Templates',
          requiresAuth: true,
          hideBackButton: false,
        },
        component: () => import('@/views/mergedocuments/documentsList')
      },
      {
        path: '/foldresAndFiles/:itemId',
        name: 'templates_files',
        meta: {
          title: 'Evaluation Templates',
          requiresAuth: true,
          hideBackButton: false,
        },
        component: () => import('@/views/mergedocuments/foldresAndFiles.vue')

      },
      {
        path: '/client-users',
        name: 'clientUsersList',
        meta: {
          title: 'Client Users',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/clientUsersList.vue')
      },
      {
        path: '/repository',
        name: 'repository_files',
        meta: {
          title: 'Repository',
          requiresAuth: true,
          hideBackButton: false,
        },
        component: () => import('@/views/filesRepository')

      },
      {
        path: '/repositoryFiles/:itemId',
        name: 'templates_files',
        meta: {
          title: 'Repository',
          requiresAuth: true,
          hideBackButton: false,
        },
        component: () => import('@/views/mergedocuments/foldresAndFiles.vue')

      },



    ]
  },

  // Customer and Professor Layout
  {
    path: '/',
    name: 'dataview',
    component: () => import('@/layouts/User.vue'),
    children: [
      {
        path: '/account',
        name: 'account',
        meta: {
          title: 'Account',
          requiresAuth: false,

        },
        component: () => import('@/views/account.vue')
      },
      {
        path: '/professordetails',
        name: 'professor-details',
        meta: {
          title: 'Professor Details',
          requiresAuth: true,

        },
        component: () => import('@/views/professordetails.vue')
      },
      {
        path: '/evaluationdetails/:itemId',
        name: 'professorrequestdetails',
        meta: {
          title: 'Evaluation Details',
          requiresAuth: true,
          hideBackButton: false,
        },
        component: () => import('@/views/requestdetails.vue')
      },

    ]
  }




]

const router = new VueRouter({
  base: process.env.BASE_URL,
  scrollBehavior() {
    return { x: 0, y: 0 }
  },
  mode: 'history',
  routes
})





router.beforeEach((to, from, next) => {
  const user = store.getters.getuser;


  if (to.meta.requiresAuth === false) {
    if ((['/resetpassword', '/guest-request','/wwhs'].indexOf(to.path) > -1 || ['/public/set-password'].indexOf(to.path) > -1 || ['/public/reset-password'].indexOf(to.path) > -1 || ['/createaccount'].indexOf(to.path) > -1) && store.getters['isLoggedIn']) {
      localStorage.removeItem('token');
      localStorage.removeItem('role_id');
      localStorage.removeItem('user');
      delete axios.defaults.headers.common['Authorization']
      store.dispatch("logout");
    }
    if (store.getters['isLoggedIn'] && to.path != '/dashboard') {
      next('/dashboard');
      return;
    }

  } else {


    if (store.getters['isLoggedIn']) {
      if (store.state.user['roleId'] != 9 && to.path == "/professordetails") {

        next('/dashboard')
        return
      }
      if (store.state.user['roleId'] != 15 && to.path == "/evaluationslist") {

        next('/dashboard')
        return
      }
      if (store.state.user['roleId'] == 9 && to.path != "/professordetails" && !(to.path.includes('/requestdetails/'))) {
        next('/professordetails')
        return
      }
      if (store.state.user['roleId'] == 15 && to.path != "/evaluationslist" && !to.path.includes('/requestdetails/') && !to.path.includes('/create-evaluation')) {
        next('/evaluationslist')
        return
      }

      if (store.getters['isLoggedIn'] && to.path == '/') {
        if ([5].indexOf(this.getUserRoleId) > -1) {
          next('/evaluations-list');
        } else {
          next('/dashboard');
        }
        return;
      }
      if (!store.getters['isLoggedIn'] && to.path != '/') {
        next('/');
        return;
      }
    } else {
      next('/login')
      return
    }


  }

  next()
})

router.afterEach(() => {
  if (store.state.token && store.state.user['_id']) {
    let postData = { 'accessToken': store.state.token, 'userId': store.state.user['_id'] };
    store.dispatch("loginFromAccessToken", postData).then((res) => {

    }).catch((err) => {

    });
  } else {

  }



})




export default router
