<template>
  <div class="wrapper" v-bind:class="{ 'professor_requests': [9, 15].indexOf(getUserRoleId) > -1 }">
    <headerVue />
    <sideBar />
    <div class="main_area">
      <router-view />
    </div>
    <!-- <cookiePopup v-if="!cookiesAccepted" /> -->
  </div>
</template>

<script>
// @ is an alias to /src
import sideBar from "@/views/sideBar.vue"
import headerVue from "@/views/header.vue"
import cookiePopup from '@/views/common/manageCookie.vue';

export default {
  name: 'Main',
  components: {
    sideBar,
    headerVue,
    cookiePopup,
  },
  computed: {
    cookiesAccepted() {
      // alert()
      return document.cookie.includes('cookiesAccepted=true');
    },
  },
}
</script>