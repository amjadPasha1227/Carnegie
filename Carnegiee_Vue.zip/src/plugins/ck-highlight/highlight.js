import Plugin from '@ckeditor/ckeditor5-core/src/plugin';
import Command from '@ckeditor/ckeditor5-core/src/command';
import HighlightUI from './highlightui';

export default class Highlight extends Plugin {
  static get requires() {
    return [HighlightUI];
  }
}

export class HighlightCommand extends Command {
  execute() {
    this.editor.model.change((writer) => {
      // Apply your custom markup or styling to the selected text
      writer.addAttributes({ style: 'background-color: yellow' }, this.editor.model.document.selection.getSelectedElement());
    });
  }
}
