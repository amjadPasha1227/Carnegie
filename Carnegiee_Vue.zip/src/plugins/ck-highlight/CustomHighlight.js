// src/plugins/CustomHighlight.js
import Plugin from '@ckeditor/ckeditor5-core/src/plugin';
import { toWidget, viewToModelPositionOutsideModelElement } from '@ckeditor/ckeditor5-widget/src/utils';
import Widget from '@ckeditor/ckeditor5-widget/src/widget';

export default class CustomHighlight extends Plugin {
  static get requires() {
    return [Widget];
  }

  init() {
    this.editor.model.schema.register('highlight', {
      allowWhere: '$text',
      isInline: true,
      isObject: true,
      allowAttributes: ['color'],
    });

    // Rest of the conversion code...
  }

    // Export the plugin name
    static get pluginName() {
        return 'CustomHighlight';
      }
}
