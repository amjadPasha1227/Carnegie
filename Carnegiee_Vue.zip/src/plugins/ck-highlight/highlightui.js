import Plugin from '@ckeditor/ckeditor5-core/src/plugin';
import ButtonView from '@ckeditor/ckeditor5-ui/src/button/buttonview';

export default class HighlightUI extends Plugin {
  init() {
    const editor = this.editor;
    editor.ui.componentFactory.add('highlight', (locale) => {
      const view = new ButtonView(locale);

      view.set({
        label: 'Highlight Text',
        icon: '<svg>...</svg>', // Add your icon markup here
        tooltip: true,
      });

      view.on('execute', () => {
        editor.execute('highlight');
      });

      return view;
    });
  }
}
