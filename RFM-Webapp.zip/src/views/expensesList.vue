<template>
    <div class="db_page">
        <!-- <div class="page_header">
        <h3>Users</h3>
      </div> -->
        <div class="filter_sec">
            <div class="d-flex w-100">
                <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" />
                <div class="custom-datepicker">

                    <date-range-picker :maxDate="new Date()" :autoApply="true" @update="applyFilters"
                        :placeholder="'dd/mm/yyyy'" :ranges="false" :opens="'left'"
                        :locale-data="{ format: 'mmm dd, yyyy', customRangeLabel: 'Custom Range', }"
                        v-model="createdeDateRange"></date-range-picker>
                    <span class="clear" @click="clearDateRange()"
                        v-if="checkProperty(createdeDateRange, 'startDate') && checkProperty(createdeDateRange, 'endDate')"><img
                            src="@/assets/images/close.svg"></span>
                </div>
            </div>
            <div class="filters_right" v-if="canCreateUser(getUserRoleId)">

                <button class="add_btn" @click="showAddExpensePopup(false)"><span></span><em>Add Expense</em></button>
            </div>
        </div>
        <div class="table-responsive" v-if="false">

            <template v-if="checkProperty(expensesList, 'length') <= 0">
                <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users'
                    :loading="isListLoading" />
            </template>
            <table class="table user_table" v-if="checkProperty(expensesList, 'length') > 0 && !isListLoading">
                <thead>
                    <tr>
                        <th>Nature of Expense</th>
                        <!-- <th>Transaction Date</th> -->
                        <th>Paid To</th>
                        <th>Amount ($)</th>
                        <th>Balance ($)</th>
                        <!-- <th>Paid From</th> -->
                        <!-- <th>Paid By</th> -->
                        <!-- <th>Updated By</th> -->
                        <!-- <th>Updated On</th> -->
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in    expensesList   " v-bind:key="index">

                        <td @click="editDetails(item, false)">
                            <span class="request_id">{{ checkProperty(item, 'expensesNatureDetails', 'name') ?
                                item.expensesNatureDetails.name : '' }}</span>
                        </td>
                        <!-- <td><span class="last_name">{{ item.transactionDate | formatDate }}</span></td> -->
                        <td><span>{{ checkProperty(item, 'paidToDetails', 'name') ? checkProperty(item,
                            'paidToDetails', 'name') : '' }}</span></td>
                        <td><span class="ph_num" v-if="checkProperty(item, 'amount')">
                                {{ checkProperty(item, 'amount') }}
                            </span>
                            <span v-else></span>
                        </td>
                        <td><span class="ph_num" v-if="checkProperty(item, 'balanceDue')">
                                {{ checkProperty(item, 'balanceDue') }}
                            </span>
                            <span v-else></span>
                        </td>
                        <!-- <td><span>{{ checkProperty(item, 'paidFromDetails', 'name') ? item.paidFromDetails.name : ''
                        }}</span></td> -->
                        <!-- <td><span>{{ checkProperty(item, 'paidByDetails', 'name') ? checkProperty(item,
                            'paidByDetails', 'name') : '' }}</span></td> -->

                        <!-- <td><span>{{ checkProperty(item, 'createdByName') ? item.createdByName : '' }}</span></td> -->
                       <!-- <td><span>{{ checkProperty(item, 'createdOn') | formatDateTime }}</span></td>-->
                        <td>
                            <div class="actions">
                                <dropdownHover aria-disabled="true">
                                    <b-dropdown-item @click="editDetails(item, true)">Edit</b-dropdown-item>
                                    <b-dropdown-item @click="editDetails(item, false)">View Details</b-dropdown-item>
                                </dropdownHover>
                            </div>

                        </td>
                    </tr>

                </tbody>
            </table>
            <!-- <h2 v-if="expensesList.length <= 0" class="loading_NoData">
            <template v-if="isListLoading"> Loading.....</template>
            <template v-else> No Users Found!</template>
          </h2> -->
        </div>

        <div class="mobile_table_list">
            <template v-if="checkProperty(expensesList, 'length') <= 0">
                <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users'
                    :loading="isListLoading" />
            </template>
            <ul v-if="checkProperty(expensesList, 'length') > 0 && !isListLoading">
                <li v-for="(item, index) in expensesList " v-bind:key="index">
                    <div class="list_row">
                        <div>
                            <span class="list_heading">{{ checkProperty(item, 'expensesNatureDetails', 'name') ?
                                item.expensesNatureDetails.name : '' }}</span>
                        </div>
                        <div class="actions">
                            <dropdownHover aria-disabled="true">
                                <b-dropdown-item @click="editDetails(item, true)">Edit</b-dropdown-item>
                                <b-dropdown-item @click="editDetails(item, false)">View Details</b-dropdown-item>
                            </dropdownHover>
                        </div>
                    </div>
                    <div class="list_row">
                        <div><span>paid to :</span> {{ checkProperty(item, 'paidToDetails', 'name') ? checkProperty(item,
                            'paidToDetails', 'name') : '' }}</div>
                        <div></div>
                    </div>
                    <div class="list_row">
                        <div><span>amount ($) :</span> {{ checkProperty(item, 'amount') }}</div>
                        <div><span>balance ($) :</span> {{ checkProperty(item, 'balanceDue') }}</div>
                    </div>
                </li>
            </ul>
            <div class="pagination-sec" v-if="checkProperty(expensesList, 'length') > 0">
                <div class="per-page">
                    <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) +
                        expensesList.length) +
                        ' of ' + totalCount + ' Results' }}</label>
                </div>
                <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
                    @input=" isListLoading = true, updateLoading(true), getExpenses()"></b-pagination>
            </div>
        </div>
        <!-- Add User Modal -->
        <b-modal v-model="showAddExpense" id="adduser_model" dialog-class="adduser_model" centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">{{ isExpenseEdit ? 'Update Expense' : 'Add Expense' }}</h6>
                <a class="close" @click=" showAddExpense = false"></a>
            </template>
            <template>

                <div class="form_info">
                    <div class="row">
                        <div class="col-md-6">
                            <simpleSelect :multiple="false" :wrapclass="'mb20'" :label="'Nature of Expense'"
                                :optionslist="natureOfExpenseList" :display="true"
                                :place-holder="'Select Nature of Expense'" :searchable="false" :required="true"
                                :close-on-select="true" :clear-on-select="true" v-model="expense.natureOfExpense"
                                :fieldName="'natureOfExpense'" :cid="'natureOfExpense'" :vvas="'Nature of Expense'"
                                :isDynamicDropdown="true" @input="updateNatureOfExpenses" />
                        </div>

                        <div class="col-md-6">
                            <datepicker :wrapclass="'mb20'" :required="true" v-model="expense.transactionDate"
                                fieldName="transactionDate" label="Transaction Date" :dateEnableTo="getCurrentDate()" />
                        </div>

                        <div class="col-md-6">
                            <simpleSelect :multiple="false" :wrapclass="'mb20'" :label="'Paid To'"
                                :optionslist="paidToCustList" :display="true" :place-holder="'Select Paid To'"
                                :searchable="false" :required="true" :close-on-select="true" :clear-on-select="true"
                                v-model="expense.paidTo" :fieldName="'paidTo'" :cid="'paidTo'" :vvas="'Paid To'"
                                :isDynamicDropdown="true" @addCustomer="updatePaidTo" :isAddCustomer="true" />
                        </div>


                        <!-- <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'paidTo'" :cid="'paidTo'" :label="'Paid To'"
                                :placeHolder="'Paid To'" :vvas="'Paid To'" :display="true" :required="true"
                                v-model="expense.paidTo" :allowAlphNum="true" />

                        </div> -->
                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'amount'" :cid="'amount'" :label="'Amount ($)'"
                                :placeHolder="'Amount'" :vvas="'Amount'" :display="true" :required="true"
                                v-model="expense.amount" :onlyNumbers="true" :allowFloatingPoint="true"
                                @input="updateBalanceAmount" />

                        </div>
                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'paidAmount'" :cid="'paidAmount'"
                                :label="'Paid ($)'" :placeHolder="'Paid'" :vvas="'Paid'" :display="true"
                                v-model="expense.paidAmount" :onlyNumbers="true" :allowFloatingPoint="true"
                                @input="updateBalanceAmount" />
                        </div>
                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'balanceDue'" :cid="'balanceDue'"
                                :label="'Balance Due ($)'" :placeHolder="'Balance Due'" :vvas="'Balance Due'"
                                :display="true" v-model="expense.balanceDue" :onlyNumbers="true" :allowFloatingPoint="true"
                                :disabled="true" />
                        </div>

                        <div class="col-md-6">
                            <datepicker :wrapclass="'mb20'" :required="isDueOnRequired" v-model="expense.balanceDueBy"
                                fieldName="balanceDueBy" label="Balance Due On" :dateEnableFrom="getCurrentDate(true)" />
                        </div>

                        <div class="col-md-6">
                            <simpleSelect :multiple="false" :wrapclass="'mb20'" :label="'Paid From'"
                                :optionslist="paidFromList" :display="true" :place-holder="'Select Paid From'"
                                :searchable="false" :required="true" :close-on-select="true" :clear-on-select="true"
                                v-model="expense.paidFrom" :fieldName="'paidFrom'" :cid="'paidFrom'" :vvas="'Paid From'" />
                        </div>
                        <!-- <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'paidFrom'" :cid="'paidFrom'" :label="'Paid From'"
                                :placeHolder="'Paid From'" :vvas="'Paid From'" :display="true" :required="true"
                                v-model="expense.paidFrom" />
                        </div> -->

                        <div class="col-md-6">

                            <simpleSelect :multiple="false" :wrapclass="'mb20'" :label="'Paid By'"
                                :optionslist="paidByUsersList" :display="true" :place-holder="'Select Paid By'"
                                :searchable="false" :required="true" :close-on-select="true" :clear-on-select="true"
                                v-model="expense.paidBy" :fieldName="'paidBy'" :cid="'paidBy'" :vvas="'Paid By'" />

                            <!-- <simpleInput :wrapclass="'mb20'" :fieldName="'paidBy'" :cid="'paidBy'" :label="'Paid By'"
                                :placeHolder="'Paid By'" :vvas="'Paid By'" :display="true" :required="true"
                                v-model="expense.paidBy" /> -->
                        </div>

                        <div class="col-md-12">
                            <textArea :label="'Notes'" :wrapclass="'h80 mb10'" placeHolder="Notes" v-model="expense.notes"
                                :required="false" :fieldName="'notes'" :cid="'notes'"></textArea>
                        </div>


                    </div>
                </div>
            </template>
            <template #modal-footer>
                <button class="form-cancel" @click=" showAddExpense = false">Cancel</button>
                <button class="primary_btn md" @click="addOrUpdateExpense">{{ isExpenseEdit ? 'Update' : 'Submit'
                }}</button>
            </template>
        </b-modal>


        <!-- Add Customer Modal -->
        <b-modal v-model="showAddCustomer" id="adduser_model" dialog-class="adduser_model" centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">{{ 'Paid To' }}</h6>
                <a class="close" @click=" showAddCustomer = false"></a>
            </template>
            <template>

                <div class="form_info">
                    <form :data-vv-scope="'customerForm'">
                        <div class="row">
                            <div class="col-md-6">
                                <simpleInput :wrapclass="'mb20'" :fieldName="'customerName'" :cid="'customerName'"
                                    :label="'Customer Name'" :placeHolder="'Customer Name'" :vvas="'Customer Name'"
                                    :display="true" :required="true" v-model="customer.customerName" :allowAlphNum="true"
                                    :formscope="'customerForm'" />
                            </div>

                            <div class="col-md-6">
                                <simpleInput :wrapclass="'mb20'" :fieldName="'email'" :cid="'email'" :label="'Email'"
                                    :placeHolder="'Email'" :vvas="'Email'" :display="true" :required="false"
                                    :datatype="'email'" v-model="customer.email" :emailFormat="true"
                                    :formscope="'customerForm'" />
                            </div>
                            <div class="col-md-6">
                                <phoneInput :wrapclass="'mb20'" :display="true" :tplkey="'phoneNumber'"
                                    @updatephoneCountryCode="updatePhoneCountryCode"
                                    :countrycode="customer.phoneCountryCode.countryCode" cid="phoneNumber"
                                    v-model="customer.phone" :fieldName="'phoneNumber'" label="Phone Number"
                                    placeHolder="Phone Number" :required="true" :formscope="'customerForm'" />
                            </div>

                        </div>
                    </form>
                </div>
            </template>
            <template #modal-footer>
                <button class="form-cancel" @click=" showAddCustomer = false">Cancel</button>
                <button class="primary_btn md" @click="addCustomer">{{ 'Submit' }}</button>
            </template>
        </b-modal>


        <!-- User Added Success Modal -->
        <b-modal v-model="showAddExpenseSuccess" id="success_model" dialog-class="success_model user_success" centered
            hide-header hide-footer>
            <template>
                <figure>
                    <img src="@/assets/images/success_mdl_img.png" />
                </figure>
                <h4 class="m-0">{{ isExpenseEdit ? 'Expense updated!' : 'Expense added!' }}</h4>
                <h7 class="m-0" style="padding-left:20px;padding-right:20px;text-align: center;">{{ successMsg }}</h7>
                <button class="primary_btn md" style="margin-top:14px ;"
                    @click=" showAddExpenseSuccess = false; page = 1; isListLoading = true; updateLoading(true); getExpenses()">OKAY</button>
            </template>
        </b-modal>

        <!-- Details Modal -->
        <b-modal v-model="showDetailsPopup" id="create_template" dialog-class="create_template details_modal" centered
            hide-footer no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">{{ 'Expense Details' }}</h6>
                <a class="close" @click="showDetailsPopup = false"></a>
            </template>
            <template>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form_group" v-if="checkProperty(selectedExpense, 'expensesNatureDetails', 'name')">
                            <lable class="form_label">Nature of Expense</lable>
                            <p>{{ checkProperty(selectedExpense, 'expensesNatureDetails', 'name') ?
                                checkProperty(selectedExpense, 'expensesNatureDetails', 'name')
                                : '' }}</p>
                        </div>

                        <div class="form_group" v-if="checkProperty(selectedExpense, 'transactionDate')">
                            <lable class="form_label">Transaction Date</lable>
                            <p>{{ checkProperty(selectedExpense, 'transactionDate') | formatDate }}</p>
                        </div>

                        <div class="form_group" v-if="checkProperty(selectedExpense, 'paidToDetails', 'name')">
                            <lable class="form_label">Paid To</lable>
                            <p>{{ checkProperty(selectedExpense, 'paidToDetails', 'name') ? checkProperty(selectedExpense,
                                'paidToDetails', 'name')
                                : '' }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedExpense, 'amount')">
                            <lable class="form_label">Amount ($)</lable>
                            <p>{{ checkProperty(selectedExpense, 'amount') }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedExpense, 'paidAmount')">
                            <lable class="form_label">Paid ($)</lable>
                            <p>{{ checkProperty(selectedExpense, 'paidAmount') ? checkProperty(selectedExpense,
                                'paidAmount')
                                : '' }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedExpense, 'balanceDue')">
                            <lable class="form_label">Balance Due ($)</lable>
                            <p>{{ checkProperty(selectedExpense, 'balanceDue') ? checkProperty(selectedExpense,
                                'balanceDue')
                                : '' }}</p>
                        </div>

                        <div class="form_group" v-if="checkProperty(selectedExpense, 'balanceDueBy')">
                            <lable class="form_label">Balance Due On</lable>
                            <p>{{ checkProperty(selectedExpense, 'balanceDueBy') | formatDate }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedExpense, 'paidFromDetails', 'name')">
                            <lable class="form_label">Paid From</lable>
                            <p>{{ checkProperty(selectedExpense, 'paidFromDetails', 'name') ? checkProperty(selectedExpense,
                                'paidFromDetails', 'name')
                                : '' }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedExpense, 'paidByDetails', 'name')">
                            <lable class="form_label">Paid By</lable>
                            <p>{{ checkProperty(selectedExpense, 'paidByDetails', 'name') ? checkProperty(selectedExpense,
                                'paidByDetails', 'name')
                                : '' }}</p>
                        </div>

                        <div class="form_group" v-if="checkProperty(selectedExpense, 'createdByName')">
                            <lable class="form_label">Updated By</lable>
                            <p>{{ checkProperty(selectedExpense, 'createdByName') ? checkProperty(selectedExpense,
                                'createdByName')
                                : '' }}</p>
                        </div>

                    </div>
                    <div class="col-md-12" v-if="checkProperty(selectedExpense, 'notes')">
                        <div class="form_group notes" >
                            <lable class="form_label">Notes</lable>
                            <p v-html="checkProperty(selectedExpense, 'notes')"></p>
                        </div>
                    </div>

                </div>
            </template>
        </b-modal>

        <EditRestructPopup v-if="showSubmitConfirmPopup" @submitAction="submitAction"></EditRestructPopup>


    </div>
</template>
  
<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import fileUpload from "@/views/forms/fileupload.vue";
import simpleSelect from '@/views/forms/simpleSelect.vue';
import dropdownHover from '@/views/forms/dropdownHover.vue';
import radioInput from "@/views/forms/radioInput.vue";
import textArea from "@/views/forms/textarea.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import phoneInput from "@/views/forms/phonenumber.vue";
import axios from 'axios';
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import NoDataFound from "@/views/common/noData.vue";
import moment from "moment";
import datepicker from '@/views/forms/datePicker.vue';
import DateRangePicker from "vue2-daterange-picker";
import 'vue2-daterange-picker/dist/vue2-daterange-picker.css'
import 'vue2-datepicker/index.css';
import EditRestructPopup from '@/views/common/editRestructPopup.vue';

export default {
    name: 'dashboard-view',
    components: {
        searchInput,
        simpleSelect,
        dropdownHover,
        radioInput,
        simpleInput,
        fileUpload,
        fileUploadDrag,
        textArea,
        phoneInput,
        DocumentsPreview,
        NoDataFound,
        datepicker,
        DateRangePicker,
        EditRestructPopup,
    },
    data: () => ({
        showSubmitConfirmPopup: false,
        showAddExpense: false,
        showAddExpenseSuccess: false,
        showProfile: false,
        showStatusChangePopup: false,
        isExpenseEdit: false,
        isListLoading: true,
        page: 1,
        perpage: 20,
        totalCount: 0,
        currentPage: 1,
        expensesList: [],
        filterSelectedStatuses: null,
        filterSearch: '',
        createdeDateRange: {
            startDate: null,
            endDate: null
        },
        expense: {
            natureOfExpense: '',
            transactionDate: '',
            paidTo: null,
            amount: '',
            paidFrom: null,
            paidBy: null,
            notes: '',
            paidAmount: '',
            balanceDue: '',
            balanceDueBy: null,
        },
        selectedExpense: null,
        successMsg: '',

        paidFromList: [],
        natureOfExpenseList: [],
        paidByUsersList: [],
        paidToCustList: [],
        showAddCustomer: false,
        customer: {
            customerName: '',
            email: '',
            phone: null,
            phoneCountryCode: {
                countryCode: 'US',
                countryCallingCode: ''
            },

        },
        isDueOnRequired: true,
        showDetailsPopup: false,
    }),
    methods: {
        submitAction(actionType) {
            this.showSubmitConfirmPopup = false
        },
        clearDateRange() {
            //alert()
            this.createdeDateRange = {
                startDate: null,
                endDate: null
            }
            this.applyFilters()
        },
        showAddExpensePopup(isEdit = false) {
            this.isExpenseEdit = false
            this.expense = {
                natureOfExpense: '',
                transactionDate: '',
                paidTo: '',
                amount: '',
                paidFrom: null,
                paidBy: null,
                notes: '',
                paidAmount: '',
                balanceDue: '',
                balanceDueBy: null,
            }

            this.showAddExpense = true
        },

        addOrUpdateExpense() {
            this.$validator.validateAll().then((result) => {
                if (result) {

                    // let postData = _.cloneDeep(this.user)
                    let postData = {
                        "transactionDate": this.expense.transactionDate,
                        "paidToId": this.checkProperty(this.expense, 'paidTo', '_id') ? this.checkProperty(this.expense, 'paidTo', '_id') : '',
                        "expenseNatureId": this.expense.natureOfExpense.id,
                        "amount": this.expense.amount,
                        "paidFromId": this.checkProperty(this.expense, 'paidFrom', 'id') ? this.checkProperty(this.expense, 'paidFrom', 'id') : '',
                        "paidById": this.checkProperty(this.expense, 'paidBy', '_id') ? this.checkProperty(this.expense, 'paidBy', '_id') : '',
                        "notes": this.expense.notes,
                        "today": new Date(),
                        "paidAmount": this.checkProperty(this.expense, 'paidAmount') ? this.checkProperty(this.expense, 'paidAmount') : '',
                        "balanceDue": this.checkProperty(this.expense, 'balanceDue') ? this.checkProperty(this.expense, 'balanceDue') : '',
                        "balanceDueBy": this.checkProperty(this.expense, 'balanceDueBy') ? this.checkProperty(this.expense, 'balanceDueBy') : '',

                    }

                    if (this.isExpenseEdit) {
                        postData['expenseId'] = this.selectedExpense._id
                        this.$store
                            .dispatch("userUpdate", postData)
                            .then((response) => {
                                if (response.error) {
                                    this.showToster({ message: response.error.message, isError: true });
                                } else {
                                    this.successMsg = response.message
                                    this.showAddExpense = false
                                    //this.showAddExpenseSuccess = true
                                    this.exp = []
                                    this.showToster({ message: response.message, isError: false });
                                    this.isListLoading = true
                                    this.updateLoading(true);
                                    this.page = 1
                                    this.getExpenses()
                                }
                            })
                            .catch((error) => {
                                this.showToster({ message: error, isError: true });
                                this.loading = false;
                            });
                    } else {
                        this.$store
                            .dispatch("expenseCreate", postData)
                            .then((response) => {
                                if (response.error) {
                                    this.showToster({ message: response.error.message, isError: true });
                                } else {
                                    this.successMsg = response.message
                                    this.showAddExpense = false
                                    this.showAddExpenseSuccess = true
                                    //this.showToster({ message: response.message, isError: false });
                                    //  this.page = 1
                                    //  this.getExpenses()
                                }
                            })
                            .catch((error) => {
                                this.showToster({ message: error, isError: true });
                                this.loading = false;
                            });
                    }




                } else {

                }
            })
        },

        getExpenses() {
            this.isExpenseEdit = false

            if (this.filterSelectedStatuses && this.checkProperty(this.filterSelectedStatuses, 'length') > 0) {
                statusIds = this.filterSelectedStatuses.map((item) => item.id)
            }
            let dateRange = []

            if (this.checkProperty(this.createdeDateRange, 'startDate') && this.checkProperty(this.createdeDateRange, 'endDate')) {
                let startDate = moment(this.checkProperty(this.createdeDateRange, 'startDate')).format("YYYY-MM-DD");
                let endDate = moment(this.checkProperty(this.createdeDateRange, 'endDate')).format("YYYY-MM-DD");
                dateRange.push(startDate)
                dateRange.push(endDate)
            }
            let postData =
            {
                "matcher": {
                    "title": this.filterSearch,
                    "searchString": this.filterSearch,
                    "statusList": [],
                    "createdByIds": [],
                    "createdDateRange":dateRange,
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": false,// if Masterdata required
                "page": this.page,
                "perpage": this.perpage,
            }
             postData['restaurantId'] = localStorage.getItem('restaurantId');
            this.$store.dispatch("getExpensesList", postData)
                .then((res) => {
                    this.isListLoading = false
                    this.updateLoading(false);
                    this.expensesList = res.data.result.list
                    if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
                        this.totalCount = this.checkProperty(res.data.result, 'totalCount');
                    }
                    setTimeout(() => {
                        this.updateLoading(false);
                    })
                })
                .catch((error) => {
                    this.expensesList = []
                    this.isListLoading = false
                    this.updateLoading(false);
                })
        },


        applyFilters() {
            this.expensesList = []
            this.isListLoading = true
            this.updateLoading(true);
            this.page = 1
            this.getExpenses()
        },
        applySearchFilters() {
            this.expensesList = []
            this.page = 1
            if (this.filterSearch && this.filterSearch.length > 2) {
                this.isListLoading = true
                this.updateLoading(true);
                this.getExpenses()
            }
            if (this.filterSearch == '') {
                this.isListLoading = true
                this.updateLoading(true);
                this.getExpenses()
            }
        },


        getMasterDataList(category) {
            this.$store.dispatch("getMasterData", category)
                .then((response) => {
                    if (category == 'expenses_nature') {
                        this.natureOfExpenseList = response;
                    }
                    if (category == 'paid_from') {
                        this.paidFromList = response;
                    }
                })
        },

        getCurrentDate(includeToday = false) {
            return moment().subtract(includeToday ? 1 : 0, 'days')
        },
        updateNatureOfExpenses(value) {
            this.expense.natureOfExpense = value
        },
        getUsers() {
            let postData =
            {
                "matcher": {
                    "roleIds": [4],
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": true,// if Masterdata required
                "page": 1,
                "perpage": 500,
            }
            this.$store.dispatch("getUsersList", postData)
                .then((res) => {
                    this.paidByUsersList = res.data.result.list
                })
                .catch((error) => {
                })
        },
        updatePaidTo(value) {
            this.showAddCustomerPopup(value)
        },
        updatePhoneCountryCode(data) {
            this.customer.phoneCountryCode = data;

        },
        showAddCustomerPopup(value) {
            this.customer = {
                customerName: value,
                email: '',
                phone: null,
                phoneCountryCode: {
                    countryCode: 'US',
                    countryCallingCode: ''
                },
            }

            this.showAddCustomer = true
        },

        addCustomer() {
            this.$validator.validateAll("customerForm").then((result) => {
                if (result) {
                    let postData =
                    {
                        "customerName": this.customer.customerName,
                        "email": this.customer.email,
                        "phone": this.customer.phone,
                        "phoneCountryCode": this.customer.phoneCountryCode,
                    }

                    this.$store.dispatch("createCustomer", postData)
                        .then((response) => {
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                            } else {
                                // this.showToster({ message: response.message, isError: false });
                                this.expense.paidTo = response.customer
                                this.showAddCustomer = false
                            }
                        })
                        .catch((error) => {
                            this.showAddcustomer = true
                            this.showToster({ message: error, isError: true });
                        })

                }
            })
        },
        getCustomersList() {
            let postData =
            {
                "matcher": {
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": true,// if Masterdata required
                "page": 1,
                "perpage": 500,
            }

            this.$store.dispatch("getcustomerList", postData)
                .then((res) => {
                    this.paidToCustList = res.data.result.list
                })

        },
        updateBalanceAmount() {
            if (this.checkProperty(this.expense, 'amount')) {
                if (this.checkProperty(this.expense, 'paidAmount')) {
                    if (parseFloat(this.checkProperty(this.expense, 'paidAmount')) > parseFloat(this.checkProperty(this.expense, 'amount'))) {
                        this.expense.paidAmount = ''
                        this.expense.balanceDue = this.checkProperty(this.expense, 'amount')
                    } else {
                        this.expense.balanceDue = this.checkProperty(this.expense, 'amount') - this.checkProperty(this.expense, 'paidAmount')
                    }
                } else {
                    this.expense.balanceDue = this.checkProperty(this.expense, 'amount')
                }
                setTimeout(() => {
                    this.isDueOnRequired = this.isBalanceDueRequired
                }, 1);
            }
        },
        editDetails(editItem, isEditDetails = false) {
            this.selectedExpense = editItem
            if (isEditDetails) {
                this.expense = _.cloneDeep(this.selectedExpense)
                this.expense['natureOfExpense'] = this.selectedExpense.expensesNatureDetails;
                this.expense['paidFrom'] = this.selectedExpense.paidFromDetails;
                this.expense['paidTo'] = this.selectedExpense.paidToDetails;
                this.expense['paidBy'] = this.selectedExpense.paidByDetails;
                this.updateBalanceAmount()
                if (!this.canEditTheRecord(this.checkProperty(editItem, 'createdOn'))) {
                    this.showSubmitConfirmPopup = true
                } else {
                    this.isExpenseEdit = true
                    this.showAddExpense = true
                }
            } else {
                this.showDetailsPopup = true
            }


            // let postData =
            // {
            //     "expenseId": editItem._id
            // }
            // this.$store.dispatch("getDetails", { data: postData, path: '/expense/details' })
            //     .then((res) => {
            //         this.selectedExpense = res
            //         this.expense = _.cloneDeep(this.selectedExpense)

            //         this.expense['natureOfExpense'] = this.selectedExpense.expensesNatureDetails;
            //         this.expense['paidFrom'] = this.selectedExpense.paidFromDetails;
            //         this.expense['paidTo'] = _.find(this.paidToCustList, { "_id": this.selectedExpense['paidToId'] });
            //         this.expense['paidBy'] = _.find(this.paidByUsersList, { "_id": this.selectedExpense['paidById'] });


            //         this.selectedExpense['paidBy'] = _.find(this.paidByUsersList, { "_id": this.selectedExpense['paidById'] });


            //         setTimeout(() => {
            //             if (isEditDetails) {
            //                 this.updateBalanceAmount()
            //                 this.isExpenseEdit = true
            //                 this.showAddExpense = true
            //             } else {
            //                 this.showDetailsPopup = true
            //             }

            //         }, 1)
            //     })
            //     .catch((error) => {
            //         console.log('error', error)
            //     })

        },


    },

    mounted() {
        this.getMasterDataList('expenses_nature')
        this.getMasterDataList('paid_from')
        this.getUsers()
        this.getCustomersList()
        // this.$store.dispatch("getMasterData", 'expenses_nature')
        //     .then((response) => {

        //     })
        // this.$store.dispatch("getMasterData", 'paid_from')
        //     .then((response) => {
        //         this.paidFromList = response;
        //     })

        this.isListLoading = true
        this.updateLoading(true);
        this.getExpenses()

    },
    computed: {

        isBalanceDueRequired() {
            if (this.checkProperty(this.expense, 'balanceDue') == 0) {
                return false
            }
            return true
        },
    },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>