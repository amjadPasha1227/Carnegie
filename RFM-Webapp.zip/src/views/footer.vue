<template>
    <footer class="footer">
        <div class="container">
           <div class="row"> 
                <div class="col-md-3 col-md-3">
                    <div class="widget">
                        <ul>
                        <li><a href="index.html"><img src="@/assets/images/logo_carne.png" alt="logo"></a></li>
                        </ul>
                    </div>
                </div>  
                <div class="col-md-8 col-md-8">
                    <div class="row"> 
                        <div class="col-md-7 col-md-7">
                            <div class="widget">
                                <h4>Say Hello</h4>
                                <ul>
                                    <li> Carnegie Evaluations LLC, 1200 US Highway 22E, Suite 2000, Bridgewater, NJ 08807</li>
                                </ul>
                            </div>
                            <div class="widget widgett">
                                <h4>Call Us</h4>
                                <ul >
                                    <li>(848) 300 0099</li>
                                </ul>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 col-md-6">
                                    <div class="widget">
                                        <ul class="quick-links">
                                        <li><a href="services.html">Services</a></li>
                                        <li><a href="strengths.html">Our Strengths</a></li>
                                        <li><a href="specialties.html">Specialties</a></li>
                                        <li><a href="pricing.html">Pricing</a></li>
                                        <li><a href="#">Contact Us</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-md-6 col-md-6">
                                    <div class="widget">
                                        <ul class="quick-links">
                                        <li><a href="#">Request an Evaluation</a></li>
                                        <li><a href="testmonials.html">Testimonials</a></li>
                                        <li><a href="#"> Terms & Conditions</a></li>
                                        <li><a href="document-checklist.html"> Document Checklist</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5 col-md-5">
                            <div class="widget">
                                <h4>Email</h4>
                                <ul>
                                    <li><a href="">eval@carnegieevaluations.com</a></li>
                                </ul>
                            </div>
                            <div class="widget widgett">
                                <h4>Socials</h4>
                                <div class="social-icons">
                                    <a href="https://www.facebook.com/people/Carnegie-Evaluations/100067473232721/" target="_blank"><figure><img src="@/assets/images/facebook.svg"></figure></a>
                                    <a href="https://www.instagram.com/explore/tags/carnegieevaluations/" target="_blank"><figure><img src="@/assets/images/insta.svg"></figure></a>
                                    <a href="https://www.linkedin.com/in/carnegie-evaluations/" target="_blank"><figure><img src="@/assets/images/linkdin.svg"></figure></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 
           </div>
        </div>
        <div class="copyrights">
           <div class="container">
              <div class="row">
                 <div class="text-center">Copyright © 2023 Carnegie Evaluations. All rights reserved.</div>
              </div>
           </div>
        </div>
     </footer>
</template>
<script>
    // @ is an alias to /src
   
    import JQuery from "jquery";
    export default {
      name: 'footer-vue',
      components: {
        
      },
      computed: {
       
      },
      methods: {
      
      },
      mounted(){
        
      },
    }
    </script>