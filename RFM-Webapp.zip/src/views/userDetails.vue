<template>
  <div class="db_page">
    <!-- <div class="page_header">
      <h3>Users</h3>
    </div> -->
    <div class="filter_sec filter_sec_v2">
      <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" :wrapclass="'me-0'" />
      <!-- <simpleSelect :multiple="true" :wrapclass="'req_status'" :optionslist="filterUserRolesList" :display="true"
        :place-holder="'User Type'" :searchable="false" :required="false" :close-on-select="false" :clear-on-select="true"
        v-model="filterSelectedUserRoles" :fieldName="'filterUserType'" :cid="'filterUserType'" :hideSelected="true"
        @input="applyFilters" />
      <simpleSelect :multiple="true" :wrapclass="'req_status'" :optionslist="filterStatusList" :display="true"
        :place-holder="'Status'" :searchable="false" :required="false" :close-on-select="false" :clear-on-select="true"
        v-model="filterSelectedStatuses" :fieldName="'filterStatuses'" :cid="'filterStatuses'" :hideSelected="true"
        @input="applyFilters" />                  -->

      <button class="filter_btn" v-if="false"><span></span><em>Filters</em></button>
      <div class="filters_right" v-if="canCreateUser(getUserRoleId)">

        <button class="add_btn" @click="showAddUserPopup(false)"><span></span><em>Add User</em></button>
      </div>
    </div>

    <ul class="custome_tabs">
      <li class="active">Users</li>
      <li @click="gotoPage('/restaurantdetails')">Restaurants</li>
    </ul>
    <div class="table-responsive" v-if="false">
          <template v-if="checkProperty(usersList, 'length') <= 0">
            <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users' :loading="isListLoading" />
          </template>
          <table class="table user_table" v-if="checkProperty(usersList, 'length') > 0 && !isListLoading">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Username</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in    usersList   " v-bind:key="index">
               
                <td><span class="first_name">{{ checkProperty(item, 'firstName') ? item.firstName : '' }}</span> <span class="last_name">{{ checkProperty(item, 'lastName') ? item.lastName : '' }}</span>
                
                     <br/>
                     <span>{{ checkProperty(item, 'roleDetails', 'name') ? checkProperty(item, 'roleDetails', 'name') : ''
                    }}</span>
                    
                    </td>
                <td><span>{{ checkProperty(item, 'email') ? item.email : '' }}</span></td>
            
                <td><span>{{ checkProperty(item, 'userName') ? item.userName : '' }}</span></td>
                <td>
                  <div class="actions" v-if="[1, 3, 4].indexOf(getUserRoleId) > -1">
                  
                    <span v-if="checkProperty(item, 'statusId') == 3" class="inactive">Inactive</span>
                    <span v-if="checkProperty(item, 'statusId') == 1" class="inactive">Pending </span>
                    <dropdownHover aria-disabled="true"
                      v-if="[1].indexOf(checkProperty(item, 'roleId')) < 0 ">
                     
                            <b-dropdown-item 
                        @click="showProfilePopup(item)">View</b-dropdown-item>
                      <b-dropdown-item v-if="checkProperty(item, 'statusId') == 2"
                        @click="editUser(item)">Edit</b-dropdown-item>
                      <b-dropdown-item v-if="!checkProperty(item, 'passwordUpdated') && checkProperty(item, 'statusId') == 2"
                        @click="sendPasswordLink(item)">Resend Password Link</b-dropdown-item>


                      <b-dropdown-item v-if="checkProperty(item, 'statusId') == 2"
                        @click="selectedUser = item; password = ''; conformPassword = ''; showPasswordChangePopup = true">{{
                          checkProperty(item, 'passwordUpdated') ? 'Reset Password' : 'Set Password' }}</b-dropdown-item>
                      <b-dropdown-item @click=" selectedUser = item; showStatusChangePopup = true">{{
                        checkProperty(item, 'statusId') == 2
                        ? 'Inactivate' : 'Activate'
                      }}</b-dropdown-item>
                    </dropdownHover>
                  </div>
                </td>
              </tr>

            </tbody>
          </table>
          <!-- <h2 v-if="usersList.length <= 0" class="loading_NoData">
              <template v-if="isListLoading"> Loading.....</template>
              <template v-else> No Users Found!</template>
            </h2> -->
    </div>
    

    <div class="mobile_table_list">
          <template v-if="checkProperty(usersList, 'length') <= 0">
            <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users' :loading="isListLoading" />
          </template>
            <ul v-if="checkProperty(usersList, 'length') > 0 && !isListLoading">
                <li v-for="(item, index) in usersList " v-bind:key="index">
                    <div class="list_row">
                        <div>
                            <span class="list_heading">{{ checkProperty(item, 'firstName') ? item.firstName : '' }} {{ checkProperty(item, 'lastName') ? item.lastName : '' }}</span>
                        </div>
                        <div class="actions" v-if="[1, 3, 4].indexOf(getUserRoleId) > -1">
                          <span v-if="checkProperty(item, 'statusId') == 3" class="inactive">Inactive</span>
                          <span v-if="checkProperty(item, 'statusId') == 1" class="inactive">Pending </span>
                          <dropdownHover aria-disabled="true"
                            v-if="[1].indexOf(checkProperty(item, 'roleId')) < 0 ">
                          
                                  <b-dropdown-item 
                              @click="showProfilePopup(item)">View</b-dropdown-item>
                            <b-dropdown-item v-if="checkProperty(item, 'statusId') == 2"
                              @click="editUser(item)">Edit</b-dropdown-item>
                            <b-dropdown-item v-if="!checkProperty(item, 'passwordUpdated') && checkProperty(item, 'statusId') == 2"
                              @click="sendPasswordLink(item)">Resend Password Link</b-dropdown-item>


                            <b-dropdown-item v-if="checkProperty(item, 'statusId') == 2"
                              @click="selectedUser = item; password = ''; conformPassword = ''; showPasswordChangePopup = true">{{
                                checkProperty(item, 'passwordUpdated') ? 'Reset Password' : 'Set Password' }}</b-dropdown-item>
                            <b-dropdown-item @click=" selectedUser = item; showStatusChangePopup = true">{{
                              checkProperty(item, 'statusId') == 2
                              ? 'Inactivate' : 'Activate'
                            }}</b-dropdown-item>
                          </dropdownHover>
                        </div>
                    </div>
                    <div class="list_row">
                        <div><span>email :</span> {{ checkProperty(item, 'email') ? item.email : '' }}</div>
                        <div></div>
                    </div>
                    <div class="list_row">
                        <div><span>role :</span> {{ checkProperty(item, 'roleDetails', 'name') ? checkProperty(item, 'roleDetails', 'name') : '' }}</div>
                        <div><span>username :</span> {{ checkProperty(item, 'userName') ? item.userName : '' }}</div>
                    </div>
                </li>
            </ul>
            <div class="pagination-sec" v-if="checkProperty(usersList, 'length') > 0">
            <div class="per-page">
              <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) + usersList.length) +
                ' of ' + totalCount + ' Results' }}</label>
            </div>
            <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
              @input=" isListLoading = true, updateLoading(true), getUsers()"></b-pagination>
            </div>
        </div>
    

    
    <!-- Add User Modal -->
    <b-modal v-model="showAddUser" id="adduser_model" dialog-class="adduser_model" centered no-close-on-backdrop>
      <template #modal-header>
        <h6 class="modal-title">{{ isUserEdit ? 'Edit User' : 'Add User' }}</h6>
        <a class="close" @click=" showAddUser = false"></a>
      </template>
      <template>
        <span class="user_header" v-if="true">User Type</span>
        <div class="user_type_list" v-if="true">
          <template v-for="(   roleItem, index    ) in    userRoles   ">
            <radioInput wrapclass="radio_group_v2" :elementId="'usertype' + index" :label="roleItem.name"
              :fieldName="'usertype'" v-model="user.userRole" :fieldValue="roleItem" @input="updateRole"
              :disabled="isUserEdit && ((checkProperty(roleItem, 'id') && checkProperty(roleItem, 'id') == 9) || (checkProperty(user, 'userRole', 'id') && checkProperty(user, 'userRole', 'id') == 9))" />
          </template>
        </div>

        <div class="user_type_list">
          <input type="hidden" class="form-control" v-validate="'required'" v-model="user.userRole" data-vv-as="User Type"
            :name="'userroleRadio'" />
          <span v-show="errors.has('userroleRadio')" class="form-error">{{ errors.first('userroleRadio') }}</span>
        </div>
        <div v-if="checkProperty(user, 'userRole', 'id') && checkProperty(user, 'userRole', 'id') == 9"
          class="user_form mt-3">
          <div class="row">
            <div class="col-md-6">
              <!-- <simpleInput :wrapclass="'mb20'" :label="'Title/Designation'" /> -->
              <simpleInput :wrapclass="'mb20'" :fieldName="'title'" :cid="'title'" :label="'Title/Designation'"
                :placeHolder="'Title/Designation'" :vvas="'Title/Designation'" :display="true" :required="true"
                v-model="user.designation" :allowAlphNum="true" />

            </div>
            <div class="col-md-6">
              <simpleSelect :multiple="false" :wrapclass="'mb20'" :label="'Department'" :optionslist="departments"
                :display="true" :place-holder="'Select Department'" :searchable="false" :required="true"
                :close-on-select="true" :clear-on-select="true" v-model="user.userDepartment" :fieldName="'department'"
                :cid="'department'" :vvas="'Department'" />
            </div>
            <div class="col-md-6">
              <simpleInput :wrapclass="'mb20'" :fieldName="'profileurl'" :cid="'profileurl'" :label="'Profile URL'"
                :placeHolder="'Profile URL'" :vvas="'Profile URL'" :display="true" v-model="user.profileURL" />
              <!-- <simpleInput :wrapclass="'mb20'" :label="'Profile URL'" /> -->
            </div>
            <!-- <div class="col-md-6">
              <fileUploadDrag :label="'Copy of letterhead'" :wrapclass="'mb20'" :multiple="false"
                :tplkey="'cpofletterhead'" v-model="user.letterHead" :tplsection="'cpofletterhead'"
                vvas="Copy of letterhead" :fieldName="'cpofletterhead'" :cid="'cpofletterhead'"
                :fileTypes="'application/pdf, application/msword'" />
            </div> -->
            <div class="col-md-12">
              <textArea :label="'Bio, Resume'" :wrapclass="'h80 mb20'" :formText="'Max. 300 Characters'"
                :tplkey="'bioAndResume'" fieldName="bioAndResume" placeHolder="Bio, Resume"
                v-model="user.bioAndResume"></textArea>
            </div>
            <div class="col-md-12">
              <div class="form_group mb-0">
                <label class="form_label">Upload Documents (Resume, Awards, Achievements etc…)</label>
                <!-- <div class="upload_doc_name">
                  <input type="text" class="form-control" placeholder="Name of the Document">
                  <div class="upload_file">
                    <img src="@/assets/images/upload_cloud.png">
                    <span>Upload</span>
                    <input type="file" title=""
                      accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      class="form-control"
                      @change="onFileUpload">
                  </div>
                </div> -->
                <template v-if="showDocuments" v-for="(   document, index    ) in    user.documents   ">
                  <fileUpload :tplkey="'document' + index" v-model="user.documents[index]" :wrapclass="''"
                    :tplsection="'document' + index" label="" vvas="Document" :fieldName="'document' + index"
                    :cid="'document' + index" :multiple="false" :showDeleteIcon="user.documents.length > 1 ? true : false"
                    @deleteDocument=" removeDocument(index)" :deleteDocPermenantly="true"></fileUpload>
                </template>
                <span @click="addNewDocument" class="add_more">+ ADD MORE</span>
              </div>
            </div>
          </div>
        </div>
        <div class="form_info mt-3">
          <div class="row">
            <div class="col-md-6">
              <simpleSelect :multiple="true" :wrapclass="'mb20'" :label="'Restaurant(s)'" :optionslist="restaurantsList"
                :display="true" :place-holder="'Select Restaurant(s)'" :searchable="true"
                :required="checkProperty(user, 'userRole', 'id') && checkProperty(user, 'userRole', 'id') == 3 ? false : true"
                :close-on-select="true" :clear-on-select="true" v-model="user.restaurants" :fieldName="'restaurants'"
                :cid="'restaurants'" :vvas="'Restaurant(s)'" :listContainsId="true" />

            </div>
            <div class="col-md-6">
              <simpleInput :wrapclass="'mb20'" :fieldName="'firstName'" :cid="'firstName'" :label="'First Name'"
                :placeHolder="'First Name'" :vvas="'First Name'" :display="true" :required="true" v-model="user.firstName"
                :allowAlphNum="true" />
              <!-- <simpleInput :wrapclass="'mb20'" :label="'First Name'" /> -->
            </div>
            <div class="col-md-6">
              <simpleInput :wrapclass="'mb20'" :fieldName="'lastName'" :cid="'lastName'" :label="'Last Name'"
                :placeHolder="'Last Name'" :vvas="'Last Name'" :display="true" :required="true" v-model="user.lastName"
                :allowAlphNum="true" />
              <!-- <simpleInput :wrapclass="'mb20'" :label="'Last Name'" /> -->
            </div>
            <div class="col-md-6">
              <simpleInput :wrapclass="'mb20'" :fieldName="'email'" :cid="'email'" :label="'Email'" :placeHolder="'Email'"
                :vvas="'Email'" :display="true" :required="true" :datatype="'email'" v-model="user.email"
                :emailFormat="true" />
              <!-- <simpleInput :wrapclass="'mb20'" :label="'Email'" /> -->
            </div>
            <div class="col-md-6">

              <phoneInput :wrapclass="'mb20'" :display="true" :tplkey="'phoneNumber'"
                @updatephoneCountryCode="updatePhoneCountryCode" :countrycode="user.phoneCountryCode.countryCode"
                cid="phoneNumber" v-model="user.phone" :fieldName="'phoneNumber'" label="Phone Number (Optional)"
                placeHolder="Phone Number" />

              <!-- <simpleInput :wrapclass="'mb20'" :label="'Phone Number (Optional)'" /> -->
            </div>
            <div class="col-md-6">
              <simpleInput :wrapclass="'mb20'" :fieldName="'userName'" :cid="'userName'" :label="'Username'"
                :placeHolder="'Username'" :vvas="'Username'" :display="true" :required="true" v-model="user.userName" />
              <!-- <simpleInput :wrapclass="'mb20'" :label="'Username'" /> -->
            </div>
          </div>
        </div>
      </template>
      <template #modal-footer>
        <button class="form-cancel" @click=" showAddUser = false">Cancel</button>
        <button class="primary_btn md" @click="addOrUpdateUser">{{ isUserEdit ? 'Update' : 'Submit' }}</button>
      </template>
    </b-modal>

    <!-- User Added Success Modal -->
    <b-modal v-model="showAddUserSuccess" id="success_model" dialog-class="success_model user_success" centered
      hide-header hide-footer>
      <template>
        <figure>
          <img src="@/assets/images/success_mdl_img.png" />
        </figure>
        <h4 class="m-0">{{ isUserEdit ? 'User updated!' : 'User added!' }}</h4>
        <h7 class="m-0" style="padding-left:20px;padding-right:20px;text-align: center;">{{ successMsg }}</h7>
        <button class="primary_btn md" style="margin-top:14px ;"
          @click=" showAddUserSuccess = false; page = 1; isListLoading = true; updateLoading(true); getUsers()">OKAY</button>
      </template>
    </b-modal>

    <!-- Profile Modal -->
    <b-modal v-model="showProfile" id="profile_model" dialog-class="profile_model" centered hide-header hide-footer
      no-close-on-backdrop>
      <template>
        <div class="profile_header">
          <!-- <div class="profile_icon">
             <img  v-if="checkProperty(selectedUser, 'details', 'profileURL')" :src=" checkProperty(selectedUser, 'details', 'profileURL') ">
            <img  v-else :src=" checkProperty(selectedUser, 'details', 'profileURL') "> 
           <figure><img src="@/assets/images/professors.svg"></figure> 
          </div> -->

          <div class="profile_title">
            <h6 v-if="checkProperty(selectedUser, 'name')">{{ checkProperty(selectedUser, 'name') }}</h6>
            <p v-if="checkProperty(selectedUser, 'roleName')">{{ checkProperty(selectedUser, 'roleName') }}</p>
            <span v-if="checkProperty(selectedUser, 'details', 'designation')">{{ checkProperty(selectedUser, 'details',
              'designation') }}</span>
          </div>
          <a class="close" @click=" $bvModal.hide('profile_model')"></a>
        </div>
        <div class="profile_info">
          <ul>
            <li v-if="checkProperty(selectedUser, 'details', 'email')">
              <span class="info_header">Email</span>
              <p class="desc">{{ checkProperty(selectedUser, 'details', 'email') }}</p>
            </li>
            <li v-if="checkProperty(selectedUser, 'details', 'phone')">
              <span class="info_header">Phone</span>
              <p class="desc">
                {{ checkProperty(selectedUser.details, 'phoneCountryCode', 'countryCallingCode') | countryFormatter }}
                {{ checkProperty(selectedUser, 'details', 'phone') | formatPhone }}
              </p>
            </li>
            <li v-if="checkProperty(selectedUser, 'details', 'userName')">
              <span class="info_header">Username</span>
              <p class="desc">{{ checkProperty(selectedUser, 'details', 'userName') }}</p>
            </li>
            <li v-if="checkProperty(selectedUser, 'departmentDetails', 'name')">
              <span class="info_header">Department</span>
              <p class="desc">{{ checkProperty(selectedUser, 'departmentDetails', 'name') }}</p>
            </li>
            <li v-if="checkProperty(selectedUser, 'details', 'profileURL')">
              <span class="info_header">Profile URL</span>
              <a href="#" class="link">{{ checkProperty(selectedUser, 'details', 'profileURL') }}</a>
            </li>
            <li
              v-if="checkProperty(selectedUser, 'details', 'letterHead') && checkProperty(selectedUser['details'], 'letterHead', 'length') > 0">
              <span class="info_header">Copy of letterhead</span>
              <!-- <div class="download_sec">
                <img src="@/assets/images/pdf-file-format.svg">
                <a href="#" class="link_btn">Download</a>
              </div> -->
              <DocumentsPreview :type="'documents'" :documentsList="checkProperty(selectedUser, 'details', 'letterHead')"
                :includeDownloadText="false" @download_or_view="download_or_view" />
            </li>
            <li
              v-if="(checkProperty(selectedUser, 'details', 'bioAndResume') || (checkProperty(selectedUser, 'details', 'documents') && checkProperty(selectedUser['details'], 'documents', 'length') > 0))"
              class="bio_resume">
              <span class="info_header">Bio/Resume</span>
              <p v-if="checkProperty(selectedUser, 'details', 'bioAndResume')"
                v-html="checkProperty(selectedUser, 'details', 'bioAndResume')"></p>
              <div
                v-if="checkProperty(selectedUser, 'details', 'documents') && checkProperty(selectedUser['details'], 'documents', 'length') > 0">
                <DocumentsPreview :type="'documents'" :documentsList="checkProperty(selectedUser, 'details', 'documents')"
                  :includeDownloadText="false" @download_or_view="download_or_view" />
              </div>

              <!-- <div v-if="checkProperty(selectedUser, 'details', 'bioAndResume')" class="download_sec">
                <img src="@/assets/images/pdf-file-format.svg">
                <a href="#" class="link_btn">Download</a>
              </div> -->
            </li>
          </ul>
        </div>
      </template>
    </b-modal>

    <!-- Reset Password Modal-->
    <b-modal v-model="showPasswordChangePopup" id="reset_model" dialog-class="reset_model" centered no-close-on-backdrop>
      <template #modal-header>
        <h6 class="modal-title">{{ checkProperty(selectedUser, 'passwordUpdated') ? 'Reset Password' : 'Set Password' }}
        </h6>
        <a class="close" @click=" $bvModal.hide('reset_model')"></a>
      </template>
      <template>
        <div>
          <div class="row">
            <div class="col-md-12">
              <div class="form_group">
                <lable class="form_label">Password<em>*</em></lable>
                <input :wrapclass="'mb20'" ref="password" v-validate="'required|min:5|max:15|strongpassword'"
                  :data-vv-as="'Password'" v-model="password" :type="'password'" class="form-control"
                  placeholder="Password" id="inputPassword" name="password" />
                <span v-show="errors.has('password')" class="form-error">
                  {{ errors.first("password") }}
                </span>
              </div>
            </div>

            <div class="col-md-12">
              <div class="form_group mb20">
                <lable class="form_label">Confirm Password<em>*</em></lable>
                <input :wrapclass="'mb20'" v-validate="'required|confirmed:password'" :data-vv-as="'Confirm Password'"
                  v-model="conformPassword" :type="showPassword ? 'text' : 'password'" class="form-control eye"
                  placeholder="Confirm Password" id="inputPassword" name="cpassword" />
                <!-- <div class="view_eye" :class="{ close: showPassword }" @click="toggleShow"> </div> -->

                <span v-show="errors.has('cpassword')" class="form-error">
                  {{ errors.first("cpassword") }}
                </span>
              </div>
            </div>

          </div>
        </div>
      </template>
      <template #modal-footer>
        <p class="password_note"><img src="@/assets/images/lock.svg"> Password must contain 6 to 15 characters</p>
        <div class="d-flex">
          <button class="form-cancel" @click=" $bvModal.hide('reset_model')">Cancel</button>
        <button class="primary_btn md" @click="updatePassword">{{ checkProperty(selectedUser,
          'passwordUpdated') ? 'Update' : 'Submit' }}</button>
        </div>
      </template>
    </b-modal>

    <!-- active inactive Modal -->
    <b-modal v-model="showStatusChangePopup" id="active_inactive_model" dialog-class="active_inactive_model" centered
      no-close-on-backdrop>
      <template #modal-header>
        <h6 class="modal-title">
          {{ checkProperty(selectedUser, 'statusId') == 2 ? 'Inactivate' : 'Activate' }}
        </h6>
        <a class="close" @click=" $bvModal.hide('active_inactive_model')"></a>
      </template>
      <template>
        <p class="confirm_msg">Do you want to {{ checkProperty(selectedUser, 'statusId') == 2 ? 'Inactivate User' :
          'Activate User' }}?</p>
      </template>
      <template #modal-footer>
        <button class="form-cancel" @click=" $bvModal.hide('active_inactive_model')">No</button>
        <button class="primary_btn" @click="changeStatus">Yes</button>
      </template>
    </b-modal>

    <b-modal id="preview_model" v-model="docPrivew" dialog-class="document_modal"
      :title="checkProperty(selectedFile, 'name')">
      <h2> <img :class="{
        pdf_view_download: docType == 'pdf',
        office_view_download: docType == 'office',
        image_view_download: docType == 'image',
      }" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>
      <div class="pdf_loader">
        <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/loader.gif" /></figure>

        <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
        <template v-if="docType == 'office'">
          <div style="height:90vh">

            <div id="placeholder" style="height:100%"></div>
          </div>
        </template>
        <template v-else-if="docType == 'image'">
          <img :src="docValue" />
        </template>
        <template v-else-if="docType == 'pdf'">
          <div class="pdf" style="height:90vh">

            <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%" width="100%">

            </iframe>
          </div>
        </template>
      </div>
    </b-modal>

  </div>
</template>

<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import fileUpload from "@/views/forms/fileupload.vue";
import simpleSelect from '@/views/forms/simpleSelect.vue';
import dropdownHover from '@/views/forms/dropdownHover.vue';
import radioInput from "@/views/forms/radioInput.vue";
import textArea from "@/views/forms/textarea.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import phoneInput from "@/views/forms/phonenumber.vue";
import axios from 'axios';
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import NoDataFound from "@/views/common/noData.vue";

export default {
  name: 'dashboard-view',
  components: {
    searchInput,
    simpleSelect,
    dropdownHover,
    radioInput,
    simpleInput,
    fileUpload,
    fileUploadDrag,
    textArea,
    phoneInput,
    DocumentsPreview,
    NoDataFound
  },
  data: () => ({
    showAddUser: false,
    showAddUserSuccess: false,
    showProfile: false,
    showStatusChangePopup: false,
    showPasswordChangePopup: false,
    isUserEdit: false,
    isListLoading: true,
    page: 1,
    perpage: 20,
    totalCount: 0,
    currentPage: 1,
    userRoles: [],
    departments: [],
    usersList: [],
    filterUserRolesList: [],
    filterStatusList: [],
    filterSelectedUserRoles: null,
    filterSelectedStatuses: null,
    filterSearch: '',
    user: {
      designation: '',
      profileURL: "",
      name: "",
      firstName: '',
      lastName: '',
      email: '',
      userName: '',
      phone: null,
      phoneCountryCode: {
        countryCode: '',
        countryCallingCode: ''
      },
      userRole: null,
      userDepartment: '',
      documents: [],
      bioAndResume: '',
      letterHead: [],
      restaurants: null,
    },
    selectedUser: null,
    successMsg: '',
    password: '',
    conformPassword: '',
    showPassword: false,
    showCPassword: false,
    showDocuments: true,
    docType: '',
    formSubmited: false,
    docPrivew: false,
    docType: '',
    selectedFile: null,
    restaurantsList: [],
  }),
  methods: {
    gotoPage(path = "/") {
      this.$router.push(path);
    },
    updatePhoneCountryCode(data) {
      // alert(JSON.stringify(data))
      this.user.phoneCountryCode = data;

    },

    updateRole(data) {
      // alert(JSON.stringify(data))
      this.user['userRole'] = data
      this.user = _.cloneDeep(this.user)
    },

    showAddUserPopup(isEdit = false) {
      this.isUserEdit = false
      this.user = {
        designation: '',
        profileURL: "",
        name: "",
        firstName: '',
        lastName: '',
        email: '',
        userName: '',
        phone: null,
        phoneCountryCode: {
          countryCode: '',
          countryCallingCode: ''
        },
        userRole: null,
        userDepartment: '',
        documents: [],
        bioAndResume: '',
        letterHead: [],
        restaurants: null,
      }
      let document = null
      this.user.documents.push(document)
      this.showAddUser = true
    },

    addOrUpdateUser() {
      this.$validator.validateAll().then((result) => {
        if (result) {

          // let postData = _.cloneDeep(this.user)
          let postData = {
            "name": this.user.firstName + " " + this.user.lastName,
            "email": this.user.email,
            "roleId": this.user.userRole.id,
            "firstName": this.user.firstName,
            "middleName": "",
            "lastName": this.user.lastName,
            "userName": this.user.userName.trim(),
            "phone": this.user.phone,
            "phoneCountryCode": this.user.phoneCountryCode,
            "userType": this.user.userRole.id,

          }
          if (this.user.restaurants && this.checkProperty(this.user.restaurants, 'length') > 0) {
            let restaurantIds = this.user.restaurants.map((item) => item['_id'])
            Object.assign(postData, { restaurantIds: restaurantIds });
          }

          if (this.isUserEdit) {
            postData['userId'] = this.selectedUser._id
            this.$store
              .dispatch("userUpdate", postData)
              .then((response) => {
                if (response.error) {
                  this.showToster({ message: response.error.message, isError: true });
                } else {
                  this.successMsg = response.message
                  this.showAddUser = false
                  //this.showAddUserSuccess = true
                  this.usersList = []
                  this.showToster({ message: response.message, isError: false });
                  this.isListLoading = true
                  this.updateLoading(true);
                  this.page = 1
                  this.getUsers()
                }
              })
              .catch((error) => {
                this.showToster({ message: error, isError: true });
                this.loading = false;
              });
          } else {
            this.$store
              .dispatch("userregister", postData)
              .then((response) => {
                if (response.error) {
                  this.showToster({ message: response.error.message, isError: true });
                } else {
                  this.successMsg = response.message
                  this.showAddUser = false
                  this.showAddUserSuccess = true
                  //this.showToster({ message: response.message, isError: false });
                  //  this.page = 1
                  //  this.getUsers()
                }
              })
              .catch((error) => {
                this.showToster({ message: error, isError: true });
                this.loading = false;
              });
          }




        } else {

        }
      })
    },
    onFileUpload(event) {

    },
    addNewDocument() {
      let document = {
        url: "",
        name: "",
      }
      this.user.documents.push(null)
    },
    showModal(modelRef, Item) {
      this.showLoader = false;
      this.$refs[modelRef].show();
      this.$validator.reset();
    },
    hideModal(modelId) {
      $bvModal(modelId).hide();
      this.showLoader = false;
    },
    getUsers() {
      this.isUserEdit = false
      let statusIds = []
      let roleIds = []
      if (this.filterSelectedStatuses && this.checkProperty(this.filterSelectedStatuses, 'length') > 0) {
        statusIds = this.filterSelectedStatuses.map((item) => item.id)
      }
      if (this.filterSelectedUserRoles && this.checkProperty(this.filterSelectedUserRoles, 'length') > 0) {
        roleIds = this.filterSelectedUserRoles.map((item) => item.id)
      }
      let postData =
      {
        "matcher": {
          "title": this.filterSearch,
          "searchString": this.filterSearch,
          "statusList": [],
          "createdByIds": [],
          "createdDateRange": [],
          "roleIds": roleIds,
          "statusIds": statusIds,
          "typeIds": [],
          "departmentIds": []
        },
        "sorting": {
          "path": "createdOn",
          "order": -1
        },
        "getMasterData": false,// if Masterdata required
        "page": this.page,
        "perpage": this.perpage,
      }
      this.$store.dispatch("getUsersList", postData)
        .then((res) => {
          this.isListLoading = false
          this.updateLoading(false);
          this.usersList = res.data.result.list
          if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
            this.totalCount = this.checkProperty(res.data.result, 'totalCount');
          }
          setTimeout(() => {
            this.updateLoading(false);
          })
        })
        .catch((error) => {
          this.usersList = []
          this.isListLoading = false
          this.updateLoading(false);
        })
    },
    showProfilePopup(profileItem) {
      let postData =
      {
        "userId": profileItem._id
      }
      this.$store.dispatch("getUserDetails", postData)
        .then((res) => {
          this.selectedUser = res.result
          this.showProfile = true
        })
        .catch((error) => {

        })

    },
    editUser(profileItem) {

      let postData =
      {
        "userId": profileItem._id
      }
      this.$store.dispatch("getUserDetails", postData)
        .then((res) => {

          this.selectedUser = res.result
          this.user = _.cloneDeep(this.selectedUser.details)
          this.user['userRole'] = _.find(this.userRoles, { "id": this.selectedUser['roleId'] });
          this.user['userDepartment'] = _.find(this.departments, { "id": this.selectedUser['details']['departmentId'] });

          if (this.checkProperty(this.selectedUser, 'details', 'documents')
            && this.checkProperty(this.selectedUser.details, 'documents', 'length') > 0) {
            let finalDocuments = []
            let existingDocs = this.checkProperty(this.selectedUser, 'details', 'documents')
            _.forEach(existingDocs, (item) => {
              let documents = []
              documents.push(item)
              finalDocuments.push(documents)
            });
            this.user.documents = finalDocuments

          } else {
            this.user.documents = []
          }

          setTimeout(() => {
            this.isUserEdit = true
            this.showAddUser = true
          }, 100)
        })
        .catch((error) => {

        })
    },
    applyFilters() {
      this.usersList = []
      this.isListLoading = true
      this.updateLoading(true);
      this.page = 1
      this.getUsers()
    },
    applySearchFilters() {
      this.usersList = []
      this.page = 1
      if (this.filterSearch && this.filterSearch.length > 2) {
        this.isListLoading = true
        this.updateLoading(true);
        this.getUsers()
      }
      if (this.filterSearch == '') {
        this.isListLoading = true
        this.updateLoading(true);
        this.getUsers()
      }
    },
    updatePassword() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          this.showLoader = true;
          //  set-password
          let path = "auth/change-password";
          if (this.checkProperty(this.selectedUser, 'passwordUpdated')) {
            path = "auth/change-password";
          }
          let postData = {
            newPassword: this.password.trim(),
            currentPassword: this.conformPassword.trim(),
            'userId': this.selectedUser['_id']
          };
          this.$store.dispatch("commonAction", { data: postData, path: path, })
            .then((response) => {
              this.showToster({ message: response.message, isError: false })
              this.showLoader = false;
              this.showPasswordChangePopup = false
              this.applyFilters();

            }).catch((error) => {
              // alert(JSON.stringify(error.message))
              this.showToster({ message: error.message, isError: true })
              this.showLoader = false;
              // this.showPasswordChangePopup = false
            });

        }
      })
    },
    changeStatus() {

      this.showLoader = true;
      let payload = {
        "userId": "",
        "statusId": 2, // 3. Inactive, 4.Delete
        "statusName": ''
      }
      payload['userId'] = this.selectedUser['_id'];
      if ([2].indexOf(this.selectedUser.statusId) > -1) {
        payload['statusId'] = 3
        payload['statusName'] = 'Inactive'
      } else {
        payload['statusId'] = 2
        payload['statusName'] = 'Active'
      }
      this.$store.dispatch("commonAction", { data: payload, path: "users/manage-status", })
        .then((response) => {
          this.showToster({ message: response.message, isError: false })
          this.showLoader = false;
          this.showStatusChangePopup = false;
          this.applyFilters();

        }).catch((error) => {
          this.showToster({ message: error.message, isError: true })
          this.showLoader = false;
          this.showStatusChangePopup = false

        });

    },
    removeDocument(index = -1) {
      if (index > -1 && this.checkProperty(this.user, 'documents', 'length') > 1) {
        this.showDocuments = false
        // if (this.user.documents[0] && this.user.documents[0].length > 0) {
        //   this.user.documents[0].splice(0, 1);
        // }
        this.user.documents.splice(index, 1);
        setTimeout(() => {
          this.showDocuments = true
        }, 0)
      }
    },
    getMasterDataList(category) {
      this.$store.dispatch("getMasterData", category)
        .then((res) => {

          if (category == 'user_statuses') {
            this.filterStatusList = [...res]
          }
        })
    },
    download_or_view(docItem) {


      let value = _.cloneDeep(docItem);
      // if (this.checkProperty(this.getPetitionDetails, 'caseNo') && this.checkProperty(value, 'name')) {
      //   let docName = _.cloneDeep(value['name']);
      //   value['name'] = this.checkProperty(this.getPetitionDetails, 'caseNo') + "_" + docName;
      // }


      var _self = this;
      this.formSubmited = false;
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }
      // value = Object.assign(value, { 'petitionId': this.petition['_id'] })
      // value = Object.assign(value, { 'subTypeDetails': this.petition['subTypeDetails'] })


      this.selectedFile = value;
      this.docValue = "";
      this.docPrivew = false;
      this.docType = false;
      this.docType = this.findmsDoctype(value["name"], value.mimetype);

      if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
        //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
          // "petitionId": value['petitionId'],

          // entityType:value['petitionId']
          "fileName": value.name ? value.name : ''
        };
        // if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
        //   postdata['entityType'] = 'perm'
        // } else {
        //   postdata['entityType'] = 'case'
        // }


        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;


          if (this.docType == "office") {
            this.docPrivew = true;
            setTimeout(() => {
              document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
              let _editing = false;

              // if ([3, 4].indexOf(this.getUserRoleId) > -1) {
              //   _editing = false;
              // }

              // if (value.viewmode) {
              //   _editing = false;
              // }
              var _ob = {}
              // if (value.editedDocument) {
              //   _ob = {

              //     evaluationId: this.evaluationDetails._id,
              //     name: value.name,
              //     _id: value._id,
              //     "extn": "docx",
              //     "formLetterType": "Letter",
              //     parentId: value.parentId
              //   }

              // } else {

              _ob = {

                name: value.name,
                evaluationId: this.evaluationDetails._id,
                _id: value._id,
                "extn": "docx",
                "formLetterType": "Letter",
                parentId: value._id

              }

              //  }


              window.docEditor = new DocsAPI.DocEditor("placeholder2",
                {

                  "document": {
                    "c": "forcesave",
                    "fileType": "docx",
                    "key": value._id,
                    "userdata": JSON.stringify(_ob),
                    "title": value.name,
                    "url": response.data.result.data,
                    permissions: {
                      edit: _editing,
                      download: true,
                      reader: false,
                      review: false,
                      comment: false
                    }
                  },

                  "documentType": "word",
                  "height": "100%",
                  "width": "100%",

                  "editorConfig": {
                    "userdata": JSON.stringify(_ob),
                    "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                    "customization": {
                      "logo": {
                        "image": "https://immibox.com/app/favicon.png",
                        "imageDark": "https://immibox.com/app/favicon.png",
                        "url": "https://immibox.com"
                      },
                      "anonymous": {
                        "request": false,
                        "label": "Guest"
                      },
                      "chat": false,
                      "comments": false,
                      "compactHeader": false,
                      "compactToolbar": true,
                      "compatibleFeatures": false,
                      "feedback": {
                        "visible": false
                      },
                      "forcesave": true,
                      "help": false,
                      "hideNotes": true,
                      "hideRightMenu": true,
                      "hideRulers": true,
                      layout: {
                        toolbar: {
                          "collaboration": false,
                        },
                      },
                      "macros": false,
                      "macrosMode": "warn",
                      "mentionShare": false,
                      "plugins": false,
                      "spellcheck": false,
                      "toolbarHideFileName": true,
                      "toolbarNoTabs": true,
                      "uiTheme": "theme-light",
                      "unit": "cm",
                      "zoom": 100
                    },
                  }, events: {
                    onReady: function () {

                    },
                    onDocumentStateChange: function (event) {
                      var url = event.data;
                      console.log(event)

                      if (!event.data) {

                        if (value.editedDocument) {

                        }

                      }
                    }

                  }
                });
              //this.docValue = encodeURIComponent(response.data.result.data);
            }, 100)
          }

          if (this.docType == "pdf") {

            // this.downloadFile(this.docValue, value.mimetype, value.name)

            // return
            var _vid = value._id;
            if (value.parentId) {
              _vid = value.parentId;
            }
            var viewmode = 1; // Enable edit
            viewmode = 0; //Disabled Edit
            if (value.viewmode) {
              viewmode = 0;
            }
            this.docValue = "https://beta.carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
            console.log(this.docValue)
            this.docPrivew = true;
          }
          if (this.docType == "image") {
            this.docPrivew = true;
          }



        });
      } else {



        this.downloads3file(value);
      }

    },
    sendPasswordLink(selectedUser) {
      this.showLoader = true;
      let payload = {
        "userName": this.checkProperty(selectedUser, 'userName'),
      }
      this.$store.dispatch("commonAction", { data: payload, path: "users/resend-verify-link", })
        .then((response) => {
          this.showToster({ message: response.message, isError: false })
          this.showLoader = false;
          // this.showStatusChangePopup = false;
          // this.applyFilters();

        }).catch((error) => {
          this.showToster({ message: error.message, isError: true })
          this.showLoader = false;
          this.showStatusChangePopup = false

        });

    },
    getRestaurantList(category) {
      this.$store.dispatch("getRestaurantList", category)
        .then((res) => {
          console.log('res', res.list)
          this.restaurantsList = res.list
        })
    },
  },

  mounted() {
    this.getMasterDataList('user_statuses')
    this.getRestaurantList()
    this.$store.dispatch("getMasterData", 'user_roles')
      .then((res) => {
        this.userRoles = _.filter(res, (item) => {
          if ([51, 50, 1, 2, 15].indexOf(item.id) <= -1) {
            return item.id;
          }
        });
        this.filterUserRolesList = _.filter(res, (item) => {
          if ([51, 50, 1, 2, 15].indexOf(item.id) <= -1) {
            return item.id;
          }
        });
      })

    this.$store
      .dispatch("getDepartments")
      .then((response) => {
        this.departments = response;
      })
      .catch(() => {
        this.loading = false;
      });

    this.isListLoading = true
    this.updateLoading(true);
    this.getUsers()

    let document = {
      url: "",
      name: "",
    }
    this.user.documents.push(document)
  },
  computed: {

  },
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
}
</script>