<template>
    <div class="login_area">
        <div class="login_sec">
            <h5>Forgot Password</h5>
            <label>Email/Username</label>
            <div class="input_group">
                <input type="text" class="form-control" placeholder="Ex: jacob@gmail.com">
                <img src="@/assets/images/user.png" style="width: 16px;left: 14px;">
            </div>
            <button class="login_btn crt_btn" @click="submitForm">Send</button>
            <p>Back to <a @click="gotoPage('/login')" class="create_link" data-bs-toggle="modal"
                    data-bs-target="#login_reg_modal">Log In</a></p>
        </div>
        <div class="guest_sec">
            <h6>Request an Evaluation as a Guest</h6>
            <a @click="gotoPage('/guest-request')" class="proceed_btn">Proceed</a>
        </div>
    </div>
</template>
<script>


export default {
    name: "CreateAccountView",
    provide() {
        return {

        };
    },
    components: {

    },
    methods: {
        gotoPage(path = "/") {
            this.$router.push(path);
        },
    },
};
</script>