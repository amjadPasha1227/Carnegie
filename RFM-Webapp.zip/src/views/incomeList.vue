<template>
    <div class="db_page">
        <!-- <div class="page_header">
        <h3>Users</h3>
      </div> -->
        <div class="filter_sec">
            <div class="d-flex w-100">
                <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" />
                <div class="custom-datepicker">

                    <date-range-picker :maxDate="new Date()" :autoApply="true" @update="getExpenses()"
                        :placeholder="'dd/mm/yyyy'" :ranges="false" :opens="'left'"
                        :locale-data="{ format: 'mmm dd, yyyy', customRangeLabel: 'Custom Range', }"
                        v-model="createdeDateRange"></date-range-picker>
                    <span class="clear" @click="clearDateRange()"
                        v-if="checkProperty(createdeDateRange, 'startDate') && checkProperty(createdeDateRange, 'endDate')"><img
                            src="@/assets/images/close.svg"></span>
                </div>
            </div>

            <div class="filters_right">

                <button class="add_btn" @click="showAddIncomePopup(false)"><span></span><em>Add Income</em></button>
            </div>
        </div>
        <div class="table-responsive" v-if="false">

            <template v-if="checkProperty(usersList, 'length') <= 0">
                <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users'
                    :loading="isListLoading" />
            </template>
            <table class="table user_table" v-if="checkProperty(usersList, 'length') > 0 && !isListLoading">
                <thead>
                    <tr>
                        <th>Order</th>
                        <th>Customer</th>
                        <th>Amount ($)</th>
                        <!-- <th>Delivery Date</th> -->
                        <!-- <th>Received ($)</th>
                        <th>Received On</th>
                        <th>Collected By</th> -->
                        <th>Balance ($)</th>
                        <!-- <th>Updated By</th> -->
                        <th>Updated On</th>
                        <!-- <th>Notes</th> -->
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in    usersList   " v-bind:key="index">

                        <td><span class="request_id" @click="editDetails(item, false)">{{ checkProperty(item,
                            'orderDetails',
                            'requestId') ?
                            checkProperty(item, 'orderDetails', 'requestId')
                            : checkProperty(item, 'orderThrough') }}</span>
                        </td>
                        <td><span class="last_name">{{ checkProperty(item, 'orderDetails', 'customerName') ?
                            checkProperty(item, 'orderDetails', 'customerName')
                            : '' }}</span></td>
                        <td><span class="last_name">{{ checkProperty(item, 'orderAmount') }}</span></td>
                        <!-- <td><span class="last_name">{{ checkProperty(item, 'deliveryDate') | formatDate }}</span></td> -->
                        <!-- <td><span class="first_name">{{ checkProperty(item, 'amountReceived') }}</span></td>
                        <td><span class="first_name">{{ checkProperty(item, 'receivedOn') | formatDate }}</span></td>
                        <td><span class="first_name">{{ checkProperty(item, 'collectedByDetails', 'name') }}</span></td> -->
                        <td><span class="first_name">{{ !checkProperty(item, 'balanceReceivable') ? '' : checkProperty(item,
                            'balanceReceivable') == 0 ? '' : checkProperty(item, 'balanceReceivable') }}</span></td>
                        <!-- <td><span>{{ checkProperty(item, 'createdByDetails', 'name') }}</span></td> -->
                        <td><span class="last_name">{{ item.createdOn | formatDate }}</span></td>

                        <!-- <td><span v-html="checkProperty(item, 'notes')"></span></td> -->

                        <td>
                            <div class="actions">
                                <dropdownHover aria-disabled="true">
                                    <b-dropdown-item @click="editDetails(item, true)">Edit</b-dropdown-item>
                                    <b-dropdown-item @click="editDetails(item, false)">View Details</b-dropdown-item>
                                </dropdownHover>
                            </div>

                        </td>
                    </tr>

                </tbody>
            </table>
            <!-- <h2 v-if="usersList.length <= 0" class="loading_NoData">
            <template v-if="isListLoading"> Loading.....</template>
            <template v-else> No Users Found!</template>
          </h2> -->
            <div class="pagination-sec" v-if="checkProperty(usersList, 'length') > 0">
                <div class="per-page">
                    <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) +
                        usersList.length) +
                        ' of ' + totalCount + ' Results' }}</label>
                </div>
                <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
                    @input=" isListLoading = true, updateLoading(true), getExpenses()"></b-pagination>
            </div>
        </div>

        <div class="mobile_table_list">
            <template v-if="checkProperty(usersList, 'length') <= 0">
                <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users'
                    :loading="isListLoading" />
            </template>
            <ul v-if="checkProperty(usersList, 'length') > 0 && !isListLoading">
                <li v-for="(item, index) in usersList " v-bind:key="index">
                    <div class="list_row">
                        <div>
                            <span class="list_heading">{{ checkProperty(item,
                            'orderDetails',
                            'requestId') ?
                            checkProperty(item, 'orderDetails', 'requestId')
                            : checkProperty(item, 'orderThrough') }}
                            </span>
                        </div>
                        <div class="actions">
                            <dropdownHover aria-disabled="true">
                                <b-dropdown-item @click="editDetails(item, true)">Edit</b-dropdown-item>
                                <b-dropdown-item @click="editDetails(item, false)">View Details</b-dropdown-item>
                            </dropdownHover>
                        </div>
                    </div>
                    <div class="list_row">
                        <div><span>customer :</span> {{ checkProperty(item, 'orderDetails', 'customerName') ?
                            checkProperty(item, 'orderDetails', 'customerName')
                            : '' }}</div>
                        <div><span>updated on :</span> {{ item.createdOn | formatDate }}</div>
                    </div>
                    <div class="list_row">
                        <div><span>amount ($) :</span> {{ checkProperty(item, 'orderAmount') }}</div>
                        <div><span>balance ($) :</span> {{ !checkProperty(item, 'balanceReceivable') ? '' : checkProperty(item,
                            'balanceReceivable') == 0 ? '' : checkProperty(item, 'balanceReceivable') }}</div>
                    </div>
                </li>
            </ul>
            <div class="pagination-sec" v-if="checkProperty(usersList, 'length') > 0">
                <div class="per-page">
                    <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) +
                        usersList.length) +
                        ' of ' + totalCount + ' Results' }}</label>
                </div>
                <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
                    @input=" isListLoading = true, updateLoading(true), getExpenses()"></b-pagination>
            </div>
        </div>
        <!-- Add User Modal -->
        <b-modal v-model="showAddIncome" id="adduser_model" dialog-class="adduser_model" centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">{{ isIncomeEdit ? 'Update Income' : 'Add Income' }}</h6>
                <a class="close" @click=" showAddIncome = false"></a>
            </template>
            <template>

                <div class="form_info">
                    <div class="row">
                        <div class="col-md-6 generated_docs generated_docs_v2">
                            <!-- :required="!checkProperty(income, 'onlineOrder') && !checkProperty(income, 'order') ? true : false" -->

                            <customSelect :multiple="false" :wrapclass="'mb-0'" :label="'Order*'" :trackBy="'requestId'"
                                :optionItemLabel="'requestId'" :optionslist="ordersList" :display="true"
                                :place-holder="'Select Order'" :searchable="false" :close-on-select="true"
                                :clear-on-select="true" v-model="income.order" :fieldName="'order'" :cid="'order'"
                                :vvas="'Order'" @input="updateOfflineOrder" :isDisabled="isIncomeEdit" />

                            <div class="or_text">
                                <span><strong>OR</strong></span>
                            </div>
                            <div class="user_type_list mb-3">
                                <template v-for="(   roleItem, index    ) in    onlineOrdersList   ">
                                    <radioInput wrapclass="radio_group_v2" :elementId="'usertype' + index"
                                        :label="roleItem.name" :fieldName="'usertype'" v-model="income.onlineOrder"
                                        :fieldValue="roleItem" @input="updateOnlineOrder" :disabled="isIncomeEdit" />
                                </template>
                                <input type="hidden" class="form-control"
                                    v-validate="!checkProperty(income, 'onlineOrder') && !checkProperty(income, 'order') ? 'required' : ''"
                                    v-model="income.onlineOrder" data-vv-as="Order" :name="'userroleRadio'" />
                                <span v-show="errors.has('userroleRadio')" class="form-error">{{
                                    errors.first('userroleRadio') }}</span>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'orderAmount'" :cid="'orderAmount'"
                                :label="'Order Total ($)'" :placeHolder="'Order Amount'" :vvas="'Order Amount'"
                                :display="true" :required="true" v-model="income.orderAmount" :onlyNumbers="true"
                                :allowFloatingPoint="true" :disabled="checkProperty(income, 'order', '_id') ? true : false"
                                @input="updatebalanceAmount" />

                        </div>
                        <div class="col-md-6">
                            <datepicker :wrapclass="'mb20'" :required="true" v-model="income.deliveryDate"
                                fieldName="deliveryDate" label="Delivery Date" />
                        </div>
                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'amountReceived'" :cid="'amountReceived'"
                                :label="'Amount Received ($)'" :placeHolder="'Amount Received'" :vvas="'Amount Received'"
                                :display="true" :required="true" v-model="income.amountReceived" :onlyNumbers="true"
                                :allowFloatingPoint="true" @input="updatebalanceAmount"
                                :disabled="checkProperty(income, 'onlineOrder') ? true : false" />

                        </div>
                        <div class="col-md-6">
                            <datepicker :wrapclass="'mb20'" :required="true" v-model="income.receivedOn"
                                fieldName="receivedOn" label="Received On" :dateEnableTo="getCurrentDate()" />
                        </div>

                        <div class="col-md-6">
                            <simpleSelect :multiple="false" :wrapclass="'mb20'" :label="'Collected By'"
                                :optionslist="collectedByList" :display="true" :place-holder="'Select Collected By'"
                                :searchable="false" :required="true" :close-on-select="true" :clear-on-select="true"
                                v-model="income.collectedBy" :fieldName="'collectedBy'" :cid="'collectedBy'"
                                :vvas="'Collected By'" />
                        </div>
                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'balanceReceivable'" :cid="'balanceReceivable'"
                                :label="'Balance Receivable ($)'" :placeHolder="'Balance Receivable'"
                                :vvas="'Balance Receivable'" :display="true" :required="true"
                                v-model="income.balanceReceivable" :onlyNumbers="true" :allowFloatingPoint="true"
                                :disabled="true" />

                        </div>
                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'updateddBy'" :cid="'updateddBy'"
                                :label="'Updated By'" :placeHolder="'Updated By'" :vvas="'Updated By'" :display="true"
                                :required="true" v-model="income.updateddBy" :allowAlphNum="true" :disabled="true" />

                        </div>


                        <div class="col-md-12">
                            <textArea :label="'Notes'" :wrapclass="'h80 mb10'" placeHolder="Notes" v-model="income.notes"
                                :required="false" :fieldName="'notes'" :cid="'notes'"></textArea>
                        </div>


                    </div>
                </div>
            </template>
            <template #modal-footer>
                <button class="form-cancel" @click=" showAddIncome = false">Cancel</button>
                <button class="primary_btn md" @click="addOrUpdateIncome">{{ isIncomeEdit ? 'Update' : 'Submit' }}</button>
            </template>
        </b-modal>

        <!-- User Added Success Modal -->
        <b-modal v-model="showAddIncomeSuccess" id="success_model" dialog-class="success_model user_success" centered
            hide-header hide-footer>
            <template>
                <figure>
                    <img src="@/assets/images/success_mdl_img.png" />
                </figure>
                <h4 class="m-0">{{ isIncomeEdit ? 'Income updated!' : 'Income added!' }}</h4>
                <h7 class="m-0" style="padding-left:20px;padding-right:20px;text-align: center;">{{ successMsg }}</h7>
                <button class="primary_btn md" style="margin-top:14px ;"
                    @click=" showAddIncomeSuccess = false; page = 1; isListLoading = true; updateLoading(true); getExpenses()">OKAY</button>
            </template>
        </b-modal>
        <!-- Details Modal -->
        <b-modal v-model="showDetailsPopup" id="create_template" dialog-class="create_template details_modal" centered
            hide-footer no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">{{ 'Income Details' }}</h6>
                <a class="close" @click="showDetailsPopup = false"></a>
            </template>
            <template>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form_group">
                            <lable class="form_label">Order</lable>
                            <p>{{ checkProperty(selectedIncome, 'incomeType') == 1 ? checkProperty(selectedIncome,
                                'orderDetails', 'requestId')
                                : checkProperty(selectedIncome, 'orderThrough') }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedIncome, 'orderAmount')">
                            <lable class="form_label">Order Total ($)</lable>
                            <p>{{ checkProperty(selectedIncome, 'orderAmount') ? checkProperty(selectedIncome,
                                'orderAmount')
                                : '' }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedIncome, 'deliveryDate')">
                            <lable class="form_label">Delivery Date</lable>
                            <p>{{ checkProperty(selectedIncome, 'deliveryDate') | formatDate }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedIncome, 'amountReceived')">
                            <lable class="form_label">Amount Received ($)</lable>
                            <p>{{ checkProperty(selectedIncome, 'amountReceived') ? checkProperty(selectedIncome,
                                'amountReceived')
                                : '' }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedIncome, 'receivedOn')">
                            <lable class="form_label">Received On</lable>
                            <p>{{ checkProperty(selectedIncome, 'receivedOn') | formatDate }}</p>
                        </div>

                        <div class="form_group" v-if="checkProperty(selectedIncome, 'collectedByDetails', 'name')">
                            <lable class="form_label">Collected By</lable>
                            <p>{{ checkProperty(selectedIncome, 'collectedByDetails', 'name') ?
                                checkProperty(selectedIncome,
                                    'collectedByDetails', 'name')
                                : '' }}</p>
                        </div>
                        <!-- <div class="form_group">
                            <lable class="form_label">Collected By</lable>
                            <p>{{ checkProperty(selectedIncome, 'collectedBy', 'name') ? checkProperty(selectedIncome,
                                'collectedBy', 'name')
                                : '' }}</p>
                        </div> -->
                        <div class="form_group" v-if="checkProperty(selectedIncome, 'balanceReceivable')">
                            <lable class="form_label">Balance Receivable ($)</lable>
                            <p>{{ checkProperty(selectedIncome, 'balanceReceivable') ? checkProperty(selectedIncome,
                                'balanceReceivable')
                                : '' }}</p>
                        </div>
                        <div class="form_group">
                            <lable class="form_label">{{ checkProperty(selectedIncome, 'updatedByDetails', 'name') ?
                                'Updated By' : 'Created By' }}</lable>
                            <p>{{ checkProperty(selectedIncome, 'updatedByDetails', 'name') ? checkProperty(selectedIncome,
                                'updatedByDetails', 'name')
                                : checkProperty(selectedIncome, 'createdByDetails', 'name') }}</p>
                        </div>

                    </div>
                    <div class="col-md-12" v-if="checkProperty(selectedIncome, 'notes')">
                        <div class="form_group notes" >
                            <lable class="form_label">Notes</lable>
                            <p v-html="checkProperty(selectedIncome, 'notes')"></p>
                        </div>
                    </div>

                </div>
            </template>
        </b-modal>
        <EditRestructPopup v-if="showSubmitConfirmPopup" @submitAction="submitAction"></EditRestructPopup>
    </div>
</template>
  
<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import fileUpload from "@/views/forms/fileupload.vue";
import simpleSelect from '@/views/forms/simpleSelect.vue';
import customSelect from '@/views/forms/customSelect.vue';
import dropdownHover from '@/views/forms/dropdownHover.vue';
import radioInput from "@/views/forms/radioInput.vue";
import textArea from "@/views/forms/textarea.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import phoneInput from "@/views/forms/phonenumber.vue";
import axios from 'axios';
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import NoDataFound from "@/views/common/noData.vue";
import moment from "moment";
import datepicker from '@/views/forms/datePicker.vue';
import DateRangePicker from "vue2-daterange-picker";
import 'vue2-daterange-picker/dist/vue2-daterange-picker.css'
import 'vue2-datepicker/index.css';
import EditRestructPopup from '@/views/common/editRestructPopup.vue';


export default {
    name: 'dashboard-view',
    components: {
        searchInput,
        simpleSelect,
        dropdownHover,
        radioInput,
        simpleInput,
        fileUpload,
        fileUploadDrag,
        textArea,
        phoneInput,
        DocumentsPreview,
        NoDataFound,
        datepicker,
        customSelect,
        DateRangePicker,
        EditRestructPopup,
    },
    data: () => ({
        showSubmitConfirmPopup: false,
        showAddIncome: false,
        showAddIncomeSuccess: false,
        isIncomeEdit: false,
        isListLoading: true,
        page: 1,
        perpage: 20,
        totalCount: 0,
        currentPage: 1,
        usersList: [],
        filterStatusList: [],
        filterSelectedUserRoles: null,
        filterSelectedStatuses: null,
        filterSearch: '',
        autoApply: "",
        createdeDateRange: {
            startDate: null,
            endDate: null
        },
        income: {
            order: '',
            deliveryDate: '',
            receivedOn: null,
            collectedBy: null,
            amountReceived: '',
            balanceReceivable: '',
            updateddBy: '',
            notes: '',
            onlineOrder: null,
            orderAmount: ''
        },
        selectedIncome: null,
        successMsg: '',
        password: '',
        conformPassword: '',
        showPassword: false,
        showCPassword: false,
        showDocuments: true,
        docType: '',
        formSubmited: false,
        docPrivew: false,
        docType: '',
        selectedFile: null,
        ordersList: [],
        collectedByList: [],
        onlineOrdersList: [
            {
                id: '1',
                name: 'Uber Eats'
            },
            {
                id: '2',
                name: 'Door Dash'
            },
            {
                id: '3',
                name: 'Grabhub'
            }
        ],
        showDetailsPopup: false,

    }),
    methods: {
        submitAction(actionType) {
            this.showSubmitConfirmPopup = false
        },
        clearDateRange() {
            //alert()
            this.createdeDateRange = {
                startDate: null,
                endDate: null
            }
            this.getExpenses()
        },
        showAddIncomePopup(isEdit = false) {
            this.isIncomeEdit = false
            this.income = {
                order: '',
                deliveryDate: '',
                receivedOn: null,
                collectedBy: null,
                amountReceived: '',
                balanceReceivable: '',
                updateddBy: this.checkProperty(this.getUserData, 'name'),
                notes: '',
                onlineOrder: null,
                orderAmount: ''
            }

            this.showAddIncome = true
        },

        addOrUpdateIncome() {
            this.$validator.validateAll().then((result) => {
                if (result) {
                    let postData = {
                        // "orderType": this.income.order.id,
                        // "orderId": this.income.order.id,
                        "deliveryDate": this.income.deliveryDate,
                        "receivedOn": this.income.receivedOn,
                        "collectedBy": this.income.collectedBy['_id'],
                        "amountReceived": this.income.amountReceived,
                        "balanceReceivable": this.income.balanceReceivable,
                        //"balanceReceivable": this.income.balanceReceivable,
                        "orderAmount": this.income.orderAmount,
                        "notes": this.income.notes,
                        "today": new Date(),
                    }
                    if (this.checkProperty(this.income, "order", "_id")) {
                        Object.assign(postData, { orderId: this.checkProperty(this.income, "order", "_id"), incomeType: "1" });
                    }
                    if (this.checkProperty(this.income, "onlineOrder", "id")) {
                        Object.assign(postData, { incomeType: "2", orderThrough: this.checkProperty(this.income, "onlineOrder", "name") });
                    }
                    if (this.isIncomeEdit) {
                        postData['incomeId'] = this.selectedIncome._id
                        this.$store
                            .dispatch("userUpdate", postData)
                            .then((response) => {
                                if (response.error) {
                                    this.showToster({ message: response.error.message, isError: true });
                                } else {
                                    this.successMsg = response.message
                                    this.showAddIncome = false
                                    //this.showAddIncomeSuccess = true
                                    this.usersList = []
                                    this.showToster({ message: response.message, isError: false });
                                    this.isListLoading = true
                                    this.updateLoading(true);
                                    this.page = 1
                                    this.getExpenses()
                                }
                            })
                            .catch((error) => {
                                this.showToster({ message: error, isError: true });
                                this.loading = false;
                            });
                    } else {
                        this.$store
                            .dispatch("incomeCreate", postData)
                            .then((response) => {
                                if (response.error) {
                                    this.showToster({ message: response.error.message, isError: true });
                                } else {
                                    this.successMsg = response.message
                                    this.showAddIncome = false
                                    this.showAddIncomeSuccess = true
                                    //this.showToster({ message: response.message, isError: false });
                                    //  this.page = 1
                                    //  this.getExpenses()
                                }
                            })
                            .catch((error) => {
                                this.showToster({ message: error, isError: true });
                                this.loading = false;
                            });
                    }




                } else {

                }
            })
        },

        getExpenses() {
            this.isIncomeEdit = false
            let dateRange = []

            if (this.checkProperty(this.createdeDateRange, 'startDate') && this.checkProperty(this.createdeDateRange, 'endDate')) {
                let startDate = moment(this.checkProperty(this.createdeDateRange, 'startDate')).format("YYYY-MM-DD");
                let endDate = moment(this.checkProperty(this.createdeDateRange, 'endDate')).format("YYYY-MM-DD");
                dateRange.push(startDate)
                dateRange.push(endDate)
            }
            if (this.filterSelectedUserRoles && this.checkProperty(this.filterSelectedUserRoles, 'length') > 0) {
                roleIds = this.filterSelectedUserRoles.map((item) => item.id)
            }


            let postData =
            {
                "matcher": {
                    "title": this.filterSearch,
                    "searchString": this.filterSearch,
                    "statusList": [],
                    "createdByIds": [],
                    "createdDateRange": dateRange,
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": false,// if Masterdata required
                "page": this.page,
                "perpage": this.perpage,
            }
             postData['restaurantId'] = localStorage.getItem('restaurantId');
            this.$store.dispatch("getIncomeList", postData)
                .then((res) => {
                    this.isListLoading = false
                    this.updateLoading(false);
                    this.usersList = res.data.result.list
                    if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
                        this.totalCount = this.checkProperty(res.data.result, 'totalCount');
                    }
                    setTimeout(() => {
                        this.updateLoading(false);
                    })
                })
                .catch((error) => {
                    this.usersList = []
                    this.isListLoading = false
                    this.updateLoading(false);
                })
        },

        applyFilters() {
            this.usersList = []
            this.isListLoading = true
            this.updateLoading(true);
            this.page = 1
            this.getExpenses()
        },
        applySearchFilters() {
            this.usersList = []
            this.page = 1
            if (this.filterSearch && this.filterSearch.length > 2) {
                this.isListLoading = true
                this.updateLoading(true);
                this.getExpenses()
            }
            if (this.filterSearch == '') {
                this.isListLoading = true
                this.updateLoading(true);
                this.getExpenses()
            }
        },

        getMasterDataList(category) {
            this.$store.dispatch("getMasterData", category)
                .then((res) => {

                    if (category == 'user_statuses') {
                        this.filterStatusList = [...res]
                    }
                })
        },

        getCurrentDate() {
            return moment().subtract(0, 'days')
        },
        getUsers() {
            let postData =
            {
                "matcher": {
                    "roleIds": [4],
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": true,// if Masterdata required
                "page": 1,
                "perpage": 500,
            }
            this.$store.dispatch("getUsersList", postData)
                .then((res) => {
                    this.collectedByList = res.data.result.list
                })
                .catch((error) => {
                })
        },

        getOrdersList() {

            let postData =
            {
                "matcher": {
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "pendingOrders": true,// if Masterdata required
                "page": 1,
                "perpage": 1000,
            }
            this.$store.dispatch("getOrdersList", postData)
                .then((res) => {
                    this.ordersList = res.data.result.list


                })
                .catch((error) => {
                    this.ordersList = []
                })
        },
        updateOnlineOrder(data) {
            // alert(JSON.stringify(data))
            this.income['onlineOrder'] = data
            this.income['order'] = null
            this.income = _.cloneDeep(this.income)
        },
        updateOfflineOrder(data) {
            // alert(JSON.stringify(data))
            this.income.orderAmount = this.checkProperty(data, 'amount')
            this.income.deliveryDate = this.checkProperty(data, 'deliveryDate')
            this.income.balanceReceivable = this.checkProperty(data, 'balanceDue')
            if (this.checkProperty(this.income, 'amountReceived') > this.checkProperty(income, 'balanceReceivable')) {
                this.income['amountReceived'] = ""
                // this.income['balanceReceivable'] = ""
            }
            // if (this.checkProperty(this.income, "amountReceived")>this.checkProperty(data, "amount")) {
            //     this.income['amountReceived'] = ""
            // }


            this.income['onlineOrder'] = null
            this.income['order'] = data
            this.income = _.cloneDeep(this.income)
        },
        updatebalanceAmount() {
            if (this.checkProperty(this.income, "order", '_id')) {
                if (!this.checkProperty(this.income, "amountReceived")) {
                    this.income.balanceReceivable = this.checkProperty(this.income, "order", 'balanceDue')
                }
                else if (this.checkProperty(this.income, "order", 'balanceDue')
                    && this.checkProperty(this.income, "amountReceived")
                    && parseFloat(this.checkProperty(this.income, "amountReceived")) > parseFloat(this.checkProperty(this.income, "order", 'balanceDue'))) {
                    this.income['amountReceived'] = ""
                    this.income['balanceReceivable'] = this.checkProperty(this.income, "order", 'balanceDue')
                } else if (!this.checkProperty(this.income, "amountReceived")) {

                }
                if (this.checkProperty(this.income, "order", 'balanceDue')
                    && this.checkProperty(this.income, 'amountReceived')) {
                    let balanceAmount = parseFloat(this.checkProperty(this.income, "order", 'balanceDue')) - parseFloat(this.checkProperty(this.income, "amountReceived"))
                    if (Number.isInteger(balanceAmount)) {

                    } else {
                        // If it's a decimal, trim it to 2 decimal places
                        balanceAmount = balanceAmount.toFixed(2);
                    }

                    this.income['balanceReceivable'] = balanceAmount < 0 ? '' : balanceAmount
                }
            } else {
                if (!this.checkProperty(this.income, "amountReceived")) {
                    this.income['balanceReceivable'] = ""
                } else {
                    this.income['balanceReceivable'] = 0
                }
                this.income['amountReceived'] = this.checkProperty(this.income, 'orderAmount')

                // if (!this.checkProperty(this.income, "amountReceived")) {
                //     this.income['balanceReceivable'] = this.checkProperty(this.income, "orderAmount")
                // }
                // else if (this.checkProperty(this.income, 'orderAmount')
                //     && this.checkProperty(this.income, "amountReceived")
                //     && parseFloat(this.checkProperty(this.income, "amountReceived")) > parseFloat(this.checkProperty(this.income, 'orderAmount'))) {

                //     this.income['amountReceived'] = ""
                //     this.income['balanceReceivable'] = this.checkProperty(this.income, 'orderAmount')
                // } else if (!this.checkProperty(this.income, "amountReceived")) {

                // }
                // if (this.checkProperty(this.income, "orderAmount")
                //     && this.checkProperty(this.income, 'amountReceived')) {
                //     let balanceAmount = parseFloat(this.checkProperty(this.income, 'orderAmount')) - parseFloat(this.checkProperty(this.income, "amountReceived"))
                //     if (Number.isInteger(balanceAmount)) {

                //     } else {
                //         balanceAmount = balanceAmount.toFixed(2);
                //     }
                //     this.income['balanceReceivable'] = balanceAmount < 0 ? '' : balanceAmount
                // }
            }


            // if (!this.checkProperty(this.income, "amountReceived")) {
            //     if (this.checkProperty(this.income, "order", '_id')) {
            //         this.income.balanceReceivable = this.checkProperty(this.income, "order", 'balanceDue')
            //     } else {
            //         this.income['balanceReceivable'] = ""
            //     }
            // }
            // else if (this.checkProperty(this.income, 'balanceReceivable')
            //     && this.checkProperty(this.income, "amountReceived")
            //     && this.checkProperty(this.income, "amountReceived") > this.checkProperty(this.income, 'balanceReceivable')) {
            //     this.income['amountReceived'] = ""
            //     // this.income['balanceReceivable'] = ""
            // } else if (!this.checkProperty(this.income, "amountReceived")) {

            // }
            // if (this.checkProperty(this.income, "balanceReceivable")
            //     && this.checkProperty(this.income, 'amountReceived')) {
            //     let balanceAmount = this.checkProperty(this.income, 'balanceReceivable') - this.checkProperty(this.income, "amountReceived")
            //     if (Number.isInteger(balanceAmount)) {

            //     } else {
            //         // If it's a decimal, trim it to 2 decimal places
            //         balanceAmount = balanceAmount.toFixed(2);
            //     }

            //     this.income['balanceReceivable'] = balanceAmount < 0 ? '' : balanceAmount
            // }
        },
        editDetails(editItem, isEditDetails = false) {

            this.selectedIncome = editItem

            if (isEditDetails) {
                this.income = _.cloneDeep(this.selectedIncome)
                this.income['collectedBy'] = this.checkProperty(this.selectedIncome, 'collectedByDetails');
                if (this.checkProperty(this.selectedIncome, 'incomeType') == 1) {
                    this.income['order'] = _.find(this.ordersList, { "_id": this.selectedIncome['orderId'] });
                } else {
                    this.income['orderThrough'] = this.checkProperty(this.selectedIncome, 'orderThrough')
                }
                this.income['onlineOrder'] = _.find(this.onlineOrdersList, { "name": this.selectedIncome['orderThrough'] });
                this.income['updateddBy'] =this.checkProperty(this.getUserData, 'name');
                
                if (!this.canEditTheRecord(this.checkProperty(editItem, 'createdOn'))) {
                    this.showSubmitConfirmPopup = true
                } else {
                    this.isIncomeEdit = true
                    this.showAddIncome = true
                }
            } else {
                this.showDetailsPopup = true
            }


            // let postData =
            // {
            //     "incomeId": editItem._id
            // }
            // this.$store.dispatch("getDetails", { data: postData, path: '/income/details' })
            //     .then((res) => {
            //         this.selectedIncome = res
            //         // this.income = {
            //         //     order: '',
            //         //     deliveryDate: this.checkProperty(this.selectedIncome,'deliveryDate')?this.checkProperty(this.selectedIncome,'deliveryDate'):'',
            //         //     receivedOn: this.checkProperty(this.selectedIncome,'receivedOn')?this.checkProperty(this.selectedIncome,'receivedOn'):'',
            //         //     collectedBy: null,
            //         //     amountReceived: this.checkProperty(this.selectedIncome,'amountReceived')?this.checkProperty(this.selectedIncome,'amountReceived'):'',
            //         //     balanceReceivable: this.checkProperty(this.selectedIncome,'balanceReceivable')?this.checkProperty(this.selectedIncome,'balanceReceivable'):'',
            //         //     updateddBy: this.checkProperty(this.selectedIncome,'updatedBy')?this.checkProperty(this.selectedIncome,'updatedBy'):'',
            //         //     notes: this.checkProperty(this.selectedIncome,'notes'),
            //         //     onlineOrder: null,
            //         //     orderAmount: this.checkProperty(this.selectedIncome,'orderAmount')?this.checkProperty(this.selectedIncome,'orderAmount'):'',
            //         // }

            //         this.income = _.cloneDeep(this.selectedIncome)

            //         this.income['collectedBy'] = _.find(this.collectedByList, { "_id": this.selectedIncome['collectedBy'] });
            //         if (this.checkProperty(this.selectedIncome, 'incomeType') == 1) {
            //             this.income['order'] = _.find(this.ordersList, { "_id": this.selectedIncome['orderId'] });
            //             this.income['order'] = _.find(this.ordersList, { "_id": this.selectedIncome['orderId'] });
            //         } else {
            //             this.income['orderThrough'] = this.checkProperty(this.selectedIncome, 'orderThrough')
            //         }
            //         this.income['onlineOrder'] = _.find(this.onlineOrdersList, { "name": this.selectedIncome['orderThrough'] });

            //         setTimeout(() => {
            //             if (isEditDetails) {
            //                 this.isIncomeEdit = true
            //                 this.showAddIncome = true
            //             } else {
            //                 this.showDetailsPopup = true
            //             }
            //         }, 100)
            //     })
            //     .catch((error) => {
            //         console.log('error', error)
            //     })

        },
        viewDetails(editItem) {
            let postData =
            {
                "incomeId": editItem._id
            }
            this.$store.dispatch("getDetails", { data: postData, path: '/income/details' })
                .then((res) => {
                    this.selectedIncome = res
                    this.selectedIncome['collectedBy'] = _.find(this.collectedByList, { "_id": this.selectedIncome['collectedBy'] });
                    if (this.checkProperty(this.selectedIncome, 'incomeType') == 1) {
                        this.selectedIncome['order'] = _.find(this.ordersList, { "_id": this.selectedIncome['orderId'] });
                        //this.selectedIncome['order'] = _.find(this.ordersList, { "_id": this.selectedIncome['orderId'] });
                    } else {
                        this.selectedIncome['orderThrough'] = this.checkProperty(this.selectedIncome, 'orderThrough')
                    }
                    this.selectedIncome['onlineOrder'] = _.find(this.onlineOrdersList, { "name": this.selectedIncome['orderThrough'] });
                    setTimeout(() => {
                        this.showDetailsPopup = true
                    }, 1)
                })
                .catch((error) => {
                    console.log('error', error)
                })


        }

    },

    mounted() {
        this.getUsers()
        this.getOrdersList()
        this.$store.dispatch("getMasterData", 'order_type')
            .then((response) => {
                this.orderTypeList = response;
            })

        this.isListLoading = true
        this.updateLoading(true);
        this.getExpenses()

    },
    computed: {

    },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>