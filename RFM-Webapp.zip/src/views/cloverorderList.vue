<template>
    <div class="db_page">
        <!-- <div class="page_header">
        <h3>Users</h3>
      </div> -->
        <div class="filter_sec">
            <div class="d-flex w-100">
                <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" />
                <div class="custom-datepicker">

                <date-range-picker :maxDate="new Date()" :autoApply="autoApply" @update="" :placeholder="'dd/mm/yyyy'"
                :ranges="false" :opens="'left'" :locale-data="{ format: 'mmm dd, yyyy', customRangeLabel: 'Custom Range', }"
                v-model="topFiveDateRange"></date-range-picker>
                <span class="clear" @click="clearDateRange()"
                v-if="checkProperty(topFiveDateRange, 'startDate') && checkProperty(topFiveDateRange, 'endDate')"><img
                    src="@/assets/images/close.svg"></span>
                </div>
            </div>

       
        </div>
        <div class="table-responsive">

            <template v-if="checkProperty(usersList, 'length') <= 0">
                <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users'
                    :loading="isListLoading" />
            </template>
            <table class="table user_table" v-if="checkProperty(usersList, 'length') > 0 && !isListLoading">
                  <thead>
        <tr>
          <th>Order ID</th>
          <th>Type</th>
          <th>Total($ )</th>
          <th>Date</th>
          <th >Payment <br/> Status</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item, index) in usersList" :key="index">
          <td><span>{{ checkProperty(item, 'orderId') }}</span></td>
          <td><span>{{ checkProperty(item, 'orderType') }}</span></td>
          <td><span>{{ checkProperty(item, 'orderTotal') }}</span></td>
          <td><span >{{ checkProperty(item, 'orderDate') | formatDate }}</span></td>
          <td><span>{{ checkProperty(item, 'orderPaymentState') }}</span></td>
        </tr>
      </tbody>
            </table>
            <!-- <h2 v-if="usersList.length <= 0" class="loading_NoData">
            <template v-if="isListLoading"> Loading.....</template>
            <template v-else> No Users Found!</template>
          </h2> -->
            <div class="pagination-sec" v-if="checkProperty(usersList, 'length') > 0">
                <div class="per-page">
                    <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) +
                        usersList.length) +
                        ' of ' + totalCount + ' Results' }}</label>
                </div>
                <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
                    @input=" isListLoading = true, updateLoading(true), getExpenses()"></b-pagination>
            </div>
        </div>
        <!-- Add User Modal -->
        <b-modal v-model="showAddUser" id="adduser_model" dialog-class="adduser_model" centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">{{ isUserEdit ? 'Update Expense' : 'Add Order' }}</h6>
                <a class="close" @click=" showAddUser = false"></a>
            </template>
            <template>

                <div class="form_info">
                    <div class="row">
                        <div class="col-md-6">
                            <simpleSelect :multiple="false" :wrapclass="'mb20'" :label="'Order Type'"
                                :optionslist="natureOfExpenseList" :display="true"
                                :place-holder="'Select Order Type'" :searchable="false" :required="true"
                                :close-on-select="true" :clear-on-select="true" v-model="order.orderType"
                                :fieldName="'orderType'" :cid="'orderType'" :vvas="'Order Type'" />
                        </div>

                        <div class="col-md-6">
                            <datepicker :wrapclass="'mb20'" :required="true" v-model="order.orderDate"
                                fieldName="transactionDate" label="Order Date" :dateEnableTo="getCurrentDate()" />
                        </div>
                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'createdBy'" :cid="'createdBy'" :label="'Created By'"
                                :placeHolder="'Created By'" :vvas="'Created By'" :display="true" :required="true"
                                v-model="order.createdBy" :allowAlphNum="true" />

                        </div>
                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'amount'" :cid="'amount'" :label="'Amount'"
                                :placeHolder="'Amount'" :vvas="'Amount'" :display="true" :required="true"
                                v-model="order.amount" :onlyNumbers="true" :allowFloatingPoint="true"/>

                        </div>
                          <div class="col-md-6">
                            <datepicker :wrapclass="'mb20'" :required="true" v-model="order.createdOn"
                                fieldName="createdOn" label="Created Date" :dateEnableTo="getCurrentDate()" />
                        </div>
                        <div class="col-md-12">
                            <textArea :label="'Notes'" :wrapclass="'h80 mb10'" placeHolder="Notes" v-model="order.notes"
                                :required="false" :fieldName="'notes'" :cid="'notes'"></textArea>
                        </div>


                    </div>
                </div>
            </template>
            <template #modal-footer>
                <button class="form-cancel" @click=" showAddUser = false">Cancel</button>
                <button class="primary_btn md" @click="addOrUpdateUser">{{ isUserEdit ? 'Update' : 'Submit' }}</button>
            </template>
        </b-modal>

        <!-- User Added Success Modal -->
        <b-modal v-model="showAddUserSuccess" id="success_model" dialog-class="success_model user_success" centered
            hide-header hide-footer>
            <template>
                <figure>
                    <img src="@/assets/images/success_mdl_img.png" />
                </figure>
                <h4 class="m-0">{{ isUserEdit ? 'Expense updated!' : 'Expense added!' }}</h4>
                <h7 class="m-0" style="padding-left:20px;padding-right:20px;text-align: center;">{{ successMsg }}</h7>
                <button class="primary_btn md" style="margin-top:14px ;"
                    @click=" showAddUserSuccess = false; page = 1; isListLoading = true; updateLoading(true); getExpenses()">OKAY</button>
            </template>
        </b-modal>

        <!-- Profile Modal -->
        <b-modal v-model="showProfile" id="profile_model" dialog-class="profile_model" centered hide-header hide-footer
            no-close-on-backdrop>
            <template>
                <div class="profile_header">
                    <!-- <div class="profile_icon">
               <img  v-if="checkProperty(selectedUser, 'details', 'profileURL')" :src=" checkProperty(selectedUser, 'details', 'profileURL') ">
              <img  v-else :src=" checkProperty(selectedUser, 'details', 'profileURL') "> 
             <figure><img src="@/assets/images/professors.svg"></figure> 
            </div> -->

                    <div class="profile_title">
                        <h6 v-if="checkProperty(selectedUser, 'name')">{{ checkProperty(selectedUser, 'name') }}</h6>
                        <p v-if="checkProperty(selectedUser, 'roleName')">{{ checkProperty(selectedUser, 'roleName') }}</p>
                        <span v-if="checkProperty(selectedUser, 'details', 'designation')">{{ checkProperty(selectedUser,
                            'details',
                            'designation') }}</span>
                    </div>
                    <a class="close" @click=" $bvModal.hide('profile_model')"></a>
                </div>
                <div class="profile_info">
                    <ul>
                        <li v-if="checkProperty(selectedUser, 'details', 'email')">
                            <span class="info_header">Email</span>
                            <p class="desc">{{ checkProperty(selectedUser, 'details', 'email') }}</p>
                        </li>
                        <li v-if="checkProperty(selectedUser, 'details', 'phone')">
                            <span class="info_header">Phone</span>
                            <p class="desc">
                                {{ checkProperty(selectedUser.details, 'phoneCountryCode', 'countryCallingCode') |
                                    countryFormatter }}
                                {{ checkProperty(selectedUser, 'details', 'phone') | formatPhone }}
                            </p>
                        </li>
                        <li v-if="checkProperty(selectedUser, 'details', 'userName')">
                            <span class="info_header">Username</span>
                            <p class="desc">{{ checkProperty(selectedUser, 'details', 'userName') }}</p>
                        </li>
                        <li v-if="checkProperty(selectedUser, 'departmentDetails', 'name')">
                            <span class="info_header">Department</span>
                            <p class="desc">{{ checkProperty(selectedUser, 'departmentDetails', 'name') }}</p>
                        </li>
                        <li v-if="checkProperty(selectedUser, 'details', 'profileURL')">
                            <span class="info_header">Profile URL</span>
                            <a href="#" class="link">{{ checkProperty(selectedUser, 'details', 'profileURL') }}</a>
                        </li>


                    </ul>
                </div>
            </template>
        </b-modal>



        <!-- active inactive Modal -->
        <b-modal v-model="showStatusChangePopup" id="active_inactive_model" dialog-class="active_inactive_model" centered
            no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">
                    {{ checkProperty(selectedUser, 'statusId') == 2 ? 'Inactivate' : 'Activate' }}
                </h6>
                <a class="close" @click=" $bvModal.hide('active_inactive_model')"></a>
            </template>
            <template>
                <p class="confirm_msg">Do you want to {{ checkProperty(selectedUser, 'statusId') == 2 ? 'Inactivate User' :
                    'Activate User' }}?</p>
            </template>
            <template #modal-footer>
                <button class="form-cancel" @click=" $bvModal.hide('active_inactive_model')">No</button>
                <button class="primary_btn" @click="changeStatus">Yes</button>
            </template>
        </b-modal>

        <b-modal id="preview_model" v-model="docPrivew" dialog-class="document_modal"
            :title="checkProperty(selectedFile, 'name')">
            <h2> <img :class="{
                pdf_view_download: docType == 'pdf',
                office_view_download: docType == 'office',
                image_view_download: docType == 'image',
            }" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>
            <div class="pdf_loader">
                <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/loader.gif" /></figure>

                <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
                <template v-if="docType == 'office'">
                    <div style="height:90vh">

                        <div id="placeholder" style="height:100%"></div>
                    </div>
                </template>
                <template v-else-if="docType == 'image'">
                    <img :src="docValue" />
                </template>
                <template v-else-if="docType == 'pdf'">
                    <div class="pdf" style="height:90vh">

                        <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%"
                            width="100%">

                        </iframe>
                    </div>
                </template>
            </div>
        </b-modal>

    </div>
</template>
  
<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import fileUpload from "@/views/forms/fileupload.vue";
import simpleSelect from '@/views/forms/simpleSelect.vue';
import dropdownHover from '@/views/forms/dropdownHover.vue';
import radioInput from "@/views/forms/radioInput.vue";
import textArea from "@/views/forms/textarea.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import phoneInput from "@/views/forms/phonenumber.vue";
import axios from 'axios';
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import NoDataFound from "@/views/common/noData.vue";
import moment from "moment";
import datepicker from '@/views/forms/datePicker.vue';
import DateRangePicker from "vue2-daterange-picker";
import 'vue2-daterange-picker/dist/vue2-daterange-picker.css'
import 'vue2-datepicker/index.css';

export default {
    name: 'dashboard-view',
    components: {
        searchInput,
        simpleSelect,
        dropdownHover,
        radioInput,
        simpleInput,
        fileUpload,
        fileUploadDrag,
        textArea,
        phoneInput,
        DocumentsPreview,
        NoDataFound,
        datepicker,
        DateRangePicker
    },
    data: () => ({
        showAddUser: false,
        showAddUserSuccess: false,
        showProfile: false,
        showStatusChangePopup: false,
        showPasswordChangePopup: false,
        isUserEdit: false,
        isListLoading: true,
        page: 1,
        perpage: 20,
        totalCount: 0,
        currentPage: 1,
        userRoles: [],
        departments: [],
        usersList: [],
        filterUserRolesList: [],
        filterStatusList: [],
        filterSelectedUserRoles: null,
        filterSelectedStatuses: null,
        filterSearch: '',
        topFiveDateRange: {
        startDate: null,
        endDate: null
        },
        order: {
            orderType: '',
            orderDate: '',
            createdBy: '',
            amount: '',
            createdOn: '',
            notes: ''
        },
        selectedUser: null,
        successMsg: '',
        password: '',
        conformPassword: '',
        showPassword: false,
        showCPassword: false,
        showDocuments: true,
        docType: '',
        formSubmited: false,
        docPrivew: false,
        docType: '',
        selectedFile: null,
    }),
    methods: {
        clearDateRange() {
      //alert()
        this.topFiveDateRange = {
            startDate: null,
            endDate: null
        }
        this.getTopEvaluations()
        },
        showAddUserPopup(isEdit = false) {
            this.isUserEdit = false
            this.expense = {
                natureOfExpense: '',
                transactionDate: '',
                paidTo: '',
                amount: '',
                paidFrom: '',
                paidBy: '',
                notes: ''
            }

            this.showAddUser = true
        },

        addOrUpdateUser() {
            this.$validator.validateAll().then((result) => {
                if (result) {
       
                    // let postData = _.cloneDeep(this.user)
                    let postData = {
                        "orderType": this.order.orderType.id,
                        "orderDate": this.order.orderDate,
                        "createdBy": this.order.createdBy,
                        "amount": this.order.amount,
                        "createdOn": this.order.createdOn,
                        "notes": this.order.notes,
                        "today": new Date(),
                    }

                    if (this.isUserEdit) {
                        postData['userId'] = this.selectedUser._id
                        this.$store
                            .dispatch("userUpdate", postData)
                            .then((response) => {
                                if (response.error) {
                                    this.showToster({ message: response.error.message, isError: true });
                                } else {
                                    this.successMsg = response.message
                                    this.showAddUser = false
                                    //this.showAddUserSuccess = true
                                    this.usersList = []
                                    this.showToster({ message: response.message, isError: false });
                                    this.isListLoading = true
                                    this.updateLoading(true);
                                    this.page = 1
                                    this.getExpenses()
                                }
                            })
                            .catch((error) => {
                                this.showToster({ message: error, isError: true });
                                this.loading = false;
                            });
                    } else {
                        this.$store
                            .dispatch("orderCreate", postData)
                            .then((response) => {
                                if (response.error) {
                                    this.showToster({ message: response.error.message, isError: true });
                                } else {
                                    this.successMsg = response.message
                                    this.showAddUser = false
                                    this.showAddUserSuccess = true
                                    //this.showToster({ message: response.message, isError: false });
                                    //  this.page = 1
                                    //  this.getExpenses()
                                }
                            })
                            .catch((error) => {
                                this.showToster({ message: error, isError: true });
                                this.loading = false;
                            });
                    }




                } else {

                }
            })
        },

        getExpenses() {
            this.isUserEdit = false
            let statusIds = []
            let roleIds = []
            if (this.filterSelectedStatuses && this.checkProperty(this.filterSelectedStatuses, 'length') > 0) {
                statusIds = this.filterSelectedStatuses.map((item) => item.id)
            }
            if (this.filterSelectedUserRoles && this.checkProperty(this.filterSelectedUserRoles, 'length') > 0) {
                roleIds = this.filterSelectedUserRoles.map((item) => item.id)
            }
            let postData =
            {
                "matcher": {
                    "title": this.filterSearch,
                    "searchString": this.filterSearch,
                    "statusList": [],
                    "createdByIds": [],
                    "createdDateRange": [],
                    "roleIds": roleIds,
                    "statusIds": statusIds,
                    "typeIds": [],
                    "departmentIds": []
                },
                "sorting":null,
                "getMasterData": false,// if Masterdata required
                "page": this.page,
                "perpage": this.perpage,
            }
             postData['restaurantId'] = localStorage.getItem('restaurantId');
            this.$store.dispatch("getCloverOrdersList", postData)
                .then((res) => {
                    this.isListLoading = false
                    this.updateLoading(false);
                    this.usersList = res.data.result.list
                    if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
                        this.totalCount = this.checkProperty(res.data.result, 'totalCount');
                    }
                    setTimeout(() => {
                        this.updateLoading(false);
                    })
                })
                .catch((error) => {
                    this.usersList = []
                    this.isListLoading = false
                    this.updateLoading(false);
                })
        },
        showProfilePopup(profileItem) {
            let postData =
            {
                "userId": profileItem._id
            }
            this.$store.dispatch("getUserDetails", postData)
                .then((res) => {
                    this.selectedUser = res.result
                    this.showProfile = true
                })
                .catch((error) => {

                })

        },
        editUser(profileItem) {

            let postData =
            {
                "userId": profileItem._id
            }
            this.$store.dispatch("getUserDetails", postData)
                .then((res) => {

                    this.selectedUser = res.result
                    this.expense = _.cloneDeep(this.selectedUser.details)
                    this.expense['userRole'] = _.find(this.userRoles, { "id": this.selectedUser['roleId'] });
                    this.expense['userDepartment'] = _.find(this.departments, { "id": this.selectedUser['details']['departmentId'] });

                    

                    setTimeout(() => {
                        this.isUserEdit = true
                        this.showAddUser = true
                    }, 100)
                })
                .catch((error) => {

                })
        },
        applyFilters() {
            this.usersList = []
            this.isListLoading = true
            this.updateLoading(true);
            this.page = 1
            this.getExpenses()
        },
        applySearchFilters() {
            this.usersList = []
            this.page = 1
            if (this.filterSearch && this.filterSearch.length > 2) {
                this.isListLoading = true
                this.updateLoading(true);
                this.getExpenses()
            }
            if (this.filterSearch == '') {
                this.isListLoading = true
                this.updateLoading(true);
                this.getExpenses()
            }
        },

        changeStatus() {

            this.showLoader = true;
            let payload = {
                "userId": "",
                "statusId": 2, // 3. Inactive, 4.Delete
                "statusName": ''
            }
            payload['userId'] = this.selectedUser['_id'];
            if ([2].indexOf(this.selectedUser.statusId) > -1) {
                payload['statusId'] = 3
                payload['statusName'] = 'Inactive'
            } else {
                payload['statusId'] = 2
                payload['statusName'] = 'Active'
            }
            this.$store.dispatch("commonAction", { data: payload, path: "users/manage-status", })
                .then((response) => {
                    this.showToster({ message: response.message, isError: false })
                    this.showLoader = false;
                    this.showStatusChangePopup = false;
                    this.applyFilters();

                }).catch((error) => {
                    this.showToster({ message: error.message, isError: true })
                    this.showLoader = false;
                    this.showStatusChangePopup = false

                });

        },

        getMasterDataList(category) {
            this.$store.dispatch("getMasterData", category)
                .then((res) => {

                    if (category == 'user_statuses') {
                        this.filterStatusList = [...res]
                    }
                })
        },

        getCurrentDate() {
            return moment().subtract(0, 'days')
        },
    },

    mounted() {

        this.$store.dispatch("getMasterData", 'order_type')
            .then((response) => {
                this.natureOfExpenseList = response;
            })

        this.isListLoading = true
        this.updateLoading(true);
        this.getExpenses()

        let document = {
            url: "",
            name: "",
        }
        this.user.documents.push(document)
    },
    computed: {

    },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>