<template>
    <div class="login_area">
        <div class="login_sec account_create">
            <h5>Create an account</h5>

            <!-- <label>Company Name*</label> -->
            <div class="input_group">
                <!-- <input type="text" class="form-control" placeholder="Company Name" name="companyName"
                    :data-vv-as="'Company Name'" v-validate="'required'" v-model="companyName"> -->
                <simpleInput :fieldName="'companyName'" :cid="'companyName'" :label="'Company Name'"
                    :placeHolder="'Company Name'" :vvas="'Company Name'" :display="true" :required="true"
                    v-model="companyName" :allowAlphNum="true" />
                <!-- <img src="@/assets/images/user.png" style="width: 16px;left: 14px;"> -->
                <!-- <p v-show="errors.has('companyName')" class="form-error">
                    {{ errors.first("companyName") }}
                </p> -->
            </div>

            <!-- <label>First Name*</label> -->
            <div class="input_group">
                <simpleInput :fieldName="'firstName'" :cid="'firstName'" :label="'First Name'" :placeHolder="'First Name'"
                    :vvas="'First Name'" :display="true" :required="true" v-model="firstName" :allowAlphNum="true" />
                <!-- <input type="text" class="form-control" placeholder="First Name" name="firstName" :data-vv-as="'First Name'"
                    v-validate="'required'" v-model="firstName"> -->
                <!-- <img src="@/assets/images/user.png" style="width: 16px;left: 14px;"> -->
                <!-- <p v-show="errors.has('firstName')" class="form-error">
                    {{ errors.first("firstName") }}
                </p> -->
            </div>

            <!-- <label>Last Name*</label> -->
            <div class="input_group">
                <simpleInput :fieldName="'lastName'" :cid="'lastName'" :label="'Last Name'" :placeHolder="'Last Name'"
                    :vvas="'Last Name'" :display="true" :required="true" v-model="lastName" :allowAlphNum="true" />
                <!-- <input type="text" class="form-control" placeholder="Last Name" name="lastName" :data-vv-as="'Last Name'"
                    v-validate="'required'" v-model="lastName"> -->
                <!-- <img src="@/assets/images/user.png" style="width: 16px;left: 14px;"> -->
                <!-- <p v-show="errors.has('lastName')" class="form-error">
                    {{ errors.first("lastName") }}
                </p> -->
            </div>


            <!-- <label>Email*</label> -->
            <div class="input_group">
                <simpleInput :fieldName="'email'" :cid="'email'" :label="'Email'" :placeHolder="'Email'" :vvas="'Email'"
                    :display="true" :required="true" v-model="email" :emailFormat="true" datatype="email" />

                <!-- <input type="text" class="form-control" placeholder="Ex: jacob@gmail.com" name="email" :data-vv-as="'Email'"
                    v-validate="'required'" v-model="email"> -->
                <!-- <img src="@/assets/images/email_img.svg"> -->
                <!-- <p v-show="errors.has('email')" class="form-error">
                    {{ errors.first("email") }}
                </p> -->
            </div>

            <!-- <label>Your Phone*</label> -->
            <div class="input_group">

                <phoneInput :display="true" @updatePhoneCountryCode="updatePhoneCountryCode"
                    :countrycode="phoneCountryCode.countryCode" cid="phoneNo" v-model="phoneNo" :fieldName="'phone'"
                    label="Phone Number (Optional)" placeHolder="Phone Number" />
                <!-- <input type="tel" class="form-control" placeholder="e.g. 999-999-99999" name="phoneno" :data-vv-as="'Phone'"
                    v-validate="'required'" v-model="phoneNo"> -->
                <!-- <img src="@/assets/images/telephone.png" style="width: 16px;left: 14px;"> -->
                <!-- <p v-show="errors.has('phoneno')" class="form-error">
                    {{ errors.first("phoneno") }}
                </p> -->
            </div>

            <!-- <label>Password*</label>
            <div class="input_group">
                <input type="password" class="form-control" placeholder="* * * * * * * *" name="password"
                    :data-vv-as="'Password'" v-validate="'required'" v-model="password">
                <img src="@/assets/images/lock.svg">
                <p v-show="errors.has('password')" class="form-error">
                    {{ errors.first("password") }}
                </p>
            </div> -->
            <button class="login_btn crt_btn" @click="submitForm">Creat Account</button>
            <p>Already an account? <a @click="gotoPage('/login')" class="create_link" data-bs-toggle="modal"
                    data-bs-target="#login_reg_modal">Log In</a></p>
        </div>
        <div class="guest_sec">
            <h6>Request an Evaluation as a Guest</h6>
            <a @click="gotoPage('/guest-request')" class="proceed_btn">Proceed</a>
        </div>

        <!-- Success Modal -->
        <b-modal id="success_model" dialog-class="success_model" centered hide-header hide-footer no-close-on-backdrop>
            <template>
                <figure>
                    <img src="@/assets/images/success_mdl_img.png" />
                </figure>
                <h5>You have registered for your account!</h5>
                <p>Check your email for your account activation link</p>
                <a class="primary_btn" @click="gotoPage('/guest-request')">Request an Evaluation</a>
            </template>
        </b-modal>

        
    </div>
</template>
<script>

import simpleInput from "@/views/forms/simpleInput.vue";
import phoneInput from "@/views/forms/phonenumber.vue";


export default {
    name: "CreateAccountView",
    provide() {
        return {

        };
    },
    components: {
        simpleInput,
        phoneInput,
    },
    methods: {
        updatePhoneCountryCode(data) {
            this.phoneCountryCode = data;
        },
        submitForm() {
            // this.gotoPage('/dashboard')

            this.errorCode = '';
            Object.assign(this.formerrors, {
                msg: "",
            });
            Object.assign(this.formmessage, {
                msg: "",
            });
            this.$validator.validateAll().then((result) => {
                if (result) {

                    let postData =
                    {
                        "companyName": this.companyName,
                        "name": this.firstName + " " + this.lastName,
                        "email": this.email,
                        "firstName": this.firstName,
                        "lastName": this.lastName,
                        "phone": this.phoneNo,
                        "phoneCountryCode": this.phoneCountryCode,
                        "authRequired": false
                        //   "password": this.password
                    }


                    this.$store.dispatch("signupCustomer", postData)
                        .then((response) => {
                            if (response.error) {
                                (response.error)
                                Object.assign(this.formerrors, {
                                    msg: response.error.result
                                });
                            } else {
                                this.showToster({ message: response.message, isError: false });
                                this.rememberMe("", "");
                                this.$router.push("/login");
                            }
                        })
                        .catch((error) => {
                            this.showAddcustomer = true
                            this.showToster({ message: error, isError: true });
                        })
                    // $bvModal.show('success_model')
                } else {
                    this.loadingLogin = false;
                    // form have errors
                }
            });
        },
        gotoPage(path = "/") {
            this.$router.push(path);
        },

        rememberMe(username = "", pwd = "") {
            this.setCookie("server_Js", "", 7);
        },
        setCookie(cname = "", cvalue = "", exdays = 1) {
            const d = new Date();
            d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
            let expires = "expires=" + d.toUTCString();
            document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
        },
    },
    data: () => ({
        showForgotPassword: false,
        showPassword: false,
        companyName: "",
        email: "",
        password: "",
        firstName: "",
        lastName: "",
        phoneNo: "",
        phoneCountryCode: {
            countryCode: 'US',
            countryCallingCode: ''
        },
        formmessage: {
            msg: "",
        },
        formerrors: {
            msg: "",
        },
    }),

    computed: {
        cookiesAccepted() {
            // Check if the cookiesAccepted cookie is set
            return document.cookie.includes('cookiesAccepted=true');
        },
    },

    provide() {
        return {
            parentValidator: this.$validator,
        };
    }
};
</script>