<template>
  <div class="db_page">
    <!-- <div class="page_header">
      <h3>Users</h3>
    </div> -->
    <div class="filter_sec filter_sec_v2">
      <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" :wrapclass="'me-0'" />
      <!-- <simpleSelect :multiple="true" :wrapclass="'req_status'" :optionslist="filterUserRolesList" :display="true"
        :place-holder="'User Type'" :searchable="false" :required="false" :close-on-select="false" :clear-on-select="true"
        v-model="filterSelectedUserRoles" :fieldName="'filterUserType'" :cid="'filterUserType'" :hideSelected="true"
        @input="applyFilters" />
      <simpleSelect :multiple="true" :wrapclass="'req_status'" :optionslist="filterStatusList" :display="true"
        :place-holder="'Status'" :searchable="false" :required="false" :close-on-select="false" :clear-on-select="true"
        v-model="filterSelectedStatuses" :fieldName="'filterStatuses'" :cid="'filterStatuses'" :hideSelected="true"
        @input="applyFilters" />                  -->

      <button class="filter_btn" v-if="false"><span></span><em>Filters</em></button>
      <div class="filters_right" v-if="canCreateUser(getUserRoleId)">

        <button class="add_btn" @click="showAddResPopup()"><span></span><em>Add Restaurant</em></button>
      </div>
    </div>


        <ul class="custome_tabs">
          <li @click="gotoPage('/userdetails')">Users</li>
          <li class="active" >Restaurants</li>
        </ul>

 <table class="table user_table" v-if="false && checkProperty(usersList, 'length') > 0 && !isListLoading">
            <thead>
              <tr>
                <th>Name</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in    restaurantsList" v-bind:key="index">
               
                <td><span class="first_name">{{ checkProperty(item, 'name') ? item.name : '' }}</span> 
                    
                    </td>
              </tr>

            </tbody>
          </table>

          <div class="mobile_table_list">
            <template v-if="checkProperty(restaurantsList, 'length') <= 0">
              <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users' :loading="isListLoading" />
            </template>
            <ul v-if="checkProperty(restaurantsList, 'length') > 0 && !isListLoading">
                <li v-for="(item, index) in restaurantsList " v-bind:key="index">
                    <div class="list_row">
                        <div>
                            <span class="list_heading">{{ checkProperty(item, 'name') ? item.name : '' }}</span>
                        </div>
                    </div>
                </li>
            </ul>
        </div>

    
   
  <b-modal id="createrestaurant_model" dialog-class="adduser_model" centered no-close-on-backdrop>
      <template #modal-header>
        <h6 class="modal-title">Create Restaurant</h6>
        <a class="close" @click="$bvModal.hide('createrestaurant_model')"></a>
      </template>
      <template>

        <div class="form_info">
          <div class="col-md-12">
            <simpleInput :wrapclass="'mb20'" :fieldName="'restaurantName'" :cid="'restaurantName'"
              :label="'Restaurant Name'" :placeHolder="'Restaurant Name'" :vvas="'Restaurant Name'" :display="true"
              :required="true" v-model="restaurantName" />
            <!-- <simpleInput :wrapclass="'mb20'" :label="'First Name'" /> -->
          </div>
        </div>
      </template>
      <template #modal-footer>
        <button class="form-cancel" @click="$bvModal.hide('createrestaurant_model')">Cancel</button>
        <button class="primary_btn md" @click="addRestaurant">Submit</button>
      </template>
    </b-modal>
  </div>
</template>

<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import fileUpload from "@/views/forms/fileupload.vue";
import simpleSelect from '@/views/forms/simpleSelect.vue';
import dropdownHover from '@/views/forms/dropdownHover.vue';
import radioInput from "@/views/forms/radioInput.vue";
import textArea from "@/views/forms/textarea.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import phoneInput from "@/views/forms/phonenumber.vue";
import axios from 'axios';
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import NoDataFound from "@/views/common/noData.vue";

export default {
  name: 'dashboard-view',
  components: {
    searchInput,
    simpleSelect,
    dropdownHover,
    radioInput,
    simpleInput,
    fileUpload,
    fileUploadDrag,
    textArea,
    phoneInput,
    DocumentsPreview,
    NoDataFound
  },
  data: () => ({
    restaurantName:'',
    showAddUser: false,
    showAddUserSuccess: false,
    showProfile: false,
    showStatusChangePopup: false,
    showPasswordChangePopup: false,
    isUserEdit: false,
    isListLoading: true,
    page: 1,
    perpage: 20,
    totalCount: 0,
    currentPage: 1,
    userRoles: [],
    departments: [],
    usersList: [],
    filterUserRolesList: [],
    filterStatusList: [],
    filterSelectedUserRoles: null,
    filterSelectedStatuses: null,
    filterSearch: '',
    user: {
      designation: '',
      profileURL: "",
      name: "",
      firstName: '',
      lastName: '',
      email: '',
      userName: '',
      phone: null,
      phoneCountryCode: {
        countryCode: '',
        countryCallingCode: ''
      },
      userRole: null,
      userDepartment: '',
      documents: [],
      bioAndResume: '',
      letterHead: [],
      restaurants: null,
    },
    selectedUser: null,
    successMsg: '',
    password: '',
    conformPassword: '',
    showPassword: false,
    showCPassword: false,
    showDocuments: true,
    docType: '',
    formSubmited: false,
    docPrivew: false,
    docType: '',
    selectedFile: null,
    restaurantsList: [],
  }),
  methods: {
    
    addRestaurant() {
      this.$validator.validateAll().then((result) => {
        if (result) {

          let postData = {
            "name": this.restaurantName,
          }
          this.$store
            .dispatch("addRestaurant", postData)
            .then((response) => {

              if (response.error) {
                this.showToster({ message: response.error.message, isError: true });
              } else {
                  this.getRestaurantList();
                this.showToster({ message: "Restaurant created successfully", isError: false });
                this.$bvModal.hide('createrestaurant_model')
              }
            })
            .catch((error) => {
              this.showToster({ message: error, isError: true });
              this.loading = false;
            });
        }
      })
    },
    gotoPage(path = "/") {
      this.$router.push(path);
    },
    updatePhoneCountryCode(data) {
      // alert(JSON.stringify(data))
      this.user.phoneCountryCode = data;

    },

    updateRole(data) {
      // alert(JSON.stringify(data))
      this.user['userRole'] = data
      this.user = _.cloneDeep(this.user)
    },

    showAddResPopup() {
      this.restaurantName = '';
       this.$bvModal.show('createrestaurant_model')
    },

    addOrUpdateUser() {
      this.$validator.validateAll().then((result) => {
        if (result) {

          // let postData = _.cloneDeep(this.user)
          let postData = {
            "name": this.user.firstName + " " + this.user.lastName,
            "email": this.user.email,
            "roleId": this.user.userRole.id,
            "firstName": this.user.firstName,
            "middleName": "",
            "lastName": this.user.lastName,
            "userName": this.user.userName.trim(),
            "phone": this.user.phone,
            "phoneCountryCode": this.user.phoneCountryCode,
            "userType": this.user.userRole.id,

          }
          if (this.user.restaurants && this.checkProperty(this.user.restaurants, 'length') > 0) {
            let restaurantIds = this.user.restaurants.map((item) => item['_id'])
            Object.assign(postData, { restaurantIds: restaurantIds });
          }

          if (this.isUserEdit) {
            postData['userId'] = this.selectedUser._id
            this.$store
              .dispatch("userUpdate", postData)
              .then((response) => {
                if (response.error) {
                  this.showToster({ message: response.error.message, isError: true });
                } else {
                  this.successMsg = response.message
                  this.showAddUser = false
                  //this.showAddUserSuccess = true
                  this.usersList = []
                  this.showToster({ message: response.message, isError: false });
                  this.isListLoading = true
                  this.updateLoading(true);
                  this.page = 1
                  this.getUsers()
                }
              })
              .catch((error) => {
                this.showToster({ message: error, isError: true });
                this.loading = false;
              });
          } else {
            this.$store
              .dispatch("userregister", postData)
              .then((response) => {
                if (response.error) {
                  this.showToster({ message: response.error.message, isError: true });
                } else {
                  this.successMsg = response.message
                  this.showAddUser = false
                  this.showAddUserSuccess = true
                  //this.showToster({ message: response.message, isError: false });
                  //  this.page = 1
                  //  this.getUsers()
                }
              })
              .catch((error) => {
                this.showToster({ message: error, isError: true });
                this.loading = false;
              });
          }




        } else {

        }
      })
    },
    onFileUpload(event) {

    },
    addNewDocument() {
      let document = {
        url: "",
        name: "",
      }
      this.user.documents.push(null)
    },
    showModal(modelRef, Item) {
      this.showLoader = false;
      this.$refs[modelRef].show();
      this.$validator.reset();
    },
    hideModal(modelId) {
      $bvModal(modelId).hide();
      this.showLoader = false;
    },
    getUsers() {
      this.isUserEdit = false
      let statusIds = []
      let roleIds = []
      if (this.filterSelectedStatuses && this.checkProperty(this.filterSelectedStatuses, 'length') > 0) {
        statusIds = this.filterSelectedStatuses.map((item) => item.id)
      }
      if (this.filterSelectedUserRoles && this.checkProperty(this.filterSelectedUserRoles, 'length') > 0) {
        roleIds = this.filterSelectedUserRoles.map((item) => item.id)
      }
      let postData =
      {
        "matcher": {
          "title": this.filterSearch,
          "searchString": this.filterSearch,
          "statusList": [],
          "createdByIds": [],
          "createdDateRange": [],
          "roleIds": roleIds,
          "statusIds": statusIds,
          "typeIds": [],
          "departmentIds": []
        },
        "sorting": {
          "path": "createdOn",
          "order": -1
        },
        "getMasterData": false,// if Masterdata required
        "page": this.page,
        "perpage": this.perpage,
      }
      this.$store.dispatch("getUsersList", postData)
        .then((res) => {
          this.isListLoading = false
          this.updateLoading(false);
          this.usersList = res.data.result.list
          if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
            this.totalCount = this.checkProperty(res.data.result, 'totalCount');
          }
          setTimeout(() => {
            this.updateLoading(false);
          })
        })
        .catch((error) => {
          this.usersList = []
          this.isListLoading = false
          this.updateLoading(false);
        })
    },
    showProfilePopup(profileItem) {
      let postData =
      {
        "userId": profileItem._id
      }
      this.$store.dispatch("getUserDetails", postData)
        .then((res) => {
          this.selectedUser = res.result
          this.showProfile = true
        })
        .catch((error) => {

        })

    },
    editUser(profileItem) {

      let postData =
      {
        "userId": profileItem._id
      }
      this.$store.dispatch("getUserDetails", postData)
        .then((res) => {

          this.selectedUser = res.result
          this.user = _.cloneDeep(this.selectedUser.details)
          this.user['userRole'] = _.find(this.userRoles, { "id": this.selectedUser['roleId'] });
          this.user['userDepartment'] = _.find(this.departments, { "id": this.selectedUser['details']['departmentId'] });

          if (this.checkProperty(this.selectedUser, 'details', 'documents')
            && this.checkProperty(this.selectedUser.details, 'documents', 'length') > 0) {
            let finalDocuments = []
            let existingDocs = this.checkProperty(this.selectedUser, 'details', 'documents')
            _.forEach(existingDocs, (item) => {
              let documents = []
              documents.push(item)
              finalDocuments.push(documents)
            });
            this.user.documents = finalDocuments

          } else {
            this.user.documents = []
          }

          setTimeout(() => {
            this.isUserEdit = true
            this.showAddUser = true
          }, 100)
        })
        .catch((error) => {

        })
    },
    applyFilters() {
      this.usersList = []
      this.isListLoading = true
      this.updateLoading(true);
      this.page = 1
      this.getUsers()
    },
    applySearchFilters() {
      this.usersList = []
      this.page = 1
      if (this.filterSearch && this.filterSearch.length > 2) {
        this.isListLoading = true
        this.updateLoading(true);
        this.getUsers()
      }
      if (this.filterSearch == '') {
        this.isListLoading = true
        this.updateLoading(true);
        this.getUsers()
      }
    },
    updatePassword() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          this.showLoader = true;
          //  set-password
          let path = "auth/change-password";
          if (this.checkProperty(this.selectedUser, 'passwordUpdated')) {
            path = "auth/change-password";
          }
          let postData = {
            newPassword: this.password.trim(),
            currentPassword: this.conformPassword.trim(),
            'userId': this.selectedUser['_id']
          };
          this.$store.dispatch("commonAction", { data: postData, path: path, })
            .then((response) => {
              this.showToster({ message: response.message, isError: false })
              this.showLoader = false;
              this.showPasswordChangePopup = false
              this.applyFilters();

            }).catch((error) => {
              // alert(JSON.stringify(error.message))
              this.showToster({ message: error.message, isError: true })
              this.showLoader = false;
              // this.showPasswordChangePopup = false
            });

        }
      })
    },
    changeStatus() {

      this.showLoader = true;
      let payload = {
        "userId": "",
        "statusId": 2, // 3. Inactive, 4.Delete
        "statusName": ''
      }
      payload['userId'] = this.selectedUser['_id'];
      if ([2].indexOf(this.selectedUser.statusId) > -1) {
        payload['statusId'] = 3
        payload['statusName'] = 'Inactive'
      } else {
        payload['statusId'] = 2
        payload['statusName'] = 'Active'
      }
      this.$store.dispatch("commonAction", { data: payload, path: "users/manage-status", })
        .then((response) => {
          this.showToster({ message: response.message, isError: false })
          this.showLoader = false;
          this.showStatusChangePopup = false;
          this.applyFilters();

        }).catch((error) => {
          this.showToster({ message: error.message, isError: true })
          this.showLoader = false;
          this.showStatusChangePopup = false

        });

    },
    removeDocument(index = -1) {
      if (index > -1 && this.checkProperty(this.user, 'documents', 'length') > 1) {
        this.showDocuments = false
        // if (this.user.documents[0] && this.user.documents[0].length > 0) {
        //   this.user.documents[0].splice(0, 1);
        // }
        this.user.documents.splice(index, 1);
        setTimeout(() => {
          this.showDocuments = true
        }, 0)
      }
    },
    getMasterDataList(category) {
      this.$store.dispatch("getMasterData", category)
        .then((res) => {

          if (category == 'user_statuses') {
            this.filterStatusList = [...res]
          }
        })
    },
    download_or_view(docItem) {


      let value = _.cloneDeep(docItem);
      // if (this.checkProperty(this.getPetitionDetails, 'caseNo') && this.checkProperty(value, 'name')) {
      //   let docName = _.cloneDeep(value['name']);
      //   value['name'] = this.checkProperty(this.getPetitionDetails, 'caseNo') + "_" + docName;
      // }


      var _self = this;
      this.formSubmited = false;
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }
      // value = Object.assign(value, { 'petitionId': this.petition['_id'] })
      // value = Object.assign(value, { 'subTypeDetails': this.petition['subTypeDetails'] })


      this.selectedFile = value;
      this.docValue = "";
      this.docPrivew = false;
      this.docType = false;
      this.docType = this.findmsDoctype(value["name"], value.mimetype);

      if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
        //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
          // "petitionId": value['petitionId'],

          // entityType:value['petitionId']
          "fileName": value.name ? value.name : ''
        };
        // if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
        //   postdata['entityType'] = 'perm'
        // } else {
        //   postdata['entityType'] = 'case'
        // }


        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;


          if (this.docType == "office") {
            this.docPrivew = true;
            setTimeout(() => {
              document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
              let _editing = false;

              // if ([3, 4].indexOf(this.getUserRoleId) > -1) {
              //   _editing = false;
              // }

              // if (value.viewmode) {
              //   _editing = false;
              // }
              var _ob = {}
              // if (value.editedDocument) {
              //   _ob = {

              //     evaluationId: this.evaluationDetails._id,
              //     name: value.name,
              //     _id: value._id,
              //     "extn": "docx",
              //     "formLetterType": "Letter",
              //     parentId: value.parentId
              //   }

              // } else {

              _ob = {

                name: value.name,
                evaluationId: this.evaluationDetails._id,
                _id: value._id,
                "extn": "docx",
                "formLetterType": "Letter",
                parentId: value._id

              }

              //  }


              window.docEditor = new DocsAPI.DocEditor("placeholder2",
                {

                  "document": {
                    "c": "forcesave",
                    "fileType": "docx",
                    "key": value._id,
                    "userdata": JSON.stringify(_ob),
                    "title": value.name,
                    "url": response.data.result.data,
                    permissions: {
                      edit: _editing,
                      download: true,
                      reader: false,
                      review: false,
                      comment: false
                    }
                  },

                  "documentType": "word",
                  "height": "100%",
                  "width": "100%",

                  "editorConfig": {
                    "userdata": JSON.stringify(_ob),
                    "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                    "customization": {
                      "logo": {
                        "image": "https://immibox.com/app/favicon.png",
                        "imageDark": "https://immibox.com/app/favicon.png",
                        "url": "https://immibox.com"
                      },
                      "anonymous": {
                        "request": false,
                        "label": "Guest"
                      },
                      "chat": false,
                      "comments": false,
                      "compactHeader": false,
                      "compactToolbar": true,
                      "compatibleFeatures": false,
                      "feedback": {
                        "visible": false
                      },
                      "forcesave": true,
                      "help": false,
                      "hideNotes": true,
                      "hideRightMenu": true,
                      "hideRulers": true,
                      layout: {
                        toolbar: {
                          "collaboration": false,
                        },
                      },
                      "macros": false,
                      "macrosMode": "warn",
                      "mentionShare": false,
                      "plugins": false,
                      "spellcheck": false,
                      "toolbarHideFileName": true,
                      "toolbarNoTabs": true,
                      "uiTheme": "theme-light",
                      "unit": "cm",
                      "zoom": 100
                    },
                  }, events: {
                    onReady: function () {

                    },
                    onDocumentStateChange: function (event) {
                      var url = event.data;
                      console.log(event)

                      if (!event.data) {

                        if (value.editedDocument) {

                        }

                      }
                    }

                  }
                });
              //this.docValue = encodeURIComponent(response.data.result.data);
            }, 100)
          }

          if (this.docType == "pdf") {

            // this.downloadFile(this.docValue, value.mimetype, value.name)

            // return
            var _vid = value._id;
            if (value.parentId) {
              _vid = value.parentId;
            }
            var viewmode = 1; // Enable edit
            viewmode = 0; //Disabled Edit
            if (value.viewmode) {
              viewmode = 0;
            }
            this.docValue = "https://beta.carnegieevaluations.com/viewer/pdfjs-dist/web/viewer.html?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
            console.log(this.docValue)
            this.docPrivew = true;
          }
          if (this.docType == "image") {
            this.docPrivew = true;
          }



        });
      } else {



        this.downloads3file(value);
      }

    },
    sendPasswordLink(selectedUser) {
      this.showLoader = true;
      let payload = {
        "userName": this.checkProperty(selectedUser, 'userName'),
      }
      this.$store.dispatch("commonAction", { data: payload, path: "users/resend-verify-link", })
        .then((response) => {
          this.showToster({ message: response.message, isError: false })
          this.showLoader = false;
          // this.showStatusChangePopup = false;
          // this.applyFilters();

        }).catch((error) => {
          this.showToster({ message: error.message, isError: true })
          this.showLoader = false;
          this.showStatusChangePopup = false

        });

    },
    getRestaurantList(category) {
      this.$store.dispatch("getRestaurantList", category)
        .then((res) => {
          console.log('res', res.list)
          this.restaurantsList = res.list
        })
    },
  },

  mounted() {
    this.getMasterDataList('user_statuses')
    this.getRestaurantList()
    this.$store.dispatch("getMasterData", 'user_roles')
      .then((res) => {
        this.userRoles = _.filter(res, (item) => {
          if ([51, 50, 1, 2, 15].indexOf(item.id) <= -1) {
            return item.id;
          }
        });
        this.filterUserRolesList = _.filter(res, (item) => {
          if ([51, 50, 1, 2, 15].indexOf(item.id) <= -1) {
            return item.id;
          }
        });
      })

    this.$store
      .dispatch("getDepartments")
      .then((response) => {
        this.departments = response;
      })
      .catch(() => {
        this.loading = false;
      });

    this.isListLoading = true
    this.updateLoading(true);
    this.getUsers()

    let document = {
      url: "",
      name: "",
    }
    this.user.documents.push(document)
  },
  computed: {

  },
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
}
</script>