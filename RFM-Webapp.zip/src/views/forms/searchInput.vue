<template>
    <div class="search_area">
        <input type="text" class="form-control" :placeholder="placeHolder" v-model="value" v-on="listeners" >
        <img src="@/assets/images/search.svg" class="search_icon" alt="search">
    </div>
</template>
<script>
export default {
    name: 'search-input',
    props: {
        placeHolder: {
            type: String,
            default: null,
        },
        value: null,       
    },
    computed: {
            listeners() {
                return {
                    ...this.$listeners,
                    input: (evt) => {
                        this.$emit('input', evt.target.value)
                    },
                    focus: (evt) => {
                        this.$emit('focus', evt)
                        // this.changeFocus(true)
                    },
                    blur: (evt) => {
                        this.$emit('blur', evt)
                        //this.changeFocus(false)
                    }
                }
            },

        }
}
</script>