<template>
  <div class="row" v-if="countries && countries.length > 0">
    <div class="col-md-6" v-if="showLane1">
      <div class="form_group mb20" :class="wrapclass">
        <label class="form_label">Street Address<em v-if="validationRequired">*</em></label>
        <input  class="form-control" :name="'line1' + cid"
                v-model="value.line1"
                data-vv-as="Street Address"
                :label="'Street Address' + ((validationRequired) ? '*' : '')"
                v-validate="{ required: validationRequired}"  />
                <span
                class="form-error"
                v-show="
                  errors.has(
                    (formscope != '' ? formscope + '.' : '') + 'line1' + cid
                  )
                "
                >{{
                  errors.first(
                    (formscope != "" ? formscope + "." : "") + "line1" + cid
                  )
                }}</span
              >
      </div>
    </div>
    <div class="col-md-6" v-if="showLane2">
      <div class="form_group mb20" :class="wrapclass">
        <label class="form_label">Apt, Suite<em v-if="validationRequired"></em></label>
        <template v-if="showaptType">
          <div class="address-suite" :class="{'address-suite-start': !showAPTCheckBox}">
            <ul>
              <li v-if="showAPTCheckBox">
                <div class="input_group">
                  <input type="checkbox" :id="'Apt'"
                  name="aptType1"
                  v-model="aptType1"
                  @change="setaptType($event, 'APT')">
                  <label :for="'Apt'" class="check_btn">
                      <div class="check"></div>
                      <span>Apt</span>
                  </label>
                </div>
              </li>
              <li>
                <div class="input_group">
                  <input type="checkbox" :id="'Ste'"
                  name="aptType2"
                  @change="setaptType($event, 'STE')"
                  v-model="aptType2">
                  <label :for="'Ste'" class="check_btn">
                      <div class="check"></div>
                      <span>Ste</span>
                  </label>
                </div>
              </li>
              <li>
                <div class="input_group">
                  <input type="checkbox" :id="'Flr'"
                  name="aptType3"
                  @change="setaptType($event, 'FLR')"
                  v-model="aptType3">
                  <label :for="'Flr'" class="check_btn">
                      <div class="check"></div>
                      <span>Flr</span>
                  </label>
                </div>
              </li>
            </ul>
            <input  class="form-control" :name="'line2' + cid"
              v-model="value.line2"
              data-vv-as="Apt, Suite">
          </div>
        </template>
        <template v-else>
          <input  class="form-control" :name="'line2' + cid"
              v-model="value.line2"
              data-vv-as="Apt, Suite">
        </template>
      </div>
    </div>
    <div class="col-md-6" v-if="showCountry">
      <div class="form_group mb20" :class="wrapclass">
        <label v-if="!placeOnly" class="form_label"
          >Country<em v-if="validationRequired">*</em></label
        >
        <label v-if="placeOnly" class="form_label">{{
          placeOnlyTitle
        }}</label>
        <div class="form_select">
          <multiselect
            @input="
              locations = [];
              states = [];
            "
            :name="'country' + cid"
            v-model="value.countryDetails"
            :show-labels="false"
            track-by="id"
            label="name"
            :ref="'refcountry' + cid"
            data-vv-as="Country"
            placeHolder="Select Country"
            :options="countrieslist"
            :searchable="true"
            :allow-empty="false"
            :disabled="loading|| disableCountry"
            v-validate="{ required: validationRequired }"
          > 
            <span slot="noResult">No Country Found</span>
          </multiselect>
        </div>
         <span
                class="text-danger text-sm"
                v-show="
                  errors.has(
                    (formscope != '' ? formscope + '.' : '') + 'Country' + cid
                  )
                "
                >{{
                  errors.first(
                    (formscope != "" ? formscope + "." : "") + "Country" + cid
                  )
                }}</span
              >
      </div>
    </div>
    <div class="col-md-6" v-if="showState">
      <div class="form_group mb20" :class="wrapclass">
        <label v-if="!placeOnly" class="form_label"
          >State<em v-if="validationRequired">*</em></label
        >
        <label v-if="placeOnly" class="form_label"></label>
        <div class="form_select">
          <multiselect
            @input="locations = []"
            :name="'state' + cid"
            v-model="value.stateDetails"
            :disabled="loading || states.length == 0"
            :show-labels="false"
            track-by="id"
            label="name"
            data-vv-as="State"
            placeholder="Select State"
            :options="states"
            :searchable="true"
            :allow-empty="false"
            v-validate="{
              required: validationRequired && states.length > 0,
            }"
          >
            <span slot="noResult">No State Found</span>
          </multiselect>
        </div>
        
        <span
                class="form-error"
                v-show="
                  errors.has(
                    (formscope != '' ? formscope + '.' : '') + 'state' + cid
                  )
                "
                >{{
                  errors.first(
                    (formscope != "" ? formscope + "." : "") + "state" + cid
                  )
                }}</span
              >
      </div>
    </div>
    <div class="col-md-6" v-if="showCity">
      <div class="form_group mb20" :class="wrapclass">
        <label v-if="!placeOnly" class="form_label"
          >City<em v-if="validationRequired">*</em></label
        >
        <label v-if="placeOnly" class="form_label"></label>
        <div class="form_select">
          <multiselect
              :name="'location' + cid"
              v-model="value.locationDetails"
              :disabled="loading"
              :show-labels="false"
              track-by="id"
              label="name"
              data-vv-as="City"
              tag-placeholder="Add"
              :taggable="checkProperty(value ,'stateDetails' ,'id')!=''"
              @tag="addLocation"
              placeholder="Select City"
              :options="locations"
              :searchable="true"
              :allow-empty="false"
              v-validate="{
                required: validationRequired && locations.length > 0,
              }"
            >
            <span slot="noResult">No Locations Found</span>
          </multiselect>
        </div>
        <span
                class="form-error"
                v-show="
                  errors.has(
                    (formscope != '' ? formscope + '.' : '') + 'location' + cid
                  )
                "
                >{{
                  errors.first(
                    (formscope != "" ? formscope + "." : "") + "location" + cid
                  )
                }}</span
              >
      </div>
    </div>
    <div class="col-md-6" v-if="showZip">
      <div class="form_group mb20" :class="wrapclass">
        <label class="form_label">Zip Code<em v-if="validationRequired">*</em></label>
        <input
          v-if="validationRequired"
          :name="'zipcode' + cid"
          v-model="value.zipcode"
          v-validate="'required|numeric|zipcodev:refcountry' + cid"
          class="form-control"
          data-vv-as="Zip Code"
        />
        <input
          v-else
          :name="'zipcode' + cid"
          v-model="value.zipcode"
          v-validate="'numeric|zipcodev:refcountry' + cid"
          class="form-control"
          data-vv-as="Zip Code"
        
        /> 
        <span
                class="form-error"
                v-show="
                  errors.has(
                    (formscope != '' ? formscope + '.' : '') + 'zipcode' + cid
                  )
                "
                >{{
                  errors.first(
                    (formscope != "" ? formscope + "." : "") + "zipcode" + cid
                  )
                }}</span
              >
      </div>
    </div>
  </div>
</template>
  
  <script>
  import _ from "lodash";
  import multiselect from "vue-multiselect-inv";
  export default {
    inject: ["parentValidator"],
    components: {
            multiselect,
        },
    props: {
      wrapclass: {
        type: String,
        default: "",
      },
      fieldsArray: Array,
      fieldName: {
        type: String,
        default: null,
      },
      value: Object,
      hideusa: {
        type: Boolean,
        default: false,
      },
      showLane1: {
        type: Boolean,
        default: true,
      },
      showLane2: {
        type: Boolean,
        default: true,
      },
      showCountry: {
        type: Boolean,
        default: true,
      },
      showState: {
        type: Boolean,
        default: true,
      },
      showCity: {
        type: Boolean,
        default: true,
      },
      showZip: {
        type: Boolean,
        default: true,
      },
  
      formscope: {
        type: String,
        default: "",
      },
      disableCountry: {
        type: Boolean,
        default: false,
      },
      showaptType: {
        type: Boolean,
        default: true,
      },
      
      isCap: {
        type: Boolean,
        default: false,
      },
      validationRequired: {
        type: Boolean,
        default: false,
      },
      addFormContainerCls: {
        type: Boolean,
        default: true,
      },
      countries: Array,
      address: Object,
      cid: {
        type: String,
        default: "",
      },
      placeOnly: {
        type: Boolean,
        default: false,
      }, 
      showAPTCheckBox: {
        type: Boolean,
        default: true,
      },
      placeOnlyTitle: String,
    },
  
    data() {
      return {
        mounted: false,
        loading: false,
        states: [],
        locations: [],
        aptType1: false,
        aptType2: false,
        aptType3: false,
        countrieslist: [],
      };
    },
    created() {
      this.$validator = this.parentValidator;
    },
    mounted() {
      setTimeout(() => {
        this.init();
      });
    },
    methods: {
      applyWatchers() {
        this.loading = false;
        this.$watch("value.aptType", function () {
        
          this.aptType1 = false;
          this.aptType2 = false;
          this.aptType3 = false;
          if(this.value.aptType == 'APT'){
            this.aptType1= true;
        }
        if(this.value.aptType == 'STE'){
          this.aptType2= true;
  
        }
        if(this.value.aptType == 'FLR'){
          this.aptType3= true;
  
        }
  
  
        });
        this.$watch("value.countryDetails", function () {
          this.value.countryId = this.value.countryDetails.id;
          this.loadStatesByCountryId(!this.mounted);
        });
        this.$watch("value.stateDetails", function () {
          this.value.stateId = this.value.stateDetails.id;
          this.loadCitiesByStateId(!this.mounted);
        });
        this.$watch("value.locationDetails", function () {
          this.value.locationId = this.value.locationDetails.id;
        });
      },
      setaptType(e, val) {
        if (e.target.name == "aptType1") {
          this.aptType2 = false;
          this.aptType3 = false;
        }
        if (e.target.name == "aptType2") {
          this.aptType1 = false;
          this.aptType3 = false;
        }
        if (e.target.name == "aptType3") {
          this.aptType1 = false;
          this.aptType2 = false;
        }
        if (e.target.checked) {
          this.value.aptType = val;
        } else {
          this.value.aptType = "";
        }
      },
      loadStatesByCountryId(firstLoad = false) {
        this.loading = true;
        let countryId = this.value.countryId;
        if (this.value.countryDetails && this.value.countryDetails.id) {
          countryId = this.value.countryDetails.id;
        }
        if (firstLoad) {
          this.mounted = true;
        }
        if (!countryId) {
          countryId = -1;
        }
        this.$store
          .dispatch("getstates", countryId)
          .then((response) => {
            this.states = response;
            this.loading = false;
  
            var stateId = this.value.stateId;
            if (stateId != null) {
              var item = _.find(this.states, function (item) {
                return item.id == stateId;
              });
  
              if (!item) {
                this.value.stateId = null;
                this.value.stateDetails = null;
                this.value.locationId = null;
                this.value.locationDetails = null;
              }
            }
            if (firstLoad) {
              if (this.checkProperty(this.value, 'stateId')) {
              this.loadCitiesByStateId(true)
            }else{
              this.applyWatchers()
            }
            }
          })
          .catch(() => {
            this.loading = false;
          });
      },
      loadCitiesByStateId(firstLoad = false) {
        this.loading = true;
  
        let countryId = this.value.countryId;
        if (this.value.countryDetails && this.value.countryDetails.id) {
          countryId = this.value.countryDetails.id;
        }
        let stateId = this.value.stateId;
        if (this.value.stateDetails && this.value.stateDetails.id) {
          stateId = this.value.stateDetails.id;
        }
  
        this.$store
          .dispatch("getlocations", {
            countryId: countryId,
            stateId: stateId,
          })
          .then((response) => {
            this.locations = response;
            this.loading = false;
  
            var location = this.value.locationId;
            if (location != null) {
              var item = _.find(this.locations, function (item) {
                return item.id == location;
              });
              if (!item) {
                this.value.locationDetails = null;
                this.value.locationId = null;
              }
            }
  
            if (firstLoad) {
              this.applyWatchers();
            }
          })
          .catch(() => {
            this.loading = false;
          });
      },
      init() {
        var _data = _.cloneDeep(this.value);
       
        if (this.value.aptType != "") {
          if (this.value.aptType == "APT") {
            this.aptType1 = true;
            this.aptType2 = false;
            this.aptType3 = false;
          }
          if (this.value.aptType == "STE") {
            this.aptType1 = false;
            this.aptType2 = true;
            this.aptType3 = false;
          }
          if (this.value.aptType == "FLR") {
            this.aptType1 = false;
            this.aptType3 = true;
            this.aptType2 = false;
          }
        }
  
        if (this.hideusa) {
          this.countrieslist = _.filter(this.countries, function (item) {
            return item.id != 231;
          });
  
          var countryId = this.value.countryId;
          if (countryId != null) {
            var item = _.find(this.countrieslist, function (item) {
              return item.id == countryId;
            });
            if (!item) {
              this.value.countryDetails = null;
              this.value.countryId = null;
            }
          }
        } else {
          this.countrieslist = this.countries;
  
          if (this.disableCountry || this.value.countryId == null) {
            this.value.countryDetails = {
              _id: "61408c9ed01ea1248cdcf6b7",
              id: 231,
              name: "United States",
              phoneCode: 1,
              order: 1,
              currencySymbol: "$",
              currencyCode: "USD",
              zipcodeLength: 5,
              sortName: "united states",
            };
            this.value.countryId = 231;
          }
        }
  
        this.loadStatesByCountryId(true);
      },
      addLocation(newTag) {
        this.loading = true;
        this.$store
          .dispatch("addLocations", {
            name: newTag,
            stateId: this.value.stateId,
          })
          .then((response) => {
            var tag = response;
            this.locations.push(response);
            this.value.location = response;
            this.loading = false;
          })
          .catch(() => {
            this.loading = false;
          });
      },
    },
    beforeDestroy() {},
  };
  </script>
  