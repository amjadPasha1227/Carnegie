<template>
    <div class="form_group" :class="wrapclass">
        <label class="form_label">{{ label }}<em v-if="required">*</em></label>
        <!---
      <VuePhoneNumberInput
       icon-pack="feather" class="w-full no-icon-border"
        :no-example="false" 
        v-validate="required? 'required|'+datatype : datatype " v-bind="translations" :data-vv-as="placeHolder" 
        :name="fieldName+cid" 
         :default-country-code="countrycode" 
         :placeholder="placeHolder" 
         :no-country-selector="false" v-model="value" @input="updateData" ></VuePhoneNumberInput>
    
        -->

        <VuePhoneNumberInput icon-pack="feather" class="w-full no-icon-border" :no-example="true" autocomplete="off"
            autocorrect="off" :data-vv-as="placeHolder" v-validate="required ? 'required|' + datatype : datatype"
            v-bind="vuePhone.props" :name="fieldName + cid" :default-country-code="countrycode" :placeholder="placeHolder"
            :no-country-selector="false" @input="updateData" v-model="value" @update="updatePhone"
            
             />
            
        <span v-if="errors.has((formscope != '' ? formscope + '.' : '') + fieldName + cid)" class="form-error">{{
            errors.first((formscope != '' ? formscope + '.' : '') + fieldName + cid) }}</span>
        <template v-else-if="inputCount > 2 && !isPhoneValid && value">
            <span class="form-error">* Invalid Phone Number</span>

            <input v-if="required" type="hidden" v-model="value" v-validate="'required'" :name="fieldName + cid">
        </template>
    </div>
</template>
    
<script>

import VuePhoneNumberInput from "vue-phone-number-input";
import "vue-phone-number-input/dist/vue-phone-number-input.css";

export default {
    inject: ["parentValidator"],
    props: {
        itemArrayIndex: {
            type: Number,
            default: -1
        },
        fieldsArray: Array,
        countrycode: {
            type: String,
            default: 'US'
        },
        wrapclass: {
            type: String,
            default: "md:w-1/2"
        },
        datatype: {
            type: String,
            default: ""
        },
        tplsection: {
            type: String,
            default: null,
        },
        tplkey: {
            type: String,
            default: null,
        },
        cid: {
            type: String,
            default: null,
        },
        formscope: {
            type: String,
            default: ''
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        }
    },
    data() {
        return {
            hiddenInputVal: '',
            inputCount: 0,
            isPhoneValid: true,
            translations: {
                phoneNumberLabel: "Phone Number",
            },
            vuePhone: {
                props: {
                    translations: {
                        phoneNumberLabel: "Phone Number"
                    }
                }

            },
        }

    },
    created() {
        this.$validator = this.parentValidator;
    },

    methods: {
        updateData() {
            this.inputCount = this.inputCount + 1;
            //  this.isPhoneValid=false;

            this.$emit('input', this.value);


        },
        updatePhone(item) {
            this.isPhoneValid = true;
            if (item.isValid) {
                let phoneCountryCode = {
                    countryCode: item.countryCode,
                    countryCallingCode: item.countryCallingCode,
                    // itemArrayIndex: -1,
                };
                // phoneCountryCode['itemArrayIndex'] = this.itemArrayIndex;
                this.$emit('updatephoneCountryCode', phoneCountryCode);

                //  this.$emit('input', this.value);
                //this.profileUpdateData.phone = item.nationalNumber;
            } else {
                let phoneCountryCode = {
                    countryCode: item.countryCode,
                    countryCallingCode: item.countryCallingCode,
                    //  itemArrayIndex: -1,
                };
                // phoneCountryCode['itemArrayIndex'] = this.itemArrayIndex;
                this.$emit('updatephoneCountryCode', phoneCountryCode);


                this.isPhoneValid = false;
            }
        },
    },
    components: {
        VuePhoneNumberInput
    }
};
</script>
    