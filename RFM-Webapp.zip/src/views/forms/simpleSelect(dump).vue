<template>
    <div>
        <vue-multi-select
            class="opinion_select"
            ref="multiSelect"
            v-model="selected"
            :multiple="true"
            :optionsmain="optionsmain"
            :btnLabel="btnLabel"
            @open="open"
            @close="close"
            :selectOptions="optionsmain">
        </vue-multi-select>
    </div>
  </template>
  
  <script>
    import vueMultiSelect from 'vue-multi-select';
    import 'vue-multi-select/dist/lib/vue-multi-select.css';

    export default {
      data() {
        return {
          
            btnLabel: values => values.length  ? values[0].name : 'select',
            btnLabel: values => values.length  ? values[0].name : 'select',
            options: {
                multi: true,
                groups: true,
            },
          selected:[],
          optionsmain: [
            { value: null, name: 'Priority' },
            { value: null, name: 'Default Selected Option' },
            { value: null, name: 'This is another option' },
            { value: null, name: 'This one is disabled', disabled: true }
          ],
          selecte:[],
          statusoptions: [
            { value: null, name: 'Specialty Occupation Expert Opinions (Position Evaluations)' },
            { value: null, name: 'Default Selected Option' },
            { value: null, name: 'This is another option' },
            { value: null, name: 'This one is disabled', disabled: true }
          ],
        }
      },
      components: {
        vueMultiSelect,
      },
      
      props: {
            placeHolder: {
                type: String,
                default: null,
            },
      }
    }
  </script>