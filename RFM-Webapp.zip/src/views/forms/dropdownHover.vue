<template>
    <div>
      <b-dropdown class="settings-drpdown" dropleft text="..." no-caret>
        <slot></slot>
      </b-dropdown>
    </div>
  </template>
  
  <script>
  export default {
    name: "b-dropdown-hover",
    methods: {
      onOver() {
        this.$refs.dropdown.visible = true;
      },
      onLeave() {
        this.$refs.dropdown.visible = false;
      },
    },
  };
  </script>