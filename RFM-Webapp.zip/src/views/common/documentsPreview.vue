<template>
    <div class="list-elements">
        <!-- <h4>{{ type | formatdoctype }}</h4> -->

        <ul>
            <li class="download_view_v2" v-for="(item, ind ) in  documentsList"
                v-b-tooltip.hover="checkProperty(item, 'name')" v-b-tooltip="{ customClass: 'docs_tooltip' }">

                <figure v-if="!includeDownloadText">
                    <img v-if="checkFileFormat(item['mimetype']) == 'pdf'" src="@/assets/images/main/pdf.svg" />
                    <img v-else-if="checkFileFormat(item['mimetype']) == 'video_mime_types'"
                        src="@/assets/images/main/film.png" />
                    <img v-else-if="checkFileFormat(item['mimetype']) == 'msDoc'" src="@/assets/images/main/doc.svg" />
                    <img v-else-if="checkFileFormat(item['mimetype']) == 'zip'"
                        src="@/assets/images/main/zip-file-format.png" />
                    <img v-else-if="checkFileFormat(item['mimetype']) == 'msPpt'" src="@/assets/images/main/ppt.svg" />
                    <img v-else-if="checkFileFormat(item['mimetype']) == 'msXl'" src="@/assets/images/main/xls.svg" />
                    <img v-else-if="checkFileFormat(item['mimetype']) == 'image'" src="@/assets/images/main/image.svg" />
                    <img v-else src="@/assets/images/main/icon-img.svg" />
                    <span class="download_icon_v2">
                        <span class="d-flex">
                            <span v-if="checkFileFormat(item['mimetype']) == 'pdf'"
                                @click="pdftowordconvert(item, checkProperty(item, 'name'))"><img
                                    class="download_img doc_img" src="@/assets/images/main/doc_file.png"></span>
                            <span @click="downloads3file(item)"><img class="download_img"
                                    src="@/assets/images/main/download.png"></span>
                        </span>
                        <span @click="downloadfile(item)"><img class="view_img"
                                src="@/assets/images/main/view_hover.svg"></span>
                    </span>
                </figure>
                <div v-if="includeDownloadText" class="download_sec">
                    <img src="@/assets/images/pdf-file-format.svg">
                    <a @click="downloads3file(item)" class="link_btn">Download</a>
                </div>
            </li>
        </ul>

        <span class="loader" v-if="convertLoading"><img src="@/assets/images/loader.gif" /></span>
    </div>
</template>
<script>
export default {

    data: () => ({
        convertLoading: false

    }),
    methods: {
        downloadfile(item) {
            this.$emit("download_or_view", item);
        },
        convertPdfToWord() {
            this.$emit("download_or_view", item);
        },

    },
    props: {
        documentsList: {
            type: Array,
            default: [],
        },
        petitionDetails: {
            type: Object,
            default: null,
        },
        type: {
            type: String,
            default: '',
        },
        includeDownloadText: {
            type: Boolean,
            default: false
        }
    },
    mounted() {
        this.$on('convertLoading', (value) => {
            const body = document.getElementsByTagName('body')[0];

            if (value)
                body.classList.add("overflow-hidden");
            else
                body.classList.remove("overflow-hidden");
            this.convertLoading = value
            console.log(value)
        })
    }
}



</script>