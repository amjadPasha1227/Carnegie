<template>
  <div class="side_menu">
    <!-- <div class="logo">
      <a @click="">
        <img src="@/assets/images/logo_carne.png">
      </a>
    </div> -->
    <ul class="menu">
        <li  :class="{ 'active': currentRouteName == 'dashboardView' }"
          @click="gotoPage('/dashboard')" class="dashboard">
          <figure>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
              <defs>
                <linearGradient id="linear-gradient" x1="0.5" x2="0.5" y2="1" gradientUnits="objectBoundingBox">
                  <stop offset="0" stop-color="#d5d6e6"/>
                  <stop offset="1" stop-color="#a6a8ce"/>
                </linearGradient>
              </defs>
              <path id="categories" d="M14.04,8.28v4.48a1.28,1.28,0,0,1-1.28,1.28H8.28A1.28,1.28,0,0,1,7,12.76V8.28A1.28,1.28,0,0,1,8.28,7h4.48A1.28,1.28,0,0,1,14.04,8.28ZM21.72,7H17.24a1.28,1.28,0,0,0-1.28,1.28v4.48a1.28,1.28,0,0,0,1.28,1.28h4.48A1.28,1.28,0,0,0,23,12.76V8.28A1.28,1.28,0,0,0,21.72,7Zm-8.96,8.96H8.28A1.28,1.28,0,0,0,7,17.24v4.48A1.28,1.28,0,0,0,8.28,23h4.48a1.28,1.28,0,0,0,1.28-1.28V17.24A1.28,1.28,0,0,0,12.76,15.96Zm6.72,0A3.52,3.52,0,1,0,23,19.48a3.52,3.52,0,0,0-3.52-3.52Z" transform="translate(-7 -7)" fill="url(#linear-gradient)"/>
            </svg>
          </figure>
          <a href="javascript:;">Dashboard</a>
        </li>
        <li @click="gotoPage('/incomelist')" class="income"
          :class="{ 'active': currentRouteName == 'income-list' }">
          <figure>
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="20" height="19.979" viewBox="0 0 20 19.979">
            <defs>
              <linearGradient id="linear-gradient" x1="0.5" x2="0.5" y2="1" gradientUnits="objectBoundingBox">
                <stop offset="0" stop-color="#d5d6e6"/>
                <stop offset="1" stop-color="#a6a8ce"/>
              </linearGradient>
            </defs>
            <path id="chart-area" d="M19.979,19.979H2.5a2.5,2.5,0,0,1-2.5-2.5V0H1.665V17.482a.834.834,0,0,0,.832.832H19.979Zm.021-11L17.583,6.559a2.557,2.557,0,0,0-3.532,0L12.487,8.122,9.258,4.894a2.556,2.556,0,0,0-3.531,0l-2.4,2.4v9.359H19.977Z" fill="url(#linear-gradient)"/>
          </svg>
          </figure>
          <a href="javascript:;">Income</a>
        </li>
        <li @click="gotoPage('/expenseslist')" class="expense"
          :class="{ 'active': currentRouteName == 'expenses-list' }">
          <figure>
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="20" height="19.935" viewBox="0 0 20 19.935">
              <defs>
                <linearGradient id="linear-gradient" x1="0.5" x2="0.5" y2="1" gradientUnits="objectBoundingBox">
                  <stop offset="0" stop-color="#d5d6e6"/>
                  <stop offset="1" stop-color="#a6a8ce"/>
                </linearGradient>
              </defs>
              <path id="usd-circle" d="M10,0A10.011,10.011,0,0,0,0,10c.5,13.248,19.5,13.245,20,0A10.011,10.011,0,0,0,10,0Zm.833,14.167V15a.833.833,0,0,1-1.667,0v-.833H8.943a2.509,2.509,0,0,1-2.165-1.249.833.833,0,1,1,1.442-.835.836.836,0,0,0,.722.417h1.89c.831.054,1.2-1.292.3-1.467L8.6,10.611c-2.918-.541-2.29-4.794.571-4.777V5a.833.833,0,0,1,1.667,0v.833h.223a2.509,2.509,0,0,1,2.165,1.25.833.833,0,1,1-1.442.834.837.837,0,0,0-.722-.417H9.167c-.831-.054-1.2,1.292-.3,1.467L11.4,9.39c2.918.541,2.29,4.794-.571,4.778Z" fill="url(#linear-gradient)"/>
            </svg>
          </figure>
          <a href="javascript:;">Expenses</a>
        </li>
           <li @click="gotoPage('/orderlist')" class="orders"
          :class="{ 'active': currentRouteName == 'order-list' }">
          <figure>
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="13.5" height="18" viewBox="0 0 13.5 18">
            <defs>
              <linearGradient id="linear-gradient" x1="0.5" x2="0.5" y2="1" gradientUnits="objectBoundingBox">
                <stop offset="0" stop-color="#d5d6e6"/>
                <stop offset="1" stop-color="#a6a8ce"/>
              </linearGradient>
            </defs>
            <path id="ticket" d="M16.5,11.25v-9A2.25,2.25,0,0,0,14.25,0h-3V.75a1.5,1.5,0,1,1-3,0V0h-3A2.25,2.25,0,0,0,3,2.25v9H6v1.5H3V18H8.25v-.75a1.5,1.5,0,0,1,3,0V18H16.5V12.75h-3v-1.5Zm-5.25,1.5h-3v-1.5h3Z" transform="translate(-3)" fill="url(#linear-gradient)"/>
          </svg>
          </figure>
          <a href="javascript:;">Orders</a>
        </li>
        <li @click="gotoPage('/cloverlist')" class="ordersinfo"
          :class="{ 'active': currentRouteName == 'clover-list' }">
          <figure>
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="17.999" height="17.999" viewBox="0 0 17.999 17.999">
              <defs>
                <linearGradient id="linear-gradient" x1="0.5" x2="0.5" y2="1" gradientUnits="objectBoundingBox">
                  <stop offset="0" stop-color="#d5d6e6"/>
                  <stop offset="1" stop-color="#a6a8ce"/>
                </linearGradient>
              </defs>
              <g id="calendar" transform="translate(-1.013 -1.013)">
                <path id="Union_1" data-name="Union 1" d="M3.039,18A3.183,3.183,0,0,1,0,14.7V4.949A3.184,3.184,0,0,1,3.039,1.643h.108v2.4A2.174,2.174,0,0,0,5.223,6.3,2.174,2.174,0,0,0,7.3,4.04v-2.4h3.4v2.4A2.174,2.174,0,0,0,12.777,6.3,2.174,2.174,0,0,0,14.853,4.04v-2.4h.108A3.184,3.184,0,0,1,18,4.949V14.7A3.183,3.183,0,0,1,14.961,18ZM12,4.04V.753a.753.753,0,0,1,1.507,0V4.04A.753.753,0,0,1,12,4.04Zm-7.5,0V.753A.753.753,0,0,1,6,.753V4.04a.753.753,0,0,1-1.507,0Z" transform="translate(1.012 1.012)" fill="url(#linear-gradient)"/>
              </g>
            </svg>
          </figure>
          <a href="javascript:;">Order Details</a>
        </li>
      
      </ul>
    <div v-if="false" class="bottom_cnt">
      <ul>
        <li class="help">
          <a href="#">Help</a>
        </li>
      </ul>
    </div>
  </div>
</template> 
<script>
import JQuery from "jquery";
import VuePerfectScrollbar from 'vue-perfect-scrollbar'
export default {
  name: 'side-bar',
  computed: {

    getCurrentUserPermissions() {

      return (itemId) => {


        let returnVal = false;
        if (_.has(this.$store.state, 'user')) {
          let user = _.cloneDeep(this.$store.state['user']);


          if (user && _.has(user, 'modules') && user['modules'].length > 0) {
            if (_.find(user['modules'], { '_id': itemId }) || user['role_id'] == 1) {
              returnVal = true;
            }

          } else {
            returnVal = true;
          }

        } else {
          returnVal = true;

        }
        return returnVal;
      }

    }
  },
  components: {
    VuePerfectScrollbar,

  },
  data: () => ({
    statusList: [
      {
        "_id": "64587b20224f0b4aa05fe65d",
        "id": 1,
        "name": "Requested",
        "sortName": "requested"
      },
      {
        "_id": "64587b20224f0b4aa05fe65e",
        "id": 3,
        "name": "Confirmed",
        "sortName": "confirmed"
      },
      {
        "_id": "64587b20224f0b4aa05fe664",
        "id": 9,
        "name": "Offshore",
        "sortName": "evaluator assigned"
      },
      {
        "_id": "64587b20224f0b4aa05fe666",
        "id": 10,
        "name": "Onsite",
        "sortName": "reviewer assigned"
      },
      {
        "_id": "64587b20224f0b4aa05fe667",
        "id": 12,
        "name": "With Professor",
        "sortName": "with professor"
      },
      {
        "_id": "64587b20224f0b4aa05fe667",
        "id": 14,
        "name": "Professor Approved",
        "sortName": "with professor"
      },
      {
        "_id": "64587b20224f0b4aa05fe667",
        "id": 15,
        "name": "Final Review",
        "sortName": "Final Review"
      },
      {
        "_id": "64587b20224f0b4aa05fe668",
        "id": 16,
        "name": "Delivered",
        "sortName": "delivered to client"
      },
    ],
    setRequestsMenu: "ALL",
    currentRouteName: 'dashboardView'
  }),
  methods: {
    gotoPage(path = '/') {
      this.$store.commit("setRequestsMenu", "ALL");
      this.$router.push(path)
    },
    gotoSubMenuPage(statusItem) {

      this.setRequestsMenu = "ALL";

      if (this.checkProperty(this.$router.currentRoute, 'name') == 'Evaluations') {
        if (this.checkProperty(statusItem, "id")) {
          this.$store.commit("setRequestsMenu", statusItem.id)
        } else {
          this.$store.commit("setRequestsMenu", "ALL")
        }
      } else {
        //  alert(this.$router.currentRoute.name)
        if (this.checkProperty(statusItem, "id")) {
          this.$store.commit("setRequestsMenu", statusItem.id)
          this.setRequestsMenu = statusItem.id;
        } else {
          this.$store.commit("setRequestsMenu", "ALL");
        }
        setTimeout(() => {
          this.$router.push({ name: 'Evaluations', params: { 'statusId': "" } })
        }, 500);

      }


    },
    getMasterDataList(category) {

      this.$store.dispatch("getMasterData", category)
        .then((res) => {
          if (category == 'evaluation_status') {
            this.statusList = res
          }
        })
    },

  },
  mounted() {
    const $ = JQuery;
    $("button").click(function () {
      $("p").toggleClass("main");
    });

    //  this.getMasterDataList('evaluation_status')
    this.$watch("$route", function (value) {

      if (this.checkProperty(this.$router.currentRoute, 'name') == 'requestdetails' || this.checkProperty(this.$router.currentRoute, 'name') == 'create-evaluation') {
        this.setRequestsMenu = localStorage.getItem('subMenuId')
      } else {
        localStorage.setItem('subMenuId', "ALL")
      }

      this.currentRouteName = this.checkProperty(this.$router.currentRoute, 'name')
      this.$store.commit("setRequestsMenu", this.setRequestsMenu);
    })
    if (this.checkProperty(this.$router.currentRoute, 'name')) {
      this.currentRouteName = this.checkProperty(this.$router.currentRoute, 'name')
    }
  },

}
</script>

