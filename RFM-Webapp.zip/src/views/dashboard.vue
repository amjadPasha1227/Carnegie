<template>
  <div class="db_page">
    <div class="filter_sec db_filter_sec">
      <!-- <span class="db_filter_btn">Yesterday</span> -->
      <span class="db_filter_btn" v-bind:class="{ 'active': dateFilterType == 1 }" @click="onTodaySelect(1)">Today</span>
      <span class="db_filter_btn" v-bind:class="{ 'active': dateFilterType == 2 }"
        @click="onTodaySelect(2)">Yesterday</span>
      <div class="custom-datepicker">

        <date-range-picker :maxDate="new Date()" :autoApply="autoApply" @update="onTodaySelect(3)"
          :placeholder="'dd/mm/yyyy'" :ranges="false" :opens="'left'"
          :locale-data="{ format: 'mmm dd, yyyy', customRangeLabel: 'Custom Range', }"
          v-model="dateRange"></date-range-picker>
        <span class="clear" @click="clearDateRange()"
          v-if="checkProperty(dateRange, 'startDate') && checkProperty(dateRange, 'endDate')"><img
            src="@/assets/images/close.svg"></span>
      </div>
    </div>

    <template v-if="isListLoading">
      <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users' :loading="isListLoading" />
    </template>

    <b-tabs justified no-body content-class="dashboard_tabs" v-if="!isListLoading">
      <b-tab title="Income" active>
        <div class="widget_wrapper_v2" v-if="!isListLoading">
          <div class="widget_icon income">
            <span></span>
          </div>
          <div class="widget_top">
            <span class="heading">Income</span>
            <span class="count"><em>$</em>{{ checkProperty(stats, 'income', 'totalincome') }}</span>
          </div>
          <ul v-if="checkProperty(stats, 'income')" class="income_list">
            <li class="offline">
              <span>Offline</span>
              <span>{{ checkProperty(stats.income, 'offlineorders', 'nooforder') }} orders</span>
              <span>${{ checkProperty(stats.income, 'offlineorders', 'total') }}</span>
            </li>
            <li class="clover">
              <span>Clover</span>
              <span>{{ checkProperty(stats.income, 'clover', 'nooforder') }} orders</span>
              <span>${{ checkProperty(stats.income, 'clover', 'total') }}</span>
            </li>
            <li class="ubereats">
              <span>Uber Eats</span>
              <span>{{ checkProperty(stats.income, 'ubereats', 'nooforder') }} orders</span>
              <span>${{ checkProperty(stats.income, 'ubereats', 'total') }}</span>
            </li>
            <li class="grubhub">
              <span>Grubhub</span>
              <span>{{ checkProperty(stats.income, 'grubhub', 'nooforder') }} orders</span>
              <span>${{ checkProperty(stats.income, 'grubhub', 'total') }}</span>
            </li>
            <li class="doordash">
              <span>Door Dash</span>
              <span>{{ checkProperty(stats.income, 'doordash', 'nooforder') }} orders</span>
              <span>${{ checkProperty(stats.income, 'doordash', 'total') }}</span>
            </li>
          </ul>
        </div>
      </b-tab>
      <b-tab title="Expenses">
        <div class="widget_wrapper_v2" v-if="!isListLoading">
          <div class="widget_icon expense">
            <span></span>
          </div>
          <div class="widget_top">
            <span class="heading">Expenses</span>
            <span class="count"><em>$</em>{{ checkProperty(stats, 'expenses', 'total') }}</span>
          </div>
          <ul v-if="checkProperty(stats, 'expenses') && checkProperty(stats.expenses, 'breakdown', 'length') > 0" class="expence_list">
            <li v-for="(item, index) in    checkProperty(stats, 'expenses', 'breakdown')">
              <span>{{ checkProperty(item, 'name') }}</span>
              <span>${{ checkProperty(item, 'amount') }}</span>
            </li>
          </ul>
          <div v-else>
            <p> No data found</p>
          </div>
        </div>
      </b-tab>
    </b-tabs>
    <div class="widget_wrapper" v-if="false">
      <div class="widget widget_v2">
        <div class="widget_top">
          <div class="widget_left">
            <span class="count">${{ checkProperty(stats, 'income', 'totalincome') }}</span>
            <span class="heading">Income</span>
          </div>
          <div class="widget_right">
            <button class="add_btn" v-if="false"><span></span><em>Add</em></button>
          </div>
        </div>
        <div class="or_text_v2">
        </div>
        <div class="widget_bottom">
          <!-- <ul>
            <li>
              <div class="order_details">
                <span>$1000</span>
              </div>
              <div class="order_details">
                <span>Uber Eats</span>
                <span>50 <em>No. of Orders</em></span>
              </div>
            </li>
          </ul> -->
          <ul v-if="checkProperty(stats, 'income')">
            <!-- <li>
              <div class="order_details">
                <span><em>Uber Eats</em></span>
                <span><em>Total Order</em></span>
              </div>
              <div class="order_details">
                <span>$2548</span>
                <span>50</span>
              </div>
            </li>
            <li>
              <div class="order_details">
                <span><em>Clover</em></span>
                <span><em>Total Order</em></span>
              </div>
              <div class="order_details">
                <span>$658</span>
                <span>12</span>
              </div>
            </li>
            <li>
              <div class="order_details">
                <span><em>Grubhub</em></span>
                <span><em>Total Order</em></span>
              </div>
              <div class="order_details">
                <span>$2552</span>
                <span>26</span>
              </div>
            </li> -->
            <li>
              <div class="order_details">
                <span><em>Offline</em> </span>
                <span>${{ checkProperty(stats.income, 'offlineorders', 'total') }}
                  <em>({{ checkProperty(stats.income, 'offlineorders', 'nooforder') }} orders)</em></span>
              </div>
            </li>
            <li>
              <div class="order_details">
                <span><em>Clover</em> </span>
                <span>${{ checkProperty(stats.income, 'clover', 'total') }}
                  <em>({{ checkProperty(stats.income, 'clover', 'nooforder') }} orders)</em></span>
              </div>
            </li>
            <li>
              <div class="order_details">
                <span><em>Uber Eats</em></span>
                <span>${{ checkProperty(stats.income, 'ubereats', 'total') }}
                  <em>({{ checkProperty(stats.income, 'ubereats', 'nooforder') }} orders)</em></span>
              </div>
            </li>
            <li>
              <div class="order_details">
                <span><em>Grubhub</em> </span>
                <span>${{ checkProperty(stats.income, 'grubhub', 'total') }}
                  <em>({{ checkProperty(stats.income, 'grubhub', 'nooforder') }} orders)</em></span>
              </div>
            </li>
            <li>
              <div class="order_details">
                <span><em>Door Dash</em> </span>
                <span>${{ checkProperty(stats.income, 'doordash', 'total') }}
                  <em>({{ checkProperty(stats.income, 'doordash', 'nooforder') }} orders)</em></span>
              </div>
            </li>

          </ul>
        </div>
      </div>
      <div class="widget widget_v2">
        <div class="widget_top">
          <div class="widget_left">
            <span class="count">${{ checkProperty(stats, 'expenses', 'total') }}</span>
            <span class="heading">Expenses</span>
          </div>
          <div class="widget_right">
            <button class="add_btn" v-if="false"><span></span><em>Add</em></button>
          </div>
        </div>
        <div class="or_text_v2">
        </div>
        <div class="widget_bottom">
          <ul v-if="checkProperty(stats, 'expenses') && checkProperty(stats.expenses, 'breakdown', 'length') > 0">
            <li v-for="(item, index) in    checkProperty(stats, 'expenses', 'breakdown')">
              <div class="order_details">
                <span><em>{{ checkProperty(item, 'name') }}</em></span>
                <span>${{ checkProperty(item, 'amount') }}</span>
              </div>
            </li>
          </ul>
          <div v-else>
            <p> No data found</p>
          </div>
        </div>
      </div>
    </div>
    <div class="pending_payments_sec" v-if="checkProperty(stats, 'ordersWithPendingBalance', 'length')">
      <h6>Payments Receivable</h6>
      <!-- <ul>
        <li v-for="(item, index) in    checkProperty(stats, 'ordersWithPendingBalance')">
          <div class="details">
            <span>{{ checkProperty(item, 'customerName') }}</span>
            <span v-if="checkProperty(item, 'deliveryDate')"> <em>Delivery:</em> {{ checkProperty(item, 'deliveryDate') |
              formatDate }}</span>
          </div>
          <div class="details balance">
            <span class="order_id"><em>Balance:</em>${{ checkProperty(item, 'balanceDue') }}</span>
          </div>
        </li>
      </ul> -->
      <ul class="patments_receivables">
        <li v-for="(item, index) in    checkProperty(stats, 'ordersWithPendingBalance')">
          <div class="payemts_list">
            <div class="name_date">
              <span :title="checkProperty(item, 'customerName')">{{ checkProperty(item, 'customerName') }}</span>
              <span v-if="checkProperty(item, 'deliveryDate')"><em>{{ checkProperty(item, 'deliveryDate') |
              formatDate }}</em></span>
            </div>
            <div class="amount">
              <span>${{ checkProperty(item, 'balanceDue') }}</span>
            </div>
          </div>
        </li>
      </ul>
    </div>
    <div class="pending_payments_sec" v-if="checkProperty(stats, 'expensesDetails', 'length')">
      <h6>Amounts Payables</h6>
      <ul>
        <li v-for="(item, index) in    checkProperty(stats, 'expensesDetails')">
          <div class="details">
            <span>{{ checkProperty(item, 'natureofExpense') }}</span>
            <span><em>Payable To :</em>{{ checkProperty(item, 'paidTo') }}</span>
          </div>
          <div class="details">
            <span><em>Due Amount :</em>${{ checkProperty(item, 'balanceDue') }}</span>
            <span v-if="checkProperty(item, 'balanceDueBy')"><em>Due Date :</em>{{ checkProperty(item, 'balanceDueBy') |
              formatDate }}</span>
          </div>
        </li>

      </ul>
    </div>


  </div>
</template>

<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
//import simpleSelect from '@/views/forms/simpleSelect.vue';

import customSelect from '@/views/forms/customSelect.vue';

import DatePicker from 'vue2-datepicker';
import 'vue2-daterange-picker/dist/vue2-daterange-picker.css'
import 'vue2-datepicker/index.css';
import NoDataFound from '@/views/common/noData.vue';
import _ from "lodash";
import DateRangePicker from "vue2-daterange-picker";
import moment from 'moment';
import dropdownHover from "@/views/forms/dropdownHover.vue"
import radioInput from "@/views/forms/radioInput.vue";
import VuePerfectScrollbar from 'vue-perfect-scrollbar';
import datepicker from '@/views/forms/datePicker.vue';
export default {
  name: 'dashboard-view',
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  components: {
    searchInput,
    //simpleSelect,
    customSelect,
    DatePicker,
    NoDataFound,
    DateRangePicker,
    dropdownHover,
    radioInput,
    VuePerfectScrollbar,
    datepicker
  },
  data: () => ({
    showChart: false,
    chartLoading: true,
    loadingTopFiveData: false,
    mostHandledLoading: false,
    isListLoading: false,
    rows: 100,
    perPage: 1,
    currentPage: 1,
    autoApply: "",
    dateRange: {
      startDate: null,
      endDate: null
    },
    defaultDateRange: {
      startDate: null,
      endDate: null
    },
    dateFilterType: 1,
    stats: {
      income: {
        totalincome: 0,
        clover: {
          "total": 0,
          "nooforder": 0
        },
        "offlineorders": {
          "total": 0,
          "nooforder": 0
        },
        "ubereats": {
          "total": 0,
          "nooforder": 0
        },
        "grubhub": {
          "total": 0,
          "nooforder": 0
        },
        "doordash": {
          "total": 0,
          "nooforder": 0
        }
      },
      expenses: {
        "breakdown": [],
        "total": 0
      },
      expensesDetails: [],
      ordersWithPendingBalance: []

    }
  }),
  methods: {
    clearDateRange() {
      this.dateFilterType = 1
      this.dateRange = {
        startDate: null,
        endDate: null
      }
      this.getDashboardStats()
    },


    gotoPage(path = "/") {
      this.$router.push(path);
    },




    onTodaySelect(type = 1) {
      this.dateFilterType = type
      if (type == 2) {
        this.defaultDateRange = {
          startDate: moment().subtract(1, 'days'),
          endDate: moment().subtract(1, 'days')
        }
      } else if (type == 1) {
        this.defaultDateRange = {
          startDate: new Date(),
          endDate: new Date()
        }
      } else {

      }
      this.getDashboardStats()


    },

    getDashboardStats() {
      this.isListLoading=true
      let postdata = {
        startDate: '',
        endDate: ''
      }
      if (this.dateFilterType == 3 && this.checkProperty(this.dateRange, 'startDate') && this.checkProperty(this.dateRange, 'endDate')) {
        let startDate = moment(this.checkProperty(this.dateRange, 'startDate')).format("YYYY-MM-DD");
        let endDate = moment(this.checkProperty(this.dateRange, 'endDate')).format("YYYY-MM-DD");
        postdata['startDate'] = startDate
        postdata['endDate'] = endDate
      } else {
        if (this.checkProperty(this.defaultDateRange, 'startDate') && this.checkProperty(this.defaultDateRange, 'endDate')) {
          let startDate = moment(this.checkProperty(this.defaultDateRange, 'startDate')).format("YYYY-MM-DD");
          let endDate = moment(this.checkProperty(this.defaultDateRange, 'endDate')).format("YYYY-MM-DD");
          postdata['startDate'] = startDate
          postdata['endDate'] = endDate
        }
      }
       postdata['restaurantId'] = localStorage.getItem('restaurantId');
      this.$store.dispatch('getDashboardStats', postdata).then((response) => {
        this.isListLoading=false
        this.stats = response
      }).catch((error) => {
        console.log(error);
      })

    }

  },
  mounted() {

    this.onTodaySelect(1)



  }

}
</script>