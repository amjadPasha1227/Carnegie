<template>
    <div class="db_page">
        <!-- <div class="page_header">
        <h3>Users</h3>
      </div> -->
        <div class="filter_sec">
            <div class="d-flex w-100">
                <searchInput :place-holder="'Search…'" v-model="filterSearch" v-on:input="applySearchFilters" />
                <div class="custom-datepicker">
                    <date-range-picker :maxDate="new Date()" :autoApply="true" @update="applyFilters"
                        :placeholder="'dd/mm/yyyy'" :ranges="false" :opens="'left'"
                        :locale-data="{ format: 'mmm dd, yyyy', customRangeLabel: 'Custom Range', }"
                        v-model="createdeDateRange"></date-range-picker>
                    <span class="clear" @click="clearDateRange()"
                        v-if="checkProperty(createdeDateRange, 'startDate') && checkProperty(createdeDateRange, 'endDate')"><img
                            src="@/assets/images/close.svg"></span>
                </div>
            </div>
            <div class="filters_right" v-if="canCreateUser(getUserRoleId)">

                <button class="add_btn" @click="showAddOrderPopup(false)"><span></span><em>Add Order</em></button>
            </div>
        </div>
        <div class="table-responsive" v-if="false">

            <template v-if="checkProperty(usersList, 'length') <= 0">
                <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users'
                    :loading="isListLoading" />
            </template>
            <table class="table user_table" v-if="checkProperty(usersList, 'length') > 0 && !isListLoading">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <!-- <th>Order Type</th> -->
                        <!-- <th>Order Date</th> -->
                        <th>Delivery Date</th>
                        <th>Customer Name</th>
                        <!-- <th>Phone Number</th> -->
                        <th>Amount ($)</th>
                        <!-- <th>Referred By</th> -->
                        <!-- <th>Created By</th> -->
                        <!--  <th>Created On</th> -->
                        <!-- <th>Notes</th> -->
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in    usersList   " v-bind:key="index">
                        <td @click="editDetails(item, false)">
                            <span class="request_id">{{ checkProperty(item, 'requestId') ? item.requestId
                                : '' }}</span>
                        </td>
                        <!-- <td><span class="first_name">{{ checkProperty(item, 'orderTypeDetails') ? item.orderTypeDetails.name
                            : '' }}</span>
                        </td> -->
                        <!-- <td><span class="last_name">{{ item.orderDate | formatDate }}</span></td> -->
                        <td><span class="last_name">{{ item.deliveryDate | formatDate }}</span></td>
                        <td><span class="first_name">{{ checkProperty(item, 'customerName') ? item.customerName
                            : '' }}</span>
                        </td>

                        <!-- <td><span class="ph_num" v-if="checkProperty(item, 'phone')">
                                {{ checkProperty(item, 'phoneCountryCode', 'countryCallingCode') | countryFormatter }}
                                {{ checkProperty(item, 'phone') | formatPhone }}
                            </span>
                            <span v-else></span>
                        </td> -->
                        <td><span class="ph_num" v-if="checkProperty(item, 'amount')">
                                {{ checkProperty(item, 'amount') }}
                            </span>
                            <span v-else></span>
                        </td>
                        <!-- <td><span>{{ checkProperty(item, 'referredByDetails', 'name') ? checkProperty(item,
                            'referredByDetails', 'name') : checkProperty(item, 'referredOtherName') }}</span></td> -->
                        <!-- <td><span>{{ checkProperty(item, 'createdByDetails', 'name') ? checkProperty(item,
                            'createdByDetails', 'name') : '' }}</span></td> -->
                      <!--    <td><span class="last_name">{{ item.createdOn | formatDateTime }}</span></td>
 -->
                        <!-- <td><span v-html="checkProperty(item, 'notes')"></span></td> -->
                        <td>
                            <div class="actions">
                                <dropdownHover aria-disabled="true">
                                    <b-dropdown-item @click="editDetails(item, true)">Edit</b-dropdown-item>
                                    <b-dropdown-item @click="editDetails(item, false)">View Details</b-dropdown-item>
                                </dropdownHover>
                            </div>

                        </td>
                    </tr>

                </tbody>
            </table>
            <!-- <h2 v-if="usersList.length <= 0" class="loading_NoData">
            <template v-if="isListLoading"> Loading.....</template>
            <template v-else> No Users Found!</template>
          </h2> -->
            <div class="pagination-sec" v-if="checkProperty(usersList, 'length') > 0">
                <div class="per-page">
                    <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) +
                        usersList.length) +
                        ' of ' + totalCount + ' Results' }}</label>
                </div>
                <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
                    @input=" isListLoading = true, updateLoading(true), getExpenses()"></b-pagination>
            </div>
        </div>
        <div class="mobile_table_list">
            <template v-if="checkProperty(usersList, 'length') <= 0">
                <NoDataFound ref="NoDataFoundRef" content="" heading="No Data Found" type='Users'
                    :loading="isListLoading" />
            </template>
            <ul v-if="checkProperty(usersList, 'length') > 0 && !isListLoading">
                <li v-for="(item, index) in usersList " v-bind:key="index">
                    <div class="list_row">
                        <div>
                            <span class="list_heading">{{ checkProperty(item, 'requestId') ? item.requestId
                                : '' }}</span>
                        </div>
                        <div class="actions">
                            <dropdownHover aria-disabled="true">
                                <b-dropdown-item @click="editDetails(item, true)">Edit</b-dropdown-item>
                                <b-dropdown-item @click="editDetails(item, false)">View Details</b-dropdown-item>
                            </dropdownHover>
                        </div>
                    </div>
                    <div class="list_row">
                        <div><span>customer :</span> {{ checkProperty(item, 'customerName') ? item.customerName
                            : '' }}</div>
                        <div><span>delivery date :</span> {{ item.deliveryDate | formatDate }}</div>
                    </div>
                    <div class="list_row">
                        <div><span>amount ($) :</span> {{ checkProperty(item, 'amount') }}</div>
                        <div></div>
                    </div>
                </li>
            </ul>
            <div class="pagination-sec" v-if="checkProperty(usersList, 'length') > 0">
                <div class="per-page">
                    <label class="page_label">{{ (((page - 1) * perpage) + 1) + '-' + (((page - 1) * perpage) +
                        usersList.length) +
                        ' of ' + totalCount + ' Results' }}</label>
                </div>
                <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
                    @input=" isListLoading = true, updateLoading(true), getExpenses()"></b-pagination>
            </div>
        </div>
        <!-- Add User Modal -->
        <b-modal v-model="showAddOrder" id="adduser_model" dialog-class="adduser_model" centered no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">{{ isOrderEdit ? 'Update Order' : 'Add Order' }}</h6>
                <a class="close" @click=" showAddOrder = false"></a>
            </template>
            <template>

                <div class="form_info">
                    <div class="row">
                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'customerName'" :cid="'customerName'"
                                :label="'Customer Name'" :placeHolder="'Customer Name'" :vvas="'Customer Name'"
                                :display="true" :required="true" v-model="order.customerName" :allowAlphNum="true" />
                        </div>

                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'email'" :cid="'email'" :label="'Email'"
                                :placeHolder="'Email'" :vvas="'Email'" :display="true" :required="false" :datatype="'email'"
                                v-model="order.email" :emailFormat="true" />
                        </div>
                        <div class="col-md-6">
                            <phoneInput :wrapclass="'mb20'" :display="true" :tplkey="'phoneNumber'"
                                @updatephoneCountryCode="updatePhoneCountryCode"
                                :countrycode="order.phoneCountryCode.countryCode" cid="phoneNumber" v-model="order.phone"
                                :fieldName="'phoneNumber'" label="Phone Number" placeHolder="Phone Number"
                                :required="true" />
                        </div>
                        <div class="col-md-6">
                            <simpleSelect :multiple="false" :wrapclass="'mb20'" :label="'Order Type'"
                                :optionslist="orderTypeList" :display="true" :place-holder="'Select Order Type'"
                                :searchable="false" :required="true" :close-on-select="true" :clear-on-select="true"
                                v-model="order.orderType" :fieldName="'orderType'" :cid="'orderType'"
                                :vvas="'Order Type'" />
                        </div>

                        <div class="col-md-6">
                            <datepicker :wrapclass="'mb20'" :required="true" v-model="order.orderDate" fieldName="orderDate"
                                label="Order Date" :dateEnableTo="getCurrentDate()" @input="updateDeliveryDate()" />
                        </div>

                        <div class="col-md-6">
                            <datepicker :wrapclass="'mb20'" :required="true" v-model="order.deliveryDate"
                                fieldName="deliveryDate" label="Delivery Date" :dateEnableFrom="getDeliveryDate()" />
                        </div>

                        <div class="col-md-6">
                            <simpleSelect :multiple="false" :wrapclass="'mb20'" :label="'Delivery Time'"
                                :optionslist="deliveryTimeList" :display="true"
                                :place-holder="'Select Delivery Time (HH:MM)'" :searchable="false" :required="true"
                                :close-on-select="true" :clear-on-select="true" v-model="order.deliveryTime"
                                :fieldName="'deliveryTime'" :cid="'deliveryTime'" :vvas="'Delivery Time'"
                                :listContainsId="true" />
                        </div>

                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'amount'" :cid="'amount'" :label="'Amount ($)'"
                                :placeHolder="'Amount'" :vvas="'Amount'" :display="true" :required="true"
                                v-model="order.amount" :onlyNumbers="true" :allowFloatingPoint="true"
                                @input="updateBalanceAmount" />
                        </div>

                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'advanceRecevied'" :cid="'advanceRecevied'"
                                :label="'Advance Received ($)'" :placeHolder="'Advance Received'" :vvas="'Advance Received'"
                                :display="true" v-model="order.advanceRecevied" :onlyNumbers="true"
                                :allowFloatingPoint="true" @input="updateBalanceAmount" :disabled="isOrderEdit" />
                        </div>
                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'balanceDue'" :cid="'balanceDue'"
                                :label="'Balance Due ($)'" :placeHolder="'Balance Due'" :vvas="'Balance Due'"
                                :display="true" v-model="order.balanceDue" :onlyNumbers="true" :allowFloatingPoint="true"
                                :disabled="true" />
                        </div>
                        <div class="col-md-6">
                            <simpleSelect :multiple="false" :wrapclass="'mb20'" :label="'Payment Mode'"
                                :optionslist="paymentModeList" :display="true" :place-holder="'Select Payment Mode'"
                                :searchable="false" :required="true" :close-on-select="true" :clear-on-select="true"
                                v-model="order.paymentMode" :fieldName="'paymentMode'" :cid="'paymentMode'"
                                :vvas="'Payment Mode'" />
                        </div>
                        <div class="col-md-6">
                            <simpleSelect :multiple="false" :wrapclass="'mb20'" :label="'Referred By'"
                                :optionslist="referedByList" :display="true" :place-holder="'Select Referred By'"
                                :searchable="false" :required="true" :close-on-select="true" :clear-on-select="true"
                                v-model="order.referredBy" :fieldName="'referredBy'" :cid="'referredBy'"
                                :vvas="'Referred By'" @input="onChangeReferedBy" />
                        </div>
                        <div class="col-md-6" v-if="checkProperty(order, 'referredBy', 'name') == 'Others'">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'referredName'" :cid="'referredName'"
                                :label="'Referred Name'" :placeHolder="'Referred Name'" :vvas="'Referred Name'"
                                :display="true" :required="true" v-model="order.referredOtherName" :allowAlphNum="true" />
                        </div>

                        <div class="col-md-6">
                            <simpleInput :wrapclass="'mb20'" :fieldName="'createdBy'" :cid="'createdBy'"
                                :label="'Created By'" :placeHolder="'Created By'" :vvas="'Created By'" :display="true"
                                :required="true" v-model="order.createdBy" :allowAlphNum="true" :disabled="true" />

                        </div>

                        <div class="col-md-6">
                            <datepicker :wrapclass="'mb20'" :required="true" v-model="order.createdOn" fieldName="createdOn"
                                label="Created Date" :dateEnableTo="getCurrentDate()" :isDisabled="true" />
                        </div>
                        <div class="col-md-12">
                            <textArea :label="'Notes'" :wrapclass="'h80 mb10'" placeHolder="Notes" v-model="order.notes"
                                :required="false" :fieldName="'notes'" :cid="'notes'"></textArea>
                        </div>


                    </div>
                </div>
            </template>
            <template #modal-footer>
                <button class="form-cancel" @click=" showAddOrder = false">Cancel</button>
                <button class="primary_btn md" @click="addOrUpdateUser">{{ isOrderEdit ? 'Update' : 'Submit' }}</button>
            </template>
        </b-modal>

        <!-- User Added Success Modal -->
        <b-modal v-model="showAddOrderSuccess" id="success_model" dialog-class="success_model user_success" centered
            hide-header hide-footer>
            <template>
                <figure>
                    <img src="@/assets/images/success_mdl_img.png" />
                </figure>
                <h4 class="m-0">{{ isOrderEdit ? 'Order updated!' : 'Order added!' }}</h4>
                <h7 class="m-0" style="padding-left:20px;padding-right:20px;text-align: center;">{{ successMsg }}</h7>
                <button class="primary_btn md" style="margin-top:14px ;"
                    @click=" showAddOrderSuccess = false; page = 1; isListLoading = true; updateLoading(true); getExpenses()">OKAY</button>
            </template>
        </b-modal>

        <!-- Details Modal -->
        <b-modal v-model="showDetailsPopup" id="create_template" dialog-class="create_template details_modal" centered
            hide-footer no-close-on-backdrop>
            <template #modal-header>
                <h6 class="modal-title">{{ 'order Details' }}</h6>
                <a class="close" @click="showDetailsPopup = false"></a>
            </template>
            <template>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form_group">
                            <lable class="form_label">Customer Name</lable>
                            <p>{{ checkProperty(selectedOrder, 'customerName') ?
                                checkProperty(selectedOrder, 'customerName')
                                : '' }}</p>
                        </div>

                        <div class="form_group" v-if="checkProperty(selectedOrder, 'email')">
                            <lable class="form_label">Email</lable>
                            <p>{{ checkProperty(selectedOrder, 'email') }}</p>
                        </div>

                        <div class="form_group" v-if="checkProperty(selectedOrder, 'phone')">
                            <lable class="form_label">Phone Number</lable>
                            <p>{{ checkProperty(selectedOrder, 'phoneCountryCode', 'countryCallingCode') | countryFormatter
                            }}
                                {{ checkProperty(selectedOrder, 'phone') | formatPhone }}</p>
                        </div>

                        <div class="form_group" v-if="checkProperty(selectedOrder, 'orderTypeDetails', 'name')">
                            <lable class="form_label">Order Type</lable>
                            <p>{{ checkProperty(selectedOrder, 'orderTypeDetails', 'name') }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedOrder, 'orderDate')">
                            <lable class="form_label">Order Date</lable>
                            <p>{{ checkProperty(selectedOrder, 'orderDate') | formatDate }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedOrder, 'deliveryDate')">
                            <lable class="form_label">Delivery Date</lable>
                            <p>{{ checkProperty(selectedOrder, 'deliveryDate') | formatDate }}</p>
                        </div>

                        <div class="form_group" v-if="checkProperty(selectedOrder, 'deliveryTime')">
                            <lable class="form_label">Delivery Time</lable>
                            <p>{{ checkProperty(selectedOrder, 'deliveryTime') }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedOrder, 'amount')">
                            <lable class="form_label">Amount ($)</lable>
                            <p>{{ checkProperty(selectedOrder, 'amount') ? checkProperty(selectedOrder, 'amount')
                                : '' }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedOrder, 'advanceRecevied')">
                            <lable class="form_label">Advance Received ($)</lable>
                            <p>{{ checkProperty(selectedOrder, 'advanceRecevied') ? checkProperty(selectedOrder,
                                'advanceRecevied')
                                : '' }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedOrder, 'balanceDue')">
                            <lable class="form_label">Balance Due ($)</lable>
                            <p>{{ checkProperty(selectedOrder, 'balanceDue') ? checkProperty(selectedOrder, 'balanceDue') :
                                '' }}</p>
                        </div>
                        <div class="form_group" v-if="checkProperty(selectedOrder, 'paymentModeDetails', 'name')">
                            <lable class="form_label">Payment Mode</lable>
                            <p>{{ checkProperty(selectedOrder, 'paymentModeDetails', 'name') ? checkProperty(selectedOrder,
                                'paymentModeDetails', 'name')
                                : '' }}</p>
                        </div>
                        <div class="form_group">
                            <lable class="form_label">Referred By</lable>
                            <p>{{ checkProperty(selectedOrder, 'referredOtherName') ? checkProperty(selectedOrder,
                                'referredOtherName') : checkProperty(selectedOrder,
                                    'referredByDetails', 'name') }}</p>
                        </div>
                        <div class="form_group">
                            <lable class="form_label">Created By</lable>
                            <p>{{ checkProperty(selectedOrder, 'createdByDetails', 'name') ? checkProperty(selectedOrder,
                                'createdByDetails', 'name')
                                : '' }}</p>
                        </div>
                        <div class="form_group">
                            <lable class="form_label">Created On</lable>
                            <p>{{ checkProperty(selectedOrder, 'createdOn') | formatDateTime }}</p>
                        </div>

                    </div>
                    <div class="col-md-12">
                        <div class="form_group notes" v-if="checkProperty(selectedOrder, 'notes')">
                            <lable class="form_label">Notes</lable>
                            <p v-html="checkProperty(selectedOrder, 'notes')"></p>
                        </div>
                    </div>

                </div>
            </template>
        </b-modal>

        <EditRestructPopup v-if="showSubmitConfirmPopup" @submitAction="submitAction"></EditRestructPopup>
    </div>
</template>
  
<script>
// @ is an alias to /src
import searchInput from '@/views/forms/searchInput.vue';
import simpleInput from "@/views/forms/simpleInput.vue";
import fileUpload from "@/views/forms/fileupload.vue";
import simpleSelect from '@/views/forms/simpleSelect.vue';
import dropdownHover from '@/views/forms/dropdownHover.vue';
import radioInput from "@/views/forms/radioInput.vue";
import textArea from "@/views/forms/textarea.vue";
import fileUploadDrag from "@/views/forms/fileUploadDragDrop.vue";
import phoneInput from "@/views/forms/phonenumber.vue";
import axios from 'axios';
import DocumentsPreview from '@/views/common/documentsPreview.vue';
import NoDataFound from "@/views/common/noData.vue";
import moment from "moment";
import datepicker from '@/views/forms/datePicker.vue';
import DateRangePicker from "vue2-daterange-picker";
import 'vue2-daterange-picker/dist/vue2-daterange-picker.css'
import 'vue2-datepicker/index.css';
import EditRestructPopup from '@/views/common/editRestructPopup.vue';


export default {
    name: 'dashboard-view',
    components: {
        searchInput,
        simpleSelect,
        dropdownHover,
        radioInput,
        simpleInput,
        fileUpload,
        fileUploadDrag,
        textArea,
        phoneInput,
        DocumentsPreview,
        NoDataFound,
        datepicker,
        DateRangePicker,
        EditRestructPopup,
    },
    data: () => ({
        showSubmitConfirmPopup: false,
        showAddOrder: false,
        showAddOrderSuccess: false,
        isOrderEdit: false,
        isListLoading: true,
        page: 1,
        perpage: 20,
        totalCount: 0,
        currentPage: 1,
        usersList: [],
        filterSearch: '',
        createdeDateRange: {
            startDate: null,
            endDate: null
        },
        order: {
            orderType: '',
            orderDate: '',
            deliveryDate: '',
            createdBy: '',
            amount: '',
            createdOn: '',
            notes: '',
            email: '',
            customerName: '',
            phone: null,
            phoneCountryCode: {
                countryCode: 'US',
                countryCallingCode: ''
            },
            referredBy: null,
            referredOtherName: '',
            deliveryTime: null,
            advanceRecevied: '',
            balanceDue: '',
            paymentMode: null,
        },
        selectedOrder: null,
        successMsg: '',
        docType: '',
        formSubmited: false,
        docPrivew: false,
        docType: '',
        selectedFile: null,
        orderTypeList: [],
        referedByList: [],
        deliveryTimeList: [],
        paymentModeList: [],
        showDetailsPopup: false,

    }),
    methods: {
        submitAction(actionType) {
            this.showSubmitConfirmPopup = false
        },
        clearDateRange() {
            //alert()
            this.createdeDateRange = {
                startDate: null,
                endDate: null
            }
            this.applyFilters()
        },
        showAddOrderPopup(isEdit = false) {
            this.isOrderEdit = false
            this.order = {
                orderType: '',
                orderDate: '',
                deliveryDate: '',
                createdBy: this.checkProperty(this.getUserData, 'name'),
                amount: '',
                createdOn: moment(new Date()).format("YYYY-MM-DD"),
                notes: '',
                email: '',
                customerName: '',
                phone: null,
                phoneCountryCode: {
                    countryCode: '',
                    countryCallingCode: ''
                },
                referredBy: null,
                referredOtherName: '',
                deliveryTime: null,
                advanceRecevied: '',
                balanceDue: '',
                paymentMode: null,
            }

            this.showAddOrder = true
        },

        addOrUpdateUser() {
            this.$validator.validateAll().then((result) => {
                if (result) {

                    // let postData = _.cloneDeep(this.user)
                    let postData = {
                        "orderType": this.order.orderType.id,
                        "orderDate": this.order.orderDate,
                        "deliveryDate": this.order.deliveryDate,
                        "deliveryTime": this.checkProperty(this.order, 'deliveryTime', 'name') ? this.checkProperty(this.order, 'deliveryTime', 'name') : '',
                        "advanceRecevied": this.order.advanceRecevied,
                        "balanceDue": this.order.balanceDue,
                        "amount": this.order.amount,
                        "paymentMode": this.checkProperty(this.order, 'paymentMode', 'id') ? this.checkProperty(this.order, 'paymentMode', 'id') : '',
                        "notes": this.order.notes,
                        "email": this.checkProperty(this.order, "email") ? this.checkProperty(this.order, "email") : "",
                        "customerName": this.checkProperty(this.order, "customerName") ? this.checkProperty(this.order, "customerName") : "",
                        "phone": this.checkProperty(this.order, "phone") ? this.checkProperty(this.order, "phone") : "",
                        "phoneCountryCode": this.checkProperty(this.order, "phoneCountryCode"),
                        "referredOtherName": this.checkProperty(this.order, "referredOtherName"),
                        "today": new Date(),
                    }
                    if (this.checkProperty(this.order, "referredBy", "_id") && this.checkProperty(this.order, "referredBy", "_id") != "1234") {
                        Object.assign(postData, { referredBy: this.checkProperty(this.order, "referredBy", "_id") });
                    }

                    if (this.isOrderEdit) {
                        postData['userId'] = this.selectedOrder._id
                        this.$store
                            .dispatch("userUpdate", postData)
                            .then((response) => {
                                if (response.error) {
                                    this.showToster({ message: response.error.message, isError: true });
                                } else {
                                    this.successMsg = response.message
                                    this.showAddOrder = false
                                    //this.showAddOrderSuccess = true
                                    this.usersList = []
                                    this.showToster({ message: response.message, isError: false });
                                    this.isListLoading = true
                                    this.updateLoading(true);
                                    this.page = 1
                                    this.getExpenses()
                                }
                            })
                            .catch((error) => {
                                this.showToster({ message: error, isError: true });
                                this.loading = false;
                            });
                    } else {
                        this.$store
                            .dispatch("orderCreate", postData)
                            .then((response) => {
                                if (response.error) {
                                    this.showToster({ message: response.error.message, isError: true });
                                } else {
                                    this.successMsg = response.message
                                    this.showAddOrder = false
                                    this.showAddOrderSuccess = true
                                    //this.showToster({ message: response.message, isError: false });
                                    //  this.page = 1
                                    //  this.getExpenses()
                                }
                            })
                            .catch((error) => {
                                this.showToster({ message: error, isError: true });
                                this.loading = false;
                            });
                    }




                } else {

                }
            })
        },

        getExpenses() {
            this.isOrderEdit = false
            let dateRange = []

            if (this.checkProperty(this.createdeDateRange, 'startDate') && this.checkProperty(this.createdeDateRange, 'endDate')) {
                let startDate = moment(this.checkProperty(this.createdeDateRange, 'startDate')).format("YYYY-MM-DD");
                let endDate = moment(this.checkProperty(this.createdeDateRange, 'endDate')).format("YYYY-MM-DD");
                dateRange.push(startDate)
                dateRange.push(endDate)
            }
            let postData =
            {
                "matcher": {
                    "title": this.filterSearch,
                    "searchString": this.filterSearch,
                    "statusList": [],
                    "createdByIds": [],
                    "createdDateRange":dateRange,
                    "typeIds": [],
                    "departmentIds": []
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": false,// if Masterdata required
                "page": this.page,
                "perpage": this.perpage,
            }
             postData['restaurantId'] = localStorage.getItem('restaurantId');
            this.$store.dispatch("getOrdersList", postData)
                .then((res) => {
                    this.isListLoading = false
                    this.updateLoading(false);
                    this.usersList = res.data.result.list
                    if (this.checkProperty(res, 'data', 'result') && this.checkProperty(res.data.result, 'totalCount')) {
                        this.totalCount = this.checkProperty(res.data.result, 'totalCount');
                    }
                    setTimeout(() => {
                        this.updateLoading(false);
                    })
                })
                .catch((error) => {
                    this.usersList = []
                    this.isListLoading = false
                    this.updateLoading(false);
                })
        },
        showProfilePopup(profileItem) {
            let postData =
            {
                "userId": profileItem._id
            }
            this.$store.dispatch("getUserDetails", postData)
                .then((res) => {
                    this.selectedOrder = res.result
                    this.showProfile = true
                })
                .catch((error) => {

                })

        },

        applyFilters() {
            this.usersList = []
            this.isListLoading = true
            this.updateLoading(true);
            this.page = 1
            this.getExpenses()
        },
        applySearchFilters() {
            this.usersList = []
            this.page = 1
            if (this.filterSearch && this.filterSearch.length > 2) {
                this.isListLoading = true
                this.updateLoading(true);
                this.getExpenses()
            }
            if (this.filterSearch == '') {
                this.isListLoading = true
                this.updateLoading(true);
                this.getExpenses()
            }
        },

        changeStatus() {

            this.showLoader = true;
            let payload = {
                "userId": "",
                "statusId": 2, // 3. Inactive, 4.Delete
                "statusName": ''
            }
            payload['userId'] = this.selectedOrder['_id'];
            if ([2].indexOf(this.selectedOrder.statusId) > -1) {
                payload['statusId'] = 3
                payload['statusName'] = 'Inactive'
            } else {
                payload['statusId'] = 2
                payload['statusName'] = 'Active'
            }
            this.$store.dispatch("commonAction", { data: payload, path: "users/manage-status", })
                .then((response) => {
                    this.showToster({ message: response.message, isError: false })
                    this.showLoader = false;
                    this.showStatusChangePopup = false;
                    this.applyFilters();

                }).catch((error) => {
                    this.showToster({ message: error.message, isError: true })
                    this.showLoader = false;
                    this.showStatusChangePopup = false

                });

        },

        getMasterDataList(category) {
            this.$store.dispatch("getMasterData", category)
                .then((res) => {

                    if (category == 'user_statuses') {

                    }
                })
        },

        getCurrentDate() {
            return moment().subtract(0, 'days')
        },
        getDeliveryDate() {
            if (this.checkProperty(this.order, 'orderDate')) {
                const date = moment(this.checkProperty(this.order, 'orderDate'));
                const subtractedDate = date.subtract(1, 'days');
                return subtractedDate
            }
            return ""
        },
        getUsers() {
            let postData =
            {
                "matcher": {
                    "roleIds": [4],
                },
                "sorting": {
                    "path": "createdOn",
                    "order": -1
                },
                "getMasterData": true,// if Masterdata required
                "page": 1,
                "perpage": 500,
            }
            this.$store.dispatch("getUsersList", postData)
                .then((res) => {
                    this.referedByList = res.data.result.list

                    this.referedByList = [...this.referedByList, ...[{ "_id": "1234", "name": "Others", "firstName": "Others", "lastName": "" }]]
                })
                .catch((error) => {
                })
        },
        updatePhoneCountryCode(data) {
            this.order.phoneCountryCode = data;

        },
        onChangeReferedBy(value) {
            this.order.referredOtherName = ""
        },
        updateBalanceAmount() {
            if (this.checkProperty(this.order, 'amount')) {
                if (this.checkProperty(this.order, 'advanceRecevied')) {
                    console.log('amount', this.checkProperty(this.order, 'amount'))
                    console.log('advanceRecevied', this.checkProperty(this.order, 'advanceRecevied'))
                    console.log('compare', parseFloat(this.checkProperty(this.order, 'advanceRecevied')) > parseFloat(this.checkProperty(this.order, 'amount')))
                    if (parseFloat(this.checkProperty(this.order, 'advanceRecevied')) > parseFloat(this.checkProperty(this.order, 'amount'))) {
                        this.order.advanceRecevied = 0
                        this.order.balanceDue = this.checkProperty(this.order, 'amount')
                    } else {
                        this.order.balanceDue = this.checkProperty(this.order, 'amount') - this.checkProperty(this.order, 'advanceRecevied')
                    }
                } else {
                    this.order.balanceDue = this.checkProperty(this.order, 'amount')
                }

            }

        },
        editDetails(editItem, isEditDetails = false) {
            this.selectedOrder = editItem

            this.order = _.cloneDeep(this.selectedOrder)
            this.order['createdBy'] = this.checkProperty(this.selectedOrder, 'createdByDetails', 'name');
            this.order['orderType'] = this.selectedOrder.orderTypeDetails;
            if (this.checkProperty(this.selectedOrder, 'referredOtherName')) {
                this.order['referredBy'] = _.find(this.referedByList, { "_id": "1234" });
            } else {
                this.order['referredBy'] = _.find(this.referedByList, { "_id": this.selectedOrder['referredBy'] });
            }
            this.order['deliveryTime'] = _.find(this.deliveryTimeList, { "name": this.selectedOrder['deliveryTime'] });

            if (isEditDetails) {
                if (!this.canEditTheRecord(this.checkProperty(editItem, 'createdOn'))) {
                    this.showSubmitConfirmPopup = true
                } else {
                    this.updateBalanceAmount()
                    this.isOrderEdit = true
                    this.showAddOrder = true
                }

            } else {
                this.showDetailsPopup = true
            }
            // let postData =
            // {
            //     "orderId": editItem._id
            // }
            // this.$store.dispatch("getDetails", { data: postData, path: '/order/details' })
            //     .then((res) => {
            //         this.selectedOrder = res
            //         this.order = _.cloneDeep(this.selectedOrder)

            //         // this.expense['natureOfExpense'] = this.selectedOrder.expensesNatureDetails;
            //         this.order['createdBy'] = this.selectedOrder.createdByName;
            //         this.order['orderType'] = _.find(this.orderTypeList, { "id": this.selectedOrder['orderType'] });
            //         this.order['referredBy'] = _.find(this.referedByList, { "_id": this.selectedOrder['referredBy'] });
            //         // this.order['paymentMode'] = _.find(this.paidByUsersList, { "_id": this.selectedOrder['paidById'] });


            //         //  this.selectedOrder['paidBy'] = _.find(this.paidByUsersList, { "_id": this.selectedOrder['paidById'] });
            //         this.selectedOrder['orderType'] = _.find(this.orderTypeList, { "id": this.selectedOrder['orderType'] });

            //         setTimeout(() => {
            //             if (isEditDetails) {
            //                 this.updateBalanceAmount()
            //                 this.isOrderEdit = true
            //                 this.showAddOrder = true
            //             } else {
            //                 this.showDetailsPopup = true
            //             }

            //         }, 1)
            //     })
            //     .catch((error) => {
            //         console.log('error', error)
            //     })

        },
        updateDeliveryDate(value) {
            if (this.checkProperty(this.order, 'orderDate')) {
                const date1 = new Date(this.checkProperty(this.order, 'deliveryDate'));
                const date2 = new Date(this.checkProperty(this.order, 'orderDate'));
                if (date1 < date2) {
                    this.order.deliveryDate = ''
                }
            }
        }
    },

    mounted() {
        this.getUsers()
        this.$store.dispatch("getMasterData", 'order_type')
            .then((response) => {
                this.orderTypeList = response;
            })

        this.$store.dispatch("getMasterData", 'paid_from')
            .then((response) => {
                this.paymentModeList = response;
            })
        this.isListLoading = true
        this.updateLoading(true);
        this.getExpenses()
        this.deliveryTimeList = this.generateTimeIntervals
    },
    computed: {

        generateTimeIntervals() {
            const intervals = [];
            const currentTime = new Date();
            let startHour = currentTime.getHours();
            let startMinute = currentTime.getMinutes();
            // if (!this.order.deliveryDate || (this.order.deliveryDate && this.order.deliveryDate === currentTime)) {
            //     startHour = 0
            //     startMinute = 0
            // }
            //    for (let hour = startHour; hour < 24; hour++) {
            let i = 0
            for (let hour = 0; hour < 24; hour++) {
                for (let minute = 0; minute < 60; minute += 30) {
                    // if (hour == startHour && startMinute > 30) {

                    // } else {
                    i = i + 1
                    const formattedHour = hour.toString().padStart(2, '0');
                    const formattedMinute = minute.toString().padStart(2, '0');
                    const time = `${formattedHour}:${formattedMinute}`;
                    let timeObject = {
                        _id: i,
                        name: time
                    }
                    intervals.push(timeObject);
                    //  }

                }
            }

            return intervals;
        },
    },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
}
</script>