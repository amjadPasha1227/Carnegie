<template>
  <div class="login_page_wrapper">

    <router-view />
    <!-- <cookiePopup v-if="!cookiesAccepted" /> -->
  </div>
</template>
  
<script>
// @ is an alias to /src
//import HelloWorld from '@/components/HelloWorld.vue'
import cookiePopup from '@/views/common/manageCookie.vue';


export default {
  name: 'before-login-layout',
  components: {
    cookiePopup,
  },
  data: () => ({

  }),
  computed: {
    cookiesAccepted() {
      // alert()
      return document.cookie.includes('cookiesAccepted=true');
    },
  },
}
</script>
  