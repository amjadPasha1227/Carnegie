<template>
    <div class="users_page_wrapper">
        <router-view/>
    </div>
  </template>
  
  <script>
  // @ is an alias to /src
  //import HelloWorld from '@/components/HelloWorld.vue'
  // import headerVue from "@/views/headerCustomer.vue"
  // import footerVue from "@/views/footer.vue"
  export default {
    name: 'users-layout',
    components: {
    },
    data: () => ({
     
    })
  }
  </script>
  