import Vue from 'vue'
import VueRouter from 'vue-router'
import _ from "lodash"
import store from '@/store'
import axios from 'axios';

Vue.use(VueRouter)

const routes = [

  {
    path: '/',
    name: 'login',
    component: () => import('@/layouts/Login.vue'),
    children: [

      {
        path: '/',
        name: 'Login View',
        meta: {
          title: 'Login',
          requiresAuth: false,

        },
        component: () => import('@/views/login.vue')
      },
      {
        path: '/login',
        name: 'Login View',
        meta: {
          title: 'Login',
          requiresAuth: false,

        },
        component: () => import('@/views/login.vue')
      },
      {
        path: '/forgotpassword',
        name: 'Forgotpassword View',
        meta: {
          title: 'Forgot Password',
          requiresAuth: false,

        },
        component: () => import('@/views/forgotPassword.vue')
      },
      {
        path: '/resetpassword',
        name: 'Resetpassword View',
        meta: {
          title: 'Reset Password',
          requiresAuth: false,

        },
        component: () => import('@/views/resetPassword.vue')
      },
      {
        path: '/public/set-password',
        name: 'Resetpassword View',
        meta: {
          title: 'Set Password',
          requiresAuth: false,

        },
        component: () => import('@/views/resetPassword.vue')
      },
      {
        path: '/createaccount',
        name: 'createaccount View',
        meta: {
          title: 'Create Account',
          requiresAuth: false,

        },
        component: () => import('@/views/createAccount.vue')
      },
     
      {
        path: '/public/reset-password',
        name: 'reset-password',
        // component: () => import('@/views/pages/setForgetPassword.vue'),
        component: () => import('@/views/resetPassword.vue'),
        meta: {
          requiresAuth: false
        }
      },
    ]
  },

  //  After Login Layout
  {
    path: '/',
    name: 'dataview',
    component: () => import('@/layouts/Main.vue'),
    children: [

      {
        path: '/dashboard',
        name: 'dashboardView',
        meta: {
          title: 'Dashboard',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/dashboard.vue')
      },
     
     
     
      {
        path: '/userdetails',
        name: 'userdetailsView',
        meta: {
          title: 'Users',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/userDetails.vue')
      },
      
      {
        path: '/restaurantdetails',
        name: 'restaurantdetailsView',
        meta: {
          title: 'Restaurant',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/restaurentDetails.vue')
      },
      {
        path: '/customerdetails',
        name: 'customerdetailsView',
        meta: {
          title: 'Customers',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/customerDetails.vue')
      },
    
     
     
     
     
     
     
      {
        path: '/client-users',
        name: 'clientUsersList',
        meta: {
          title: 'Client Users',
          requiresAuth: true,
          hideBackButton: true,
        },
        component: () => import('@/views/clientUsersList.vue')
      },
     
     
      {
        path: '/expenseslist',
        name: 'expenses-list',
        meta: {
          title: 'Expenses',
          requiresAuth: true,

        },
        component: () => import('@/views/expensesList.vue')
      },

      {
        path: '/orderlist',
        name: 'order-list',
        meta: {
          title: 'Orders',
          requiresAuth: true,

        },
        component: () => import('@/views/orderList.vue')
      },
      {
        path: '/incomelist',
        name: 'income-list',
        meta: {
          title: 'Income',
          requiresAuth: true,

        },
        component: () => import('@/views/incomeList.vue')
      },
      {
        path: '/cloverlist',
        name: 'clover-list',
        meta: {
          title: 'Orders',
          requiresAuth: true,

        },
        component: () => import('@/views/cloverorderList.vue')
      },
    ]
  },

]

const router = new VueRouter({
  base: process.env.BASE_URL,
  scrollBehavior() {
    return { x: 0, y: 0 }
  },
  mode: 'history',
  routes
})





router.beforeEach((to, from, next) => {
  const user = store.getters.getuser;


  if (to.meta.requiresAuth === false) {
    if ((['/resetpassword', '/guest-request'].indexOf(to.path) > -1 || ['/public/set-password'].indexOf(to.path) > -1 || ['/public/reset-password'].indexOf(to.path) > -1 || ['/createaccount'].indexOf(to.path) > -1) && store.getters['isLoggedIn']) {
      localStorage.removeItem('token');
      localStorage.removeItem('role_id');
      localStorage.removeItem('user');
      delete axios.defaults.headers.common['Authorization']
      store.dispatch("logout");
    }
    
    if (store.getters['isLoggedIn'] && to.path != '/dashboard') {
      next('/dashboard');
      return;
    }

  } else {


    if (store.getters['isLoggedIn']) {
      if (store.state.user['roleId'] != 9 && to.path == "/professordetails") {

        next('/dashboard')
        return
      }
      if (store.state.user['roleId'] != 15 && to.path == "/evaluationslist") {

        next('/dashboard')
        return
      }
      if (store.state.user['roleId'] == 9 && to.path != "/professordetails" && !(to.path.includes('/requestdetails/'))) {
        next('/professordetails')
        return
      }
      if (store.state.user['roleId'] == 15 && to.path != "/evaluationslist" && !to.path.includes('/requestdetails/') && !to.path.includes('/create-evaluation')) {
        next('/evaluationslist')
        return
      }

      if (store.getters['isLoggedIn'] && to.path == '/') {
        if ([5].indexOf(this.getUserRoleId) > -1) {
          next('/evaluations-list');
        } else {
          next('/dashboard');
        }
        return;
      }
      if (!store.getters['isLoggedIn'] && to.path != '/') {
        next('/');
        return;
      }
    } else {
      next('/login')
      return
    }


  }

  next()
})

router.afterEach(() => {
  if (store.state.token && store.state.user['_id']) {
    let postData = { 'accessToken': store.state.token, 'userId': store.state.user['_id'] };
    store.dispatch("loginFromAccessToken", postData).then((res) => {

    }).catch((err) => {

    });
  } else {

  }



})




export default router
