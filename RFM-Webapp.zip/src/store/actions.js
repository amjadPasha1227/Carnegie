import axios from '@/axios.js';
//import store from '@/store'
//import moment from 'moment'

import state from './state'

let restaurantId = ''
if (_.has(state, "restaurantId")) {
  restaurantId = state['restaurantId']
}


const actions = {
  loginFromAccessToken({ commit }, item) {
    if (restaurantId) {
      item = Object.assign(item, { "restaurantId": restaurantId })
    }
    return new Promise((resolve, reject) => {
      axios.post("/users/details", item)
        .then((response) => {
          const token = item['accessToken'];//response.data.result.data.accessToken
          const userRole = response.data.result.roleId;
          const user = response.data.result;
          localStorage.setItem('userRole', userRole)
          // localStorage.setItem('token', token)
          localStorage.setItem('user', JSON.stringify(user))
          localStorage.setItem('loginuserRole', userRole)
          // localStorage.setItem('loginToken', token)
          localStorage.setItem('loginUserData', JSON.stringify(user))
          localStorage.setItem('logintenantId', '')
          axios.defaults.headers.common['Authorization'] = token
          if (_.has(state, "restaurantId")) {
            restaurantId = state['restaurantId']
          }

          commit('auth_success', { accessToken: token, user: user, role_id: userRole })
          resolve(response)
        })
        .catch((error) => {
          console.log(error);
          reject(error.response.data.result)
        })
    })
  },



  login({ commit }, item) {
    return new Promise((resolve, reject) => {
      axios.post("/auth/login", item)
        .then((response) => {
          const token = response.data.result.data.accessToken;

          let postData = { 'accessToken': '' };
          postData['accessToken'] = token;
          localStorage.setItem('role_id', response.data.result.data.roleId)
          localStorage.setItem('token', token)
          localStorage.setItem('user', JSON.stringify(response.data.result.data))
          axios.defaults.headers.common['Authorization'] = token
          const user = response.data.result.data;
          commit('auth_success', user)
          resolve(response.data.result.data)
        })
        .catch((error) => {
          reject(error.response.data);
        }
        ) 
    })
  },


  logout({ commit }) {
    return new Promise((resolve) => {
      console.log(commit);
      commit('logout')
      localStorage.removeItem('token');
      localStorage.removeItem('role_id');
      localStorage.removeItem('user');
      localStorage.removeItem('restaurantId');
      delete axios.defaults.headers.common['Authorization']
      resolve()
    })
  },

  getList({ commit }, { data, path = " " }) {
    return new Promise((resolve, reject) => {
      axios.post(path, data)
        .then((response) => {
          console.log(response)
          resolve(response.data.result)
        })
        .catch((error) => {

          reject(error);

        })
    })
  },

  commonAction({ commit }, { data, path = "" }) {
    return new Promise((resolve, reject) => {
      axios.post(path, data)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          // alert(JSON.stringify(error.response.data.result));
          // alert(error.response.data.message);
          reject(error.response.data);

        })
    })
  },
  uploadS3File({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/s3/upload", postdata)
        .then((response) => {
          console.log(response);
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result.message);
          }
        })
    })
  },


  getcountries() {
    return new Promise((resolve) => {
      let item = {
        page: 1,
        perpage: 1000,
        category: "countries",
        //tenantId: "5db7d79d6032453bd060ed9c",
      };
      //if (tenantId) {
      //item = Object.assign(item, { "tenantId": tenantId })
      //  }
      axios.post("/masterdata/list", item)
        .then((response) => {
          resolve(response.data.result.list)
        });
    })
  },
  getstates({ commit }, countryId) {
    return new Promise((resolve) => {
      let item = {
        matcher: {
          countryId: countryId
        },
        page: 1,
        perpage: 1000,
        category: "states",
        //tenantId: "5db7d79d6032453bd060ed9c",
      };

      // if (tenantId) {
      //   item = Object.assign(item, { "tenantId": tenantId })
      // }
      axios.post("/masterdata/list", item)
        .then((response) => {
          //  commit('getcountries')
          resolve(response.data.result.list)
        });
    })
  },
  getlocations({ commit }, obj) {
    return new Promise((resolve) => {
      let item = {
        matcher: {
          stateId: obj.stateId
        },
        page: 1,
        perpage: 1000,
        category: "locations",
        //tenantId: "5db7d79d6032453bd060ed9c",
      };
      // if (tenantId) {
      //   item = Object.assign(item, { "tenantId": tenantId })
      // }
      axios.post("/masterdata/list", item)
        .then((response) => {
          //  commit('getlocations')
          resolve(response.data.result.list)
        });
    })
  },
  addLocations({ commit }, obj) {
    return new Promise((resolve) => {
      let item = {
        page: 1,
        perpage: 1000,
        stateId: obj.stateId,
        name: obj.name,
        category: "locations",
        // tenantId: "5db7d79d6032453bd060ed9c",
      };

      // if (tenantId) {
      // item = Object.assign(item, { "tenantId": tenantId })
      // }
      axios.post("/masterdata/add", item)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  getMasterData({ commit }, category = '') {
    return new Promise((resolve) => {
      let item = {
        matcher: {
        },
        page: 1,
        perpage: 1000,
        category: category//"user_departments","customer_types","user_roles"
      };
      axios.post("/masterdata/list", item)
        .then((response) => {
          //  commit('getlocations')
          resolve(response.data.result.list)
        });
    })
  },

  getDepartments({ commit }) {
    return new Promise((resolve) => {
      let item = {
        matcher: {
        },
        page: 1,
        perpage: 1000,
        category: "user_departments",
      };
      axios.post("/masterdata/list", item)
        .then((response) => {
          //  commit('getlocations')
          resolve(response.data.result.list)
        });
    })
  },
  userregister({ commit }, postdata) {

    // if(tenantId){
    //   postdata = Object.assign( postdata ,{"tenantId":tenantId})
    // }
    return new Promise((resolve, reject) => {
      axios.post("/users/register", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  userUpdate({ commit }, postdata) {

    // if(tenantId){
    //   postdata = Object.assign( postdata ,{"tenantId":tenantId})
    // }
    return new Promise((resolve, reject) => {
      axios.post("/users/update", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  getUsersList({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/users/list", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },


  getUserDetails({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/users/details", postdata)
        .then((response) => {
          resolve(response.data)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  createCustomer({ commit }, postdata) {

    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/customer/create", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  updateCustomer({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/customer/update", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  getcustomerList({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/customer/list", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  getCustomerDetails({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/customer/details", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },


  getEmailsList({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post("/email-template/list", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },

  getSignedUrl({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("s3/get-signed-url", postdata)
        .then((response) => {
          console.log(response);
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },
  pdftoword({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("convert/pdf-to-word", postdata, {
        responseType: 'blob',
      }).then((response) => {
        console.log(response);
        resolve(response)
      })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },



  getStatsCount({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post("/dashboard/stats-count", postdata)
        .then((response) => {
          resolve(response.data)

        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  getTopFiveEvaluations({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post("/dashboard/top-five-evaluations", postdata)
        .then((response) => {
          resolve(response.data)

        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  showMostHandledCases({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post("/dashboard/most-cases-handled", postdata)
        .then((response) => {
          resolve(response.data)

        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  getStatsChartView({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post("/dashboard/stats-chart-view", postdata)
        .then((response) => {
          resolve(response.data)

        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },


  forgot_password({ commit }, item) {
    return new Promise((resolve) => {
      axios.post("/auth/forgot-password", item)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => { resolve(error.response) })
    })
  },
  updatePassword({ commit }, item) {

    return new Promise((resolve) => {
      axios.post("/auth/update-password", item)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => { resolve(error.response) })
    })
  },



  getFilteredStatsChartView({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post("/dashboard/stats-chart", postdata)
        .then((response) => {
          resolve(response.data)

        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },


  getDueTodayEvaluations({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post("dashboard/due-today", postdata)
        .then((response) => {
          resolve(response)

        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },

  signupCustomer({ commit }, postdata) {

    // if(tenantId){
    //   postdata = Object.assign( postdata ,{"tenantId":tenantId})
    // }
    return new Promise((resolve, reject) => {
      axios.post("/auth/signup", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },



  downloadAllFiles({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post("/s3/get-zipped-files", postdata, {
        responseType: 'blob',
      })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },


  expenseCreate({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/expense/create", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  getExpensesList({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/expense/list", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },

  orderCreate({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/order/create", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  getOrdersList({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/order/list", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  addMasterData({ commit }, obj) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve) => {
      let item = {
        page: 1,
        perpage: 1000,
        name: obj.name,
        category: "expenses_nature",
        // tenantId: "5db7d79d6032453bd060ed9c",
      };

      // if (tenantId) {
      // item = Object.assign(item, { "tenantId": tenantId })
      // }
      axios.post("/masterdata/add", item)
        .then((response) => {
          resolve(response.data.result)
        });
    })
  },
  getCloverOrdersList({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/clover/list", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  incomeCreate({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/income/create", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  getIncomeList({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/income/list", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  getDetails({ commit }, { data, path = "" }) {
    if (localStorage.getItem('restaurantId')) {
      data = Object.assign(data, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post(path, data)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  addRestaurant({ commit }, postdata) {

    return new Promise((resolve, reject) => {
      axios.post("/createrestaurant", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  getRestaurantList({ commit }, postdata) {

    // if(tenantId){
    //   postdata = Object.assign( postdata ,{"tenantId":tenantId})
    // }
    return new Promise((resolve, reject) => {
      axios.post("/restaurantlist", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  expenseUpdate({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/expense/update", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  incomeUpdate({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/income/update", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  orderUpdate({ commit }, postdata) {
    if (localStorage.getItem('restaurantId')) {
      postdata = Object.assign(postdata, { "restaurantId": localStorage.getItem('restaurantId') })
    }
    return new Promise((resolve, reject) => {
      axios.post("/order/update", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },
  getDashboardStats({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post("/dashboard/stats-count", postdata)
        .then((response) => {
          resolve(response.data.result)

        })
        .catch((error) => {
          reject(error.response.data.message);

        })
    })
  },

}

export default actions;
