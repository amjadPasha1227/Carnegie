import axios from 'axios'
import store from '@/store/store';
import _ from 'lodash';

let domain;
if (process.env.NODE_ENV !== 'production') {
    domain = process.env.VUE_APP_SUBAPI_URL + "/";
} else {
    domain = process.env.VUE_APP_SUBAPI_URL;
}



const instance = axios.create({
    baseURL: domain
    // You can add your headers here
})

instance.interceptors.request.use(function (config) {
    const token = store.state.token;
    if (token != null) {
        config.headers.Authorization = "Bearer uS1SkJFxLKgJito+K0K1EwrNWTBvyiVWvM7BaQDXCdxqCvAv";
    }
    return config;
}, function (err) {
    return Promise.reject(err);
});


const actions = {
    //masterdata/list
    getMaterData({ commit }, payLoad) {
        
        return new Promise((resolve, reject) => {
            instance.post("masterdata/list", payLoad)
                .then(res => {

                    resolve(res.data.result);
                })
                .catch(err => {
                    reject(err.response.data.result.error_message.message);
                })
        });

    },
    subscribe({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/plans/subscribe", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    upgradeplan({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/plans/upgrade", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    attachpaymentmethod({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/billing/attach-payment-method", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    chargeforplan({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/billing/charge-for-plan", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    getplans({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/plans/list-for-end-users", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    cardDetails({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/billing/get-payment-methods", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    getSelectedPlan({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/plans/get-selected-plan", data)
                .then((response) => {
                    commit("loading", false);
                    let data = _.orderBy(response.data.result, 'invoiceDetails', 'asc');
                    commit("UPDATE_SUBSCRIPTIONS",data)
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    resolve(error);
                })
        })
    },
    cancelPlan({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/plans/cancel", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },
    getList({ commit }, { data, path = "/plans/testing" }) {

        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post(path, data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })
    },

    createCupon({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/coupons/create", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);
                    reject(error.response.data.result);
                })
        })

    },

    validateCupon({ commit }, data) {
        commit("loading", true);
        return new Promise((resolve, reject) => {
            instance.post("/coupons/validate", data)
                .then((response) => {
                    commit("loading", false);
                    resolve(response.data.result)
                })
                .catch((error) => {
                    commit("loading", false);

                    reject(error.response.data.result.error_message.message);
                })
        })

    },
    ///invoices/get-document
   ///invoices/get-document
   getInvoices({ commit }, data) {
    commit("loading", true);
    return new Promise((resolve, reject) => {
        //instance.config.headers.responseType="arraybuffer";
        //instance.config.headers.responseType ="arraybuffer"
       // instance.defaults.headers.post['responseType'] = 'arraybuffer'
        //alert(JSON.stringify(data));
        instance.post("/invoices/get-document", data)
            .then((response) => {
                commit("loading", false);
                resolve(response)
            })
            .catch((error) => {
                commit("loading", false);

                reject(error.response.data.result.error_message.message);
            })
    })

}


}

export default actions
