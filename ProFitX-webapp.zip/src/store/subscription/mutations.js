const mutations = {
    loading(state ,value){
     // state.show_loading =value;

  },
  UPDATE_SUBSCRIPTIONS(state,data){
    state.subscriptions = data
  },
}

export default mutations
