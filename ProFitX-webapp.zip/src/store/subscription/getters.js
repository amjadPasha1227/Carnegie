


const getters = {
    getSubscriptions: state => state?state.subscriptions:null
}

export default getters