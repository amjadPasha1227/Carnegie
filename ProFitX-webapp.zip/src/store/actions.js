import axios from '@/axios.js';
import _ from "lodash";
import allTeams from "@/data/teams.json";
import allPlayers from "@/data/players.json";

console.log(process.env)
var _APIBASE = process.env.VUE_APP_AI_URL;
//_APIBASE = "http://localhost:8988/"
//_APIBASE =  "https://qa.profitx.ai/api/";
var _APIBASEPROD = process.env.VUE_APP_API_URL+"/api/";

if (process.env.NODE_ENV == 'production') {
  _APIBASEPROD = process.env.VUE_APP_API_URL+"/api/";
} 

const actions = {

  getmasterdata({ commit }, type) {
    return new Promise((resolve) => {
      const item = {
        page: 1,
        perpage: 1000,
        category: type,
        tenantId: "5db7d79d6032453bd060ed9c",
      };
      axios.post("/masterdata/list", item)
        .then((response) => {
          resolve(response.data.result.list)
        });
    })
  },
  getusefav({ commit }, postdata) {

    return new Promise((resolve, reject) => {
      //
      axios.post('/users/get-favlist', postdata)
        .then((response) => {
          const dt = response.data.result
          resolve(dt)
        })
        .catch((error) => {
          reject(error)

        })
    })

  },
  addTofav({ commit }, postdata) {

    return new Promise((resolve, reject) => {
      //
      axios.post('/users/add-to-fav', postdata)
        .then((response) => {
          const dt = response.data.result
          resolve(dt)
        })
        .catch((error) => {
          const dt = error.response.data.result.error_message
          reject(dt)

        })
    })

  },
  removeFromfav({ commit }, postdata) {

    return new Promise((resolve, reject) => {
      //
      axios.post('/users/remove-fav', postdata)
        .then((response) => {
          const dt = response.data.result
          resolve(dt)
        })
        .catch((error) => {
          const dt = error.response.data.result.error_message
          reject(dt)

        })
    })

  },
  ///users/activate
  userActivate({ commit }, postdata) {

    return new Promise((resolve, reject) => {
      //
      axios.post('/users/manage-status', postdata)
        .then((response) => {
          const dt = response.data.result
          resolve(dt)
        })
        .catch((error) => {
          const dt = error.response.data.result.error_message
          reject(dt)

        })
    })

  },

  userRegister({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post('/auth/signup', postdata)
        .then((response) => {
          const dt = response.data.result
          resolve(dt)
        })
        .catch((error) => {
          const dt = error.response.data.result.error.message
          reject(dt)

        })
    })
  },
  registerNewUser({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post('/users/register', postdata)
        .then((response) => {
          const dt = response.data.result
          resolve(dt)
        })
        .catch((error) => {
          const dt = error.response.data.result.error.message
          reject(dt)

        })
    })
  },


  userCreate({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post('/users/create', postdata)
        .then((response) => {
          const dt = response.data.result
          resolve(dt)
        })
        .catch((error) => {
          const dt = error.response.data.result.error
          reject(dt)
        })
    })
  },
  updateProfilePassword({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      //
      axios.post('/users/update-password', postdata)
        .then((response) => {
          const dt = response.data.result
          resolve(dt)
        })
        .catch((error) => {
          const dt = error.response.data.result.error.message
          reject(dt)

        })
    })
  },

  updateUserPassword({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      //
      axios.post('/auth/reset-password', postdata)
        .then((response) => {
          const dt = response.data.result
          resolve(dt)
        })
        .catch((error) => {
          const dt = error.response.data.result.error_message
          reject(dt)

        })
    })

  },
  ///auth/update-password

  updatePassword({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      //
      axios.post('/auth/update-password', postdata)
        .then((response) => {
          const dt = response.data.result
          resolve(dt)
        })
        .catch((error) => {
          const dt = error.response.data.result.error.message
          reject(dt)

        })
    })

  },

  //updateUserPassword
  getUsersList({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/users/list", postdata)
        .then((response) => {
          resolve(response['data']['result'])
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getplayers({ commit }, postdata) {
    return new Promise((resolve) => {
      
      axios.post("/players/list", postdata, { baseURL: _APIBASEPROD })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getplayersMasterList({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/players/masterlist", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getplayerdetails({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/players/playersdetails", postdata, { baseURL: _APIBASEPROD })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getshots({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/players/shots", postdata, { baseURL: _APIBASEPROD })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getRealtimeCommentary({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/realtimecommentory", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response.data.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data);

          }

        })
    })
  },
  
  getRealtimeindex({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/realtimetrajectory", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getAttributes({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/attributes", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getplayerroles({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/playerrolesgroup", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getplayerrolesbyplayer({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/playerrolesbyplayer", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getTendencies({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/tendecies", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getStarSystem({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/starsystem", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getpimpact({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/pimpact", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },


  getPerformance({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/performance", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getFinacialimpact({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/financialimpactnew", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getTeamfit({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/teamfitnew", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getproxtial({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/proxtial", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getOppurtunitytime({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/oppurtunitytime", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getOppurtunity({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/oppurtunitynmodel", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getTradeassets({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/tradeassets", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  top5picks({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/top5picks", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  }, dashboardstats({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/dashboarddata", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  }, dashboardstatstop({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/dashboarddatatop", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  }, dashboarddatatopfa({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/dashboarddatatopfa", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  }, topperformaerroles({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/topperformaerroles", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getawards({ commit }, playerId) {
    return new Promise((resolve) => {
      

      axios.post("/players/awards", { PLAYER_ID: playerId })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getsynergy({ commit }, playerId) {
    return new Promise((resolve) => {
      var url = "/players/runsynergy?PLAYER_ID=" + playerId;
      

      axios.get(url)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  }, getseasonsdata({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/playerstats", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getInjury({ commit }, player) {
    return new Promise((resolve) => {
      
      var url = "/players/getinjury?PLAYER_ID=" + player.playerid + "&Season=" + player.season;
      

      axios.get(url)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getProfitImpact({ commit }, postdata) {
    return new Promise((resolve) => {
      
      axios.post("/players/profitimpact", postdata, { baseURL: _APIBASEPROD })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  }, logout({ commit }) {
    return new Promise((resolve) => {

      let user = JSON.parse(localStorage.getItem('user'));
      let postdata = {"userId":user._id ,"loginSessionId":user.lastLogInId};
      axios.post("/users/logout", postdata)
        .then((response) => {
          commit('logout')
          localStorage.removeItem('token');
          localStorage.removeItem('userRole');
          localStorage.removeItem('user');
          delete axios.defaults.headers.common['Authorization']
          resolve()
        })
        .catch((error) => {
          commit('logout')
          localStorage.removeItem('token');
          localStorage.removeItem('userRole');
          localStorage.removeItem('user');
          delete axios.defaults.headers.common['Authorization']
          resolve()

        })

     
    })
  },
  //auth/set-verificationcode
  setVerificationcode({ commit }, item) {
    return new Promise((resolve ,reject) => {
      axios.post("/auth/set-verificationcode", item)
        .then((response) => {
          
          resolve(response)

        })
        .catch((error) => {
          
          reject(error.response.data.result);
        })
    })
  },

  login({ commit }, item) {
    return new Promise((resolve) => {
      let localDeviceId = localStorage.getItem("localDeviceId");
      if(localDeviceId){
        item = Object.assign(item ,{ "userDeviceId":localDeviceId})
      }
      axios.post("/auth/login", item)
        .then((response) => {
         
          console.log(JSON.stringify(response.data.result.data));
          if (response.data.result.data) {
           

            let token = response.data.result.data.accessToken;
            let userRole = response.data.result.data.roleId;
            let user = response.data.result.data;
            
            response = Object.assign(response ,{ "response":user.lastLogInClosed});
            
          
            
            //response.allowLogin = true;
            //response.otpRequired =false;
           

             // if(user.lastLogInClosed || [1,2,3].indexOf(userRole)>-1){
           
                 // localStorage.setItem( "localDeviceId",user.userDevice["deviceId"]);
                  user['userRole'] = userRole;
                  user['profilePicture'] = user['profilePicture'] ? user['profilePicture'] : '';

                  if (!user['phoneNo']) {
                  Object.assign(user, { "phoneNo": '' });
                  }
                  if (!user['phoneCode']) {
                  Object.assign(user, { "phoneCode": '' });
                  }
                  //lastLogInId
                  localStorage.setItem('lastLogInId', user["lastLogInId"])
                  localStorage.setItem('userRole', userRole)
                  localStorage.setItem('token', token)
                  localStorage.setItem('loggedin', new Date())
                  localStorage.setItem('user', JSON.stringify(user))


                  axios.defaults.headers.common['Authorization'] = token
                  commit('auth_success', { token: token, user: user, userRole: userRole });
                  resolve(user)

           
            
            

          } else {

            resolve(response.data.result)


          }



        })
        .catch((error) => {
          
          resolve(error.response.data.result)
        })
    })
  }, forgotpassword({ commit }, item) {
    return new Promise((resolve) => {
      axios.post("/auth/forgot-password", item)
        .then((response) => {
          resolve(response)

        })
        .catch((error) => {
          
          resolve(error.response.data.result)
        })
    })
  }, setpassword({ commit }, item) {
    return new Promise((resolve) => {
      axios.post("/auth/update-password", item)
        .then((response) => {
          resolve(response)

        })
        .catch((error) => {
          
          resolve(error.response.data.result)
        })
    })
  },

  updateProfile({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      //
      axios.post('/user/update-profile', postdata)
        .then((response) => {
          const dt = response.data.result

          let userRole = localStorage.getItem('userRole');
          let token = localStorage.getItem('token');
          let user = JSON.parse(localStorage.getItem('user'));
          user['firstName'] = postdata['firstName'];
          user['middleName'] = postdata['middleName'];
          user['lastName'] = postdata['lastName'];
          user['name'] = postdata['firstName'] + ' ' + postdata['lastName'];
          user['phoneNo'] = postdata['phoneNo'];
          user['phoneCode'] = postdata['phoneCode'];
          localStorage.setItem('user', JSON.stringify(user))
          commit('auth_success', { token: token, user: user, userRole: userRole })
          resolve(dt)
        })
        .catch((error) => {
          const dt = error.response.data.result.error_message
          reject(dt)

        })
    })

  },
  //updateProfileDetails
  updateProfilePicture({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      //
      axios.post('/users/update-profile-picture', postdata)
        .then((response) => {
          const dt = response.data.result
          let userRole = localStorage.getItem('userRole');
          let token = localStorage.getItem('token');
          let user = JSON.parse(localStorage.getItem('user'));
          user['profilePicture'] = postdata['profilePicture'];
          localStorage.setItem('user', JSON.stringify(user))
          commit('auth_success', { token: token, user: user, userRole: userRole })
          resolve(dt)
        })
        .catch((error) => {
          const dt = error.response.data.result.error_message
          reject(dt)

        })
    })

  },

  uploadS3File({ commit }, postdata) {
    return new Promise((resolve) => {
      commit("loading", true);
      axios.post("/s3/upload", postdata)
        .then((response) => {
          commit("loading", false);
          resolve(response)
        })
        .catch((error) => {
          commit("loading", false);
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },
  getSignedUrl({ commit }, postdata) {
    
    return new Promise((resolve) => {
      axios.post("s3/get-signed-url", postdata)
        .then((response) => {
          
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },

  //support-tickets/create 
  supportTicketsCreate({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post("/support-tickets/create", postdata)
        .then((response) => {
          
          resolve(response.data.result)
        })
        .catch((err) => {
          reject(err.response.data.message)
        });
    })
  },
  // http://localhost:8989/support-tickets/update

  supportTicketsUpdate({ commit }, postdata) {
    return new Promise((resolve, reject) => {
      axios.post("/support-tickets/update", postdata)
        .then((response) => {
          
          resolve(response.data.result)
        })
        .catch((err) => {
          reject(err.response.data.message)
        });
    })
  },

  //support-tickets/list
  supportTicketsList({ commit }, postData) {
    return new Promise((resolve) => {
      axios.post("/support-tickets/list", postData)
        .then((response) => {
          //alert(JSON.stringify(response.data.result));
          resolve(response.data.result)
        })
        .catch((error) => {

          if (error.response) {
            resolve(error);

          }

        })
    })
  },
  //support-tickets/assign
  supportTicketsAssign({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/support-tickets/assign", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },
  //support-tickets/update
  supportTicketupdate({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/support-tickets/update", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },
  //support-tickets/details
  supportTickesDetails({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/support-tickets/details", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },

  supportTickeCommentList({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/support-tickets/comment-list", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },

  //support-tickets/assign
  supportTicketsComment({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/support-tickets/comment", postdata)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);
          }
        })
    })
  },
  getuserDetails({ commit }, postdata) {
    return new Promise((resolve,reject) => {
      axios.post("/auth/details", postdata)
        .then((response) => {
          let data = {
            user: response.data.result.result,
            userRole: response.data.result.result.roleId[0],
            widgetpermissions: response.data.result.result.widgets,
            subscription:response.data.result.result.subscription,
          };
          commit('UPDATE_USER_DETAILS', data)

          resolve(response.data.result)
        })
        .catch((error) => {
          if (error.response) {
            reject(error.response)
          }
        })
    })
  },

  //updateAthlets
  updateAthlets({ commit }, postdata) {
    
    return new Promise((resolve, reject) => {
      //
      axios.post('/subscription/update-athlets', postdata)
        .then((response) => {
          const dt = response.data.result
          resolve(dt)
        }).catch((error) => {
          const dt = error.response.data.result.error.message
          reject(dt)

        })
    })

  },

  //updateAthlets
  updatePaymentstatus({ commit }, postdata) {
    
    return new Promise((resolve, reject) => {
      //
      axios.post('/subscription/update-payment-status', postdata)
        .then((response) => {
          const dt = response.data.result;
          commit('UPDATE_USER_PAYMENT_STATUS', 2)

          resolve(dt)
        }).catch((error) => {
          const dt = error.response.data.result.error_message
          reject(dt)

        })
    })

  },
  unsubscribetoemaillist({ commit }, item) {
    return new Promise((resolve, reject) => {
      axios.post("/users/unsubscribe", item)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          reject(error.response.data.result)
        })
    })
  },
  subscribetoemaillist({ commit }, item) {
    return new Promise((resolve, reject) => {
      axios.post("/users/subscribe", item)
        .then((response) => {
          resolve(response.data.result)
        })
        .catch((error) => {
          
          reject(error.response.data.result)
        })
    })
  },
  enquirySubmit({ commit }, item) {
    return new Promise((resolve, reject) => {
      axios.post("/enquiry/create", item)
        .then((response) => {
          resolve(response.data.result)


        })
        .catch((error) => {
          
          reject(error.response.data.result)
        })
    })
  },
  // Enquires List
  enquiresList({ commit }, postData) {
    return new Promise((resolve) => {
      axios.post("/enquiry/list", postData)
        .then((response) => {
          //alert(JSON.stringify(response.data.result));
          resolve(response.data.result)
        })
        .catch((error) => {

          if (error.response) {
            resolve(error);

          }

        })
    })
  },
  seacrhSynergy({ commit }, postdata) {
    return new Promise((resolve) => {
      axios.post("/synergysearch", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getAllPlayersList({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/players/get-all-players", postdata)
        .then((response) => {
          resolve(response)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  gettodayprobability({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/probability", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response.data.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  gettodayprobability2({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/probabilityv2", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response.data.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getprobabilitydetailsv2({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/probabilitydetailsv2", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response.data.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getodds({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/noddslist", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response.data.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  }
  ,
  getcurrentgame({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/currentgame", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response.data.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  hometeadf({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/hometeadf", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response.data.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
   //getPolsList
   getPolsList({ commit }, postData) {
    return new Promise((resolve ,reject) => {
      axios.post("/polls/list", postData)
        .then((response) => {
         
         let result = _.cloneDeep(response.data.result);

         let  list =result['list']
        // this.pollsList
        let tempList = [];
        _.forEach(list, (item)=>{
            //find Oprion1 percentage
                
            item = Object.assign(item,{"option1Percentage":0 , "option1votedByme":false ,'option1voteCount':0 ,"option1Image":'' });
            item = Object.assign(item,{"option2Percentage":0 , "option2votedByme":false ,"option2voteCount":0 ,"option2Image":'' });
            item = Object.assign(item,{"option3Percentage":0 , "option3votedByme":false ,"option3voteCount":0 ,"option3Image":'' });
            item = Object.assign(item,{"option4Percentage":0 , "option4votedByme":false ,"option4voteCount":0 ,"option4Image":'' });
            item = Object.assign(item,{"option5Percentage":0 , "option5votedByme":false ,"option5voteCount":0 ,"option5Image":'' });
            item = Object.assign(item,{"option6Percentage":0 , "option6votedByme":false ,'option6voteCount':0 ,"option6Image":'' }); 

            item = Object.assign(item,{ "playerImage":''})
              item = Object.assign(item,{ "teamImage":''})
            if(_.has(item ,'playerList') && item['playerList'].length>0 ){


                let playerData =  _.find(allPlayers ,{"PLAYER_NAME":item['playerList'][0]});
               
                if(playerData && _.has(playerData ,"PLYER_ID")){

                    item['playerImage'] = "https://profitx.ai/api/viewfile?path=playerimages/"+playerData['PLYER_ID']+".png"

                  //find team Image based on player team

                  let teamData =  _.find(allTeams,{"PLYER_ID":playerData['PLYER_ID']});
                  if(teamData && _.has(teamData ,"TEAM_ID")){
                      item['teamImage'] = "https://profitx.ai/api/viewfile?path=teams/"+teamData['TEAM_ID']+".png"
                  }



                }

            }  

            if(_.has(item ,"option1" ) && item['option1'].length>0){
                let option1 = item['option1'];

               if( _.has(item , 'optionTypeId') && item['optionTypeId'] ==1){ // 1. Team Option
                  let teamData =  _.find(allTeams,{"TEAM_NAME":option1[0]});
                  if(teamData && _.has(teamData ,"TEAM_ID")){
                      item['option1Image'] = "https://profitx.ai/api/viewfile?path=teams/"+teamData['TEAM_ID']+".png"
                  }

               }
             
                if( _.has(item , 'optionTypeId') && item['optionTypeId'] ==2){ // 2. Player Option
                  let playerData =  _.find(allPlayers ,{"PLAYER_NAME":option1[0]});
                 
                  if(playerData && _.has(playerData ,"PLYER_ID")){
                      item['option1Image'] = "https://profitx.ai/api/viewfile?path=playerimages/"+playerData['PLYER_ID']+".png"
                  }

              }
               
            

                 
                
                
                if(_.has(item ,'selfVoting') && item['selfVoting'].length>0) {
                    
                    if(item['selfVoting'][0]['opinion'][0] ==option1[0] ){
                        item = Object.assign(item,{"option1votedByme":true});

                }
                }
                
                _.forEach(item['votingStats'] , (vote)=>{
                    
                    if(option1[0] ==vote['_id'][0]){
                        let percentage = ((vote['count']/item['totalVotings'])*100);
                        if(percentage<100){
                          percentage = percentage.toFixed(2);

                        }
                        item['option1Percentage']= percentage
                        item['option1voteCount']=vote['count'];

                        return false;

                    }

                })
                
            }
            if(_.has(item ,"option2" ) && item['option2'].length>0){
                let option1 = item['option2'];

                if( _.has(item , 'optionTypeId') && item['optionTypeId'] ==1){ // 1. Team Option
                  let teamData =  _.find(allTeams,{"TEAM_NAME":option1[0]});
                  if(teamData && _.has(teamData ,"TEAM_ID")){
                      item['option2Image'] = "https://profitx.ai/api/viewfile?path=teams/"+teamData['TEAM_ID']+".png"
                  }

               }else if( _.has(item , 'optionTypeId') && item['optionTypeId'] ==2){ // 2. Player Option
                  let playerData =  _.find(allPlayers ,{"PLAYER_NAME":option1[0]});
                  if(playerData && _.has(playerData ,"PLYER_ID")){
                      item['option2Image'] = "https://profitx.ai/api/viewfile?path=playerimages/"+playerData['PLYER_ID']+".png"
                  }

              }
              
                if(_.has(item ,'selfVoting') && item['selfVoting'].length>0) {
                    
                    if(item['selfVoting'][0]['opinion'][0] ==option1[0] ){
                        item = Object.assign(item,{"option2votedByme":true});

                }
                }
                
                _.forEach(item['votingStats'] , (vote)=>{
                    
                    if(option1[0] ==vote['_id'][0]){
                      let percentage = ((vote['count']/item['totalVotings'])*100);
                      if(percentage<100){
                        percentage = percentage.toFixed(2);

                      }  
                        item['option2Percentage']= percentage
                        item['option2voteCount']=vote['count'];

                        return false;

                    }

                })
                
            }
            if(_.has(item ,"option3" ) && item['option3'].length>0){
                let option1 = item['option3'];

                if( _.has(item , 'optionTypeId') && item['optionTypeId'] ==1){ // 1. Team Option
                  let teamData =  _.find(allTeams,{"TEAM_NAME":option1[0]});
                  if(teamData && _.has(teamData ,"TEAM_ID")){
                      item['option3Image'] = "https://profitx.ai/api/viewfile?path=teams/"+teamData['TEAM_ID']+".png"
                  }

               }else if( _.has(item , 'optionTypeId') && item['optionTypeId'] ==2){ // 2. Player Option
                  let playerData =  _.find(allPlayers ,{"PLAYER_NAME":option1[0]});
                  if(playerData && _.has(playerData ,"PLYER_ID")){
                      item['option3Image'] = "https://profitx.ai/api/viewfile?path=playerimages/"+playerData['PLYER_ID']+".png"
                  }

              }
              
                if(_.has(item ,'selfVoting') && item['selfVoting'].length>0) {
                    
                    if(item['selfVoting'][0]['opinion'][0] ==option1[0] ){
                        item = Object.assign(item,{"option3votedByme":true});

                }
                }
                
                _.forEach(item['votingStats'] , (vote)=>{
                    
                    if(option1[0] ==vote['_id'][0]){
                        
                      let percentage = ((vote['count']/item['totalVotings'])*100);
                      if(percentage<100){
                        percentage = percentage.toFixed(2);

                      }  
                        item['option3Percentage']=  percentage;
                        item['option3voteCount']=vote['count'];

                        return false;

                    }

                })
                
            }
            if(_.has(item ,"option4" )  && item['option4'].length>0){
                let option1 = item['option4'];

                if( _.has(item , 'optionTypeId') && item['optionTypeId'] ==1){ // 1. Team Option
                  let teamData =  _.find(allTeams,{"TEAM_NAME":option1[0]});
                  if(teamData && _.has(teamData ,"TEAM_ID")){
                      item['option4Image'] = "https://profitx.ai/api/viewfile?path=teams/"+teamData['TEAM_ID']+".png"
                  }

               }else if( _.has(item , 'optionTypeId') && item['optionTypeId'] ==2){ // 2. Player Option
                  let playerData =  _.find(allPlayers ,{"PLAYER_NAME":option1[0]});
                  if(playerData && _.has(playerData ,"PLYER_ID")){
                      item['option4Image'] = "https://profitx.ai/api/viewfile?path=playerimages/"+playerData['PLYER_ID']+".png"
                  }

              }
                
                if(_.has(item ,'selfVoting')&& item['selfVoting'].length>0) {
                    
                    if(item['selfVoting'][0]['opinion'][0] ==option1[0] ){
                        item = Object.assign(item,{"option4votedByme":true});

                }
                }
                
                _.forEach(item['votingStats'] , (vote)=>{
                    
                    if(option1[0] ==vote['_id'][0]){

                      let percentage = ((vote['count']/item['totalVotings'])*100);
                      if(percentage<100){
                        percentage = percentage.toFixed(2);

                      } 
                        
                        item['option4Percentage']=  percentage
                        item['option4voteCount']=vote['count'];

                        return false;

                    }

                })
                
            }
            if(_.has(item ,"option5" )  && item['option5'].length>0){
            let option1 = item['option5'];

            if( _.has(item , 'optionTypeId') && item['optionTypeId'] ==1){ // 1. Team Option
              let teamData =  _.find(allTeams,{"TEAM_NAME":option1[0]});
              if(teamData && _.has(teamData ,"TEAM_ID")){
                  item['option5Image'] = "https://profitx.ai/api/viewfile?path=teams/"+teamData['TEAM_ID']+".png"
              }

           }else if( _.has(item , 'optionTypeId') && item['optionTypeId'] ==2){ // 2. Player Option
              let playerData =  _.find(allPlayers ,{"PLAYER_NAME":option1[0]});
              if(playerData && _.has(playerData ,"PLYER_ID")){
                  item['option5Image'] = "https://profitx.ai/api/viewfile?path=playerimages/"+playerData['PLYER_ID']+".png"
              }

          }
           
            
            if(_.has(item ,'selfVoting') && item['selfVoting'].length>0) {
                
                if(item['selfVoting'][0]['opinion'][0] ==option1[0] ){
                    item = Object.assign(item,{"option5votedByme":true});

            }
            }

            _.forEach(item['votingStats'] , (vote)=>{
                
                if(option1[0] ==vote['_id'][0]){

                  let percentage = ((vote['count']/item['totalVotings'])*100);
                      if(percentage<100){
                        percentage = percentage.toFixed(2);

                      } 
                    
                    item['option5Percentage']=  percentage
                    item['option5voteCount']=vote['count'];

                    return false;

                }

            })

            }
            if(_.has(item ,"option6" ) && item['option6'].length>0){
                let option1 = item['option6'];

                if( _.has(item , 'optionTypeId') && item['optionTypeId'] ==1){ // 1. Team Option
                  let teamData =  _.find(allTeams,{"TEAM_NAME":option1[0]});
                  if(teamData && _.has(teamData ,"TEAM_ID")){
                      item['option6Image'] = "https://profitx.ai/api/viewfile?path=teams/"+teamData['TEAM_ID']+".png"
                  }
    
               }else if( _.has(item , 'optionTypeId') && item['optionTypeId'] ==2){ // 2. Player Option
                  let playerData =  _.find(allPlayers ,{"PLAYER_NAME":option1[0]});
                  if(playerData && _.has(playerData ,"PLYER_ID")){
                      item['option6Image'] = "https://profitx.ai/api/viewfile?path=playerimages/"+playerData['PLYER_ID']+".png"
                  }
    
              }
                
                if(_.has(item ,'selfVoting') && item['selfVoting'].length>0) {
                    
                    if(item['selfVoting'][0]['opinion'][0] ==option1[0] ){
                        item = Object.assign(item,{"option6votedByme":true});

                }
                }
                
                _.forEach(item['votingStats'] , (vote)=>{
                    
                    if(option1[0] ==vote['_id'][0]){
                        
                        item['option6Percentage']=  ((vote['count']/item['totalVotings'])*100).toFixed(2);
                        item['option6voteCount']=vote['count'];

                        return false;

                    }

                })
                
            }
        
            tempList.push(item)



         });
        result['list'] =tempList;
         resolve(result)
        })
        .catch((error) => {

          if (error.response) {
            reject(error.response.data.result);

          }

        })
    })
  },
  getPolDetails({ commit }, postData) {
    return new Promise((resolve ,reject) => {
      axios.post("/polls/details", postData)
        .then((response) => {
          //alert(JSON.stringify(response.data.result));
          resolve(response.data.result)
        })
        .catch((error) => {

          if (error.response) {
            reject(error.response.data.result);

          }

        })
    })
  },
  //polls/submit-voting

  submitVoting({ commit }, postData) {
    return new Promise((resolve ,reject) => {
      axios.post("/polls/submit-voting", postData)
        .then((response) => {
          //alert(JSON.stringify(response.data.result));
          resolve(response.data.result)
        })
        .catch((error) => {

          if (error.response) {
            reject(error.response.data.result.error);

          }

        })
    })
  },
  deletingVoting({ commit }, postData) {
    return new Promise((resolve ,reject) => {
      axios.post("/polls/delete-voting", postData)
        .then((response) => {
          //alert(JSON.stringify(response.data.result));
          resolve(response.data.result)
        })
        .catch((error) => {

          if (error.response) {
            reject(error.response.data.result);

          }

        })
    })
  },

  //polls/get-stats-by-user
  getPollsstatsByUser({ commit }, postData) {
    return new Promise((resolve ,reject) => {
      axios.post("/polls/get-stats-by-user", postData)
        .then((response) => {
          //alert(JSON.stringify(response.data.result));
          resolve(response.data.result)
        })
        .catch((error) => {

          if (error.response) {
            reject(error.response.data.result);

          }

        })
    })
  },
  //polls/share
  pollsShare({ commit }, postData) {
    return new Promise((resolve ,reject) => {
      axios.post("/polls/share", postData)
        .then((response) => {
          //alert(JSON.stringify(response.data.result));
          resolve(response.data.result)
        })
        .catch((error) => {

          if (error.response) {
            reject(error.response.data.result);

          }

        })
    })
  },
  getHomepageOdds({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/probabilityhome", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response.data.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getTopshooters({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/topshooters", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response.data.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getTopPerfomers({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/toppeformers", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response.data.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  },
  getStockrisers({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/stockrisers", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response.data.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  }, getHiddengems({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/hiddengems", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response.data.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  }, getoutlookplayers({ commit }, postdata) {
    return new Promise((resolve) => {
      

      axios.post("/outlookplayers", postdata, { baseURL: _APIBASE })
        .then((response) => {
          resolve(response.data.data)
        })
        .catch((error) => {
          if (error.response) {
            resolve(error.response.data.result);

          }

        })
    })
  }
}

export default actions