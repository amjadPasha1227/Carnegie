const state = {
    status: '',
    token: localStorage.getItem('token') || '',
    user: JSON.parse(localStorage.getItem('user')) || [],
    userRole: parseInt(localStorage.getItem('userRole')) || '',
    windowWidth: null,
    widgetpermissions:[],
    subscriptions:[],
    subscription:null

}

export default state
