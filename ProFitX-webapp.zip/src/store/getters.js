import state from "./state"

const getters = {
  isLoggedIn: state => !!state.token,
  authStatus: state => state.status,
  getuser: state => state.user,
  getuserRole: state => state.userRole,
  getuserSubscription: state => state.subscription,
  getUserPermessions: state =>state.userPermessions,
  getWidgetpermissions: state =>state.widgetpermissions
}

export default getters