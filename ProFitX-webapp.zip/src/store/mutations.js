import state from "./state"

const mutations = {
    auth_request(state){
        state.status = 'loading'
      },
      loading(state){
        
      },
      auth_success(state, {token, user, userRole}){
        state.status = 'success'
        state.token = token
        state.user = user
        state.userRole = parseInt(userRole)
      },
      auth_error(state){
        state.status = 'error'
      },
      logout(state){
        state.status = ''
        state.token = ''
        state.user=''
      },
      UPDATE_USER_DETAILS(state,data){
        state.status = 'success'
        state.user = data.user
        state.userRole = data.userRole
        state.subscription = data.subscription
        state.widgetpermissions = data.widgetpermissions
      },
      UPDATE_USER_PAYMENT_STATUS(state,statusId){
        state.user.subscription.paymentStatusId = statusId
      },
    
}

export default mutations
