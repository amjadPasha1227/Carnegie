import Vue from 'vue'
import App from './App.vue'
import VueSlimScroll from 'vue-slimscroll'
Vue.use(VueSlimScroll)
import VueGtag from "vue-gtag";

import Vue2Filters from 'vue2-filters'

import VeeValidate from 'vee-validate';
Vue.use(VeeValidate);

import VueMeta from 'vue-meta'
Vue.use(VueMeta, {
  refreshOnceOnNavigation: true
})


var Vue2FiltersConfig = {
  currency: {
    symbol: '$',
    decimalDigits: 0,
    thousandsSeparator: ',',
    decimalSeparator: '.',
    symbolOnLeft: true,
    spaceBetweenAmountAndSymbol: false,
    showPlusSign: false
  }
}

Vue.use(Vue2Filters, Vue2FiltersConfig)

import VueMoment from 'vue-moment'
import moment from 'moment-timezone'


Vue.use(VueMoment, {
  moment,
})

import Trend from "vuetrend"
Vue.use(Trend)

import store from '@/store/store'
import VueLodash from 'vue-lodash'
import lodash from 'lodash'
Vue.use(VueLodash, { name: 'custom', lodash: lodash })

import vWow from 'v-wow'
Vue.use(vWow);

import VuePageTransition from 'vue-page-transition';
Vue.use(VuePageTransition);

import VTooltip from 'v-tooltip'
Vue.use(VTooltip)

import ScrollLoader from 'vue-scroll-loader'
Vue.use(ScrollLoader)

Vue.filter('percentazec', function (value) {
  if (!value) return ''
  return parseFloat(value).toFixed(1)

})
import Multiselect from 'vue-multiselect-inv'

Vue.component('multiselect', Multiselect)

Vue.filter('percentagecustom', function (value, decimals) {
  if (!value) {
    value = 0
  }

  if (!decimals) {
    decimals = 0
  }

  value = value * 100
  value = Math.round(value * Math.pow(10, decimals)) / Math.pow(10, decimals)
  return value
})

Vue.filter('truncatec', function (value, length) {
  if (!value) return ''
  value = value.toString()
  if (value.length > length) {
    return value.substring(0, length)
  } else {
    return value
  }
})

Vue.config.productionTip = false

import './styles/global.scss'



Vue.filter('formatDate', function (value) {
  if (value) {
    return moment(String(value)).format('MMMM Do YYYY')
  }
});
Vue.filter('formatDateDM', function (value) {
  if (value) {
    return moment(String(value)).format('MMM DD')
  }
}
);
Vue.filter('formatDateTime', function (value) {
  if (value) {
    return moment(String(value)).format('MMM DD, YYYY hh:mm A')
  }
}
);
if (process.env.NODE_ENV == 'production') {
  Vue.use(VueGtag, {
    config: { id: "GTM-KHL7JMR" },
    includes: [
      { id: 'GTM-KHL7JMR' }
    ]
  });

} else {
  Vue.use(VueGtag, {
    config: { id: "G-N9ZG4KVQQ1" }
  });

}

import VCalendar from 'v-calendar';

Vue.use(VCalendar, {
  componentPrefix: 'vc'
})

// Vue Router
import router from './router'

import vuetify from './plugins/vuetify';
import './mixins/app.js'


new Vue({
  store,
  router,
  vuetify,
  render: h => h(App),

  mounted() {

    window.addEventListener('beforeunload', this.beforeunloadHandler())
    window.addEventListener('unload', this.unloadHandler())

    this.$validator.localize('en', {
      messages: {
        required: (field) => '* ' + field + ' is required'
      },
    })
  },
  destroyed() {
    window.removeEventListener('beforeunload', this.beforeunloadHandler())
    window.removeEventListener('unload', this.unloadHandler())
  },
  methods: {
    beforeunloadHandler() {

      // var self = this;
      // this.$store.dispatch("logout").then(() => { });
    },
    unloadHandler(e) {


    }
  },
  metaInfo() {
    return {
      title: "ProFitX",
      titleTemplate: '',
      htmlAttrs: {
        lang: 'en',
        amp: true
      }

    }

  }

}).$mount('#app')
