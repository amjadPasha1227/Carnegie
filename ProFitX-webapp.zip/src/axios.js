// axios
import axios from 'axios'
import store from '@/store/store';

//const domain = "http://localhost:8988/";
//process.env.VUE_APP_API_URL+"/api";
//const domain  = process.env.VUE_APP_API_URL+"/api";
//const domain = "http://localhost:8988";
//const domain = "https://profitxv2.innvectra.in/api/"

let domain;

if (process.env.NODE_ENV !== 'production') {
  domain = process.env.VUE_APP_API_URL+"/userapi/";
} else {
    domain = process.env.VUE_APP_API_URL+"/userapi/";
}

const instance = axios.create({
    baseURL:domain
  // You can add your headers here
})

instance.interceptors.request.use(function(config) {
    const token = store.state.token;
    if ( token != null ) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  }, function(err) {
    return Promise.reject(err);
  });

export default instance;
