<!-- =========================================================================================
    File Name: Main.vue
    Description: Main layout

========================================================================================== -->

<template>
  <div class="layout--main">
    <!-------- Header Starts ------------>
    <the-header>
      <the-navbar />      
    </the-header>
    <!-------- Header Ends ------------>
    <div class="content-body"> 
      <sidebar />
      <!-- <the-filter/> -->
      <div class="content-wrapper">
        <router-view></router-view>
      </div>
    </div>
    <!-------- Footer Starts ------------>
    <the-footer>Footer</the-footer>
    <!-------- Footer Ends ------------>
  </div>
</template>

<script>
import TheHeader from "@/layouts/components/TheHeader.vue";
import Sidebar from "@/layouts/components/Sidebar.vue";
// import TheFilter from "@/layouts/components/TheFilter.vue";
import TheFooter from "@/layouts/components/TheFooter.vue";
import TheNavbar from "@/layouts/components/TheNavbar.vue";

export default {
  data() {
    this.disableThemeTour = true;  
    return {};
  },
  watch: {},
  computed: {},
  methods: {},
  components: {
    Sidebar,
    // TheFilter,
    TheFooter,
    TheNavbar,
    TheHeader,
  },
  created() {}
};
</script>
