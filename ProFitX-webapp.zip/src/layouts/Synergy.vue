<!-- =========================================================================================
    File Name: AtheleteIndex.vue
    Description: AtheleteIndex layout

========================================================================================== -->

<template>
  <div class="layout--main">
    <!-------- Header Starts ------------>
    <the-header>
      <the-navbar />      
    </the-header>
    <!-------- Header Ends ------------>
    <vue-page-transition name="fade">
        <div class="minpage" >
        <router-view :key="$route.fullPath"></router-view>
        </div>
   </vue-page-transition>

    <!-------- Footer Starts ------------>
    <the-footer>Footer</the-footer>
    <!-------- Footer Ends ------------>
  </div>
</template>

<script>
import TheHeader from "@/layouts/components/TheHeader.vue";
import TheFooter from "@/layouts/components/TheFooter.vue";
import TheNavbar from "@/layouts/components/TheNavbar.vue";
import VuePageTransition from 'vue-page-transition'

export default {
  data() {
    this.disableThemeTour = true;  
    return {};
  },
  watch: {},
  computed: {},
  methods: {},
  components: {
    TheFooter,
    TheNavbar,
    TheHeader,
  },
  created() {}
};
</script>
