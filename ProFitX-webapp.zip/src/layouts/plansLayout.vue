<template>
  <div class="layout--main block-layout">
    <div>
      <router-view></router-view>
    </div>
    <the-footer></the-footer>
  </div>
</template>

<script>
import TheFooter from "@/layouts/components/TheFooter.vue";
export default {
  data() {
    return {};
  },
  watch: {},
  computed: {},
  methods: {},
  components: {
    TheFooter
  }
};
</script>
