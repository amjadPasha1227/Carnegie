<!-- =========================================================================================
    File Name: AtheleteIndex.vue
    Description: AtheleteIndex layout

========================================================================================== -->

<template>
  <div class="layout--main">
    <!-------- Header Starts ------------>
    <the-header>
      <the-navbar />      
    </the-header>
    <!-------- Header Ends ------------>
    <vue-page-transition name="fade">
        <div class="minpage" >
        <router-view :key="$route.fullPath"></router-view>
        </div>
   </vue-page-transition>

    <!-------- Footer Starts ------------>
    <the-footer>Footer</the-footer>
    <!-------- Footer Ends ------------>

    <signupAlert  v-if="showsignupalert" />


  </div>
</template>

<script>
import TheHeader from "@/layouts/components/TheHeader.vue";
import TheFooter from "@/layouts/components/TheFooter.vue";
import TheNavbar from "@/layouts/components/TheNavbar.vue";
import VuePageTransition from 'vue-page-transition'
import signupAlert from "@/views/common/signupalert.vue";

export default {
  data() {
    this.disableThemeTour = true;  
    return {
      showsignupalert:false
    };
  },
  watch: {},
  computed: {},
  methods: {},
  components: {
    TheFooter,
    TheNavbar,
    TheHeader,
    signupAlert
  },
  created() {}
};
</script>
