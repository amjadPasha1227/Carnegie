<!-- =========================================================================================
    File Name: Breadcrumb.vue
    Description: Breadcrumb component
    Component Name: Breadcrumb

========================================================================================== -->

 
<template >
  <div>Breadcrumb</div>
</template>

<script>
export default {
  name: "breadcrumb"
};
</script>
