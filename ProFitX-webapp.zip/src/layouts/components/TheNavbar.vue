
<template>
<div class="relative">
   NAV BAR
</div>
</template>

<script>
export default {
    name: "the-navbar",
    props: {

    },
    data() {
        return {

        };
    },
    watch: {

    },
    mounted() {

    },
    computed: {

    },
    methods: {

    },
    directives: {

    },
    components: {

    }
};
</script>
