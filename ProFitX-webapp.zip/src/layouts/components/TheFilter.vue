<template>
    
    <div class="the-filter flex-wrap justify-between" v-bind:class="{ active: isActive }">
        <button class="mobile_sidemenu" v-on:click="isActive = !isActive">
            <v-icon>mdi-filter-variant</v-icon>
            <v-icon>mdi-arrow-right-bold</v-icon>
        </button>
        <div class="filters-content">
            <!-- <a class="navbar-brand" href="#/dashboard">
              <img src="../../assets/images/logo.svg" alt="BOLT">
          </a> -->
            <!-- <div class="filters-inner-content" :class="{static: scrollPosition < 80, fixed: scrollPosition > 80}"> -->
            <div class="filters-inner-content">
                <div class="filters-top">
                    <div class="filters-top-left">
                        <v-icon>mdi-filter-variant</v-icon> FILTERS
                    </div>
                    <div class="filters-top-right" @click="resetFilter()">
                        <button class="filter_reset"><img src="@/assets/images/reset.svg"></button>
                    </div>
                </div>
                <div v-slimscroll="options" class="filters_scrool">
                <v-expansion-panels>
                    <v-expansion-panel>
                        <v-expansion-panel-header>TEAM</v-expansion-panel-header>
                        <v-expansion-panel-content>
                            <!-- <ul v-slimscroll="options"> -->
                            <ul>
                                <li v-for="(team, index) in teams" v-bind:key='index'>
                                    <v-checkbox :key="index" v-model="player_team[index]" :value='team.TEAM_NAME' :label='team.TEAM_NAME'></v-checkbox>
                                    <img :src='"https://stats.nba.com/media/img/teams/logos/"+team.TEAM_NAME+"_logo.svg"'>
                                </li>
                            </ul>
                        </v-expansion-panel-content>
                    </v-expansion-panel>
                    <v-expansion-panel>
                        <v-expansion-panel-header>POSITIONS/VERSATILITY</v-expansion-panel-header>
                        <v-expansion-panel-content>
                            <ul>
                                <li v-for="(position, index) in positions" v-bind:key='index'>
                                    <v-checkbox :key="index" v-model="player_position[index]" :value='position.value' :label='position.name'></v-checkbox>
                                </li>
                            </ul>
                        </v-expansion-panel-content>
                    </v-expansion-panel>

                    <v-expansion-panel>
                        <v-expansion-panel-header>PLAYER ROLES</v-expansion-panel-header>
                        <v-expansion-panel-content>
                            <ul>
                                <li v-for="(position, index) in playerroles" v-bind:key='index'>
                                    <v-checkbox :key="index" v-model="player_role" :value='position.name' :label='position.name'></v-checkbox>
                                </li>
                            </ul>
                        </v-expansion-panel-content>
                    </v-expansion-panel>

                    <v-expansion-panel>
                        <v-expansion-panel-header>Real-Time Contract</v-expansion-panel-header>
                        <v-expansion-panel-content>
                            <template>
                                <v-container fluid grid-list-lg class="range-slider">
                                    <v-layout row wrap>
                                        <v-flex>
                                            <v-range-slider v-model="RTC" :max="60000000" :min="0" :step="100000"></v-range-slider>
                                        </v-flex>
                                        <div class="range-var">
                                            <v-flex>
                                                <v-text-field v-model="RTC[0]" class="mt-0" hide-details single-line type="number">
                                                </v-text-field>
                                            </v-flex>
                                            <v-flex>
                                                <v-text-field v-model="RTC[1]" class="mt-0" hide-details single-line type="number">
                                                </v-text-field>
                                            </v-flex>
                                        </div>
                                    </v-layout>
                                </v-container>
                            </template>

                        </v-expansion-panel-content>
                    </v-expansion-panel>

                    <v-expansion-panel>
                        <v-expansion-panel-header>FREE AGENTS</v-expansion-panel-header>
                        <v-expansion-panel-content>
                            <template>
                                <v-container fluid grid-list-lg class="range-slider">
                                    <v-layout row wrap>
                                        <v-flex>
                                            <v-range-slider v-model="fa" :max="2070" :min="2021" :step="1"></v-range-slider>
                                        </v-flex>
                                        <div class="range-var">
                                            <v-flex>
                                                <v-text-field v-model="fa[0]" class="mt-0" hide-details single-line type="number">
                                                </v-text-field>
                                            </v-flex>
                                            <v-flex>
                                                <v-text-field v-model="fa[1]" class="mt-0" hide-details single-line type="number">
                                                </v-text-field>
                                            </v-flex>
                                        </div>
                                    </v-layout>
                                </v-container>
                            </template>

                        </v-expansion-panel-content>
                    </v-expansion-panel>

                    <v-expansion-panel>
                        <v-expansion-panel-header>Experience</v-expansion-panel-header>
                        <v-expansion-panel-content>
                            <template>
                                <v-container fluid grid-list-lg class="range-slider">
                                    <v-layout row wrap>
                                        <v-flex>
                                            <v-range-slider v-model="experience" :max="25" :min="0" :step="1"></v-range-slider>
                                        </v-flex>
                                        <div class="range-var">
                                            <v-flex>
                                                <v-text-field v-model="experience[0]" class="mt-0" hide-details single-line type="number">
                                                </v-text-field>
                                            </v-flex>
                                            <v-flex>
                                                <v-text-field v-model="experience[1]" class="mt-0" hide-details single-line type="number">
                                                </v-text-field>
                                            </v-flex>
                                        </div>
                                    </v-layout>
                                </v-container>
                            </template>

                        </v-expansion-panel-content>
                    </v-expansion-panel>

                    <v-expansion-panel>
                        <v-expansion-panel-header>AGE</v-expansion-panel-header>
                        <v-expansion-panel-content>
                            <template>
                                <v-container fluid grid-list-lg class="range-slider">
                                    <v-layout row wrap>
                                        <v-flex>
                                            <v-range-slider v-model="playerage" :max="45" :min="18" :step="1"></v-range-slider>
                                        </v-flex>
                                        <div class="range-var">
                                            <v-flex>
                                                <v-text-field v-model="playerage[0]" class="mt-0" hide-details single-line type="number">
                                                </v-text-field>
                                            </v-flex>
                                            <v-flex>
                                                <v-text-field v-model="playerage[1]" class="mt-0" hide-details single-line type="number">
                                                </v-text-field>
                                            </v-flex>
                                        </div>
                                    </v-layout>
                                </v-container>
                            </template>

                        </v-expansion-panel-content>
                    </v-expansion-panel>

                    <v-expansion-panel>
                        <v-expansion-panel-header>HEIGHT</v-expansion-panel-header>
                        <v-expansion-panel-content>
                            <template>
                                <v-container fluid grid-list-lg class="range-slider">
                                    <v-layout row wrap>
                                        <v-flex>
                                            <v-range-slider v-model="playerheight" :max="8" :min="5" :step="0.1"></v-range-slider>
                                        </v-flex>
                                        <div class="range-var">
                                            <v-flex>
                                                <v-text-field v-model="playerheight[0]" class="mt-0" hide-details single-line type="number">
                                                </v-text-field>
                                            </v-flex>
                                            <v-flex>
                                                <v-text-field v-model="playerheight[1]" class="mt-0" hide-details single-line type="number">
                                                </v-text-field>
                                            </v-flex>
                                        </div>
                                    </v-layout>
                                </v-container>
                            </template>

                        </v-expansion-panel-content>
                    </v-expansion-panel>

                    <v-expansion-panel>
                        <v-expansion-panel-header>WEIGHT</v-expansion-panel-header>
                        <v-expansion-panel-content>
                            <template>
                                <v-container fluid grid-list-lg class="range-slider">
                                    <v-layout row wrap>
                                        <v-flex>
                                            <v-range-slider v-model="playerweight" :max="320" :min="150" :step="1"></v-range-slider>
                                        </v-flex>
                                        <div class="range-var">
                                            <v-flex>
                                                <v-text-field v-model="playerweight[0]" class="mt-0" hide-details single-line type="number">
                                                </v-text-field>
                                            </v-flex>
                                            <v-flex>
                                                <v-text-field v-model="playerweight[1]" class="mt-0" hide-details single-line type="number">
                                                </v-text-field>
                                            </v-flex>
                                        </div>
                                    </v-layout>
                                </v-container>
                            </template>

                        </v-expansion-panel-content>
                    </v-expansion-panel>

                </v-expansion-panels>
                </div>
                <div class="filters-bottom">
                    <a class="apply-filters" @click="updatefilters" href="javascript:;">
                        Apply Filters
                    </a>
                </div>
            </div>

        </div>

    </div>
</template>

<script>
import Vue from 'vue'
import VueSlimScroll from 'vue-slimscroll'

export default {
    name: "the-filter",
    data() {
        return {
            scrollPosition: null,
            isActive: false,
            teams: [{
                    "TEAM_ID": 1610612760,
                    "TEAM_NAME": "Oklahoma City Thunder",
                    "TEAM_ABBREVIATION": "OKC"
                },
                {
                    "TEAM_ID": 1610612757,
                    "TEAM_NAME": "Portland Trail Blazers",
                    "TEAM_ABBREVIATION": "POR"
                },
                {
                    "TEAM_ID": 1610612752,
                    "TEAM_NAME": "New York Knicks",
                    "TEAM_ABBREVIATION": "NYK"
                },
                {
                    "TEAM_ID": 1610612756,
                    "TEAM_NAME": "Phoenix Suns",
                    "TEAM_ABBREVIATION": "PHX"
                },
                {
                    "TEAM_ID": 1610612750,
                    "TEAM_NAME": "Minnesota Timberwolves",
                    "TEAM_ABBREVIATION": "MIN"
                },
                {
                    "TEAM_ID": 1610612761,
                    "TEAM_NAME": "Toronto Raptors",
                    "TEAM_ABBREVIATION": "TOR"
                },
                {
                    "TEAM_ID": 1610612739,
                    "TEAM_NAME": "Cleveland Cavaliers",
                    "TEAM_ABBREVIATION": "CLE"
                },
                {
                    "TEAM_ID": 1610612763,
                    "TEAM_NAME": "Memphis Grizzlies",
                    "TEAM_ABBREVIATION": "MEM"
                },
                {
                    "TEAM_ID": 1610612751,
                    "TEAM_NAME": "Brooklyn Nets",
                    "TEAM_ABBREVIATION": "BKN"
                },
                {
                    "TEAM_ID": 1610612747,
                    "TEAM_NAME": "Los Angeles Lakers",
                    "TEAM_ABBREVIATION": "LAL"
                },
                {
                    "TEAM_ID": 1610612758,
                    "TEAM_NAME": "Sacramento Kings",
                    "TEAM_ABBREVIATION": "SAC"
                },
                {
                    "TEAM_ID": 1610612765,
                    "TEAM_NAME": "Detroit Pistons",
                    "TEAM_ABBREVIATION": "DET"
                },
                {
                    "TEAM_ID": 1610612762,
                    "TEAM_NAME": "Utah Jazz",
                    "TEAM_ABBREVIATION": "UTA"
                },
                {
                    "TEAM_ID": 1610612744,
                    "TEAM_NAME": "Golden State Warriors",
                    "TEAM_ABBREVIATION": "GSW"
                },
                {
                    "TEAM_ID": 1610612738,
                    "TEAM_NAME": "Boston Celtics",
                    "TEAM_ABBREVIATION": "BOS"
                },
                {
                    "TEAM_ID": 1610612743,
                    "TEAM_NAME": "Denver Nuggets",
                    "TEAM_ABBREVIATION": "DEN"
                },
                {
                    "TEAM_ID": 1610612759,
                    "TEAM_NAME": "San Antonio Spurs",
                    "TEAM_ABBREVIATION": "SAS"
                },
                {
                    "TEAM_ID": 1610612753,
                    "TEAM_NAME": "Orlando Magic",
                    "TEAM_ABBREVIATION": "ORL"
                },
                {
                    "TEAM_ID": 1610612742,
                    "TEAM_NAME": "Dallas Mavericks",
                    "TEAM_ABBREVIATION": "DAL"
                },
                {
                    "TEAM_ID": 1610612740,
                    "TEAM_NAME": "New Orleans Pelicans",
                    "TEAM_ABBREVIATION": "NOP"
                },
                {
                    "TEAM_ID": 1610612749,
                    "TEAM_NAME": "Milwaukee Bucks",
                    "TEAM_ABBREVIATION": "MIL"
                },
                {
                    "TEAM_ID": 1610612764,
                    "TEAM_NAME": "Washington Wizards",
                    "TEAM_ABBREVIATION": "WAS"
                },
                {
                    "TEAM_ID": 1610612737,
                    "TEAM_NAME": "Atlanta Hawks",
                    "TEAM_ABBREVIATION": "ATL"
                },
                {
                    "TEAM_ID": 1610612741,
                    "TEAM_NAME": "Chicago Bulls",
                    "TEAM_ABBREVIATION": "CHI"
                },
                {
                    "TEAM_ID": 1610612754,
                    "TEAM_NAME": "Indiana Pacers",
                    "TEAM_ABBREVIATION": "IND"
                },
                {
                    "TEAM_ID": 1610612755,
                    "TEAM_NAME": "Philadelphia 76ers",
                    "TEAM_ABBREVIATION": "PHI"
                },
                {
                    "TEAM_ID": 1610612766,
                    "TEAM_NAME": "Charlotte Hornets",
                    "TEAM_ABBREVIATION": "CHA"
                },
                {
                    "TEAM_ID": 1610612746,
                    "TEAM_NAME": "Los Angeles Clippers",
                    "TEAM_ABBREVIATION": "LAC"
                },
                {
                    "TEAM_ID": 1610612748,
                    "TEAM_NAME": "Miami Heat",
                    "TEAM_ABBREVIATION": "MIA"
                },
                {
                    "TEAM_ID": 1610612745,
                    "TEAM_NAME": "Houston Rockets",
                    "TEAM_ABBREVIATION": "HOU"
                }
            ],
            player_team: {},
            player_position: {},
            player_role: null,
            fa:[2021,2080],
            playerroles: [{
                name: "Sharpshooter"

            }, {
                name: "Interior Finisher"

            }, {
                name: "High Volume Scorer"

            }, {
                name: "Playmaker"

            }, {
                name: "Versatile Defender"

            }, {
                name: "Rim Protector"

            }, {
                name: "Rebounding Specialist"

            }, {
                name: "Turnover Specialist"

            }, {
                name: "High Motor"

            }],
            positions: [{
                name: "Power Forward",
                value: "F-C"

            }, {
                name: "Forward",
                value: "F"
            }, {
                name: "Versatile Center",
                value: "C-F"
            }, {
                name: "Center",
                value: "C"
            }, {
                name: "Combo Guard",
                value: "G-F"
            }, {
                name: "Guard",
                value: "G"
            }, {
                name: "Wing",
                value: "F-G"
            }],
            RTC: [0, 60000000],
            playerheight: [5, 8],
            playerweight: [150, 320],
            playerage: [18, 45],
            experience: [0, 25],
            options: {
                height: '100%',
                size: 0,
                wheelStep : 5,
            }
        }
    },
    props: {
        username: String,
        classes: {
            type: String,
        },
    },
    mounted() {

        this.teams = this.lodash.sortBy(this.teams, "TEAM_NAME")
        window.addEventListener('scroll', this.updateScroll);
    },
    methods: {
        resetFilter(){
             let filterdata = {
                // player_position: [],
                // player_team: [],
                // player_role: this.player_role,
                // age: this.playerage,
                // weight: this.playerweight,
                // height: this.playerheight,
                // playerage: this.playerage,
                // exp: this.experience,
                // RTC: this.RTC,
                // fa:this.fa
            }
            this.$emit('updatefilters', filterdata)

        },
        updateScroll() {
            this.scrollPosition = window.scrollY
        },
        updatefilters() {

            var player_position = [];
            Vue._.forEach(this.player_position, function (value, key) {
                if (value) player_position.push(value);
            });

            var player_team = [];
            Vue._.forEach(this.player_team, function (value, key) {
                if (value) player_team.push(value);
            });

            let filterdata = {
                player_position: player_position,
                player_team: player_team,
                player_role: this.player_role,
                age: this.playerage,
                weight: this.playerweight,
                height: this.playerheight,
                playerage: this.playerage,
                exp: this.experience,
                RTC: this.RTC,
                fa:this.fa
            }
            this.$emit('updatefilters', filterdata)
        }
    }
}
</script>
