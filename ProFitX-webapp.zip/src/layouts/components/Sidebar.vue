
<template>
<div class="side_navbar" v-bind:class="{ sideMenuShow: isOpen }">
 
    <button class="mobile_sidemenu" v-on:click="isOpen = !isOpen">
        <!-- <v-icon>mdi-arrow-right-bold</v-icon> <label>Menu</label> -->
        <!-- <v-app-bar-nav-icon></v-app-bar-nav-icon>  -->
        <div class="menu-icon">
            <span></span>
            <span></span>
            <span></span>
        </div>        
        <label>Menu</label>
    </button>

    <div class="sidebar_cnt">
        <div class="profile_details_menu" v-bind:class="{ active: isActive }" v-if="player">

     

            <div class="profile_logo" v-if="player.goalserveDetails"><img :src='"https://profitx.ai/api/viewfile?path=teams/"+player.goalserveDetails.TeamID+".png"'></div>

                 <template v-if="player.PLAYER_IMAGE">

              <figure>
                    <img :src='player.PLAYER_IMAGE' class="align-self-center" :alt="player.PLAYER_NAME">
                </figure>
                            <label> {{player.PLAYER_NAME}} </label>

            </template>
             <template v-else>

               <figure>
                    <img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+player.goalserveDetails.PlayerID+".png"' class="align-self-center" :alt="player.PLAYER_NAME">
                </figure>
                            <label> {{player.PLAYER_NAME}} </label>

            </template>
        </div>
        <div class="profile_details_menu_name"> </div>
        <ul class="side_menu">
            <template v-for="(s, index) in subscriptions">
                <li v-if="checkMenuPermissions(s.name)" :class="{ 'active': $route.name == s.name}" :key="s.id" @click="setActive(index)">
                    <router-link :to="{ name: s.name, params: { userId: currentPlayer }}" v-if="(player && player.totalgames > 39) ||  index==0">{{ s.name }}</router-link>
                </li>
            </template>
        </ul>
    </div>

    <addSupportTicket v-if="getUserrole==4" />

</div>
</template>

<script>
import addSupportTicket from "@/views/components/addSupportTicke.vue"

export default {

    name: 'sidebar',
    components: {

        addSupportTicket

    },
    data: () => ({
        pageTitle: "ProFitX",
        currentPlayer: null,
        menuopen: true,
        isActive: false,
        isOpen:false,
        isRowActive: false,
        scrollPosition: null,
        subscriptions: [
            {
                id: 2,
                name: 'Team Dynamic',
                alias: "teamdynamic",
                path: '/athlete/:id/teamdynamic'
            },{
                id: 1,
                name: 'PLAYER DNA',
                alias: "playerdna",
                path: '/athlete/:id/playerdna'
            },
            {
                id: 3,
                name: 'Player Development',
                alias: "potential",
                path: '/athlete/:id/potential'
            },
            {
                id: 5,
                name: 'Performance Trajectory',
                alias: "stats",
                path: '/athlete/:id/performancestats'
            },
            {
                id: 4,
                name: 'Contract Analysis',
                alias: "contract",
                path: '/athlete/:id/playercontract'
            }
        ],
        activeIndex: 0,
    }),

    props: {
        player: null
    },
    mounted() {
        this.currentPlayer = this.$route.params.id;
        window.addEventListener('scroll', this.updateScroll);
        let rname = this.lodash.cloneDeep(this.$route.name)
        this.pageTitle = "ProFitX - " + this.player.PLAYER_NAME + " - " + rname;
        window.top.document.title = this.pageTitle;
      


    },
    methods: {

        setHref(path) {
            return path.replace(':id', this.$route.params.id)
        },
        setActive(index) {
            this.activeIndex = index
        },
        updateScroll() {
            this.scrollPosition = window.scrollY;

            if (this.scrollPosition > 270) {
                this.isActive = true;
            } else {
                this.isActive = false;
            }

        }
    },
    computed: {
        getProfileData() {
            return this.$store.state.user;
        },
         getUserrole() {
            return this.$store.state.userRole;
        },
        compClasses: function () {
            return {
                available: this.available,
                nearby: this.nearby
            }
        }
    },

}
</script>
