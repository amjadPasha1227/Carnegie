<template>
<div class="main_header">
  <div v-if="isUserloggeIn &&  isUserPaid"></div>
    <div v-else class="trail_bar" >
      <p>Sign up now for a free 2-day trial of our Sports Probability Platform - the most dynamic sports technology tool on the market. <router-link
              class="subscribe"
              to="/pricing"
            >Subscribe</router-link></p>  
            <span class="close"><v-icon>mdi-close</v-icon></span>
  </div>
  <header
    id="stickyheader"
    :class="{ fixed_header: scrollY > 0 }"
    @click="snackbar = false"
  >
    <nav class="navbar" id="banner" :class="{ menu_open: showMobileMenu }">
      <!-- Brand -->
       <router-link
              class="navbar-brand"
              to="/"
            >

        <img  width="180" src="../../assets/images/logo.svg" alt="ProFitX" />
      </router-link>
      <!-- Navbar links -->

      <div class="navbar-collapse">
        <ul class="navbar-nav navbarmob" id="navabr-nav" ref="navbarmob">
          <li class="nav-item">
            <router-link
              v-bind:class="{ active: currentpage == 'athletes' }"
              class="nav-link"
              to="/athletes"
            >
              Athledex
            </router-link>
          </li>
            <!-- <li class="nav-item"  >
              <router-link
              v-bind:class="{ active: currentpage == 'probability' }"
              class="nav-link"
              to="/probability"
            >
              Probability
            </router-link>
          </li> -->


               <li class="nav-item" v-if="
            currentpage != 'PLAYER DNA' &&
            currentpage != 'Team Dynamic' &&
            currentpage != 'Contract Analysis' &&
            currentpage != 'Performance Trajectory' &&
            currentpage != 'Player Development'
          ">
            <router-link
              v-bind:class="{ active: currentpage == 'analytics' }"
              class="nav-link"
              to="/top-performers"
            >
              Analytics<v-icon>mdi-chevron-down</v-icon>
            </router-link>
             <div class="submenu_cnt">
                <div class="submenu">
                    <ul>
                        <li> <router-link to="/top-performers"><img src="@/assets/images/topPerformer.svg">Top Performers</router-link></li>
                        <li> <router-link to="/top-shooters"><img src="@/assets/images/fieldGoalPerformance.svg">Top Shooters</router-link></li>
                        <li> <router-link to="/stock-risers"><img src="@/assets/images/topPerformer.svg">Stock Risers</router-link></li>
                        <li> <router-link to="/hidden-gems"><img src="@/assets/images/hiddenGems.svg">Hidden Gems</router-link></li>
                    </ul>
                    <ul class="sub_list">
                        <li> <router-link 
                        :to="{ name: 'career-outlook-extend', params: { type: 1 }}"
                       >MVP Candidates</router-link></li>
                        <li> <router-link   :to="{ name: 'career-outlook-extend', params: { type: 2 }}">All-NBA</router-link></li>
                        <li> <router-link   :to="{ name: 'career-outlook-extend', params: { type: 3 }}">All-Stars</router-link></li>
                        <li> <router-link   :to="{ name: 'career-outlook-extend', params: { type: 4 }}">Starters</router-link></li>
                        <li> <router-link   :to="{ name: 'career-outlook-extend', params: { type: 5 }}">Key Reserves</router-link></li>
                    </ul>
                </div>
            </div>
          </li>
           
           <li class="nav-item">
            <a class="nav-link" href="/corporate/technology">Technology<v-icon>mdi-chevron-down</v-icon></a>
            <div class="submenu_cnt submenu_cnt2">
                <div class="submenu">
                    <ul>                             
                        <li><a href="/corporate/nba-athledex"><img src="@/assets/images/NBA_icon.svg">The Nba Athledex</a></li>
                        <li><a href="/corporate/probability-platform"><img src="@/assets/images/analysis.svg">The Sports Probability <br/>Platform</a></li>    
                    </ul>
                </div>
            </div>
          </li>
                   <li class="nav-item"      v-if="
            currentpage != 'PLAYER DNA' &&
            currentpage != 'Team Dynamic' &&
            currentpage != 'Contract Analysis' &&
            currentpage != 'Performance Trajectory' &&
            currentpage != 'Player Development'
          ">
            <a class="nav-link" href="/corporate/resources/"
            >
              Resources<v-icon>mdi-chevron-down</v-icon>
            </a>
             <div class="submenu_cnt submenu_cnt2">
                <div class="submenu">
                    <ul>
                             
                        <li><a href="/corporate"><img src="@/assets/images/aboutus.svg">About Us</a></li>
                        <li><a href="/corporate/blogs"><img src="@/assets/images/blogs_icon.svg">Blog</a></li>
                        <li><a href="/corporate/inmedia"><img src="@/assets/images/megaphone.svg">In the Media</a></li>
                        <li><a href="/corporate/case-studies"><img src="@/assets/images/casestudies_icon.svg">Case Studies</a></li>
                        <li><a href="/corporate/updates"><img src="@/assets/images/update-2.svg">Updates</a></li>
                       <li >
            <router-link
              v-bind:class="{ active: currentpage == 'polls' }"
              class=" "
              to="/polls"
            ><img src="@/assets/images/polls.svg">
              Polls
            </router-link>
          </li>
                    
                    </ul>
                </div>
            </div>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/synergysearch">Synergy Search</router-link>               
          </li>
        </ul>
      </div>
      <div class="right-side-buttons">
        <div
          class="player_search"
          v-if="
            currentpage == 'PLAYER DNA' ||
            currentpage == 'Team Dynamic' ||
            currentpage == 'Contract Analysis' ||
            currentpage == 'Performance Trajectory' ||
            currentpage == 'Player Development'
          "
        >
          <input
            class="search"
            v-model="serch_title"
            @keyup="getPlayersList()"
            type="text"
            placeholder="Search Athletes"
          />
          <span class="loader" v-if="loading"
            ><img src="../../assets/images/loading.gif"
          /></span>
          <div
            class="search_list_wrap"
            v-if="playersList.length > 0"
            :class="{
              one: playersList.length == 1,
              two: playersList.length == 2,
              three: playersList.length == 3,
              four: playersList.length == 4,
            }"
          >
            <div class="search_list">
              <ul v-slimscroll="searchoptions">
                <li
                  style="cursor: pointer"
                  v-for="(player, index) in playersList"
                  :key="index"
                  @click="goToplayerDetails(player)"
                >
                  <label>{{ player.PLAYER_NAME }}</label>
                  <p>
                    {{ player.TEAM_ABBREVIATION }}
                    <span v-if="player.POSITION">
                      - {{ getposition(player.POSITION) }}
                    </span>
                  </p>
                </li>
              </ul>
            </div>
          </div>
        </div>
            <div class="header_actions" v-if="!isUserloggeIn">

               <router-link
              class="signin"
              to="/pricing?show=login"
            >
              Sign In</router-link>
                  <router-link
              class="gradient_btn"
              to="/pricing"
            >
               <span>Subscribe</span></router-link>
            </div>
        <ul>
          
          <li class="wusername" v-if="isUserloggeIn">
            <figure>
              <img
                :src="checkProperty(getProfileData, 'profilePicture')"
                @error="getProfilePhoto($event)"
              />
            </figure>
            <span>{{ getProfileData.name }}</span><v-icon>mdi-chevron-down</v-icon>
            <ul class="user_options">
              <!-- <li @click="initUpdateProfile() "><a>Update Profile</a></li>
                        <li  @click="initUpdatePassword();"><a>Change Password</a></li> -->
              <li @click="goToPage('/profile')">
                <a href="javascript:;">Profile</a>
              </li>
              <li
                @click="goToPage('/users-list')"
                v-if="[1, 2, 3].indexOf(getUserrole) > -1"
              >
                <a href="javascript:;">Users</a>
              </li>
              <li
                @click="goToPage('/plan')"
                v-if="[4].indexOf(getUserrole) > -1"
              >
                <a href="javascript:;">Plan</a>
              </li>
              <li
                @click="goToPage('/payments')"
                v-if="[1, 2, 4].indexOf(getUserrole) > -1"
              >
                <a href="javascript:;">Payments</a>
              </li>
              <li
                @click="goToPage('/support')"
                v-if="[1, 2, 3, 4].indexOf(getUserrole) > -1"
              >
                <a href="javascript:;">Support</a>
              </li>
              <li
                @click="goToPage('/enquiries')"
                v-if="[1, 2].indexOf(getUserrole) > -1"
              >
                <a href="javascript:;">Enquiries</a>
              </li>

              <li @click="logout()"><a href="javascript:;">Logout</a></li>
            </ul>
          </li>
          <!-- <li class="logout"><a href="javascript:;" @click="logout()">Logout</a></li> -->
        </ul>

        <v-dialog
          v-model="updateProfilePopup"
          max-width="500"
          class="injury-dialog-block"
        >
          <div class="dialog_body">
            <div class="dialog_title">
              <h3>Update Profile</h3>
              <v-btn
                color="primary"
                text
                @click="updateProfilePopup = false"
                class="close-btn"
              >
                <v-icon>mdi-close</v-icon>
              </v-btn>
            </div>
            <form>
              <div class="form-group">
                <v-text-field
                  name="email"
                  :disabled="true"
                  class="text_field"
                  label="Email"
                  v-validate="'required|email'"
                  v-model="profileData.email"
                  single-line
                  outlined
                ></v-text-field>
                <span class="error-text" v-show="errors.has('email')">{{
                  errors.first("email")
                }}</span>
              </div>

              <div class="form-group">
                <v-text-field
                  name="Name"
                  label="Name"
                  v-validate="'required'"
                  v-model="profileData.name"
                  single-line
                  outlined
                ></v-text-field>
                <span class="error-text" v-show="errors.has('Name')">{{
                  errors.first("Name")
                }}</span>
              </div>

              <div class="form-group">
                <v-text-field
                  name="First Name"
                  label="First Name"
                  v-validate="'required'"
                  v-model="profileData.firstName"
                  single-line
                  outlined
                ></v-text-field>
                <span class="error-text" v-show="errors.has('First Name')">{{
                  errors.first("First Name")
                }}</span>
              </div>

              <div class="form-group">
                <v-text-field
                  name="Middle Name"
                  label="Middle Name"
                  v-validate="'required'"
                  v-model="profileData.middleName"
                  single-line
                  outlined
                ></v-text-field>
                <span class="error-text" v-show="errors.has('Middle Name')">{{
                  errors.first("Middle Name")
                }}</span>
              </div>
              <div class="form-group">
                <v-text-field
                  name="Last Name"
                  class="text_field"
                  label="Last Name"
                  v-validate="'required'"
                  v-model="profileData.lastName"
                  single-line
                  outlined
                ></v-text-field>
                <span class="error-text" v-show="errors.has('Last Name')">{{
                  errors.first("Last Name")
                }}</span>
              </div>

              <!--<div class="form-group">
                        <v-text-field name="Password" :type="textType"  class="text_field" label="Password" v-validate="'required'" v-model="profileData.password" single-line outlined></v-text-field>
                        <span class="error-text" v-show="errors.has('Password')">{{ errors.first("Password") }}</span>
                        </div>-->

              <div class="dialog_actions">
                <button
                  class="secondary-btn"
                  :disabled="checkUpdateProfile"
                  style="cursor: pointer"
                  @click="updateProfile()"
                  href="javascript:;"
                >
                  Update
                </button>
              </div>
            </form>
          </div>
        </v-dialog>

        <v-dialog
          v-model="updatePasswordpopup"
          max-width="500"
          class="injury-dialog-block"
        >
          <div class="dialog_body">
            <div class="dialog_title">
              <h3>Update Password</h3>
              <v-btn
                color="primary"
                text
                @click="updatePasswordpopup = false"
                class="close-btn"
              >
                <v-icon>mdi-close</v-icon>
              </v-btn>
            </div>
            <form v-on:submit.prevent>
              <div class="form-group">
                <label>Current Password*</label>
                <v-text-field
                  v-validate="'required'"
                  name="current password"
                  type="password"
                  class="form-control"
                  ref="cpassword"
                  v-model="currentPassword"
                  single-line
                  outlined
                ></v-text-field>
                <span
                  class="error-text"
                  v-show="errors.has('current password')"
                  >{{ errors.first("current password") }}</span
                >
              </div>
              <div class="form-group">
                <label>New Password*</label>
                <v-text-field
                  v-validate="'required'"
                  name="password"
                  type="password"
                  class="form-control"
                  ref="password"
                  v-model="newPassword"
                  single-line
                  outlined
                ></v-text-field>
                <span class="error-text" v-show="errors.has('password')">{{
                  errors.first("password")
                }}</span>
              </div>
              <div class="form-group">
                <label>Confirm Password* </label>
                <v-text-field
                  v-validate="'required|confirmed:password'"
                  name="password_confirmation"
                  type="password"
                  class="form-control"
                  data-vv-as="password"
                  v-model="confirmPassword"
                  single-line
                  outlined
                ></v-text-field>
                <span
                  class="error-text"
                  v-show="errors.has('password_confirmation')"
                  >{{ errors.first("password_confirmation") }}</span
                >
              </div>

              <div class="dialog_actions">
                <button
                  :disabled="checkpasswordUpdateform"
                  class="secondary-btn"
                  @click="updatePassword()"
                  href="javascript:;"
                >
                  Update Password
                </button>
              </div>
            </form>
          </div>
        </v-dialog>

        <!-- <v-snackbar
                v-model="snackbar"
                :vertical="vertical"
                 right
                shaped
                top 
                >
                {{ text }}

                <template v-slot:action="{ attrs }">
                    <v-btn
                    color="indigo"
                    text
                    v-bind="attrs"
                    @click="snackbar = false"
                    >
                    Close
                    </v-btn>
                </template>
                </v-snackbar> -->
        <snakebar
          v-if="snackbar"
          :snackbar="snackbar"
          :msg="text"
          :isError="isError"
        />
      </div>
      <div class="mobile_menu" @click="showMobileMenu = !showMobileMenu">
        <div id="nav-icon1">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
    </nav>
  </header>
</div>
</template>

<script>
import snakebar from "@/views/components/snakebar.vue";

import VueSlimScroll from "vue-slimscroll";
export default {
  name: "the-header",
  components: {
    snakebar,
  },
  props: {
    classes: {
      type: String,
    },
  },
  created() {
    // if (this.currentpage == 'PLAYER DNA')
    window.addEventListener("scroll", this.handleScroll);
  },
  destroyed() {
    //   if (this.currentpage == 'PLAYER DNA')
    window.removeEventListener("scroll", this.handleScroll);
  },
  mounted() {
    this.currentpage = this.$route.name;

    this.user = this.$store.state.user;

    window.addEventListener("resize", this.onResize);
  },
  beforeDestroy() {
    window.removeEventListener("resize", this.onResize);
  },
  watch: {
    "$route.name": {
      handler: function () {
        this.currentpage = this.$route.name;
      },
      deep: true,
      immediate: true,
    },
    windowWidth() {
      this.$refs.navbarmob.style.display = "";
    },
  },
  methods: {
    goToPage(page) {
      this.$router.push(page);
    },
    initUpdateProfile() {
      this.text = "";
      this.updateProfilePopup = true;
      //"phoneNo": "",
      this.profileData = {
        firstName: this.user["firstName"],
        middleName: this.user["middleName"],
        lastName: this.user["lastName"],
        name: this.user["name"],
        email: this.user["email"],
      };

      this.$validator.reset();
    },
    updateProfile() {
      let postData = this.profileData;
      postData["userId"] = "userID";

      this.$store
        .dispatch("updateProfile", this.profileData)
        .then((response) => {
          this.snackbar = true;
          this.isError = false;
          this.text = response.message;
          this.updateProfilePopup = false;
          this.user = JSON.parse(localStorage.getItem("user"));
        })
        .catch((err) => {
          this.text = err;
          this.isError = false;
          this.snackbar = true;
        });
    },
    initUpdatePassword() {
      this.text = "";

      this.currentPassword = "";
      this.newPassword = "";
      this.confirmPassword = "";
      this.updatePasswordpopup = true;
      this.$validator.reset();
    },
    updatePassword() {
      let postData = {
        email: this.user["email"],
        currentPassword: this.currentPassword,
        newPassword: this.newPassword,
        confirmPassword: this.confirmPassword,
      };
      this.$store
        .dispatch("updatePassword", postData)
        .then((response) => {
          this.updatePasswordpopup = false;
          this.text = response.message;
          this.snackbar = true;
          this.isError = false;
        })
        .catch((err) => {
          this.isError = true;
          this.text = err;
          this.snackbar = true;
        });
    },

    handleScroll() {
      this.scrollY = window.scrollY;
    },
    goToplayerDetails(player) {
      //alert(player.PLAYER_ID);
      this.playersList = [];
      this.serch_title = null;

      this.$router.replace({
        ...this.$router.currentRoute,
        params: {
          id: player.PLAYER_ID || undefined,
        },
      });

      // this.$router.push("/athlete/" + player.PLAYER_ID + "/playerdna");
      // window.location ="/athlete/"+player.PLAYER_ID+"/playerdna";
    },
    getposition(type) {
      var _p = this.lodash.find(this.positions, function (my) {
        return my.value == type;
      });
      return _p.name;
    },
    getPlayersList() {
      this.playersList = [];
      this.loading = false;

      let serch_title = this.serch_title;
      serch_title = this.serch_title.trim();
      if (serch_title) {
        const postData = {
          page: 1, //this.page++,
          perpage: 15, //this.perpage++,
          matcher: {
            startswith: "",
            searchString: serch_title,
            //"playerage": this.playerage,
            //"playerteam": this.playerteam,
            // "playerposition": this.playerposition
          },
        };

        this.loading = true;
        this.$store
          .dispatch("getplayers", postData)
          .then((response) => {
            if (response.error) {
              this.playersList = [];
            } else {
              this.playersList = response.data.result.list;
            }

            this.loading = false;
          })
          .catch((err) => {
            this.playersList = [];
            this.loading = false;
          });
      }
    },
    logout() {
      var self = this;
      this.$store.dispatch("logout").then(() => {
        self.$router.go("/pricing?show=login");
      });
    },
    onResize() {
      this.windowWidth = window.innerWidth;
    },
    say: function () {
      this.$refs.navbarmob.style.display =
        this.$refs.navbarmob.style.display === "block"
          ? "none"
          : !this.$refs.navbarmob.style.display ||
            this.$refs.navbarmob.style.display === "none"
          ? "block"
          : "none";
    },
  },
  data: () => ({
    trail_bar:false,
    isError: false,
    showMobileMenu: false,
    snackbar: false,
    text: "",
    vertical: true,
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
    updatePasswordpopup: false,
    updateProfilePopup: false,
    profileData: {
      firstName: "",
      middleName: "",
      lastName: "",
      name: "",
      email: "",
      password: "",
      phoneNo: "",
      roleId: "6",
    },
    scrollY: 0,
    searchoptions: {
      height: "100%",
      size: "8px",
    },
    isScrolled: false,
    currentpage: null,
    awesome: true,
    user: null,
    windowWidth: 0,

    playersList: [],
    loading: false,
    serch_title: "",
    positions: [
      {
        name: "Power Forward",
        value: "F-C",
      },
      {
        name: "Forward",
        value: "F",
      },
      {
        name: "Versatile Center",
        value: "C-F",
      },
      {
        name: "Center",
        value: "C",
      },
      {
        name: "Combo Guard",
        value: "G-F",
      },
      {
        name: "Guard",
        value: "G",
      },
      {
        name: "Wing",
        value: "F-G",
      },
    ],
  }),
  //checkpasswordUpdateform
  computed: {
    isUserloggeIn(){
     return this.$store.state && this.$store.state.user!=''

    },
     isUserPaid(){
     if([1, 2, 3].indexOf(this.$store.state.userRole) > -1){

       return true
     }  
     let currentPlan = this.$store.getters["subscription/getSubscriptions"];
     if(currentPlan && currentPlan.length > 0) return true; 
     return false;
    },
    getProfileData() {
      return this.$store.state.user;
    },
    getUserrole() {
      return this.$store.state.userRole;
    },

    checkUpdateProfile() {
      //profileData:{ "firstName": "","middleName": "", "lastName": "", "name": "", "email": "", "password": "","phoneNo": "", "roleId": "6"},
      if (
        this.profileData["name"] == "" ||
        this.profileData["name"] == null ||
        this.profileData["name"] == undefined ||
        this.profileData["firstName"] == "" ||
        this.profileData["firstName"] == null ||
        this.profileData["firstName"] == undefined ||
        this.profileData["middleName"] == "" ||
        this.profileData["middleName"] == null ||
        this.profileData["middleName"] == undefined ||
        this.profileData["lastName"] == "" ||
        this.profileData["lastName"] == null ||
        this.profileData["lastName"] == undefined
      ) {
        return true;
      } else {
        return false;
      }
    },
    checkpasswordUpdateform() {
      if (
        this.currentPassword == "" ||
        this.currentPassword == null ||
        this.newPassword == "" ||
        this.newPassword == null ||
        this.confirmPassword == "" ||
        this.confirmPassword == null ||
        this.confirmPassword != this.newPassword
      ) {
        return true;
      } else {
        return false;
      }
    },
  },
};
</script>
