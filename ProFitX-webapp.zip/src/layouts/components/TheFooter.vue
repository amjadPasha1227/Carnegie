<!-- =========================================================================================
    File Name: TheFooter.vue
    Description: Footer component
   ========================================================================================== -->

<template>
<footer class="footer_wrapper">
    <div class="container">
        <div class="row">
            <div class="footer_cnt">
                <div class="footer_list">
                    <div id="logo" class="wow fadeInUp">
                        <a href="/"><img width="200" src="../../assets/images/logo.svg" alt="Profit Logo"></a>
                        <!-- <p>© Copyright {{currentYear}}, ProFitX Sports Club, LLC. All rights reserved. <a href="https://profitx.ai/privacy-policy">Privacy Policy</a></p> -->
                        <p>Copyright ProFitX Sports Inc.</p>
                    </div>

                </div>
                <div class="footer_nav">                    
                    <ul>
                        <li><a href="/corporate">About</a></li>
                        <li><a href="/corporate/contact">Contact</a></li>
                        <li><a href="/corporate/technology">Technology</a></li>
                        <li><a href="/corporate/resources">Resources</a></li>
                        <li><a href="/corporate/faq">FAQ</a></li>
                        <li><a href="/corporate/privacy-policy/">Privacy Policy</a></li>
                    </ul>
                </div>
                <div class="footer_list">

                    <div class="footer_social">
                        <h6>Follow Us On</h6>
                        <ul>
                            <li><a href="https://www.instagram.com/profitxai/" target="_blank" class="facebook">
                                    <v-icon>mdi-instagram</v-icon>
                                </a></li>
                            <li><a href="https://www.linkedin.com/company/profitx-ai/" class="linkedin" target="_blank">
                                    <v-icon>mdi-linkedin</v-icon>
                                </a></li>
                            <li><a href="https://twitter.com/profitxai" class="twitter" target="_blank">
                                    <v-icon>mdi-twitter</v-icon>
                                </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- <div class="row">
            <div class="copyrights wow fadeInUp">
                <p>© Copyright {{currentYear}}, ProFitX Sports Corporation. All Rights Reserved. <a href="https://profitx.ai/privacy-policy">Privacy Policy</a></p>
            </div>
        </div> -->
    </div>

        <success-popup @closePopup="closePopup" :closebutton="closebutton" :showoverlay="subscribedone" title="Thank You" description="Thank you for registering " />

</footer>
</template>

<script>
import moment from "moment";
import successPopup from "@/views/success.vue";

export default {
    name: "the-footer",
    props: {
        classes: {
            type: String,
        },
    },
    data() {
        return {
            closebutton:true,
            subscribedone:false,
            subscribeemail: null,
            btndisabled: false,
            currentYear: null
        }
    },
    components: {
        successPopup
    },
    mounted() {

        this.currentYear = moment().format("YYYY")

    },
    methods: {
        closePopup(){
                this.subscribedone = false;


        },
        subscribeNewletter() {
            this.btndisabled = true;
            const subobj = {
                email: this.subscribeemail,
                listId: 36006
            };
            this.$store.dispatch("subscribetoemaillist", subobj).then(response => {
                this.subscribeemail = null;
                this.subscribedone = true;
                this.btndisabled = false;

            })
            return false;
        }

    }
}
</script>
