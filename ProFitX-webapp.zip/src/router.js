import Vue from 'vue'
import Router from 'vue-router'
import store from '@/store/store'
import _ from "lodash";


Vue.use(Router)

const router = new Router({
  base: process.env.BASE_URL,
  mode: 'history',
  scrollBehavior() {
    return window.scrollTo({ top: 0, behavior: 'smooth' });
  },
  routes: [

    {
      path: '',
      component: () => import('./layouts/AtheleteIndex.vue'),
      children: [

        {
          path: '/dashboard',
          name: 'dashboard',
          component: () => import('./views/dashboard.vue')
        },
        {
          path: '/athlete-selection',
          name: 'athlets_selection',
          component: () => import('./views/athlets_selection.vue')
        },
        {
          path: '/athletes_old',
          name: 'athletes_old',
          component: () => import('./views/athletes_old.vue')
        },
        {
          path: '/athletes',
          name: 'athletes',
          component: () => import('./views/athletes.vue')
        },
        {
          path: '/athletesfav',
          name: 'athletesfav',
          component: () => import('./views/athletesfav.vue')
        },
        {
          path: '/athlete/:id/playerdna',
          name: 'PLAYER DNA',
          component: () => import('./views/playerdna.vue')
        },
        {
          path: '/under_construction',
          name: 'under Construction',
          component: () => import('./views/under_construction.vue')
        },
        {
          path: '/athlete/:id/teamdynamic',
          name: 'Team Dynamic',
          component: () => import('./views/impactpillar.vue')
        },
        {
          path: '/athlete/:id/potential',
          name: 'Player Development',
          component: () => import('./views/potential.vue')
        },
        {
          path: '/athlete/:id/playercontract',
          name: 'Contract Analysis',
          component: () => import('./views/playercontract.vue')
        },
        {
          path: '/athlete/:id/performancestats',
          name: 'Performance Trajectory',
          component: () => import('./views/performancestats.vue')
        },
        {
          path: '/athlete/:id/metrics',
          name: 'metrics',
          component: () => import('./views/metrics.vue')
        },
        {
          path: '/athlete/:id/brand-value',
          name: 'brand-value',
          component: () => import('./views/brand-value.vue')
        },
        {
          path: '/users-list',
          name: 'users-list',
          component: () => import('./views/users-list.vue'),

        },
        {
          path: '/top-shooters',
          name: 'home',
          component: () => import('./views/home/topPerformerDetails.vue'),
          meta: {
            requiresAuth: true
          }
        },
        {
          path: '/top-performers',
          name: 'home',
          component: () => import('./views/home/topPerformerDetails.vue'),
          meta: {
            requiresAuth: true
          }
        },
        {
          path: '/stock-risers',
          name: 'home',
          component: () => import('./views/home/topPerformerDetails.vue'),
          meta: {
            requiresAuth: true
          }
        },
        {
          path: '/hidden-gems',
          name: 'home',
          component: () => import('./views/home/topPerformerDetails.vue'),
          meta: {
            requiresAuth: true
          }
        },

        {
          path: '/career-outlook',
          name: 'career-outlook',
          component: () => import('./views/home/topPerformerDetails.vue'),
          meta: {
            requiresAuth: true
          }
        }, {
          path: '/career-outlook/:type',
          name: 'career-outlook-extend',
          component: () => import('./views/home/topPerformerDetails.vue'),
          meta: {
            requiresAuth: true
          }
        },
        {
          path: '/',
          name: 'home',
          component: () => import('./views/dashboard/index.vue'),
          meta: {
            requiresAuth: false
          }
        },
        {
          path: '/polls',
          name: 'polls',
          component: () => import('./views/polls/polls.vue'),
          meta: {
            requiresAuth: true
          }
        },
        {
          path: '/profile',
          name: 'profile',
          component: () => import('./views/profile.vue')
        },
        {
          path: '/plan',
          name: 'plan',
          component: () => import('./views/plan.vue'),
          meta: {
            requiresAuth: false
          }
        },
        {
          path: '/payments',
          name: 'payments',
          component: () => import('./views/payments.vue')
        },
        {
          path: '/support',
          name: 'support',
          component: () => import('./views/support.vue')
        },
        //enquiryList.vue
        {
          path: '/enquiries',
          name: 'enquiries',
          component: () => import('./views/enquiryList.vue')
        },



      ],
    },
    {
      path: '',
      component: () => import('./layouts/Synergy.vue'),
      children: [
        {
          path: '/synergysearch',
          name: 'synergysearch',
          component: () => import('./views/synergysearch.vue')
        }
      ],
    },
    {
      path: '',
      component: () => import('./layouts/Synergy.vue'),
      children: [
        {
          path: '/probability',
          name: 'probability',
          component: () => import('./views/probabilityIndex.vue'),
          meta: {
            requiresAuth: true
          }
        }
      ],
    },
    {
      path: '',
      component: () => import('./layouts/Synergy.vue'),
      children: [
        {
          path: '/probability-details/:id',
          name: 'probability-details',
          component: () => import('./views/probabilityIndex-details.vue'),
          meta: {
            requiresAuth: true
          }
        }
      ],
    },
    {
      path: '',
      component: () => import('./layouts/NoSidebar.vue'),
      children: [
        {
          path: '/nosidebar',
          name: 'nosidebar',
          component: () => import('./views/nosidebar.vue')
        }
      ],
    },
    {
      path: '',
      component: () => import('@/layouts/AtheleteIndex.vue'),
      children: [
        {
          path: '/pricing',
          name: 'PlansAndPricing',
          component: () => import('./views/PlansAndPricing.vue'),
          meta: {
            requiresAuth: false
          }
        }
      ],
    },
    {
      path: '',
      component: () => import('@/layouts/AtheleteIndex.vue'),
      children: [
        {
          path: '/pricing-v2',
          name: 'PlansAndPricing',
          component: () => import('./views/PlansAndPricingV2.vue'),
          meta: {
            requiresAuth: false
          }
        }
      ],
    },
    {
      path: '',
      component: () => import('@/layouts/AtheleteIndex.vue'),
      children: [
        {
          path: '/thank-you',
          name: 'thankYou',
          component: () => import('./views/thankYou.vue'),
          meta: {
            requiresAuth: false
          }
        }
      ],
    },

    {
      path: '',
      component: () => import('@/layouts/AtheleteIndex.vue'),
      children: [
        {
          path: '/login',
          name: 'login',
          component: () => import('@/views/login.vue'),
          meta: {
            requiresAuth: false
          }
        },

      ]
    },
    {
      path: '',
      component: () => import('@/layouts/FullPage.vue'),
      children: [
        {
          path: '/forgot-password',
          name: 'forgotpassword',
          component: () => import('@/views/forgotpassword.vue'),
          meta: {
            requiresAuth: false
          }
        },

      ]
    }, {
      path: '',
      component: () => import('@/layouts/FullPage.vue'),
      children: [
        {
          path: '/set-password',
          name: 'setpassword',
          component: () => import('@/views/setpassword.vue'),
          meta: {
            requiresAuth: false
          }
        }, {
          path: 'public/set-password',
          name: 'setpassword',
          component: () => import('@/views/setpassword.vue'),
          meta: {
            requiresAuth: false
          }
        }, {
          path: 'public/reset-password',
          name: 'setpassword',
          component: () => import('@/views/setpassword.vue'),
          meta: {
            requiresAuth: false
          }
        },

      ]
    },
    {
      path: '',
      component: () => import('@/layouts/FullPage.vue'),
      children: [
        {
          path: '/signup',
          name: 'signup',
          component: () => import('@/views/sign-up.vue'),
          meta: {
            requiresAuth: false
          }
        },

      ]
    },
    {
      path: '*',
      redirect: '/pages/error-404'
    }
  ],
})
router.afterEach((to, from, next) => {
  Vue.nextTick(() => {
    const user = store.getters.getuser;

    if (user && user._id) {
      Vue.$gtag.config({
        'GA_MEASUREMENT_ID': {
          'user_id': user._id.toString()
        }
      }
      )


    }


    Vue.$gtag.set({
      'user_properties': {
        'ProFitX_User_ID': user._id,
        'ProFitX_User_Name': user.name
      }
    })




  });

})

router.beforeEach((to, from, next) => {


  if (to.matched.some(record => record.meta.requiresAuth == false)) {

    next()

  } else {

    /*
   Change All User State data on every Router change
  */
    let user = store.getters.getuser;
    var payLoad = { subscriber: { name: user.name, email: user.email, phone: user.phoneNo, phoneCode: "+1" }, page: 1, perpage: 100, appActivity: true };
    store.dispatch("subscription/getSelectedPlan", payLoad).then((currentPlan) => {


      if (store.getters.isLoggedIn && [1, 2, 3, 5].indexOf(user.roleId) > -1) {

        next()

      } else if (store.getters.isLoggedIn) {
        let subscription = store.getters['subscription/getSubscriptions'];
        /* Payment Check */
        if (to.path != "/planss" && to.path != "/profile" && to.path != "/support" && (subscription && subscription.length > 0 && subscription[0].invoiceDetails == null) || (subscription && subscription.length > 0 && subscription[0].invoiceDetails != null && subscription[0].invoiceDetails.statusId != 2)) {
          next('/plan')
          return
        } else if (subscription && subscription.length > 0 && subscription[0].invoiceDetails != null && subscription[0].invoiceDetails.statusId == 2) {
          next()
        } else {

          next()
        }


      } else {
        if (to.path != "/pricing") {

          next('/pricing?show=subscribepopup')

        } else {

          next()
        }

      }

    }).catch((err) => {

      if (to.path != "/pricing") {

        next('/pricing')

      } else {

        next()
      }
    });






  }




})

export default router
