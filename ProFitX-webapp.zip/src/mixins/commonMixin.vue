<template>
<div> </div>
</template>
<script>
import  mixin from './app';
export default {
  mixins: [mixin]
}
</script>