import Vue from 'vue'
import mprofileImage from "@/assets/images/mprofile.svg"
import fprofileImage from "@/assets/images/fprofile.svg"
import playerImage from "@/assets/images/profile_dp-1.png"
import _ from "lodash";
Vue.mixin({
    data: function () {
        return {
            swapCount: 0,
            myPlanData: null,
            profileData: null,
            chartcolors: [
                "#C73434",
                "#C9AB2E",
                "#27B2DB",
                "#8434E2",
                "#D97C2D",
                "#2D70CE",
                "#B51F9E",
                "#739025",
                "#2FA7A7",
                "#27B2DB",
                "#8434E2",
                "#D97C2D",
                "#FF4300",
                "#655575",
                "#66452A",
                "#703153",
                "#568384",
                "#B7B7B7",
                "#5C6BA0",
                "#FBF9B9",
                "#dd8b31",
                "#6c7aef",
                "#9db92d",
                "#8458d1",
                "#61c350",
                "#a141b8",
                "#41912e",
                "#da45a9",
                "#38c481",
                "#e33771",
                "#3c8c51",
                "#c777e6",
                "#c6b43c",
                "#4b58bf",
                "#cda039",
                "#5586de",
                "#e2672a",
                "#45c7c8",
                "#ce3e29",
                "#59a9dc",
                "#cd3f4b",
                "#77c28b",
                "#ac4197",
                "#9ab65b",
                "#e081d6",
                "#4c6a18",
                "#6f509d",
                "#7a8627",
                "#9279c2",
                "#6f944d",
                "#e3659c",
                "#399d82",
                "#af3366",
                "#306a3c",
                "#975797",
                "#486a2d",
                "#aba2e7",
                "#a17c2f",
                "#476da6",
                "#e7735a",
                "#277257",
                "#e3808f",
                "#70692c",
                "#d28abb",
                "#c3ae70",
                "#954b6d",
                "#e0916c",
                "#a75355",
                "#956232",
                "#a64d26",
                "#C73434",
            ],
            widgetsPermessions: [],
        }

    },
    created: function () {
    },
    mounted() {
        this.swapCount = 0;
        let permessions = this.$store.getters['getWidgetpermissions'];
        this.profileData = this.$store.state.user;
        let userRole = this.$store.state.userRole;
        let subscriptions = this.$store.getters['subscription/getSubscriptions'];

        if ([1, 2, 3, 5, 6].indexOf(userRole) > -1) {

            this.widgetsPermessions = permessions['ALLWIDGETS'];
        }
        if ([4].indexOf(userRole) > -1 && subscriptions != undefined) {


            if (subscriptions && subscriptions.length > 0 && subscriptions[0].planDetails && subscriptions[0].planDetails['uniqueId'] != null) {

                let plan = subscriptions[0].planDetails['uniqueId'];



                if (plan.includes('OFFIN')) {
                    this.widgetsPermessions = permessions['INSEASONWIDGETS'].concat(permessions['OFFSEASONWIDGETS']);
                } else if (plan.includes('IN')) {
                    this.widgetsPermessions = permessions['INSEASONWIDGETS'];
                } else if (plan.includes('OFF')) {




                    this.widgetsPermessions = permessions['OFFSEASONWIDGETS'];
                } else if (plan.includes('LEAGUEPASS')) {

                    this.widgetsPermessions = permessions['LEAGUEPASSWIDGETS'];


                }

            }
        }


    },
    methods: {
        setPageTitle(title = "") {
            if (title != '')
                this.$root.$root.$metaInfo.title = title;
        },
        /**
     * On user has registered
     * @param selectedAthlets | Array
     * @param dbAthletes | Array
     * 
     * **/
        processSwapCount({ selectedAthlets = [], dbAthletes = [], dbSwapCount = 0 }) {
            this.swapCount = dbSwapCount;
            if (dbAthletes.length == 0) {
                this.swapCount = 0;
            }

            let commanItems = _.intersection(dbAthletes, selectedAthlets);

            if (commanItems.length > 0) {
                this.swapCount = ((dbAthletes).length - (commanItems.length)) + this.swapCount

            } else {
                this.swapCount = this.swapCount + (selectedAthlets).length;

            }

            return this.swapCount

        },
        checkPhonenumber(e) {

            let char = String.fromCharCode(e.keyCode); // Get the character
            if (/^[-0-9+]+$/.test(char) && e.target.value.length <= 15) return true; // Match with regex 
            else e.preventDefault(); // If not match, don't add to input text 
        },
        download_file(value) {
            if (_.has(value, "path")) {
                value['url'] = value['path'];
            }
            let postdata = { keyName: value.url };
            this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                window.open(response.data.result.data);
            });
        },
        checkWidgetsPermessions(widget = '') {
            var _p = this.widgetsPermessions;
            let userRole = this.$store.state.userRole;

            if ([1, 2, 3, 5, 6].indexOf(userRole) > -1) {
                return true;
            }
            if (widget != '' && this.lodash.includes(_p, widget)) {
                return true;
            } else {
                return false;
            }

        },
        checkMenuPermissions(menuName = '') {
            let returnValue = false
            if (menuName == '' || menuName == null || menuName == undefined) {
                returnValue = true;


            } else {
                //PLAYER DNA
                if (menuName == 'PLAYER DNA') {
                    if (this.checkWidgetsPermessions('PLAYER_ROLES')
                        || this.checkWidgetsPermessions('STAR_SYSTEM')
                        || this.checkWidgetsPermessions('POSITION_VERSATILITY')
                        || this.checkWidgetsPermessions('TENDENCIES')
                        || this.checkWidgetsPermessions('ATTRIBUTES')
                    ) {

                        returnValue = true;
                    }
                }
                //IMPACT menu
                else if (menuName == 'Team Dynamic') {
                    if (this.checkWidgetsPermessions('CAREER_OUTLOOK')
                        || this.checkWidgetsPermessions('INJURY_RISK')
                        || this.checkWidgetsPermessions('INJURY_MANAGEMENT')
                        || this.checkWidgetsPermessions('OPPORTUNITY')

                    ) {

                        returnValue = true;
                    }
                }

                //Player Development menu
                else if (menuName == 'Player Development') {
                    if (this.checkWidgetsPermessions('PROXTIAL')
                        || this.checkWidgetsPermessions('TEAMFIT')
                        || this.checkWidgetsPermessions('ATHLETE_PERFORMANCE')
                        || this.checkWidgetsPermessions('TRADE_VALUE')

                    ) {

                        returnValue = true;
                    }
                }

                //Contract Analysis menu
                else if (menuName == 'Contract Analysis') {
                    if (this.checkWidgetsPermessions('PLAYER_CONTRACTS')) {

                        returnValue = true;
                    }
                }

                //Performance Trajectory menu
                else if (menuName == 'Performance Trajectory') {
                    if (this.checkWidgetsPermessions('PERFORMANCE_IMPACT')
                        || this.checkWidgetsPermessions('FINANCIAL_IMPACT')
                        || this.checkWidgetsPermessions('CAREER_DATA')

                    ) {

                        returnValue = true;
                    }
                }



            }

            return returnValue;
        },
        checkProperty(object = null, mainKey = '', subKey = '') {
            if (object != null && mainKey != '') {
                if (this.lodash.has(object, mainKey)) {

                    if (subKey != '') {
                        if (this.lodash.has(object[mainKey], subKey)) {
                            return object[mainKey][subKey];

                        } else {
                            return '';

                        }


                    } else {
                        return object[mainKey];

                    }


                } else {
                    return '';
                }


            } else {
                return '';
            }

        },
        getProfilePhoto(event, gender = '') {

            if (gender == 'M' || gender == 'O') {
                event.target.src = mprofileImage;
            } else if (gender == 'F') {
                event.target.src = fprofileImage;
            } else {
                event.target.src = mprofileImage;
            }


        },
        setDefaultPlayerImage(event) {
            event.target.src = playerImage;

        },
        setDefaultTeamImage(event) {
            event.target.src = playerImage;

        }


    }
})
