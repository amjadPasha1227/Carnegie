<template>
<div class="payment-simple">

    <StripeElements :stripe-key="stripeKey" :instance-options="instanceOptions" :elements-options="elementsOptions" #default="{ elements }" ref="elms">

        <div class="row">
            <div class="col-sm-6 col-xs-12 padtb0">
                <div class="form-group">
                    <label class="form_label">Card number</label>
                    <div class="form-control">
                        <StripeElement type="cardNumber" :elements="elements" :options="cardOptions" ref="cardNumber" />
                    </div>

                </div>
            </div>
            <div class="col-sm-6 padtb0">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label class="form_label">Expire Date</label>
                            <select>
                                <option value="0">Month</option>
                                <option value="1">jan</option>
                                <option value="2">feb</option>
                                <option value="3">mar</option>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label class="form_label">&nbsp;</label>
                            <select>
                                <option value="0">Year</option>
                                <option value="1">2021</option>
                                <option value="2">2020</option>
                                <option value="3">2020</option>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label class="form_label d-flex">CVV<p>
                                    <v-icon>mdi-information</v-icon><small>A CVV is the three- or four-digit number on your card</small>
                                </p></label>
                            <input class="form-control" type="text">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-xs-12 padtb0">
                <div class="form-group">
                    <label class="form_label">Card holder’s name</label>
                    <input class="form-control" type="text">
                </div>
            </div>
        </div>
        <div class="card_actions">
            <button type="button" class="update_btn">Update</button>
            <button class="cancel_btn" id="cancel_btn">Cancel</button>
        </div>

    </StripeElements>
    <button @click="pay" type="button">Pay</button>
</div>
</template>

<script>
import {
    StripeElements,
    StripeElement
} from 'vue-stripe-elements-plus'

export default {
    components: {
        StripeElements,
        StripeElement
    },

    data() {
        return {
            stripeKey: 'pk_test_pZnhKyNDKZ7mQJR6cfQxTHe600TzKSwrOg', // test key, don't hardcode
            instanceOptions: {
                // https://stripe.com/docs/js/initializing#init_stripe_js-options 
            },
            elementsOptions: {
                style: {
                    base: {
                        iconColor: '#c4f0ff',
                        color: '#f0f0f0',
                        fontWeight: '500',
                        fontSize: '50px',
                        fontSmoothing: 'antialiased',
                        ':-webkit-autofill': {
                            color: '#fce883',
                        },
                        '::placeholder': {
                            color: '#87BBFD',
                        },
                    },
                    invalid: {
                        iconColor: '#FFC7EE',
                        color: '#FFC7EE',
                    },
                }

                // https://stripe.com/docs/js/elements_object/create#stripe_elements-options
            },
            cardOptions: {
                // reactive
                // remember about Vue 2 reactivity limitations when dealing with options
                value: {
                    postalCode: ''
                }
                // https://stripe.com/docs/stripe.js#element-options
            }
        }
    },

    methods: {
        pay() {
            // ref in template
            const groupComponent = this.$refs.elms
            const cardComponent = this.$refs.card
            // Get stripe element
            const cardElement = cardComponent.stripeElement

            // Access instance methods, e.g. createToken()
            groupComponent.instance.createSource(cardElement).then(result => {
                alert(JSON.stringify(result))
            })
        }
    }
}
</script>
