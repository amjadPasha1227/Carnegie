

<template>
  <div class="pI__details_banner prematch livematch" v-if="gamedata">
    <div class="pI_teams_bg">
      <div class="team_one">
 
        <div class="team_background"
          :style="{
            opacity: 0.4,
            width: '100%',
            height: '100%',
            background: homebackgroundcolors,
          }"
        >
          
        </div>       <img class="logo_watermark"  
            :src="gamedata.HomeTeam.logo"
          />
      </div>
      <div class="team_two">
        
        <div class="team_background"
          :style="{
            opacity: 0.4,
            width: '100%',
            height: '100%',
            background: awaybackgroundcolors,
          }"
        >
        
        </div>  <img class="logo_watermark"  
            :src="gamedata.AwayTeam.logo"
          />
      </div>
    </div>
    <div class="pI_match_info">
      <!-- <span class="match_status" v-if="gamedata.Status=='InProgress' ">LIVE</span> -->
       
      <div class="live-alert" v-if="gamedata.Status=='InProgress' ">
        <div class="waveWrapper left">
          <div class="waveWrapperInner delay1">
            <div class="wave"></div>
          </div>
          <div class="waveWrapperInner delay2">
            <div class="wave"></div>
          </div>
          <div class="waveWrapperInner delay3">
            <div class="wave"></div>
          </div>
        </div>
        <div class="wave-text">
          <div class="text-wrapper">
            <h2>Live</h2>
          </div>
        </div>
        <div class="waveWrapper right">
            <div class="waveWrapperInner delay1">
              <div class="wave"></div>
            </div>
            <div class="waveWrapperInner delay2">
              <div class="wave"></div>
            </div>
            <div class="waveWrapperInner delay3">
              <div class="wave"></div>
            </div>
        </div>
      </div>
      <div class="PI_match_teams">
        <figcaption>{{gamedata.HomeTeam.Name}}</figcaption>
        <figure><img  :src="gamedata.HomeTeam.logo" /></figure>
         <span
          v-if="gamedata.LiveProb"
          >{{ gamedata.LiveProb.home_score }}</span
        >
         <label v-if="gamedata.Status == 'InProgress'"
          ><small>SCORES</small><b>{{ gamedata.LiveProb.elapsed }}</b></label
        >
        <label v-else-if="gamedata.Status == 'Scheduled'"
          ><small>Starts In</small><b>{{ startsIn }} hrs</b></label
        >
        <label v-else-if="gamedata.Status != 'InProgress' && gamedata.Status != 'Scheduled'"
          ><small>Status</small><b>{{gamedata.Status}}</b></label
        >
     <span
          v-if="gamedata.LiveProb"
          >{{ gamedata.LiveProb.away_score }}</span
        >
        <figure><img  :src="gamedata.AwayTeam.logo" /></figure>
        <figcaption>{{gamedata.AwayTeam.Name}}</figcaption>
      </div>
      <div class="PI_team_scores">
        <div class="team1_score">
          <div class="score_value" v-bind:class="{
              high: HomeWinPer * 100 > 60,
              low: HomeWinPer * 100 < 30,
              medium:
                HomeWinPer * 100 > 30 &&
                HomeWinPer * 100 < 60,
            }">
            <label>{{ HomeWinPer | percentagecustom(1)
              }}<sub>%</sub></label>
            <span>H</span>
          </div>
          <div class="score_progress" v-bind:class="{
              high: HomeWinPer * 100 > 60,
              low: HomeWinPer * 100 < 30,
              medium:
                HomeWinPer * 100 > 30 &&
                HomeWinPer * 100 < 60,
            }"></div>
        </div>
        <div class="team2_score">
          <div class="score_progress" v-bind:class="{
              high: AwayWinPer * 100 > 60,
              low: AwayWinPer * 100 < 30,
              medium:
                AwayWinPer * 100 > 30 &&
                AwayWinPer * 100 < 60,
            }"></div>
          <div class="score_value"  v-bind:class="{
              high: AwayWinPer * 100 > 60,
              low: AwayWinPer * 100 < 30,
              medium:
                AwayWinPer * 100 > 30 &&
                AwayWinPer * 100 < 60,
            }">
            <span>H</span>
            <label>{{ AwayWinPer | percentagecustom(1)
              }}<sub>%</sub></label>
          </div>
        </div>
        <strong class="trophy"><img src="@/assets/images/trophy.png" /></strong>
      </div>
    </div>
  </div>
</template>

<script>
import moment from "moment";

export default {
  data() {
    return {
      angle: "246",
      color1: "red",
      color2: "blue",
    };
  },
  computed: {
          HomeWinPer(){
      if(this.gamedata.Status == "InProgress" || this.gamedata.Status == "Final"){

        return this.gamedata.LiveProb.home_win_pct
      }
      return this.gamedata.home_win_pct
    },
    AwayWinPer(){
      if(this.gamedata.Status == "InProgress" || this.gamedata.Status == "Final"){

        return this.gamedata.LiveProb.away_win_pct
      }
      return this.gamedata.away_win_pct
    },
   startsIn() {
      if (moment.utc(this.gamedata.gamedate).isAfter(moment().utc())) {

        return moment.utc(this.gamedata.gamedate).diff(
          moment().utc(),
          "hours"
        );
      }
      return moment()
        .utc()
        .diff(moment(this.gamedata.gamedate), "hours");
    },
    homebackgroundcolors() {
      if (this.gamedata) {
        return `transparent linear-gradient(${this.angle}deg, #${this.gamedata.HomeTeam.PrimaryColor} 0%, #${this.gamedata.HomeTeam.SecondaryColor} 100%) 0% 0% no-repeat padding-box`;
      }
      return "";
    },
    awaybackgroundcolors() {
      if (this.gamedata) {
        return `transparent linear-gradient(${this.angle}deg, #${this.gamedata.AwayTeam.PrimaryColor} 0%, #${this.gamedata.AwayTeam.SecondaryColor} 100%) 0% 0% no-repeat padding-box`;
      }
      return "";
    },
  },
  props: {
    gamedata: null,
    gameId: null,
  },
};
</script>

