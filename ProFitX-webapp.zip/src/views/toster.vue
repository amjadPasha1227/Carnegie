<template>
<v-snackbar v-model="toaster" :vertical="true" right shaped top>
    {{ description }}
</v-snackbar>
</template>

<script>
export default {
    data() {
        return {};
    },
    props: ['toaster', "description"],
    methods: {

    },
    mounted() {

    }
}
</script>
