<template>
<div class="leaderboard_page">
    <div class="teams_list_sec">
        <teamsList></teamsList>
    </div>
    <div class="players_list_sec">
        <playersList></playersList>
    </div>
    <div class="leaderboard_cnt">
        <div class="leaderboard_left">
            <div class="groupwise">
                <groups></groups>
            </div>
            <div class="team_performance_sec">
                <teamPerformance></teamPerformance>
            </div>
            <div class="teamFit_sec">
                <teamFit></teamFit>
            </div>
            <v-row>
                <v-col class="col-md-6 col-sm-12">
                    <div class="peerAnalytics">
                        <peerAnalytics></peerAnalytics>
                    </div>
                </v-col>
                <v-col class="col-md-6 col-sm-12">
                    <div class="contractvalue_sec">
                        <contractValue></contractValue>
                    </div>
                </v-col>
            </v-row>
            <div class="latest_news_sec">
                <latestNews></latestNews>
            </div>
            <div class="aboutProfitX_sec">
                <aboutProfitX></aboutProfitX>
            </div>
        </div>




        <div class="leaderboard_right">
            <div class="bannerSlider">
                <bannerSlider></bannerSlider>
            </div>
            <div class="contestslist_sec">
                <contestsList></contestsList>
            </div>  
            <div class="teamContest_sec">
                <teamContest></teamContest>
            </div>
            <div>
                <athleteContests></athleteContests>
            </div>
            <div class="topSpendingPlayers">
                <topSpendingPlayers></topSpendingPlayers>
            </div>
            <div class="development_sec">
                <development></development>
            </div>
            <div class="development_sec">
                <development></development>
            </div>
            <newsLetter></newsLetter>
        </div>
    </div> 
</div>
</template>

<script>
import teamsList from "@/views/components/leaderBoard/teamsList.vue";
import playersList from "@/views/components/leaderBoard/playersList.vue"; 
import teamPerformance from "@/views/components/leaderBoard/teamPerformance.vue"; 
import groups from "@/views/components/leaderBoard/groups.vue"; 
import teamFit from "@/views/components/leaderBoard/teamFit.vue"; 
import peerAnalytics from "@/views/components/leaderBoard/peerAnalytics.vue"; 
import contractValue from "@/views/components/leaderBoard/contractValue.vue"; 
import latestNews from "@/views/components/leaderBoard/latestNews.vue"; 
import aboutProfitX from "@/views/components/leaderBoard/aboutProfitX.vue"; 

import bannerSlider from "@/views/components/leaderBoard/bannerSlider.vue"; 
import contestsList from "@/views/components/leaderBoard/contestsList.vue"; 
import teamContest from "@/views/components/leaderBoard/teamContest.vue"; 
import athleteContests from "@/views/components/leaderBoard/athleteContests.vue";
import topSpendingPlayers from "@/views/components/leaderBoard/topSpendingPlayers.vue"; 
import development from "@/views/components/leaderBoard/development.vue"; 
import newsLetter from "@/views/components/leaderBoard/newsLetter.vue"; 

export default {
    name: "synergy-seacrh",
    components: {
        teamsList,
        playersList,
        teamPerformance,
        groups,
        teamFit,
        peerAnalytics,
        bannerSlider,
        contestsList,
        teamContest,
        athleteContests,
        contractValue,
        latestNews,
        aboutProfitX,
        topSpendingPlayers,
        development,
        newsLetter,
        
    },
    
     
    mounted() {

         


    },
    data() {
        return {
            
        };
    }
};
</script>
