<template>
<div class="content-body">
    <sidebar v-if="player!=null" :player=player />
  <div class="content-wrapper">
    <div class="athlete_content_wrap">
        <v-row>
        <v-col><player-details/></v-col>
        </v-row>
       <div class="nodataBox" v-if="player && player.RTC == null">

                No Data Available
            </div>
            <div class="athlete_body_content" v-if="player && player.RTC">
            <div class="brand-value-wrapper">
                <!--TOTAL BRAND VALUE-->            
                <v-row>
                    <v-col><total-brand-value/></v-col>
                </v-row>
                <!--SOCIAL MEDIA-->
                
                <v-row>
                    <v-col><social-media/></v-col>
                </v-row>
                <!--TURNOVERS-->            
                <v-row>
                    <v-col class="col-md-4">
                        <turnovers/>
                    </v-col>
                    <v-col class="col-md-4">
                        <game-attendance/>
                    </v-col>
                    <v-col class="col-md-4">
                        <player-productivity/>
                    </v-col>
                </v-row>
                <!--ENDORSEMENTS-->
                
                <v-row>
                    <v-col>
                        <endorsements/>
                    </v-col>
                    
                </v-row>
            </div>

        </div>
        </div>
    </div>
</div>
</template>

<script>
import playerDetails from "@/views/components/playerDetails.vue";
import endorsements from "@/views/components/endorsements.vue";
import socialMedia from "@/views/components/socialMedia.vue";
import totalBrandValue from "@/views/components/totalBrandValue.vue";
import turnovers from "@/views/components/turnovers.vue";
import gameAttendance from "@/views/components/gameAttendance.vue";
import playerProductivity from "@/views/components/playerProductivity.vue";
import Sidebar from "@/layouts/components/Sidebar.vue";

export default { 
 components: {
    playerDetails,
    endorsements,
    socialMedia,
    totalBrandValue,
    turnovers,
    gameAttendance,
    playerProductivity,
    Sidebar
    
  },
 
};
</script>
