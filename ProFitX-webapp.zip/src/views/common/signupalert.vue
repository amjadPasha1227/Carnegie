
<template>
  <div>
    <v-dialog persistent max-width="500" v-model="showMe">
      <div class="dialog_body">
        <div class="signup_alert">
          <img width="100" src="@//assets/images/logo.svg" />
          <p>
            Thank you for checking out the Sports Probability Platform (SPP).
            For further access to the SPP and/or the Athledex, please visit the
            pricing and subscription page.
          </p>
          <p>
            You may also Register yourself to participate in the Polls and
            access content. We look forward to always providing the most
            up-to-date performance and financial technology on the market.
          </p>

          <div class="btns btnslist">
            <router-link to="/pricing?show=signup" class="btn"
              ><span>Register</span></router-link
            >
            <router-link to="/pricing" class="btn gradient_btn"
              ><span>Subscribe</span></router-link
            >
          </div>
        </div>
      </div>
    </v-dialog>
  </div>
</template>
<script>
export default {
  data: () => ({
    showMe: true,
  }),
    mounted() {
    this.showMe = true;
  },
};
</script>