<template>
  <div class="matches_list" style="cursor:pointer"  @click="gotoIndexdetail(gamedata)">
    <div class="box_bg">
      <div class="left" :style="{ 'background-color': '#'+gamedata.HomeTeam.PrimaryColor }">
        <div class="left_angle" :style="{ 'border-top-color': '#'+gamedata.HomeTeam.PrimaryColor }"> </div>
      </div>
      <div class="right" :style="{ 'background-color': '#'+gamedata.AwayTeam.PrimaryColor }"></div>
    </div>
    <div class="teams_cnt">
      <!-- <span class="match_status" v-if="gamedata.Status == 'InProgress'">
        <template>LIVE</template>
      </span> --> 
    <div class="live-alert" v-if="gamedata.Status == 'InProgress'">
      <div class="waveWrapper left">
        <div class="waveWrapperInner delay1">
          <div class="wave"></div>
        </div>
        <div class="waveWrapperInner delay2">
          <div class="wave"></div>
        </div>
        <div class="waveWrapperInner delay3">
          <div class="wave"></div>
        </div>
      </div>
      <div class="wave-text">
        <div class="text-wrapper">
          <h2>Live</h2>
        </div>
      </div>
      <div class="waveWrapper right">
          <div class="waveWrapperInner delay1">
            <div class="wave"></div>
          </div>
          <div class="waveWrapperInner delay2">
            <div class="wave"></div>
          </div>
          <div class="waveWrapperInner delay3">
            <div class="wave"></div>
          </div>
      </div>
    </div>
      <div class="team_logs">
        <figure>
          <img :title="gamedata.HomeTeam.Name"  :src="gamedata.HomeTeam.logo" />

          <figcaption v-if="gamedata.LiveProb">{{ gamedata.LiveProb.home_score }}</figcaption>
        </figure>
        <div class="score_cnt">
          <span><img src="@/assets/images/vs.svg" /></span>
          <p v-if="gamedata.Status == 'InProgress'">
            Scores
            <b>{{gamedata.LiveProb.elapsed}}</b>
          </p>
            <p v-else-if="gamedata.Status == 'Scheduled'">
            Starts In
            <b>{{startsIn}} Hours</b>
          </p>
            <p v-else>
           {{gamedata.Status}}
          </p>
        </div>

        <figure>
          <img  :src="gamedata.AwayTeam.logo" :title="gamedata.AwayTeam.Name" />
          <figcaption v-if="gamedata.LiveProb">{{ gamedata.LiveProb.away_score }}</figcaption>
          </figure>
      </div>
      <div class="prodiction">
        <div class="prodiction_btn">
          <h4>ProFitX - Prediction</h4>
        </div>
        <div class="prodiction_value" v-if="gamedata.Status != 'InProgress'">
          <p>
              <template v-if="HomeWinPer > AwayWinPer">Winning</template>
              <template v-if="HomeWinPer < AwayWinPer">Losing</template>

            <b>{{ HomeWinPer | percentagecustom(1)
              }}%</b>
          </p>
          <p><b>{{ AwayWinPer | percentagecustom(1)
              }}%</b>              <template v-if="AwayWinPer > HomeWinPer">Winning</template>
              <template v-if="AwayWinPer < HomeWinPer">Losing</template></p>
        </div>
              <div class="prodiction_value" v-if="gamedata.Status == 'InProgress'">
          <p>
              <template v-if="gamedata.LiveProb.home_win_pct > gamedata.LiveProb.away_win_pct">Winning</template>
              <template v-if="gamedata.LiveProb.home_win_pct < gamedata.LiveProb.away_win_pct">Losing</template>

            <b>{{ gamedata.LiveProb.home_win_pct | percentagecustom(1)
              }}%</b>
          </p>
          <p><b>{{ gamedata.LiveProb.away_win_pct | percentagecustom(1)
              }}%</b>              <template v-if="gamedata.LiveProb.away_win_pct > gamedata.LiveProb.home_win_pct">Winning</template>
              <template v-if="gamedata.LiveProb.away_win_pct < gamedata.LiveProb.home_win_pct">Losing</template></p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import moment from "moment";

export default {
  components: {},
  props: {
    gamedata: null,
  },
  methods: {
    gotoIndexdetail(data) {

            if (this.isUserloggeIn) {

      this.$router.push({
        name: "probability-details",
        params: { id: data.gameid},
      });

            }else{

        this.$emit("triggerSignup");

            }
     
      
    },
  },
  mounted() {
    this.siteUrl = process.env.VUE_APP_API_URL;
  },
  computed: {
    isUserloggeIn() {
      return this.$store.state && this.$store.state.user != "";
    },
     HomeWinPer(){
      if(this.gamedata.Status == "InProgress" || this.gamedata.Status == "Final"){

        return this.gamedata.LiveProb.home_win_pct
      }
      return this.gamedata.home_win_pct
    },
    AwayWinPer(){
      if(this.gamedata.Status == "InProgress" || this.gamedata.Status == "Final"){

        return this.gamedata.LiveProb.away_win_pct
      }
      return this.gamedata.away_win_pct
    },
    startsIn() {
      if (
        moment
          .utc(this.gamedata.DateTimeUTC + ".128Z")
          .isAfter(moment().utc())
      ) {
        return moment
          .utc(this.gamedata.DateTimeUTC + ".128Z")
          .diff(moment().utc(), "hours");
      }
      return moment()
        .utc()
        .diff(moment
          .utc(this.gamedata.DateTimeUTC + ".128Z"), "hours");
    },
    iscompleted() {
      return moment().isBefore(moment(this.gamedata.gamedatee));
    },
    livematch() {
      return (
        moment().isSameOrAfter(moment(this.gamedata.gamedate)) &&
        moment().isSameOrBefore(moment(this.gamedata.gamedatee))
      );
    },
    getHTeamlogo() {
      return this.gamedata.HomeTeam.NbaDotComTeamID;
    },
    getaTeamlogo() {
      return this.gamedata.AwayTeam.NbaDotComTeamID;
    },
  },

  data() {
    return {
      tab: null,
      siteUrl: null,
      linupslider1: {
        slidesPerView: "auto",
        spaceBetween: 0,
        pagination: {
          el: ".swiper-pagination",
        },
        navigation: {
          nextEl: ".next1",
          prevEl: ".prev1",
        },
      },
      linupslider2: {
        slidesPerView: "auto",
        spaceBetween: 0,
        pagination: {
          el: ".swiper-pagination",
        },
        navigation: {
          nextEl: ".next2",
          prevEl: ".prev2",
        },
      },
    };
  },
};
</script>
