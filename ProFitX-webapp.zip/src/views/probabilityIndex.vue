<template>
  <div class="probality_index">
    <div class="pI_tabs">
      <probabilityPeriod @reloadProb="reloadProb"></probabilityPeriod>
    </div>
    <div class="pI_matches_title" style="display: none">
      <span>4 Live Matches</span>
    </div>

    <div class="pI_matches_list">
      <div class="loading-page" v-if="isloading">
        <figure>
          <img src="@/assets/images/loader.gif" />
        </figure>
        Loading
      </div>
      <template v-else>
        <template v-for="(game, index) in gameslist">
          <teamProbability :gamedata="game" :key="index"></teamProbability>
        </template>
      </template>
    </div>
  </div>
</template>

<script>
import moment from "moment";
import "swiper/dist/css/swiper.css";
import teamProbability from "@/views/components/teamProbability.vue";
import probabilityPeriod from "@/views/components/probabilityPeriod.vue";
export default {
  components: {
    teamProbability,
    probabilityPeriod,
  },
  methods: {
    reloadProb(date) {
      if (!date.reload) {
        this.isloading = true;
      }
      this.$store
        .dispatch("gettodayprobability2", {
          startdate: date.date,
          enddate: date.edate,
        })
        .then((response) => {
          this.gameslist = [];
          var _games = [];
          if (response && response.length > 0) {
            response.forEach((element) => {
              var _e = element;
              _e["sortdate"] = moment(_e.gamedate);
              _games.push(_e);
            });
            _games = this.lodash.orderBy(_games, "sortdate", ["asc"]);
            this.gameslist = _games;
            this.isloading = false;
          } else {
            var _aresponse = JSON.parse(response);

            _aresponse.forEach((element) => {
              var _e = element;
              _e["awayteamdata"] = JSON.parse(_e.awayteamdata);
              _e["cheadtoheada"] = JSON.parse(_e.cheadtoheada);
              _e["headtoheada"] = JSON.parse(_e.headtoheada);
              _e["headtoheadh"] = JSON.parse(_e.headtoheadh);
              _e["hometeamdata"] = JSON.parse(_e.hometeamdata);
              _e["gamedatee"] = moment(_e.gamedate).add(150, "minutes");
              _e["sortdate"] = moment(_e.gamedate);

              _games.push(_e);
            });

            _games = this.lodash.sortBy(_games, "sortdate");
            this.gameslist = _games;
            if (!date.reload) {
              this.isloading = false;
            }
          }
        });
    },
  },
  mounted() {

    if([1, 2, 3, 5].indexOf(this.$store.state.userRole) > -1){

 var t = 100
    }else{
this.$router.push("/plan");

    }
    
  },
  data() {
    return {
      isloading: true,
      gameslist: null,
    
    };
  },
};
</script>
