<template>
  <div class="content-body"> 
    <sidebar v-if="player!=null" :player=player />
    <div class="content-wrapper">
      <div class="athlete_content_wrap">
        <v-row>
          <v-col><player-details v-if="player"  :player="player" /></v-col>
        </v-row>
         <div class="nodataBox" v-if="player && player.RTC == null">

                No Data Available
            </div>
            <div class="athlete_body_content" v-if="player && player.RTC">
          <v-row>
              <v-col><teamValue/></v-col>
          </v-row>        
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import playerDetails from "@/views/components/playerDetails.vue";
import teamValue from "@/views/components/teamValue.vue";
import Sidebar from "@/layouts/components/Sidebar.vue";


export default {
  data() {
    return {};
  },
  watch: {},
  computed: {},
  methods: {},
  components: {
    playerDetails,
    teamValue,
    Sidebar
  },
  created() {}
};
</script>

<style>

</style>