<template>
<div class="flex w-full bg-img vx-row no-gutter  justify-center login-wrapper" id="page-login">
    <div class="login-support-wrap">
        <!-- <div class="login-logo-img">
            <img src="@//assets/images/logo.svg" alt="ProFitX" class="login-logo-img">
            

        </div> -->
            <div class="success_alert" v-if="formmessage && formmessage.msg!=''">
                <figure>
                    <v-icon>mdi-check-decagram-outline</v-icon>  
                </figure>
                <p>{{ formmessage.msg }}</p>                                 
            </div>

            <div v-else>
                <h2>Forgot Password</h2>
                <form class="pad0">
                    <div class="text-danger text-sm formerrors" v-if="formerrors && formerrors.msg!=''">
                        {{ formerrors.msg }}                           
                    </div>
                    <div class="login-inputs" >
                        <div class="inputbix email">
                            <v-text-field name="email" class="text_field" label="Email" v-validate="'required|email'" v-model="user.email" single-line outlined></v-text-field>
                            <span class="error-text" v-show="errors.has('email')">{{ errors.first("email") }}</span>
                        </div>             

                        <div class="action_btns">
                            <a class="primary_btn" @click="submitForm()" href="javascript:;">
                                Reset Password
                            </a> 
        
                        
                        </div>

                    </div>
                </form>
            </div>
    </div>
</div>
</template>

<script>
export default {
    data() {
        return {
            test: true,
            user: {
                email: "",
                password: ""
            },
            checkbox_remember_me: false,
            formmessage: {
                msg: ""
            },
            formerrors: {
                msg: ""
            }
        };
    },
    methods: {
        clearfields() {
            Object.assign(this.user, {
                email: "",
                password: ""
            });
        },
        requestAgain() {
            this.$vs.loading();

            const obj = {
                apiKey: "FV$HSE@JUGUUGU$J5L@HE",
                tenantId: "5db7d79d6032453bd060ed9c",
                email: this.user.email
            };

            Object.assign(this.formerrors, {
                msg: ''
            });
            Object.assign(this.formmessage, {
                msg: ''
            });
            this.$store
                .dispatch("petitioner/requestactivationEmail", obj)
                .then(response => {
                    this.$vs.loading.close();
                    Object.assign(this.formerrors, {
                        msg: ''
                    });
                    Object.assign(this.formmessage, {
                        msg: ''
                    });
                    if (response.error) {
                        Object.assign(this.formerrors, {
                            msg: response.error.message
                        });
                    } else {
                        Object.assign(this.formmessage, {
                            msg: response.data.result.message
                        });

                    }
                })
                .catch(() => {});

        },
        submitForm() {
            Object.assign(this.formerrors, {
                msg: ''
            });
            Object.assign(this.formmessage, {
                msg: ''
            });
            this.$validator.validateAll().then(result => {
                if (result) {
                    const obj = {
                        email: this.user.email
                    };

                    this.$store
                        .dispatch("forgotpassword", obj)
                        .then(response => {
                        
                            if (response.error) {
                                Object.assign(this.formerrors, {
                                    msg: response.error.message
                                });
                            } else {
                           // this.$router.go('/athletes');
                                 Object.assign(this.formmessage, {
                                    msg: response.data.result.message
                                });
                                this.user=  {email: "", password: "" };
                                this.$validator.reset();
                            }
                        })
                        .catch(() => {


                        });

                    // if form have no errors
                } else {
                    // form have errors
                }
            });
        }
    }
};
</script>
