<template>
  <div class="profile_section" @click="snackbar =false">
    <div class="prfile_nav">
      <menuItems/>
    </div>
    <div class="profile_body">

    <div class="action_btns">
      <div class="d-flex align-items-center">
      <input class="search"  v-model="searchtxt"  @keyup="getSupportTickets()" placeholder="Search">
      <div class="range_picker">
        <v-menu
                        ref="menu"
                        v-model="menu"
                        :close-on-content-click="false"
                        
                        transition="scroll-x-transition"
                        offset-y
                        min-width="auto"
                      >
                        <template v-slot:activator="{ on, attrs }">
                          <v-text-field
                            v-model="dateRangeText"
                            label=""
                            placeholder="Select Date Range"
                            prepend-icon="mdi-calendar"
                            readonly
                            v-bind="attrs"
                            v-on="on"

                          ></v-text-field>
                        </template>
                        <v-date-picker
                          v-model="dateRange"
                          :show-current="true"
                          :max="new Date().toISOString()"
                          range
                          no-title
                          scrollable
                        >
                          <v-spacer></v-spacer>
                          <v-btn
                            text
                            color="primary"
                            @click="menu = false;dateRange=[];getSupportTickets();"
                          >
                            Cancel
                          </v-btn>
                          <v-btn
                            text
                            color="primary"
                            @click="$refs.menu.save(dateRange);getSupportTickets();"
                            :disabled="dateRange.length<2"
                          >
                            OK
                          </v-btn>
                        </v-date-picker>
        </v-menu>
      </div>
      </div>
      <!--v-if="getProfileData.userRole==4"-->
      <button v-if="getUserrole==4" class="primary_btn" @click="initNewComment()"> 
          New Ticket
        </button> 
    </div>
      <div class="support_table">
        
        <v-simple-table fixed-header height="300px">
          <template v-slot:default>
            <thead>
              <tr>
                <th>                 
                  <span @click="sortMe('customId')"  v-bind:class="{'sort_ascending':sortKeys['customId']==1, 'sort_descending':sortKeys['customId']!=1}">Ticket ID</span>
                </th>
                <th>
                  <span @click="sortMe('subject')" v-bind:class="{'sort_ascending':sortKeys['subject']==1, 'sort_descending':sortKeys['subject']!=1}">Title</span>
                </th>
                <th>
                  <span @click="sortMe('createdOn')"  v-bind:class="{'sort_ascending':sortKeys['createdOn']==1, 'sort_descending':sortKeys['createdOn']!=1}">Created On </span>
                 </th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <template v-if="tickets.length >0">
                <template     v-for="(item, index) in tickets">
                    <tr :key="index" @click="showtr(item, index)">
                    <td>{{item['customId']}}</td>
                    <td>{{item['subject']}}</td>
                    <td>{{item['createdOn'] | formatDate}}</td>
                    <td>{{checkProperty(item ,'statusDetails' ,'name')}}</td>
                    <td class="arrow">
                        <v-icon v-if="item.is_expend">mdi-chevron-up</v-icon>
                        <v-icon v-if="!item.is_expend">mdi-chevron-down</v-icon>
                    </td>
                    </tr>
                    <tr v-if="item.is_expend" :key="100000+index">
                    <td colspan="5" class="expanded">
                        <div class="expanded_cnt">

                        <div class="init_comments">
                          <span class="ticketdate">{{item['createdOn'] | formatDateTime}}</span>
                            <p>
                            {{item['description']}}
                            </p>
                            

                            <ul class="uploded_list" v-if="item['attachments'].length>0">
                                <template  v-for="(fle, sfi) in item['attachments']">
                                <li :key="sfi"  @click="download_file(fle)">
                                    <figure>
                                    <img src="@/assets/images/image.svg" />
                                    </figure>
                                    <figcaption>Title</figcaption>
                                </li>
                                </template>
                                
                                </ul>
                            
                        </div>
                        <div class="comments_entry" v-if="item.statusId!=5">
                        
                            <textarea type="text" class="inputarea" name="Comment" data-vv-as="Comment" v-model="CommentPayload.description" v-validate="'required'"></textarea>
                            <span class="error-text" v-show="errors.has('Comment')">{{ errors.first("Comment") }}</span>
                
                            <div class="comments_actions">
                            <div class="file_upload_input" @click="documents = []">
                                <file-upload
                                v-model="documents"
                                class="file-upload-input"
                                accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                :name="'Documents'+index" 
                                :multiple="true"
                                data-vv-as=" documents"
                                @input="upload(documents , 'comment_attachments')"
                                
                                >
                                <span @click="documents = []"
                                    ><v-icon>mdi-paperclip</v-icon>Upload
                                    Attachments</span
                                >
                                </file-upload>
                            </div>
                            <div class="action_buttons" >
                                                      
                                <select v-if="[1,2,3].indexOf(getUserrole) > -1" v-model="item.selectedStatusId" :name="'status_'+index" @change="changedtickedStatus(item.selectedStatusId , index ,item)" placeholder="status" > 
                                <template v-for="(statusItem , stin) in all_statusids">
                                <option :value="statusItem['_id']" :key="stin">{{statusItem.name}}</option>
                                </template>
                                
                                
                                </select>
                                <button :disabled="checkComment" @click="supportTicketsCreateComment()" class="post_btn">POST</button>
                            </div>
                            </div>
                        </div>
                        <div class="uploding_list">
                        
                            <ul class="uploding_list">
                            <template v-for="(item, uf) in CommentPayload['attachments']">
                                    <li  :key="uf" @click="remove(item, CommentPayload.attachments , uf)"  closable v-if="item.status !== false  && item.name !== null  && item.url !== null  && item.url !== ''">
                                       <!-- {{ item.name }}-->
                                        <figure>
                                          <img src="@/assets/images/image.svg" />
                                        </figure>
                                       
                                        <span><v-icon>mdi-close</v-icon></span>
                                         <figcaption>{{checkProperty( item,'name')}}</figcaption>
                                    </li>

                                    
                                </template>
                            </ul>
                        </div>
                        <div class="comments_list_wrap" v-if="item.all_comments.length>0">
                            <div class="comments_list" v-for="( comment,ic) in item.all_comments" :key="ic">
                            <figure>
                                <img @error="getProfilePhoto($event )" :src="checkProperty(comment,'createdByDetails','profilePicture')" />
                            </figure>
                            <div class="comment_details">
                                <strong>{{checkProperty(comment,"createdByDetails","name")}}<span>{{comment.createdOn | formatDateTime}}</span></strong>
                                <p>{{comment.description}}</p>
                                

                                <ul class="uploded_list" v-if="comment['attachments'].length>0">
                                <template  v-for="(fl, cfi) in comment['attachments']">
                                <li :key="cfi"  @click="download_file(fl)">
                                    <figure>
                                    <img src="@/assets/images/image.svg" />
                                    </figure>
                                     <figcaption>{{checkProperty( fl,'name')}}</figcaption>
                                </li>
                                </template>
                                
                                </ul>
                            </div>
                            </div>
                            <!--
                              @click="download_file(item)"
                              <div class="comments_list">
                            <figure>
                                <img src="@/assets/images/avatar1.png" />
                            </figure>
                            <div class="comment_details">
                                <strong>John</strong>
                                <p>
                                Lorem Ipsum is simply dummy text of the printing
                                and typesetting industry. Lorem Ipsum has been the
                                industry's standard dummy text ever since the
                                1500s, when an unknown printer took a galley…
                                </p>
                            </div>
                            </div>
                            <div class="comments_list">
                            <figure>
                                <img src="@/assets/images/avatar1.png" />
                            </figure>
                            <div class="comment_details">
                                <strong>John</strong>
                                <p>
                                Lorem Ipsum is simply dummy text of the printing
                                and typesetting industry. Lorem Ipsum has been the
                                industry's standard dummy text ever since the
                                1500s, when an unknown printer took a galley…
                                </p>
                                <ul>
                                <li>
                                    <figure>
                                    <img src="@/assets/images/image.svg" />
                                    </figure>
                                </li>
                                <li>
                                    <figure>
                                    <img src="@/assets/images/image.svg" />
                                    </figure>
                                </li>
                                </ul>
                            </div>
                            </div>-->
                        </div>
                        </div>
                    </td>
                    </tr>                
                </template>
              </template>
              <tr>
                  <td v-if="tickets.length <=0" colspan="6" class="no-data">No Tickets Found!</td>
                </tr>
            </tbody>
          </template>
        </v-simple-table>
        <div class="pagination_wrap"  v-if="tickets.length > 0">
        <paginate         
          v-model="page"
          :page-count="totalpages"
          :page-range="3"
          :margin-pages="2"
          :click-handler="pageNate"
          prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
          next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next"
          :prev-text="'<i></i>'"
          :next-text="'<i></i>'"
          :container-class="'pagination vs-pagination--nav'"
          :page-class="'page-item'"
        ></paginate>
        </div>
      </div>
    </div>
    <v-dialog
      v-model="AddNewTicket"
      max-width="400"
      class="card_dialog" fullscreen
      persistent
    >
      <div class="dialog_body">
        <div class="dialog_head">
          <h4>New Ticket</h4>
          <v-btn
            color="primary"
            text
            @click="AddNewTicket = false"
            class="close-btn"
          >
            <v-icon>mdi-close</v-icon>
          </v-btn>
        </div>
        <div class="form_section">
          <form v-on:submit.prevent>
          
          <div class="row" v-if="formerrors.msg">
              <div class="col">
                <div class="form-group">
                 <span class="form_error-text"> {{formerrors.msg}}</span>
                 </div>
              </div>
            </div>
          <!--
            <div class="row">
              <div class="col">
                <div class="form-group">
                  <label class="form_label">Ticket ID</label>
                  <input type="text" class="form_control" />
                 </div>
              </div>
            </div>-->
            <div class="row">
              <div class="col">
                <div class="form-group">
                  <label class="form_label">Title</label>
                  <input type="text" class="form_control" v-model="newTicket.subject" placeholder="Title" name="subject" v-validate="'required'"  data-vv-as="Title"  />
                  <span class="error-text" v-show="errors.has('subject')">{{ errors.first("subject") }}</span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col">
                <div class="form-group">
                  <label class="form_label">Comments</label>
                  <textarea type="text" class="form_control" name="description" data-vv-as="Description" v-model="newTicket.description" v-validate="'required'"></textarea>
                  <span class="error-text" v-show="errors.has('description')">{{ errors.first("description") }}</span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col">
                <div class="upload-group" @click="documents = []">
                  <!-- <label class="form_label">Files</label> -->
                   <file-upload
                      v-model="documents"
                      class="file-upload-input"
                      accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      :name="'Documents'+index" 
                      :multiple="true"
                      data-vv-as=" documents"
                      @input="upload(documents ,'newTicke')"
                      
                    >
                      <span @click="documents = []"
                        ><v-icon>mdi-paperclip</v-icon>Upload
                        Attachments</span
                      >
                    </file-upload>
                    <ul class="uploded_list">
                      <li v-for="(attachment, ai) in newTicket.attachments" :key="ai" 
                       @click="remove(attachment, newTicket.attachments , ai)"
                       >
                       <!-- {{attachment.name}} -->
                          <figure>
                          <img src="@/assets/images/image.svg" />
                          </figure>
                          <figcaption>{{checkProperty( attachment,'name')}}</figcaption>
                          <span><v-icon>mdi-close</v-icon></span>
                       </li>
                    </ul>
                </div>
              </div>
            </div>
            <div class="dialog_actions">
            
              <button
               :disabled="checkNewTicket"
                class="primary_btn w-100"
                href="javascript:;"
                @click="supportTicketsCreate()"
              >
                Create
              </button>
            </div>
          </form>
        </div>
      </div>
    </v-dialog>
    <!-- <v-snackbar
    v-model="snackbar"
    :vertical="vertical"
      right
    shaped
    top 
    >
    {{ snackbarMessage }}

    <template v-slot:action="{ attrs }">
        <v-btn
        color="indigo"
        text
        v-bind="attrs"
        @click="snackbar = false"
        >
        Close
        </v-btn>
    </template>
    </v-snackbar> -->
    <snakebar v-if="snackbar" :snackbar="snackbar" :msg="snackbarMessage" :isError="isError" />
    
    
            <div class="loading-page" v-if="isloading">
                <figure>
                    <img src="@/assets/images/loader.gif">
                </figure>Loading
            </div>
  </div>
</template>

 

<script>
import FileUpload from "vue-upload-component/src";
import moment from "moment";
import _ from "lodash";
import Paginate from "vuejs-paginate";
import menuItems from "@/views/components/menuItems.vue";
import snakebar from "@/views/components/snakebar.vue";
 
export default {
  components: {
    snakebar,
    FileUpload,
    Paginate,
    menuItems
  },
  mounted(){
    this.setPageTitle("ProFitX - Support Tickets ");
    
      this.sortKeys = {
      'subject':1,
      'description':1,
      "customId":1,
      "createdOn":-1,
     

    }
    this.sortKey['createdOn'] =-1;
    
    
      this.get_statusids();
      this.getSupportTickets();
  },
  data() {
    return {

      menu: false,
      modal: false,
      menu2: false,
      dateRange: [],

        isloading:false,
        loaded:false,
        snackbarMessage:'',
        snackbar:false,
        isError:false,
        vertical: true,
      list: [{ is_expend: false }, { is_expend: false }, { is_expend: false }],
      documents: [],
      AddNewTicket: false,
      value: [],
      newTicket: {
        subject: "",
        description: "",
        attachments: [],
        today: moment().format("YYYY-MM-DD"),
      },
      formerrors: {
        msg: "",
      },
      tickets: [],
      sortKeys: {},
      sortKey: {},
      searchtxt: "",
      page: 1,
      perpage: 25,
      totalpages: 0,
      perPeges: [10, 25, 50, 75, 100],
      filter_searchtxt: "",
      all_statusids: [],
      selected_statusids: [],
      final_selected_statusids: [],

      buttoncol: true,
      currentuserRole: null,
      selected_createdDateRange: ["", ""],
      autoApply: "",
      roleId: 0,
      all_user_roles: [],
      users: [],
      selected_user: null,
      assignmrntPopUp: false,
      selected_role: "",

      ticket_comments: [],
      ticket: null,
      selected_ticketId: "",
      selected_ticket_tindex: null,
      CommentPayload: {
        ticketId: "",
        statusId: "",
        description: "",
        attachments: [],
        today: moment().format("YYYY-MM-DD"),
      },
    };
  },
  

  methods: {
      changedtickedStatus(statusId ,index ,item){
          let sid = this.tickets[index].selectedStatusId
          let st = _.find(this.all_statusids ,{"_id":statusId});
          if(this.tickets[index]["statusId"] !=1 && sid ==1){
            this.tickets[index]['selectedStatusId']  = this.tickets[index]["statusId"];
            item['selectedStatusId'] = this.tickets[index]["statusId"];
          }
        
      },
      initNewComment(){
          this.documents =[];
          this.snackbarMessage = '';
          this.isError =false;
          this.AddNewTicket = true,
          this.formerrors.msg='';
          this.newTicket = {
            subject: "",
            description: "",
            attachments: [],
            today: moment().format("YYYY-MM-DD"),
          }
        this.$validator.reset();
      },
    showtr(item, index) {
             
        this.selected_ticketId = item["_id"];
        this.selected_ticket_tindex = index;
        this.CommentPayload =  {
        ticketId: this.selected_ticketId,
        statusId: item['statusId'],
        description: "",
        attachments: [],
        today: moment().format("YYYY-MM-DD"),
      }
     this.$validator.reset();
      if (item.is_expend) {
        item.is_expend = false;
      } else {
        item.is_expend = true;
        this.loadTicketComments();
      }

      _.forEach(this.tickets,(ticket ,ind)=>{
          if(index !=ind){
               this.tickets[ind]['is_expend'] = false;
          }

      });
    },
    successUpload() {
      this.$vs.notify({
        color: "success",
        title: "Upload Success",
        text: "Lorem ipsum dolor sit amet, consectetur",
      });
    },
    upload(files, type = "") {
      let model = _.cloneDeep(files);
      this.documents =[];
      var _current = this;
      //this.$vs.loading();
      
     this.isloading =true;
      let formData = new FormData();

      let tempFiles = [];
      let tempFilesNames =[];
      if (model.length > 0) {
        model.forEach((doc, index) => {
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          formData.append("getDetails", true);

          this.$store.dispatch("uploadS3File", formData).then((response) => {
            response.data.result.forEach((urlGenerated) => {
              doc.url = urlGenerated;
              delete doc.file;
              let temp_file = urlGenerated;

              tempFiles.push(temp_file);
              let fl = {
                name: temp_file["name"],
                url: temp_file["path"],
                mimetype: temp_file["mimetype"],
              };
              if(tempFilesNames.indexOf(temp_file["name"]) <=-1){
                    
                    if (type == "comment_attachments") {
                    //this.CommentPayload

                    this.CommentPayload["attachments"].push(fl);
                  } 
                  if(type == 'newTicke') {
                    this.newTicket.attachments.push(fl);
                  }


              }
              tempFilesNames.push(temp_file["name"]);

              
              if (tempFiles.length >= model.length) {
               // _current.$vs.loading.close();
                this.isloading =false;

              }
            });
          });
        });
      }
      //  model.splice(0, mapper.length, ...mapper);
    },
    remove(item, data, filindex) {
      data.splice(filindex, 1);
    },

    pageNate(pageNum) {
      this.page = pageNum;
      this.getSupportTickets();
    },
    set_filter: function () {
      this.final_selected_statusids = [];

      if (this.selected_statusids.length > 0) {
        this.final_selected_statusids = [];
        for (let ind = 0; ind < this.selected_statusids.length; ind++) {
          let current_index = this.selected_statusids[ind];
          this.final_selected_statusids.push(current_index["id"]);
        }
      }

      this.searchtxt = this.filter_searchtxt;

      this.getSupportTickets();
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    clear_filter: function () {
      this.searchtxt = "";
      this.selected_statusids = [];
      this.final_selected_statusids = [];

      this.date = "";
      this.date_range = [];
      this.selected_createdDateRange["startDate"] = "";
      this.selected_createdDateRange["endDate"] = "";

      this.filter_searchtxt = "";
      this.$refs["filter_menu"].dropdownVisible = false;
      this.getSupportTickets();
    },
    getStatusName(id='' ,index){
       let st = _.find(this.all_statusids ,{"id":id});
       if(st && _.has(st ,"name")){
           this.tickets[index]['statusDetails'] = st;
           return st['name'];
       }else{
           return "";
       }

    },

    get_statusids() {
      this.$store
        .dispatch("getmasterdata", "support_status")
        .then((response) => {
          //console.log(response);
          let lst = response;
          
          
          this.all_statusids = _.filter(lst ,(item)=>{
            return item['id'] != 1;
          });
          
          //this.all_statusids = response;
          this.getSupportTickets();
        });
    },
    getSupportTickets() {
      //  "title": "INTK-TK",
      //             "statusIds": [1, 2, 4],
      //             "assignedToIds": ["5de4a68f3f265070080ad945"],
      //             "createdByIds": ["5de4f0957573e61e381688ea"],

      let obj = {
        matcher: {
          title: this.searchtxt,
          statusIds: this.final_selected_statusids,
          assignedToIds: [],
          createdByIds: [],
          dateRange: [],
        },
        page: this.page,
        perpage: this.perpage,
        sortKeys: this.sortKey,
      };

      if ( this.dateRange.length >=2) {
        obj["matcher"]["dateRange"] = [moment(this.dateRange[0]).format("YYYY-MM-DD") ,moment(this.dateRange[1]).format("YYYY-MM-DD")];
      }

      this.$store
        .dispatch("supportTicketsList", obj)
        .then((response) => {
          let data = response.list;
          let temp_list = [];
          _.forEach(data, (obj) => {
            //obj['statusDetails'] =null; 
            obj['selectedStatusId'] = obj['statusId'];
            obj["is_expend"] = false;
            obj["all_comments"] = [];
            temp_list.push(obj);
          });
          this.tickets = temp_list;
          this.totalpages = Math.ceil(response.totalCount / this.perpage);
        })
        .catch((err) => {
          //alert(err);
          this.tickets = [];
        });
    },
    sortMe(sort_key = "") {
      if (sort_key != "") {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
        this.sortKey = {};
        this.sortKey[sort_key] = this.sortKeys[sort_key];

        localStorage.setItem("tickets_sort_key", sort_key);
        localStorage.setItem("tickets_sort_value", this.sortKey[sort_key]);
        this.getSupportTickets();
      }
    },
    changeperPage() {
      this.page = 1;
      localStorage.setItem("petitions_perpage", this.perpage);
      this.getSupportTickets();
    },
    resetNewTicket() {
      this.AddBeneficiary = false;
      this.newTicket = {
        subject: "",
        description: "",
        attachments: [],
        today: moment().format("YYYY-MM-DD"),
      };
      this.$validator.reset();
    },
    supportTicketsCreate() {
      this.$store
        .dispatch("supportTicketsCreate", this.newTicket)
        .then((response) => {
          this.AddNewTicket = false;
          this.snackbarMessage  = response.message
          this.snackbar = true;
          this.isError =false;
          this.getSupportTickets();
        })
        .catch((err) => {
          //alert(JSON.stringify(err));
          this.formerrors.msg = err;
        
        });
    },
    supportTicketsUpdate() {
      this.$store
        .dispatch("supportTicketsUpdate", this.newTicket)
        .then((response) => {
          this.AddNewTicket = false;
          this.snackbarMessage  = response.message
          this.snackbar = true;
          this.getSupportTickets();
        })
        .catch((err) => {
          //alert(JSON.stringify(err));
          this.formerrors.msg = err;
       
        });
    },

    supportTicketsCreateComment() {
      this.formerrors.msg = "";
      this.CommentPayload["statusId"] =
        this.tickets[this.selected_ticket_tindex]["selectedStatusId"];
      this.$store
        .dispatch("supportTicketsComment", this.CommentPayload)
        .then((response) => {
            this.getSupportTickets();
          this.AddNewTicketComment = false;
          this.snackbarMessage  = response.message
          this.snackbar = true;
          this.isError =false;

          this.CommentPayload =  {
            ticketId: this.selected_ticketId,
            statusId: this.tickets[this.selected_ticket_tindex]["selectedStatusId"],
            description: "",
            attachments:[],

            today: moment().format("YYYY-MM-DD"),
        }
     this.$validator.reset();
          this.reloadTicket(
            this.selected_ticketId,
            this.selected_ticket_tindex
          );
        })
        .catch((err) => {
          //alert(JSON.stringify(err));
          this.formerrors.msg = err;
       
        });
    },
    resetComment() {
      this.formerrors.msg = "";
      this.CommentPayload = {
        ticketId: "",
        statusId: this.ticket["statusId"],
        description: "",
        attachments: [],
        today: moment().format("YYYY-MM-DD"),
      };
      this.$validator.reset();
    },
    reloadTicket(id, tindex) {
      this.formerrors.msg = "";
      this.selected_ticketId = id;
      this.selected_ticket_tindex = tindex;
      this.CommentPayload.ticketId = id;

      this.CommentPayload["ticketId"] = this.selected_ticketId;
      // this.loadTicket();

      //this.tickets[this.selected_ticket_tindex]["is_expend"] != this.tickets[this.selected_ticket_tindex]["is_expend"];

      //if( !this.tickets[this.selected_ticket_tindex]['is_expend']){
      this.loadTicketComments();
      // }
    },

    loadTicket() {
      this.loaded = false;
      this.$store
        .dispatch("supportTickesDetails", { ticketId: this.selected_ticketId })
        .then((response) => {
          //alert(JSON.stringify(response));
          this.ticket = response;
        });
    },

    loadTicketComments() {
      this.loaded = true;
      this.tickets[this.selected_ticket_tindex]["is_expend"] = false;
      this.$store
        .dispatch("supportTickeCommentList", {
          ticketId: this.selected_ticketId,
        })
        .then((response) => {
          this.tickets[this.selected_ticket_tindex]["all_comments"] = response;
          this.tickets[this.selected_ticket_tindex]["is_expend"] = true;
          this.tickets = this.tickets;
          this.loaded = false;
        });
    },
    getUsers(roleId = "") {
      this.$store.dispatch("getusersByrole", roleId).then((response) => {
        this.users = response.list;
      });
    },

    chengedUserRole() {
      // alert(JSON.stringify(this.selected_role));
      this.getUsers(this.selected_role["id"]);
    },

    assgnment() {
      this.formerrors.msg = "";
      let payLoad = {};
      payLoad["ticketId"] = this.selected_ticketId;
      payLoad["assignedTo"] = this.selected_user["_id"];
      this.$store
        .dispatch("supportTicketsAssign", payLoad)
        .then((response) => {
          this.assignmrntPopUp = false;
          this.$vs.notify({
            title: "Success",
            position: "top-right",
            color: "success",
            iconPack: "feather",
            icon: "icon-check",
            text: response.message,
          });
          this.reloadTicket(
            this.selected_ticketId,
            this.selected_ticket_tindex
          );
        })
        .catch((err) => {
          //alert(JSON.stringify(err));
          this.formerrors.msg = err;
          
        });
    },
  },
  watch: {
    dateRange: function(val){
      
     // this.getSupportTickets();
    },
    
    searchtxt: function (value) {
      this.getSupportTickets();
    },
  },
   computed: {
      
         getUserrole() {
            return this.$store.state.userRole;
        },
     getProfileData(){
         return this.$store.state.user;
     },
     dateRangeText () {
        return this.dateRange.join(' To ')
      },
       checkComment(){
          

        if(
        (this.CommentPayload['ticketId'] =='' || this.CommentPayload['ticketId'] ==null || this.CommentPayload['ticketId'] ==undefined)
        || (this.CommentPayload['description'] =='' || this.CommentPayload['description'] ==null || this.CommentPayload['description'] ==undefined)
        //|| (this.CommentPayload['statusId'] =='' || this.CommentPayload['statusId'] ==null || this.CommentPayload['statusId'] ==undefined)
       
       ){
            
            return true;

        }else{
            return false;

        }
       },

     checkNewTicket(){
         //profileData:{ "firstName": "","middleName": "", "lastName": "", "name": "", "email": "", "password": "","phoneNo": "", "roleId": "6"},
        if(
        (this.newTicket['subject'] =='' || this.newTicket['subject'] ==null || this.newTicket['subject'] ==undefined)
        || (this.newTicket['description'] =='' || this.newTicket['description'] ==null || this.newTicket['description'] ==undefined)
       ){
            
            return true;

        }else{
            return false;

        }
        
     },
  }
};
</script>
