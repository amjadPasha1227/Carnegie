<template>
<div class="content-body">
    <div class="under_construction_wrap">
        <div class="under_construction">
            <figure><img src="@/assets/images/profitx_logo.svg"></figure>
            <div class="under_construction_text">
                <h4>We are <br/>under construction</h4>
                <a href="mailto:je@profitx.ai">Contact US</a>
            </div>
        </div>

        <figure class="player_img"><img src="@/assets/images/player_img.svg"></figure>
    </div>
     
     
</div>
</template>

<script> 
 

export default {
    data() {
        return { 

        };
    },
     
      
        
        
 
  
   
};
</script>

<style>

</style>
