<template>
  <div
    class="flex w-full bg-img vx-row no-gutter justify-center login-wrapper"
    id="page-login"
  >
    <div class="login-support-wrap">
      <form style="padding: 0px" @submit.prevent="retrunFalse">
        <h2>Sign Up</h2>

        <div class="login-inputs">
          <div
            class="text-danger text-sm formerrors"
            v-if="formerrors && formerrors.msg != ''"
          >
            {{ formerrors.msg }}
          </div>
          <div class="inputbix name">
            <v-text-field
              name="First Name"
              placeholder="First Name"
              v-validate="'required|max:30'"
              v-model="newUser.firstName"
              single-line
              outlined
            ></v-text-field>
            <span class="error-text" v-show="errors.has('First Name')">{{
              errors.first("First Name")
            }}</span>
          </div>

          <div class="inputbix name">
            <v-text-field
              name="Last Name"
              placeholder="Last Name"
              v-validate="'required|max:30'"
              v-model="newUser.lastName"
              single-line
              outlined
            ></v-text-field>
            <span class="error-text" v-show="errors.has('Last Name')">{{
              errors.first("Last Name")
            }}</span>
          </div>

          <div class="inputbix email">
            <v-text-field
              data-vv-as="Email"
              name="email"
              class="text_field"
              placeholder="Email"
              v-validate="'required|email'"
              v-model="newUser.email"
              single-line
              outlined
            ></v-text-field>
            <span class="error-text" v-show="errors.has('email')">{{
              errors.first("email")
            }}</span>
          </div>
          <!--
                <div class="inputbix phone">
                    <v-text-field name="Phone number" v-on:keypress="checkPhonenumber($event)" class="text_field" placeholder="Phone (Optional)" v-model="newUser.phoneNo" v-validate="'max:15'" single-line outlined></v-text-field>
                    <span class="error-text" v-show="errors.has('Phone number')">{{ errors.first("Phone number") }}</span>

                </div>
                     -->
          <div class="inputbix password">
            <v-text-field
              name="Password"
              type="password"
              ref="password"
              class="text_field"
              placeholder="Password"
              v-validate="'required'"
              v-model="newUser.password"
              single-line
              outlined
            ></v-text-field>
            <em class="eye"><img src="@//assets/images/view.svg" /></em>
            <span class="error-text" v-show="errors.has('Password')">{{
              errors.first("Password")
            }}</span>
          </div>
          <div class="inputbix password">
            <v-text-field
              name="ConfirmPassword"
              type="password"
              class="text_field"
              placeholder="Confirm Password"
              data-vv-as="Confirm Password"
              v-validate="'required|confirmed:password'"
              v-model="newUser.cnfrmPassword"
              single-line
              outlined
            ></v-text-field>
            <span class="error-text" v-show="errors.has('ConfirmPassword')">{{
              errors.first("ConfirmPassword")
            }}</span>
          </div>

          <div class="input_actions justify-content-start">
            <v-checkbox
              v-model="newUser.acceptedTerms"
              :label="`I agree to the`"
            ></v-checkbox>
            <a
              href="https://profitx.ai/corporate/terms-and-conditions/"
              target="_blank"
              >Terms and Conditions</a
            >
            and
            <a
              class="privacy"
              href="https://profitx.ai/corporate/refund-policy/"
              target="_blank"
              >Payment Policy</a
            >
          </div>

          <div class="action_btns d-block">
            <input
              value="  Sign Up "
              type="submit"
              :disabled="signuphit || !newUser.acceptedTerms"
              class="primary_btn"
              @click="createUser()"
            />
            <!--<input value="  Sign Up"   type="submit" :disabled="signuphit || !newUser.acceptedTerms" class="primary_btn" @click="createUserBackup()" />-->

            <p>Already have an account? <a @click="showLogin()">Sign In</a></p>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
//import VuePhoneNumberInput from 'vue-phone-number-input';
import _ from "lodash";
export default {
  props: {
    selectedPlans: null,
    plan: null,
    loadedFromPopup: {
      type: Boolean,
      default: false,
    },
  },
  components: {
    //     VuePhoneNumberInput
  },
  mounted() {},
  computed: {
    checkNewUser() {
      if (
        this.newUser["firstName"] == "" ||
        this.newUser["firstName"] == null ||
        this.newUser["firstName"] == undefined ||
        this.newUser["middleName"] == "" ||
        this.newUser["middleName"] == null ||
        this.newUser["middleName"] == undefined ||
        this.newUser["lastName"] == "" ||
        this.newUser["lastName"] == null ||
        this.newUser["lastName"] == undefined
      ) {
        return true;
      } else {
        return false;
      }
    },
  },
  data() {
    return {
      signuphit: false,
      test: true,
      user: {
        email: "",
        password: "",
      },
      newUser: {
        pin: "",
        action: "set-password",
        newPassword: "",
        confirmPassword: "",
        userId: "",
        notUsingEmailLink: true,
        acceptedTerms: false,
        activateUser: true,
        firstName: "",
        middleName: "",
        lastName: "",
        name: "",
        email: "",
        password: "",
        cnfrmPassword: "",
        phoneCode: "",
        phoneNo: "",
        roleId: 4,
        passType: "",
        athletes: [],
        athletescount: 0,
        paymentAmt: 0,
        frequency: null,
      },
      checkbox_remember_me: false,
      formmessage: {
        msg: "",
      },
      formerrors: {
        msg: "",
      },
    };
  },
  methods: {
    retrunFalse() {
      return false;
    },
    showLogin() {
      this.$emit("showLogin", true);
    },
    createUserBackup() {
      var self = this;
      this.signuphit = true;

      Object.assign(this.formerrors, {
        msg: "",
      });
      Object.assign(this.formmessage, {
        msg: "",
      });

      if (this.plan) {
        this.newUser.passType = this.plan.uniqueId;
        this.newUser.athletescount = this.plan.criteria[0].qty;
        this.newUser.frequency = this.plan.frequencyDetails.__id;
        this.newUser.paymentAmt = this.plan.criteria[0].amount;
      }

      this.$validator
        .validateAll()
        .then((result) => {
          if (result) {
            this.$store
              .dispatch("registerNewUser", this.newUser)
              .then((res) => {
                this.signuphit = false;
                if (res.error) {
                  Object.assign(this.formerrors, {
                    msg: res.error.message,
                  });
                } else {
                  this.$emit("showResult", true);
                  const obj = {
                    email: this.newUser.email,
                    password: this.newUser.password,
                  };
                  const subobj = {
                    email: this.newUser.email,
                    name: this.newUser.firstName,
                    listId: 36008,
                  };
                  this.$store
                    .dispatch("subscribetoemaillist", subobj)
                    .then((response) => {});

                  var subscribepayLoad = {
                    selPlanIds: [],
                    plans: [],
                    source: null,
                    serviceTypeId: 1,
                    methodTypeId: 1,
                    newSource: true,
                    subscriber: {
                      name: self.newUser.firstName,
                      email: self.newUser.email,
                      phone: self.newUser.phoneNo,
                      phoneCode: "+1",
                    },
                    today: self.$moment(new Date()).format("YYYY-MM-DD"),
                    timezone: self.$moment.tz.guess(),
                    browserTS: self.$moment(new Date()),
                  };

                  subscribepayLoad.plans.push({
                    planId: self.plan._id,
                    criteria: self.plan.criteria,
                    frequencyDays: 0,
                  });
                  if (
                    self.selectedPlans &&
                    _.has(self.selectedPlans, "probabilityPlan")
                  ) {
                    if (_.has(self.selectedPlans["probabilityPlan"], "_id")) {
                      subscribepayLoad.plans.push({
                        planId: self.selectedPlans["probabilityPlan"]._id,
                        criteria:
                          self.selectedPlans["probabilityPlan"].criteria,
                        frequencyDays: 0,
                      });
                    }
                  }

                  this.$store
                    .dispatch("subscription/subscribe", subscribepayLoad)
                    .then((res) => {});

                  this.$store
                    .dispatch("login", obj)
                    .then((response) => {
                      if (response.error) {
                        Object.assign(this.formerrors, {
                          msg: response.error.message,
                        });
                      } else {
                        self.$router.push("/plan");
                      }
                    })
                    .catch(() => {});
                }
              })
              .catch((error) => {
                this.signuphit = false;
                Object.assign(this.formerrors, {
                  msg: error,
                });
              });
          } else {
            this.signuphit = false;
          }
        })
        .catch((error) => {
          this.signuphit = false;
        });
    },
    autologin() {
      Object.assign(this.formerrors, { msg: "" });
      let self = this;
      let obj = { email: "", password: "" };
      obj["email"] = this.newUser.email;
      obj["password"] = this.newUser.password;

      this.$store
        .dispatch("login", obj)
        .then((response) => {
          if (response.error) {
            this.showResult();
            Object.assign(self.formerrors, {
              msg: response.error.message,
            });
          } else {
            this.$emit("updateNewUser",this.newUser);

          }
        })
        .catch((err) => {
          this.showResult();
          Object.assign(this.formerrors, { msg: err });
        });
    },

    createUser() {
      var self = this;
      this.signuphit = true;

      Object.assign(this.formerrors, {
        msg: "",
      });
      Object.assign(this.formmessage, {
        msg: "",
      });

      if (this.plan) {
        this.newUser.passType = this.plan.uniqueId;
        this.newUser.athletescount = this.plan.criteria[0].qty;
        this.newUser.frequency = this.plan.frequencyDetails.__id;
        this.newUser.paymentAmt = this.plan.criteria[0].amount;
      }

      this.$validator
        .validateAll()
        .then((result) => {
          if (result) {
            this.$store
              .dispatch("registerNewUser", this.newUser)
              .then((res) => {
                this.signuphit = false;
                if (res.error) {
                  Object.assign(this.formerrors, {
                    msg: res.error.message,
                  });
                } else {
                  //every user subscribe



                  this.autologin();
                }
              })
              .catch((error) => {
                this.signuphit = false;
                Object.assign(this.formerrors, {
                  msg: error,
                });
              });
          } else {
            this.signuphit = false;
          }
        })
        .catch((error) => {
          this.signuphit = false;
        });
    },

    /**
     * On adding the phone number
     * @param item | Object
     */
    updatePhoneNumber(item) {
      if (item.isValid) {
        this.newUser.phoneCode = item.countryCallingCode;
        this.newUser.phoneNo = item.nationalNumber;
      }
    },
  },
};
</script>

<style scoped>
.body {
  overflow: hidden;
}
</style>
