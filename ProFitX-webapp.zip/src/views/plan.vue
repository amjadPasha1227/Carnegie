<template>
<div class="profile_section">
    <div class="prfile_nav">
        <menuItems />
    </div>
    <div class="profile_body">
        <div class="plans_wrap">

            <div class="plans_list athlete_pass">

                <label class="plans_label" v-if="userplan == null && selectedPlan!=null && selectedPlan.planDetails">{{selectedPlan.planDetails.name}}</label>
                <label class="plans_label" v-if="userplan != null ">{{userplan.name}}</label>

                <div class="plan_cnt">

                    <div class="athlete_pass_details">

                        <template v-if="userplan == null && selectedPlan!=null && selectedPlan.criteria && selectedPlan.criteria.length > 0">
                            <h6> <template v-if="selectedPlan!=null && selectedPlan.planDetails.uniqueId !='LEAGUEPASS' && selectedPlan.criteria[0].qty > 10">{{selectedPlan.criteria[0].qty}} Athletes</template> 
                            <template  v-if="selectedPlan!=null && selectedPlan.planDetails.uniqueId =='LEAGUEPASS'">480+ Athletes</template>
                            <strong>${{selectedPlan.criteria[0].amount}}<small><span v-if="selectedPlan.planDetails.uniqueId !='LEAGUEPASS'&& selectedPlan.frequencyId==1">/Month</span>
                                        <span v-if="selectedPlan && selectedPlan.planDetails.uniqueId !='LEAGUEPASS'&& selectedPlan.frequencyId==4">/Year</span></small></strong>

                                <span v-if="cancelled"> Plan cancelled on {{selectedPlan.createdOn | formatDate}} </span>

                            </h6>
                        </template>

                        <template v-if="userplan != null && userplan.criteria && userplan.criteria.length > 0">
                            <h6> <template v-if="selectedPlan.planDetails.uniqueId !='LEAGUEPASS'">{{userplan.criteria[0].qty}} Athletes</template> 
                             <template  v-if="selectedPlan.planDetails.uniqueId =='LEAGUEPASS'">480+ Athletes</template>
                            <strong>${{userplan.criteria[0].amount}}<small><span v-if="selectedPlan.planDetails.uniqueId !='LEAGUEPASS' && userplan.frequencyId==1">/Month</span>
                                        <span v-if="selectedPlan && selectedPlan.planDetails.uniqueId !='LEAGUEPASS'&& userplan.frequencyId==4">/Year</span></small></strong>

                            </h6>
                        </template>
                        <template v-if="selectedPlan && selectedPlan.planDetails.uniqueId =='LEAGUEPASS'">

                        </template>
                        <template v-else>

                            <div class="check_list" v-if="selectedPlan && selectedPlan.planDetails" >
                                {{selectedPlan.planDetails.description}}

                                          <template v-if="selectedPlan && selectedPlan.planDetails.uniqueId =='PROBABILITY'">
                                              If you don't cancel before the end of the free trial, we will automatically bill you for the subscription fee after the trial ends. Free trials require a credit card that automatically converts to active account unless canceled before trial period ends.
                        </template>
                            </div>
                        </template>
                        
                    </div>

                    <div class="plan_actions" v-if="selectedPlan!=null">
                        <button v-if="selectedPlan &&  (selectedPlan.planDetails.uniqueId !='LEAGUEPASS' && selectedPlan.invoiceDetails && selectedPlan.invoiceDetails.statusId==1) || (selectedPlan.planDetails.uniqueId !='LEAGUEPASS' && selectedPlan.invoiceDetails==null)" @click="upgradePlanpack=true;firsttime=true" class="primary_btn">Change</button>
                        <button v-if="selectedPlan && selectedPlan.planDetails.uniqueId !='LEAGUEPASS' && selectedPlan.invoiceDetails && selectedPlan.invoiceDetails.statusId==2 && !cancelled" @click="upgradePlanpack=true" class="primary_btn">Upgrade</button>
                        <button v-if="selectedPlan && userplan != null && selectedPlan.planDetails.uniqueId!=userplan.uniqueId" @click="reloadRoute()" class="secondary_btn">Cancel</button>

                    </div>
                </div>
            </div>

            <div class="plans_list" v-if="selectedPlan && selectedPlan.planDetails.uniqueId !='LEAGUEPASS' && selectedPlan.invoiceDetails && selectedPlan.invoiceDetails.statusId==2">
                <label class="plans_label">Athletes List</label>
                <div class="plan_cnt">
                    <div v-if="usersubscription.athletes && usersubscription.athletes.length > 0">
                        <selected-atheletes v-if="usersubscription.athletes" :athletes="usersubscription.athletes" />
                    </div>
                    <div v-if="usersubscription.athletes && usersubscription.athletes.length == 0">
                        <h5> Choose Athletes </h5>
                    </div>
                    <div class="plan_actions" v-if="usersubscription.athletes && usersubscription.athletes.length == 0">

                        <router-link to="athlete-selection" class="secondary_btn">
                            <v-icon>mdi-border-color</v-icon>Selet
                        </router-link>
                    </div>
                    <div class="plan_actions" v-if="usersubscription.athletes &&  usersubscription.athletes.length > 0">
                        <router-link to="athletes" class="primary_btn">

                            View

                        </router-link>
                        <router-link to="athlete-selection" class="secondary_btn" >
                            <v-icon>mdi-border-color</v-icon>Edit
                        </router-link>
                    </div>
                </div>
            </div>
        </div>

        <div class="row" v-if="cardDetails==null">

            <stripe-payment :cancelbtn="false" :selectedPlan="selectedPlan" :userplan="userplan" :stripe="stripeKey" />

        </div>

    </div>
    <v-dialog v-model="upgradePlanpack" width="auto " content-class="plan-upgrade" fullscreen persistent>
        <div class="dialog_body signup">
            <v-btn color="primary" text @click="upgradePlanpack = false" class="close-btn close-btn2">
                <v-icon>mdi-close</v-icon>
            </v-btn>
            <plans-list :defaultselected="selectedPlan" @changetheplan="changetheplan" ref="planlistupgrade" :firsttime="firsttime" upgradeplan="true" />
        </div>
    </v-dialog>
    <v-dialog v-if="canCelPlan" v-model="canCelPlan" max-width="400" content-class="items_middle" fullscreen persistent>
        <div class="dialog_body pad0">
            <v-btn color="primary" text @click="canCelPlan = false" class="close-btn close-btn2">
                <v-icon>mdi-close</v-icon>
            </v-btn>
            <cancel-plantemp @completeCancelcard="completeCancelcard" @closeCancelcard="canCelPlan = false" />
        </div>
    </v-dialog>
    <success-popup :showoverlay="cancelshow" title="Plan Cancelled" description="Subscription of your plan is cancelled successfully." />
</div>
</template>

<script>
import stripePayment from "@/views/stripe.vue";
import successPopup from "@/views/success.vue";
import selectedAtheletes from "@/views/selectedathletes.vue";
import plansList from "@/views/plans.vue";
import menuItems from "@/views/components/menuItems.vue";
import cancelPlantemp from "@/views/cancelPlan.vue";

export default {
    components: {
        menuItems,
        stripePayment,
        successPopup,
        selectedAtheletes,
        plansList,
        cancelPlantemp
    },

    data() {
        return {
            isEditable: false,
            cancelshow: false,
            canCelPlan: false,
            firsttime: false,
            upgradePlanpack: false,
            logintoApp: false,
            forgotpassword: false,
            signuptoApp: false,
            planselected: false,
            selectedplan: 1,
            freq: false,
            inseason: false,
            offseason: false,
            planslist: null,
            finalplan: null,
            loggedinview: false,
            showcardinfo: false,
            userplan: null,
            cuser: null,
            cancelled: false,
            selectedPlan: null,
            cardDetails: null,
            stripeKey: null,
            usersubscription:null
        };
    },

    methods: {
        reloadRoute() {
            window.location.reload()
        },
        checkEditable() {
            if (this.selectedPlan && this.selectedPlan.invoiceDetails && this.selectedPlan.invoiceDetails.statusId == 2) {

                let atcount = this.usersubscription.athletes.length;
                var qty = this.selectedPlan.criteria[0].qty;
                if (atcount < qty) {
                    this.isEditable = true;
                } 
                      this.isEditable = true;
            }
        },
        completeCancelcard() {
            var self = this;
            this.canCelPlan = false;
            this.cancelshow = true;
            setTimeout(function () {

                self.$router.go("/plan");

            }, 2000)
        },
        changetheplan(data) {
            this.upgradePlanpack = false;
            this.userplan = data;
            this.offseason = false;
            this.inseason = false;
            if (data.uniqueId.includes("OFFIN")) {
                this.offseason = true;
                this.inseason = true;
            }
            if (data.uniqueId.includes("IN")) {
                this.inseason = true;
            }
            if (data.uniqueId.includes("OFF")) {
                this.offseason = true;
            }
        },
        initUser() {
            this.logintoApp = false
            this.forgotpassword = false;
            this.signuptoApp = false;
        },
        showFP() {
            this.forgotpassword = true;
        }
    },
    mounted() {

        this.stripeKey = process.env.VUE_APP_STRIPE_KEY;
        this.cuser = this.$store.state.user;
        var user = this.$store.getters.getuser;
        let currentPlan= this.$store.getters['subscription/getSubscriptions'];
        this.usersubscription = this.$store.state.subscription;
      
                         if (currentPlan && currentPlan.length > 0 && currentPlan[0].cancelled) {
                            this.cancelled = true;
                        }
                        if (currentPlan && currentPlan.length > 0) {
                            this.selectedPlan = currentPlan[0];

                            if (this.selectedPlan.planDetails.uniqueId.includes("OFFIN")) {
                                this.offseason = true;
                                this.inseason = true;
                            }
                            if (this.selectedPlan.planDetails.uniqueId.includes("IN")) {
                                this.inseason = true;
                            }
                            if (this.selectedPlan.planDetails.uniqueId.includes("OFF")) {
                                this.offseason = true;
                            }

                           
                            this.checkEditable();
                        }
        var payLoad = {subscriber: {name: user.name,email: user.email,phone: user.phoneNo,phoneCode: "+1"},page: 1,perpage: 100,appActivity: true};
         this.$store.dispatch("subscription/cardDetails", payLoad).then((cardResponse) => {
                 if (cardResponse && cardResponse.list && cardResponse.list.length > 0) {
                            this.cardDetails = cardResponse.list;
                  }


         })


    }
}
</script>

<style scoped>
.v-dialog.plan-upgrade.v-dialog--fullscreen .dialog_body {
    max-width: 1000px;
}
</style>
