<template>
  <div class="athletes-list">
    <div class="top-bar">
      <div class="top-bar-left">
        <h3>ATHLETE INDEX OLD</h3>
      </div>
      <div class="top-bar-right">
        <ul>
          <li>
            <v-select :items="items" label="ALL TEAMS" solo></v-select>
          </li>
          <li>
            <input type="text" class="search" placeholder="Player Search">
          </li>
        </ul>
      </div>
    </div>
    <div class="athletes-alphabets">
      <ul>
        <li class="active"><a href="">All</a></li>
        <li><a href="">A</a></li>
        <li><a href="">b</a></li>
        <li><a href="">c</a></li>
        <li><a href="">d</a></li>
        <li><a href="">e</a></li>
        <li><a href="">f</a></li>
        <li><a href="">g</a></li>
        <li><a href="">h</a></li>
        <li><a href="">i</a></li>
        <li><a href="">j</a></li>
        <li><a href="">k</a></li>
        <li><a href="">l</a></li>
        <li><a href="">m</a></li>
        <li><a href="">n</a></li>
        <li><a href="">o</a></li>
        <li><a href="">p</a></li>
        <li><a href="">q</a></li>
        <li><a href="">r</a></li>
        <li><a href="">s</a></li>
        <li><a href="">t</a></li>
        <li><a href="">u</a></li>
        <li><a href="">v</a></li>
        <li><a href="">w</a></li>
        <li><a href="">x</a></li>
        <li><a href="">y</a></li>
        <li><a href="">z</a></li>
      </ul>
    </div>
    <div class="athletes-details-list">
      <v-simple-table dark>
        <template v-slot:default>
          <thead>
            <tr>
              <th class="text-left">PLAYERS</th>
              <th class="text-left">TEAM CONTRACT</th>
              <th class="text-left">PLAYER DNA</th>
              <th class="text-left">CAREER</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <div class="player-info">
                  <div class="media up">
                    <figure>
                      <img src="../assets/images/avatar1.png" class="align-self-center" alt="...">                      
                    </figure>
                    <div class="badge-logo"><img src="../assets/images/icon-logo1.png"></div>
                  </div>
                  <div class="players-info-list">
                    <h2>
                      <a href="#/athlete/playerdna"> Amir Coffey </a><span>PG</span>
                    </h2>
                    <ul>
                      <li>
                        <p>AGE</p>
                        <span>26yrs</span>
                      </li>
                      <li>
                        <p>HT</p>
                        <span>6'6"</span>
                      </li>
                      <li>
                        <p>WT</p>
                        <span>195 lbs</span>
                      </li>
                      <li>
                        <p>EXP</p>
                        <span>2yr</span>
                      </li>
                      <li>
                        <p>EXP</p>
                        <span>2yr</span>
                      </li>
                      <li>
                        <p>WINGSPAN</p>
                        <span>7’ 2.25’’</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </td>
              <td>
                <div class="team-contract">
                  <ul>
                    <li class="team_red">
                      <v-chip>
                        <v-avatar>TC</v-avatar>
                        $123,073,318
                      </v-chip>
                    </li>
                    <li class="team_green">
                      <v-chip>
                        <v-avatar>RC</v-avatar>
                        $112,346,544
                      </v-chip>
                    </li>
                  </ul>
                </div>
              </td>
              <td>
                <div class="player-dna">
                  <ul>
                    <li class="team_red">
                      <v-chip>
                        <v-avatar>TC</v-avatar>
                        $123,073,318
                      </v-chip>
                    </li>
                    <li class="team_green">
                      <v-chip>
                        <v-avatar>RC</v-avatar>
                        $112,346,544
                      </v-chip>
                    </li>
                  </ul>
                </div>
              </td>
              <td>Career Info</td>
            </tr>
            <tr>
              <td>
                <div class="player-info">
                  <div class="media down">
                    <figure>
                      <img src="../assets/images/avatar1.png" class="align-self-center" alt="...">                      
                    </figure>
                    <div class="badge-logo"><img src="../assets/images/icon-logo1.png"></div>
                  </div>
                  <div class="players-info-list">
                    <h2>
                      Amir Coffey <span>PG</span>
                    </h2>
                    <ul>
                      <li>
                        <p>AGE</p>
                        <span>26yrs</span>
                      </li>
                      <li>
                        <p>HT</p>
                        <span>6'6"</span>
                      </li>
                      <li>
                        <p>WT</p>
                        <span>195 lbs</span>
                      </li>
                      <li>
                        <p>EXP</p>
                        <span>2yr</span>
                      </li>
                      <li>
                        <p>EXP</p>
                        <span>2yr</span>
                      </li>
                      <li>
                        <p>WINGSPAN</p>
                        <span>7’ 2.25’’</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </td>
              <td>
                <div class="d-inline-block">
                  <div class="text-center">
                    <v-menu v-model="menu" open-on-hover :close-on-content-click="false" :nudge-width="200" offset-x>
                      <template v-slot:activator="{ on }">
                        <div class="team-contract" v-on="on">
                          <div class="team-contract">
                            <ul>
                            <li class="team_red">
                              <v-chip>
                                <v-avatar>TC</v-avatar>
                                $123,073,318
                              </v-chip>
                            </li>
                            <li class="team_green">
                              <v-chip>
                                <v-avatar>RC</v-avatar>
                                $112,346,544
                              </v-chip>
                            </li>
                          </ul>
                          </div>
                        </div>
                      </template>
                      <v-card class="chart-card">
                        <div class="team-contract-scores">
                          <div class="teamcontact-scores-left">
                            <h2>OFFENSIVE SCORE</h2>
                            <p>
                              65% 
                              <v-icon>mdi-menu-up</v-icon>
                            </p>
                          </div>
                          <div class="teamcontact-scores-right">
                            <h2>DIFFENSIVE SCORE</h2>
                            <p>
                              45% 
                              <v-icon>mdi-menu-down</v-icon>
                            </p>
                          </div>
                        </div>
                        <div id="chart">
                          <apexchart type="area" height="150" :options="chartOptions2" :series="series"></apexchart>
                        </div> 
                      </v-card> 
                    </v-menu>
                </div>
                </div>
              </td>
              <td>
                <div>
                  <div class="text-center">
                    <v-menu v-model="menu" open-on-hover :close-on-content-click="false" :nudge-width="200" offset-y>
                      <template v-slot:activator="{ on }">                        
                        <div class="player-dna" v-on="on">
                          <ul>
                            <li class="team_red">
                              <v-chip>
                                <v-avatar>
                                  TC
                                </v-avatar>
                                $123,073,318
                              </v-chip>
                            </li>
                            <li class="team_green">
                              <v-chip>
                                <v-avatar>
                                  RC
                                </v-avatar>
                                $112,346,544
                              </v-chip>
                            </li>
                          </ul>
                        </div>
                      </template>
                      <v-card class="chart-card player-dna-charts-panel">
                        <div class="team-contract-scores">
                          <div class="teamcontact-scores-left">
                            <h2>CURRENT PLAYER DNA</h2>
                          </div> 
                        </div>
                        <div id="chart2" class="player-dna-charts">
                          <apexchart type="donut" height="150" :options="chartOptions3" :series="series"></apexchart>
                        </div>
                      </v-card>
                      <v-card class="chart-card player-dna-charts-panel">
                        <div class="team-contract-scores">
                          <div class="teamcontact-scores-left">
                            <h2>PROJECTED PLAYER DNA</h2>
                            
                          </div> 
                        </div>
                        <div id="chart3" class="player-dna-charts">
                          <apexchart type="donut" height="150" :options="chartOptions4" :series="series"></apexchart>
                        </div>
                      </v-card>
                    </v-menu>
                </div>
                </div>



                
              </td>
              <td>
                Career
              </td>
            </tr>
            <tr>
              <td>
                <div class="player-info">
                  <div class="media up">
                    <figure>
                      <img src="../assets/images/avatar1.png" class="align-self-center" alt="...">                      
                    </figure>
                    <div class="badge-logo"><img src="../assets/images/icon-logo1.png"></div>
                  </div>
                  <div class="players-info-list">
                    <h2>
                      <a href="#/athlete/playerdna"> Amir Coffey </a><span>PG</span>
                    </h2>
                    <ul>
                      <li>
                        <p>AGE</p>
                        <span>26yrs</span>
                      </li>
                      <li>
                        <p>HT</p>
                        <span>6'6"</span>
                      </li>
                      <li>
                        <p>WT</p>
                        <span>195 lbs</span>
                      </li>
                      <li>
                        <p>EXP</p>
                        <span>2yr</span>
                      </li>
                      <li>
                        <p>EXP</p>
                        <span>2yr</span>
                      </li>
                      <li>
                        <p>WINGSPAN</p>
                        <span>7’ 2.25’’</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </td>
              <td>
                <div class="team-contract">
                  <ul>
                    <li class="team_red">
                      <v-chip>
                        <v-avatar>TC</v-avatar>
                        $123,073,318
                      </v-chip>
                    </li>
                    <li class="team_green">
                      <v-chip>
                        <v-avatar>RC</v-avatar>
                        $112,346,544
                      </v-chip>
                    </li>
                  </ul>
                </div>
              </td>
              <td>
                <div class="player-dna">
                  <ul>
                    <li class="team_red">
                      <v-chip>
                        <v-avatar>TC</v-avatar>
                        $123,073,318
                      </v-chip>
                    </li>
                    <li class="team_green">
                      <v-chip>
                        <v-avatar>RC</v-avatar>
                        $112,346,544
                      </v-chip>
                    </li>
                  </ul>
                </div>
              </td>
              <td>Career Info</td>
            </tr>
            <tr>
              <td>
                <div class="player-info">
                  <div class="media up">
                    <figure>
                      <img src="../assets/images/avatar1.png" class="align-self-center" alt="...">                      
                    </figure>
                    <div class="badge-logo"><img src="../assets/images/icon-logo1.png"></div>
                  </div>
                  <div class="players-info-list">
                    <h2>
                      <a href="#/athlete/playerdna"> Amir Coffey </a><span>PG</span>
                    </h2>
                    <ul>
                      <li>
                        <p>AGE</p>
                        <span>26yrs</span>
                      </li>
                      <li>
                        <p>HT</p>
                        <span>6'6"</span>
                      </li>
                      <li>
                        <p>WT</p>
                        <span>195 lbs</span>
                      </li>
                      <li>
                        <p>EXP</p>
                        <span>2yr</span>
                      </li>
                      <li>
                        <p>EXP</p>
                        <span>2yr</span>
                      </li>
                      <li>
                        <p>WINGSPAN</p>
                        <span>7’ 2.25’’</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </td>
              <td>
                <div class="team-contract">
                  <ul>
                    <li class="team_red">
                      <v-chip>
                        <v-avatar>TC</v-avatar>
                        $123,073,318
                      </v-chip>
                    </li>
                    <li class="team_green">
                      <v-chip>
                        <v-avatar>RC</v-avatar>
                        $112,346,544
                      </v-chip>
                    </li>
                  </ul>
                </div>
              </td>
              <td>
                <div class="player-dna">
                  <ul>
                    <li class="team_red">
                      <v-chip>
                        <v-avatar>TC</v-avatar>
                        $123,073,318
                      </v-chip>
                    </li>
                    <li class="team_green">
                      <v-chip>
                        <v-avatar>RC</v-avatar>
                        $112,346,544
                      </v-chip>
                    </li>
                  </ul>
                </div>
              </td>
              <td>Career Info</td>
            </tr>
            <tr>
              <td>
                <div class="player-info">
                  <div class="media up">
                    <figure>
                      <img src="../assets/images/avatar1.png" class="align-self-center" alt="...">                      
                    </figure>
                    <div class="badge-logo"><img src="../assets/images/icon-logo1.png"></div>
                  </div>
                  <div class="players-info-list">
                    <h2>
                      <a href="#/athlete/playerdna"> Amir Coffey </a><span>PG</span>
                    </h2>
                    <ul>
                      <li>
                        <p>AGE</p>
                        <span>26yrs</span>
                      </li>
                      <li>
                        <p>HT</p>
                        <span>6'6"</span>
                      </li>
                      <li>
                        <p>WT</p>
                        <span>195 lbs</span>
                      </li>
                      <li>
                        <p>EXP</p>
                        <span>2yr</span>
                      </li>
                      <li>
                        <p>EXP</p>
                        <span>2yr</span>
                      </li>
                      <li>
                        <p>WINGSPAN</p>
                        <span>7’ 2.25’’</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </td>
              <td>
                <div class="team-contract">
                  <ul>
                    <li class="team_red">
                      <v-chip>
                        <v-avatar>TC</v-avatar>
                        $123,073,318
                      </v-chip>
                    </li>
                    <li class="team_green">
                      <v-chip>
                        <v-avatar>RC</v-avatar>
                        $112,346,544
                      </v-chip>
                    </li>
                  </ul>
                </div>
              </td>
              <td>
                <div class="player-dna">
                  <ul>
                    <li class="team_red">
                      <v-chip>
                        <v-avatar>TC</v-avatar>
                        $123,073,318
                      </v-chip>
                    </li>
                    <li class="team_green">
                      <v-chip>
                        <v-avatar>RC</v-avatar>
                        $112,346,544
                      </v-chip>
                    </li>
                  </ul>
                </div>
              </td>
              <td>Career Info</td>
            </tr>
          </tbody>
        </template>
      </v-simple-table>

      <div class="loading-page">
        <figure>
          <img src="@/assets/images/loader.gif">
        </figure>Loading
      </div>
    </div>

  </div>
</template>
<script>
  import VueApexCharts from 'vue-apexcharts';
  export default {
    components: { apexchart: VueApexCharts, },
  
    // data: () => ({
    //   items: ['Foo', 'Bar', 'Fizz', 'Buzz'],
    //   fav: true,
    //   menu: false,
    //   message: false,
    //   hints: true,
    //   chartOptions2: {
    //     chart: {
    //       type: 'area'
    //     },
    //     colors: ['#53CD3F', '#E91E63'],
    //     legend: {
    //       show: false
    //     },
    //     xaxis: {
    //       labels: {
    //         show: false,
    //       }
    //     },
    //     yaxis: {
    //       labels: {
    //         show: false,
    //       }
    //     },
    //   },
    //   series: [{
    //     name: 'series-1',
    //     data: [0, 70, 40, 65, 30, 49, 54]
    //   }]
    // }),

    data: () => ({
      items: ['Foo', 'Bar', 'Fizz', 'Buzz'],
      fav: true,
      menu: false,
      message: false,
      hints: true,
      chartOptions3: {
        chart: {
          type: 'donut'
        },
        labels: ['PTS', 'Defence', 'Playmaking'],
        colors: ['#FF8F00' , '#0071C0' ,'#CF0025'],
        legend: {
          show: true
        },
        xaxis: {
          labels: {
            show: false,
          }
        },
        yaxis: {
          labels: {
            show: false,
          }
        },
      },
      chartOptions4: {
        chart: {
          type: 'donut'
        },
        labels: ['PTS', 'Defence', 'Playmaking'],
        colors: ['#FF8F00' , '#0071C0' ,'#CF0025'],
        legend: {
          show: true
        },
        xaxis: {
          labels: {
            show: false,
          }
        },
        yaxis: {
          labels: {
            show: false,
          }
        },
      },
      
      series: [45, 45, 45], 
    }),
  }
</script>