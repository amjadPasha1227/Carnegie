
<template>
<div class="dialog_body signup signup_body">
        <v-btn
          color="primary"
          text
          @click="closedSetPassword()"
          class="close-btn close-btn2"
        >
          <v-icon>mdi-close</v-icon>
        </v-btn>

        <div
          class="
            flex
            w-full
            bg-img
            vx-row
            no-gutter
            justify-center
            login-wrapper
          "
          id="page-login"
        >
          <div class="login-support-wrap" @click="formerrors.msg=''">
            <form style="padding: 0px" @submit.prevent="retrunFalse">
              <h2>Set Password</h2>
              <div class="login-inputs">

              <div class="text-danger text-sm formerrors" v-if="formerrors && formerrors.msg!=''">
                    {{ formerrors.msg }}
                </div>
                <div class="inputbix password">
                  <v-text-field
                    name="Password"
                    type="password"
                    ref="password"
                    class="text_field"
                    placeholder="Password"
                    v-validate="'required'"
                    v-model="newUser.newPassword"
                    single-line
                    outlined
                  ></v-text-field>
                  <em class="eye"><img src="@//assets/images/view.svg" /></em>
                  <span class="error-text" v-show="errors.has('Password')">{{
                    errors.first("Password")
                  }}</span>
                </div>
                <div class="inputbix password">
                  <v-text-field
                    name="ConfirmPassword"
                    type="password"
                    class="text_field"
                    placeholder="Confirm Password"
                    data-vv-as="Confirm Password"
                    v-validate="'required|confirmed:password'"
                    v-model="newUser.confirmPassword"
                    single-line
                    outlined
                  ></v-text-field>
                  <span
                    class="error-text"
                    v-show="errors.has('ConfirmPassword')"
                    >{{ errors.first("ConfirmPassword") }}</span
                  >
                </div>

                <div class="action_btns d-block">
                  <input
                    value="Set Pasword"
                    type="submit"
                    :disabled="setPasswordhit"
                    class="primary_btn"
                    @click="setPasswordAction()"
                  />
                 

                  
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
</template>
<script>
import _ from "lodash";
export default {
    props: {
    newUser:{
        type:Object,

    }
  },
  data() {
    return {
        setPasswordhit:false,
        formmessage: {
        msg: "",
      },
      formerrors: {
                msg: ""
            },

        

    }
  },
mounted(){

    
},
methods: {
     closedSetPassword(){
               this.$emit('closedSetPassword')  
         
    },
    
    setPasswordAction(){
        this.$validator.validateAll().then(result => {
            
            if (result) {
                this.setPasswordhit =true
                this.$store.dispatch("updatePassword", this.newUser).then((res) => {
                    this.setPasswordhit = false;
                    if (res.error) {
                        Object.assign(this.formerrors, {
                            msg: res.error.message
                        });
                    } else {
                       
                        let user = _.cloneDeep(this.newUser);
                        this.$emit('setPasswordSuccess' ,user)
                    
                    }
                }).catch((error) => {
                    this.setPasswordhit = false;
                    Object.assign(this.formerrors, {
                        msg: error
                    });

                });
            }


    });

    },
}
}
</script>    
