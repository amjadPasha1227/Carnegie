<template>
  <div class="pI__details_page">
    <probobilityHeaderLive
      v-if="gamedata.Status != 'Scheduled'"
      :gamedata="gamedata"
      :gameid="gamedata.gameid"
    />
    <probobilityHeaderPre
      v-if="gamedata.Status == 'Scheduled'"
      :gamedata="gamedata"
      :gameid="gamedata.gameid"
    />
    <div class="pI_liveteams_sec">
      <div class="pI_liveteams_cnt">
        <div class="live_team_graph" v-if="gamedata.Status == 'InProgress'">
          <odds :game="gamedata" :gameId="gamedata.gameid" />
        </div>
        <div class="live_lineups">
          <h3>Real-Time Team Rosters</h3>
          <div class="live_lineups_tabs">
            <ul>
              <li @click="awaytab = 1" v-bind:class="{ active: awaytab == 1 }">
                <a>Active</a>
              </li>
              <li @click="awaytab = 2" v-bind:class="{ active: awaytab == 2 }">
                <a>Inactive</a>
              </li>
              <li
                v-if="gamedata.Status == 'InProgress'"
                @click="awaytab = 3"
                v-bind:class="{ active: awaytab == 3 }"
              >
                <a>Bench</a>
              </li>
              <li @click="awaytab = 4" v-bind:class="{ active: awaytab == 4 }">
                <a>Salary Converter</a>
              </li>
            </ul>
          </div>
          <div class="lineups_list_sec">
            <div class="lineups_list_wrap">
              <div class="lineups_list">
                <div class="lineups_team">
                  <figure>
                    <img :src="gamedata.HomeTeam.logo" />
                  </figure>
                  <figcaption>{{ gamedata.HomeTeam.Name }}</figcaption>
                </div>
                <ul v-if="awaytab == 1">
                  <li>
                    <template v-for="(player, index) in gamedata.HomeLineup">
                      <span
                        :key="index"
                        v-if="
                          (gamedata.Status == 'InProgress' &&
                            homePlayerplaying(player.Name)) ||
                          (gamedata.Status != 'InProgress' &&
                            player.InjuryStatus == null)
                        "
                        @click="
                          dialog = true;
                          getplayers(player);
                        "
                      >
                        <playerInfo
                          :backgroundcolors="homebackgroundcolors"
                          :player="player"
                          :PlayerGames="gamedata.PlayerGames"
                          :live="gamedata.Status == 'InProgress'"
                          :siteUrl="siteUrl"
                          :key="index"
                        ></playerInfo>
                      </span>
                    </template>
                  </li>
                </ul>

                <ul v-if="awaytab == 2">
                  <li>
                    <template v-for="(player, index) in gamedata.HomeLineup">
                      <span
                        :key="index"
                        v-if="
                          (gamedata.Status == 'InProgress' &&
                            player.InjuryStatus != null &&
                            player.Confirmed != true) ||
                          (gamedata.Status != 'InProgress' &&
                            player.InjuryStatus != null &&
                            player.Confirmed != true)
                        "
                        @click="
                          dialog = true;
                          getplayers(player);
                        "
                      >
                        <playerInfo
                          :backgroundcolors="homebackgroundcolors"
                          :player="player"
                          :PlayerGames="gamedata.PlayerGames"
                          :showinjury="true"
                          :siteUrl="siteUrl"
                          :key="index"
                        ></playerInfo>
                      </span>
                    </template>
                  </li>
                </ul>
                <ul v-if="awaytab == 3">
                  <li>
                    <template v-for="(player, index) in gamedata.HomeLineup">
                      <span
                        :key="index"
                        @click="
                          dialog = true;
                          getplayers(player);
                        "
                        v-if="
                          player.Confirmed == true &&
                          !homePlayerplaying(player.Name)
                        "
                      >
                        <playerInfo
                          :backgroundcolors="homebackgroundcolors"
                          :player="player"
                          :PlayerGames="gamedata.PlayerGames"
                          :siteUrl="siteUrl"
                          :key="index"
                        ></playerInfo>
                      </span>
                    </template>
                  </li>
                </ul>

                <ul v-if="awaytab == 4">
                  <li>
                    <template v-for="(player, index) in gamedata.HomeLineup">
                      <span
                        :key="index"
                        v-if="player.InjuryStatus == null && player.realtime50k && player.realtime50k.length > 0"
                        @click="
                          dialog = true;
                          getplayers(player);
                        "
                      >
                        <playerInfo
                          :backgroundcolors="homebackgroundcolors"
                          :player="player"
                          :PlayerGames="gamedata.PlayerGames"
                          :live="gamedata.Status == 'InProgress'"
                          :siteUrl="siteUrl"
                          showrtc="1"
                          :key="index"
                        ></playerInfo>
                      </span>
                    </template>
                  </li>
                </ul>
              </div>
              <div class="lineups_list">
                <div class="lineups_team">
                  <figure>
                    <img :src="gamedata.AwayTeam.logo" />
                  </figure>
                  <figcaption>{{ gamedata.AwayTeam.Name }}</figcaption>
                </div>
                <ul v-if="awaytab == 1">
                  <li>
                    <template v-for="(player, index) in gamedata.AwayLineup">
                      <span
                        :key="index"
                        v-if="
                          (gamedata.Status == 'InProgress' &&
                            awayPlayerplaying(player.Name)) ||
                          (gamedata.Status != 'InProgress' &&
                            player.InjuryStatus == null)
                        "
                        @click="
                          dialog = true;
                          getplayers(player);
                        "
                      >
                        <playerInfo
                          :backgroundcolors="awaybackgroundcolors"
                          :player="player"
                          :PlayerGames="gamedata.PlayerGames"
                          :live="gamedata.Status == 'InProgress'"
                          :siteUrl="siteUrl"
                          :key="index"
                        ></playerInfo>
                      </span>
                    </template>
                  </li>
                </ul>
                <ul v-if="awaytab == 2">
                  <li>
                    <template v-for="(player, index) in gamedata.AwayLineup">
                      <span
                        :key="index"
                        v-if="
                          (gamedata.Status == 'InProgress' &&
                            player.InjuryStatus != null &&
                            player.Confirmed != true) ||
                          (gamedata.Status != 'InProgress' &&
                            player.InjuryStatus != null &&
                            player.Confirmed != true)
                        "
                        @click="
                          dialog = true;
                          getplayers(player);
                        "
                      >
                        <playerInfo
                          :backgroundcolors="awaybackgroundcolors"
                          :player="player"
                          :PlayerGames="gamedata.PlayerGames"
                          :showinjury="true"
                          :siteUrl="siteUrl"
                          :key="index"
                        ></playerInfo>
                      </span>
                    </template>
                  </li>
                </ul>
                <ul v-if="awaytab == 3">
                  <li>
                    <template v-for="(player, index) in gamedata.AwayLineup">
                      <span
                        :key="index"
                        @click="
                          dialog = true;
                          getplayers(player);
                        "
                        v-if="
                          player.Confirmed == true &&
                          !awayPlayerplaying(player.Name)
                        "
                      >
                        <playerInfo
                          :backgroundcolors="awaybackgroundcolors"
                          :player="player"
                          :PlayerGames="gamedata.PlayerGames"
                          :siteUrl="siteUrl"
                          :key="index"
                        ></playerInfo>
                      </span>
                    </template>
                  </li>
                </ul>
                <ul v-if="awaytab == 4">
                  <li>
                    <template v-for="(player, index) in gamedata.AwayLineup">
                      <span
                        :key="index"
                         v-if="player.InjuryStatus == null && player.realtime50k && player.realtime50k.length > 0"

                        @click="
                          dialog = true;
                          getplayers(player);
                        "
                      >
                        <playerInfo
                          :backgroundcolors="homebackgroundcolors"
                          :player="player"
                          :PlayerGames="gamedata.PlayerGames"
                          :live="gamedata.Status == 'InProgress'"
                          :siteUrl="siteUrl"
                          showrtc="1"
                          :key="index"
                        ></playerInfo>
                      </span>
                    </template>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <probobilityWidgetsPre :gamedata="gamedata" :gameid="gamedata.gameid" />
    <div class="modaldialog" v-if="dialog" width="1130">
      <div class="wrapperdivbg"></div>
      <div class="wrapperdiv" id="modaldialogv">
        <v-card>
          <v-row class="mar0">
            <v-col class="pad0">
              <div
                class="widget_block marb0 role_modal player_infomodal"
                v-if="selectedplayer"
              >
                <div class="widget_title modal_header">
                  <div class="modal_title">
                    <h3>{{ selectedplayer.PLAYER_NAME }}</h3>
                    <ul class="tab_buttons">
                      <li
                        v-bind:class="{ active: atab == 'Opportunity' }"
                        @click="atab = 'Opportunity'"
                      >
                        <a>Opportunity</a>
                      </li>
                      <li
                        v-bind:class="{
                          active: atab == 'Position Versatility',
                        }"
                        @click="atab = 'Position Versatility'"
                      >
                        <a>Position Versatility</a>
                      </li>
                      <li
                        v-bind:class="{ active: atab == 'Career Outlook' }"
                        @click="atab = 'Career Outlook'"
                      >
                        <a>Career Outlook </a>
                      </li>
                     
                    </ul>
                  </div>
                  <div>
                    <v-btn color="primary" text @click="dialog = false">
                      <img src="@/assets/images/close.svg" />
                    </v-btn>
                  </div>
                </div>
                <div class="widget_body" style="padding: 0px">
                  <div v-if="atab == 'Opportunity'">
                    <opportunity
                      v-if="selectedplayer != null"
                      :player="selectedplayer"
                    />
                  </div>
                  <div v-if="atab == 'Position Versatility'">
                    <player-position-versatility
                      v-if="selectedplayer != null"
                      :player="selectedplayer"
                    />
                  </div>
                  <div v-if="atab == 'Career Outlook'">
                    <profit-impact
                      v-if="selectedplayer != null"
                      :player="selectedplayer"
                    />
                  </div>
            
                </div>
              </div>
            </v-col>
          </v-row>
        </v-card>
      </div>
    </div>
  </div>
</template>


<script>
import moment from "moment";
import opportunity from "@/views/components/opportunity.vue";
import playerPositionVersatility from "@/views/components/playerPositionVersatility.vue";

import probobilityHeaderPre from "@/views/probability-header-pre.vue";
import probobilityHeaderLive from "@/views/probability-header-live";
import playerInfo from "@/views/components/playerInfo.vue";
import probobilityWidgetsPre from "@/views/probability-widgets-pre";
import injuryRisk from "@/views/components/injuryRisk.vue";
import odds from "@/views/components/odds.vue";
import profitImpact from "@/views/components/profitImpact2.vue";

export default {
  components: {
    probobilityWidgetsPre,
    opportunity,
    playerPositionVersatility,
    probobilityHeaderPre,
    probobilityHeaderLive,
    playerInfo,
    odds,
    profitImpact
  },

  computed: {
    homebackgroundcolors() {
      if (this.gamedata) {
        return `transparent linear-gradient(to right, #${this.gamedata.HomeTeam.SecondaryColor} 0%, #${this.gamedata.HomeTeam.PrimaryColor} 70%,  #10182B 100%) 0% 0% no-repeat padding-box`;
      }
      return "";
    },
    awaybackgroundcolors() {
      if (this.gamedata) {
        return `transparent linear-gradient(to right, #${this.gamedata.AwayTeam.SecondaryColor} 0%, #${this.gamedata.AwayTeam.PrimaryColor} 70%, #10182B 100%) 0% 0% no-repeat padding-box`;
      }
      return "";
    },
    iscompleted() {
      return moment().isBefore(moment(this.gamedata.gamedatee));
    },
    livematch() {
      return (
        moment().isSameOrAfter(moment(this.gamedata.gamedate)) &&
        moment().isSameOrBefore(moment(this.gamedata.gamedatee))
      );
    },
  },
  beforeDestroy() {
    clearInterval(this.polling);
  },
  mounted() {
    if ([1, 2, 3, 5].indexOf(this.$store.state.userRole) > -1) {
      var t = 100;
    } else {
      this.$router.push("/plan");
    }

    this.siteUrl = process.env.VUE_APP_API_URL;
    this.isloading = true;

    this.reloadData();
    this.pollData();
  },
  methods: {
    homePlayerplaying(n) {
      return this.gamedata.LivePredictionlog.ahometeamlist.indexOf(n) > -1;
    },
    awayPlayerplaying(n) {
      return this.gamedata.LivePredictionlog.aawayteamlist.indexOf(n) > -1;
    },
    pollData() {
      this.polling = setInterval(() => {
        this.reloadData();
      }, 36000);
    },
    reloadData() {
      this.$store
        .dispatch("getprobabilitydetailsv2", {
          gameId: this.$route.params.id,
        })
        .then((response) => {
          this.gamedata = [];
          response.forEach((element) => {
            var _e = element;

            this.gamedata = _e;
          });

          if (this.gamedata && this.gamedata.Status != "InProgress") {
            clearInterval(this.polling);
          }

          this.isloading = false;
        });
    },
    getplayers(s) {
      // alert(window.scrollY)
      if (s.PLAYER_ID) {
        this.atab = "Opportunity";
        this.isloading = true;
        this.serach = {
          page: 1,
          perpage: 1,
          matcher: {
            playerId: s.PLAYER_ID,
          },
        };

        this.$store
          .dispatch("getplayerdetails", this.serach)
          .then((response) => {
            if (response.error) {
              Object.assign(this.formerrors, {
                msg: response.error.message,
              });
            } else {
              this.totalCount = response.data.result.totalCount;
              let nitem = response.data.result.list[0];

              var totalgames = 0;

              nitem["seasons"].forEach(function (tem) {
                totalgames = totalgames + tem.GP;
              });
              nitem.totalgames = totalgames;
              nitem._matches = this.lodash.orderBy(nitem.matches, (o) =>
                moment(o.gamedate)
              );

              this.selectedplayer = nitem;
            }
            var self = this;
            setTimeout(function () {
              self.isloading = false;
            }, 1000);
          });
      }
    },
  },
  data() {
    return {
      awaytab: 1,
      htab: 1,
      angle: "246",
      options: {
        height: "100%",
        size: 0,
      },
      polling: null,
      atab: "Opportunity",
      isloading: false,
      selectedplayer: null,
      dialog: false,
      siteUrl: null,
      gamedata: null,
      tabs: null,
      //   options: {
      //         height: '100%',
      //         size: 5,
      //         wheelStep : 5,
      //     }
    };
  },
};
</script>