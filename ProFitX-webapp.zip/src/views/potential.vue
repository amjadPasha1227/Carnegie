<template>


  <div class="content-body">

<sidebar v-if="player!=null" :player=player />

        <div class="content-wrapper">



  <div class="athlete_content_wrap">
    <v-row>
      <v-col > <player-details v-if="player!=null" :player=player /></v-col>
    </v-row>
    <div class="nodataBox" v-if="player && player.RTC == null">

                No Data Available
            </div>
            <div class="athlete_body_content" v-if="player && player.RTC">
     <v-row v-if="checkWidgetsPermessions('PROXTIAL')">
      <v-col><player-proxtial v-if="player!=null" :player=player /></v-col>
    </v-row>

     <v-row v-if="checkWidgetsPermessions('INJURY_RISK') || checkWidgetsPermessions('INJURY_MANAGEMENT')">
  
        <v-col v-if="checkWidgetsPermessions('INJURY_RISK')"  class="injury_sec" ><injury-risk  v-if="player!=null" :player=player  /></v-col> 
        <v-col  v-if="checkWidgetsPermessions('INJURY_MANAGEMENT')"   class="load_management"><load-management   v-if="player!=null"  :player=player /></v-col> 
      </v-row>

 <v-row v-if="checkWidgetsPermessions('POSITION_VERSATILITY')">
                    <v-col cols="12">
                        <player-position-versatility v-if="player.PLAYER_NAME!=null && checkWidgetsPermessions('POSITION_VERSATILITY')" :player=player />
                    </v-col>
                </v-row>

                
 <v-row v-if="checkWidgetsPermessions('CAREER_OUTLOOK')">
        <v-col><profit-impact  v-if="player!=null" :player=player   /></v-col>
      </v-row>
  
    </div>
  </div>
         
    </div>
  </div>
</template>

<script>
import playerDetails from "@/views/components/playerDetails.vue";
import playerProxtial from "@/views/components/playerProxtial.vue";

import Sidebar from "@/layouts/components/Sidebar.vue";
import injuryRisk from '@/views/components/injuryRisk.vue';
import loadManagement from '@/views/components/loadManagement.vue';
import playerPositionVersatility from "@/views/components/playerPositionVersatility.vue";
import profitImpact from "@/views/components/profitImpact.vue";
import moment from "moment";

export default {
     components:{
       profitImpact,
       playerPositionVersatility,
       injuryRisk,
       loadManagement,
    playerDetails,
    playerProxtial,
    Sidebar,
     },
      methods: { 


 getplayers() {
            this.isloading = true
            this.serach = {
                "page": 1,
                "perpage": 1,
                "matcher": {
                    "playerId": this.$route.params.id
                }
            };

            this.$store
                .dispatch("getplayerdetails", this.serach)
                .then(response => {
                    if (response.error) {
                        Object.assign(this.formerrors, {
                            msg: response.error.message
                        });
                    } else {
                        this.totalCount = response.data.result.totalCount;
                            let nitem = response.data.result.list[0];
                              var totalgames = 0
                            
                            nitem['seasons'].forEach(function(tem){

                                totalgames =totalgames+tem.GP;
                            })
                            nitem.totalgames = totalgames;
                       nitem._matches =  this.lodash.orderBy(nitem.matches, o => moment(o.gamedate));
                            this.player = nitem;



                    }
                    var self = this;
                    setTimeout(function () {

                        self.isloading = false;
                    }, 1000)

                });

        }


  },
  mounted () {
   this.getplayers()
},  data() {
    return {
      player:null

    };
  }
}
</script>

