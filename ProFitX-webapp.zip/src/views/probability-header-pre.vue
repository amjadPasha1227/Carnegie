
<template>
  <div class="pI__details_banner prematch pre--" v-if="gamedata">
    <div class="pI_teams_bg">
      <div class="team_one">
 
        <div  class="team_background"
          :style="{
            
            
            opacity: 0.6,
            width: '100%',
            height: '100%',
            background: homebackgroundcolors,
          }"
        >
          
        </div>       
        <img class="logo_watermark"             
            :src="gamedata.HomeTeam.logo"
          />
      </div>
      <div class="team_two">
        
        <div class="team_background"
          :style="{
            opacity: 0.6,
            width: '100%',
            height: '100%',
            background: awaybackgroundcolors,
          }"
        >
        
        </div>  <img class="logo_watermark"
            
            :src="gamedata.AwayTeam.logo"
          />
      </div>
    </div>
    <div class="pI_match_info">
      <!-- <span class="match_status" v-if="gamedata.Status=='InProgress' ">LIVE</span> -->
      <div class="live-alert" v-if="gamedata.Status=='InProgress' ">
        <div class="waveWrapper left">
          <div class="waveWrapperInner delay1">
            <div class="wave"></div>
          </div>
          <div class="waveWrapperInner delay2">
            <div class="wave"></div>
          </div>
          <div class="waveWrapperInner delay3">
            <div class="wave"></div>
          </div>
        </div>
        <div class="wave-text">
          <div class="text-wrapper">
            <h2>Live</h2>
          </div>
        </div>
        <div class="waveWrapper right">
            <div class="waveWrapperInner delay1">
              <div class="wave"></div>
            </div>
            <div class="waveWrapperInner delay2">
              <div class="wave"></div>
            </div>
            <div class="waveWrapperInner delay3">
              <div class="wave"></div>
            </div>
        </div>
      </div>
       <div class="PI_match_teams">
        <figcaption>{{gamedata.HomeTeam.Name}}</figcaption>
        <figure><img  :src="gamedata.HomeTeam.logo" /></figure>
         <span
          v-if="gamedata.LiveProb"
          >{{ gamedata.LiveProb.home_score }}</span
        >
         <label v-if="gamedata.Status == 'InProgress'"
          ><small>SCORES</small><b>{{ gamedata.elapsed }}</b></label
        >
        <label v-else-if="gamedata.Status == 'Scheduled'"
          ><small>Starts In</small><b>{{ startsIn }} hrs</b></label
        >
        <label v-else-if="gamedata.Status != 'InProgress' && gamedata.Status != 'Scheduled'"
          ><small>Status</small><b>{{gamedata.Status}}</b></label
        >
     <span
          v-if="gamedata.LiveProb"
          >{{ gamedata.LiveProb.away_score }}</span
        >
        <figure><img  :src="gamedata.AwayTeam.logo" /></figure>
        <figcaption>{{gamedata.AwayTeam.Name}}</figcaption>
      </div>
      <div class="PI_team_scores">
        <div class="team1_score">
          <div class="score_value" v-bind:class="{
              high: gamedata.home_win_pct * 100 > 60,
              low: gamedata.home_win_pct * 100 < 30,
              medium:
                gamedata.home_win_pct * 100 > 30 &&
                gamedata.home_win_pct * 100 < 60,
            }">
            <label>{{ gamedata.home_win_pct | percentagecustom(1)
              }}<sub>%</sub></label>
            <span>H</span>
          </div>
          <div class="score_progress" v-bind:class="{
              high: gamedata.home_win_pct * 100 > 60,
              low: gamedata.home_win_pct * 100 < 30,
              medium:
                gamedata.home_win_pct * 100 > 30 &&
                gamedata.home_win_pct * 100 < 60,
            }"></div>
        </div>
        <div class="team2_score">
          <div class="score_progress" v-bind:class="{
              high: gamedata.away_win_pct * 100 > 60,
              low: gamedata.away_win_pct * 100 < 30,
              medium:
                gamedata.away_win_pct * 100 > 30 &&
                gamedata.away_win_pct * 100 < 60,
            }"></div>
          <div class="score_value"  v-bind:class="{
              high: gamedata.away_win_pct * 100 > 60,
              low: gamedata.away_win_pct * 100 < 30,
              medium:
                gamedata.away_win_pct * 100 > 30 &&
                gamedata.away_win_pct * 100 < 60,
            }">
            <span>H</span>
            <label>{{ gamedata.away_win_pct | percentagecustom(1)
              }}<sub>%</sub></label>
          </div>
        </div>
        <strong class="trophy"><img src="@/assets/images/trophy.png" /></strong>
      </div>
    </div>
  </div>
</template>

<script>
import moment from "moment";

export default {
  data() {
    return {
      angle: "246",
      color1: "red",
      color2: "blue",
    };
  },
  computed: {
      
   startsIn() {
      if (moment.utc(this.gamedata.gamedate).isAfter(moment().utc())) {

        return moment.utc(this.gamedata.gamedate).diff(
          moment().utc(),
          "hours"
        );
      }
      return moment()
        .utc()
        .diff(moment(this.gamedata.gamedate), "hours");
    },
    homebackgroundcolors() {
      if (this.gamedata) {
        return `transparent linear-gradient(${this.angle}deg, #${this.gamedata.HomeTeam.PrimaryColor} 0%, #${this.gamedata.HomeTeam.SecondaryColor} 100%) 0% 0% no-repeat padding-box`;
      }
      return "";
    },
    awaybackgroundcolors() {
      if (this.gamedata) {
        return `transparent linear-gradient(${this.angle}deg, #${this.gamedata.AwayTeam.PrimaryColor} 0%, #${this.gamedata.AwayTeam.SecondaryColor} 100%) 0% 0% no-repeat padding-box`;
      }
      return "";
    },
  },
  props: {
    gamedata: null,
    gameId: null,
  },
};
</script>

