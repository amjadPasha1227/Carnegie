<template>
<div class='credit-card-inputs payment-simple vv' :class='{ complete }' @click="snackbar =false">

    <label v-if="cardDetails && cardDetails.length > 0 && cardDetails[0].source" class="sm_label">Card Information</label>
    <div class="card_info" v-if="cardDetails && cardDetails.length > 0 && cardDetails[0].source">
        <div class="card_info_cnt">
            <figure><em>
                    <img v-if="cardDetails[0].source && cardDetails[0].source.card.brand == 'MasterCard'" src="@/assets/images/mastercard.png" />
                    <img v-else-if="cardDetails[0].source && cardDetails[0].source.card.brand == 'American Express'" src="@/assets/images/americalexpress.png" />
                    <img v-else-if="cardDetails[0].source && cardDetails[0].source.card.brand == 'Discover'" src="@/assets/images/discover.png" />
                    <img v-else-if="cardDetails[0].source && cardDetails[0].source.card.brand == 'JCB'" src="@/assets/images/jcb.png" />
                    <img v-else-if="cardDetails[0].source && cardDetails[0].source.card.brand == 'Visa'" src="@/assets/images/visa.png" />
                    <template v-else> {{cardDetails[0].source.card.brand}}</template>

                </em></figure>
            <div class="card_details">
                <div class="card_details_cnt">
                    <p>XXXX - XXXX - XXXX - {{cardDetails[0].source.card.last4}}</p>
                    <button v-if="!updatecardpop" @click="updatecardpop=true" class="primary_btn">Update</button>
                </div>

            </div>
        </div>
        <stripe-payment v-if="updatecardpop" @cancelop="cancelop" :updatecard="updatecardpop" :userplan="userplan" stripe="pk_test_51IxaUrJgjpVfL01stIruJm5wLlUF27lzcnbuvnEAV5ah93XktLmNeBkAprU8ZTLggKqecysdoMYoLrm6LyePD03s00iDPkGfib" />
    </div>
    <v-overlay v-if="showoverlay">
        <v-progress-circular indeterminate size="64"></v-progress-circular>
    </v-overlay>
    <snakebar v-if="snackbar" :snackbar="snackbar" :msg="text" :isError="isError" />

    <toaster-popup :toaster="toasteshow" :description="toastecontent" />

</div>
</template>

<script>
import toasterPopup from "@/views/toster.vue";
import snakebar from "@/views/components/snakebar.vue";
import stripePayment from "@/views/stripe.vue";

export default {
    data() {
        return {
            updatecardpop: false,
            complete: false,
            number: false,
            expiry: false,
            cvc: false,
            showoverlay: false,
            toasteshow: false,
            toastecontent: null,
            text: null,
            snackbar: false,
            isError: false,
            cardDetails: null
        }
    },
    components: {
        toasterPopup,
        snakebar,
        stripePayment
    },
    mounted() {
        this.getCardDetails();
    },
    methods: {
        cancelop() {
            this.updatecardpop = false;
        },
        getCardDetails() {
            //cardDetails

            var user = this.$store.state.user;

            var payLoad = {
                subscriber: {
                    name: user.name,
                    email: user.email,
                    phone: user.phoneNo,
                    phoneCode: "+1"
                },
                page: 1,
                perpage: 100,
                appActivity: true
            };
            this.$store.dispatch("subscription/cardDetails", payLoad).then((cardResponse) => {
                this.cardDetails = cardResponse.list;
             
            })
        }
    }
}
</script> 

<style>

</style>
