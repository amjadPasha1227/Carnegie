<template>
  <div class="player_performance_cnt">
    <div class="performance_block">
      <div class="team_title">
        <figure>
          <img :src="gamedata.HomeTeam.logo" />
        </figure>
        <figcaption>
          {{ gamedata.HomeTeam.Name }} Performance Attributes
        </figcaption>
      </div>

      <div class="perfomance_players">
        <div class="player_tabs">
          <ul>
            <li
              @click="
                currentHometab = 1;
                synergyHome(currentHometab, 'Defensive IQ', 1);
              "
              v-bind:class="{ active: currentHometab == 1 }"
            >
              <a>Defensive IQ</a>
            </li>
            <li
              @click="
                currentHometab = 2;
                synergyHome(currentHometab, 'Interior Defense', 1);
              "
              v-bind:class="{ active: currentHometab == 2 }"
            >
              <a>Interior Defense</a>
            </li>
            <li
              @click="
                currentHometab = 3;
                synergyHome(currentHometab, 'Perimeter Defense', 1);
              "
              v-bind:class="{ active: currentHometab == 3 }"
            >
              <a>Perimeter Defense</a>
            </li>
            <li
              @click="
                currentHometab = 4;
                synergyHome(currentHometab, 'Defensive Impact', 1);
              "
              v-bind:class="{ active: currentHometab == 4 }"
            >
              <a>Defensive Impact</a>
            </li>
          </ul>
        </div>
        <div class="players_list">
          <template v-for="(player, index) in hometablist">
            <div class="player" :key="index">
              <div class="player_cnt">
                <figure>
                  <img
                    :src="
                      siteUrl +
                      '/api/viewfile?path=playerimages/sportsdataio/' +
                      player.PlayerID +
                      '.png'
                    "
                  />
                </figure>
                <strong>
                  {{ player.FirstName }} {{ player.LastName
                  }} <span>{{ player.Position }}</span>
                  
                          <div class="player_actions">
                  <div class="gradient_btn"><p>{{ player.sortdata }}<sub></sub></p></div>
   </div>

                  
                  </strong
                >
              </div>
            </div>
          </template>
        </div>
      </div>

      <div class="perfomance_players">
        <div class="player_tabs">
          <ul>
            <li
              @click="
                currentHometab1 = 1;
                synergyHome(currentHometab1, 'Offensive Impact', 2);
              "
              v-bind:class="{ active: currentHometab1 == 1 }"
            >
              <a>Offensive Impact</a>
            </li>
            <li
              @click="
                currentHometab1 = 2;
                synergyHome(currentHometab, 'Interior Scoring', 2);
              "
              v-bind:class="{ active: currentHometab1 == 2 }"
            >
              <a>Interior Scoring</a>
            </li>
            <li
              @click="
                currentHometab1 = 3;
                synergyHome(currentHometab, 'Attacking the Basket', 2);
              "
              v-bind:class="{ active: currentHometab1 == 3 }"
            >
              <a>Attacking the Basket</a>
            </li>
            <li
              @click="
                currentHometab1 = 4;
                synergyHome(currentHometab, 'Perimeter Scoring', 2);
              "
              v-bind:class="{ active: currentHometab1 == 4 }"
            >
              <a>Perimeter Scoring</a>
            </li>
          </ul>
        </div>
        <div class="players_list">
          <template v-for="(player, index) in hometablist2">
            <div class="player" :key="index">
              <div class="player_cnt">
                <figure>
                  <img
                    :src="
                      siteUrl +
                      '/api/viewfile?path=playerimages/sportsdataio/' +
                      player.PlayerID +
                      '.png'
                    "
                  />
                </figure>
                <strong>
                  {{ player.FirstName }} {{ player.LastName
                  }}<span>{{ player.Position }}</span>
                  
                          <div class="player_actions">
                  <div class="gradient_btn"><p>{{ player.sortdata }}<sub></sub></p></div>
   </div>

                  
                  </strong
                >
              </div>
            </div>
          </template>
        </div>
      </div>

      <div class="perfomance_players">
        <div class="player_tabs">
          <ul>
            <li
              @click="
                currentHometab2 = 1;
                synergyHome(currentHometab2, 'Ball Handing', 3);
              "
              v-bind:class="{ active: currentHometab2 == 1 }"
            >
              <a>Ball Handing</a>
            </li>
            <li
              @click="
                currentHometab2 = 2;
                synergyHome(currentHometab2, 'Perimeter Assists', 3);
              "
              v-bind:class="{ active: currentHometab2 == 2 }"
            >
              <a>Perimeter Assists</a>
            </li>
            <li
              @click="
                currentHometab2 = 3;
                synergyHome(currentHometab2, 'Interior Assists', 3);
              "
              v-bind:class="{ active: currentHometab2 == 3 }"
            >
              <a>Interior Assists</a>
            </li>
            <li
              @click="
                currentHometab2 = 4;
                synergyHome(currentHometab2, 'Draw Fouls', 3);
              "
              v-bind:class="{ active: currentHometab2 == 4 }"
            >
              <a>Free Throws</a>
            </li>
          </ul>
        </div>
        <div class="players_list">
          <template v-for="(player, index) in hometablist3">
            <div class="player" :key="index">
              <div class="player_cnt">
                <figure>
                  <img
                    :src="
                      siteUrl +
                      '/api/viewfile?path=playerimages/sportsdataio/' +
                      player.PlayerID +
                      '.png'
                    "
                  />
                </figure>
                <strong>
                  {{ player.FirstName }} {{ player.LastName
                  }}<span>{{ player.Position }}</span>

                  <div class="player_actions">
                  <div class="gradient_btn"><p>{{ player.sortdata }}<sub></sub></p></div>
   </div>

                  
                  </strong
                >
              </div>
            </div>
          </template>
        </div>
      </div>
    </div>
    <div class="performance_block">
      <div class="team_title">
        <figure>
          <img :src="gamedata.AwayTeam.logo" />
        </figure>
        <figcaption>
          {{ gamedata.AwayTeam.Name }} Performance Attributes
        </figcaption>
      </div>
      <div class="perfomance_players">
        <div class="player_tabs">
          <ul style="font-size: 14px">
            <li
              @click="
                currentAwayTab = 1;
                synergyaway(currentAwayTab, 'Defensive IQ',1);
              "
              v-bind:class="{ active: currentAwayTab == 1 }"
            >
              <a>Defensive IQ</a>
            </li>
            <li
              @click="
                currentAwayTab = 2;
                synergyaway(currentAwayTab, 'Interior Defense',1);
              "
              v-bind:class="{ active: currentAwayTab == 2 }"
            >
              <a>Interior Defense</a>
            </li>
            <li
              @click="
                currentAwayTab = 3;
                synergyaway(currentAwayTab, 'Perimeter Defense',1);
              "
              v-bind:class="{ active: currentAwayTab == 3 }"
            >
              <a>Perimeter Defense</a>
            </li>
            <li
              @click="
                currentAwayTab = 4;
                synergyaway(currentAwayTab, 'Defensive Impact',1);
              "
              v-bind:class="{ active: currentAwayTab == 4 }"
            >
              <a>Defensive Impact</a>
            </li>
          </ul>
        </div>
        <div class="players_list">
          <template v-for="(player, index) in awaytablist">
            <div class="player" :key="index">
              <div class="player_cnt">
                <figure>
                  <img
                    :src="
                      siteUrl +
                      '/api/viewfile?path=playerimages/sportsdataio/' +
                      player.PlayerID +
                      '.png'
                    "
                  />
                </figure>
                <strong>
                  {{ player.FirstName }} {{ player.LastName
                  }}<span>{{ player.Position }}</span>
                  
                          <div class="player_actions">
                  <div class="gradient_btn"><p>{{ player.sortdata }}<sub></sub></p></div>
   </div>

                  </strong
                >
              </div>
            </div>
          </template>
        </div>
      </div>

      <div class="perfomance_players">
        <div class="player_tabs">
          <ul>
            <li
              @click="
                currentAwayTab1 = 1;
                synergyaway(currentAwayTab1, 'Offensive Impact', 2);
              "
              v-bind:class="{ active: currentAwayTab1 == 1 }"
            >
              <a>Offensive Impact</a>
            </li>
            <li
              @click="
                currentAwayTab1 = 2;
                synergyaway(currentAwayTab1, 'Interior Scoring', 2);
              "
              v-bind:class="{ active: currentAwayTab1 == 2 }"
            >
              <a>Interior Scoring</a>
            </li>
            <li
              @click="
                currentAwayTab1 = 3;
                synergyaway(currentAwayTab1, 'Attacking the Basket', 2);
              "
              v-bind:class="{ active: currentAwayTab1 == 3 }"
            >
              <a>Attacking the Basket</a>
            </li>
            <li
              @click="
                currentAwayTab1 = 4;
                synergyaway(currentAwayTab1, 'Perimeter Scoring', 2);
              "
              v-bind:class="{ active: currentAwayTab1 == 4 }"
            >
              <a>Perimeter Scoring</a>
            </li>
          </ul>
        </div>
        <div class="players_list">
          <template v-for="(player, index) in awaytablist2">
            <div class="player" :key="index">
              <div class="player_cnt">
                <figure>
                  <img
                    :src="
                      siteUrl +
                      '/api/viewfile?path=playerimages/sportsdataio/' +
                      player.PlayerID +
                      '.png'
                    "
                  />
                </figure>
                <strong>
                  {{ player.FirstName }} {{ player.LastName
                  }}<span>{{ player.Position }}</span>
                          <div class="player_actions">
                  <div class="gradient_btn"><p>{{ player.sortdata }}<sub></sub></p></div>
   </div>

                  
                  </strong
                >
              </div>
            </div>
          </template>
        </div>
      </div>

      <div class="perfomance_players">
        <div class="player_tabs">
          <ul>
            <li
              @click="
                currentAwayTab2 = 1;
                synergyaway(currentAwayTab2, 'Ball Handing', 3);
              "
              v-bind:class="{ active: currentAwayTab2 == 1 }"
            >
              <a>Ball Handing</a>
            </li>
            <li
              @click="
                currentAwayTab2 = 2;
                synergyaway(currentAwayTab2, 'Perimeter Assists', 3);
              "
              v-bind:class="{ active: currentAwayTab2 == 2 }"
            >
              <a>Perimeter Assists</a>
            </li>
            <li
              @click="
                currentAwayTab2 = 3;
                synergyaway(currentAwayTab2, 'Interior Assists', 3);
              "
              v-bind:class="{ active: currentAwayTab2 == 3 }"
            >
              <a>Interior Assists</a>
            </li>
            <li
              @click="
                currentAwayTab2 = 4;
                synergyaway(currentAwayTab2, 'Draw Fouls', 3);
              "
              v-bind:class="{ active: currentAwayTab2 == 4 }"
            >
              <a>Free Throws</a>
            </li>
          </ul>
        </div>
        <div class="players_list">
          <template v-for="(player, index) in awaytablist3">
            <div class="player" :key="index">
              <div class="player_cnt">
                <figure>
                  <img
                    :src="
                      siteUrl +
                      '/api/viewfile?path=playerimages/sportsdataio/' +
                      player.PlayerID +
                      '.png'
                    "
                  />
                </figure>
                <strong>
                  {{ player.FirstName }} {{ player.LastName
                  }}<span>{{ player.Position }}</span>
                          <div class="player_actions">
                  <div class="gradient_btn"><p>{{ player.sortdata }}<sub></sub></p></div>
   </div>

                  
                  </strong
                >
              </div>
            </div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    gamedata: null,
  },
  computed: {},
  methods: {
    synergyHome(currenttab, typed, list) {
      var _self = this;
      var attrs = [];
      this.gamedata.HomeLineup.forEach((element) => {
        if (element["ATTR"] && element["ATTR"][typed]) {
          element.sortdata = (element["ATTR"][typed]*100).toFixed(0);
          attrs.push(element);
        }
      });
      const nestedData = _self.lodash.orderBy(attrs, ["sortdata"], ["desc"]);

      if (list == 1) {
        this.hometablist = nestedData.slice(0, 4);
      }
      else if (list == 2) {
        this.hometablist2 = nestedData.slice(0, 4);
      }
      else if (list == 3) {
        this.hometablist3 = nestedData.slice(0, 4);
      }
    },
    synergyaway(currenttab, typed, list) {
      var _self = this;

      var attrs = [];
      this.gamedata.AwayLineup.forEach((element) => {
      

          if (element["ATTR"] &&  element["ATTR"][typed]) {
          element.sortdata = (element["ATTR"][typed]*100).toFixed(0);
          attrs.push(element);
        }

      });

      const nestedData = _self.lodash.orderBy(attrs, ["sortdata"], ["desc"]);

      if (list == 1) {
        this.awaytablist = nestedData.slice(0, 4);
      }
      else if (list == 2) {
        this.awaytablist2 = nestedData.slice(0, 4);
      }
      else if (list == 3) {
        this.awaytablist3 = nestedData.slice(0, 4);
      }
    },
  },
  watch: {},
  mounted() {
    this.synergyHome(this.currentHometab, "Defensive IQ", 1);
    this.synergyHome(this.currentHometab1, "Offensive Impact", 2);

    this.synergyHome(this.currentHometab2, "Ball Handing", 3);

    this.synergyaway(this.currentAwayTab, "Defensive IQ", 1);
    this.synergyaway(this.currentAwayTab1, "Offensive Impact", 2);

    this.synergyaway(this.currentAwayTab2, "Ball Handing", 3);

    this.siteUrl = process.env.VUE_APP_API_URL;
  },
  data() {
    return {
      siteUrl: 1,
      currentHometab: 1,
      currentHometab1: 1,
      currentHometab2: 1,
      currentAwayTab: 1,
      currentAwayTab1: 1,
      currentAwayTab2: 1,
      hometablist: [],
      awaytablist: [],
      hometablist2: [],
      hometablist3: [],
      awaytablist2: [],
      awaytablist3: [],
    };
  },
};
</script>
