<template>
<div class="flex w-full bg-img vx-row no-gutter  justify-center login-wrapper" id="page-login">
    <div class="login-support-wrap">
        <!-- <div class="login-logo-img">
            <img src="@//assets/images/logo.svg" alt="ProFitX" class="login-logo-img">

        </div> -->
        <h2>{{enquirytype}}</h2>
        <div class="text-danger text-sm formerrors" v-if="formerrors && formerrors.msg!=''">
            {{ formerrors.msg }}
        </div>
        <div class="text-success text-sm formerrors" v-if="formmessage && formmessage.msg!=''">
            {{ formmessage.msg }}
        </div>

        <div class="login-inputs">
            <div class="inputbix name">
                <v-text-field name="Name" class="text_field" label="Name" v-validate="'required'" v-model="enquiry.name" single-line outlined></v-text-field>
                <span class="error-text" v-show="errors.has('Name')">{{ errors.first("Name") }}</span>
            </div>

            <div class="inputbix email">
                <v-text-field name="Email" class="text_field" label="Email" v-validate="'required|email'" v-model="enquiry.email" single-line outlined></v-text-field>
                <span class="error-text" v-show="errors.has('Email')">{{ errors.first("Email") }}</span>
            </div>
            <div class="inputbix phone">
                <v-text-field name="Phonenumber" v-on:keypress="checkPhonenumber($event)" v-model="enquiry.phoneNo" class="text_field" label="Phone (Optional)" v-validate="'max:15'" single-line outlined></v-text-field>
                <span class="error-text" v-show="errors.has('Phonenumber')">{{ errors.first("Phonenumber") }}</span>

            </div>

            <div class="inputbix password">

                <textarea type="text" class="form_control" name="Message" data-vv-as="Message" v-model="enquiry.description"  placeholder="Message"></textarea>
                <span class="error-text" v-show="errors.has('Message')">{{ errors.first("Message") }}</span>

            </div>
            <!--<div class="input_actions">
                <v-checkbox v-model="checkbox" :label="`Remember Me`"></v-checkbox>
                <a  @click="showFP()">Forgot Your Password?</a>
            </div>-->
            <div class="action_btns d-block">
                <button class="primary_btn" @click="submitForm()" href="javascript:;">Submit </button>
            </div>

        </div>

    </div>
    <!-- <snakebar v-if="snackbar" :snackbar="snackbar" :msg="text" :isError="isError" />-->
    <success-popup :showoverlay="snackbar" :title="'Success'" :description="text" />
</div>
</template>

<style scoped>
.theme--dark.v-overlay {

    z-index: 1000;
}
</style>

<script>
import successPopup from "@/views/success.vue";

export default {
    props: ["enquirytype", "selectedplan", "et"],
    components: {
        successPopup
    },
    data() {
        return {
            isError: '',
            text: '',
            snackbar: false,
            test: true,
            enquiry: {
                name: "",
                phoneNo: '',
                phoneCode: '+1',
                email: "",
                description: '',
                enquirytype: '',
                selectedplan:null

            },
            checkbox_remember_me: false,
            formmessage: {
                msg: ""
            },
            formerrors: {
                msg: ""
            }
        };
    },
    methods: {
        updatePhoneNumber(item) {
            if (item.isValid) {
                this.enquiry.phoneCode = item.countryCallingCode;
                this.enquiry.phoneNo = item.nationalNumber;
            }
        },
        showFP() {

            this.$emit('showFP', true)

        },
        showSignup() {
            this.$emit('showSignup', true)
        },
        clearfields() {
            this.enquiry = {
                name: "",
                phoneNo: '',
                phoneCode: '',
                email: "",
                description: ''

            }
        },

        submitForm() {
            Object.assign(this.formerrors, {
                msg: ''
            });
            Object.assign(this.formmessage, {
                msg: ''
            });
            this.$validator.validateAll().then(result => {
                if (result) {

                    if(this.et == 1){

                        this.enquiry.selectedplan = this.selectedplan
                    }

                  this.enquiry.enquirytype = this.enquirytype


                    this.$store
                        .dispatch("enquirySubmit", this.enquiry)
                        .then(response => {
                            let message = '';
                            if (response.error) {
                                message = response.error.message;
                                this.isError = true;
                                Object.assign(this.formerrors, {
                                    msg: response.error.message
                                });
                            } else {
                                message = response['message'];
                                this.isError = false;
                                this.text = "Thanks for your interest. ProfitX team will reach you to help you with your interest";


                            }

                            this.snackbar = true;
                            setTimeout(() => {
                                this.snackbar = false;
                                this.clearfields();
                                this.$validator.reset();
                                this.$emit('closeEnquiry', {
                                    "action": false
                                })
                            }, 3000)

                        })
                        .catch((err) => {
                            this.formmessage.msg = err.message

                        });

                }
            });
        }
    }
};
</script>

<style scoped>
.body {
    overflow: hidden;
}
</style>
