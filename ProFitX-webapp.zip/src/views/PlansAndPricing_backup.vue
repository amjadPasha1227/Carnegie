<template>
<div>
    <div id="myHeader" class="pricing_header" data-aos="fade-down">
        <div class="container padtb0">
            <div class="row">
                <div class="header">
                    <div id="logo">
                        <a :href="websiteurl"><img width="180" src="@/assets/images/logo.svg"></a>
                    </div>
                    <nav>
                        <ul>
                            <li>
                                <a :href="websiteurl+'/benefits/'">Benefits</a>
                            </li>
                            <li>
                                <a :href="websiteurl+'/about/'">About Us</a>
                            </li>
                            <li>
                                <a 
                                :href="websiteurl+'/case-studies/'"
                                >Case Studies</a>
                            </li>
                            <li>
                                <a class="active" 
                                
                                
                                href="javascript:;">Pricing</a>
                            </li>
                            <li>
                                <a 
                                 :href="websiteurl+'/contact/'"
                                
                                >Contact</a>
                            </li>
                        </ul>
                    </nav>
                    <!-- <div class="header_actions">
                            <a href="#" class="secndary_btn">Login</a> 
                        </div> -->
                    <div class="header_actions" v-if="!loggedinview">
                     <a class="secndary_btn" v-on:click="loadlogin()">Login</a>  <!--  -->
                    </div>
                <div class="header_actions" v-else>
                     <router-link class="secndary_btn" to="profile">My Account</router-link>  <!--  -->
                    </div>


                    <div id="nav-icon1">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <plans-list ref="planlist" :shwologin="shwologin" />
    <section class="plans_comparison">
        <div class="container">
            <div class="row">
                <div class="comparison_cnt">
                    <h3 class="subtitle" data-aos="fade-up">Comparison</h3>
                    <h5 class="tag_line" data-aos="fade-up">Human Performance Intelligence, custom-made & calibrated to the finest detail  built for everyone in the sports ecosystem at critical junctures of the year. The Financial and Performance packages are designed to track and evaluate your favorite athletes and teams during the Season and Off-season.  </h5>
                    <ul data-aos="fade-up">
                        <li>
                            <h6>Features</h6>
                            <h3>League Pass</h3>
                            <h3>In-Season</h3>
                            <h3>Off-Season</h3>
                            
                        </li>
                        <li>
                            <label>Star/System Reliance</label>
                            <span><img src="@/assets/images/check.png"></span>
                             <span><img src="@/assets/images/check.png"></span>
                              <span><img src="@/assets/images/check.png"></span>
                        </li>
                        <li>
                            <label>Player Roles</label>
                            <span><img src="@/assets/images/check.png"></span>
                           
                            <span><img src="@/assets/images/check.png"></span>
                             <span></span>
                        </li>
                        <li>
                            <label>Career Outlook</label>
                            <span><img src="@/assets/images/check.png"></span>
                              
                        <span></span>
                                                        <span><img src="@/assets/images/check.png"></span>

                        </li>
                        <li>
                            <label>Opportunity</label>
                            <span><img src="@/assets/images/check.png"></span>
                            
 <span><img src="@/assets/images/check.png"></span>
<span></span>
                            
                        </li>
                        <li>
                            <label>Team Fit</label>
                            <span><img src="@/assets/images/check.png"></span>
                           
                              <span></span>
                        <span><img src="@/assets/images/check.png"></span>
                        </li>
                        <li>
                            <label>Athlete Performance</label>
                            <span><img src="@/assets/images/check.png"></span>
                              <span><img src="@/assets/images/check.png"></span>
                            <span></span>

                        </li>
                        <li>
                            <label>Trade Value</label>
                            <span><img src="@/assets/images/check.png"></span>
                                                      <span><img src="@/assets/images/check.png"></span>
                            <span><img src="@/assets/images/check.png"></span>

                        </li>
                        <li>
                            <label>Player Synergy</label>
                            <span><img src="@/assets/images/check.png"></span>
                             <span><img src="@/assets/images/check.png"></span>
                            <span><img src="@/assets/images/check.png"></span>

                        </li>
                        <li>
                            <label>Attributes</label>
                            <span><img src="@/assets/images/check.png"></span>
                             <span><img src="@/assets/images/check.png"></span>

                            <span></span>

                        </li>
                        <li>
                            <label>Tendencies</label>
                            <span><img src="@/assets/images/check.png"></span>
                          <span></span>

                            <span><img src="@/assets/images/check.png"></span>

                         
                        </li>
                        <li>
                            <label>Injury Risk</label>
                            <span><img src="@/assets/images/check.png"></span>
                           <span><img src="@/assets/images/check.png"></span>

                            <span></span>

                       
                        </li>
                        <li>
                            <label>Load Management</label>
                            <span><img src="@/assets/images/check.png"></span>
                               <span><img src="@/assets/images/check.png"></span>
                                  <span></span>
                                  
                        </li>
                        <li>
                            <label>Player Contracts</label>
                            <span><img src="@/assets/images/check.png"></span>
                            <span></span>

                            <span><img src="@/assets/images/check.png"></span>

                          
                        </li>
                        <li>
                            <label>Financial Impact</label>
                            <span><img src="@/assets/images/check.png"></span>
                           <span></span>

                            <span><img src="@/assets/images/check.png"></span>

                           
                        </li>
                        <li>
                            <label>Athlete Impact</label>
                            <span><img src="@/assets/images/check.png"></span>
                            <span><img src="@/assets/images/check.png"></span>

                            <span></span>

                           
                        </li>
                        <li>
                            <label>Position Versatility</label>
                            <span><img src="@/assets/images/check.png"></span>
                            <span><img src="@/assets/images/check.png"></span>

                            <span></span>

                           
                        </li>
                        <li>
                            <label>ProXtial</label>
                            <span><img src="@/assets/images/check.png"></span>
                            <span><img src="@/assets/images/check.png"></span>
                            <span><img src="@/assets/images/check.png"></span>

                          
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

</div>
</template>

<style lang="scss">

</style>

<script>
import plansList from "@/views/plans.vue";

export default {
    data() {
        return {
            websiteurl:null,
            shwologin: false,
            loggedinview: false
        };
    },
    components: {
        plansList
    },
    mounted() {
        this.websiteurl = process.env.VUE_APP_WEBSITE_URL;
        //if user logged in
        if (this.$store.state && this.$store.state.user && this.$store.state.user._id) {
            var user = this.$store.state.user;
            this.loggedinview = true;

        }

    },
    computed: {

    },
    methods: {
        loadForm(){
            this.$refs["planlist"].enquiryApp = true;
                        this.$refs["planlist"].et = 1;

            this.$refs["planlist"].enquirytype = 'Request For Athlete Pass'

        },
        loadlogin() {

            this.$refs["planlist"].logintoApp = true;
        }

    }
}
</script>
