<template>
  <div
    @click="
      snackbar = false;
      swapCount =0
      
    "
  >
    <div class="athelets_sec">
      <div class="athelets_header">
        <div>
          <h3>Athletes</h3>
          <p>Add athletes to the dashboard so they can manage the content</p>
        </div>
        <div class="d-flex">
          <v-select
            v-model="tempSelectedTeamId"
            @input="changedTeam()"
            :items="allTeams"
            item-text="TEAM_NAME"
            item-value="TEAM_ID"
            label="ALL TEAMS"
            solo
          ></v-select>
          <input
            v-model="searchText"
            type="text"
            @keyup="searchPlayer()"
            class="search"
            placeholder="Search Athletes"
          />
        </div>
      </div>
      <div class="athelets_list">
        <div class="loading-page" v-if="isloading">
          <figure>
            <img src="@/assets/images/loader.gif" />
          </figure>
          Loading
        </div>
        <div class="loading-page" v-if="!isloading && players.length == 0">
          No Results Found
        </div>

        <ul v-slimscroll="options">
          <template v-for="(player, index) in players">
            <li :key="index" @click="secectionProcess(player)">
              <div class="athelet" :class="{ selected: player.selected }">
                <figure>
                  <span
                    ><img
                      :src="
                        'https://profitx.ai/api/viewfile?path=playerimages/' +
                        player.goalserveDetails.PlayerID +
                        '.png'
                      "
                  /></span>
                  <em
                    ><img
                      :src="
                        'https://profitx.ai/api/viewfile?path=teams/' +
                        player.goalserveDetails.TeamID +
                        '.png'
                      "
                  /></em>
                </figure>
                <label>
                  <strong>{{ player.PLAYER_NAME }}</strong>
                  <span v-if="player.TEAM_ABBREVIATION">{{
                    player.TEAM_ABBREVIATION
                  }}</span>
                </label>
              </div>
            </li>
          </template>
        </ul>
      </div>
    </div>
    <div class="slected_warp">
      <div class="slected_list">
        <ul>
          <template v-for="(selectedAthlet, si) in selectedAthlets.slice(0, 8)">
            <li :key="si" @click="secectionProcess(selectedAthlet)">
              <figure>
                <span
                  ><img
                    :src="
                      siteUrl +
                      '/api/viewfile?path=playerimages/' +
                      selectedAthlet.goalserveDetails.PlayerID +
                      '.png'
                    "
                /></span>
              </figure>
              <div class="athelet">
                <figure>
                  <span
                    ><img
                      :src="
                        siteUrl +
                        '/api/viewfile?path=playerimages/' +
                        selectedAthlet.goalserveDetails.PlayerID +
                        '.png'
                      "
                  /></span>
                  <em
                    ><img
                      :src="
                        siteUrl +
                        '/api/viewfile?path=teams/' +
                        selectedAthlet.goalserveDetails.TeamID +
                        '.png'
                      "
                  /></em>
                </figure>
                <label>
                  <strong>{{ selectedAthlet.PLAYER_NAME }}</strong>
                  <span v-if="selectedAthlet.TEAM_ABBREVIATION">{{
                    selectedAthlet.TEAM_ABBREVIATION
                  }}</span>
                </label>
              </div>
            </li>
          </template>

          <li class="more" v-if="selectedAthlets.length > 8">
            <figure>+{{ selectedAthlets.length - 8 }}</figure>
            <div class="athelets_details">
              <vue-custom-scrollbar class="scroll-area" :settings="settings">
                <div>
                  <template
                    v-for="(pl, plindex) in selectedAthlets.slice(8, 100)"
                  >
                    <div
                      :key="plindex"
                      class="athelets_details_list"
                      @click="secectionProcess(pl)"
                    >
                      <figure>
                        <span
                          ><img
                            :src="
                              siteUrl +
                              '/api/viewfile?path=playerimages/' +
                              pl.goalserveDetails.PlayerID +
                              '.png'
                            "
                        /></span>
                        <em
                          ><img
                            :src="
                              siteUrl +
                              '/api/viewfile?path=teams/' +
                              pl.goalserveDetails.TeamID +
                              '.png'
                            "
                        /></em>
                      </figure>
                      <label
                        >{{ pl.PLAYER_NAME }}
                        <p>{{ pl.TEAM_ABBREVIATION }}</p>
                      </label>
                    </div>
                  </template>
                </div>
              </vue-custom-scrollbar>
            </div>
          </li>
        </ul>
        <div class="slected_actions">
          <p>
            <span>{{ selectedAthlets.length }}/</span>{{ athletsLimit }}
          </p>
         
          <button
            @click="updateAthlets() || swapCount > athletsLimit"
            :disabled="selectedAthlets.length < athletsLimit || (dbSwapCount>=athletsLimit  )"
            class="primary_btn"
          >
            Get Started <!-- {{swapCount}} --{{dbSwapCount}}-->
           
          </button>
        </div>
      </div>
    </div>

    <snakebar
      v-if="snackbar"
      :snackbar="snackbar"
      :msg="text"
      :isError="isError"
    />

    <snakebar
      v-if="swapCount > athletsLimit"
      :snackbar="true"
      :msg="'Swap count exceded'"
      :isError="true"
    />
  </div>
</template>

<script>
import teams from "@/data/teams.json";
import snakebar from "@/views/components/snakebar.vue";
import vueCustomScrollbar from "vue-custom-scrollbar";
import "vue-custom-scrollbar/dist/vueScrollbar.css";
import _ from "lodash";
export default {
  components: {
    snakebar,
    vueCustomScrollbar,
  },

  data() {
    return {
      searchInitCount: 0,
      settings: {
        suppressScrollY: false,
        suppressScrollX: false,
        wheelPropagation: false,
      },
      text: "",
      isError: false,
      snackbar: false,
      vertical: true,
      athletsLimit: 0,
      allTeams: [], //['Team1', 'Team2', 'Team3', 'Team4'],
      options: {
        height: "100%",
        size: 5,
        wheelStep: 10,
      },
      selectedTeamId: {},
      tempSelectedTeamId: "",
      selectedAthlets: [],
      searchText: "",
      page: 1,
      perpage: 60,
      totalCount: 0,
      players: [],
      isloading: false,

      playerposition: {},
      playerteam: {},
      playerage: {},
      experience: null,
      playerweight: null,
      playerheight: null,
      player_role: null,
      exp: null,
      RTC: null,
      FA: null,
      tempSelectedPlayerIds: [],
      cuser: null,
      callFromSearch: false,
      allPlayers: [],
      usersubscription:null,
      dbSwapCount:0,
    };
  },
  methods: {
    updateAthlets() {
      if (this.selectedAthlets.length > 0) {
        let postData = {
          userId: this.cuser["_id"],
          athletes: [],
        };
        this.lodash.forEach(this.selectedAthlets, (item) => {
          postData["athletes"].push(item["PLAYER_NAME"]);
        });
        this.isloading = true;
        this.$store
          .dispatch("updateAthlets", postData)
          .then((res) => {
            this.text = res.message;
            this.snackbar = true;
            this.isError = false;
            this.isloading = false;
            this.$router.push("/athletes");
          })
          .catch((err) => {
            this.text = err;
            this.isError = true;
            this.snackbar = true;
            this.isloading = false;
          });
      }
    },
    secectionProcess(player) {

        if(this.dbSwapCount >=this.athletsLimit){
            return false;

        }
      let isExists = this.lodash.find(this.selectedAthlets, {
        PLAYER_NAME: player.PLAYER_NAME,
      });

      if (isExists) {
        player.selected = false;
        //remove from selectedAthlets
        let tempList = [];
        //this.selectedAthlets = this.lodash.remove(this.selectedAthlets ,{"PLAYER_ID":player.PLAYER_ID});
        this.selectedAthlets.forEach((item, index) => {
          if (item.PLAYER_NAME != player.PLAYER_NAME) {
            tempList.push(item);
          }
        });
        this.selectedAthlets = tempList;
      } else {
        //add to selectedAthlets

        if (this.selectedAthlets.length < this.athletsLimit) {
          player.selected = true;
          this.selectedAthlets.push(player);

          let selectedAth = _.map(this.selectedAthlets, "PLAYER_NAME");

          if (
            this.usersubscription!=null) {
            let dbAthletes = this.usersubscription["athletes"];
            this.dbSwapCount = this.usersubscription["swapCount"]
              ? this.usersubscription["swapCount"]
              : 0;
            this.processSwapCount({
              selectedAthlets: selectedAth,
              dbAthletes: dbAthletes,
              dbSwapCount: this.dbSwapCount,
            });
          }
        }
      }
    },
    searchPlayer() {
      this.callFromSearch = true;
      this.page = 1;
      this.getPlayersList();
    },
    changedTeam() {
      this.callFromSearch = true;
      this.selectedTeamId = {};
      let dt = this.lodash.find(this.allTeams, {
        TEAM_ID: this.tempSelectedTeamId,
      });
      if (dt) {
        if (dt.TEAM_ID > 0) {
          this.selectedTeamId = dt;
        }
      }
      this.getPlayersList();
    },
    getPlayersList() {
      let isEdit = false;
      var user = this.cuser;
      let serach = {
        page: this.page,
        perpage: this.perpage,
        //Season: "2020-2021",
        matcher: {
          //"filterplayers":[],
          startswith: "",
          searchString: this.searchText,
          playerage: {},
          playerteam: {}, // this.selectedTeamId,
          playerposition: {}, //this.playerposition,
          exp: this.exp,
          RTC: this.RTC,
          playerweight: this.playerweight,
          playerheight: this.playerheight,
          player_role: this.player_role,
          FA: this.FA,
        },
      };

      if (
        this.callFromSearch == false &&
        user &&
        this.usersubscription.athletes &&
        this.usersubscription.athletes.length > 0
      ) {
        serach["matcher"]["filterplayers"] = this.usersubscription.athletes;
        isEdit = true;
        //this.selectedAthlets =  [];
      }
      if (this.lodash.has(this.selectedTeamId, "TEAM_NAME")) {
        serach["matcher"]["playerteam"] = [this.selectedTeamId["TEAM_NAME"]];
      }
      this.isloading = true;
      this.callFromSearch = false;

      this.$store.dispatch("getplayers", serach).then((response) => {
        if (response.error) {
          var test="df"
        } else {
          this.totalCount = response.data.result.totalCount;
          // this.players = response.data.result.list;

          let finaldata = response.data.result.list;

          // this.players = finaldata;
          var _players = [];
          finaldata.forEach((item, index) => {
            let nitem = item;
            nitem.selected = false;
            let isSelected = this.lodash.find(this.selectedAthlets, {
              PLAYER_NAME: item.PLAYER_NAME,
            });

            if (isSelected) {
              nitem.selected = true;
            }
            //alert(JSON.stringify(user['subscriptionDetails']));

            if (
              this.usersubscription!=null &&
              this.searchInitCount <= 0
            ) {
              //subscription.athletes
              if (
                this.usersubscription.athletes &&
                this.usersubscription.athletes.length > 0 &&
                this.usersubscription.athletes.indexOf(
                  nitem.PLAYER_NAME
                ) > -1 &&
                !this.lodash.find(this.selectedAthlets, {
                  PLAYER_NAME: nitem.PLAYER_NAME,
                })
              ) {
                nitem.selected = true;
                this.selectedAthlets.push(nitem);
              }
            }

            _players.push(nitem);
          });

          this.players = _players;
          this.searchInitCount++;
        }
        this.isloading = false;
      });
    },

    getAllPlayersList() {
      let isEdit = false;
      var user = this.cuser;
      let serach = {
        page: this.page,
        perpage: this.perpage,
        //Season: "2020-2021",
        matcher: {
          //"filterplayers":[],
          startswith: "",
          searchString: this.searchText,
          playerage: {},
          playerteam: {}, // this.selectedTeamId,
          playerposition: {}, //this.playerposition,
          exp: this.exp,
          RTC: this.RTC,
          playerweight: this.playerweight,
          playerheight: this.playerheight,
          player_role: this.player_role,
          FA: this.FA,
        },
      };
      if (
        this.callFromSearch == false &&
        user &&
        user.subscriptionDetails &&
        user.subscriptionDetails.length > 0 &&
        user.subscriptionDetails[0].athletes.length > 0
      ) {
        serach["matcher"]["filterplayers"] =
          user.subscriptionDetails[0].athletes;
        isEdit = true;
        //this.selectedAthlets =  [];
      }
      if (this.lodash.has(this.selectedTeamId, "TEAM_NAME")) {
        serach["matcher"]["playerteam"] = [this.selectedTeamId["TEAM_NAME"]];
      }

      this.$store.dispatch("getAllPlayersList", serach).then((response) => {
        if (response.error) {
          var _test= false;
        } else {
          let finaldata = response.data.result.list;

          // this.players = finaldata;
          var _players = [];
          finaldata.forEach((item, index) => {
            let nitem = item;
            nitem.selected = false;
            let isSelected = this.lodash.find(this.selectedAthlets, {
              PLAYER_NAME: item.PLAYER_NAME,
            });

            if (isSelected) {
              nitem.selected = true;
            }

            if (_.has(user, "subscriptionDetails")) {
              //subscription.athletes
              if (
                user.subscriptionDetails[0].athletes &&
                user.subscriptionDetails[0].athletes.length > 0 &&
                user.subscriptionDetails[0].athletes.indexOf(
                  nitem.PLAYER_NAME
                ) > -1 &&
                !this.lodash.find(this.selectedAthlets, {
                  PLAYER_NAME: nitem.PLAYER_NAME,
                }) &&
                this.selectedAthlets.length < this.athletsLimit
              ) {
                nitem.selected = true;
                this.selectedAthlets.push(nitem);
              }
            }

            _players.push(nitem);
          });

          this.allPlayers = _players;
        }
        //this.isloading = false;
      });
    },
  },
  mounted() {
    var $self = this;
    let user = this.$store.state.user;
    let userRole = this.$store.state.userRole;
    let currentPlan = this.$store.getters["subscription/getSubscriptions"];
    this.usersubscription = this.$store.state.subscription;
    let subscription = this.$store.state.subscription;

    if(this.usersubscription){
        this.dbSwapCount = this.usersubscription["swapCount"]? this.usersubscription["swapCount"]: 0;
    }
    this.setPageTitle("ProFitX - Athletes Selection ");
    this.siteUrl = process.env.VUE_APP_API_URL;
    if (userRole != 4 && userRole != 6) {
      this.$router.push("/athletes");
    }
    if(this.usersubscription && this.usersubscription.passType && this.usersubscription.passType =="Limited Access"){

             var _limit = this.usersubscription.athletescount;
              if(_limit == 0) _limit=15;
             this.athletsLimit = _limit;

             
        $self.cuser = user;

        let all = {
          TEAM_ID: 0,
          color: "",
          TEAM_NAME: "ALL TEAMS",
          TEAM_ABBREVIATION: "",
        };

        this.allTeams = teams;

        const insert = (arr, index, newItem) => [
          ...arr.slice(0, index),
          newItem,
          ...arr.slice(index),
        ];

     
        this.allTeams = insert(this.allTeams, 0, all);
        this.getPlayersList();

    }
    if (
      currentPlan &&
      currentPlan.length > 0 &&
      currentPlan[0].criteria.length > 0 &&
      currentPlan[0].criteria[0].qty != 0
    ) {
      this.athletsLimit = currentPlan[0].criteria[0].qty;
    }

    /* Non Paid Block one */
    if (
      currentPlan &&
      currentPlan.length > 0 &&
      currentPlan[0].invoiceDetails > 0 &&
      currentPlan[0].invoiceDetails.statusId != 2
    ) {
      this.$router.push("/plan");
    } else {
      if (
       currentPlan &&
      currentPlan.length > 0 &&
      currentPlan[0].invoiceDetails!=null &&
      currentPlan[0].invoiceDetails.statusId == 2
      ) {


          if(currentPlan[0].planDetails.uniqueId =='LEAGUEPASS'){
             this.$router.push("/athletes");

          }



        $self.cuser = user;

        let all = {
          TEAM_ID: 0,
          color: "",
          TEAM_NAME: "ALL TEAMS",
          TEAM_ABBREVIATION: "",
        };

        this.allTeams = teams;

        const insert = (arr, index, newItem) => [
          ...arr.slice(0, index),
          newItem,
          ...arr.slice(index),
        ];

     
        this.allTeams = insert(this.allTeams, 0, all);
        this.getPlayersList();
      }
    }
  },
  watch: {},
};
</script>

<style>
.scroll-area {
  position: relative;
  margin: auto;
  height: 260px;
}
</style>
