<template>
<div class="plan_athelets_list">
    <ul  v-if="players && players.length > 0">
        <template v-for="(player , index ) in players.slice(0,8)">

            <li :key="index">
                <figure><img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+player.goalserveDetails.PlayerID+".png"'></figure>
                <div class="athelets_details">
                    <figure>
                        <span><img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+player.goalserveDetails.PlayerID+".png"'></span>
                        <em><img :src='"https://profitx.ai/api/viewfile?path=teams/"+player.goalserveDetails.TeamID+".png"'></em>
                    </figure>
                    <label>{{player.PLAYER_NAME}}
                        <p>{{player.TEAM_ABBREVIATION}}</p>
                    </label>
                </div>
            </li>
        </template>
        <li class="more" v-if="athletes.length > 8">
            <figure>+{{athletes.length-8}}</figure>
            <div class="athelets_details">
 <vue-custom-scrollbar class="scroll-area"  :settings="settings" >
                    <template v-for="(player , index ) in players.slice(8,100)">

                        <div class="athelets_details_list" :key="index">
                            <figure>
                                <span><img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+player.goalserveDetails.PlayerID+".png"'></span>
                                <em><img :src='"https://profitx.ai/api/viewfile?path=teams/"+player.goalserveDetails.TeamID+".png"'></em>

                            </figure>
                            <label>{{player.PLAYER_NAME}}
                                <p>{{player.TEAM_ABBREVIATION}}</p>
                            </label>
                        </div>

                    </template>
                  </vue-custom-scrollbar>


            </div>
        </li>
    </ul>

</div>
</template>

<script>
import vueCustomScrollbar from 'vue-custom-scrollbar'
import "vue-custom-scrollbar/dist/vueScrollbar.css"

export default {
      components: {
    vueCustomScrollbar
  },
    props: {
        athletes: null
    },
    data() {
        return {
             settings: {
        suppressScrollY: false,
        suppressScrollX: false,
        wheelPropagation: false
      },
            players: null,
            options: {
                height: '100%',
                size: 5,
                wheelStep: 10,

            },
        }
    },
    mounted() {

   
        if (this.athletes && this.athletes.length > 0) {

            this.serach = {
                page: 1,
                perpage: 100,
                matcher: {
                    filterplayers: this.athletes,
                }
            };

            this.$store
                .dispatch("getplayers", this.serach)
                .then(response => {
                    this.players = response.data.result.list;

                });

        }

    }
}
</script>

<style >
.scroll-area {
  position: relative;
  margin: auto;
  height: 260px;
}
</style>
