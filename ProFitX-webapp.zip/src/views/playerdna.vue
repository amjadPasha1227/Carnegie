<template>
<div class="content-body">

    <sidebar v-if="player!=null" :player=player />

    <div class="content-wrapper">

        <div class="athlete_content_wrap">
            <v-row>
                <v-col>
                    <player-details v-if="player!=null" :player="player" />
                </v-col>
            </v-row>
            <div class="nodataBox" v-if="player && player.totalgames <  40">

                Profile will display once player has met minimum data threshold to ensure accuracy.
            </div>
            <div class="athlete_body_content" v-if="player && player.totalgames > 39">
             
            
                <v-row v-if="checkWidgetsPermessions('TENDENCIES')">
                    <v-col>
                        <player-tendencies v-if="player.PLAYER_NAME!=null && checkWidgetsPermessions('TENDENCIES')" :player=player />
                    </v-col>
                </v-row>
                <v-row>
                    <v-col>
                        <player-attributes v-if="player.PLAYER_NAME!=null && checkWidgetsPermessions('ATTRIBUTES')" :player=player />
                    </v-col>
                </v-row>
                   <v-row>
                    <v-col cols="12">
                        <player-roles v-if="player.PLAYER_NAME!=null && checkWidgetsPermessions('PLAYER_ROLES')" :player=player />
                    </v-col>
                </v-row>
              
            </div>
        </div>
    </div>
</div>
</template>

<script>
import playerDetails from "@/views/components/playerDetails.vue";
import playerRoles from "@/views/components/playerRoles.vue";


import playerAttributes from "@/views/components/playerAttributes.vue";
import playerTendencies from "@/views/components/playerTendencies.vue";
import Sidebar from "@/layouts/components/Sidebar.vue";

export default {
    data() {
        return {
            player: null,
            attributes: true,
            tendecies: true

        };
    },
    watch: {},
    computed: {},
    methods: {
        checkPermissions() {
   let user = this.$store.state.user;
    let userRole = this.$store.state.userRole;
    let currentPlan = this.$store.getters["subscription/getSubscriptions"];
    this.usersubscription = this.$store.state.subscription;
    let subscription = this.$store.state.subscription;

            var $self = this;
        if (userRole != 4) {
                        $self.getplayers()
                    } else {

                     if (currentPlan[0].invoiceDetails == null) {

                                $self.$router.push("/plan");
                            } else {

                                if (currentPlan && currentPlan.length > 0 && currentPlan[0].invoiceDetails > 0 && currentPlan[0].invoiceDetails.statusId != 2) {

                                    $self.$router.push("/plan");
                                } else {

                                    if (subscription && subscription.athletes && subscription.athletes.length > 0) {

                                        //response.subscriptionDetails[0].athletes
                                        $self.getplayers()

                                    }
                                    if(currentPlan && currentPlan.length > 0 && currentPlan[0].planDetails['uniqueId']=='LEAGUEPASS'){
                                         $self.getplayers()
                                    }

                                }

                            }

                    }

        },

        getRoles(filter) {
            let returnvalues = [];
            if (filter != undefined) {
                returnvalues["o"] = [{
                        k: 'Sharpshooter',
                        v: filter["Sharpshooter"] * 100
                    },
                    {
                        k: 'Interior Finisher',
                        v: filter["Interior Finisher"] * 100
                    },
                    {
                        k: 'High Volume Scorer',
                        v: filter["High Volume Scorer"] * 100
                    },
                    {
                        k: 'Playmaker',
                        v: filter["Playmaker"] * 100
                    }
                ]
                returnvalues["d"] = [{
                        k: 'Versatile Defender',
                        v: filter["Versatile Defender"] * 100
                    },
                    {
                        k: 'Rim Protector',
                        v: filter["Rim Protector"] * 100
                    },
                    {
                        k: 'Rebounding Specialist',
                        v: filter["Rebounding Specialist"] * 100
                    },
                    {
                        k: 'Turnover Specialist',
                        v: filter["Turnover Specialist"] * 100
                    },
                    {
                        k: 'High Motor',
                        v: filter["High Motor"] * 100
                    }

                ]

                returnvalues["d"] = this.lodash.orderBy(returnvalues["d"], ['v'], ['desc']);
                returnvalues["o"] = this.lodash.orderBy(returnvalues["o"], ['v'], ['desc']);

            }
            return returnvalues;
        },
        getplayers() {
            this.isloading = true
            this.serach = {
                "page": 1,
                "perpage": 1,
                "matcher": {
                    "playerId": this.$route.params.id
                }
            };

            this.$store
                .dispatch("getplayerdetails", this.serach)
                .then(response => {
                    if (response.error) {
                        this.$router.push("/athletes");
                    } else {

                        this.totalCount = response.data.result.totalCount;
                        let _roles = this.getRoles(response.data.result.list[0].ROLES);
                        let nitem = response.data.result.list[0];
                        nitem._roles = _roles;

                        var totalgames = 0

                        nitem['seasons'].forEach(function (tem) {

                            totalgames = totalgames + tem.GP;
                        })
                        nitem.totalgames = totalgames;
                        this.player = nitem;

                    }
                    var self = this;
                    setTimeout(function () {

                        self.isloading = false;
                    }, 1000)

                });

        }

    },
    components: {
        playerDetails,
        playerRoles,
        playerTendencies,
        playerAttributes,
        Sidebar
    },
    mounted() {

        this.checkPermissions()
    }
};
</script>

<style>

</style>
