<template>
<div class="profile_section">
    <div class="prfile_nav">
        <menuItems />
    </div>
    <div class="profile_body" :class="{'payments_body': [1,2,3].indexOf(userRole) >-1}">
      <card-details />
      
        <div class="profile_table">
            <div class="action_btns marb20">
                <div class="d-flex align-items-center">
                    <input class="search" v-model="searchtxt" @keyup="getPayments()" placeholder="Search" />
                    <div class="range_picker">
                        <!-- :return-value.sync="dates" -->
                        <v-menu ref="menu" v-model="menu" :close-on-content-click="false" transition="scroll-x-transition" offset-y min-width="auto">
                            <template v-slot:activator="{ on, attrs }">
                                <v-text-field v-model="dateRangeText" label="" placeholder="Select Date Range" prepend-icon="mdi-calendar" readonly v-bind="attrs" v-on="on"></v-text-field>
                            </template>
                            <v-date-picker v-model="dateRange" :show-current="true" :max="new Date().toISOString()" range no-title scrollable>
                                <v-spacer></v-spacer>
                                <v-btn text color="primary" @click="menu = false;dateRange=[] ;getPayments()">
                                    Cancel
                                </v-btn>
                                <v-btn :disabled="dateRange.length<2" text color="primary" @click="$refs.menu.save(dateRange);getPayments()">
                                    OK
                                </v-btn>
                            </v-date-picker>
                        </v-menu>
                    </div>
                </div>
            </div>
            <label class="sm_label">Invoices</label>
            <v-simple-table fixed-header height="300px">
                <template v-slot:default>
                    <thead>
                        <tr>
                            <th class="text-left">
                                <span @click="sortMe('refId')" v-bind:class="{
                      sort_ascending: sortKeys['refId'] == 1,
                      sort_descending: sortKeys['refId'] != 1,
                    }">Invoice No. 
                                </span>
                            </th>

                            

                        <th class="text-left" v-if="userRole && [1,2,3].indexOf(userRole)>-1" >
                                   <!-- <span @click="sortMe('email')" v-bind:class="{
                            sort_ascending: sortKeys['email'] == 1,
                            sort_descending: sortKeys['email'] != 1,
                        }">Email
                                    </span>
                                    refId
                                    -->
                                    Email
                                </th>

                            <th class="text-left">Plan</th>
                            <th>
                                <span @click="sortMe('totalAmount')" v-bind:class="{
                      sort_ascending: sortKeys['totalAmount'] == 1,
                      sort_descending: sortKeys['totalAmount'] != 1,
                    }">Amount
                                </span>
                            </th>
                            <th>
                                <span @click="sortMe('createdOn')" v-bind:class="{
                      sort_ascending: sortKeys['createdOn'] == 1,
                      sort_descending: sortKeys['createdOn'] != 1,
                    }">Created On
                                </span>
                            </th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <template v-if="list.length > 0">
                            <template v-for="(payment, index) in list">
                                <tr :key="index">
                                    <td>{{payment.refId}}</td>
                                    <td class="text-left" v-if="userRole && [1,2,3].indexOf(userRole)>-1" >
                                        {{checkProperty(payment , 'subscriberDetails' ,'email') }}
                                    </td>
                                    <td>
                                        <span v-if="payment.planDetails.criteria && payment.planDetails.criteria.length > 0 && payment.planDetails.criteria[0].qty!=0">{{payment.planDetails.criteria[0].qty}} </span>
                                        <span v-if="payment.planDetails.criteria && payment.planDetails.criteria.length > 0 && payment.planDetails.criteria[0].label!=null">{{payment.planDetails.criteria[0].label}}</span>
                                    </td>
                                    <td>${{payment.totalAmount}}</td>
                                    <td>{{payment.createdOn | formatDate}}</td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <span class="td_status " :class="{'pending':payment.statusId==1,'paid':payment.statusId==2}">{{ checkProperty(payment ,'statusDetails' , 'name') }}</span>

                                        </div>
                                    </td>
                                    <td>
                                        <div class="menu_profile">
                                            <v-icon>mdi-dots-horizontal</v-icon>
                                            <div class="menu_list">
                                                <ul>
                                                    <li @click="downloadInvoice(payment)"><a>Download</a></li>
                                                    <!-- <li><a href="#">View</a></li>-->
                                                </ul>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </template>
                        </template>

                        <tr>
                            <td v-if="list.length <= 0" colspan="6" class="no-data">
                                No Invoices Found!
                            </td>
                        </tr>
                    </tbody>
                </template>
            </v-simple-table>
           <div class="pagination_wrap"   v-if="list.length > 0">
            <paginate 
            v-model="page"
          :page-count="totalpages"
          :page-range="3"
          :margin-pages="2"
          :click-handler="pageNate"
          prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
          next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next"
          :prev-text="'<i></i>'"
          :next-text="'<i></i>'"
          :container-class="'pagination vs-pagination--nav'"
          :page-class="'page-item'"
        ></paginate>
           </div>
        </div>
    </div>

</div>
</template>

<script>
import menuItems from "@/views/components/menuItems.vue";
import cardDetails from "@/views/card.vue";
import Paginate from "vuejs-paginate";
import moment from "moment";
import _ from "lodash";

export default {
    components: {
        menuItems,
        cardDetails,
        Paginate
    },

    mounted() {
        this.setPageTitle("ProFitX - Payments");
        this.userData = this.$store.state.user;
        this.userRole= this.$store.state.userRole;

        this.sortKeys = {
            refId:1,
            invoice: 1,
            amount: 1,
            totalAmount:1,
            createdOn: -1,
            updatedOn:1
        };
        this.sortKey = {"path":"createdOn" ,"order":-1};
        this.getMaterData("invoice_company_list");
        //this.getPayments();
         this.userData = this.$store.state.user;
    },

    data() {
        return {
            userData: null,
            menu: false,
            modal: false,
            menu2: false,
            dateRange: [],

            list: [],
            isloading: false,
            callFromSort: false,
            loaded: false,
            snackbarMessage: "",
            snackbar: false,
            popupcreateUser2: false,
            items: ["Foo", "Bar", "Fizz", "Buzz"],
            tickets: [],
            sortKeys: {},
            sortKey: {},
            searchtxt: "",
            page: 1,
            perpage: 25,
            totalpages: 0,
            perPeges: [10, 25, 50, 75, 100],
            filter_searchtxt: "",
        userRole:null,
            invoice_company_list: [],
        };
    },
    methods: {

           
       
        downloadInvoice(invoice) {

            if (this.lodash.has(invoice, "document")) {
                // alert(invoice.document);
                var domain='';
                if(process.env.NODE_ENV!=='production'){
                    domain = process.env.VUE_APP_SUBAPI_URL+"/api/";
                }else{
                    domain = process.env.VUE_APP_SUBAPI_URL;
                }

                let user = this.$store.state.user;
                let subscriber ={ // Send when view as 'End User'
                        "name": user['name'],
                        "email": user['email'],
                        "phone": user['phoneNo'] ? user['phoneNo'] : "",
                        "phoneCode": user['phoneCode'] ? user['phoneCode'] : "+1"
                    }

                let postData ={
                    "invoiceId":invoice._id,
                    "subscriber":subscriber,
                    appActivity: true
                }
                this.$store.dispatch("subscription/getInvoices" ,postData)
                   .then(pdf => {
     
        if (pdf != null) {
          var blobPDF = new Blob([pdf], { type: 'application/pdf' })
                    let fileName = "Invoice-"+invoice._id+".pdf";

                    const url = URL.createObjectURL(blobPDF);
                   // alert(url);
    
                    const link = document.createElement('a');
                    if (link.download !== undefined) { // feature detection
                        link.setAttribute('href', url);
                        link.setAttribute('download', fileName);
                        link.style.visibility = 'hidden';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                    
        }

                })
                .catch((err)=>{
                })
                //:src='"https://beta.profitx.ai/api/viewfile?path=playerimages/"+selectedAthlet.goalserveDetails.PlayerID+".png"'
                //let basePath = domain+"/common/viewfile?path=" + invoice.document;
                //window.open(basePath);

            }
        },
        getMaterData(category) {
            let payLoad = {
                appActivity: true,
                matcher: {
                    title: "",
                    cntryIds: [],
                    stateIds: [],
                },
                category: "invoice_company_list", // "plan_type", //invoice_company_list, city, state, country, plan_category, plan_frequency, plan_operator, payment_service, plan_status, subscribe_status, invoice_status, user_role, user_status, company_status
                page: 1,
                perpage: 2500,
            };
            this.$store.dispatch("subscription/getMaterData", payLoad).then((res) => {
                this[category] = res.list;
                this.getPayments();
            });
        },
        pageNate(pageNum) {
            this.page = pageNum;
            this.getPayments();
        },
        getPayments() {
            var self = this;
                let user = this.$store.state.user;
    let userRole = this.$store.state.userRole;

            let obj = {
                appActivity: true,
                "filters": {
                    "companyId": "", // Send When view as 'Admin'
                    "title": this.searchtxt,
                    "statusIds": [],
                    "dueDateRange": [],
                    "paidDateRange": [],
                    "createdOnRange": []
                },
                page: this.page,
                perpage: this.perpage,
                //sortKeys: this.sortKey,
                sorting: this.sortKey
            };

            if (this.dateRange.length >= 2) {
                obj["filters"]["createdOnRange"] = [moment(this.dateRange[0]).format("YYYY-MM-DD"), moment(this.dateRange[1]).format("YYYY-MM-DD")];
            }

          if ([1, 2, 3].indexOf(userRole) != -1) {

                    obj["filters"]["companyId"] = this.invoice_company_list[0]['_id'];

                } else {
                    obj["subscriber"] = { // Send when view as 'End User'
                        "name": user['name'],
                        "email": user['email'],
                        "phone": user['phoneNo'] ? user['phoneNo'] : "",
                        "phoneCode": user['phoneCode'] ? user['phoneCode'] : "+1"
                    }

                }

            if (this.callFromSort) {
                this.callFromSort = false;
            } else {
                this.loading = true;
                this.callFromSort = false;
                this.list = [];

            }

            this.$store
                .dispatch("subscription/getList", {
                    data: obj,
                    path: "/invoices/list"
                })
                .then((response) => {
                    // alert(JSON.stringify(response));
                    this.list = response.list;
                    this.totalpages = Math.ceil(response.totalCount / this.perpage);
                   // this.totalpages = Math.ceil(response.totalCount / this.perpage);
                })
                .catch((err) => {
                    //alert(err);
                    this.list = [];
                });
        },
        sortMe(sort_key = "") {
            if (sort_key != "") {
                this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
               // this.sortKey = {"path":"updatedOn" ,"order":-1};
               // this.sortKey[sort_key] = this.sortKeys[sort_key];
               this.sortKey = { "path":sort_key ,"order":this.sortKeys[sort_key]};
                this.callFromSort = true;

                this.getPayments();
            }
        },
        changeperPage() {
            this.page = 1;
            this.getPayments();
        },
    },
    watch: {
        dateRange: function (value) {
           // this.getPayments();
        },
        searchtxt: function (value) {
            this.getPayments();
        },
    },
    computed: {
        getRoleData() {
            return parseInt(localStorage.getItem('userRole'));
        },
        getUserData() {
            return this.$store.state.user;
        },

        dateRangeText() {
            return this.dateRange.join(" To ");
        },
    },
};
</script>
