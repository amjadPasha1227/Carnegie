<template>
<div class="profile_section" @click="snackbar =false">
    <div class="prfile_nav">
        <menuItems />
        <!--<ul>
                <li><router-link to="/profile">Profile</router-link></li>
                <li><router-link to="/plan">Plan</router-link></li>
                <li class="active"><router-link to="/payments">Payments</router-link></li>
                <li><router-link to="/support">Support</router-link></li>
            </ul>-->
    </div>
    <!--<the-filter /> -->
    <div class="profile_body" :class="{'payments_body': [1,2,3].indexOf(userRole) >-1}">
        <div class="profile_table ">
            <div class="action_btns marb20">
                <input class="search" v-model="serch_title" @keyup="onEnter" placeholder="Search By Name">
                <!--selectedroles   usersRoles  onChange-->
                <div style="display:none" class="assets-teams" v-if="[1,2 ,3].indexOf(userRole) >-1" >
                            
                                <multiselect
                                    :multiple="true"
                                   :value="'id'"
                                    label="name"
                                    @input="onChange"
                                    placeholder="User Role"
                                    :allow-empty="true"
                                    :close-on-select="false"
                                    :clear-on-select="false"
                                    :hide-selected="false"
                                    :preserve-search="true"
                                    v-model="selectedroles"
                                    :options="usersRoles"
                                    >
                                    <template slot="selection" slot-scope="{ values, isOpen }">
                                        <span
                                        class="multiselect__selectcustom"
                                        v-if="values.length && !isOpen"
                                        >{{ values.length }} selected</span
                                        >
                                        <span
                                        class="multiselect__selectcustom"
                                        v-if="values.length && isOpen"
                                        ></span>
                                    </template>
                                </multiselect>
                            
                        </div>

                <button v-if="userRole==1" class="primary_btn" @click="snackbar =false; initUser();popupcreateUser=true">
                    Invite User
                </button>
            </div>

            <template v-if="!loading">

                <v-simple-table fixed-header height="300px">
                    <template v-slot:default>
                        <thead>
                            <tr>
                                <th>
                                    <span @click="sortMe('name')" v-bind:class="{
                              sort_ascending: sortKeys['name'] == 1,
                              sort_descending: sortKeys['name'] != 1,
                            }">Name
                                    </span>
                                </th>
                                
                                <th>
                                    <span @click="sortMe('email')" v-bind:class="{
                              sort_ascending: sortKeys['email'] == 1,
                              sort_descending: sortKeys['email'] != 1,
                            }">Email
                                    </span>
                                </th>
                                <th>Role</th>
                                <th>
                                    <span @click="sortMe('createdOn')" v-bind:class="{
                              sort_ascending: sortKeys['createdOn'] == 1,
                              sort_descending: sortKeys['createdOn'] != 1,
                            }">Created On
                                    </span>
                                </th>

                                <th> Status </th>

                                <!-- <td>Edit</td> -->

                                <th class="rt-align"> Action </th>

                            </tr>
                        </thead>
                        <tbody>
                            <template v-if="list && list.length > 0">
                                <tr v-for="(item, index) in list" :key="index">
                                    <td>

                                        {{ item.name}}
                                    </td>
                                    <td>
                                        {{ item.email}}
                                    </td>
                                    <td>
                                        {{ getUserRole(item.roleDetails)}}
                                    </td>
                                    <td>
                                        {{ item.createdOn | formatDate}}
                                    </td>

                                    <td>
                                        <span :class="{'active':item['status'] ,'inactive':item['status']}">

                                            {{item['status']?'Active':'Inactive'}}
                                        </span>
                                    </td>
                                    <!-- <td>

                        </td> -->
                                    <!-- <span>
                        <v-btn
                            class="ma-2" outlined color="indigo" @click="UpdateUser(item)">Update</v-btn>
                        </span> -->
                                    <td class="td_actions">

                                        <span @click=" selectedUser =item; userActionPopup = true">
                                            <v-icon v-if="item.status">mdi-account</v-icon>
                                            <v-icon v-else>mdi-account-off</v-icon>
                                        </span>
                                        <!-- <span @click="UpdateUser(item)"><v-icon>mdi-lead-pencil</v-icon></span>-->

                                        <!-- <span @click=" selectedUser =item; userActionPopup = true" class="td_action">

                              {{item['status']?'Inactivate':'Activate'}}
                          </span> -->

                                    </td>
                                </tr>
                            </template>
                            <template v-else>
                                <tr>
                                    <td colspan="6" class="center-align no-data">No Users Found!</td>
                                </tr>
                            </template>
                        </tbody>
                    </template>
                </v-simple-table>
                <div class="pagination_wrap" v-if="totalCount > 0">
                    <paginate v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2" :click-handler="changedPage" prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev" next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'" :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
                </div>

                <!-- <div class="pagination_wrap" v-if="totalCount > 0">

        <Paginate
        v-if="totalpages > 1"

          :page-count="totalpages"
    :page-range="3"
    :margin-pages="2"
    :click-handler="changedPage"
    :prev-text="'Prev'"
    :next-text="'Next'"
    :container-class="'pagination'"
    :page-class="'page-item'"

        />
      </div> -->
            </template>

            <div class="loading-page" v-if="loading">
                <figure>
                    <img src="@/assets/images/loader.gif">
                </figure>Loading
            </div>

        </div>
    </div>
    <v-dialog v-model="popupcreateUser" max-width="600" class="injury-dialog-block" fullscreen persistent>
        <div class="dialog_body add_user">
            <div class="dialog_head">
                <h4>Invite User</h4>
                <v-btn color="primary" text @click="initUser(); popupcreateUser = false" class="close-btn">
                    <v-icon>mdi-close</v-icon>
                </v-btn>
            </div>
            <div class="form_section">
                <form v-on:submit.prevent>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label class="form_label">First Name</label>
                                <v-text-field name="First Name" v-validate="'required'" v-model="newUser.firstName" single-line outlined></v-text-field>
                                <span class="error-text" v-show="errors.has('First Name')">{{ errors.first("First Name") }}</span>
                            </div>
                        </div>
                        <div class="col">
                            <!-- <div class="form-group">
                  <v-text-field name="Middle Name" label="Middle Name" v-validate="'required'" v-model="newUser.middleName" single-line outlined></v-text-field>
                  <span class="error-text" v-show="errors.has('Middle Name')">{{ errors.first("Middle Name") }}</span>
                </div> -->
                            <div class="form-group">
                                <label class="form_label">Last Name</label>
                                <v-text-field name="Last Name" class="text_field" v-validate="'required'" v-model="newUser.lastName" single-line outlined></v-text-field>
                                <span class="error-text" v-show="errors.has('Last Name')">{{ errors.first("Last Name") }}</span>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="form-group">

                                <label class="form_label">Contact Number <small>(Optional)</small></label>
                                <input type="text" v-on:keypress="checkPhonenumber($event)" class="form_control" name="Phone" v-validate="'required'|'max:15'|'min:10'" v-model="newUser.phoneNo">
                                <span class="error-text" v-show="errors.has('Phone')">{{ errors.first("Phone") }}</span>

                                <!-- <label class="form_label">Phone Number</label>
                        <VuePhoneNumberInput 

                      default-country-code="US"
                      :no-example="true"
                      :no-country-selector="false"
                      @update="updatePhoneNumber"  
                      :required="true"
                      v-model="newUser.phoneNo" />
                  <span class="v-messages error-msg ddd">{{ errors[0] }}</span>-->
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label class="form_label">Email</label>
                                <v-text-field name="email" class="text_field" v-validate="'required|email'" v-model="newUser.email" single-line outlined></v-text-field>
                                <span class="error-text" v-show="errors.has('email')">{{ errors.first("email") }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="row">

                        <div class="col">
                            <div class="form-group">
                                <label class="form_label">Pass Type </label>
                                <v-select v-model="newUser.passType" :name="'Pass Type'" :items="slectitems" label="Pass Type" solo></v-select>

                                <!--                     
                      <select v-model="newUser.passType" :name="'Pass Type'"  > 

                        <option value="leegpass">Leeg Pass</option>
                      </select>                -->
                                <span class="error-text" v-show="errors.has('Pass Type')">{{ errors.first("Pass Type") }}</span>

                            </div>
                        </div>
                        <div class="col" v-if="newUser.passType !='Free Access' && newUser.passType !='Limited Access'">
                            <div class="form-group">
                                <label class="form_label">Amount</label>
                                <v-text-field data-vv-as=" Amount" type="number" name="paymentAmt" class="text_field" label="Amount" v-validate="'required'|'min:1'" v-model="newUser.paymentAmt" single-line outlined></v-text-field>
                                <span class="error-text" v-show="errors.has('paymentAmt')">{{ errors.first("paymentAmt") }}</span>
                            </div>
                        </div>


                        <div class="col col-6" v-if="newUser.passType =='Free Access' || newUser.passType =='Limited Access'" >
                                <div class="form-group">
                                    <label class="form_label">Date Range</label>
                                    <div class="range_picker">

                                        <!-- :return-value.sync="dates" -->
                                        <v-menu ref="menu" v-model="menu" :close-on-content-click="false" transition="scroll-x-transition" offset-y min-width="auto">
                                            <template v-slot:activator="{ on, attrs }">
                                                <v-text-field v-model="dateRangeTextUser" label="" prepend-icon="mdi-calendar" readonly v-bind="attrs" v-on="on"></v-text-field>
                                            </template>
                                            <v-date-picker v-model="dateRange" :show-current="true" :min="new Date().toISOString()" range no-title scrollable>
                                                <v-spacer></v-spacer>
                                                <v-btn text color="primary" @click="menu = false;dateRange=[];">
                                                    Cancel
                                                </v-btn>
                                                <v-btn :disabled="dateRange.length<2" text color="primary" @click="$refs.menu.save(dateRange)">
                                                    OK
                                                </v-btn>
                                            </v-date-picker>
                                        </v-menu>
                                    </div>
                                </div>
                            </div>

                    </div>
                    <div class="row" v-if="newUser.passType !='Free Access' && newUser.passType !='Limited Access'" >

                        <div class="col col-6">
                            <div class="form-group">
                                <label class="form_label">Date Range</label>
                                <div class="range_picker">

                                    <!-- :return-value.sync="dates" -->
                                    <v-menu ref="menu" v-model="menu" :close-on-content-click="false" transition="scroll-x-transition" offset-y min-width="auto">
                                        <template v-slot:activator="{ on, attrs }">
                                            <v-text-field v-model="dateRangeTextUser" label="" prepend-icon="mdi-calendar" readonly v-bind="attrs" v-on="on"></v-text-field>
                                        </template>
                                        <v-date-picker v-model="dateRange" :show-current="true" :min="new Date().toISOString()" range no-title scrollable>
                                            <v-spacer></v-spacer>
                                            <v-btn text color="primary" @click="menu = false;dateRange=[];">
                                                Cancel
                                            </v-btn>
                                            <v-btn :disabled="dateRange.length<2" text color="primary" @click="$refs.menu.save(dateRange)">
                                                OK
                                            </v-btn>
                                        </v-date-picker>
                                    </v-menu>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="dialog_actions">
                        <button  class="secondary-btn" @click="createUser()" href="javascript:;">
                            Invite
                        </button>
                    </div>
                </form>
            </div>
        </div>

    </v-dialog>

    <v-dialog v-model="popupcreateUser2" max-width="400" content-class="dialog_new">
        <div class="dialog_body">
            <div class="dialog_title">
                <h3>Edit Password</h3>
                <v-btn color="primary" text @click=" popupcreateUser2 = false" class="close-btn">
                    <v-icon>mdi-close</v-icon>
                </v-btn>
            </div>
            <form v-on:submit.prevent>
                <div class="form-group">
                    <label class="form_label">New Password </label>
                    <v-text-field v-validate="'required'" name="password" type="password" class="form-control" ref="password" v-model="selectedUser.newPassword" single-line outlined></v-text-field>
                    <span class="error-text" v-show="errors.has('password')">{{ errors.first("password") }}</span>
                </div>
                <div class="form-group">
                    <label class="form_label">Confirm Password </label>
                    <v-text-field v-validate="'required|confirmed:password'" name="password_confirmation" type="password" class="form-control" data-vv-as="password" v-model="selectedUser.confirmPassword" single-line outlined></v-text-field>
                    <span class="error-text" v-show="errors.has('password_confirmation')">{{ errors.first("password_confirmation") }}</span>
                </div>

                <div class="dialog_actions">
                    <button :disabled="checkUpdateForm" class="secondary-btn w-100" @click="UpdateAction()" href="javascript:;">
                        Update Password
                    </button>
                </div>
            </form>
        </div>

    </v-dialog>
    <v-dialog v-model="userActionPopup" max-width="400" content-class="dialog_new">

        <div class="dialog_body">
            <div class="dialog_title">
                <h3>Update Status</h3>
                <v-btn color="primary" text @click="userActionPopup =false; initUser(); popupcreateUser = false" class="close-btn">
                    <v-icon>mdi-close</v-icon>
                </v-btn>
            </div>
            <div class="alert_body update_body">
                <template v-if="selectedUser && selectedUser['status']">
                    <h6>Are you sure of inactivating this user?</h6>
                </template>
                <template v-if="selectedUser && !selectedUser['status']">
                    <h6>Are you sure of activating this user again?</h6>
                </template>
                <div class="dialog_actions">
                    <button class="apply-filters" @click="userToggleActivate()" href="javascript:;">
                        <template v-if="selectedUser && selectedUser['status']"><button class="secondary-btn">Inactivate</button></template>
                        <template v-if="selectedUser && !selectedUser['status']"><button class="secondary-btn"> Activate</button></template>
                    </button>

                </div>
            </div>
        </div>

    </v-dialog>
    <!-- <v-snackbar
v-model="snackbar"
:vertical="vertical"
right
        shaped
        top 
>
{{ text }}

<template v-slot:action="{ attrs }">
<v-btn
  color="indigo"
  text
  v-bind="attrs"
  @click="snackbar = false"
>
  Close
</v-btn>
</template>
</v-snackbar> -->
    <snakebar v-if="checkSnackbar" :snackbar="snackbar" :msg="text" :isError="isError" />

</div>
</template>



<script>
//import TheFilter from "./../layouts/components/TheFilter.vue";
import Paginate from 'vuejs-paginate'
import VuePhoneNumberInput from 'vue-phone-number-input';
import menuItems from "@/views/components/menuItems.vue";
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import snakebar from "@/views/components/snakebar.vue";
import Multiselect from "vue-multiselect-inv";

export default {
    components: {
        Multiselect,
        //TheFilter,
        snakebar,
        Paginate,
        //VuePhoneNumberInput,
        menuItems

    },
    methods: {
        //selectedroles
       
        onChange(dt){
             this.filterRoleIds =[];
             this.lodash.forEach(dt ,(item)=>{
                 //alert(item.id);
                  this.filterRoleIds.push(item.id);

             })
            this.getList();
        },

         getUserRole(userRoles =[]){
            if(userRoles.length>0  ){
                let item = userRoles[0];
              //  alert(JSON.stringify(item));
                return item['name'];

            }else{
                return '';
            }
         },
        userToggleActivate() {
            var self = this;
            let payLoad = {
                userId: this.selectedUser['_id'],
                status: this.selectedUser['status'] ? false : true
            };
            this.$store.dispatch("userActivate", payLoad).then((res) => {

                this.userActionPopup = false;
                this.popupcreateUser = false;
                this.userActionPopup = false;
                this.popupcreateUser2 = false;
                //alert(self.userActionPopup)
                this.snackbar = true;
                this.isError = false;
                this.text = res.message; // res.message;

                this.getList();
                this.initUser();

            }).catch((error) => {

                this.popupcreateUser = false;
                this.userActionPopup = false;
                this.popupcreateUser2 = false;
                this.snackbar = true;
                this.isError = false
                this.selectedUser = null;

                this.snackbar = true;
                this.isError = true;
                this.text = error;

            });

        },
        changedPage(numPage) {
            this.page = numPage;
            this.getList();

        },
        initUser() {
            this.snackbar = false;
            this.text = '';
            this.newUser = {
                "firstName": "",
                "middleName": "",
                "lastName": "",
                "name": "",
                "email": "",
                "phoneNo": "",
                "roleId": "4",
                "passType": "leagpass",
                "phoneCode": "",
                "athletes": [],
                "paymentAmt": 0,
                "frequency": "custom",
                startDate: null,
                endDate: null,
            }
            this.text = '';
            this.$validator.reset();
        },
        _getplans() {
            let payLoad = {
                page: 1,
                perpage: 2500
            };
            this.$store.dispatch("subscription/getplans", payLoad).then((res) => {

                this.planslist = res.list;

            })

        },
        createUser() {
            var self = this;
            this.$validator.validateAll().then(result => {
                this.snackbar = false;
                this.isError = false;
                 this.newUser.roleId = 4;
                if(this.newUser.passType =='Free Access'){
                     this.newUser.amount = 0
                     this.newUser.roleId = 5;
                
                }
                if(this.newUser.passType =='Limited Access'){
                     this.newUser.amount = 0
                     this.newUser.roleId = 6;
                
                }
               

                var subscribepayLoad = {
                    selPlanIds: [],
                    plans: [],
                    source: null,
                    serviceTypeId: 1,
                    methodTypeId: 1,
                    newSource: true,
                    subscriber: {
                        name: self.newUser.firstName,
                        email: self.newUser.email,
                        phone: self.newUser.phoneNo,
                        phoneCode: "+1"
                    },
                    today: self.$moment(new Date()).format("YYYY-MM-DD"),
                    timezone: self.$moment.tz.guess(),
                    browserTS: self.$moment(new Date())
                };

                subscribepayLoad.plans.push({
                    planId: "60cd45b3e9f6a817f9df59fd",
                    criteria: {
                        "label": "Athletes",
                        "key": "athletes",
                        "operator": "=",
                        "qty": 1,
                        "amount": null,
                        "dynamicAmount": false,
                        "hasDiscount": false,
                        "discountTypeId": null,
                        "discountAmount": 0,
                        "hasSubCriteria": false,
                        "subCriteria": []
                    },
                    frequencyDays: self.$moment(this.dateRange[0]).diff(self.$moment(this.dateRange[1]), 'days')
                })

                false;

                if (result) {
                    this.$store.dispatch("userCreate", this.newUser).then((res) => {
                        if(this.newUser.passType !='Free Access' && this.newUser.passType !='Limited Access'){
                          this.$store.dispatch("subscription/subscribe", subscribepayLoad).then((res) => {})
                        }

                        this.popupcreateUser = false;
                        this.getList();
                        this.initUser();
                        this.snackbar = false;
                        this.snackbar = true;
                        this.isError = false;
                        this.text = res.message;

                    }).catch((error) => {
                        this.snackbar = false;
                        this.isError = true;
                        this.snackbar = true;
                        this.text = error.message;
                       

                    });
                }

            });

        },

        /**
         * On adding the phone number
         * @param item | Object 
         */
        updatePhoneNumber(item) {
            if (item.isValid) {
                this.newUser.phoneCode = item.countryCallingCode;
                this.newUser.phoneNo = item.nationalNumber;
            }
        },

        UpdateUser(user) {
            this.selectedUser = {
                    password: '',
                    confirmPassword: '',
                    userId: user._id,
                },
                this.popupcreateUser2 = true

        },
        UpdateAction() {
            this.$store.dispatch("updateUserPassword", this.selectedUser).then((res) => {
                this.popupcreateUser2 = false;

                this.getList();
                this.isError = false;
                this.snackbar = true;
                this.text = res.message;

            }).catch((error) => {

                this.isError = true;
                this.snackbar = true;
                this.text = error;

            });

        },

        getList() {
            let path = this.sortKey['path'];
            let order = this.sortKey['order']
            const postData = {

                matcher: {
                    searchString: this.serch_title,
                    roleIds:this.filterRoleIds
                },
                sorting: this.sortKey,
                page: this.page,
                perpage: this.perPage,

            };
            if (this.callFromSort) {
                this.callFromSort = false;
            } else {
                this.loading = true;
                this.callFromSort = false;
                this.list = [];

            }

            this.$store.dispatch("getUsersList", postData).then((response) => {
                    this.list = response['list'];
                    this.totalCount = response.totalCount;
                    this.totalpages = Math.ceil(response.totalCount / this.perPage);
                    this.loading = false;

                })
                .catch((err) => {

                    this.loading = false;
                });
        },
        sortMe(sort_key = "") {
            this.sortKey = {
                "createdOn": -1
            };
            if (sort_key != "") {
                this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
                this.sortKey = {};

                this.sortKey[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1; //sort_key;
                //this.sortKey["order"] = this.sortKeys[sort_key] == 1 ? -1 : 1;
                this.callFromSort = true;
                this.getList();
            }
        },
        onEnter() {
            this.callFromSort = true;
            this.snackbar = false;
            this.getList();
        },
        change_perPage() {
            this.callFromSort = true;
            this.page = 1;
            this.getList();
        },
    },
    data: () => ({
        menu: false,
        modal: false,
        menu2: false,
        slectitems: ['League Pass' ,"Free Access","Limited Access"], //['League Pass' ,'Athlete Pass'], 
        dates: [],
        dateRange: [],
        userActionPopup: false,
        //selectedUser:null,
        actionText: 'activate',
        isError: false,
        snackbar: false,
        text: '',
        vertical: true,

        textType: 'password',
        selectedUser: {
            password: '',
            confirmPassword: '',
            userId: '',
        },
        popupcreateUser: false,
        popupcreateUser2: false,
        newUser: {
            "firstName": "",
            "middleName": "",
            "lastName": "",
            "name": "",
            "email": "",
            "phoneNo": "",
            "roleId": "4",
            "passType": "leagpass",
            "phoneCode": "",
            "athletes": [],
            "paymentAmt": 0,
            "frequency": "custom",
            startDate: null,
            endDate: null,
        },
        perPeges: [25, 50, 75, 100],
        loading: false,
        callFromSort: false,
        serch_title: "",
        disabled: false,
        list: [],
        sortKey: {},
        sortKeys: {
            name: 1,
            email: 1,
            phone: 1,
            createdOn: -1,

        },
        page: 1,
        perPage: 25,
        totalpages: 0,
        totalCount: 0,
        planslist: null,
        usersRoles:[ { "id":1 ,name:"Super Admin"  } ,{ "id":2 ,name:"Admin"  } ,{ "id":3 ,name:"Support"  },{ "id":4 ,name:"Customer"  } , { "id":5 ,"name":"Free Access"}],
        selectedroles:[],
        filterRoleIds:[],
        userRole:null
    }),
    mounted() {
         this.setPageTitle("ProFitX - Users List");
          let userRole = this.$store.state.userRole;
        this.userRole= this.$store.state.userRole;
        this._getplans();
        this.sortKeys = {
            name: 1,
            email: 1,
            phone: 1,
            createdOn: -1,

        }
        this.sortKey = {
            "createdOn": -1
        };
        this.getList();

    },
    computed: {
        closeAllpopups(){
            return false;
        },
        checkSnackbar(){
            return this.snackbar;
        },
        getProfileData() {
            return this.$store.state.user;
        },
        dateRangeTextUser() {
            return this.dateRange.join(' To ')
        },
        dateRangeText() {
            return this.dates.join(' To ')
        },
        checkNewUser() {
            if ((this.newUser['firstName'] == '' || this.newUser['firstName'] == null || this.newUser['firstName'] == undefined)
                //|| (this.newUser['middleName'] =='' || this.newUser['middleName'] ==null || this.newUser['middleName'] ==undefined)
                //|| (this.newUser['lastName'] =='' || this.newUser['lastName'] ==null || this.newUser['lastName'] ==undefined)
                ||
                (this.newUser['email'] == '' || this.newUser['email'] == null || this.newUser['email'] == undefined) ||
                (  this.newUser.passType !='Free Access'   && ( (this.newUser['paymentAmt'] == '' || this.newUser['paymentAmt'] <= 0 || this.newUser['paymentAmt'] == null || this.newUser['paymentAmt'] == undefined)) ||
                (this.dateRange.length < 2 || this.dateRange == null || this.dateRange == undefined))

            ) {
                return true;

            } else {
                return false;

            }

        },
        checkUpdateForm() {
            return this.selectedUser.newPassword == '' || this.selectedUser.confirmPassword != this.selectedUser.newPassword
        }
    }
}
</script>
<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
