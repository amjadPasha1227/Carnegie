<template>
<v-overlay v-if="showoverlay">
    <div class="success_dialogue">
        <div class="success_dialogue_title">
            <h4>{{title}}</h4>
           <v-btn v-if="closebutton" color="primary" text @click="closePopup()" class="close-btn close-btn2">
                <v-icon>mdi-close</v-icon>
            </v-btn>
        </div>
        <div class="success_dialogue_cnt">                         
            <figure>
                <v-icon>mdi-check-decagram-outline</v-icon>  
               <!--  <v-icon>mdi-close-octagon-outline</v-icon>
               <img src="@/assets/images/loading.gif"> -->
            </figure>
            <p>{{description}}</p>
        </div>
    </div>
</v-overlay>
</template>

<script>
export default {
    data() {
        return {};
    },
    props: ['showoverlay',"title","description","closebutton"],
    methods: {
        closePopup(){

                                this.$emit("closePopup")

        }
    },
    mounted() {

    }
}
</script>

<style scoped>
.v-overlay--active{ z-index: 200 !important;}
</style>
