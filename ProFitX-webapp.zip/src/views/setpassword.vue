<template>
<div class="flex w-full bg-img vx-row no-gutter  justify-center login-wrapper" id="page-login">
    <div class="login-support-wrap">
        <div class="login-logo-img" style="margin-top:20px">
            <img width="180" src="@//assets/images/logo.svg" alt="ProFitX" class="login-logo-img">

        </div>
        <form>
             <div class="text-danger text-sm formerrors" v-if="formerrors && formerrors.msg!=''">

                              {{ formerrors.msg }}
                           
                                </div>
                                  <div class="text-success text-sm formerrors" v-if="formmessage && formmessage.msg!=''">

                                        {{ formmessage.msg }}
                                </div>

            <div class="login-inputs">
              <div class="inputbix password">

                    <v-text-field name="password" ref="password" type="password" class="text_field" label="Password" v-validate="'required'" v-model="user.password" single-line outlined></v-text-field>
                         <span class="error-text" v-show="errors.has('password')">{{ errors.first("password") }}</span>

                </div>
  <div class="inputbix password">

                    <v-text-field name="cpassword" data-vv-as="Confirm Password" type="password" class="text_field" label="Confirm Password" v-validate="'required|confirmed:password'" v-model="user.cpassword" single-line outlined></v-text-field>
                    <span class="error-text" v-show="errors.has('cpassword')">{{ errors.first("cpassword") }}</span>

                </div>
              

                <div class="action_btns setpassword_actions">
                    <a class="primary_btn" @click="submitForm()" href="javascript:;">
                        {{invite? 'Update Password': 'Reset Password'}}
                    </a> 
   <router-link v-if="!invite" to="/pricing" class="set_login">

                        <span>   Login  </span>
                      </router-link>
                  
                </div>

            </div>

        </form>

    </div>
</div>
</template>

<script>
export default {
    data() {
        return {
            test: true,
            invite: false,
            user: {
                cpassword: "",
                password: ""
            },
            checkbox_remember_me: false,
            formmessage: {
                msg: ""
            },
            formerrors: {
                msg: ""
            }
        };
    },
    methods: {
        clearfields() {
            Object.assign(this.user, {
                email: "",
                password: ""
            });
        },
        requestAgain() {
            this.$vs.loading();

            const obj = {
                apiKey: "FV$HSE@JUGUUGU$J5L@HE",
                tenantId: "5db7d79d6032453bd060ed9c",
                email: this.user.email
            };

            Object.assign(this.formerrors, {
                msg: ''
            });
            Object.assign(this.formmessage, {
                msg: ''
            });
            this.$store
                .dispatch("petitioner/requestactivationEmail", obj)
                .then(response => {
                    this.$vs.loading.close();
                    Object.assign(this.formerrors, {
                        msg: ''
                    });
                    Object.assign(this.formmessage, {
                        msg: ''
                    });
                    if (response.error) {
                        Object.assign(this.formerrors, {
                            msg: response.error.message
                        });
                    } else {
                        Object.assign(this.formmessage, {
                            msg: response.data.result.message
                        });

                    }
                })
                .catch(() => {});

        },
        submitForm() {
            let _self = this;
             Object.assign(this.formerrors, {
                msg: ''
            });
            Object.assign(this.formmessage, {
                msg: ''
            });
            this.$validator.validateAll().then(result => {
                if (result) {
                    const obj = {
                            pin: this.$route.query.key,
                         "action": "forgot-password", 
                newPassword:this.user.password,
                confirmPassword:this.user.cpassword,
                userId: this.$route.query.userId,
                    };

                    this.$store
                        .dispatch("setpassword", obj)
                        .then(response => {
                            if (response.error) {
                                Object.assign(this.formerrors, {
                                    msg: response.error.message
                                });
                                
                           
                            } else {
                               

                          
                                Object.assign(this.formmessage, {
                                    msg: response.data.result.message
                                });

                                

                                 setTimeout(function () {
                                          _self.$router.push('/athlete-selection');
                                    }, 1000)
                            }
                        })
                        .catch(() => {


                        });

                    // if form have no errors
                } else {
                    // form have errors
                }
            });
        }
    },
     mounted() {

        this.$store.dispatch("logout").then(() => {});
        
        if (this.$route.query.invite || this.$route.query.invite =="true") {
            
            this.invite = this.$route.query.invite
        }



    }
};
</script>
