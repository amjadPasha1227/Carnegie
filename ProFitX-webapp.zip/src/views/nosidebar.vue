<template>
<div>

    nosidebar

</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
