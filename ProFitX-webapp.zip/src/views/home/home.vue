<template>
  <div>
    <oddsSlider></oddsSlider>
    <div class="home_middle_sec">
      <div class="home_middle_cnt" v-bind:class="{ nosidebar: isActive }">
        <div class="home_middle_left">
          <TopPerformer></TopPerformer>
          <fieldGoalPerformance></fieldGoalPerformance>
          <playerPerformance></playerPerformance>
          <profitXrating></profitXrating>
        </div>
        <div class="home_middle_right">
          <span class="hide" v-on:click="makeRed"></span>
          <div class="aboutus">
            <h4>About ProFitX</h4>
            <p>
              ProFitX is committed to creating balance within sports by
              democratizing information and continuing to defy the limits of
              performance and financial analytics. Our innovative technology is
              supported by Artificial Intelligence and allows us to do the hard
              work while you make informed decisions on the fly.
            </p>
            <div class="btns">
              <router-link to="/pricing" class="btn">Subscribe</router-link>
              <a href="/corporate" class="btn">Explore</a>
            </div>
          </div>
          <div class="playerpools_wrap">
            <span class="showall" v-on:click="sidebaropen">View All</span>
            <playerPolls></playerPolls>
          </div>

          <template v-for="(item, ind) in pollsList">
            <pollItem
              v-if="ind <= 1"
              :key="ind"
              :pollItem="item"
              @reloadpollsList="reloadpollsList"
              :loadedFromList="'home'"
            />
          </template>
        </div>
      </div>
    </div>

    <section class="home_articles_sec">
      <articles></articles>
    </section>
  </div>
</template>



<script>
import oddsSlider from "@/views/home/oddsSlider.vue";

import TopPerformer from "@/views/home/TopPerformer.vue";
import fieldGoalPerformance from "@/views/home/fieldGoalPerformance.vue";
import playerPerformance from "@/views/home/playerPerformance.vue";
import profitXrating from "@/views/home/profitXrating.vue";
import articles from "@/views/home/articles.vue";
import playerPolls from "@/views/home/playerPolls.vue";
import moment from "moment";
import pollItem from "@/views/polls/pollItem.vue";

import _ from "lodash";

export default {
  components: {
    oddsSlider,
    TopPerformer,
    fieldGoalPerformance,
    playerPerformance,
    profitXrating,
    articles,
    playerPolls,
    pollItem,
  },
  methods: {
    reloadpollsList() {
      this.getPolsList();
    },

    getPolsList() {
      let _self = this;
      let payLoad = {
        page: _self.page,
        perpage: _self.perPage,
        matcher: {
          typeIds: [1, 2],
          subTypeIds: [],
          statusList: [true, false],
          createdByIds: [],
          createdDateRange: [],
        },
        getForPublish: true,
        getOpinionStats: true,
        timezone: moment.tz.guess(),
        sorting: {
          path: "customId",
          order: -1,
        },
      };
      this.listLoading = true;
      this.$store
        .dispatch("getPolsList", payLoad)
        .then((res) => {
          this.pollsList = _.shuffle(res["list"]);
          this.listLoading = false;
        })
        .catch((err) => {
          this.listLoading = false;
        });
    },

    makeRed: function () {
      this.isActive = !this.isActive;
    },
    sidebaropen: function () {
      this.isActive = !this.isActive;
    },
  },
  data: () => ({
    pollsList: [],
    page: 1,
    perPage: 25,

    isActive: false,
  }),
  mounted() {
    this.reloadpollsList();
  },
  computed: {},
};
</script> 
