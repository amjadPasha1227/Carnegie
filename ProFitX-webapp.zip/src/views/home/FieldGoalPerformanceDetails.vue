<template>

<div>
    <div class="goal_performance-details">
        <div class="details_page_filters">

        </div>
        <div class="performance-details-cnt">       
            <div class="goal_block_wrap" v-for="index in 6" :key="index">      
                <div class="goal_block" >
                    <div class="player_profile">
                        <div class="player_dp">
                            <figure><img src="@/assets/images/player-dp.png"></figure>
                            <span class="teamLogo"><img src="@/assets/images/team_icon-1.png"></span>
                        </div>
                        <div class="player_info">
                            <h4>Stephen Curry</h4>
                            <p>Power Forward</p> 
                            <h6>Field Goal<strong>15</strong><sub>%</sub></h6>
                        </div>
                    </div>
                    <div class="goal_graph">
                        
                    </div>
                </div>
            </div>
                      
        </div>
        <div class="loading-list">
                <figure>
                <img src="@/assets/images/loader.gif" />
                </figure>
                Loading
            </div>
    </div>

 
</div>
</template>



<script>  
  

export default {
    components: {   
    },
    methods: {
        
       
        
    },
    data: () => ({ 
         
    }),
    mounted() {
 

    },
    computed: {
  
    }
}
</script> 
