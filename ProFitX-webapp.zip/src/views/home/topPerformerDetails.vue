<template>
  <div class="top-performer-details">
    <div class="top-performer-content">
      <!-- searchsynergy -->
      <div class="performer_filters">
        <div class="assets-teams" >
          <h2 class="page-title" v-if="currentpagename == 'career-outlook-extend'">Career Outlook - {{playeroutlook.name}}</h2>

          <h2 class="page-title" v-if="currentpage == '/stock-risers'" >Rising Stocks</h2>
          <h2 class="page-title" v-if="currentpage == '/hidden-gems'" >Hidden Gems</h2>
          <h2 class="page-title" v-if="currentpage == '/top-shooters'" >Top Shooters</h2>
          <h2 class="page-title" v-if="currentpage == '/top-performers'" >Top Performers</h2>

        </div>
        <div class="d-flex buttonFilters">
           <div class="assets-teams" v-if="currentpagename != 'career-outlook-extend'">
          <span class="selectlbl"> Duration </span>
          <ul class="tab_buttons">
            <li
              v-bind:class="{ active: combotype == 1 }"
              @click="
                setCombotype(1);
                filterPlayers();
              "
            >
              <a>Last Week</a>
            </li>
            <li
              v-bind:class="{ active: combotype == 2 }"
              @click="
                setCombotype(2);
                filterPlayers();
              "
            >
              <a>Last Three Months</a>
            </li>
            <li
              v-bind:class="{ active: combotype == 3 }"
              @click="
                setCombotype(3);
                filterPlayers();
              "
            >
              <a>Current Season</a>
            </li>
          </ul>
          </div>
        <div class="d-flex align-items-center">
          <div class="assets-teams">
            <div class="assets-teams">
              <span class="selectlbl"> League/Team Filter </span>
              <span>
                <multiselect
                  :select-label="''"
                  deselect-label=""
                  v-model="playerteam"
                  :options="teamsList"
                  :close-on-select="true"
                  @input="filterPlayers"
                  placeholder="Select a Team"
                  label="TEAM_NAME"
                ></multiselect>
              </span>
            </div>
          </div>

          <div class="assets-teams">
            <div class="assets-teams">
              <span class="selectlbl"> Position </span>
              <span>
                <multiselect
                  :select-label="''"
                  deselect-label=""
                  v-model="playerposition"
                  :options="positions"
                  :close-on-select="true"
                  @input="filterPlayers"
                  placeholder="Select a Position"
                  label="name"
                ></multiselect>
              </span>
            </div>
          </div>

          <div class="assets-teams" v-if="currentpagename == 'career-outlook-extend'">
            <span class="selectlbl"> Outlook </span>
            <span>
              <multiselect
                :select-label="''"
                deselect-label=""
                v-model="playeroutlook"
                :options="outlooklist"
                :close-on-select="true"
                @input="filterPlayers"
                placeholder="Select a Role"
                label="name"
              ></multiselect>
            </span>
          </div>

          <div class="assets-teams">
            <span class="selectlbl"> Player Roles </span>
            <span>
              <multiselect
                :select-label="''"
                deselect-label=""
                v-model="playerrole"
                :options="playerroles"
                :close-on-select="true"
                @input="filterPlayers"
                placeholder="Select a Role"
                label="name"
              ></multiselect>
            </span>
          </div>
        </div>
        </div>
      </div>

      <div
        class="top-performer-table"
        v-if="
          currentpage == '/top-performers' ||
          currentpagename == 'career-outlook-extend'
        "
      >
        <v-sheet v-if="isloading" class="pa-3">
          <v-skeleton-loader
            class="mx-auto"
            type="table-row"
          ></v-skeleton-loader>
        </v-sheet>
        <table v-if="!isloading">
          <!-- <thead>
          <tr>
            <th class="text-left">
              Name
            </th>
            <th class="text-left">
              Calories
            </th>
          </tr>
        </thead> -->
          <tbody>
            <template v-for="(player, index) in playerslist">
              <tr :key="index">
                <td>
                  <div class="d-flex align-items-center">
                    <div class="player_dp">
                      <figure>
                        <template v-if="player.PLAYER_IMAGE">
                          <img
                            :src="player.PLAYER_IMAGE"
                            class="align-self-center"
                            :alt="player.PLAYER_NAME"
                          />
                        </template>
                        <template v-else>
                          <img
                            :src="
                              'https://profitx.ai/api/viewfile?path=playerimages/' +
                              player.GPlayerID +
                              '.png'
                            "
                            class="align-self-center"
                            :alt="player.PLAYER_NAME"
                          />
                        </template>
                      </figure>
                      <span class="teamLogo" v-if="player.team"
                        ><img :src="player.team.logo"
                      /></span>
                    </div>
                    <div class="player_info">
                      <h4>{{ player.PLAYER_NAME }}</h4>
                      <p>
                        {{ getposition(player.Position) }} | {{ player.AGE }}yrs
                      </p>
                    </div>
                  </div>
                </td>
                <!-- <td><span class="devider"></span></td> -->
                <td>
                  <div class="player_info">
                    <p v-if="player.ROLES">
                      Top Roles<span>{{ getroles(player.ROLES) }}</span>
                    </p>
                  </div>
                </td>
                <td>
                  <div class="player_info">
                    <h6>
                      ProFitX Ranking<strong>{{ player.RANK }}</strong>
                    </h6>
                  </div>
                </td>
                <td>
                  <div class="player_achievements" v-if="player.RTP">
                    <label>RTP</label>
                    <p>{{ player.RTP.toFixed(0) }}<sub>/100</sub></p>
                    <div class="graph"></div>
                  </div>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>

      <div
        class="top-performer-table"
        v-if="currentpage == '/stock-risers' || currentpage == '/hidden-gems'"
      >
        <v-sheet v-if="isloading" class="pa-3">
          <v-skeleton-loader
            class="mx-auto"
            type="table-row"
          ></v-skeleton-loader>
        </v-sheet>
        <table v-if="!isloading">
          <!-- <thead>
          <tr>
            <th class="text-left">
              Name
            </th>
            <th class="text-left">
              Calories
            </th>
          </tr>
        </thead> -->
          <tbody>
            <template v-for="(player, index) in playerslist">
              <tr :key="index">
                <td>
                  <div class="d-flex align-items-center">
                    <div class="player_dp">
                      <figure>
                        <template v-if="player.PLAYER_IMAGE">
                          <img
                            :src="player.PLAYER_IMAGE"
                            class="align-self-center"
                            :alt="player.PLAYER_NAME"
                          />
                        </template>
                        <template v-else>
                          <img
                            :src="
                              'https://profitx.ai/api/viewfile?path=playerimages/' +
                              player.GPlayerID +
                              '.png'
                            "
                            class="align-self-center"
                            :alt="player.PLAYER_NAME"
                          />
                        </template>
                      </figure>
                      <span class="teamLogo" v-if="player.team"
                        ><img :src="player.team.logo"
                      /></span>
                    </div>
                    <div class="player_info">
                      <h4>{{ player.PLAYER_NAME }}</h4>
                      <p>
                        {{ getposition(player.Position) }} | {{ player.AGE }}yrs
                      </p>
                    </div>
                  </div>
                </td>
                <!-- <td><span class="devider"></span></td> -->
                <td>
                  <div class="player_info">
                    <p v-if="player.ROLES">
                      Top Roles<span>{{ getroles(player.ROLES) }}</span>
                    </p>
                  </div>
                </td>
                <td>
                  <div class="player_info">
                    <h6>
                      ProFitX Ranking<strong>{{ player.RANK }}</strong>
                    </h6>
                  </div>
                </td>
                <td>
                  <div class="player_achievements" v-if="player.RTP">
                    <label>RTP</label>
                    <p>{{ player.RTP.toFixed(0) }}<sub>/100</sub></p>
                    <div class="graph"></div>
                  </div>
                </td>
                <td>
                  <div class="gradient_btn">
                    <span>
                      <img class="up" src="@/assets/images/up_arrow.png" />
                      <!-- <img src="@/assets/images/down_arrow.png"> -->

                      <template v-if="player.MRTCchange">
                        <strong
                          >{{ player.MRTCchange.toFixed(0)
                          }}<sub>%</sub></strong
                        >
                      </template>
                      <template v-if="player.TCchange">
                        <strong
                          >{{ player.TCchange.toFixed(0) }}<sub>%</sub></strong
                        >
                      </template>
                    </span>
                  </div>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>

      <div
        class="goal_performance-details"
        v-if="currentpage == '/top-shooters'"
      >
        <div class="details_page_filters"></div>
        <div class="performance-details-cnt">
          <template v-for="(player, index) in playerslist">
            <div class="goal_block_wrap" :key="index">
              <div class="goal_block">
                <div class="player_profile">
                  <div class="player_dp">
                    <figure>
                      <template v-if="player.PLAYER_IMAGE">
                        <img
                          :src="player.PLAYER_IMAGE"
                          class="align-self-center"
                          :alt="player.PLAYER_NAME"
                        />
                      </template>
                      <template v-else>
                        <img
                          :src="
                            'https://profitx.ai/api/viewfile?path=playerimages/' +
                            player.GPlayerID +
                            '.png'
                          "
                          class="align-self-center"
                          :alt="player.PLAYER_NAME"
                        />
                      </template>
                    </figure>
                    <span class="teamLogo"
                      ><img :src="player.team.logo"
                    /></span>
                  </div>
                  <div class="player_info">
                    <h4>{{ player.PLAYER_NAME }}</h4>
                    <p>{{ getposition(player.Position) }}</p>
                  </div>
                </div>
                <div class="goal_graph" style="position: relative">
                  <figure class="nbacourt">
                    <div class="left3pt">
                      <ul>
                        <li>
                          <span> LEFT 3PT Rating</span
                          ><strong>
                            {{ (player.left3pt * 100).toFixed(0) }}</strong
                          >
                        </li>
                      </ul>
                    </div>

                    <div class="right3pt">
                      <ul>
                        <li>
                          <span> RIGHT 3PT Rating</span
                          ><strong>
                            {{ (player.right3pt * 100).toFixed(0) }}</strong
                          >
                        </li>
                      </ul>
                    </div>

                    <div class="mid3pt">
                      <ul>
                        <li>
                          <span> MIDRANGE Rating</span
                          ><strong>
                            {{ (player.midrange * 100).toFixed(0) }}</strong
                          >
                        </li>
                      </ul>
                    </div>

                    <div class="center3pt">
                      <ul>
                        <li>
                          <span> CENTER 3PT Rating</span
                          ><strong>
                            {{ (player.center3pt * 100).toFixed(0) }}</strong
                          >
                        </li>
                      </ul>
                    </div>
                  </figure>
                  <ul>
                    <li>
                      <span>SharpShooting Rating</span>
                      <strong
                        >{{ (player.ROLES.Sharpshooter * 100).toFixed(0)
                        }}<sub></sub
                      ></strong>
                    </li>
                    <li>
                      <span>3PT%</span>
                      <strong
                        >{{
                          ((player["3PTM"] / player["3PTA"]) * 100)
                            | percent(2)
                        }}<sub></sub
                      ></strong>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </template>
        </div>
        <!-- <div class="loading-list">
                <figure>
                <img src="@/assets/images/loader.gif" />
                </figure>
                Loading
            </div> -->
      </div>
    </div>
  </div>
</template>


<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>

<script>
import teams from "@/data/teams.json";

export default {
  components: {},
  methods: {
    getroles(type) {
      const keys = Object.keys(type);
      var returnvalues = [];
      keys.forEach((key, index) => {
        returnvalues.push({
          k: key,
          v: type[key] * 100,
        });
      });

      var formated = this.lodash.orderBy(returnvalues, ["v"], ["desc"]);

      var finals = "";

      formated.forEach(function (_role, index) {
        if (index <= 2) {
          if (finals != "") {
            finals = finals + " | " + _role["k"];
          } else {
            finals = _role["k"];
          }
        }
      });

      return finals;
    },
    getposition(type) {
      var _p = this.lodash.find(this.positions, function (my) {
        return my.value == type;
      });
      if (_p) return _p.name;
      return "";
    },
    setCombotype(type) {
      this.combotype = type;
    },
    filterPlayers() {
      this.loadPerformers(this.pahed);
    },
    loadPerformers(path) {
      this.pahed = path;
      this.isloading = true;
      var tt;
      var tp;
      if (this.playerteam && this.playerteam.TEAM_NAME) {
        tt = this.playerteam.TEAM_NAME;
      }
      if (this.playerposition && this.playerposition.value) {
        tp = this.playerposition.value;
      }
      this.$store
        .dispatch(path, {
          combotype:this.combotype,
          playerlimit: 50,
          role: this.playerrole,
          position: tp,
          outlook: this.playeroutlook ? this.playeroutlook.value : null,
          playerteam: tt,
        })
        .then((response) => {
          this.playerslist = [];
          this.isloading = false;
          var _games = [];
          if (response && response.length > 0) {
            this.playerslist = response;
          }
        });
    },
  },
  data: () => ({
    isloading: false,
    playerslist: [],
    combotype: 1,
    playerposition: null,
    playerteam: null,
    playerrole: null,
    playeroutlook: null,
    currentpagename: null,
    outlooklist: [
      {
        name: "MVP Candidates",
        value: "MVP CANDIDATE",
      },
      {
        name: "All-NBA",
        value: "ALL NBA",
      },
      {
        name: "All-Stars",
        value: "ALL STAR",
      },
      {
        name: "Impact Starters",
        value: "IMPACT STARTER",
      },
      {
        name: "Starters",
        value: "STARTER",
      },
      {
        name: "Key Reserves",
        value: "KEY RESERVE",
      },
    ],
    playerroles: [
      {
        name: "Sharpshooter",
      },
      {
        name: "Interior Finisher",
      },
      {
        name: "High Volume Scorer",
      },
      {
        name: "Playmaker",
      },
      {
        name: "Versatile Defender",
      },
      {
        name: "Rim Protector",
      },
      {
        name: "Rebounding Specialist",
      },
      {
        name: "Turnover Specialist",
      },
      {
        name: "High Motor",
      },
    ],
    positions: [
      {
        name: "Power Forward",
        value: "F-C",
      },
      {
        name: "Forward",
        value: "F",
      },
      {
        name: "Versatile Center",
        value: "C-F",
      },
      {
        name: "Center",
        value: "C",
      },
      {
        name: "Combo Guard",
        value: "G-F",
      },
      {
        name: "Guard",
        value: "G",
      },
      {
        name: "Wing",
        value: "F-G",
      },
    ],
    teamsList: [],
    siteUrl: null,
    currentpage: null,
    pahed: null,
  }),
  mounted() {
    var _defaultoption = [
      {
        TEAM_ID: 0,
        TEAM_NAME: "Entire League",
        TEAM_ABBREVIATION: "Entire League",
      },
    ];

    _defaultoption = _defaultoption.concat(teams);

    this.teamsList = _defaultoption;
    this.siteUrl = process.env.VUE_APP_API_URL;

    this.currentpage = this.$route.path;
    this.currentpagename = this.$route.name;

    if (this.currentpage == "/top-performers") {
      this.loadPerformers("getTopPerfomers");
    }
    if (this.currentpage == "/top-shooters") {
      this.loadPerformers("getTopshooters");
    }
    if (this.currentpage == "/stock-risers") {
      this.loadPerformers("getStockrisers");
    }
    if (this.currentpage == "/hidden-gems") {
      this.loadPerformers("getHiddengems");
    }
    if (this.currentpage == "/career-outlook/1") {
      this.playeroutlook = {
        name: "MVP Candidates",
        value: "MVP CANDIDATE",
      };
      this.loadPerformers("getoutlookplayers");
    }
        if (this.currentpage == "/career-outlook/2") {
      this.playeroutlook = {
 name:"All-NBA",
 value:"ALL NBA"
};
      this.loadPerformers("getoutlookplayers");
    }      if (this.currentpage == "/career-outlook/3") {
      this.playeroutlook = {
 name:"All-Stars",
 value:"ALL STAR"
};
      this.loadPerformers("getoutlookplayers");
    }
     if (this.currentpage == "/career-outlook/4") {
      this.playeroutlook = {
 name:"Impact Starters",
 value:"IMPACT STARTER"
};
      this.loadPerformers("getoutlookplayers");
    }
         if (this.currentpage == "/career-outlook/5") {
      this.playeroutlook = {
 name:"Starters",
 value:"STARTER"
};
      this.loadPerformers("getoutlookplayers");
    }
  },
  computed: {},
};
</script> 
