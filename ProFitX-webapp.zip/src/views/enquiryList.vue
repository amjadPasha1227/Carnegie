<template>
  <div class="profile_section" @click="snackbar =false">
    <div class="prfile_nav">
      <menuItems/>
    </div>
    <div class="profile_body">

    <div class="action_btns">
      <div class="d-flex align-items-center">
      <input class="search"  v-model="searchtxt"  @keyup="getSupportTickets()" placeholder="Search">
      <div class="range_picker">
        <v-menu
                        ref="menu"
                        v-model="menu"
                        :close-on-content-click="false"
                        
                        transition="scroll-x-transition"
                        offset-y
                        min-width="auto"
                      >
                        <template v-slot:activator="{ on, attrs }">
                          <v-text-field
                            v-model="dateRangeText"
                            label=""
                            placeholder="Select Date Range"
                            prepend-icon="mdi-calendar"
                            readonly
                            v-bind="attrs"
                            v-on="on"

                          ></v-text-field>
                        </template>
                        <v-date-picker
                          v-model="dateRange"
                          :show-current="true"
                          :max="new Date().toISOString()"
                          range
                          no-title
                          scrollable
                        >
                          <v-spacer></v-spacer>
                          <v-btn
                            text
                            color="primary"
                            @click="menu = false;dateRange=[];getSupportTickets()"
                          >
                            Cancel
                          </v-btn>
                          <v-btn
                          :disabled="dateRange.length<2"
                            text
                            color="primary"
                            @click="$refs.menu.save(dateRange);getSupportTickets()"
                          >
                            OK
                          </v-btn>
                        </v-date-picker>
        </v-menu>
      </div>
      </div>
     <!-- <button v-if="dateRange.length>1 || searchtxt !=''" class="primary_btn" @click="getSupportTickets()"> 
          Search
     </button>-->
     
     
    </div>
      <div class="support_table">
        
        <v-simple-table fixed-header height="300px">
          <template v-slot:default>
            <thead>
              <tr>
                <th>                 
                  <span @click="sortMe('name')"  v-bind:class="{'sort_ascending':sortKeys['name']==1, 'sort_descending':sortKeys['name']!=1}">Name</span>
                </th>
                <th>
                  <span @click="sortMe('email')" v-bind:class="{'sort_ascending':sortKeys['email']==1, 'sort_descending':sortKeys['email']!=1}">Email</span>
                </th>
                <th>
                  <span @click="sortMe('phoneNo')"  v-bind:class="{'sort_ascending':sortKeys['phoneNo']==1, 'sort_descending':sortKeys['phoneNo']!=1}">Phone</span>
                 </th>
                 
                <th>
                <span @click="sortMe('createdOn')"  v-bind:class="{'sort_ascending':sortKeys['createdOn']==1, 'sort_descending':sortKeys['createdOn']!=1}">Created On</span>
                
                </th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <template v-if="tickets.length >0">
                <template     v-for="(item, index) in tickets">
                    <tr :key="index" @click="showtr(item, index)">
                    <td>{{item['name']}}</td>
                    <td>{{item['email']}}</td>
                    <td>{{item['phoneNo']}}</td>
                    <td>{{item['createdOn'] | formatDate}}</td>
                    <td class="arrow">
                        <v-icon v-if="item.is_expend">mdi-chevron-up</v-icon>
                        <v-icon v-if="!item.is_expend">mdi-chevron-down</v-icon>
                    </td>
                   </tr>
                   <tr v-if="item.is_expend" :key="index+100000">
                        <td colspan="6" class="expanded">
                          <div class="expanded_cnt">
                            <p>{{item.description}}</p>
                          </div>
                        </td>
                   </tr>
                                  
                </template>
              </template>
              <tr>
                  <td v-if="tickets.length <=0" colspan="6" class="no-data">No Enquiries Found!</td>
                </tr>
            </tbody>
          </template>
        </v-simple-table>
        <div class="pagination_wrap" v-if="tickets.length > 0">
        <paginate           
          v-model="page"
          :page-count="totalpages"
          :page-range="3"
          :margin-pages="2"
          :click-handler="pageNate"
          prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
          next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next"
          :prev-text="'<i></i>'"
          :next-text="'<i></i>'"
          :container-class="'pagination vs-pagination--nav'"
          :page-class="'page-item'"
        ></paginate>
        </div>
      </div>
    </div>
   
    <snakebar v-if="snackbar" :snackbar="snackbar" :msg="snackbarMessage" :isError="isError" />
    
    
            <div class="loading-page" v-if="isloading">
                <figure>
                    <img src="@/assets/images/loader.gif">
                </figure>Loading
            </div>
  </div>
</template>

 

<script>

import moment from "moment";
import _ from "lodash";
import Paginate from "vuejs-paginate";
import menuItems from "@/views/components/menuItems.vue";
import snakebar from "@/views/components/snakebar.vue";
 
export default {
  components: {
    snakebar,
   
    Paginate,
    menuItems
  },
  mounted(){
    this.setPageTitle("ProFitX - Enquiries ");
      this.sortKeys = {
      'name':1,
      "email":1,
      'description':1,
      "createdOn":-1,
      "phoneNo":1
     

    }
    this.sortKey['createdOn'] =-1;
   
    
      
      this.getSupportTickets();
  },
  data() {
    return {

      menu: false,
      modal: false,
      menu2: false,
      dateRange: [],

        isloading:false,
        loaded:false,
        snackbarMessage:'',
        snackbar:false,
        isError:false,
        vertical: true,
      list: [{ is_expend: false }, { is_expend: false }, { is_expend: false }],
      documents: [],
      AddNewTicket: false,
      value: [],
      newTicket: {
        subject: "",
        description: "",
        attachments: [],
        today: moment().format("YYYY-MM-DD"),
      },
      formerrors: {
        msg: "",
      },
      tickets: [],
      sortKeys: {},
      sortKey: {},
      searchtxt: "",
      page: 1,
      perpage: 25,
      totalpages: 0,
      perPeges: [10, 25, 50, 75, 100],
      filter_searchtxt: "",
      all_statusids: [],
      selected_statusids: [],
      final_selected_statusids: [],

      buttoncol: true,
      currentuserRole: null,
      selected_createdDateRange: ["", ""],
      autoApply: "",
      roleId: 0,
      all_user_roles: [],
      users: [],
      selected_user: null,
      assignmrntPopUp: false,
      selected_role: "",

      ticket_comments: [],
      ticket: null,
      selected_ticketId: "",
      selected_ticket_tindex: null,
      CommentPayload: {
        ticketId: "",
        statusId: "",
        description: "",
        attachments: [],
        today: moment().format("YYYY-MM-DD"),
      },
    };
  },
  

  methods: {
      clearFilter(){
          this.dateRange =[];
          this.searchtxt ='';
          this.getSupportTickets();

      },
     
    showtr(item, index) {
        
     this.$validator.reset();
      if (item.is_expend) {
        item.is_expend = false;
      } else {
        item.is_expend = true;
        
      }

      _.forEach(this.tickets,(ticket ,ind)=>{
          if(index !=ind){
               this.tickets[ind]['is_expend'] = false;
          }

       });
    },
    
    
    
    pageNate(pageNum) {
      this.page = pageNum;
      this.getSupportTickets();
    },
    
    
    getSupportTickets() {
      
      let obj = {
        matcher: {
          searchString: this.searchtxt,
          dateRange: [],
        },
        page: this.page,
        perpage: this.perpage,
        sorting: this.sortKey,
      };

      if ( this.dateRange.length >=2) {
        obj["matcher"]["createdDateRange"] = [moment(this.dateRange[0]).format("YYYY-MM-DD") ,moment(this.dateRange[1]).format("YYYY-MM-DD")];
      }

      this.$store
        .dispatch("enquiresList", obj)
        .then((response) => {
          let data = response.list;
          let temp_list = [];
          _.forEach(data, (obj) => {
              obj["is_expend"] = false;
          
             temp_list.push(obj);
          });
          this.tickets = temp_list;
          this.totalpages = Math.ceil(response.totalCount / this.perpage);
        })
        .catch((err) => {
          //alert(err);
          this.tickets = [];
        });
    },
    sortMe(sort_key = "") {
      if (sort_key != "") {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
        this.sortKey = {};
        this.sortKey[sort_key] = this.sortKeys[sort_key];

        localStorage.setItem("tickets_sort_key", sort_key);
        localStorage.setItem("tickets_sort_value", this.sortKey[sort_key]);
        this.getSupportTickets();
      }
    },
    changeperPage() {
      this.page = 1;
      localStorage.setItem("petitions_perpage", this.perpage);
      this.getSupportTickets();
    },
    
    

    
  },
  watch: {
    dateRange: function(val){
      
     // this.getSupportTickets();
    },
    
    searchtxt: function (value) {
      this.getSupportTickets();
    },
  },
   computed: {
     
     getProfileData(){
         return this.$store.state.user;
     },
     dateRangeText () {
        return this.dateRange.join(' To ')
      },
       checkComment(){
          

        if(
        (this.CommentPayload['ticketId'] =='' || this.CommentPayload['ticketId'] ==null || this.CommentPayload['ticketId'] ==undefined)
        || (this.CommentPayload['description'] =='' || this.CommentPayload['description'] ==null || this.CommentPayload['description'] ==undefined)
        //|| (this.CommentPayload['statusId'] =='' || this.CommentPayload['statusId'] ==null || this.CommentPayload['statusId'] ==undefined)
       
       ){
            
            return true;

        }else{
            return false;

        }
       },

     checkNewTicket(){
         //profileData:{ "firstName": "","middleName": "", "lastName": "", "name": "", "email": "", "password": "","phoneNo": "", "roleId": "6"},
        if(
        (this.newTicket['subject'] =='' || this.newTicket['subject'] ==null || this.newTicket['subject'] ==undefined)
        || (this.newTicket['description'] =='' || this.newTicket['description'] ==null || this.newTicket['description'] ==undefined)
       ){
            
            return true;

        }else{
            return false;

        }
        
     },
  }
};
</script>
