<template>
  <div class="player_performance_cnt">
    <div class="performance_block combo_players_wrap">
      <div class="team_title">
        <figure>
          <img :src="gamedata.HomeTeam.logo" />
        </figure>
        <figcaption>
          {{ gamedata.HomeTeam.Name }} Pre-Match Roster Synergy
        </figcaption>
      </div>

      <div class="perfomance_players">
        <div class="player_tabs">
          <ul>
            <li
              @click="
                currentHometab = 1;
                synergyHome(currentHometab);
              "
              v-bind:class="{ active: currentHometab == 1 }"
            >
              <a>Four Player Combo</a>
            </li>
            <li
              @click="
                currentHometab = 2;
                synergyHome(currentHometab);
              "
              v-bind:class="{ active: currentHometab == 2 }"
            >
              <a>Three Player Combo</a>
            </li>
          </ul>
        </div>
        <div class="players_list combo_players">
          <template v-for="(player, index) in hometablist">
            <div class="player" :key="index">
              <div class="player_cnt">
                <figure>
                  <img
                    :src="
                      siteUrl +
                      '/api/viewfile?path=playerimages/sportsdataio/' +
                      player.PlayerID +
                      '.png'
                    "
                  />
                </figure>
                <div class="player_info">
                  <label>{{ player.FirstName }} {{ player.LastName }}</label>
                  <p>{{ getposition(player.Position) }}</p>
                  <p v-if="getroles(player.ROLES) != ''">
                    Top Roles<span> {{ getroles(player.ROLES) }}</span>
                  </p>
                </div>
                <!-- <strong>
                {{ player.FirstName }} {{ player.LastName
                }}<span>{{ player.Position }}</span></strong> -->
              </div>
            </div>
          </template>
        </div>
        <div class="players_list combo_players">
          <template v-for="(player, index) in hometablist2">
            <div class="player" :key="index">
              <div class="player_cnt">
                <figure>
                  <img
                    :src="
                      siteUrl +
                      '/api/viewfile?path=playerimages/sportsdataio/' +
                      player.PlayerID +
                      '.png'
                    "
                  />
                </figure>
                <div class="player_info">
                  <label>{{ player.FirstName }} {{ player.LastName }}</label>
                  <p>{{ getposition(player.Position) }}</p>
                  <p>
                    Top Roles<span>{{ getroles(player.ROLES) }}</span>
                  </p>
                </div>
              </div>
            </div>
          </template>
        </div>
      </div>
    </div>
    <div class="performance_block combo_players_wrap">
      <div class="team_title">
        <figure>
          <img :src="gamedata.AwayTeam.logo" />
        </figure>
        <figcaption>
          {{ gamedata.AwayTeam.Name }} Pre-Match Roster Synergy
        </figcaption>
      </div>
      <div class="perfomance_players">
        <div class="player_tabs">
          <ul>
            <li
              @click="
                currentAwayTab = 1;
                synergyaway(currentAwayTab);
              "
              v-bind:class="{ active: currentAwayTab == 1 }"
            >
              <a>Four Player Combo</a>
            </li>
            <li
              @click="
                currentAwayTab = 2;
                synergyaway(currentAwayTab);
              "
              v-bind:class="{ active: currentAwayTab == 2 }"
            >
              <a>Three Player Combo</a>
            </li>
          </ul>
        </div>
        <div class="players_list combo_players">
          <template v-for="(player, index) in awaytablist">
            <div class="player" :key="index">
              <div class="player_cnt">
                <figure>
                  <img
                    :src="
                      siteUrl +
                      '/api/viewfile?path=playerimages/sportsdataio/' +
                      player.PlayerID +
                      '.png'
                    "
                  />
                </figure>
                <div class="player_info">
                  <label>{{ player.FirstName }} {{ player.LastName }}</label>
                  <p>{{ getposition(player.Position) }}</p>
                  <p>
                    Top Roles<span>{{ getroles(player.ROLES) }}</span>
                  </p>
                </div>
              </div>
            </div>
          </template>
        </div>
        <div class="players_list combo_players">
          <template v-for="(player, index) in awaytablist2">
            <div class="player" :key="index">
              <div class="player_cnt">
                <figure>
                  <img
                    :src="
                      siteUrl +
                      '/api/viewfile?path=playerimages/sportsdataio/' +
                      player.PlayerID +
                      '.png'
                    "
                  />
                </figure>
                <div class="player_info">
                  <label>{{ player.FirstName }} {{ player.LastName }}</label>
                  <p>{{ getposition(player.Position) }}</p>
                  <p>
                    Top Roles<span>{{ getroles(player.ROLES) }}</span>
                  </p>
                </div>
              </div>
            </div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    gamedata: null,
  },
  computed: {},
  methods: {
    synergyHome(currenttab) {
      var _self = this;

      var filteredlineup = _self.lodash.filter(
        this.gamedata.HomeLineup,
        function (player) {
          return true;
         // return player.InjuryStatus == null || player.InjuryStatus == 'Probable';
        }
      );

      var sorteddata = _self.lodash.orderBy(filteredlineup, "Points", "desc");

      var postData = {
        synergyteamteam: this.lodash.map(filteredlineup, "Name"),
        players: [sorteddata[0]["Name"]],
        combooutput: currenttab == 1 ? 3 : 2,
      };
      this.$store
        .dispatch("seacrhSynergy", postData)
        .then((response) => {
          // this.shotsloading = false;
          if (response.error) {
            this.hometablist = [];
          } else {
            var _plist = [];
            var _plist2 = [];
            var selft = this;
            response.data.forEach(function (item) {
              if (item["new_col"]) {
                item["new_col"].push(sorteddata[0]["Name"]);
              } else {
                item["new_col"] = [];
                item["new_col"].push(sorteddata[0]["Name"]);
                if (item.player1) item["new_col"].push(item.player1);
                if (item.player2) item["new_col"].push(item.player2);
                if (item.player3) item["new_col"].push(item.player3);
              }
              if (
                selft.lodash.uniq(item["new_col"]).length ==
                  postData.combooutput + 1 &&
                _plist.length == 0
              ) {
                console.log(_plist);
                _plist = item["new_col"];
                console.log("_plist_plist_plist");
              }
              if (
                item["new_col"] != _plist &&
                selft.lodash.uniq(item["new_col"]).length ==
                  postData.combooutput + 1 &&
                _plist.length > 0 &&
                _plist2.length == 0
              ) {
                _plist2 = item["new_col"];
              }
            });

            this.hometablist = this.lodash.filter(
              this.gamedata.HomeLineup,
              function (o) {
                if ( _plist.indexOf(o.Name) > -1 ){
                  return o;
                }
              }
            );

            this.hometablist2 = this.lodash.filter(
              this.gamedata.HomeLineup,
              function (o) {
                if (
                  _plist2.indexOf(o.Name) > -1 
                )
                  return o;
              }
            );

            console.log(this.hometablist2);
          }
        })
        .catch((err) => {
          // this.shotsloading = false;
          // this.synergyplayers = [];
        });
    },
    getroles(type) {
      if (!type) {
        return "";
      }
      const keys = Object.keys(type);
      var returnvalues = [];
      keys.forEach((key, index) => {
        returnvalues.push({
          k: key,
          v: type[key] * 100,
        });
      });

      var formated = this.lodash.orderBy(returnvalues, ["v"], ["desc"]);

      var finals = "";

      formated.forEach(function (_role, index) {
        if (index <= 2) {
          if (finals != "") {
            finals = finals + " | " + _role["k"];
          } else {
            finals = _role["k"];
          }
        }
      });

      return finals;
    },
    getposition(type) {
      var _p = this.lodash.find(this.positions, function (my) {
        return my.value == type;
      });
      if (_p) return _p.name;
      return type;
    },
    synergyaway(currenttab) {
      var _self = this;

      var filteredlineup = _self.lodash.filter(
        this.gamedata.AwayLineup,
        function (player) {
           return true;
          //return player.InjuryStatus == null || player.InjuryStatus == 'Probable';
        }
      );
      var sorteddata = _self.lodash.orderBy(filteredlineup, "Points", "desc");

      var postData = {
        synergyteamteam: this.lodash.map(filteredlineup, "Name"),
        players: [sorteddata[0]["Name"]],
        combooutput: currenttab == 1 ? 3 : 2,
      };
      this.$store
        .dispatch("seacrhSynergy", postData)
        .then((response) => {
          // this.shotsloading = false;

          if (response.error) {
            this.awaytablist = [];
          } else {
            var _plist = [];
            var _plist2 = [];
            var selft = this;
            response.data.forEach(function (item) {
              if (item["new_col"]) {
                item["new_col"].push(sorteddata[0]["Name"]);
              } else {
                item["new_col"] = [];
                item["new_col"].push(sorteddata[0]["Name"]);
                if (item.player1) item["new_col"].push(item.player1);
                if (item.player2) item["new_col"].push(item.player2);
                if (item.player3) item["new_col"].push(item.player3);
              }
              if (
                selft.lodash.uniq(item["new_col"]).length ==
                  postData.combooutput + 1 &&
                _plist.length == 0
              ) {
                console.log(_plist);
                _plist = item["new_col"];
                console.log("_plist_plist_plist");
              }
              if (
                item["new_col"] != _plist &&
                selft.lodash.uniq(item["new_col"]).length ==
                  postData.combooutput + 1 &&
                _plist.length > 0 &&
                _plist2.length == 0
              ) {
                _plist2 = item["new_col"];
              }
            });

            this.awaytablist = this.lodash.filter(
              this.gamedata.AwayLineup,
              function (o) {
                if (
                  _plist.indexOf(o.Name) > -1 
                )
                  return o;
              }
            );

            this.awaytablist2 = this.lodash.filter(
              this.gamedata.AwayLineup,
              function (o) {
                if (
                  _plist2.indexOf(o.Name) > -1 
                )
                  return o;
              }
            );
          }
        })
        .catch((err) => {
          // this.shotsloading = false;
          // this.synergyplayers = [];
        });
    },
  },
  watch: {},
  mounted() {
    this.synergyHome(this.currentHometab);
    this.synergyaway(this.currentAwayTab);
    this.siteUrl = process.env.VUE_APP_API_URL;
  },
  data() {
    return {
      positions: [
        {
          name: "Power Forward",
          value: "F-C",
        },
        {
          name: "Forward",
          value: "F",
        },
        {
          name: "Versatile Center",
          value: "C-F",
        },
        {
          name: "Center",
          value: "C",
        },
        {
          name: "Combo Guard",
          value: "G-F",
        },
        {
          name: "Guard",
          value: "G",
        },
        {
          name: "Wing",
          value: "F-G",
        },
      ],
      siteUrl: 1,
      currentHometab: 1,
      currentAwayTab: 1,
      hometablist: [],
      awaytablist: [],
      hometablist2: [],
      awaytablist2: [],
    };
  },
};
</script>
