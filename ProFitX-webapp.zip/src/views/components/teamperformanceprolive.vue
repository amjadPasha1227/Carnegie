<template>
  <div class="team_performance_cnt">
    <div class="teams_list">
      <div class="team_block">
        <h4>Head to Head Team Performance</h4>
        <div
          id="pointschartdivprob"
          class="oddschart"
          style="height: 220px"
        ></div>

        <div class="flexbox">
          <div class="team_title">
            <figure>
              <img :src="game.HomeTeam.logo" />
            </figure>
            <figcaption>{{ game.HomeTeam.Name }}</figcaption>
          </div>

          <div class="team_title">
            <figure>
              <img :src="game.AwayTeam.logo" />
            </figure>
            <figcaption>{{ game.AwayTeam.Name }}</figcaption>
          </div>
        </div>
      </div>
      <div class="team_block">
        <h4>Head to Head Offense</h4>

        <div
          id="offencechartdivprob"
          class="oddschart"
          style="height: 220px"
        ></div>

        <div class="flexbox">
          <div class="team_title">
            <figure>
              <img :src="game.HomeTeam.logo" />
            </figure>
            <figcaption>{{ game.HomeTeam.Name }}</figcaption>
          </div>

          <div class="team_title">
            <figure>
              <img :src="game.AwayTeam.logo" />
            </figure>
            <figcaption>{{ game.AwayTeam.Name }}</figcaption>
          </div>
        </div>
      </div>
      <div class="team_block">
        <h4>Head to Head Defense</h4>

        <div
          id="defencechartdivprob"
          class="oddschart"
          style="height: 220px"
        ></div>

        <div class="flexbox">
          <div class="team_title">
            <figure>
              <img :src="game.HomeTeam.logo" />
            </figure>
            <figcaption>{{ game.HomeTeam.Name }}</figcaption>
          </div>

          <div class="team_title">
            <figure>
              <img :src="game.AwayTeam.logo" />
            </figure>
            <figcaption>{{ game.AwayTeam.Name }}</figcaption>
          </div>
        </div>
      </div>
    </div>
    <div class="games_cout">
      <ul>
        <li>(Current Game)</li>
        <li>(Current Game)</li>
        <li>(Current Game)</li>
      </ul>
    </div>
  </div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import teamslist from "./../../data/teams.json";

am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);
var _pointschart;
var _pointschart2;
var _pointschart3;

export default {
  components: {},
  props: {
    game: null,
    gameId: null,
  },
  data: function () {
    return {
      htab: 3,
      firstloading: true,
      timeInterval: "D",
      selecteddates: null,
      shotsloading: false,
      noshots: false,
      tdateperiod: null,
      tselectedvalues: {},

      Prediction: null,
      options: {
        height: "100%",
        size: 5,
      },
      selectedones: ["awayscore", "homescore"],
      tendencies: ["awayscore", "homescore"],
      colors: [],
      tendenciesdata: [],
    };
  },
  beforeDestroy() {
    clearInterval(this.polling);
  },
  methods: {
    pollData() {
      this.polling = setInterval(() => {
        this._getodds();

        //this.$emit("reloadProb",{date:this.dateslist[this.selectedIndex].date,edate:this.dateslist[this.selectedIndex].edate,reload:true})
      }, 36000);
    },
    _drawodds(lineup, htab, chartdiv) {
      var _self = this;
      if (htab == 1) {
        if (_pointschart) _pointschart.dispose();
      }
      if (htab == 2) {
        if (_pointschart2) _pointschart2.dispose();
      }
      if (htab == 3) {
        if (_pointschart3) _pointschart3.dispose();
      }
      setTimeout(function () {
        var data = [];

        var _cd = {};
        _cd.Date = lineup._id;
        
        _cd.awayscore = lineup.LiveProb.awayrtp;
        _cd.homescore = lineup.LiveProb.homertp;

        if (htab == 2) {
          _cd.awayscore = lineup.LiveProb.awayoffrank * 10;
          _cd.homescore = lineup.LiveProb.homeoffrank * 10;
        }

        if (htab == 3) {
          _cd.awayscore = lineup.LiveProb.homedefrank * 10;
          _cd.homescore = lineup.LiveProb.awaydefrank * 10;
        }
        _cd.homescore = _cd.homescore.toFixed(0);

        _cd.awayscore = _cd.awayscore.toFixed(0);
        data.push(_cd)
        let chart = am4core.create(chartdiv, am4charts.XYChart);
        if (htab == 1) {
          _pointschart = chart;
        }
        if (htab == 2) {
          _pointschart2 = chart;
        }
        if (htab == 3) {
          _pointschart2 = chart;
        }
        data = _self.lodash.sortBy(data, "Date");
       
        chart.data = data;

        chart.colors.step = 2;
        var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
        categoryAxis.dataFields.category = "Date";
        categoryAxis.renderer.grid.template.location = 0;
        categoryAxis.renderer.line.strokeOpacity = 1;
        categoryAxis.renderer.minGridDistance = 30;

        categoryAxis.renderer.cellStartLocation = 0.2;
        categoryAxis.renderer.cellEndLocation = 0.8;
        categoryAxis.renderer.labels.template.disabled = true;
        var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
        if (htab == 1) {
          valueAxis.max = 500;
        } 
        valueAxis.min = 0;
           valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
        var series1 = chart.series.push(new am4charts.LineSeries());
        series1.tooltipText = "{name}: {valueY.value}";
 
        series1.name = _self.game.AwayTeam.Name;
        series1.dataFields.categoryX = "Date";
        series1.dataFields.valueY = "awayscore";

        var series2 = chart.series.push(new am4charts.LineSeries());
       // series2.columns.template.width = am4core.percent(100);
        series2.tooltipText = "{name}: {valueY.value}";
        series2.name = _self.game.HomeTeam.Name;
   
        chart.cursor = new am4charts.XYCursor();
categoryAxis.cursorTooltipEnabled = false;

        series2.dataFields.categoryX = "Date";
        series2.dataFields.valueY = "homescore";
      }, 200);
    },
    changeLineup(lineup) {
      this._drawodds(lineup);
    },
    _getodds() {
      this._drawodds(this.game, 1, "pointschartdivprob");
      this._drawodds(this.game, 2, "offencechartdivprob");

      this._drawodds(this.game, 3, "defencechartdivprob");
    },
  },
  watch: {},
  mounted() {
    var self = this;
    this.colors = this.chartcolors;
    this._getodds();
    this.pollData()
  },
};
</script>
