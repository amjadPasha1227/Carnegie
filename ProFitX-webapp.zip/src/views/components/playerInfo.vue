<template>
  <div class="lineup_player" style="cursor: pointer">
    <span class="InjuryStatus" v-if="showinjury && player.InjuryStatus != null">
      {{ player.InjuryStatus }}
    </span>
    <span class="link">
      <!-- <img src="@/assets/images/right-arrow.png" /> -->
    </span>
    <div class="player_info">
      <div class="d-flex align-items-center" style="width: 180px">
        <span
          class="playebg"
          :style="{
            width: '100%',

            height: '100%',
            background: backgroundcolors,
          }"
        >
        </span>
        <figure v-if="player.PlayerID">
          <img
            :src="
              siteUrl +
              '/api/viewfile?path=playerimages/sportsdataio/' +
              player.PlayerID +
              '.png'
            "
          />
        </figure>

        <figcaption>
          {{ player.FirstName }} {{ player.LastName }}
          <span>{{ player.Position }}</span>
        </figcaption>
      </div>
    

      <div class="player_buttons" v-if="showrtc == null">
        <ul>
            <li
            :key="i"
            :class="{ active: activeitem == i }"
            @click="activeitem = i"
          >
            <v-tooltip bottom>
              <template v-slot:activator="{ on, attrs }">
                <a v-bind="attrs" v-on="on" class="player_btn opportunity"></a>
              </template>
              <span>Opportunity</span>
            </v-tooltip>
          </li>
          <li
            :key="i"
            :class="{ active: activeitem == i }"
            @click="activeitem = i"
          >
            <v-tooltip bottom>
              <template v-slot:activator="{ on, attrs }">
                <a
                  v-bind="attrs"
                  v-on="on"
                  class="player_btn PositionVersatility"
                ></a>
              </template>
              <span>Position Versatility</span>
            </v-tooltip>
          </li>
          <li
            :key="i"
            :class="{ active: activeitem == i }"
            @click="activeitem = i"
          >
            <v-tooltip bottom>
              <template v-slot:activator="{ on, attrs }">
                <a v-bind="attrs" v-on="on" class="player_btn tendencies"></a>
              </template>
              <span>Career Outlook</span>
            </v-tooltip>
          </li>
         
        </ul>
      </div>
    </div>
    <div class="yyd" style="margin-right: 50px">
      <div
        v-if="
          showrtc != null && player.realtime50k && player.realtime50k.length > 0
        "
        class="team-contract"
      >
        <ul   @mouseover="
                                _drawperformance(
                                  'contract_graph' + player.PlayerID,
                                  player.realtime50k
                                );
                                _drawrtc(
                                  'contract_graphm' + player.PlayerID,
                                 player.realtime60k
                                );
                              " >
          <li class="team_blue">
            <v-chip>
              <v-avatar>50K</v-avatar>
              {{ player.realtime50k[0]["RTM"] | currency }}
            </v-chip>
          </li>

          <li class="team_green">
            <v-chip>
              <v-avatar>60K</v-avatar>
              {{ player.realtime60k[0]["RTM"] | currency }}
            </v-chip>
          </li>
        </ul>

            <div class="contract_details_wrap">
                              <div
                                class="contract_details contract_performance"
                              >
                                <div
                                  class="ct_details_header"
                               
                                >
                                  <h4>50K Contract Trajectory - Past 10 Games</h4>
                               
                                </div>
                                <div class="contract_graph axixcolors">
                                  <div
                                    :id="'contract_graph' + player.PlayerID"
                                    style="height: 210px; margin-top: 20px"
                                    class="performancegraph"
                                  ></div>

                                  <div class="ct_details_header">
                                    <h4>60K Contract Trajectory - Past 10 Games</h4>
                                    <div></div>
                                  </div>

                                  <div
                                    :id="'contract_graphm' + player.PlayerID"
                                    style="height: 210px; margin-top: 20px"
                                    class="performancegraph"
                                  ></div>
                                </div>
                              </div>
                            </div>

      </div>
    </div>
    <div class="player_status" v-if="live"></div>
  </div>
</template>

<script>
import _ from "lodash";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);
import moment from "moment";


var _performancechart;
var _performancecharta;
export default {
  components: {},
    methods: {
_drawrtc(id, ndata) {
      var _self = this;
      if (_performancecharta) _performancecharta.dispose();

      var chart = am4core.create(id, am4charts.XYChart);
      _performancecharta = chart;
      // The following would work as well:
      // var chart = am4core.create("chartdiv", "XYChart");

      var results = ndata;
      var data = [];

      results.forEach((d, index) => {
        var _cd = {};
        _cd["date"] = moment(d["date"]).format("MMM, DD");
        _cd["RTM"] = d["RTM"].toFixed(2);
        data.push(_cd);
      });

      // Add Data
      chart.data = data.reverse();

      // Add category axis
      var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
      categoryAxis.dataFields.category = "date";
      categoryAxis.renderer.grid.template.location = 0;
      categoryAxis.renderer.minGridDistance = 5;
      categoryAxis.renderer.labels.template.horizontalCenter = "right";
      categoryAxis.renderer.labels.template.verticalCenter = "middle";
      categoryAxis.renderer.labels.template.rotation = 270;
      // Add value axis
      let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
      valueAxis.fillOpacity = 0.6;
      valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
      // Add series
      var series = chart.series.push(new am4charts.LineSeries());
      series.dataFields.categoryX = "date";
      series.dataFields.valueY = "RTM";
      series.stroke = am4core.color("green");
      series.strokeWidth = 4;
      categoryAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
    },
    _drawperformance(id, ndata) {
      var _self = this;
      if (_performancechart) _performancechart.dispose();

      var chart = am4core.create(id, am4charts.XYChart);
      _performancechart = chart;
      // The following would work as well:
      // var chart = am4core.create("chartdiv", "XYChart");

      var results = ndata;
      var data = [];

      results.forEach((d, index) => {
        var _cd = {};
        _cd["date"] = moment(d["date"]).format("MMM, DD");
         _cd["RTM"] = d["RTM"].toFixed(2);
        data.push(_cd);
      });

      // Add Data
      chart.data = data.reverse();

      // Add category axis
      var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
      categoryAxis.dataFields.category = "date";
      categoryAxis.renderer.grid.template.location = 0;
      categoryAxis.renderer.minGridDistance = 5;
      categoryAxis.renderer.labels.template.horizontalCenter = "right";
      categoryAxis.renderer.labels.template.verticalCenter = "middle";
      categoryAxis.renderer.labels.template.rotation = 270;
      // Add value axis
      let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
      valueAxis.fillOpacity = 0.6;

      valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
      // Add series
      var series = chart.series.push(new am4charts.LineSeries());
      series.dataFields.categoryX = "date";
      series.dataFields.valueY = "RTM";
      series.stroke = am4core.color("green");
      series.strokeWidth = 4;

    
      categoryAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
    },

    },
  watch: {
    PlayerGames: {
      handler: function () {
        let st = _.find(this.PlayerGames, { Name: this.player.Name });
        if (st) {
          this.playerscore = st;
        }
      },
      deep: true,
    },
  },
  props: {
    backgroundcolors: null,
    live: null,
    PlayerGames: null,
    showinjury: null,
    player: null,
    siteUrl: null,
    showrtc: null,
  },

  data() {
    return {
      activeitem: 1,
      playerscore: null,
      injured: false,
      mlive: false,
    };
  },
};
</script>

