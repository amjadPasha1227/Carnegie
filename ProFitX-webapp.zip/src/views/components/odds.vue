<template>
  <div>
    <div class="widget_block dark-sheet">
      <v-sheet v-if="shotsloading" class="pa-3">
        <v-skeleton-loader class="mx-auto" type="table-row"></v-skeleton-loader>
        <v-skeleton-loader class="mx-auto" type="table-row"></v-skeleton-loader>
        <v-skeleton-loader class="mx-auto" type="table-row"></v-skeleton-loader>
      </v-sheet>

      <div class="widget_body flex-direction-column oddschartwidget_wrap">
        <div class="d-flex oddschartwidget">
          <div class="tendencies_graph_wrap" style="width: 100%">
            <div class="tendencies_graph" style="padding-bottom: 20px">
              <div id="starsystemchartdiv" class="oddschart"></div>
              <div
                id="pointschartdiv"
                style="height: 250px; margin-top: -50px"
                class="oddschart"
              ></div>
              <div class="graph_devisions" v-if="!shotsloading">
                <ul>
                  <li>1</li>
                  <li>2</li>
                  <li>3</li>
                  <li>4</li>
                  <li>5</li>
                  <li>6</li>
                  <li>7</li>
                  <li>8</li>
                  <li>9</li>
                  <li>10</li>
                  <li>11</li>
                  <li>12</li>
                  <li>13</li>
                  <li>14</li>
                  <li>15</li>
                  <li>16</li>
                  <li>17</li>
                  <li>18</li>
                  <li>19</li>
                  <li>20</li>
                  <li>21</li>
                  <li>22</li>
                  <li>23</li>
                  <li>24</li>
                  <li>25</li>
                  <li>26</li>
                  <li>27</li>
                  <li>28</li>
                  <li>29</li>
                  <li>30</li>
                  <li>31</li>
                  <li>32</li>
                  <li>33</li>
                  <li>34</li>
                  <li>35</li>
                  <li>36</li>
                  <li>37</li>
                  <li>38</li>
                  <li>39</li>
                  <li>40</li>
                  <li>41</li>
                  <li>42</li>
                  <li>43</li>
                  <li>44</li>
                  <li>45</li>
                  <li>46</li>
                  <li>47</li>
                  <li>48</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import teamslist from "./../../data/teams.json";

am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);
var _starsystemchart, _pointschart;
export default {
  name: "odds",
  components: {},
  props: {
    game: null,
    gameId: null,
  },
  data: function () {
    return {
      firstloading: true,
      timeInterval: "D",
      selecteddates: null,
      shotsloading: false,
      noshots: false,
      tdateperiod: null,
      tselectedvalues: {},

      Prediction: null,
      options: {
        height: "100%",
        size: 5,
      },
      selectedones: ["awayscore", "homescore"],
      tendencies: ["awayscore", "homescore"],
      colors: [],
      tendenciesdata: [],
    };
  },

  beforeDestroy() {
    clearInterval(this.polling);
  },
  methods: {
    pollData() {
      this.polling = setInterval(() => {
        this._getodds();

        //this.$emit("reloadProb",{date:this.dateslist[this.selectedIndex].date,edate:this.dateslist[this.selectedIndex].edate,reload:true})
      }, 36000);
    },
    _drawodds() {
      var _self = this;
      if (_starsystemchart) {
        var aresults = _self.Prediction;
        var adata = [];
        var aranges = [];
        aresults.forEach((ad, index) => {
          var _cd = {};
          var d = ad.Prediction;
          if (d["gamedate"] != null) {
            if (aranges.length == 0) {
              aranges.push(new Date(d.gamedate + "T00:12:00"));
              aranges.push(new Date(d.gamedate + "T00:24:00"));
              aranges.push(new Date(d.gamedate + "T00:36:00"));
              aranges.push(new Date(d.gamedate + "T00:48:00"));
            }

            var coeff = 1000 * 60 * 1;

            var pdate = new Date(d.gamedate + "T" + d.elapsed).getTime();
            _cd.Date = new Date(Math.round(pdate / coeff) * coeff);
            _cd.awayscore = (d.away_win_pct * 100).toFixed(1);
            _cd.elapsed = d.elapsed;
            _cd.homescore = (d.home_win_pct * 100).toFixed(1);
            adata.push(_cd);
          }
        });

        // Create chart instance
        adata = _self.lodash.sortBy(adata, "Date");

        _starsystemchart.data = adata;

        _starsystemchart.data;
        _starsystemchart.invalidateRawData();
        return;
      }

      //_starsystemchart.dispose();
      setTimeout(function () {
        var results = _self.Prediction;
        var data = [];
        var ranges = [];
        var startdata;
        var edata;
        results.forEach((ad, index) => {
          var _cd = {};
          var d = ad.Prediction;
          if (d["gamedate"] != null) {
            if (ranges.length == 0) {
              ranges.push(new Date(d.gamedate + "T00:12:00"));
              ranges.push(new Date(d.gamedate + "T00:24:00"));
              ranges.push(new Date(d.gamedate + "T00:36:00"));
              ranges.push(new Date(d.gamedate + "T00:48:00"));
            }
            startdata = new Date(d.gamedate + "T00:00:00");
            edata = new Date(d.gamedate + "T00:48:00").getTime();
            var coeff = 1000 * 60 * 1;

            var pdate = new Date(d.gamedate + "T" + d.elapsed).getTime();
            _cd.Date = new Date(Math.round(pdate / coeff) * coeff);

            _cd.awayscore = (d.away_win_pct * 100).toFixed(1);
            _cd.elapsed = d.elapsed;
            _cd.homescore = (d.home_win_pct * 100).toFixed(1);
            data.push(_cd);
          }
        });

        // Create chart instance
        let chart = am4core.create("starsystemchartdiv", am4charts.XYChart);
        _starsystemchart = chart;
        data = _self.lodash.sortBy(data, "Date");
        chart.zoomOutButton.disabled = true;

        chart.data = data;
        chart.paddingTop = 30;
        chart.svgContainer.autoResize = false;
        chart.preloader.background.fill = am4core.color("#000000");
        chart.preloader.background.fillOpacity = 0.1;
        let dateAxis = chart.xAxes.push(new am4charts.DateAxis());
        dateAxis.renderer.grid.template.percentWidth = 25;
        dateAxis.fillOpacity = 0;
        dateAxis.max = edata;
        dateAxis.maxColumns = 4;
        dateAxis.baseInterval.timeUnit = "minute";
        dateAxis.baseInterval.count = 1;

        let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
        valueAxis.fillOpacity = 0.6;
        valueAxis.max = 100;
        valueAxis.min = 0;
        valueAxis.renderer.labels.template.marginLeft = 0;
        valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
        valueAxis.renderer.labels.template.fillOpacity = 0.6;
        var teamseries;
        var playerseries;
        var _colors = ["#FF9C00", "#038EAB"];
        var _types = _self.tendencies;

        valueAxis.renderer.grid.template.strokeWidth = 0;
        dateAxis.renderer.grid.template.strokeWidth = 0;
        chart.background.fill = "#0f0";
        chart.background.opacity = 0;

        teamseries = chart.series.push(new am4charts.ColumnSeries());
        teamseries.dataFields.valueY = "awayscore";
        teamseries.dataFields.dateX = "Date";
        teamseries.columns.template.fill = am4core.color(
          "#" + _self.game.AwayTeam.PrimaryColor
        );
        teamseries.columns.template.fillOpacity = 0.1;
        let hover = teamseries.columns.template.states.create("hover");
        hover.properties.fill = am4core.color(
          "#" + _self.game.AwayTeam.PrimaryColor
        );
        hover.properties.fillOpacity = 1;

        teamseries.stacked = true;
        teamseries.strokeWidth = 0;
        teamseries.columns.template.width = am4core.percent(65);
        playerseries = chart.series.push(new am4charts.ColumnSeries());
        playerseries.dataFields.valueY = "homescore";
        playerseries.dataFields.dateX = "Date";
        playerseries.columns.template.fill = am4core.color(
          "#" + _self.game.HomeTeam.PrimaryColor
        );
        playerseries.columns.template.fillOpacity = 0.1;
        let ahover = playerseries.columns.template.states.create("hover");
        ahover.properties.fillOpacity = 1;

        playerseries.stacked = true;
        playerseries.columns.template.width = am4core.percent(65);
        playerseries.strokeWidth = 0;
        var ttip = `<div class='graph_tooltip'>`;
        ttip =
          ttip +
          `<figure>
                <img src="` +
          _self.game.AwayTeam.logo +
          `">
                <figcaption class="winning">
                    <b>{awayscore}%</b>
                </figcaption>  
              </figure>
              <figure>
                <img src="` +
          _self.game.HomeTeam.logo +
          `">
                <figcaption class="losing">
                    <b>{homescore}%</b>
                </figcaption>  
              </figure>`;
        ttip = ttip + `</div>`;

        playerseries.tooltipHTML =
          `<div class="roleslist_tooltips " ><div>` + ttip + `</div></div>`;
        playerseries.tooltip.pointerOrientation = "horizontal";
        playerseries.tooltip.background.strokeWidth = 0;
        playerseries.tooltip.getFillFromObject = false;
        playerseries.tooltip.background.fill = am4core.color("#11172B");
        playerseries.tooltip.background.fillOpacity = 0.7;



        chart.events.on("ready", function (ev) {
          valueAxis.min = valueAxis.minZoomed;
          valueAxis.max = valueAxis.maxZoomed;
        });
        //chart.cursor.behavior = "none";

        chart.cursor = new am4charts.XYCursor();
      }, 200);
    },
    _drawpoints() {
      var _self = this;

      if (_pointschart) {
        var aresults = _self.Prediction;
        var adata = [];
        var aranges = [];
        aresults.forEach((ad, index) => {
          var _cd = {};
          var d = ad.Prediction;
          if (d["gamedate"] != null) {
            if (aranges.length == 0) {
              aranges.push(new Date(d.gamedate + "T00:12:00"));
              aranges.push(new Date(d.gamedate + "T00:24:00"));
              aranges.push(new Date(d.gamedate + "T00:36:00"));
              aranges.push(new Date(d.gamedate + "T00:48:00"));
            }

            var coeff = 1000 * 60 * 1;

            var pdate = new Date(d.gamedate + "T" + d.elapsed).getTime();
            _cd.Date = new Date(Math.round(pdate / coeff) * coeff);

            let dt = _self.lodash.find(adata, {
              Date: _cd.Date,
            });
            _cd.awayscore = d.away_score;
            _cd.elapsed = d.elapsed;
            _cd.homescore = d.home_score;
            if (!dt) adata.push(_cd);
          }
        });

        // Create chart instance
        adata = _self.lodash.sortBy(adata, "Date");

        _pointschart.data = adata;

        _pointschart.data;
        _pointschart.invalidateRawData();
        return;
      }

      setTimeout(function () {
        var results = _self.Prediction;
        var data = [];
        var ranges = [];
        var startdata;
        var edata;
        results.forEach((ad, index) => {
          var _cd = {};
          var d = ad.Prediction;
          if (d["gamedate"] != null) {
            if (ranges.length == 0) {
              ranges.push(new Date(d.gamedate + "T00:12:00"));
              ranges.push(new Date(d.gamedate + "T00:24:00"));
              ranges.push(new Date(d.gamedate + "T00:36:00"));
              ranges.push(new Date(d.gamedate + "T00:48:00"));
            }
            startdata = new Date(d.gamedate + "T00:00:00");
            edata = new Date(d.gamedate + "T00:48:00").getTime();

            var coeff = 1000 * 60 * 1;

            var pdate = new Date(d.gamedate + "T" + d.elapsed).getTime();
            _cd.Date = new Date(Math.round(pdate / coeff) * coeff);

            let dt = _self.lodash.find(data, {
              Date: _cd.Date,
            });

            _cd.awayscore = d.away_score;
            _cd.elapsed = d.elapsed;
            _cd.homescore = d.home_score;
            if (!dt) data.push(_cd);
          }
        });

        // Create chart instance
        let chart = am4core.create("pointschartdiv", am4charts.XYChart);
        _pointschart = chart;
        data = _self.lodash.sortBy(data, "Date");

        chart.data = data;
        chart.paddingTop = 30;
        chart.svgContainer.autoResize = false;
        chart.preloader.background.fill = am4core.color("#000000");
        chart.preloader.background.fillOpacity = 0.1;
        let dateAxis = chart.xAxes.push(new am4charts.DateAxis());
        dateAxis.renderer.labels.template.fillOpacity = 0;
        dateAxis.baseInterval.timeUnit = "minute";
        dateAxis.baseInterval.count = 1;
        dateAxis.max = edata;
        chart.background.fillOpacity = 0;

        dateAxis.renderer.labels.template.disabled = true;
        dateAxis.renderer.labels.template.fillOpacity = 0;

        let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
        valueAxis.fillOpacity = 0.6;

        valueAxis.renderer.labels.template.marginLeft = 0;

        valueAxis.renderer.labels.template.marginLeft = 0;
        valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
        valueAxis.renderer.labels.template.fillOpacity = 0.6;

        dateAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
        dateAxis.renderer.labels.template.fillOpacity = 0.6;

        valueAxis.renderer.grid.template.strokeWidth = 0;
        dateAxis.renderer.grid.template.strokeWidth = 0;
        chart.background.fill = "#0f0";
        chart.background.opacity = 0;

        var teamseries;
        var playerseries;
        var _colors = ["#FF9C00", "#038EAB"];
        var _types = _self.tendencies;

        teamseries = chart.series.push(new am4charts.LineSeries());
        teamseries.dataFields.valueY = "awayscore";
        teamseries.dataFields.dateX = "Date";
        teamseries.stroke = am4core.color(
          "#" + _self.game.AwayTeam.PrimaryColor
        );

        teamseries.strokeWidth = 3;
        teamseries.connect = true;
        var bullet = teamseries.bullets.push(new am4charts.Bullet());
        var square = bullet.createChild(am4core.Circle);
        square.width = 5;
        square.fill = am4core.color("#" + _self.game.AwayTeam.PrimaryColor);
        square.height = 5;
        square.horizontalCenter = "middle";
        square.verticalCenter = "middle";

        playerseries = chart.series.push(new am4charts.LineSeries());
        playerseries.dataFields.valueY = "homescore";
        playerseries.dataFields.dateX = "Date";
        playerseries.connect = true;
        playerseries.stroke = am4core.color(
          "#" + _self.game.HomeTeam.PrimaryColor
        );

        playerseries.strokeWidth = 3;

        var bulletp = playerseries.bullets.push(new am4charts.Bullet());
        var squarep = bulletp.createChild(am4core.Circle);
        squarep.fill = am4core.color("#" + _self.game.HomeTeam.PrimaryColor);

        squarep.width = 5;
        squarep.height = 5;
        squarep.horizontalCenter = "middle";
        squarep.verticalCenter = "middle";

        var ttip = `<div class='graph_tooltip'>`;
        ttip =
          ttip +
          `<figure>
                <img src="` +
          _self.game.AwayTeam.logo +
          `">
                <figcaption class="winning">
                    <b>{awayscore}</b>
                </figcaption>  
              </figure>
              <figure>
                <img src="` +
          _self.game.HomeTeam.logo +
          `">
                <figcaption class="losing">
                    <b>{homescore}</b>
                </figcaption>  
              </figure>`;
        ttip = ttip + `</div>`;

        playerseries.tooltipHTML =
          `<div class="roleslist_tooltips " ><div>` + ttip + `</div></div>`;
        playerseries.tooltip.pointerOrientation = "horizontal";
        playerseries.tooltip.background.strokeWidth = 0;
        playerseries.tooltip.getFillFromObject = false;
        playerseries.tooltip.background.fill = am4core.color("#11172B");
        playerseries.tooltip.background.fillOpacity = 0.7;

        chart.events.on("ready", function (ev) {
          valueAxis.min = valueAxis.minZoomed;
          valueAxis.max = valueAxis.maxZoomed;
        });
        _self.shotsloading = false;

        chart.cursor = new am4charts.XYCursor();
      }, 200);
    },
    _showhideline(_index) {
      let series = _starsystemchart.series.getIndex(_index);
      if (series.isHiding || series.isHidden) {
        series.show();
      } else {
        series.hide();
      }
    },
    _getodds() {
      this.noshots = false;
      var self = this;
      var postdata = {
        gameId: this.gameId,
      };
      this.$store.dispatch("getodds", postdata).then((response) => {
        this.Prediction = response;

        this._drawodds();
        this._drawpoints();
      });
    },
  },
  watch: {},
  mounted() {
    var self = this;
    this.colors = this.chartcolors;
    this.shotsloading = true;

    this._getodds();
    this.pollData();
  },
};
</script>
