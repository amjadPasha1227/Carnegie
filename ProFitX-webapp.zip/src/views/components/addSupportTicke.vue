<template>
<div @click="snackbar =false" class="report_sec">

<button class="primary_btn reportbtn" @click="initNewComment()"> 
  Report an Issue
</button> 


<v-dialog
      v-model="AddNewTicket"
      max-width="400"
      class="card_dialog" fullscreen
      persistent
    >
      <div class="dialog_body report_cnt">
        <div class="dialog_head">
          <h4>Report an Issue</h4>
          <v-btn
            color="primary"
            text
            @click="AddNewTicket = false"
            class="close-btn"
          >
            <v-icon>mdi-close</v-icon>
          </v-btn>
        </div>
        <div class="form_section">
          <form v-on:submit.prevent>
          
          <div class="row" v-if="formerrors.msg">
              <div class="col">
                <div class="form-group">
                 <span class="form_error-text"> {{formerrors.msg}}</span>
                 </div>
              </div>
            </div>
          <!--
            <div class="row">
              <div class="col">
                <div class="form-group">
                  <label class="form_label">Ticket ID</label>
                  <input type="text" class="form_control" />
                 </div>
              </div>
            </div>-->
            <div class="row">
              <div class="col">
                <div class="form-group">
                  <label class="form_label">Title</label>
                  <input type="text" class="form_control" v-model="newTicket.subject"  name="subject" v-validate="'required'"  data-vv-as="Title"  />
                  <span class="error-text" v-show="errors.has('subject')">{{ errors.first("subject") }}</span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col">
                <div class="form-group">
                  <label class="form_label">Comments</label>
                  <textarea type="text" class="form_control" name="description" data-vv-as="Description" v-model="newTicket.description" v-validate="'required'"></textarea>
                  <span class="error-text" v-show="errors.has('description')">{{ errors.first("description") }}</span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col">
                <div class="upload-group" @click="documents = []">
                  <!-- <label class="form_label">Files</label> -->
                   <file-upload
                      v-model="documents"
                      class="file-upload-input"
                      accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      :name="'Documents'+index" 
                      :multiple="true"
                      data-vv-as=" documents"
                      @input="upload(documents ,'newTicke')"
                      
                    >
                      <span @click="documents = []"
                        ><v-icon>mdi-paperclip</v-icon>Upload
                        Attachments</span
                      >
                    </file-upload>
                    <figure class="file_loader"  v-if="isloading" >
                    <img src="@/assets/images/loading.gif">
                  </figure>
                    <ul class="uploded_list">
                      <li v-for="(attachment, ai) in newTicket.attachments" :key="ai" 
                       @click="remove(attachment, newTicket.attachments , ai)"
                       >
                       <!-- {{attachment.name}} -->
                          <figure>
                          <img src="@/assets/images/image.svg" />
                          </figure>
                          <figcaption>{{checkProperty( attachment,'name')}}</figcaption>
                          <span><v-icon>mdi-close</v-icon></span>
                       </li>
                    </ul>
                </div>
              </div>
            </div>
            <div class="dialog_actions">
            
              <button
               :disabled="checkNewTicket || isloading"
                class="primary_btn w-100"
                href="javascript:;"
                @click="supportTicketsCreate()"
              >
                Submit
              </button>
              
            </div>
             
 
          </form>
        </div>
      </div>
</v-dialog>


<snakebar v-if="snackbar" :snackbar="snackbar" :msg="snackbarMessage" :isError="isError" />


    <!--<div class="loading-page" v-if="isloading">
        <figure>
            <img src="@/assets/images/loader.gif">
        </figure>Loading
    </div>-->


</div>

</template>
<script>
import FileUpload from "vue-upload-component/src";
import moment from "moment";
import _ from "lodash";
import Paginate from "vuejs-paginate";
import snakebar from "@/views/components/snakebar.vue";
 
export default {
  components: {
    snakebar,
    FileUpload,
   
  },
  mounted(){
     
  },
  data() {
    return {

     

        isloading:false,
        loaded:false,
        snackbarMessage:'',
        snackbar:false,
        isError:false,
        vertical: true,
       documents: [],
       AddNewTicket: false,
      
      newTicket: {
        subject: "",
        description: "",
        attachments: [],
        today: moment().format("YYYY-MM-DD"),
      },
      formerrors: {
        msg: "",
      }
    } 

  },
  

  methods: {
      changedtickedStatus(statusId ,index ,item){
          let sid = this.tickets[index].selectedStatusId
          let st = _.find(this.all_statusids ,{"_id":statusId});
          if(this.tickets[index]["statusId"] !=1 && sid ==1){
            this.tickets[index]['selectedStatusId']  = this.tickets[index]["statusId"];
            item['selectedStatusId'] = this.tickets[index]["statusId"];
          }
        
      },
      initNewComment(){
          this.documents =[];
          this.snackbarMessage = '';
          this.isError =false;
          this.AddNewTicket = true,
          this.formerrors.msg='';
          this.newTicket = {
            subject: "",
            description: "",
            attachments: [],
            today: moment().format("YYYY-MM-DD"),
          }
        this.$validator.reset();
      },
   
    upload(files, type = "") {
      let model = _.cloneDeep(files);
      this.documents =[];
      var _current = this;
      //this.$vs.loading();
      this.isloading =false;
      this.isloading =true;
      let formData = new FormData();

      let tempFiles = [];
      let tempFilesNames =[];
      if (model.length > 0) {
        model.forEach((doc, index) => {
          
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          formData.append("getDetails", true);

          this.$store.dispatch("uploadS3File", formData).then((response) => {
            response.data.result.forEach((urlGenerated) => {
              doc.url = urlGenerated;
              delete doc.file;
              let temp_file = urlGenerated;

              tempFiles.push(temp_file);
              let fl = {
                name: temp_file["name"],
                url: temp_file["path"],
                mimetype: temp_file["mimetype"],
              };
              if(tempFilesNames.indexOf(temp_file["name"]) <=-1){
                    
                    
                  if(type == 'newTicke') {
                    this.newTicket.attachments.push(fl);
                  }


              }
              tempFilesNames.push(temp_file["name"]);

              
              if (tempFiles.length >= model.length) {
               // _current.$vs.loading.close();
                this.isloading =true;
                 this.isloading =false;
                

              }
            });
          });
        });
      }
      //  model.splice(0, mapper.length, ...mapper);
    },
    remove(item, data, filindex) {
      data.splice(filindex, 1);
    },

   
    getSupportTickets() {
      //  "title": "INTK-TK",
      //             "statusIds": [1, 2, 4],
      //             "assignedToIds": ["5de4a68f3f265070080ad945"],
      //             "createdByIds": ["5de4f0957573e61e381688ea"],

      let obj = {
        matcher: {
          title: this.searchtxt,
          statusIds: this.final_selected_statusids,
          assignedToIds: [],
          createdByIds: [],
          dateRange: [],
        },
        page: this.page,
        perpage: this.perpage,
        sortKeys: this.sortKey,
      };

      if ( this.dateRange.length >=2) {
        obj["matcher"]["dateRange"] = [moment(this.dateRange[0]).format("YYYY-MM-DD") ,moment(this.dateRange[1]).format("YYYY-MM-DD")];
      }

      this.$store
        .dispatch("supportTicketsList", obj)
        .then((response) => {
          let data = response.list;
          let temp_list = [];
          _.forEach(data, (obj) => {
            //obj['statusDetails'] =null; 
            obj['selectedStatusId'] = obj['statusId'];
            obj["is_expend"] = false;
            obj["all_comments"] = [];
            temp_list.push(obj);
          });
          this.tickets = temp_list;
          this.totalpages = Math.ceil(response.totalCount / this.perpage);
        })
        .catch((err) => {
          //alert(err);
          this.tickets = [];
        });
    },
    sortMe(sort_key = "") {
      if (sort_key != "") {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
        this.sortKey = {};
        this.sortKey[sort_key] = this.sortKeys[sort_key];

        localStorage.setItem("tickets_sort_key", sort_key);
        localStorage.setItem("tickets_sort_value", this.sortKey[sort_key]);
        this.getSupportTickets();
      }
    },
    changeperPage() {
      this.page = 1;
      localStorage.setItem("petitions_perpage", this.perpage);
      this.getSupportTickets();
    },
    resetNewTicket() {
      this.AddBeneficiary = false;
      this.newTicket = {
        subject: "",
        description: "",
        attachments: [],
        today: moment().format("YYYY-MM-DD"),
      };
      this.$validator.reset();
    },
    supportTicketsCreate() {
      this.$store
        .dispatch("supportTicketsCreate", this.newTicket)
        .then((response) => {
          this.AddNewTicket = false;
          this.snackbarMessage  = response.message
          this.snackbar = true;
          this.isError =false;
          this.getSupportTickets();
        })
        .catch((err) => {
          //alert(JSON.stringify(err));
          this.formerrors.msg = err;
        
        });
    },
  
    
    
  },
  watch: {
    
  },
   computed: {
     checkLoading(){
       return this.isLoading;
     },
       getProfileData(){
         return this.$store.state.user;
     },
     
     
     checkNewTicket(){
         //profileData:{ "firstName": "","middleName": "", "lastName": "", "name": "", "email": "", "password": "","phoneNo": "", "roleId": "6"},
        if(
        (this.newTicket['subject'] =='' || this.newTicket['subject'] ==null || this.newTicket['subject'] ==undefined)
        || (this.newTicket['description'] =='' || this.newTicket['description'] ==null || this.newTicket['description'] ==undefined)
       ){
            
            return true;

        }else{
            return false;

        }
        
     },
  }
};
</script>