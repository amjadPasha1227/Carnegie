<template>
  <div style="position: relative">
    <div class="widget_block profit_widget">
      <div class="widget_title" style="z-index: 111">
        <h3>
          Contract Analysis

          <v-tooltip bottom>
            <template v-slot:activator="{ on, attrs }">
              <v-btn class="info_btn" v-bind="attrs" v-on="on">
                <v-icon>mdi-information-outline</v-icon>
              </v-btn>
            </template>
            <span>
              <div style="width: 450px">
                <p>
                  This model will display 5 seasons of team and real-time
                  contract value for the athlete and projections for next two
                  seasons with HI-LOW range.
                </p>
                <p>
                  Dynamic AI Projections for decisions on Team Options, Player
                  Options, Non-Guaranteed Contracts, and Qualifying Offers
                  located in player contract.
                </p>
                <p>
                  Dynamic AI Projections on athlete contracts with a range of
                  1-3 years.
                </p>
                <p>
                  Displays projected free agent class by real-time contract
                  value, position, and free agency year.
                </p>
              </div>
            </span>
          </v-tooltip>
        </h3>
      </div>
      <div class="widget_body" style="height: auto">
        <div class="profit_status">
          <ul class="profit-agent-items">
            <li class="agent">Free Agent</li>
            <li class="earnings">Team Contract</li>
            <li class="projected">Real-Time Contract</li>
            <li class="projected2">Fair Market Value</li>
          </ul>
        </div>
        <div class="yearsFlexwrap">
          <div class="shotsloading" v-if="shotsloading">
            <img src="@/assets/images/shotsloading.svg" />
          </div>

          <div id="contractchart" class="timeserieschart"></div>

          <div class="commentorylist"></div>
        </div>

        <!--  -->
      </div>

      <div class="agents_widget">
        <v-row>
          <v-col cols="12">
            <div class="performer contractperformer topranksliderwrap">
              <div class="toppinck">
                <div class="sblock" style="max-width: 140px" v-if="player.RTC">
                  <h3>Team ROI</h3>
                  <div
                    class="carrer_info carrer_up"
                    v-bind:class="{
                      carrer_up: getPercentageChange(player.RTC, player.TC) > 0,
                      carrer_down:
                        getPercentageChange(player.RTC, player.TC) < 0,
                    }"
                  >
                    <label
                      >{{ getPercentageChange(player.RTC, player.TC) }} %</label
                    >
                    <span></span>
                  </div>

                  <!-- <span><v-icon>mdi-menu-up</v-icon></span> -->
                </div>

                <div class="sblock" style="max-width: 140px" v-if="player.FA">
                  <h3>Free Agency Year</h3>

                  <label>{{ player.FA }}</label>
                </div>

                <div class="sblock" v-if="player.PO">
                  <h3>Player Option - {{ player.PO }}</h3>

                  <label>
                    {{ POA }}
                    <span style="padding-left: 10px">
                      {{ POAV | currency }}
                    </span>
                  </label>
                </div>

                <div class="sblock" v-if="player.TO">
                  <h3>Team Option - {{ player.TO }}</h3>
                  <label>
                    {{ TOA }}
                    <span style="padding-left: 20px">
                      {{ TOAV | currency }}
                    </span>
                  </label>
                </div>

                <div class="sblock" v-if="QOA">
                  <h3>Qualifying Offer - {{ player.QO }}</h3>

                  <label>
                    {{ QOA }}
                    <span style="padding-left: 20px">
                      {{ QOAV | currency }}
                    </span>
                  </label>
                </div>

                <div class="sblock" v-if="RQOA">
                  <h3>Restricted Free Agency - {{ player.QO }}</h3>

                  <label>
                    {{ RQOA
                    }}<span style="padding-left: 20px">{{
                      QOAV | currency
                    }}</span>
                  </label>
                </div>

                <div class="sblock" v-if="player.NG">
                  <h3>Non-Guaranteed - {{ player.NG }}</h3>

                  <label>
                    {{ NGA }}
                    <span style="padding-left: 20px">
                      {{ NGAV | currency }}
                    </span>
                  </label>
                </div>
              </div>
            </div>
          </v-col>
        </v-row>
        <v-row>
          <v-col cols="9">
            <div class="performer contractperformer topranksliderwrap">
              <div class="agents_slider">
                <h3>Top Free Agents - {{ player.FA }}</h3>

                <div class="toprankslider">
                  <div class="slider_navigation" v-if="top5picks.length > 5">
                    <div class="swiper-button-prev">
                      <span class="icon-play-flip"></span>
                    </div>
                    <div class="swiper-button-next">
                      <span class="icon-play"></span>
                    </div>
                  </div>
                </div>
                <div class="performer_list_wrap" v-if="top5picks.length > 5">
                  <swiper ref="awesomeSwiperA" :options="swiperOption">
                    <swiper-slide
                      :key="index"
                      v-for="(player, index) in top5picks"
                    >
                      <div class="performer_list" :key="index">
                        <div class="performance_details">
                          <label
                            ><small>
                              {{ player.playerDetails.RTC | currency }}</small
                            ></label
                          >
                        </div>
                        <div
                          class="performance_data"
                          style="height: 100px"
                        ></div>
                        <div class="performer">
                          <figure v-if="player.goalserveDetails[0]">
                            <img
                              :src="
                                'https://profitx.ai/api/viewfile?path=playerimages/' +
                                player.goalserveDetails[0].PlayerID +
                                '.png'
                              "
                              class="align-self-center"
                              :alt="player.PLAYER_NAME"
                            />
                          </figure>
                          <span v-if="player.goalserveDetails[0]">
                            <img
                              :src="
                                'https://profitx.ai/api/viewfile?path=teams/' +
                                player.goalserveDetails[0].TeamID +
                                '.png'
                              "
                            />
                          </span>
                        </div>
                        <label>{{ player.PLAYER_NAME }}</label>
                      </div>
                    </swiper-slide>
                  </swiper>
                </div>
                <div
                  class="performer_list_wrap altswrap"
                  v-if="top5picks.length <= 5"
                >
                  <div
                    class="performer_list"
                    v-for="(player, index) in top5picks"
                    :key="index"
                  >
                    <div class="performance_details">
                      <label
                        ><small>
                          {{ player.playerDetails.RTC | currency }}</small
                        ></label
                      >
                    </div>
                    <div class="performance_data" style="height: 100px"></div>
                    <div class="performer">
                      <figure>
                        <img
                          :src="
                            'https://profitx.ai/api/viewfile?path=playerimages/' +
                            player.goalserveDetails[0].PlayerID +
                            '.png'
                          "
                          class="align-self-center"
                          :alt="player.PLAYER_NAME"
                        />
                      </figure>
                      <span>
                        <img
                          :src="
                            'https://profitx.ai/api/viewfile?path=teams/' +
                            player.goalserveDetails[0].TeamID +
                            '.png'
                          "
                        />
                      </span>
                    </div>
                    <label>{{ player.PLAYER_NAME }}</label>
                  </div>
                </div>
              </div>
            </div>
          </v-col>

          <v-col cols="3">
            <div class="contractProjections">
              <h3>Contract Projections</h3>
              <div class="projBlock_wrap">
                <div class="projBlock" v-if="oneyear">
                  <span>1 Year</span>
                  <h2>{{ oneyear | currency }}</h2>
                </div>

                <div class="projBlock" v-if="twoyear">
                  <span>2 Year</span>
                  <h2>{{ twoyear | currency }}</h2>
                </div>

                <div class="projBlock" v-if="threeyear">
                  <span>3 Year</span>
                  <h2>{{ threeyear | currency }}</h2>
                </div>
              </div>
            </div>
          </v-col>
        </v-row>
      </div>
    </div>

    <div class="widget_block profit_widget">
      <div class="widget_title" style="z-index: 111">
        <h3 style="text-transform: uppercase">
          Real-Time Contract Performance
        </h3>
      </div>
      <div class="widget_body" style="height: auto">
        <div id="attributeschartdiv" class="timeserieschartattributes22"></div>
      </div>
    </div>
  </div>
</template>

<script>
import moment from "moment";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);
import "swiper/dist/css/swiper.css";
var _attributeschart;

import { swiper, swiperSlide } from "vue-awesome-swiper";

export default {
  components: {
    swiper,
    swiperSlide,
  },
  props: {
    player: {},
  },
  data: () => ({
    shotsloading: false,
    swiperOption: {
      slidesPerView: 5,
      spaceBetween: 10,
      pagination: {
        el: ".swiper-pagination",
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
        // nextEl: this.$el.querySelector('.swiper-button-next'),
        // prevEl: this.$el.querySelector('.swiper-button-prev')
      },
    },
    commentory: null,
    commentorylist: null,
    oneyear: null,
    twoyear: null,
    threeyear: null,
    outlook: [],
    selectedvaluesout: [],
    pioffensive: true,
    pidefensive: false,
    impactdata: [],
    top5picks: [],
    colors: null,
    POA: null,
    TOA: null,
    QOA: null,
    RQOA: null,
    NGA: null,
    POAV: null,
    TOAV: null,
    QOAV: null,
    NGAV: null,
    indexdata: null,
    attributes: ["Real-Time Contract", "Team Contract"],
    selectedonesa: ["Real-Time Contract", "Team Contract"],
  }),
  filters: {
    roundme: function (value) {
      if (!value) return "";
      value = value.toFixed(0);
      return value;
    },
  },
  methods: {
    getPercentageChange(a, b) {
      var rt = ((a - b) * 100) / b;
      return rt.toFixed(2);
    },
    gettop5picks() {
      this.$store
        .dispatch("top5picks", {
          FA: this.player.FA,
          POSITION: this.player.POSITION,
          PLAYER_NAME: this.player.PLAYER_NAME,
          PLAYER_ID: this.player.PLAYER_ID,
        })
        .then((response) => {
          this.top5picks = response.data.data;
        });
    },

    _setSeason(startDate, endDate, dateAxis, color, title, opacity) {
      let offrange = dateAxis.axisRanges.create();

      offrange.date = new Date(startDate);
      offrange.endDate = new Date(endDate);
      offrange.axisFill.fill = am4core.color(color);
      offrange.axisFill.fillOpacity = opacity;

      offrange.label.inside = true;
      offrange.label.text = title;
      offrange.label.textAlign = "end";
      offrange.label.height = 310;
      offrange.label.rotation = 270;
      offrange.label.dy = -125;
      offrange.label.dx = -5;
      offrange.label.adapter.add("horizontalCenter", function () {
        return "middle";
      });
      offrange.label.fill = am4core.color("#000");

      offrange.label.fontFamily = "rajdhanisemibold";
    },
    _drawindex() {
      var _self = this;
      if (_attributeschart) _attributeschart.dispose();
      setTimeout(function () {
        var results = _self.lodash.sortBy(_self.indexdata, "Date");
        var data = [];

        results.forEach((d, index) => {
          var _cd = {};
          _cd.Date = new Date(d.Date);
          var _season = moment(new Date(d.Date)).format("YYYY");
          _season = parseInt(_season) - 1 + "-" + _season;
          var seasosntc = _self.lodash.find(_self.impactdata, function (my) {
            return my.SEASON == _season;
          });
          _self.selectedonesa.forEach(function (_role) {
            if (_role == "Team Contract") {
              if (seasosntc && seasosntc["TC"] > 0)
                _cd["Team Contract"] = +parseInt(seasosntc["TC"]);
            } else {
              _cd["Real-Time Contract"] = +d["RTM"].toFixed(2);
            }
          });

          data.push(_cd);
        });

        _attributeschart = am4core.create(
          "attributeschartdiv",
          am4charts.XYChart
        );
        //_attributeschart = chart;
        data = _self.lodash.sortBy(data, "Date");
        _attributeschart.data = data;
        _attributeschart.preloader.background.fill = am4core.color("#000000");
        _attributeschart.preloader.background.fillOpacity = 0.1;
        _attributeschart.svgContainer.autoResize = false;
        let dateAxis = _attributeschart.xAxes.push(new am4charts.DateAxis());
        dateAxis.renderer.grid.template.location = 0;
        dateAxis.renderer.minGridDistance = 60;
        dateAxis.fillOpacity = 0.6;
        let valueAxis = _attributeschart.yAxes.push(new am4charts.ValueAxis());
        valueAxis.fillOpacity = 0.6;
        valueAxis.maxY = 10;
        valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");

        var series;
        var _colors = _self.colors;
        var _types = _self.attributes;
        var _tipseries;

        var ttip = `<ul>`;
        _self.selectedonesa.forEach(function (_role, index) {
          series = _attributeschart.series.push(new am4charts.LineSeries());
          series.dataFields.valueY = _role;
          series.dataFields.dateX = "Date";
          var sindex = _self.attributes.indexOf(_role);
          series.stroke = am4core.color(_colors[sindex]);
          series.connect = true;
          series.strokeWidth = 2;
          ttip =
            ttip +
            `<li class='aaaaval1{` +
            _role +
            `}'><em style='background:` +
            _colors[sindex] +
            `'></em> <span>` +
            _role +
            `: {` +
            _role +
            `}</span></li>`;

          if (index == 0) {
            _tipseries = series;
          }
        });

        ttip = ttip + `</ul>`;
        _tipseries.tooltipHTML =
          `<div class="roleslist_tooltips " ><div><div style="color:#ffffff" class="dateperiod">{dateX.formatDate("MMM d, yyyy")}</div>` +
          ttip +
          `</div></div>`;
        _tipseries.tooltip.pointerOrientation = "horizontal";
        _tipseries.tooltip.background.strokeWidth = 0;
        _tipseries.tooltip.getFillFromObject = false;
        _tipseries.tooltip.background.fill = am4core.color("#11172B");
        _tipseries.tooltip.background.fillOpacity = 0.7;
        _attributeschart.events.on("ready", function (ev) {
          // valueAxis.min = valueAxis.minZoomed;
          //   valueAxis.max = valueAxis.maxZoomed;
        });

        for (var i = 2009; i < 2023; i++) {
          var _sdate = i + "-09-30";
          var _edate = i + 1 + "-05-30";

          let range = dateAxis.axisRanges.create();

          range.date = new Date(_sdate);
          range.endDate = new Date(_edate);
          range.axisFill.fill = am4core.color("#8790b1cc");
          range.axisFill.fillOpacity = 0.4;
        }

        for (var ix = 2009; ix < 2023; ix++) {
          let _sdate = ix + "-06-01";
          let _edate = ix + 1 + "08-30";

          let offrange = dateAxis.axisRanges.create();

          offrange.date = new Date(_sdate);
          offrange.endDate = new Date(_edate);
          offrange.axisFill.fill = am4core.color("#000000");
          offrange.axisFill.fillOpacity = 1;

          offrange.label.inside = true;
          offrange.label.text = "Offseason";
          offrange.label.textAlign = "end";
          offrange.label.height = 310;
          offrange.label.rotation = 270;
          offrange.label.dy = -195;
          offrange.label.dx = -5;
          offrange.label.adapter.add("horizontalCenter", function () {
            return "middle";
          });
          offrange.label.fill = am4core.color("#7484a1cc");

          offrange.label.fontFamily = "rajdhanisemibold";
        }

        /* PLAY OFFS */
        _self._setSeason(
          "2010-04-17",
          "2010-06-17",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );
        _self._setSeason(
          "2011-04-16",
          "2011-06-12",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );
        _self._setSeason(
          "2012-04-28",
          "2012-06-21",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );
        _self._setSeason(
          "2013-04-20",
          "2013-06-20",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );
        _self._setSeason(
          "2014-04-19",
          "2014-06-15",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );
        _self._setSeason(
          "2015-04-18",
          "2015-06-16",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );

        _self._setSeason(
          "2016-04-16",
          "2016-06-19",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );

        _self._setSeason(
          "2017-04-15",
          "2017-06-12",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );
        _self._setSeason(
          "2018-04-15",
          "2018-06-12",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );
        _self._setSeason(
          "2018-04-14",
          "2018-06-08",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );
        _self._setSeason(
          "2019-04-13",
          "2019-06-12",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );
        _self._setSeason(
          "2020-08-17",
          "2020-10-30",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );
        _self._setSeason(
          "2021-05-22",
          "2021-07-30",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );
        _self._setSeason(
          "2022-04-16",
          "2022-06-16",
          dateAxis,
          "#8790b1",
          "PLAYOFFS",
          1
        );

        dateAxis.renderer.labels.template.textAlign = "middle";
        dateAxis.dateFormats.setKey("month", "MMM-yy");

        _attributeschart.scrollbarX = new am4core.Scrollbar();
        _attributeschart.scrollbarX.parent =
          _attributeschart.bottomAxesContainer;
        _attributeschart.zoomOutButton.disabled = true;

        _attributeschart.scrollbarX.stroke = am4core.color("#3F4C76");
        _attributeschart.scrollbarX.strokeOpacity = 0.6;
        _attributeschart.scrollbarX.background.fill = am4core.color("#3F4C76");
        _attributeschart.scrollbarX.background.fillOpacity = 0.6;
        _attributeschart.scrollbarX.startGrip.background.fill =
          am4core.color("#3F4C76");
        _attributeschart.scrollbarX.endGrip.background.fill =
          am4core.color("#3F4C76");

        _attributeschart.cursor = new am4charts.XYCursor();
      }, 150);
    },
    _getrealtimeindex() {
      this.noshots = false;
      this.shotsloading = true;
      var self = this;
      var postdata = {
        timeInterval: this.timeInterval,
        type: "Attributes",
        startdate: moment()
          .subtract(this.impactdata.length, "years")
          .startOf("year")
          .format("YYYY-MM-DD"),
        player: this.player.PLAYER_NAME,
      };
      this.$store.dispatch("getRealtimeindex", postdata).then((response) => {
        var results = JSON.parse(response.data);

        if (results.length > 0) {
          this.shotsloading = false;
          this.indexdata = results;

          this._drawindex();
        } else {
          this.shotsloading = false;
          this.noshots = true;
        }
      });
    },
    getprofitimpact() {
      var d3 = window.d3;
      this.isloading = true;
      var self = this;
      this.serach = {
        page: 1,
        perpage: 5,
        matcher: {
          playerId: this.player.PLAYER_NAME,
        },
      };

      this.shotsloading = true;
      // this.commentory = commentory;
      this.shotsloading = false;

      this.$store.dispatch("getProfitImpact", this.serach).then((response) => {
        if (response.error) {
          Object.assign(this.formerrors, {
            msg: response.error.message,
          });
        } else {
          this.totalCount = response.data.result.totalCount;
          this.impactdata = response.data.result.list;
          this._getrealtimeindex();

          var data = [
            {
              name: "Actual Earnings",
              values: [],
            },
            {
              name: "Projected Earnings",
              values: [],
            },
          ];

          var age = [
            {
              name: "Age",
              values: [],
            },
          ];

          var p = 0;
          var _hr = 0;

          var routlook = [];
          var freeagentYear = "280000";
          if (self.player.FA) {
            freeagentYear = self.player.FA.toString();
          }

          this.impactdata.forEach(function (ide) {
            var _cs = parseInt(ide.SEASON.split("-")[1]);

            if (
              p == 0 &&
              ide.projectionDetails &&
              ide.projectionDetails.PR.length > 0
            ) {
              data[1].values.push({
                date: (_cs + 2).toString(),
                season: "2023-2024",
                price: ide.projectionDetails.PR[1].V.toFixed(2),
                U: ide.projectionDetails.PR[1].U.toFixed(2),
                L: ide.projectionDetails.PR[1].L.toFixed(2),
              });
              _hr = ide.projectionDetails.PR[1].U;
              data[1].values.push({
                date: (_cs + 1).toString(),
                season: "2022-2023",
                price: ide.projectionDetails.PR[0].V.toFixed(2),
                U: ide.projectionDetails.PR[0].U.toFixed(2),
                L: ide.projectionDetails.PR[0].L.toFixed(2),
              });

              if (self.player["2023-2024"]) {
                data[0].values.push({
                  season: "2023-2024",
                  date: (_cs + 2).toString(),
                  price: self.player["2023-2024"],
                  U: self.player["2023-2024"],
                  L: self.player["2023-2024"],
                });
              } else {
                data[0].values.push({
                  season: "2023-2024",
                  date: (_cs + 2).toString(),
                  price: ide.TC,
                  U: ide.TC,
                  L: ide.TC,
                });
              }

              if (self.player["2022-2023"]) {
                data[0].values.push({
                  date: (_cs + 1).toString(),
                  season: "2022-2023",
                  price: self.player["2022-2023"],
                  U: self.player["2022-2023"],
                  L: self.player["2022-2023"],
                });
              } else {
                data[0].values.push({
                  date: (_cs + 1).toString(),
                  season: "2022-2023",
                  price: self.player["2022-2023"],
                  U: self.player["2022-2023"],
                  L: self.player["2022-2023"],
                });
              }
              age[0].values.push({
                date: (_cs + 2).toString(),
                age: ide.AGE + 2,
              });

              age[0].values.push({
                date: (_cs + 1).toString(),
                age: ide.AGE + 1,
              });

              if (ide.outlook) routlook.push(ide.outlook.OUTLOOK);
              if (ide.outlook) routlook.push(ide.outlook.OUTLOOK);
            }

            if (ide.outlook) routlook.push(ide.outlook.OUTLOOK);
            data[0].values.push({
              date: _cs.toString(),
              season: ide.SEASON,
              price: ide.TC,
              U: ide.TC,
              L: ide.TC,
            });
            data[1].values.push({
              date: _cs.toString(),
              season: ide.SEASON,
              price: ide.RTC,
              U: ide.RTC,
              L: ide.RTC,
            });
            age[0].values.push({
              date: _cs.toString(),
              age: ide.AGE,
            });

            p++;
          });

          var _dt = routlook.reverse();

          if (_dt.length > 0) {
            var _t = _dt[_dt.length - 1];
            _dt.push(_t);
            var _at = _dt[_dt.length - 1];
            _dt.push(_at);
            var _aat = _dt[_dt.length - 1];
            _dt.push(_aat);
          }

          this.outlook = routlook.reverse();

          var _hrtc = this.lodash.maxBy(data[1].values, "price").price;
          var _htc = this.lodash.maxBy(data[0].values, "price").price;
          if (_hrtc < _htc) _hrtc = _htc;
          if (_hr > _hrtc) _hrtc = _hr;

          var _mrtc = this.lodash.minBy(data[1].values, "price").price;
          var _mtc = this.lodash.minBy(data[0].values, "price").price;
          if (_mrtc > _mtc) _mrtc = _mtc;

          /* Format Data */
          var parseDate = d3.timeParse("%Y");
          var ndats = [];
          data[0].values.forEach(function (d, index) {
            var _currentseason,
              _cta = parseInt(moment(d.date).format("Y"));

            _cta = _cta - 1;
            _currentseason = _currentseason - 1 + "-" + _currentseason;

            _currentseason = d.season;

            var _n = 0;
            var indexerpt = 0;
            if (index == 0) {
              indexerpt = 1;
            }
            if (index == 1) {
              indexerpt = 2;
            }

            var _ct = self.lodash.find(self.commentory, function (ao) {
              return ao.year == _cta;
            });

            if (
              parseInt(moment(d.date).format("Y")) > parseInt(freeagentYear)
            ) {
              ndats.push({
                linecolor: am4core.color("#47A01A"),
                dotcolor: am4core.color("#47A01A"),
                category: _currentseason,
                rtc: 0,
                rcu: 0,
                comment: _ct ? _ct.comment : "",
                indexer: index,
                indexerp: indexerpt,
                rcl: 0,
                ageimpact: 0,
                freeagent: _n,
              });
            } else {
              ndats.push({
                linecolor: am4core.color("#47A01A"),
                dotcolor: am4core.color("#47A01A"),
                category: _currentseason,
                tc: d.price,
                tcu: d.U,
                tcl: d.L,
                comment: _ct ? _ct.comment : "",
                indexer: index,
                indexerp: indexerpt,
                rtc: 0,
                rcu: 0,
                rcl: 0,
                ageimpact: 0,
                freeagent: _n,
              });
            }
          });
          this.commentorylist = ndats;
          var leapranges = [];

          data[1].values.forEach(function (d, index) {
            if (index == 0) {
              ndats[index]["linecolor"] = am4core.color("#fac126");
              ndats[index]["dotcolor"] = am4core.color("#fac126");
            }
            if (index == 1) {
              ndats[index]["linecolor"] = am4core.color("#fac126");
              ndats[index]["dotcolor"] = am4core.color("#fac126");
            }
            if (index == 2) {
              ndats[index]["linecolor"] = am4core.color("#fac126");
              ndats[index]["dotcolor"] = am4core.color("#47A01A");
            }

            ndats[index]["rtc"] = Math.round(d.price).toFixed(0);
            ndats[index]["rcu"] = Math.round(d.U).toFixed(0);
            ndats[index]["rcl"] = Math.round(d.L).toFixed(0);
          });

          var _oneyear = parseInt(data[1].values[0].price);
          var _twoyear =
            parseInt(data[1].values[0].price) +
            parseInt(data[1].values[1].price);
          var _threeyear =
            parseInt(data[1].values[0].price) +
            parseInt(data[1].values[1].price) +
            parseInt(data[1].values[1].price);
          ndats = ndats.reverse();

          ndats.forEach(function (d, index) {
            if (d.category.includes(freeagentYear + "-")) {
              ndats[index]["freeagent"] = _hrtc;
              delete ndats[index]["tc"];
            }

            if (ndats[index]["tc"] == 0) {
              delete ndats[index]["tc"];
            }

            var ageimpact = (d.rtc / d.rtc - 1) * 100;
            if (index > 0) {
              ageimpact = (d.rtc / ndats[index - 1].rtc - 1) * 100;
            }
            ndats[index]["ageimpact"] = ageimpact;

            var percDiff =
              (100 * (ndats[index]["rtc"] - ndats[index]["tc"])) /
              ((ndats[index]["rtc"] + ndats[index]["tc"]) / 2);
            if (percDiff > 60) {
              if (ndats[index - 1] && ndats[index - 1]["category"]) {
                if (
                  ndats[index]["category"] != "2017-2018" &&
                  ndats[index]["category"] != "2018-2019" &&
                  ndats[index]["category"] != "2019-2020"
                ) {
                  leapranges.push({
                    categorys: ndats[index - 1]["category"],
                    categorye: ndats[index]["category"],
                  });
                }
              }
              ndats[index]["leapyear"] = "Leapyear";
            }
          });
          self.twoyear = _twoyear;
          self.oneyear = _oneyear;
          self.threeyear = _threeyear;

          // Create chart instance
          var chart = am4core.create("contractchart", am4charts.XYChart);

          // Add data
          chart.data = ndats;

          // Create axes
          var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
          categoryAxis.dataFields.category = "category";

          categoryAxis.renderer.grid.template.location = 0;
          categoryAxis.renderer.minGridDistance = 25;

          categoryAxis.renderer.labels.template.rotation = 0;

          //categoryAxis.renderer.minGridDistance = 30;

          categoryAxis.renderer.labels.template.events.on(
            "over",
            function (ev) {
              var point = categoryAxis.categoryToPoint(
                ev.target.dataItem.category
              );
              chart.cursor.triggerMove(point, "soft");
            }
          );

          categoryAxis.renderer.labels.template.events.on("out", function (ev) {
            var point = categoryAxis.categoryToPoint(
              ev.target.dataItem.category
            );
            chart.cursor.triggerMove(point, "none");
          });

          ndats.forEach(function (values, index) {
            if (ndats[index]) {
              let offrange2 = categoryAxis.axisRanges.create();
              var start = ndats[index].category;
              if (index > 0) {
                start = ndats[index].category;
              }

              var color = "#8790B1";
              var fillOpacity = 0.1;
              if (index % 2 == 0) {
                color = "#000";
                fillOpacity = 0;
              }

              offrange2.category = ndats[index].category;
              offrange2.endCategory = ndats[index].category;
              offrange2.axisFill.fill = am4core.color(color);
              offrange2.axisFill.fillOpacity = fillOpacity;
            }
          });

          var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
          //valueAxis.tooltip.disabled = true;

          chart.cursor = new am4charts.XYCursor();
          chart.cursor.lineY.disabled = true;
          chart.cursor.lineX.disabled = true;

          var valueAxis2 = chart.yAxes.push(new am4charts.ValueAxis());
          valueAxis2.renderer.opposite = true;
          valueAxis2.renderer.grid.template.disabled = true;

          // Create series
          var series1 = chart.series.push(new am4charts.LineSeries());
          series1.dataFields.valueY = "tc";
          series1.dataFields.categoryX = "category";
          series1.strokeWidth = 3;
          series1.stroke = am4core.color("#E55400");

          var bullet = series1.bullets.push(new am4charts.Bullet());
          bullet.fill = am4core.color("#E55400"); // tooltips grab fill from parent by default
          var circle = bullet.createChild(am4core.Circle);
          circle.radius = 6;
          circle.fill = am4core.color("#E55400");
          circle.fillOpacity = 1;
          circle.strokeWidth = 4;

          series1.tooltipHTML = `<div class="roleslist_tooltips twocolumn" ><div><ul><li> TEAM CONTRACT:&nbsp;&nbsp;$ {valueY}</li></ul></div></div>`;
          series1.tooltip.pointerOrientation = "horizontal";
          series1.tooltip.background.strokeWidth = 0;
          series1.tooltip.getFillFromObject = false;
          series1.tooltip.background.fill = am4core.color("#8790B1");
          series1.tooltip.background.fillOpacity = 0.7;

          var lineSeriesh = chart.series.push(new am4charts.LineSeries());
          lineSeriesh.dataFields.openValueY = "rcl";
          lineSeriesh.dataFields.valueY = "rcu";
          lineSeriesh.dataFields.value = "rcu";
          lineSeriesh.dataFields.customValue = "rtc";
          lineSeriesh.dataFields["comment"] = "comment";

          lineSeriesh.dataFields.categoryX = "category";

          lineSeriesh.stroke = am4core.color("#fac126");
          lineSeriesh.strokeWidth = 0;
          lineSeriesh.propertyFields.strokeDasharray = "lineDash";
          lineSeriesh.tooltip.label.textAlign = "middle";

          lineSeriesh.fill = lineSeriesh.stroke;
          lineSeriesh.fillOpacity = 0.5;

          lineSeriesh.tooltipHTML = `<div class="roleslist_tooltips roleslist_tooltipsleft" ><div><ul><li class="class{indexer}"> HI:&nbsp;&nbsp;$ {valueY}</li><li class="class{indexer}">PROJECTED:&nbsp;&nbsp;$ {customValue}</li><li class="classa{indexerp}">REAL-TIME CONTRACT:&nbsp;&nbsp;$ {customValue}</li><li class="class{indexer}">LOW:&nbsp;&nbsp;$ {openValueY}</li></ul></div></div>`;

          lineSeriesh.tooltip.pointerOrientation = "horizontal";
          lineSeriesh.tooltip.background.strokeWidth = 0;
          lineSeriesh.tooltip.getFillFromObject = false;
          lineSeriesh.tooltip.background.fill = am4core.color("#8790B1");
          lineSeriesh.tooltip.background.fillOpacity = 0.7;

          /* var lineSerieshba = chart.series.push(new am4charts.LineSeries());
                        lineSerieshba.dataFields.valueY = "rtc";
                        lineSerieshba.dataFields["comment"]="comment"
                        
                        lineSerieshba.dataFields.categoryX = "category";


                        lineSerieshba.stroke = am4core.color('#fac126');
                        lineSerieshba.strokeWidth = 0;
                        lineSerieshba.propertyFields.strokeDasharray = "lineDash";
                        lineSerieshba.tooltip.label.textAlign = "middle";

                        lineSerieshba.fill = lineSeriesh.stroke;
                        lineSerieshba.fillOpacity = 0;

                        lineSerieshba.tooltipHTML = `<div class="roleslist_tooltips roleslist_tooltipsleft" ><div><ul><li class="commentrtc"> {comment}</li></ul></div></div>`;

                        lineSerieshba.tooltip.pointerOrientation = "up";
                        lineSerieshba.tooltip.background.strokeWidth = 0;
                        lineSerieshba.tooltip.getFillFromObject = false;
                        lineSerieshba.tooltip.background.fill = am4core.color("#8790B1");
                        lineSerieshba.tooltip.background.fillOpacity = 0.7;*/

          var series2 = chart.series.push(new am4charts.LineSeries());
          series2.dataFields.valueY = "rtc";
          series2.dataFields.categoryX = "category";
          series2.strokeWidth = 3;
          series2.propertyFields.stroke = "linecolor";

          var bullet2 = series2.bullets.push(new am4charts.Bullet());
          bullet2.propertyFields.fill = "dotcolor";
          var circle2 = bullet2.createChild(am4core.Circle);
          circle2.radius = 6;
          circle2.propertyFields.stroke = "dotcolor";
          circle2.propertyFields.fill = "dotcolor";
          circle2.strokeWidth = 4;

          // Create series
          var series = chart.series.push(new am4charts.LineSeries());
          series.dataFields.valueY = "freeagent";
          series.dataFields.categoryX = "category";

          series.strokeWidth = 0;
          series.stroke = am4core.color("#4B58AA");
          series.opacity = 0;

          var bulletfa = series.bullets.push(new am4charts.Bullet());
          bulletfa.fill = am4core.color("#4B58AA"); // tooltips grab fill from parent by default
          var circlefa = bulletfa.createChild(am4core.Circle);
          circlefa.radius = 6;
          circlefa.fill = am4core.color("#4B58AA");
          circlefa.fillOpacity = 1;
          circlefa.strokeWidth = 4;

          series.tooltipHTML = `<div class="roleslist_tooltips twocolumn" ><div><ul><li>Free Agent</li></ul></div></div>`;
          series.tooltip.pointerOrientation = "horizontal";
          series.tooltip.background.strokeWidth = 0;
          series.tooltip.getFillFromObject = false;
          series.tooltip.background.fill = am4core.color("#8790B1");
          series.tooltip.background.fillOpacity = 0.7;

          series.adapter.add("tooltipHTML", function (text, target) {
            let data = target.tooltipDataItem.dataContext;
            if (data.freeagent == 0) {
              return "";
            } else {
              return text;
            }
          });

          circlefa.adapter.add("radius", function (fillOpacity, target) {
            if (!target.dataItem) {
              return fillOpacity;
            }
            return target.dataItem.dataContext.freeagent == 0 ? 0 : 12;
          });

          circlefa.adapter.add("fillOpacity", function (fillOpacity, target) {
            if (!target.dataItem) {
              return fillOpacity;
            }
            return target.dataItem.dataContext.freeagent == 0 ? 0 : 1;
          });

          categoryAxis.renderer.labels.template.fill =
            am4core.color("#7484a1cc");
          valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
          valueAxis.renderer.inside = true;
          valueAxis.renderer.labels.template.visible = false;
          valueAxis2.renderer.inside = true;
          valueAxis2.renderer.labels.template.visible = false;
          categoryAxis.renderer.grid.template.disabled = true;

          categoryAxis.renderer.grid.template.strokeWidth = 0;

          leapranges.forEach(function (item) {
            let offrange3 = categoryAxis.axisRanges.create();

            offrange3.category = item["categorye"];
            offrange3.endCategory = item["categorye"];

            offrange3.label.height = 310;
            offrange3.label.rotation = 360;
            offrange3.label.dy = -320;
            offrange3.label.dx = 0;

            offrange3.axisFill.fill = am4core.color("#ff0000");
            offrange3.axisFill.fillOpacity = 0.1;

            offrange3.label.textAlign = "center";

            offrange3.label.inside = true;
            offrange3.label.text = "Leap Year";
          });

          let _sdate = "2021-2022";
          let _edate = "2021-2022";

          let offrange = categoryAxis.axisRanges.create();

          offrange.category = _sdate;
          offrange.endCategory = _edate;

          offrange.axisFill.fill = am4core.color("#000000");
          offrange.axisFill.fillOpacity = 1;

          offrange.label.inside = true;
          offrange.label.text = "CURRENT SEASON";
          offrange.label.textAlign = "end";
          offrange.label.height = 310;
          offrange.label.opacity = 0.3;
          offrange.label.rotation = 270;
          offrange.label.dy = -180;
          offrange.label.dx = -35;
          offrange.label.adapter.add("horizontalCenter", function () {
            return "middle";
          });
          offrange.label.fill = am4core.color("#7484a1cc");
          offrange.label.fontSize = 30;
          offrange.label.fontFamily = "rajdhanisemibold";
        }
      });
    },
    checdiff(rtc, valu) {
      var percDiff = (100 * (rtc - valu)) / ((rtc + valu) / 2);
      if (percDiff > 20) {
        return false;
      }
      return true;
    },
  },
  mounted() {
    this.colors = this.chartcolors;

    this.gettop5picks();
    this.getprofitimpact();
    if (this.player.PO) {
      var _amounts = this.player.PO + "-" + (this.player.PO + 1);
      var _diffpo = this.player.RTC - this.player[_amounts];
      if (this.player[_amounts] && this.player[_amounts] > 20000000) {
        if (_diffpo > 10000000) {
          this.POA = "Opt Out";
        } else {
          this.POA = "Opt In";
        }
      }

      if (this.player[_amounts] && this.player[_amounts] > 15000000) {
        if (_diffpo > 60000000) {
          this.POA = "Opt Out";
        } else {
          this.POA = "Opt In";
        }
      }

      if (this.player[_amounts] && this.player[_amounts] < 15000000) {
        if (_diffpo > 4000000) {
          this.POA = "Opt Out";
        } else {
          this.POA = "Opt In";
        }
      }

      this.POAV = this.player[_amounts];
    }

    if (this.player.TO) {
      _amounts = this.player.TO - 1 + "-" + this.player.TO;
      if (
        this.player[_amounts] &&
        this.checdiff(this.player.RTC, this.player[_amounts])
      ) {
        this.TOA = "Decline";
      } else {
        this.TOA = "Exercise";
      }

      this.TOAV = this.player[_amounts];
    }

    if (this.player.NG) {
      _amounts = this.player.NG - 1 + "-" + this.player.NG;
      if (
        this.player[_amounts] &&
        this.checdiff(this.player.RTC, this.player[_amounts])
      ) {
        this.NGA = "Decline";
      } else {
        this.NGA = "Exercise";
      }

      this.NGAV = this.player[_amounts];
    }

    if (this.player.QO && this.player.QO == 2021) {
      _amounts = this.player.QO - 1 + "-" + this.player.QO;
      if (
        this.player[_amounts] &&
        this.checdiff(this.player.RTC, this.player[_amounts])
      ) {
        this.QOA = "Renounce";
      } else {
        this.QOA = "Issue";
      }

      this.QOAV = this.player[_amounts];
    }

    if (this.player.QO) {
      _amounts = this.player.QO - 1 + "-" + this.player.QO;
      this.RQOA = "Match";

      // this.QOAV = this.player[_amounts];
    }
  },
};
</script>



<style scoped>
.v-tooltip__content {
  max-width: 500px;
}

.performer_list_wrap {
  justify-content: left !important;
}
.performer_list {
  max-width: 150px;
  margin-right: 10px;
}
</style>

<style >
.commentrtc {
  max-width: 300px;
  white-space: pre-wrap;
  font-size: 14px;
}
.aaaaval1 {
  display: none;
}
.commentorylist {
  width: 100%;
  position: absolute;
  z-index: 1111;
  margin-top: -85px;
}
.commentorylist ul {
  display: flex;
}
.commentorylist ul > li {
  flex: 1;
  text-align: center;
  align-items: center;
  justify-content: center;
  color: #fff;
}
.commentorylist i {
  color: #8790b1 !important;
}
.commentorylist .v-icon.v-icon::after {
  border-radius: none !important;
}
.ttipBox {
  max-width: 400px;
}
.ttipBox li {
  margin-left: 20px;
  font-size: 13px;
}
.ttipBox ul {
  margin-top: 10px;
}
.ttipBox li,
.ttipBox ul {
  list-style: disc;
}
.ttipBoxwrap::after,
.ttipBoxwrap::before {
  display: none;
}
</style>
