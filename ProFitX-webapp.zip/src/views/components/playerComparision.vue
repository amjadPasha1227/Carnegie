

<template>  
    <div>
        <div class="widget_block">
            <div class="widget_title">
                <h3>PLAYER COMPARISION</h3>
                <div>
                    <a class="next_btn marr20" href="#"></a>
                </div>
            </div>
            <div class="widget_body padb0">
                <div class="comparision_wrap">
                    <div class="comparision_titles">
                        <label class="player1">Jonathan Drouin</label>
                        <label class="player2">DeVaughn Akoon-Purcell</label>
                    </div>
                    <v-row>
                        <v-col class="col-lg-5 col-md-6">
                            <div class="comp_player_details">
                                <div class="comp_player_title">
                                    <figure><img src="../../assets/images/profile_dp-1.png" alt="display Picture"></figure>
                                    <div class="player_personal_details col">
                                        <h5>DeVaughn Akoon-Purcell</h5>
                                        <ul>
                                            <li>
                                                <label>AGE</label>23yrs
                                            </li>
                                            <li>
                                                <label>MIN</label>125
                                            </li>
                                            <li>
                                                <label>TEAM</label>Warriors
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="comp_player_experience">
                                        <label><v-icon>mdi-menu-up</v-icon>$ 16,000,000
                                        <span>4yrs</span></label>
                                    </div>
                                </div>
                                <div class="comp_player_status">
                                    <p>Remaining Contract<br/>Amount</p>
                                    <label>Guaranteed</label>
                                </div>
                            </div>
                            <div class="comp_player_details">
                                <div class="comp_player_title">
                                    <figure><img src="../../assets/images/profile_dp-1.png" alt="display Picture"></figure>
                                    <div class="player_personal_details col">
                                        <h5>DeVaughn Akoon-Purcell</h5>
                                        <ul>
                                            <li>
                                                <label>AGE</label>23yrs
                                            </li>
                                            <li>
                                                <label>MIN</label>125
                                            </li>
                                            <li>
                                                <label>TEAM</label>Warriors
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="comp_player_experience">
                                        <label><v-icon>mdi-menu-up</v-icon>$ 16,000,000
                                        <span>4yrs</span></label>
                                    </div>
                                </div>
                                <div class="comp_player_status">
                                    <p>Remaining Contract<br/>Amount</p>
                                    <label>Guaranteed</label>
                                </div>
                            </div>
                        </v-col>
                        <v-col class="col-lg-7 col-md-6">
                            <div class="player_differences">
                                <ul>
                                    <li>
                                        <h6>Goals</h6>
                                        <playerGoal/>
                                    </li>
                                    <li>
                                        <h6>Assets</h6>
                                        <playerAssets/>
                                    </li>
                                    <li>
                                        <h6>Points</h6>
                                        <playerPoints/>
                                    </li>
                                    <li>
                                        <h6>Shot on Goal</h6>
                                        <shotGoal/>
                                    </li>
                                    <li>
                                        <h6>Shooting Percentage</h6>
                                        <shootingPercentage/>
                                    </li>
                                    <li>
                                        <h6>Average time on ICE</h6>
                                        <timeAverge/>
                                    </li>
                                </ul>
                            </div>
                        </v-col>
                    </v-row>
                </div>
            </div>
        </div>
    </div>    
</template>

<script>
//import VueApexCharts from 'vue-apexcharts';
import playerGoal from "@/views/components/playerGoal.vue";
import playerAssets from "@/views/components/playerAssets.vue";
import playerPoints from "@/views/components/playerPoints.vue";
import shotGoal from "@/views/components/shotGoal.vue";
import shootingPercentage from "@/views/components/shootingPercentage.vue";
import timeAverge from "@/views/components/timeAverge.vue";


export default {
  
   name: "player-comparision",
   components: {
        //apexchart:VueApexCharts,
        playerGoal,
        playerAssets,
        playerPoints,
        shotGoal,
        shootingPercentage,
        timeAverge,
    },
    data: function() {
      return {
        // chartOptions: {
        //   chart: {
        //     id: 'vuechart-example'
        //   },
          
        // },
        // series: [{
        //     data: [{
        //         x: 'TEAM A',
        //         y: [1, 20]
        //     },
        //     {
        //         x: 'TEAM B',
        //         y: [10, 50]
        //     }]
        // }]
      }
    },
};
</script>