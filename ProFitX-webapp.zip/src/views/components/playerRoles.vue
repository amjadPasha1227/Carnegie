<template>
<div>
    <div class="widget_block role_widget" v-if="player">
        <div class="widget_title">
            <h3>PLAYER ROLES - CURRENT SEASON

                <v-tooltip bottom>
                    <template v-slot:activator="{ on, attrs }">
                        <v-btn class="info_btn" v-bind="attrs" v-on="on">
                            <v-icon>mdi-information-outline</v-icon>
                        </v-btn>
                    </template>
                    <span>Dynamic AI model that displays real-time game by game ratings of 10 athlete performance roles for offense and defense for the current season.</span>
                </v-tooltip>
            </h3>
            <div>
                <div class="text-center">
                    <v-dialog v-model="dialog" width="1130" class="role_history">
                        <template v-slot:activator="{ on }">
                            <v-btn @click="_drawplayerroles('o')" color="modal_btn" v-on="on">Historical Roles</v-btn>
                        </template>

                        <v-card>
                            <v-row class="mar0">
                                <v-col class="pad0">
                                    <div class="widget_block marb0 role_modal">
                                        <div class="widget_title modal_header">
                                            <div class="modal_title">
                                                <h3>PLAYER ROLES


                                                      <v-tooltip bottom>
                    <template v-slot:activator="{ on, attrs }">
                        <v-btn class="info_btn" v-bind="attrs" v-on="on">
                            <v-icon>mdi-information-outline</v-icon>
                        </v-btn>
                    </template>
                    <span>Provides historical offensive and defensive player role ratings for entire career on a time series chart displaying overall trajectory of development.  </span>
                </v-tooltip>

                                                </h3>
                                                <ul class="tab_buttons">
                                                    <li v-bind:class="{ active: offensiveact }" @click="
                                                                                        offensiveact = true;
                                                                                        defffensiveact = false;
                                                                                        _drawplayerroles('o');
                              ">
                                                        <a>Offensive Rating</a>
                                                    </li>
                                                    <li v-bind:class="{ active: defffensiveact }" @click="
                                defffensiveact = true;
                                offensiveact = false;
                                _drawplayerroles('d');
                              ">
                                                        <a>Defensive Rating</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div>
                                                <v-btn color="primary" text @click="dialog = false">
                                                    <img src="../../assets/images/close.svg" />
                                                </v-btn>
                                            </div>
                                        </div>
                                        <div class="widget_body">
                                            <div id="roleschartdiv" class="timeserieschart"></div>

                                            <div class="role_footer">
                                                <ul class="status_list" v-show="offensiveact">
                                                    <li v-for="(orole, oroleindex) in offensive" v-bind:key="oroleindex">
                                                        <span v-bind:style="{
                                  background: colors[oroleindex],
                                }"></span>
                                                        <p>{{ orole }}</p>
                                                    </li>
                                                </ul>

                                                <ul class="status_list" v-show="defffensiveact">
                                                    <li v-for="(drole, droleindex) in defensive" v-bind:key="droleindex">
                                                        <span v-bind:style="{
                                  background: colors[droleindex],
                                }"></span>
                                                        <p>{{ drole }}</p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </v-col>
                            </v-row>
                        </v-card>
                    </v-dialog>
                </div>
            </div>
        </div>
        <div class="widget_body role_body" style="min-height: 400px">
            <div class="shotsloading" v-if="!rolesloaded">
                <img src="../../assets/images/shotsloading.svg" />
            </div>
            <v-row class="mar0">
                <v-col md="6" cols="12" class="pad0">
                    <div class="role_content">
                        <h6>Offensive Rating</h6>
                        <ul>
                            <li v-for="(role, index) in currentplayerroles.o" :key="index">
                                <span v-bind:style="{ borderColor: colors[index] }">{{
                    role.v | percentazec
                  }}</span>
                                <div class="role_status" v-bind:style="{
                      background: colors[index],
                      width: role.v + '%',
                    }"></div>
                                <label>{{ role.k }}</label>
                            </li>
                        </ul>
                    </div>
                </v-col>
                <v-col md="6" cols="12" class="pad0">
                    <div class="role_content defensive_content">
                        <h6>Defensive Rating</h6>

                        <ul>
                            <li v-for="(role, index) in currentplayerroles.d" :key="index">
                                <span v-bind:style="{ borderColor: colors[index + 6] }">{{
                    role.v | percentazec
                  }}</span>
                                <div class="role_status" v-bind:style="{
                      background: colors[index + 6],
                      width: role.v + '%',
                    }"></div>
                                <label>{{ role.k }}</label>
                            </li>
                        </ul>
                    </div>
                </v-col>
            </v-row>
        </div>
    </div>
</div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";

am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);
var _roleschart;
export default {
    name: "player-roles",
    props: {
        player: {},
        playerid: null,
    },
    data: () => ({
        rolesloaded: false,
        rolesgroup: [],
        currentplayerroles: {},
        getplayerrolesbyplayer: [],
        dialog: false,
        offensiveact: true,
        defffensiveact: false,
        chartloaded: false,
        dateperiod: null,
        selectedvaluesout: [],
        innerdata: [],
        selectedtype: [],
        offensive: [
            "Sharpshooter",
            "Slasher",
            "Interior Finisher",
            "High Volume Scorer",
            "Playmaker",
        ],
        defensive: [
            "Versatile Defender",
            "Rim Protector",
            "Rebounding Specialist",
            "Turnover Specialist",
            "High Motor",
        ],
        colors: [],
        ddata: [],
    }),
    methods: {
        playerrole(playername) {
            let returnvalues = [];
            let filter = this.player.ROLES;

            if (filter != undefined) {
                returnvalues["o"] = [];
                this.offensive.forEach(function (_role) {
                    returnvalues["o"].push({
                        k: _role,
                        v: filter[_role] * 100,
                    });
                });

                returnvalues["d"] = [];
                this.defensive.forEach(function (_role) {
                    returnvalues["d"].push({
                        k: _role,
                        v: filter[_role] * 100,
                    });
                });

                returnvalues["d"] = this.lodash.orderBy(
                    returnvalues["d"],
                    ["v"],
                    ["desc"]
                );
                returnvalues["o"] = this.lodash.orderBy(
                    returnvalues["o"],
                    ["v"],
                    ["desc"]
                );
            }
            this.rolesloaded = true;
            return returnvalues;
        },
        _getRoles() {

                        this.$store.dispatch("getplayerroles", {}).then((response) => {
                var results = JSON.parse(response.data);
                this.rolesgroup = results;
             //   this.currentplayerroles = this.playerrole(this.player.PLAYER_NAME);
                this.rolesloaded = true;
            });
            this.$store
                .dispatch("getplayerrolesbyplayer", {
                    playerName: this.player.PLAYER_NAME,
                })
                .then((response) => {
                    var results = JSON.parse(response.data);
                    this.getplayerrolesbyplayer = results;
                });

                this.currentplayerroles = this.playerrole(this.player.PLAYER_NAME);
        },
        _setSeason(startDate,endDate,dateAxis,color,title,opacity){

          

                    let offrange = dateAxis.axisRanges.create();

                    offrange.date = new Date(startDate);
                    offrange.endDate = new Date(endDate);
                    offrange.axisFill.fill = am4core.color(color);
                    offrange.axisFill.fillOpacity = opacity;

                    offrange.label.inside = true
                    offrange.label.text = title;
                    offrange.label.textAlign = "end"
                    offrange.label.height = 310
                    offrange.label.rotation = 270;
                    offrange.label.dy = -125
                    offrange.label.dx = -5
                    offrange.label.adapter.add("horizontalCenter", function () {
                        return "middle";
                    });
                    offrange.label.fill = am4core.color("#000");

                    offrange.label.fontFamily = 'rajdhanisemibold';

        },
        _drawplayerroles(_type) {
            var _self = this;
            if (this.offensiveact) _type = "o";
            if (this.defffensiveact) _type = "d";
            if (_roleschart) _roleschart.dispose()
            setTimeout(function () {
                var results = _self.getplayerrolesbyplayer;
                var data = [];
                results.forEach((d, index) => {
                    var _cd = {};
                    _cd.Date = new Date(d.date);
                    if (_type == "o") {
                        _self.offensive.forEach(function (_role) {
                            _cd[_role] = +(d[_role] * 100).toFixed(1);
                        });
                    }

                    _cd.oteam=d.oteam;

                    if (_type == "d") {
                        _self.defensive.forEach(function (_role) {
                            _cd[_role] = +(d[_role] * 100).toFixed(1);
                        });
                    }

                    data.push(_cd);
                });

                // Create chart instance
                let chart = am4core.create("roleschartdiv", am4charts.XYChart);
                _roleschart = chart;
                data = _self.lodash.sortBy(data, "Date");
                chart.data = data;
                chart.preloader.background.fill = am4core.color("#000000");
                chart.preloader.background.fillOpacity = 0.1;

                let dateAxis = chart.xAxes.push(new am4charts.DateAxis());
                dateAxis.renderer.grid.template.location = 0;
                dateAxis.renderer.minGridDistance = 60;
                dateAxis.fillOpacity = 0.6;
                let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
                valueAxis.fillOpacity = 0.6;
                valueAxis.max = 100;
                valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");

                var series;
                var _colors = _self.colors;
                var _types;
                if (_type == "o") _types = _self.offensive;
                if (_type == "d") _types = _self.defensive;

                var ttip = `<ul>`;
                _types.forEach(function (_role, index) {
                    series = chart.series.push(new am4charts.LineSeries());
                    series.dataFields.valueY = _role;
                    series.dataFields.dateX = "Date";
                    series.stroke = am4core.color(_colors[index]);
                    series.connect = true;
                    series.strokeWidth = 2;
                    ttip = ttip + `<li><em style='background:` + _colors[index] + `'></em> <span>` + _role + `: {` + _role + `}</span></li>`;
                });

                for (var i = 2009; i < 2023; i++) {
                    var _sdate = i + "-09-30";
                    var _edate = (i + 1) + "-05-30";

                    let range = dateAxis.axisRanges.create();

                    range.date = new Date(_sdate);
                    range.endDate = new Date(_edate);
                    range.axisFill.fill = am4core.color('#8790b1cc');
                    range.axisFill.fillOpacity = 0.4;

                }

                for (var ix = 2009; ix < 2023; ix++) {
                    _self._setSeason(_sdate,_edate,dateAxis,'#000000',"Offseason",1)

                }

                /* PLAY OFFS */
            _self._setSeason("2010-04-17","2010-06-17",dateAxis,'#8790b1',"PLAYOFFS",1)    
             _self._setSeason("2011-04-16","2011-06-12",dateAxis,'#8790b1',"PLAYOFFS",1)    
            _self._setSeason("2012-04-28","2012-06-21",dateAxis,'#8790b1',"PLAYOFFS",1)    
             _self._setSeason("2013-04-20","2013-06-20",dateAxis,'#8790b1',"PLAYOFFS",1)    
               _self._setSeason("2014-04-19","2014-06-15",dateAxis,'#8790b1',"PLAYOFFS",1)  
              _self._setSeason("2015-04-18","2015-06-16",dateAxis,'#8790b1',"PLAYOFFS",1)  

                _self._setSeason("2016-04-16","2016-06-19",dateAxis,'#8790b1',"PLAYOFFS",1)  

                _self._setSeason("2017-04-15","2017-06-12",dateAxis,'#8790b1',"PLAYOFFS",1)  
                _self._setSeason("2018-04-15","2018-06-12",dateAxis,'#8790b1',"PLAYOFFS",1) 
                _self._setSeason("2018-04-14","2018-06-08",dateAxis,'#8790b1',"PLAYOFFS",1) 
               _self._setSeason("2019-04-13","2019-06-12",dateAxis,'#8790b1',"PLAYOFFS",1)
               _self._setSeason("2020-08-17","2020-10-30",dateAxis,'#8790b1',"PLAYOFFS",1)
               _self._setSeason("2021-05-22","2021-07-30",dateAxis,'#8790b1',"PLAYOFFS",1)
_self._setSeason("2022-04-16","2022-06-16",dateAxis,'#8790b1',"PLAYOFFS",1)


                dateAxis.renderer.labels.template.textAlign = "middle";
                dateAxis.dateFormats.setKey("month", "MMM-yy");

                ttip = ttip + `</ul>`;
                series.tooltipHTML = `<div class="roleslist_tooltips" ><div><div style="color:#ffffff" class="dateperiod">{dateX.formatDate("MMM d, yyyy")}</div>` + ttip + `</div></div>`;
                series.tooltip.pointerOrientation = "vertical";
                series.tooltip.background.strokeWidth = 0;
                series.tooltip.getFillFromObject = false;
                series.tooltip.background.fill = am4core.color("#11172B");
                series.tooltip.background.fillOpacity = 0.7;
                chart.events.on("ready", function (ev) {
                    valueAxis.min = valueAxis.minZoomed;
                    valueAxis.max = valueAxis.maxZoomed;
                });

                // Add vertical scrollbar
                chart.scrollbarX = new am4core.Scrollbar();
                chart.scrollbarX.parent = chart.bottomAxesContainer;
                chart.zoomOutButton.disabled = true;
                chart.scrollbarX.stroke = am4core.color("#3F4C76");
                chart.scrollbarX.strokeOpacity = 0.6
                chart.scrollbarX.background.fill = am4core.color("#3F4C76");
                chart.scrollbarX.background.fillOpacity = 0.6
                chart.scrollbarX.startGrip.background.fill = am4core.color("#3F4C76");
                chart.scrollbarX.endGrip.background.fill = am4core.color("#3F4C76");
                                chart.events.on("ready", function () {
                
                });
                // Add cursor
                chart.cursor = new am4charts.XYCursor();
            }, 150);
        },
    },
    watch: {
        player: function (value) {
            var self = this;
            this.selectedtype = this.offensive;
        },
    },
    mounted() {
        this.colors = this.chartcolors;
        var self = this;
        setTimeout(function () {
            self._getRoles();
        }, 500);
    },
};
</script>
