<template>
<div>

    <div class="widget_block profit_widget">
        <div class="widget_title" style="z-index:111;">
            <h3>CAREER OUTLOOK

                <v-tooltip bottom>
                    <template v-slot:activator="{ on, attrs }">
                        <v-btn class="info_btn" v-bind="attrs" v-on="on">
                            <v-icon>mdi-information-outline</v-icon>
                        </v-btn>
                    </template>
                    <span >
                        
                       <div style="width:300px" >    <p >  Dynamic AI model that will display and identify the year by year financial and performance trajectory, age impact of performance, free agency market tier, and projections for next 2 seasons of the professional athlete’s career. 
 </p>
                   </div>     
                         </span>
                </v-tooltip>

            </h3>
         
        </div>
        <div class="widget_body">
            <div class="profit_status" v-if="pioffensive">
                <ul class="profit-agent-items">
                    <li class="impact">Age Impact</li>
                    <li class="agent">Free Agent</li>
                    <li class="earnings">Team Contract </li>
                    <li class="projected">Real Time Contract </li>
                     <li class="projected2">Fair Market Value </li>
                </ul>
            </div>
            <div class="profit_status" v-if="pidefensive">
                <ul class="profit-agent-items">
                    <li class="agent">Playmaking</li>
                    <li class="earnings">Defense</li>
                    <li class="projected">Offense</li>
                </ul>
            </div>
            <div class="yearsFlexwrap">
                <div class="yearsFlex">
                    <div v-for="(lael, index) in outlook" v-bind:key='index'>{{lael}}</div>

                </div>
                <ContractsChart v-if="player && pioffensive" :player="player" />
                <PfChart v-if="player && pidefensive" :player="player" />

            </div>
            <!--  -->
        </div>
    </div>
</div>
</template>

<script>
import moment from "moment";
import ContractsChart from './contracts/contracts'
import PfChart from './contracts/performance'

export default {
    components: {
        ContractsChart,
        PfChart
    },
    props: {
        player: null
    },
    data: () => ({
        outlook: [],
        pioffensive: false,
        pidefensive: true,
    }),
    methods: {

    
    },
    mounted() {

    }
};
</script>


<style scoped>
.v-tooltip__content{
max-width:800px;
}
</style>