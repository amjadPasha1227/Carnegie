<template>
<div style="cursor:pointer;  color:#fff !important"> 
    <v-icon style="cursor:pointer;  font-size:30px; color:#fff !important" v-if="loadeds && !currenteam" @click="addFav(player)">mdi-star-outline</v-icon>
    <v-icon  style="cursor:pointer; font-size:30px; color:#fff !important"  v-if="loadeds && currenteam" @click="removeFav(player)">mdi-star</v-icon>

</div>
</template>

<script>
export default {
    props: {
        player: {},
        favslist: null,
    },
    mounted() {
        var self = this;

        this.currenteam = self._.find(this.favslist, function (obj) {
            return obj.name === self.player["PLAYER_NAME"];
        });

        this.loadeds = true;

    },
    data: () => ({
        currenteam: null,
        loadeds: false
    }),
    methods: {
        addFav(obj) {
            var userid = this.$store.state.user._id;
            const obja = {
                name: this.player["PLAYER_NAME"],
                userId: userid
            };
            this.$store
                .dispatch("addTofav", obja)
                .then(response => {
                    this.currenteam = response;
                })

        },
        removeFav(obj) {
                    this.currenteam = null;

            var userid = this.$store.state.user._id;
            const obja = {
                name: this.player["PLAYER_NAME"],
                userId: userid
            };
        
            this.$store
                .dispatch("removeFromfav", obja)
                .then(response => {

                })

        }
    }
}
</script>
