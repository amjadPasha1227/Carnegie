

<template>  
    <div>
        <div class="total-brand-value">
            <div class="tbv-left">
                <h2 class="small-heading">total brand value</h2>
                <div id="chart2" class="total-brand-value-chart">
                    <apexchart type="donut" height="150" :options="chartOptions3" :series="series"></apexchart>
                </div>
            </div>
            <div class="tbv-right">
                <ul>
                    <li>
                        <span>2019 Earnings</span>
                        <p>$18,340M</p>
                    </li>
                    <li>
                        <span>2019 Salary</span>
                        <p>$8,570M</p>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script>
import VueApexCharts from 'vue-apexcharts';

export default {
    name: "total-brand-Value",
    components: {
        apexchart: VueApexCharts,
    },
    data: () => ({
        items: ['Foo', 'Bar', 'Fizz', 'Buzz'],
        fav: true,
        menu: false,
        message: false,
        hints: true,
        
        chartOptions3: {
          chart: {
            type: 'donut'
          },
          labels: ['Market', 'Arena', 'Brand'],
          colors: ['#802A2A' , '#5E5D8D' ,'#7E8F38'],
          legend: {
            show: true
          },
          xaxis: {
            labels: {
              show: false,
            }
          },
          yaxis: {
            labels: {
              show: false,
            }
          },
        },
        
        series: [45, 45, 45], 
      }),
  watch: {},
  computed: {},
  methods: {}, 
  created() {}
    
}
</script>
