<template>
<div>
    <div class="widget_block load-manage-block">
        <div class="widget_title">
            <h3>LOAD MANAGEMENT

                <v-tooltip bottom>
                    <template v-slot:activator="{ on, attrs }">
                        <v-btn class="info_btn" v-bind="attrs" v-on="on">
                            <v-icon>mdi-information-outline</v-icon>
                        </v-btn>
                    </template>
                    <span>Dynamic AI model displays the athlete’s current season schedule for the next 7 games and project when he should be rested, ideal minutes played, or should be given a minutes restriction based off workload, injury history, and the upcoming schedule. </span>
                </v-tooltip>

            </h3>
            <div>
                <v-row>
                    <v-col>

                    </v-col>
                </v-row>
            </div>
        </div>
        <!-- <div class="widget_body calendar-block"> -->
        <div class="widget_body load-management" v-slimscroll="options" >
            <v-row justify="center" >

                <span class="outofseason" v-if="player.injuries && player.injuries.length > 0 && player.injuries[player.injuries.length-1].Status == 'Out for Season'">Out for Season</span>
                            <span class="outofseason" v-else-if="player.injuries && player.injuries.length > 0 && player.injuries[player.injuries.length-1].endDate == null">Active Injury</span>
                <span class="outofseason" v-else-if="fmatches.length == 0 ">NO MATCHES SCHEDULED</span>
                <span v-else style="width:100%">

                    <template v-for="(match,index) in fmatches">
 

                            <ul v-bind:key="index">
                                <li><span>Away Team</span><p>{{match.awayteam}}</p></li>
                                <li v-if="match.venue_name"><span>Venue</span><p>{{match.venue_name}}</p></li>
                                <li><span>Date</span><p>{{match.gamedate | formatDate}}</p></li>
                                <li v-if="match.playsecs!=0"><span>Ideal Time</span><p>{{match.playsecs}} Minutes</p></li>
                                <li v-if="match.playsecs!=0 && SickTime > 30"><span>Minutes Restriction</span><p>{{match.playsecs-(match.playsecs*30/100)}} Minutes</p></li>

                            </ul> 

                    </template>

                </span>
            </v-row>
        </div>
    </div>
</div>
</template>

<script>
import moment from 'moment'

export default {
    name: "load-management",

    props: {
        player: {}
    },
    components: {

    },
    mounted() {

        var _self = this;

        if (this.player.ninjuries && this.player.ninjuries.length > 0 && _self.player._matches.length > 0) {

            var groupbyparts = _self.lodash.groupBy(this.player.ninjuries, "BODYPART");
            const totalmissed = this.lodash.sumBy(this.player.ninjuries, injury => {
                return parseInt(injury.MISSED);
            });
            var filterd = _self.lodash.filter(_self.player._matches, function (o) {
                return moment(o.gamedate).startOf('day').isSameOrBefore(moment().startOf('day'))
            })

            this.SickTime = (totalmissed / filterd.length) * 100;

        }
        this._getTime();
    },
    methods: {
        _getTime() {
            var self = this;
            var postdata = {}
            postdata = {
                selectedones: this.selectedones,
                playerName: this.player.PLAYER_NAME
            };

            this.$store.dispatch("getOppurtunitytime", postdata).then(response => {
                var results = JSON.parse(response.data.data);
                this.projectedminutes = results;
                var matches = self.player.matches;

                var i = 0;
                matches.forEach(function (item, index) {

                    if (moment(item.gamedate).startOf('day').isSameOrAfter(moment(new Date()).startOf('day'))) {
                        if (results[i] && results[i]['playsecs']) {

                            self.player.matches[index]['playsecs'] = Math.round(results[i]['playsecs'] / 60);
                        } else {

                            self.player.matches[index]['playsecs'] = 0;
                        }
                        i++;
                    } else {

                        self.player.matches[index]['playsecs'] = 0;

                    }

                })

                var filterd = self.lodash.filter(self.player.matches, function (o) {
                    return moment(o.gamedate).startOf('day').isSameOrAfter(moment().startOf('day'))
                })
           
                if (filterd && filterd.length > 0) {
                    this.player.matches = [];
                    this.fmatches = filterd.slice(0, 10)
                    this.player.matches = filterd.slice(0, 10)

                }

            });

        },
        functionEvents(date) {
            var dates = this.lodash.map(this.player.matches, 'gamedate');
            var filterd = this.lodash.find(dates, function (o) {

                return moment(o).startOf('day').isSame(moment(date).startOf('day'))
            })
            if (filterd) return ['#ff8f00']
            return false
        },
    },
    computed: {
        attributes() {
            return [
                // Attributes for todos
                ...this.player.matches.map(todo => ({
                    highlight: {
                        color: 'orange',
                        fillMode: 'light',
                    },
                    dates: todo.gamedate,

                    customData: todo,
                    popover: {
                        visibility: 'hover',
                        isInteractive: false, // Defaults to true when using slot

                    }
                })),
            ];
        },
    },
    data: () => ({
        fmatches: [],
        SickTime: 0,
        projectedminutes: [],
        todos: [{
            description: 'Take Noah to basketball practice.',
            isComplete: false,
            dates: {
                weekdays: 6
            }, // Every Friday
            color: 'red',
        }],
        itemsA: ['Foo', 'Bar', 'Fizz', 'Buzz'],
        itemsB: ['Foo', 'Bar', 'Fizz', 'Buzz'],
        itemsC: ['Foo', 'Bar', 'Fizz', 'Buzz'],
        picker: new Date().toISOString().substr(0, 10),
        options: {
            height: '100%',
            size:5,
            wheelStep : 5,
        },
    }),
}
</script>

<style scoped>

</style>
