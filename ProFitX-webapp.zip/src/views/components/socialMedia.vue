

<template>  
    <div>
        <h2 class="small-heading">social Media</h2>
        <div class="brand-social-media">
            <ul class="bsm-list">
                <li>
                <div class="card">
                    <div class="card-header">
                        <div class="brand-fallowers">
                            <figure><v-icon>mdi-instagram</v-icon></figure>
                            <div>
                                <h4>Followers</h4>
                                <p>74M</p>
                            </div>
                        </div>
                        <div class="chart">
                            <img src="@/assets/images/chart-icon.svg">
                        </div>
                    </div>
                    <div class="card-content">
                        <ul>
                            <li>
                                <p>Total Value</p>
                                <span>$125M</span>
                            </li>
                            <li>
                                <p>Revenue Per Fan</p>
                                <span>$41</span>
                            </li>
                        </ul>
                    </div>
                </div>
                </li>
                <li>
                <div class="card">
                    <div class="card-header">
                        <div class="brand-fallowers">
                            <figure><v-icon>mdi-facebook</v-icon></figure>
                            <div>
                                <h4>Followers</h4>
                                <p>12M</p>
                            </div>
                        </div>
                        <div class="chart">
                            <img src="@/assets/images/chart-icon.svg">
                        </div>
                    </div>
                    <div class="card-content">
                        <ul>
                            <li>
                                <p>Total Value</p>
                                <span>$125M</span>
                            </li>
                            <li>
                                <p>Revenue Per Fan</p>
                                <span>$41</span>
                            </li>
                        </ul>
                    </div>
                </div>
                </li>
                <li>
                <div class="card">
                    <div class="card-header">
                        <div class="brand-fallowers">
                            <figure><v-icon>mdi-twitter</v-icon></figure>
                            <div>
                                <h4>Followers</h4>
                                <p>25M</p>
                            </div>
                        </div>
                        <div class="chart">
                            <img src="@/assets/images/chart-icon.svg">
                        </div>
                    </div>
                    <div class="card-content">
                        <ul>
                            <li>
                                <p>Total Value</p>
                                <span>$125M</span>
                            </li>
                            <li>
                                <p>Revenue Per Fan</p>
                                <span>$41</span>
                            </li>
                        </ul>
                    </div>
                </div>
                </li>
                <li>
                <div class="card">
                    <div class="card-header">
                        <div class="brand-fallowers">
                            <figure><v-icon>mdi-youtube</v-icon></figure>
                            <div>
                                <h4>Followers</h4>
                                <p>126M</p>
                            </div>
                        </div>
                        <div class="chart">
                            <img src="@/assets/images/chart-icon.svg">
                        </div>
                    </div>
                    <div class="card-content">
                        <ul>
                            <li>
                                <p>Total Value</p>
                                <span>$125M</span>
                            </li>
                            <li>
                                <p>Revenue Per Fan</p>
                                <span>$41</span>
                            </li>
                        </ul>
                    </div>
                </div>
                </li>
            </ul>  
        </div>
    </div>
</template>

<script>
export default {
    name: "social-media",
    
}
</script>
