<template>
  <div>
    <div class="widget_block" v-if="player">
      <div class="widget_title" style="z-index: 111">
        <h3>
          OPPORTUNITY

          <v-tooltip bottom>
            <template v-slot:activator="{ on, attrs }">
              <v-btn class="info_btn" v-bind="attrs" v-on="on">
                <v-icon>mdi-information-outline</v-icon>
              </v-btn>
            </template>
            <span>
              <div style="width: 400px">
                <p>
                  PREVIOUS GAMES & PERFORMANCE: This model will display athlete
                  performance and minutes played for past 20 games for each
                  individual performance area
                </p>
                <p>
                  PROJECTIONS: Dynamic AI model that provides the HI-LOW
                  performance projections for the athlete configured with
                  opponents for next 5 games and ability to manually input the
                  number of minutes played to see production.
                </p>
              </div>
            </span>
          </v-tooltip>
        </h3>
        <div>
          <v-row class="mar0 align-items-center">
            <label class="title_label" style="padding-left: 20px"
              >Minutes</label
            >
            <div class="opportunity_search">
              <v-text-field
                class="text_field"
                label="1 %"
                v-model="projectedminutes"
                single-line
                outlined
              ></v-text-field>
              <button class="apply_btn" @click="_getAttributes()">
                <v-icon>mdi-checkbox-marked-circle</v-icon>
              </button>
            </div>
            <button class="reset_btn">
              <img src="@/assets/images/refresh.svg" />
            </button>
          </v-row>
        </div>
      </div>
      <div class="widget_body tendencies_widget flex-row">
        <div v-if="shotsloading" class="shotsloading">
          <img src="@/assets/images/shotsloading.svg" />
        </div>
        <div class="tendencies_list">
          <ul>
            <li v-for="(tendency, index) in tendencies" v-bind:key="index">
              <v-checkbox
                @change="_getAttributes()"
                :class="'color' + (index + 1)"
                v-model="selectedones"
                :label="tendency.label"
                :color="colors[index]"
                :border-color="colors[index]"
                :value="tendency"
                hide-details
              ></v-checkbox>
            </li>
          </ul>
        </div>
        <div class="tendencies_graph_wrap">
          <div class="tendencies_graph padt30">
            <div
              id="chartdiv2"
              style="height: 400px"
              class="timeserieschart"
            ></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import moment from "moment";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);
import teamslist from "./../../data/teams.json";

export default {
  name: "player-tendencies",
  components: {},
  props: {
    player: null,
    playerid: null,
  },
  data: function () {
    return {
      shotsloading: false,
      tdateperiod: null,
      tselectedvalues: [],
      options: {
        height: "100%",
        size: 5,
      },
      selectedones: {
        field: "points",
        label: "POINTS",
        color: "#C73434",
      },
      tendencies: [
        {
          field: "points",
          label: "POINTS",
          color: "#C73434",
        },
        {
          field: "OREB",
          label: "OFFENSIVE REBOUNDS",
          color: "#2D70CE",
        },
        {
          field: "DREB",
          label: "DEFENSIVE REBOUNDS",
          color: "#B51F9E",
        },
        {
          field: "TOV",
          label: "TURNOVERS",
          color: "#2FA7A7",
        },
        {
          field: "AST",
          label: "ASSISTS",
          color: "#C9AB2E",
        },
        {
          field: "BLK",
          label: "BLOCKS",
          color: "#27B2DB",
        },
        {
          field: "STL",
          label: "STEALS",
          color: "#8434E2",
        },
      ],
      colors: [],
      projectedminutesd: null,
      projectedminutes: null,
    };
  },
  methods: {
    _getAttributes() {
      var test = 111111111;

      if (this.selectedones != null) {
        this.noshots = false;
        this.shotsloading = true;
        var self = this;
        var postdata = {};
        var _colorindex = this.selectedones.color;
        var filterd = self.lodash.filter(self.player.matches, function (o) {
          return moment(o.gamedate)
            .startOf("day")
            .isSameOrAfter(moment().startOf("day"));
        });

        filterd = self.lodash.sortBy(filterd, function(dateObj) {
  //return moment(o.gamedate);
});

        console.log(filterd)

        filterd = filterd.slice(0, 10);

        var oppteams = [];
        filterd.forEach(function (d) {
          let currenteam = self._.find(teamslist, function (obj) {
            return obj.TEAM_NAME === d.awayteam;
          });

          if (currenteam) oppteams.push(currenteam.TEAM_NAME);
        });

        postdata = {
          selectedones: this.selectedones.field,
          playerName: this.player.PLAYER_NAME,
          futureperiods: filterd.length,
          oppteams: oppteams,
        };
        if (
          this.projectedminutes != null &&
          this.projectedminutesd != this.projectedminutes
        ) {
          postdata.playsecs = parseInt(this.projectedminutes) * 60;
        }
        this.$store.dispatch("getOppurtunity", postdata).then((response) => {
          var nresults = JSON.parse(response.data.data);
          this.projectedminutes = Math.round(response.data.idealseconds / 60);
          this.projectedminutesd = Math.round(response.data.idealseconds / 60);
          if (nresults.length > 0) {
            this.shotsloading = false;

            var tend = JSON.parse(response.data.tend);

            var data = [];
            var results = nresults.reverse();
            var range1, range2, range3, range4;
            results.forEach(function (d) {
              var lds = {
                date: new Date(d.Date),
              };
              lds["year"] = moment(new Date(d.Date)).format("MM-DD-YY");

              lds[self.selectedones.field] = d["performance"];
              lds[self.selectedones.field + "HIGH"] = d["performance"];
              lds[self.selectedones.field + "LOW"] = d["performance"];
              var _t = Math.round(d["playsecs"] / 60);
           
              lds["playsecs"] = _t;
              data.push(lds);
            });

            range1 = data[0].year;
            range2 = data[data.length - 1].year;

            var iu = 0;

            tend.forEach(function (d) {
              if (filterd[iu] && filterd[iu].gamedate) {
                var tomorrow = new Date();

                var lds = {
                  date: moment(filterd[iu].gamedate),
                };
                lds["year"] = moment(filterd[iu].gamedate).format("MM-DD-YY");
                if (self.player.TEAM_ABBREVIATION != filterd[iu].awayteam) {
                  lds["opp"] = filterd[iu].awayteam;
                } else {
                  lds["opp"] = filterd[iu].hometeam;
                }
                lds[self.selectedones.field] = d["performance"];
                lds[self.selectedones.field + "HIGH"] = d["ulimit"];
                lds[self.selectedones.field + "LOW"] = d["llimit"];
                var _t = Math.round(d["playsecs"] / 60);
              
                lds["playsecs"] = _t;
                data.push(lds);
                iu++;
              }
            });

            if (data[data.length - filterd.length]) {
              range3 = data[data.length - filterd.length].year;
            }
            range4 = data[data.length - 1].year;

            am4core.useTheme(am4themes_animated);

            // Create chart instance
            var chart = am4core.create("chartdiv2", am4charts.XYChart);

            // Add data
            chart.data = data;
            chart.zoomOutButton.disabled = true;

            chart.seriesContainer.draggable = false;
            chart.seriesContainer.resizable = false;
            chart.maxZoomLevel = 1;

            // Create axes
            var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
            categoryAxis.dataFields.category = "year";

            categoryAxis.renderer.grid.template.location = 0;
            categoryAxis.renderer.minGridDistance = 5;
            categoryAxis.renderer.labels.template.horizontalCenter = "right";
            categoryAxis.renderer.labels.template.verticalCenter = "middle";
            categoryAxis.renderer.labels.template.rotation = 270;

            //categoryAxis.renderer.minGridDistance = 30;

            categoryAxis.renderer.labels.template.events.on(
              "over",
              function (ev) {
                var point = categoryAxis.categoryToPoint(
                  ev.target.dataItem.category
                );
                chart.cursor.triggerMove(point, "soft");
              }
            );

            categoryAxis.renderer.labels.template.events.on(
              "out",
              function (ev) {
                var point = categoryAxis.categoryToPoint(
                  ev.target.dataItem.category
                );
                chart.cursor.triggerMove(point, "none");
              }
            );

            var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
            valueAxis.tooltip.disabled = true;

            valueAxis.title.text = "Minutes Played";
            valueAxis.title.dy = 80;
            valueAxis.title.rotation = 270;
            valueAxis.title.align = "center";
            valueAxis.title.valign = "top";
            valueAxis.title.fontWeight = 600;
            valueAxis.title.fill = am4core.color("#7484a1cc");

            valueAxis.min = 0;
            // Create series
            var series = chart.series.push(new am4charts.ColumnSeries());
            series.dataFields.valueY = "playsecs";
            series.dataFields.categoryX = "year";
            let offrange = categoryAxis.axisRanges.create();
            offrange.category = range1;
            offrange.endCategory = range2;
            offrange.axisFill.fill = am4core.color("#cf0025");
            offrange.axisFill.fillOpacity = 0.1;
            offrange.label.rotation = 360;
            offrange.label.dy = -280;
            offrange.label.inside = true;
            offrange.label.text = "Previous Games & Performance";

            let offrange2 = categoryAxis.axisRanges.create();
            offrange2.category = range3;
            offrange2.endCategory = range4;
            offrange2.axisFill.fill = am4core.color("#cf0025");
            offrange2.axisFill.fillOpacity = 0.4;
            offrange2.label.rotation = 360;
            offrange2.label.dy = -280;
            offrange2.label.dx = 60;
            offrange2.label.inside = true;
            if (data[data.length - filterd.length]) {
              offrange2.label.text = "Projections";
            }

            offrange.label.adapter.add("horizontalCenter", function () {
              return "middle";
            });
            offrange.label.fill = am4core.color("#7484a1cc");

            offrange.label.fontFamily = "rajdhanisemibold";

            series.adapter.add("tooltipText", (text, target) => {
              let data = target.tooltipDataItem.dataContext;
              let proj = Math.round(
                target.tooltipDataItem.dataContext[self.selectedones.field]
              );
              let high = Math.round(
                target.tooltipDataItem.dataContext[
                  self.selectedones.field + "HIGH"
                ]
              );
              let low = Math.round(
                target.tooltipDataItem.dataContext[
                  self.selectedones.field + "LOW"
                ]
              );
              if (low < 0) low = 0;
              var dt = low + " - " + high;
              if (high == low) {
                dt = high;
              }

              if (
                moment(data.date)
                  .startOf("day")
                  .isSameOrAfter(moment(new Date()).startOf("day"))
              ) {
                return `[bold]${self.selectedones.label}[/]

                                                           [font-size: 18px line-height:30px] HI:${high}
                                                            PROJECTED:${proj}
                                                            LO:${low}
                                                            [/]
                                                            MINUTES: ${data.playsecs}\n 
                                                            OPPONENT:${data.opp}\n `;
              } else {
                return `${self.selectedones.label}:${high}\nMINUTES: ${data.playsecs}\n `;
              }
            });

            series.tooltip.pointerOrientation = "down";
            series.tooltip.background.strokeWidth = 0;
            series.tooltip.getFillFromObject = false;
            series.tooltip.background.fill = am4core.color("#11172B");
            series.tooltip.background.fillOpacity = 0.7;
            series.tooltip.height = 320;

            series.fill = am4core.color("#7484a1cc");
            series.stroke = am4core.color("#7484a1cc");

            chart.cursor = new am4charts.XYCursor();
            chart.cursor.lineY.disabled = true;
            chart.cursor.lineX.disabled = true;

            var lineSeriesh = chart.series.push(new am4charts.LineSeries());
            lineSeriesh.dataFields.openValueY = self.selectedones.field + "LOW";
            lineSeriesh.dataFields.valueY = self.selectedones.field + "HIGH";
            lineSeriesh.dataFields.categoryX = "year";

            lineSeriesh.stroke = am4core.color(_colorindex);
            lineSeriesh.strokeWidth = 3;
            lineSeriesh.propertyFields.strokeDasharray = "lineDash";
            lineSeriesh.tooltip.label.textAlign = "middle";

            lineSeriesh.fill = lineSeriesh.stroke;
            lineSeriesh.fillOpacity = 0.8;

            var lineSeries = chart.series.push(new am4charts.LineSeries());
            lineSeries.dataFields.valueY = self.selectedones.field;
            lineSeries.dataFields.categoryX = "year";

            lineSeries.stroke = am4core.color(_colorindex);
            lineSeries.strokeWidth = 3;

            var bullet = lineSeries.bullets.push(new am4charts.Bullet());
            bullet.fill = am4core.color(_colorindex); // tooltips grab fill from parent by default
            var circle = bullet.createChild(am4core.Circle);
            circle.radius = 3;
            circle.fill = am4core.color("#fff");
            circle.strokeWidth = 2;

            valueAxis.renderer.labels.template.fill =
              am4core.color("#7484a1cc");
            categoryAxis.renderer.labels.template.fill =
              am4core.color("#7484a1cc");
            //  self._drawChart(results, JSON.parse(response.data.tend));
            //self._drawSeconds(results, JSON.parse(response.data.tend))
          } else {
            this.shotsloading = false;
            this.noshots = true;
          }
        });
      } else {
        this.shotsloading = false;
      }
    },
  },
  mounted() {
    this.colors = this.chartcolors;
    this._getAttributes();
  },
};
</script>

<style scoped>
.v-tooltip__content {
  max-width: 450px;
}
</style>
