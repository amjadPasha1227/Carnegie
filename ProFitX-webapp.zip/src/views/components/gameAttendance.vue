

<template>  
    <div>
        <div class="widget_block">            
            <div class="widget_body">
                <h2 class="small-heading">PER GAME ATTENDANCE</h2>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "game-attendance",
    
}
</script>
