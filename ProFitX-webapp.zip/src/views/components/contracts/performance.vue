<template>
<div>
    <div id="contractchart" class="timeserieschart" style="height:450px;"></div>
</div>
</template>

<script>
import moment from "moment";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);

export default {
    props: {
        player: {},
        outlooklbl: []
    },
    data: () => ({
        oneyear: null,
        twoyear: null,
        threeyear: null,
        outlook: [],
        selectedvaluesout: [],
        pioffensive: true,
        pidefensive: false,
        impactdata: [],
        top5picks: []
    }),
    methods: {
          printoutlook(seson, rtc) {

              if (seson == "2023-2024") {
                switch (true) {
                    case rtc >= 0 && rtc <= 3000000:
                        return "BENCH"
                    case rtc > 3000000 && rtc <= 6000000:
                        return "2ND UNIT"
                    case rtc > 6000000 && rtc <= 10000000:
                        return "KEY RESERVE"
                    case rtc > 10000000 && rtc <= 15000000:
                        return "STARTER"
                    case rtc > 15000000 && rtc <= 23000000:
                        return "IMPACT STARTER"
                    case rtc > 23000000 && rtc <= 31000000:
                        return "ALL STAR"
                    case rtc > 31000000 && rtc <= 39000000:
                        return "ALL NBA"
                    case rtc > 39000000:
                        return "MVP CANDIDATE"
                }

            }

             if (seson == "2022-2023") {
                switch (true) {
                    case rtc >= 0 && rtc <= 3000000:
                        return "BENCH"
                    case rtc > 3000000 && rtc <= 6000000:
                        return "2ND UNIT"
                    case rtc > 6000000 && rtc <= 10000000:
                        return "KEY RESERVE"
                    case rtc > 10000000 && rtc <= 15000000:
                        return "STARTER"
                    case rtc > 15000000 && rtc <= 23000000:
                        return "IMPACT STARTER"
                    case rtc > 23000000 && rtc <= 31000000:
                        return "ALL STAR"
                    case rtc > 31000000 && rtc <= 39000000:
                        return "ALL NBA"
                    case rtc > 39000000:
                        return "MVP CANDIDATE"
                }

            }
             if (seson == "2021-2022") {
                switch (true) {
                     case rtc >= 0 && rtc <= 2000000:
                        return "BENCH"
                    case rtc > 2000000 && rtc <= 5000000:
                        return "2ND UNIT"
                    case rtc > 5000000 && rtc <= 9000000:
                        return "KEY RESERVE"
                    case rtc > 9000000 && rtc <= 16000000:
                        return "STARTER"
                    case rtc > 16000000 && rtc <= 22000000:
                        return "IMPACT STARTER"
                    case rtc > 22000000 && rtc <= 30000000:
                        return "ALL STAR"
                    case rtc > 30000000 && rtc <= 38000000:
                        return "ALL NBA"
                    case rtc > 38000000:
                        return "MVP CANDIDATE"
                }

            }
             if (seson == "2020-2021") {
                switch (true) {
                      case rtc >= 0 && rtc <= 2000000:
                        return "BENCH"
                    case rtc > 2000000 && rtc <= 5000000:
                        return "2ND UNIT"
                    case rtc > 5000000 && rtc <= 8000000:
                        return "KEY RESERVE"
                    case rtc > 8000000 && rtc <= 15000000:
                        return "STARTER"
                    case rtc > 15000000 && rtc <= 21000000:
                        return "IMPACT STARTER"
                    case rtc > 21000000 && rtc <= 29000000:
                        return "ALL STAR"
                    case rtc > 29000000 && rtc <= 37000000:
                        return "ALL NBA"
                    case rtc > 37000000:
                        return "MVP CANDIDATE"
                }

            }
             if (seson == "2019-2020") {
                switch (true) {
                    case rtc >= 0 && rtc <= 2000000:
                        return "BENCH"
                    case rtc > 2000000 && rtc <= 4000000:
                        return "2ND UNIT"
                    case rtc > 4000000 && rtc <= 7000000:
                        return "KEY RESERVE"
                    case rtc > 7000000 && rtc <= 14000000:
                        return "STARTER"
                    case rtc > 14000000 && rtc <= 20000000:
                        return "IMPACT STARTER"
                    case rtc > 20000000 && rtc <= 28000000:
                        return "ALL STAR"
                    case rtc > 28000000 && rtc <= 36000000:
                        return "ALL NBA"
                    case rtc > 36000000:
                        return "MVP CANDIDATE"
                }

            }
             if (seson == "2018-2019") {
                switch (true) {
                      case rtc >= 0 && rtc <= 3000000:
                        return "BENCH"
                    case rtc > 3000000 && rtc <= 5000000:
                        return "2ND UNIT"
                    case rtc > 5000000 && rtc <= 7000000:
                        return "KEY RESERVE"
                    case rtc > 7000000 && rtc <= 13000000:
                        return "STARTER"
                    case rtc > 13000000 && rtc <= 19000000:
                        return "IMPACT STARTER"
                    case rtc > 19000000 && rtc <= 26000000:
                        return "ALL STAR"
                    case rtc > 26000000 && rtc <= 34000000:
                        return "ALL NBA"
                    case rtc > 34000000:
                        return "MVP CANDIDATE"
                }

            }
             if (seson == "2017-2018") {
                switch (true) {
                     case rtc >= 0 && rtc <= 2000000:
                        return "BENCH"
                    case rtc > 2000000 && rtc <= 4000000:
                        return "2ND UNIT"
                    case rtc > 4000000 && rtc <= 6000000:
                        return "KEY RESERVE"
                    case rtc > 6000000 && rtc <= 11000000:
                        return "STARTER"
                    case rtc > 11000000 && rtc <= 17000000:
                        return "IMPACT STARTER"
                    case rtc > 17000000 && rtc <= 23000000:
                        return "ALL STAR"
                    case rtc > 23000000 && rtc <= 31000000:
                        return "ALL NBA"
                    case rtc > 31000000:
                        return "MVP CANDIDATE"
                }

            }
             if (seson == "2016-2017") {
                switch (true) {
                    case rtc >= 0 && rtc <= 2000000:
                        return "BENCH"
                    case rtc > 2000000 && rtc <= 4000000:
                        return "2ND UNIT"
                    case rtc > 4000000 && rtc <= 7000000:
                        return "KEY RESERVE"
                    case rtc > 7000000 && rtc <= 10000000:
                        return "STARTER"
                    case rtc > 10000000 && rtc <= 15000000:
                        return "IMPACT STARTER"
                    case rtc > 15000000 && rtc <= 21000000:
                        return "ALL STAR"
                    case rtc > 21000000 && rtc <= 26000000:
                        return "ALL NBA"
                    case rtc > 26000000:
                        return "MVP CANDIDATE"
                }

            }

           


        },
        getprofitimpact() {
            var d3 = window.d3;
            this.isloading = true
            var self = this;
            this.serach = {
                "page": 1,
                "perpage": 5,
                "matcher": {
                    "playerId": this.player.PLAYER_NAME
                }
            };
            this.$store
                .dispatch("getProfitImpact", this.serach)
                .then(response => {
                    if (response.error) {
                        Object.assign(this.formerrors, {
                            msg: response.error.message
                        });
                    } else {
                        this.totalCount = response.data.result.totalCount;
                        this.impactdata = response.data.result.list;
                        var data = [{
                                name: "Playmaking",
                                values: []
                            },
                            {
                                name: "Defense",
                                values: []
                            },
                            {
                                name: "Offence",
                                values: []
                            },
                            {
                                name: "Performance",
                                values: []
                            }
                        ];

                        var age = [{
                            name: "Age",
                            values: []
                        }];

                        var p = 0;
                        var _hr = 0;

                        var cdata = [{
                                name: "Actual Earnings",
                                values: []
                            },
                            {
                                name: "Projected Earnings",
                                values: []
                            }
                        ];

                        var routlook = []
                        var rtcs = []
                        var freeagentYear = "280000";
                        if (self.player.fadetails != undefined && self.player.fadetails.FA) {

                            freeagentYear = self.player.fadetails.FA.toString();
                        }

                        var ppdates = []

                        this.impactdata.forEach(function (ide) {
                            var _cs = parseInt(ide.SEASON.split('-')[1]);

                            if (p == 0 && ide.projectionDetails && ide.projectionDetails.PR.length > 0) {

                                cdata[1].values.push({
                                    date: (_cs + 2).toString(),
                                    season: "2023-2024",
                                    price: ide.projectionDetails.PR[1].V,
                                    U: ide.projectionDetails.PR[1].U,
                                    L: ide.projectionDetails.PR[1].L
                                })
                                _hr = ide.projectionDetails.PR[1].U
                                cdata[1].values.push({
                                    date: (_cs + 1).toString(),
                                    season: "2023-2024",
                                    price: ide.projectionDetails.PR[0].V,
                                    U: ide.projectionDetails.PR[0].U,
                                    L: ide.projectionDetails.PR[0].L
                                })

                                cdata[0].values.push({
                                    date: (_cs + 2).toString(),
                                    season: "2022-2023",
                                    price: ide.TC,
                                    U: ide.TC,
                                    L: ide.TC
                                })

                                cdata[0].values.push({
                                    date: (_cs + 1).toString(),
                                    season: "2022-2023",
                                    price: ide.TC,
                                    U: ide.TC,
                                    L: ide.TC
                                })

                            }

                            cdata[0].values.push({
                                date: (_cs).toString(),
                                season: ide.SEASON,
                                price: ide.TC,
                                U: ide.TC,
                                L: ide.TC
                            })
                            cdata[1].values.push({
                                date: (_cs).toString(),
                                price: ide.RTC,
                                season: ide.SEASON,
                                U: ide.RTC,
                                L: ide.RTC
                            })

                            p++;

                        })

                        p = 0;
                        this.impactdata.forEach(function (ide) {
                            var _cs = parseInt(ide.SEASON.split('-')[1]);

                            if (p == 0 && ide.pfDetails != undefined && ide.pfDetails.PR != undefined) {
                                data[0].values.push({
                                    date: (_cs + 2).toString(),
                                    season: "2023-2024",
                                    price: ide.pfDetails.PM[1].V.toFixed(2),
                                    U: ide.pfDetails.PM[1].U,
                                    L: ide.pfDetails.PM[1].L

                                })
                                data[1].values.push({
                                    date: (_cs + 2).toString(),
                                    season: "2023-2024",
                                    price: ide.pfDetails.DF[1].V.toFixed(2),
                                    U: ide.pfDetails.DF[1].U,
                                    L: ide.pfDetails.DF[1].L
                                })
                                data[2].values.push({
                                    date: (_cs + 2).toString(),
                                    season: "2023-2024",
                                    price: ide.pfDetails.OF[1].V.toFixed(2),
                                    U: ide.pfDetails.OF[1].U,
                                    L: ide.pfDetails.OF[1].L
                                })
                                data[3].values.push({
                                    date: (_cs + 2).toString(),
                                    season: "2023-2024",
                                    price: ide.pfDetails.PR[1].V.toFixed(2),
                                    U: ide.pfDetails.PR[1].U,
                                    L: ide.pfDetails.PR[1].L
                                })

                                data[0].values.push({
                                    date: (_cs + 1).toString(),
                                    season: "2022-2023",
                                    price: ide.pfDetails.PM[0].V.toFixed(2),
                                    U: ide.pfDetails.PM[0].U,
                                    L: ide.pfDetails.PM[0].L
                                })
                                data[1].values.push({
                                    date: (_cs + 2).toString(),
                                    season: "2022-2023",
                                    price: ide.pfDetails.DF[0].V.toFixed(2),
                                    U: ide.pfDetails.DF[0].U.toFixed(2),
                                    L: ide.pfDetails.DF[0].L.toFixed(2)
                                })
                                data[2].values.push({
                                    date: (_cs + 2).toString(),
                                    season: "2022-2023",
                                    price: ide.pfDetails.OF[0].V.toFixed(2),
                                    U: ide.pfDetails.OF[0].U.toFixed(2),
                                    L: ide.pfDetails.OF[0].L.toFixed(2)
                                })
                                data[3].values.push({
                                    date: (_cs + 2).toString(),
                                    season: "2022-2023",
                                    price: ide.pfDetails.PR[0].V.toFixed(2),
                                    U: ide.pfDetails.PR[0].U.toFixed(2),
                                    L: ide.pfDetails.PR[0].L.toFixed(2)
                                })

                                age[0].values.push({
                                    date: (_cs + 2).toString(),
                                    age: parseInt(ide.AGE) + 2
                                })

                                age[0].values.push({
                                    date: (_cs + 1).toString(),
                                    age: parseInt(ide.AGE) + 1
                                })

                                if (ide.outlook) routlook.push(ide.outlook.OUTLOOK)
                                if (ide.outlook) routlook.push(ide.outlook.OUTLOOK)

                            }

                            if (ide.outlook) routlook.push(ide.outlook.OUTLOOK)

                            var _pm = ide.PLAYMAKING;
                            if (!_pm) {
                                _pm = ide.ATTR.Playmaking
                            }
                            var _df = ide.DEFENSE;
                            if (!_df) {
                                _df = ide.ATTR.Defense
                            }
                            var _of = ide.OFFENCE;
                            if (!_of) {
                                _of = ide.ATTR.Offense
                            }
                            data[0].values.push({
                                date: (_cs).toString(),
                                season: ide.SEASON,
                                price: (_pm * 100).toFixed(2),
                                U: (_pm * 100).toFixed(2),
                                L: (_pm * 100).toFixed(2)
                            })
                            data[1].values.push({
                                date: (_cs).toString(),
                                season: ide.SEASON,
                                price: (_df * 100).toFixed(2),
                                U: (_df * 100).toFixed(2),
                                L: (_df * 100).toFixed(2)
                            })
                            data[2].values.push({
                                date: (_cs).toString(),
                                season: ide.SEASON,
                                price: (_of * 100).toFixed(2),
                                U: (_of * 100).toFixed(2),
                                L: (_of * 100).toFixed(2)
                            })
                            data[3].values.push({
                                date: (_cs).toString(),
                                season: ide.SEASON,
                                price: ide.RTP.toFixed(2),
                                U: ide.RTP.toFixed(2),
                                L: ide.RTP.toFixed(2)
                            })

                            age[0].values.push({
                                date: (_cs).toString(),
                                age: parseInt(ide.AGE)
                            })

                            p++;
                        })

                        var _dt = routlook.reverse();

                        if (_dt.length > 0) {
                            var _t = _dt[_dt.length - 1];
                            _dt.push(_t);
                            var _at = _dt[_dt.length - 1];
                            _dt.push(_at)
                            var _aat = _dt[_dt.length - 1];
                            _dt.push(_aat)
                        }

                        this.outlook = routlook.reverse();

                        var _hrtc = this.lodash.maxBy(data[1].values, 'price').price;
                        var _htc = this.lodash.maxBy(data[0].values, 'price').price;
                        if (_hrtc < _htc) _hrtc = _htc
                        if (_hr > _hrtc) _hrtc = _hr

                        var _mrtc = this.lodash.minBy(data[1].values, 'price').price;
                        var _mtc = this.lodash.minBy(data[0].values, 'price').price;
                        if (_mrtc > _mtc) _mrtc = _mtc

                        /* Format Data */
                        var parseDate = d3.timeParse("%Y");
                        var ndats = [];
                        data[0].values.forEach(function (d, index) {

                            var _n = 0;
                            var _currentseason = parseInt(moment(d.date).format("Y"));
                            _currentseason = d.season;
                            if (freeagentYear == moment(d.date).format("Y")) {
                                _n = _htc
                            }

                            ndats.push({
                                category: _currentseason,
                                playmaking: d.price,
                                playmakingu: d.U,
                                playmakingl: d.L,
                                indexer:index,
                                rtc: 0,
                                df: 0,
                                dfu: 0,
                                dfl: 0,
                                of: 0,
                                ou: 0,
                                ol: 0,
                                pf: 0,
                                pu: 0,
                                pl: 0,
                                ageimpact: 0
                            })

                        });

                        data[1].values.forEach(function (d, index) {
                            ndats[index]['df'] = d.price;
                            ndats[index]['dfu'] = d.U;
                            ndats[index]['dfl'] = d.L;

                        });
                        data[2].values.forEach(function (d, index) {
                            ndats[index]['of'] = d.price;
                            ndats[index]['ou'] = d.U;
                            ndats[index]['ol'] = d.L;

                        });

                        data[3].values.forEach(function (d, index) {
                            ndats[index]['pf'] = d.price;
                            ndats[index]['pu'] = d.U;
                            ndats[index]['pl'] = d.L;

                        });

                        ndats.forEach(function (d, index) {
                            var ageimpact = ((d.pf / d.pf) - 1) * 100
                            if (index > 0) {
                                ageimpact = ((d.pf / ndats[index - 1].pf) - 1) * 100

                            }
                            ndats[index]['ageimpact'] = ageimpact;

                        })

                        cdata[1].values.forEach(function (d, index) {

                            //  console.log(ndats[index]['rtc'])
                            if (ndats[index]) {

                                ndats[index]['rtc'] = Math.round(d.price);

                            }

                        });

                        ndats = ndats.reverse();

                        // Create chart instance
                        var chart = am4core.create("contractchart", am4charts.XYChart);

                        // Add data
                        chart.data = ndats;
                        chart.paddingTop = 50;

                        // Create axes
                        var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
                        categoryAxis.dataFields.category = "category";

                        categoryAxis.renderer.grid.template.location = 0;
                        categoryAxis.renderer.minGridDistance = 5;

                        categoryAxis.renderer.labels.template.rotation = 0;
                        categoryAxis.renderer.grid.template.strokeWidth = 0;
                        //categoryAxis.renderer.minGridDistance = 30;

                        categoryAxis.renderer.labels.template.events.on("over", function (ev) {
                            var point = categoryAxis.categoryToPoint(ev.target.dataItem.category);
                            chart.cursor.triggerMove(point, "soft");
                        });

                        categoryAxis.renderer.labels.template.events.on("out", function (ev) {
                            var point = categoryAxis.categoryToPoint(ev.target.dataItem.category);
                            chart.cursor.triggerMove(point, "none");
                        });
                        ndats.forEach(function (values, index) {
                            if (ndats[index]) {
                                let offrange2 = categoryAxis.axisRanges.create();
                                var start = ndats[index].category;
                                if (index > 0) {
                                    start = ndats[index].category;
                                }

                                var color = "#8790B1";
                                var fillOpacity = 0.1;
                                if (index % 2 == 0) {
                                    color = "#000"
                                    fillOpacity = 0;
                                }
                                var _cat = self.printoutlook(ndats[index].category, ndats[index].rtc)
                                offrange2.category = start;
                                offrange2.endCategory = ndats[index].category;
                                offrange2.axisFill.fill = am4core.color(color);
                                offrange2.axisFill.fillOpacity = fillOpacity;
                                offrange2.label.rotation = 360
                                offrange2.label.dy = -390
                                offrange2.label.dx = 0
                                offrange2.label.inside = true
                                offrange2.label.text = _cat;

                            }

                        })

                        var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
                        //valueAxis.tooltip.disabled = true;

                        chart.cursor = new am4charts.XYCursor();
                        chart.cursor.lineY.disabled = true;
                        chart.cursor.lineX.disabled = true;

                        var valueAxis2 = chart.yAxes.push(new am4charts.ValueAxis());
                        valueAxis2.renderer.opposite = true;
                        valueAxis2.renderer.grid.template.disabled = true;

                        var series1x = chart.series.push(new am4charts.LineSeries());
                        series1x.dataFields.openValueY = "playmakingl";
                        series1x.dataFields.customValue = "playmaking"
                        series1x.dataFields.valueY = "playmakingu";
                        series1x.dataFields.categoryX = "category";

                        series1x.stroke = am4core.color('#4B58AA');
                        series1x.strokeWidth = 0;
                        series1x.propertyFields.strokeDasharray = "lineDash";
                        series1x.tooltip.label.textAlign = "middle";

                        series1x.fill = am4core.color('#4B58AA');
                        series1x.fillOpacity = 0.3;

                        // Create series
                        var series1 = chart.series.push(new am4charts.LineSeries());
                        series1.dataFields.valueY = "playmaking";
                        series1.dataFields.categoryX = "category";
                        series1.strokeWidth = 3;
                        series1.stroke = am4core.color('#4B58AA');

                        var bullet = series1.bullets.push(new am4charts.Bullet());
                        bullet.fill = am4core.color('#4B58AA'); // tooltips grab fill from parent by default
                        var circle = bullet.createChild(am4core.Circle);
                        circle.radius = 6;
                        circle.fill = am4core.color("#4B58AA");
                        circle.fillOpacity = 1
                        circle.strokeWidth = 4;

                        series1x.tooltipHTML = `<div class="roleslist_tooltips roleslist_tooltipsleft" ><div><ul><li class="classapr{indexer}"> HI:&nbsp;&nbsp;{valueY}</li><li class="classapr{indexer}">PROJECTED:&nbsp;&nbsp;{customValue}</li><li class="classakr{indexer}">Playmaking:&nbsp;&nbsp;{customValue}</li><li class="classapr{indexer}">LOW:&nbsp;&nbsp;{openValueY}</li></ul></div></div>`;

                        series1x.tooltip.pointerOrientation = "horizontal";
                        series1x.tooltip.background.strokeWidth = 0;
                        series1x.tooltip.getFillFromObject = false;
                        series1x.tooltip.background.fill = am4core.color("#8790B1");
                        series1x.tooltip.background.fillOpacity = 0.7;

                        var lineSerieshxz = chart.series.push(new am4charts.LineSeries());
                        lineSerieshxz.dataFields.openValueY = "dfl";
                        lineSerieshxz.dataFields.customValue = "df"
                        lineSerieshxz.dataFields.valueY = "dfu";
                        lineSerieshxz.dataFields.categoryX = "category";

                        lineSerieshxz.stroke = am4core.color('#E55400');
                        lineSerieshxz.strokeWidth = 0;
                        lineSerieshxz.propertyFields.strokeDasharray = "lineDash";
                        lineSerieshxz.tooltip.label.textAlign = "middle";

                        lineSerieshxz.fill = am4core.color('#E55400');
                        lineSerieshxz.fillOpacity = 0.3;

                        var lineSeriesh = chart.series.push(new am4charts.LineSeries());
                        lineSeriesh.dataFields.valueY = "df";
                        lineSeriesh.dataFields.categoryX = "category";
                        lineSeriesh.stroke = am4core.color('#E55400');
                        lineSeriesh.strokeWidth = 3;
                        lineSeriesh.propertyFields.strokeDasharray = "lineDash";
                        lineSeriesh.tooltip.label.textAlign = "middle";

                        var dfbullet = lineSeriesh.bullets.push(new am4charts.Bullet());
                        dfbullet.fill = am4core.color('#E55400'); // tooltips grab fill from parent by default
                        var dfcircle = dfbullet.createChild(am4core.Circle);
                        dfcircle.radius = 6;
                        dfcircle.fill = am4core.color("#E55400");
                        dfcircle.fillOpacity = 1
                        dfcircle.strokeWidth = 4;
                       // lineSerieshxz.tooltipHTML = `<div class="roleslist_tooltips roleslist_tooltipsleft" ><div><ul><li class="classapr{indexer}"> HI:&nbsp;&nbsp;$ {valueY}</li><li class="classapr{indexer}">PROJECTED:&nbsp;&nbsp;$ {customValue}</li><li class="classapr{indexer}">LOW:&nbsp;&nbsp;$ {openValueY}</li></ul></div></div>`;
                        lineSerieshxz.tooltipHTML = `<div class="roleslist_tooltips roleslist_tooltipsleft" ><div><ul><li class="classapr{indexer}"> HI:&nbsp;&nbsp;{valueY}</li><li class="classapr{indexer}">PROJECTED:&nbsp;&nbsp;{customValue}</li><li class="classakr{indexer}">Defense:&nbsp;&nbsp;{customValue}</li><li class="classapr{indexer}">LOW:&nbsp;&nbsp;{openValueY}</li></ul></div></div>`;

                        //lineSeriesh.tooltipHTML = `<div class="roleslist_tooltips twocolumn" ><div><ul><li> {valueY}</li></ul></div></div>`;
                        lineSerieshxz.tooltip.pointerOrientation = "horizontal";
                        lineSerieshxz.tooltip.background.strokeWidth = 0;
                        lineSerieshxz.tooltip.getFillFromObject = false;
                        lineSerieshxz.tooltip.background.fill = am4core.color("#8790B1");
                        lineSerieshxz.tooltip.background.fillOpacity = 0.7;

                        var lineSerieshxzo = chart.series.push(new am4charts.LineSeries());
                        lineSerieshxzo.dataFields.openValueY = "ol";
                        lineSerieshxzo.dataFields.customValue = "of"
                        lineSerieshxzo.dataFields.valueY = "ou";
                        lineSerieshxzo.dataFields.categoryX = "category";

                        lineSerieshxzo.stroke = am4core.color('#47A01A');
                        lineSerieshxzo.strokeWidth = 0;
                        lineSerieshxzo.propertyFields.strokeDasharray = "lineDash";
                        lineSerieshxzo.tooltip.label.textAlign = "middle";

                        lineSerieshxzo.fill = am4core.color('#47A01A');
                        lineSerieshxzo.fillOpacity = 0.3;

                        var series2 = chart.series.push(new am4charts.LineSeries());
                        series2.dataFields.valueY = "of";
                        series2.dataFields.categoryX = "category";
                        series2.strokeWidth = 3;
                        series2.stroke = am4core.color('#47A01A');

                        var bullet2 = series2.bullets.push(new am4charts.Bullet());
                        bullet2.fill = am4core.color('#47A01A'); // tooltips grab fill from parent by default
                        var circle2 = bullet2.createChild(am4core.Circle);
                        circle2.radius = 6;
                        circle2.fill = am4core.color("#47A01A");
                        circle2.strokeWidth = 4;
                        
                       // lineSerieshxzo.tooltipHTML = `<div class="roleslist_tooltips roleslist_tooltipsleft" ><div><ul><li class="classapr{indexer}"> HI:&nbsp;&nbsp;$ {valueY}</li><li class="classapr{indexer}">PROJECTED:&nbsp;&nbsp;$ {customValue}</li><li class="classapr{indexer}">LOW:&nbsp;&nbsp;$ {openValueY}</li></ul></div></div>`;
                        lineSerieshxzo.tooltipHTML = `<div class="roleslist_tooltips roleslist_tooltipsleft" ><div><ul><li class="classapr{indexer}"> HI:&nbsp;&nbsp; {valueY}</li><li class="classapr{indexer}">PROJECTED:&nbsp;&nbsp;{customValue}</li><li class="classakr{indexer}">Offense:&nbsp;&nbsp;{customValue}</li><li class="classapr{indexer}">LOW:&nbsp;&nbsp;{openValueY}</li></ul></div></div>`;

                        lineSerieshxzo.tooltip.pointerOrientation = "horizontal";
                        lineSerieshxzo.tooltip.background.strokeWidth = 0;
                        lineSerieshxzo.tooltip.getFillFromObject = false;
                        lineSerieshxzo.tooltip.background.fill = am4core.color("#8790B1");
                        lineSerieshxzo.tooltip.background.fillOpacity = 0.7;

                        categoryAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
                        valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
                        valueAxis.renderer.inside = true
                        valueAxis.renderer.labels.template.visible = false;
                        valueAxis2.renderer.inside = true
                        valueAxis2.renderer.labels.template.visible = false;

                        let _sdate = "2021-2022";
                        let _edate = "2021-2022";

                        let offrange = categoryAxis.axisRanges.create();

                        offrange.category = _sdate;
                        offrange.endCategory = _edate;

                        offrange.axisFill.fill = am4core.color('#000000');
                        offrange.axisFill.fillOpacity = 1;

                        offrange.label.inside = true
                        offrange.label.text = "CURRENT SEASON";
                        offrange.label.textAlign = "end"
                        offrange.label.height = 310
                        offrange.label.opacity = 0.3;
                        offrange.label.rotation = 270;
                        offrange.label.dy = -180
                        offrange.label.dx = -35
                        offrange.label.adapter.add("horizontalCenter", function () {
                            return "middle";
                        });
                        offrange.label.fill = am4core.color("#7484a1cc");
                        offrange.label.fontSize = 30
                        offrange.label.fontFamily = 'rajdhanisemibold';

                    }

                });

        }

    },
    mounted() {
        this.getprofitimpact();
    }
};
</script>
