<template>
<div>
    <div id="contractchart" class="timeserieschart" style="height:450px;"></div>
</div>
</template>

<script>
import moment from "moment";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);

export default {
    props: {
        player: {},
        outlooklbl: []
    },
    data: () => ({
        oneyear: null,
        twoyear: null,
        threeyear: null,
        outlook: [],
        selectedvaluesout: [],
        pioffensive: true,
        pidefensive: false,
        impactdata: [],
        top5picks: []
    }),
    methods: {
            printoutlook(seson, rtc) {

                 if (seson == "2023-2024") {
                switch (true) {
                    case rtc >= 0 && rtc <= 3000000:
                        return "BENCH"
                    case rtc > 3000000 && rtc <= 6000000:
                        return "2ND UNIT"
                    case rtc > 6000000 && rtc <= 10000000:
                        return "KEY RESERVE"
                    case rtc > 10000000 && rtc <= 15000000:
                        return "STARTER"
                    case rtc > 15000000 && rtc <= 23000000:
                        return "IMPACT STARTER"
                    case rtc > 23000000 && rtc <= 31000000:
                        return "ALL STAR"
                    case rtc > 31000000 && rtc <= 39000000:
                        return "ALL NBA"
                    case rtc > 39000000:
                        return "MVP CANDIDATE"
                }

            }

             if (seson == "2022-2023") {
                switch (true) {
                    case rtc >= 0 && rtc <= 3000000:
                        return "BENCH"
                    case rtc > 3000000 && rtc <= 6000000:
                        return "2ND UNIT"
                    case rtc > 6000000 && rtc <= 10000000:
                        return "KEY RESERVE"
                    case rtc > 10000000 && rtc <= 15000000:
                        return "STARTER"
                    case rtc > 15000000 && rtc <= 23000000:
                        return "IMPACT STARTER"
                    case rtc > 23000000 && rtc <= 31000000:
                        return "ALL STAR"
                    case rtc > 31000000 && rtc <= 39000000:
                        return "ALL NBA"
                    case rtc > 39000000:
                        return "MVP CANDIDATE"
                }

            }
             if (seson == "2021-2022") {
                switch (true) {
                     case rtc >= 0 && rtc <= 2000000:
                        return "BENCH"
                    case rtc > 2000000 && rtc <= 5000000:
                        return "2ND UNIT"
                    case rtc > 5000000 && rtc <= 9000000:
                        return "KEY RESERVE"
                    case rtc > 9000000 && rtc <= 16000000:
                        return "STARTER"
                    case rtc > 16000000 && rtc <= 22000000:
                        return "IMPACT STARTER"
                    case rtc > 22000000 && rtc <= 30000000:
                        return "ALL STAR"
                    case rtc > 30000000 && rtc <= 38000000:
                        return "ALL NBA"
                    case rtc > 38000000:
                        return "MVP CANDIDATE"
                }

            }
             if (seson == "2020-2021") {
                switch (true) {
                      case rtc >= 0 && rtc <= 2000000:
                        return "BENCH"
                    case rtc > 2000000 && rtc <= 5000000:
                        return "2ND UNIT"
                    case rtc > 5000000 && rtc <= 8000000:
                        return "KEY RESERVE"
                    case rtc > 8000000 && rtc <= 15000000:
                        return "STARTER"
                    case rtc > 15000000 && rtc <= 21000000:
                        return "IMPACT STARTER"
                    case rtc > 21000000 && rtc <= 29000000:
                        return "ALL STAR"
                    case rtc > 29000000 && rtc <= 37000000:
                        return "ALL NBA"
                    case rtc > 37000000:
                        return "MVP CANDIDATE"
                }

            }
             if (seson == "2019-2020") {
                switch (true) {
                    case rtc >= 0 && rtc <= 2000000:
                        return "BENCH"
                    case rtc > 2000000 && rtc <= 4000000:
                        return "2ND UNIT"
                    case rtc > 4000000 && rtc <= 7000000:
                        return "KEY RESERVE"
                    case rtc > 7000000 && rtc <= 14000000:
                        return "STARTER"
                    case rtc > 14000000 && rtc <= 20000000:
                        return "IMPACT STARTER"
                    case rtc > 20000000 && rtc <= 28000000:
                        return "ALL STAR"
                    case rtc > 28000000 && rtc <= 36000000:
                        return "ALL NBA"
                    case rtc > 36000000:
                        return "MVP CANDIDATE"
                }

            }
             if (seson == "2018-2019") {
                switch (true) {
                      case rtc >= 0 && rtc <= 3000000:
                        return "BENCH"
                    case rtc > 3000000 && rtc <= 5000000:
                        return "2ND UNIT"
                    case rtc > 5000000 && rtc <= 7000000:
                        return "KEY RESERVE"
                    case rtc > 7000000 && rtc <= 13000000:
                        return "STARTER"
                    case rtc > 13000000 && rtc <= 19000000:
                        return "IMPACT STARTER"
                    case rtc > 19000000 && rtc <= 26000000:
                        return "ALL STAR"
                    case rtc > 26000000 && rtc <= 34000000:
                        return "ALL NBA"
                    case rtc > 34000000:
                        return "MVP CANDIDATE"
                }

            }
             if (seson == "2017-2018") {
                switch (true) {
                     case rtc >= 0 && rtc <= 2000000:
                        return "BENCH"
                    case rtc > 2000000 && rtc <= 4000000:
                        return "2ND UNIT"
                    case rtc > 4000000 && rtc <= 6000000:
                        return "KEY RESERVE"
                    case rtc > 6000000 && rtc <= 11000000:
                        return "STARTER"
                    case rtc > 11000000 && rtc <= 17000000:
                        return "IMPACT STARTER"
                    case rtc > 17000000 && rtc <= 23000000:
                        return "ALL STAR"
                    case rtc > 23000000 && rtc <= 31000000:
                        return "ALL NBA"
                    case rtc > 31000000:
                        return "MVP CANDIDATE"
                }

            }
             if (seson == "2016-2017") {
                switch (true) {
                    case rtc >= 0 && rtc <= 2000000:
                        return "BENCH"
                    case rtc > 2000000 && rtc <= 4000000:
                        return "2ND UNIT"
                    case rtc > 4000000 && rtc <= 7000000:
                        return "KEY RESERVE"
                    case rtc > 7000000 && rtc <= 10000000:
                        return "STARTER"
                    case rtc > 10000000 && rtc <= 15000000:
                        return "IMPACT STARTER"
                    case rtc > 15000000 && rtc <= 21000000:
                        return "ALL STAR"
                    case rtc > 21000000 && rtc <= 26000000:
                        return "ALL NBA"
                    case rtc > 26000000:
                        return "MVP CANDIDATE"
                }

            }

           


        },
        getprofitimpact() {
            var d3 = window.d3;
            this.isloading = true
            var self = this;
            this.serach = {
                "page": 1,
                "perpage": 5,
                "matcher": {
                    "playerId": this.player.PLAYER_NAME
                }
            };
            this.$store
                .dispatch("getProfitImpact", this.serach)
                .then(response => {
                    if (response.error) {
                        Object.assign(this.formerrors, {
                            msg: response.error.message
                        });
                    } else {
                        this.totalCount = response.data.result.totalCount;
                        this.impactdata = response.data.result.list;
                        var data = [{
                                name: "Actual Earnings",
                                values: []
                            },
                            {
                                name: "Projected Earnings",
                                values: []
                            }
                        ];

                        var age = [{
                            name: "Age",
                            values: []
                        }];

                        var p = 0;
                        var _hr = 0;

                        var routlook = []
                        var freeagentYear = "280000";
                        if (self.player.FA) {

                            freeagentYear = self.player.FA.toString();
                        }

                        this.impactdata.forEach(function (ide) {
                            var _cs = parseInt(ide.SEASON.split('-')[1]);


                            if (p == 0 && ide.projectionDetails && ide.projectionDetails.PR.length > 0) {

                                data[1].values.push({
                                    date: (_cs + 2).toString(),
                                    season:"2022-2024",
                                    price: ide.projectionDetails.PR[1].V,
                                    U: ide.projectionDetails.PR[1].U,
                                    L: ide.projectionDetails.PR[1].L
                                })
                                _hr = ide.projectionDetails.PR[1].U
                                data[1].values.push({
                                    date: (_cs + 1).toString(),
                                    season:"2022-2023",
                                    price: ide.projectionDetails.PR[0].V,
                                    U: ide.projectionDetails.PR[0].U,
                                    L: ide.projectionDetails.PR[0].L
                                })


                if(self.player["2023-2024"]){

                         data[0].values.push({
                                      season:"2023-2024",
                                    date: (_cs + 2).toString(),
                                    price: self.player["2023-2024"],
                                    U: self.player["2023-2024"],
                                    L: self.player["2023-2024"]
                                })
                }else{

                        data[0].values.push({
                                      season:"2023-2024",
                                    date: (_cs + 2).toString(),
                                    price: ide.TC,
                                    U: ide.TC,
                                    L: ide.TC
                                })
                }
                            
                if(self.player["2022-2023"]){
                           data[0].values.push({
                                    date: (_cs + 1).toString(),
                                    season:"2022-2023",
                                    price: self.player["2022-2023"],
                                    U: self.player["2022-2023"],
                                    L: self.player["2022-2023"]
                                })
                }else{

       data[0].values.push({
                                    date: (_cs + 1).toString(),
                                    season:"2022-2023",
                                    price: self.player["2022-2023"],
                                    U: self.player["2022-2023"],
                                    L: self.player["2022-2023"]
                                })

                }

                         
                                age[0].values.push({
                                    date: (_cs + 2).toString(),
                                    age: ide.AGE + 2
                                })

                                age[0].values.push({
                                    date: (_cs + 1).toString(),
                                    age: ide.AGE + 1
                                })

                                if (ide.outlook) routlook.push(ide.outlook.OUTLOOK)
                                if (ide.outlook) routlook.push(ide.outlook.OUTLOOK)

                            }

                            if (ide.outlook) routlook.push(ide.outlook.OUTLOOK)
                            data[0].values.push({
                                date: (_cs).toString(),
                                season:ide.SEASON,
                                price: ide.TC,
                                U: ide.TC,
                                L: ide.TC
                            })
                            data[1].values.push({
                                date: (_cs).toString(),
                                season:ide.SEASON,
                                price: ide.RTC,
                                U: ide.RTC,
                                L: ide.RTC
                            })
                            age[0].values.push({
                                date: (_cs).toString(),
                                age: ide.AGE
                            })

                            p++;

                        })

                        var _dt = routlook.reverse();

                        if (_dt.length > 0) {
                            var _t = _dt[_dt.length - 1];
                            _dt.push(_t);
                            var _at = _dt[_dt.length - 1];
                            _dt.push(_at)
                            var _aat = _dt[_dt.length - 1];
                            _dt.push(_aat)
                        }

                        this.outlook = routlook.reverse();

                        var _hrtc = this.lodash.maxBy(data[1].values, 'price').price;
                        var _htc = this.lodash.maxBy(data[0].values, 'price').price;
                        if (_hrtc < _htc) _hrtc = _htc
                        if (_hr > _hrtc) _hrtc = _hr

                        var _mrtc = this.lodash.minBy(data[1].values, 'price').price;
                        var _mtc = this.lodash.minBy(data[0].values, 'price').price;
                        if (_mrtc > _mtc) _mrtc = _mtc

                        /* Format Data */
                        var parseDate = d3.timeParse("%Y");
                        var ndats = [];

                                            
                        data[0].values.forEach(function (d, index) {

                            var _n = 0;

                                var indexerpt= 0;
                            if(index == 0){
                               indexerpt = 1
                            }
                              if(index == 1){
                               indexerpt = 2
                            }

                               var _currentseason = parseInt(moment(d.date).format("Y"));
                         
                            _currentseason = (_currentseason - 1) + "-" + _currentseason
                            _currentseason= d.season;

                        
                            if (parseInt(moment(d.date).format("Y"))  >  parseInt(freeagentYear) ) {

                                ndats.push({
                                    linecolor:am4core.color('#47A01A'),
                                    dotcolor:am4core.color('#47A01A'),
                                    category: _currentseason,
                                    rtc: 0,
                                    indexer:index,
                                    indexerp:indexerpt,
                                    rcu: 0,
                                    rcl: 0,
                                    ageimpact: 0,
                                    freeagent: _n
                                })

                            } else {

                                ndats.push({
                                     linecolor:am4core.color('#47A01A'),
                                    dotcolor:am4core.color('#47A01A'),
                                    category: _currentseason,
                                    tc: d.price,
                                    tcu: d.U,
                                    indexer:index,
                                    indexerp:indexerpt,
                                    tcl: d.L,
                                    age:0,
                                    rtc: 0,
                                    rcu: 0,
                                    rcl: 0,
                                    ageimpact: 0,
                                    freeagent: _n
                                })

                            }

                        });

                        data[1].values.forEach(function (d, index) {

                                 if(index == 0){
                                       ndats[index]['linecolor'] = am4core.color('#fac126');
                                        ndats[index]['dotcolor'] = am4core.color('#fac126');

                            }
                              if(index == 1){
                                       ndats[index]['linecolor'] = am4core.color('#fac126');
                                    ndats[index]['dotcolor'] = am4core.color('#fac126');

                            }
                              if(index == 2){
                                       ndats[index]['linecolor'] = am4core.color('#fac126');
                                       ndats[index]['dotcolor'] = am4core.color('#47A01A');
                            }

                            ndats[index]['rtc'] = Math.round(d.price).toFixed(0);
                            ndats[index]['rcu'] = Math.round(d.U).toFixed(0);
                            ndats[index]['rcl'] = Math.round(d.L).toFixed(0)
                           ndats[index]['age'] = age[0].values[index].age   
                        });
                        var _oneyear = data[1].values[0].price;
                        var _twoyear = data[1].values[0].price + data[1].values[1].price
                        var _threeyear = data[1].values[0].price + data[1].values[1].price + data[1].values[2].price + data[1].values[2].price
                                              ndats.forEach(function (d, index) {

                                                    if(index!=0){

                            ndats[index]['age'] = ndats[index-1]['age']-1;

                                                    }

                                              })
                      
                      ndats = ndats.reverse();

                          ndats.forEach(function (d, index) {

                            if (d.category.includes(freeagentYear+"-")) {
                                ndats[index]['freeagent'] = _hrtc;
                                delete  ndats[index]['tc'];

                            }

                             if (ndats[index]['tc'] == 0){
                                delete  ndats[index]['tc'];


                            }

                            var ageimpact = ((d.rtc / d.rtc) - 1) * 100
                            if (index > 0) {
                                ageimpact = ((d.rtc / ndats[index - 1].rtc) - 1) * 100

                            }
                            ndats[index]['ageimpact'] = ageimpact.toFixed(2);

                        })
                        self.twoyear = _twoyear
                        self.oneyear = _oneyear
                        self.threeyear = _threeyear

                        // Create chart instance
                        var chart = am4core.create("contractchart", am4charts.XYChart);

                        // Add data
                        chart.data = ndats;
                        chart.paddingTop = 50;

                        // Create axes
                        var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
                        categoryAxis.dataFields.category = "category";

                        categoryAxis.renderer.grid.template.location = 0;
                        categoryAxis.renderer.minGridDistance = 5;

                        categoryAxis.renderer.labels.template.rotation = 0;
       categoryAxis.renderer.grid.template.strokeWidth = 0;
                        //categoryAxis.renderer.minGridDistance = 30;

                        categoryAxis.renderer.labels.template.events.on("over", function (ev) {
                            var point = categoryAxis.categoryToPoint(ev.target.dataItem.category);
                            chart.cursor.triggerMove(point, "soft");
                        });

                        categoryAxis.renderer.labels.template.events.on("out", function (ev) {
                            var point = categoryAxis.categoryToPoint(ev.target.dataItem.category);
                            chart.cursor.triggerMove(point, "none");
                        });

                        ndats.forEach(function (values, index) {

                            if (ndats[index]) {
                                let offrange2 = categoryAxis.axisRanges.create();
                                var start = ndats[index].category;
                                if (index > 0) {
                                    start = ndats[index].category;
                                }

                                var color = "#8790B1";
                                var fillOpacity = 0.1;
                                if (index % 2 == 0) {
                                    color = "#000"
                                    fillOpacity = 0;
                                }

                                var _cat = self.printoutlook(ndats[index].category,ndats[index].rtc)
                                offrange2.category = ndats[index].category;
                                offrange2.endCategory = ndats[index].category;
                                offrange2.axisFill.fill = am4core.color(color);
                                offrange2.axisFill.fillOpacity = fillOpacity;
                                offrange2.label.rotation = 360
                                offrange2.label.dy = -390
                                offrange2.label.dx = 0
                                offrange2.label.inside = true
                                offrange2.label.text = _cat;

                            }

                        })

                        var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
                        //valueAxis.tooltip.disabled = true;

                        chart.cursor = new am4charts.XYCursor();
                        chart.cursor.lineY.disabled = true;
                        chart.cursor.lineX.disabled = true;

                        var valueAxis2 = chart.yAxes.push(new am4charts.ValueAxis());
                        valueAxis2.renderer.opposite = true;
                        valueAxis2.renderer.grid.template.disabled = true;

                        var seriesage = chart.series.push(new am4charts.LineSeries());
                        seriesage.dataFields.valueY = "ageimpact";
                        seriesage.dataFields.categoryX = "category";
                        seriesage.strokeWidth = 3;
                        seriesage.strokeDasharray = "3,3"
                        seriesage.yAxis = valueAxis2;

                        seriesage.stroke = am4core.color('#FFE200');

                                                seriesage.tooltipHTML = `<div class="roleslist_tooltips " ><div><ul><li> AGE: {age}</li><li> AGE IMPACT: {ageimpact}%</li></ul></div></div>`;
                        seriesage.tooltip.pointerOrientation = "horizontal";
                        seriesage.tooltip.background.strokeWidth = 0;
                        seriesage.tooltip.getFillFromObject = false;
                        seriesage.tooltip.background.fill = am4core.color("#8790B1");
                        seriesage.tooltip.background.fillOpacity = 0.7;

                        var bulletage = seriesage.bullets.push(new am4charts.Bullet());
                        bulletage.fill = am4core.color('#FFE200'); // tooltips grab fill from parent by default
                        var circleage = bulletage.createChild(am4core.Circle);
                        circleage.radius = 6;
                        circleage.fill = am4core.color("#FFE200");
                        circleage.fillOpacity = 0.2;
                        circleage.strokeDasharray = "1,1"
                        circleage.strokeWidth = 4;

                        // Create series
                        var series1 = chart.series.push(new am4charts.LineSeries());
                        series1.dataFields.valueY = "tc";
                        series1.dataFields.categoryX = "category";
                        series1.strokeWidth = 3;
                        series1.stroke = am4core.color('#E55400');

                        var bullet = series1.bullets.push(new am4charts.Bullet());
                        bullet.fill = am4core.color('#E55400'); // tooltips grab fill from parent by default
                        var circle = bullet.createChild(am4core.Circle);
                        circle.radius = 6;
                        circle.fill = am4core.color("#E55400");
                        circle.fillOpacity = 1
                        circle.strokeWidth = 4;

                        series1.tooltipHTML = `<div class="roleslist_tooltips twocolumn" ><div><ul><li> TEAM CONTRACT:&nbsp;&nbsp;$ {valueY}</li></ul></div></div>`;
                        series1.tooltip.pointerOrientation = "horizontal";
                        series1.tooltip.background.strokeWidth = 0;
                        series1.tooltip.getFillFromObject = false;
                        series1.tooltip.background.fill = am4core.color("#8790B1");
                        series1.tooltip.background.fillOpacity = 0.7;

                        var lineSeriesh = chart.series.push(new am4charts.LineSeries());
                        lineSeriesh.dataFields.openValueY = "rcl";
                        lineSeriesh.dataFields.customValue="rtc"
                        lineSeriesh.dataFields.valueY = "rcu";
                        lineSeriesh.dataFields.categoryX = "category";

                        lineSeriesh.propertyFields.stroke = "linecolor";
                        lineSeriesh.strokeWidth = 0;
                        lineSeriesh.propertyFields.strokeDasharray = "lineDash";
                        lineSeriesh.tooltip.label.textAlign = "middle";

                        lineSeriesh.propertyFields.fill = "linecolor";
                        lineSeriesh.fillOpacity = 0.3;

                        lineSeriesh.tooltipHTML = `<div class="roleslist_tooltips roleslist_tooltipsleft" ><div><ul><li class="class{indexer}"> HI:&nbsp;&nbsp;$ {valueY}</li><li class="class{indexer}">PROJECTED:&nbsp;&nbsp;$ {customValue}</li><li class="classa{indexerp}">REAL-TIME CONTRACT:&nbsp;&nbsp;$ {customValue}</li><li class="class{indexer}">LOW:&nbsp;&nbsp;$ {openValueY}</li></ul></div></div>`;
                        lineSeriesh.tooltip.pointerOrientation = "horizontal";
                        lineSeriesh.tooltip.background.strokeWidth = 0;
                        lineSeriesh.tooltip.getFillFromObject = false;
                        lineSeriesh.tooltip.background.fill = am4core.color("#8790B1");
                        lineSeriesh.tooltip.background.fillOpacity = 0.7;

                        var series2 = chart.series.push(new am4charts.LineSeries());
                        series2.dataFields.valueY = "rtc";
                        series2.dataFields.categoryX = "category";
                        series2.strokeWidth = 3;
                        series2.propertyFields.stroke = "linecolor";

                        var bullet2 = series2.bullets.push(new am4charts.Bullet());
                        bullet2.fill = am4core.color('#47A01A'); // tooltips grab fill from parent by default
                        var circle2 = bullet2.createChild(am4core.Circle);
                        circle2.radius = 6;
                        circle2.propertyFields.stroke = "dotcolor";
                        circle2.propertyFields.fill = "dotcolor";
                        circle2.strokeWidth = 4;

                        // Create series
                        var series = chart.series.push(new am4charts.LineSeries());
                        series.dataFields.valueY = "freeagent";
                        series.dataFields.categoryX = "category";

                        series.strokeWidth = 0;
                        series.stroke = am4core.color('#4B58AA');
                        series.opacity = 0;

                        var bulletfa = series.bullets.push(new am4charts.Bullet());
                        bulletfa.fill = am4core.color('#4B58AA'); // tooltips grab fill from parent by default
                        var circlefa = bulletfa.createChild(am4core.Circle);
                        circlefa.radius = 6;
                        circlefa.fill = am4core.color("#4B58AA");
                        circlefa.fillOpacity = 1
                        circlefa.strokeWidth = 4;

                        series.tooltipHTML = `<div class="roleslist_tooltips twocolumn" ><div><ul><li>Free Agent</li></ul></div></div>`;
                        series.tooltip.pointerOrientation = "horizontal";
                        series.tooltip.background.strokeWidth = 0;
                        series.tooltip.getFillFromObject = false;
                        series.tooltip.background.fill = am4core.color("#8790B1");
                        series.tooltip.background.fillOpacity = 0.7;

                        series.adapter.add("tooltipHTML", function (text, target) {
                            let data = target.tooltipDataItem.dataContext;
                            if (data.freeagent == 0) {
                                return "";
                            } else {
                                return text;
                            }
                        });

                        circlefa.adapter.add("radius", function (fillOpacity, target) {
                            if (!target.dataItem) {
                                return fillOpacity;
                            }
                            return target.dataItem.dataContext.freeagent == 0 ? 0 : 12;
                        });

                        circlefa.adapter.add("fillOpacity", function (fillOpacity, target) {
                            if (!target.dataItem) {
                                return fillOpacity;
                            }
                            return target.dataItem.dataContext.freeagent == 0 ? 0 : 0.6;
                        });

                        categoryAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
                        valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
                        valueAxis.renderer.inside = true
                        valueAxis.renderer.labels.template.visible = false;
                        valueAxis2.renderer.inside = true
                        valueAxis2.renderer.labels.template.visible = false;

                      let _sdate = "2021-2022";
                    let _edate =  "2021-2022";

                    let offrange = categoryAxis.axisRanges.create();


                    offrange.category = _sdate;
                        offrange.endCategory = _edate;


                
                    offrange.axisFill.fill = am4core.color('#000000');
                    offrange.axisFill.fillOpacity = 1;

                    offrange.label.inside = true
                    offrange.label.text = "CURRENT SEASON";
                    offrange.label.textAlign = "end"
                    offrange.label.height = 310
                    offrange.label.opacity = 0.3;
                    offrange.label.rotation = 270;
                    offrange.label.dy = -180
                    offrange.label.dx = -35
                    offrange.label.adapter.add("horizontalCenter", function () {
                        return "middle";
                    });
                    offrange.label.fill = am4core.color("#7484a1cc");
offrange.label.fontSize = 30
                    offrange.label.fontFamily = 'rajdhanisemibold';

                    }

                });

        }

    },
    mounted() {
        this.getprofitimpact();
    }
};
</script>
