<template>
    <div>
        <div class="widget_block ballimpact_block">
            <div class="widget_title">
                <h3>BALL IMPACT</h3> 
                <div>
                    <v-row>
                        <v-col>
                           <!-- <v-switch
                                v-model="Per40pts"
                                class="mx-2"
                                label="Per40pts">
                          </v-switch> -->
                           <div class="toggle_switch">
                              <v-switch v-model="switch1" flat :label="'Per 40pts:'"></v-switch>
                          </div>
                        </v-col> 
                        <v-col class="overall">
                            <v-select
                            :items="itemsA" 
                            label="OVERALL"
                            solo
                            ></v-select>
                        </v-col>
                    </v-row>                  
                </div>
            </div>
            <div class="widget_body">
                <div id="chart" style="display:none">
                    <apexchart type="scatter" height="350" :options="chartOptions" :series="series"></apexchart>
                </div>
                
            </div>
     </div>
    </div>
</template>
<script>
import VueApexCharts  from 'vue-apexcharts';
export default {
    name: "BallImpact",
     components: {
        apexchart: VueApexCharts
    },
    methods: {
        generateDayWiseTimeSeries(baseval, count, yrange) {
            var i = 0;
            var series = [];
            while (i < count) {
            var y = Math.floor(Math.random() * (yrange.max - yrange.min + 1)) + yrange.min;

            series.push([baseval, y]);
            baseval += 86400000;
            i++;
            }
            return series;
        }
    },
    data: () => ({
        itemsA: ['PTS', 'FGM', 'FGA', 'FG%'],
        tab: null,
        text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
        icons: false,
        centered: false,
        grow: false,
        vertical: false,
        prevIcon: false,
        nextIcon: false,
        right: false,
        tabs: 3,
        series: [
            {
              name: 'TEAM 1',
            //   data: generateDayWiseTimeSeries(new Date('11 Feb 2017 GMT').getTime(), 20, {
            //     min: 10,
            //     max: 60
            //   })
            },
            {
              name: 'TEAM 2',
            //   data: 
            //   this.generateDayWiseTimeSeries(new Date('11 Feb 2017 GMT').getTime(), 20, {
            //     min: 10,
            //     max: 60
            //   })
            },
            {
              name: 'TEAM 3',
            //   data: [1001, 10]
            //  this.generateDayWiseTimeSeries(new Date('11 Feb 2017 GMT').getTime(), 30, {
            //     min: 10,
            //     max: 60
            //   })
            },
            {
              name: 'TEAM 4',
            //   data: this.generateDayWiseTimeSeries(new Date('11 Feb 2017 GMT').getTime(), 10, {
            //     min: 10,
            //     max: 60
            //   })
            },
            {
              name: 'TEAM 5',
              data: [100, 10]
            // this.generateDayWiseTimeSeries(new Date('11 Feb 2017 GMT').getTime(), 30, {
            //     min: 10,
            //     max: 60
            //   })
            },
        ],
        chartOptions: {
            chart: {
              height: 350,
              type: 'scatter',
              zoom: {
                type: 'xy'
              }
            },
            dataLabels: {
              enabled: false
            },
            grid: {
              xaxis: {
                lines: {
                  show: true
                }
              },
              yaxis: {
                lines: {
                  show: true
                }
              },
            },
            xaxis: {
              type: 'datetime',
            },
            yaxis: {
              max: 70
            }
        },

    }),
}
</script>