<template>
  <ul>
    <li
      v-on:click="reloadData(date, index)"
      v-for="(date, index) in dateslist"
      :key="index"
      v-bind:class="{ active: index == selectedIndex }"
    >
      <a>{{ date.dateno }}</a>
    </li>
  </ul>
</template>

<script>
import moment from "moment";

export default {
  components: {},
  methods: {
    pollData() {
      this.polling = setInterval(() => {
        this.$emit("reloadProb", {
          date: this.dateslist[this.selectedIndex].date,
          edate: this.dateslist[this.selectedIndex].edate,
          reload: true,
        });
      }, 36000);
    },
    reloadData(date, index) {
      this.selectedIndex = index;
      this.$emit("reloadProb", {
        date: date.date,
        edate: date.edate,
        reload: false,
      });
    },
  },
  beforeDestroy() {
    clearInterval(this.polling);
  },
  mounted() {
    var a = moment();
    var _s = this;
    var _ds = [0, 1, 2, 3,4];

    var m = moment().utc();
    var usatime = moment().utcOffset("+05:30").format("H");
    var offset = new Date().getTimezoneOffset();
    if (usatime > 13 && offset == -330) {
      _ds = [1, 2, 3, 4,5];
    }
    m.set({ hour: 4, minute: 0, second: 0, millisecond: 0 });

    var time1 = moment().utc().format("YYYY-MM-DD");
    var time2 = moment().tz("Asia/Calcutta").format("YYYY-MM-DD");

    _ds.forEach((ekement) => {
      var s = moment().add(ekement, "days").startOf("day"),
        e = moment().add(ekement, "days").endOf("day");
        var asa = s;
        if (moment().add(1, "days").startOf("day").isSame(s) ) {
            asa = 'Tomorrow';
        }
        if (moment().add(0, "days").startOf("day").isSame(s) ) {
            asa = 'Today';
        } 
        
        if (moment().add(ekement, "days").startOf("day").isAfter(moment().add(1, "days").startOf("day")) ) {
        
            asa = s.format("MMM-DD")
        }
      this.dateslist.push({ dateno: asa , date: s, edate: e });
    });

    _s.$emit("reloadProb", {
      date: this.dateslist[0].date,
      edate: this.dateslist[0].edate,
      reload: false,
    });

    this.pollData();
  },

  data() {
    return {
      selectedIndex: 0,
      dateslist: [],
      polling: null,
    };
  },
};
</script>
