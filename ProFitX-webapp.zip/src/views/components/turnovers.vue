

<template>  
    <div>
        <div class="widget_block">            
            <div class="widget_body turnovers_widget">
                <h2 class="small-heading">TURNOVERS</h2>
                <label>$2,346<span><v-icon>mdi-menu-up</v-icon>8.1%</span></label>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "turnovers",
    
}
</script>
