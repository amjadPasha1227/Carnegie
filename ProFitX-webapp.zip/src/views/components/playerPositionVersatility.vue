<template>
<div>
    <div class="widget_block versatility_widget" v-if="player">
        <div class="widget_title">
            <h3>POSITION VERSATILITY

                <v-tooltip bottom>
                    <template v-slot:activator="{ on, attrs }">
                        <v-btn class="info_btn" v-bind="attrs" v-on="on">
                            <v-icon>mdi-information-outline</v-icon>
                        </v-btn>
                    </template>
                    <span>Time series model displays and identifies athlete’s monthly offensive efficiency & versatility from all areas of the court and where he excels and needs improvement on shot selection, shot attempts, shots made, and field goal % throughout his entire career.  </span>
                </v-tooltip>

            </h3>
            <div class="d-flex">  

                    <div class="assets-teams assets-teamswidth">
        
              </div>


                <ul class="graph_actions" style="display:none">
                    <li class="active">
                        <p class="action_btn">Offensive</p>
                    </li>
                    <li>
                        <p class="action_btn">Defensive</p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="widget_body" style="height:auto">
            <v-container fluid class="pad0">
                <v-row>
                    <v-col class="pad0">
                        <div class="versatility_graph_wrap">
                            <div class="versatility_graph" style="height:650px">
                                <div class="shotsloading" v-if="shotsloading">
                                    <img src="../../assets/images/shotsloading.svg" />
                                </div>
                                <div class="shotsloading" v-if="noshots">No Shots Found</div>
                                <div class="imghidden" style="position:absolute;display:none">
                                    <img src="../../assets/images/analytics.svg" />
                                </div>
                                <svg id="court" style="max-width:940px" class="maxwidth" viewBox="-20 17 940 667" />

                                <div id="yearSelecter" style="margin:-40px 0px 0px 00px;">
                                <div class="timeserieschart" style="height:auto" id="zchartdiv"></div>
                <div class="rangeselecter">{{seletedrange.s}} - {{seletedrange.e}}</div>
                                </div>
                            </div>
                            <div class="versatility_subtitle">
                                    <h3> SHOT EFFICIENCY</h3>
                                <ul>
                                    <li><span class="blk" style="background:Red;opacity:0.6"> </span> Hot Zone </li>
                                    <li><span class="blk" style="background:Orange;opacity:0.6"> </span>High </li>
                                    <li><span class="blk" style="background:#41a3f2;opacity:0.6"> </span>Average </li>
                                    <li><span class="blk" style="background:white;opacity:0.6"> </span> Low </li>

                                </ul>

                                    <h3 style="margin-top:40px;"> SHOOTING  </h3>

                                    <ul >
                                    <li><span class="blk" style="background:#008000;"> </span> Shots Made </li>
                                    <li><span class="blk" style="background:#FF8F00;"> </span>Shots Missed </li>

                                </ul>

                                <!-- <ul>
                    <li>
                      <label>Efficiency by Location</label>
                      <p>
                        BELOW AVG
                        <span>
                          <img src="../../assets/images/Hexagon_shape.svg" />
                        </span>ABOVE AVG
                      </p>
                    </li>

                  </ul>-->

                            </div>
                        </div>
                    </v-col>
                </v-row>
            </v-container>
        </div>
    </div>
    <div class="vstip" style="display:none">
        <div v-if="selectedzone.shots == 0">
            N/A
        </div>
        <div v-if="selectedzone.shots > 0">
            <h4>{{szones[selectedzone.name]}} </h4>

            <p>Shot Attempts - {{selectedzone.shots}}</p>
            <p>Shots Made - {{selectedzone.made}}</p>
            <p>FG % - {{((selectedzone.made/selectedzone.shots)*100).toFixed(1)}}</p>
        </div>
    </div>

    <div class="hovercharttip">
        <div class="hheaderchart">
            Chart
            <ul class="performance_status">
                <li><span style="background:#AF3945"></span> FG%</li>
                <li><span style="background:#2C7839"></span>FGM</li>
            </ul>
        </div>

        <svg id="hoverchart" width="400" height="220" />

    </div>

</div>
</template>
<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>

<script>
var dl = require("datalib");
import moment from "moment";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";

am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);

var court;
var Snap = window.Snap;
var d3 = window.d3;
var selfd = this;
var courtimage;
// zonepaths
var insiderightarcpath,
    centerarcpath,
    rightarcpath,
    leftarcpath,
    left3zonepath,
    right3zonepath,
    leftlongzonepath,
    rightlongzonepath,
    keyzonepath,
    insideleftarcpath,
    longcenterzonepath;
var courtlines;
export default {
    name: "player-position-versatility",
    data() {
        return {
            seletedrange:{},
              selectedones: null,
            tendencies:[
"3PT Jump Shot",
"3PT Pullup Jump Shot",
"3PT Step Back Jump Shot",
"Cutting Dunk Shot",
"Cutting Layup Shot",
"Driving Dunk",
"Floater",
"Driving Layup",

"Fadeaway Jumper",

"Jump Shot",

"Pullup Jump Shot",
"Putback Dunk",
"Putback Layup",

"Reverse Layup",

"Alley Oop",


"Tipped Shot",


"Turnaround Fadeaway ",

"Turnaround Jump Shot"],
            szones: ["", "3PT CORNER LEFT", "3PT CORNER RIGHT", "MID-RANGE LEFT CORNER", "MID-RANGE RIGHT CORNER", "PAINT", "MID-RANGE CENTER LEFT", "MID-RANGE CENTER RIGHT", "TOP OF THE KEY", "3PT CENTER", "3PT CENTER LEFT", "3PT CENTER RIGHT"],
            szone: null,
            noshots: false,
            shotss:false,
            startdate:new Date(),
            enddate:new Date(),
            shotsloading: false,
            selectedzone: {
                shots: 0,
                made: 0,
                name: null
            },
            chartdata: null,
        };
    },
    props: {
        player: {}
    },
    methods: {
        positionchange(){
       this.drwaYeasrScrollbar();

        },
        zone_hover(ev, data) {
            var group = Snap(ev.target);
            this.selectedzone.shots = data.shots;
            this.selectedzone.made = data.made;

            group = group.parent();
            group.attr({
                opacity: 1
            });
            this.selectedzone.name = group.attr("id").replace("zone", "");
            var doc = document.documentElement;
            var left = (window.pageXOffset || doc.scrollLeft) - (doc.clientLeft || 0);
            var top = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
            d3.select(".vstip")
                .style("display", "block")
                .style("left", ev.clientX + 20 + "px")
                .style("top", ev.clientY + top - 100 + "px");
        },
        drawChart(data) {
            var d3 = window.d3;
            d3.select("#hoverchart")
                .selectAll("*")
                .remove();
            var svg = d3.select("#hoverchart"),
                margin = {
                    top: 20,
                    right: 5,
                    bottom: 40,
                    left: 20
                },
                width = +svg.attr("width") - margin.left - margin.right,
                height = +svg.attr("height") - margin.top - margin.bottom;
            var x = d3.scaleTime().range([0, width]),
                y = d3.scaleLinear().range([height, 0]);

            var color = d3.scaleOrdinal().range(["#AF3945", "#2C7839"]);

            var xAxis = d3.axisBottom(x),
                yAxis = d3.axisLeft(y);

            svg
                .append("defs")
                .append("clipPath")
                .attr("id", "clip")
                .append("rect")
                .attr("width", width)
                .attr("height", height);

            var focus = svg
                .append("g")
                .attr("class", "focus")
                .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
            data.forEach(function (d) {
                d.date = new Date(d.date);
            });

            var line = d3
                .line()
                .x(function (d) {
                    return x(d.date);
                })
                .y(function (d) {
                    return y(d.close);
                })
                .curve(d3.curveMonotoneX);

            color.domain(
                d3.keys(data[0]).filter(function (key) {
                    return key !== "date";
                })
            );

            var stocks = color.domain().map(function (name) {
                return {
                    name: name,
                    values: data.map(function (d) {
                        return {
                            date: d.date,
                            close: d[name]
                        };
                    })
                };
            });

            x.domain([
                d3.min(stocks, function (c) {
                    return d3.min(c.values, function (v) {
                        return v.date;
                    });
                }),
                d3.max(stocks, function (c) {
                    return d3.max(c.values, function (v) {
                        return v.date;
                    });
                })
            ]);

            y.domain([
                0,
                d3.max(stocks, function (c) {
                    return d3.max(c.values, function (v) {
                        return v.close;
                    });
                })
            ]);

            var stock = focus
                .append("g")
                .selectAll(".stockXYZ")
                .data(stocks)
                .enter()
                .append("g")
                .attr("class", "stockXYZ");

            stock
                .append("path")
                .attr("class", "line")
                .attr("id", function (d, i) {
                    return "id" + i;
                })
                .attr("d", function (d) {
                    return line(d.values);
                })
                .style("stroke", function (d) {
                    return color(d.name);
                });

            focus
                .append("g")
                .attr("class", "axis axis--x axisyear")
                .attr("transform", "translate(-30," + height + ")")
                .call(xAxis.ticks(4).tickFormat(d3.timeFormat("%b, %y")));
            focus
                .append("g")
                .attr("class", "axis axismoneyleft")
                .call(yAxis.ticks(4));
        },
        zone_unhover(ev) {
            var group = Snap(ev.target);
            group = group.parent();
            if (group.attr("locked") == 0) {
                group.attr({
                    opacity: 0.4
                });
            }
            d3.select(".vstip").style("display", "none");
        },
        lock(ev) {
            var group = Snap(ev.target);
            group = group.parent();
            var dx = d3
                .select(group)
                .node()
                .getBBox();
            var xl = dx.width + dx.x - 45;
            if (group.attr("id") == "zone10" || group.attr("id") == "zone1") {
                xl = dx.x + 15;
            }
            if (group.attr("id") == "zone9") {
                xl = dx.x + 35;
            }
            this.szone = Number(group.attr("id").replace("zone", ""));
            d3.select("#analytics")
                .attr("y", dx.y + 20)
                .attr("x", xl);
            if (group.attr("locked") == 1) {
                group.attr({
                    locked: 0
                });
            } else if (group.attr("locked") == 0) {
                group.attr({
                    locked: 1
                });
            }
        },
        zonecolor(data, zone) {
            var shots = this._.filter(data, function (i) {
                return i.zone == zone;
            });
            var shotsmade = this._.filter(shots, function (i) {
                return i.zone == zone && i.result == "made";
            });
            var shotsmissed = this._.filter(shots, function (i) {
                return i.zone == zone && i.result != "made";
            });
            var per = (shotsmade.length / shots.length) * 100;
            var color;
            if (per < 33) color = "white";
            if (per > 33 && per < 37) color = "#41a3f2";
            if (per > 37 && per < 41) color = "Orange";
            if (per > 41) color = "Red";

            return {
                color: color,
                made: shotsmade.length,
                shots: shots.length
            };
        },
        choosecolor(per) {
            if (per > 0.09) return "#d73027";
            if (per > 0.06 && per <= 0.09) return "#f46d43";
            if (per > 0.03 && per <= 0.06) return "#fdae61";
            if (per >= 0 && per <= 0.03) return "#fee090";
            if (per < 0 && per >= -0.03) return "#bfe2ee";
            if (per < -0.03 && per >= -0.06) return "#abd9e9";
            if (per < -0.06 && per >= -0.09) return "#74add1";
            if (per < -0.09) return "#4575b4";
        },
        drawCourt() {
            var self = this;
            if (typeof courtlines != "undefined") {
                courtlines.clear();
            }
            this.shotsloading = true;
            this.noshots = false;
            // lines and rects
            court = Snap("#court");

            // lines and rects
            var graph_box = court.rect(-30, -20, 1100, 1000).attr({
                fill: "none"
            });
            // var details_box=court.rect(0,30,900,20).attr({fill:'#606060'})
            var key_outer_left = court
                .line(306, 50, 306, 392)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var key_outer_right = court
                .line(594, 50, 594, 392)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var key_inner_left = court
                .line(342, 50, 342, 392)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var key_inner_right = court
                .line(558, 50, 558, 392)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var key_top = court
                .line(306, 392, 594, 392)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var baseline_tick_left = court
                .line(252, 50, 252, 59)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var baseline_tick_right = court
                .line(648, 50, 648, 59)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var ft_tick_left = court
                .line(360, 284, 369, 284)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var ft_tick_right = court
                .line(540, 284, 531, 284)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var backboard = court
                .line(396, 120.2, 504, 120.2)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var nocharge_tick_left = court
                .line(378, 125.6, 378, 148.1)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var nocharge_tick_right = court
                .line(522, 125.6, 522, 148.1)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var key_left_tick1 = court
                .line(306, 176, 292.5, 176)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var key_right_tick1 = court
                .line(594, 176, 607.5, 176)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var key_left_tick2 = court
                .line(306, 194, 292.5, 194)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var key_right_tick2 = court
                .line(594, 194, 607.5, 194)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var key_left_tick3 = court
                .line(306, 248, 292.5, 248)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var key_right_tick3 = court
                .line(594, 248, 607.5, 248)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var key_left_tick4 = court
                .line(306, 302, 292.5, 302)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var key_right_tick4 = court
                .line(594, 302, 607.5, 302)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var left_threeline = court
                .line(54, 50, 54, 144.5)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var right_threeline = court
                .line(846, 50, 846, 144.5)
                .attr({
                    "shape-rendering": "crispEdges"
                });
            var baseline = court
                .line(0, 50, 900, 50)
                .attr({
                    "shape-rendering": "crispEdges",
                    "stroke-width": 2
                });

            // arcs
            var three_arc = court
                .path("M54,144.5A396,396 1 0,0 846,144.5")
                .attr({
                    "stroke-width": 1,
                    stroke: "#ffffff",
                    opacity: 0.5
                });
            var inner_ft_circle = court
                .path("M342,392A108,108 1 0,1 558,392")
                .attr({
                    "stroke-dasharray": [22.5, 22.5]
                });
            var outer_ft_circle = court
                .path("M342,392A108,108 1 0,0 558,392")
                .attr({
                    "stroke-width": 1,
                    stroke: "#ffffff",
                    "customnaem": "rightarc",
                    opacity: 0.5
                });
            var hoop = court
                .circle(450, 134.6, 13.5)
                .attr({
                    "stroke-width": 1,
                    stroke: "#ffffff",
                    "customnaem": "rightarc",
                    opacity: 1
                });
            var nocharge = court
                .path("M378,148.1A72,72 1 0,0 522,148.1")
                .attr({
                    "stroke-width": 1,
                    stroke: "#ffffff",
                    "customnaem": "rightarc",
                    opacity: 0.5
                });

            //zones
            var left3zone = court.line(0, 306, 50, 306).attr({
                "stroke-dasharray": [6, 6],
                "stroke-width": 1,
                stroke: "#ffffff",
                "customnaem": "rightarc",
                opacity: 1,
                "shape-rendering": "crispEdges"
            });
            var right3zone = court.line(846, 306, 896, 306).attr({
                "stroke-dasharray": [6, 6],
                "stroke-width": 1,
                stroke: "#ffffff",
                "customnaem": "rightarc",
                opacity: 1,
                "shape-rendering": "crispEdges"
            });
            var longleftzone = court.line(50, 306, 306, 306).attr({
                "stroke-dasharray": [6, 6],
                "stroke-width": 1,
                stroke: "#ffffff",
                "customnaem": "rightarc",
                opacity: 1,
                "shape-rendering": "crispEdges"
            });
            var longrightzone = court.line(594, 306, 846, 306).attr({
                "stroke-dasharray": [6, 6],
                "stroke-width": 1,
                stroke: "#ffffff",
                "customnaem": "rightarc",
                opacity: 1,
                "shape-rendering": "crispEdges"
            });
            var longcenterzone1 = court.line(306, 392, 306, 515).attr({
                "stroke-dasharray": [6, 6],
                "stroke-width": 1,
                stroke: "#ffffff",
                "customnaem": "rightarc",
                opacity: 1,
                "shape-rendering": "crispEdges"
            });
            longcenterzone1 = court.line(594, 392, 594, 515).attr({
                "stroke-dasharray": [6, 6],
                "stroke-width": 1,
                stroke: "#ffffff",
                "customnaem": "rightarc",
                opacity: 1,
                "shape-rendering": "crispEdges"
            });
            var leftarc = court.line(266, 500, 186, 664).attr({
                "stroke-dasharray": [6, 6],
                "stroke-width": 1,
                "customnaem": "rightarc",
                stroke: "#ffffff",
                opacity: 1,
                "shape-rendering": "crispEdges"
            });
            var rightarc = court.line(634, 500, 714, 664).attr({
                "stroke-dasharray": [6, 6],
                "customnaem": "rightarc",
                "stroke-width": 1,
                stroke: "#ffffff",
                opacity: 1,
                "shape-rendering": "crispEdges"
            });

            left3zonepath = court
                .path("M54,50L0,50L0,306L89,306A396,396 0 0,1 54,144.5L54,50")
                .attr({
                    fill: "none",
                    id: "zone"
                });
            right3zonepath = court
                .path("M846,50L900,50L900,306L811,306A396,396 1 0,0 846,144.5L846,50")
                .attr({
                    fill: "none",
                    id: "zone"
                });
            leftlongzonepath = court
                .path("M54,144.5L54,50L306,50L306,306L89,306A396,396, 1 0,1 54,144.5")
                .attr({
                    fill: "none",
                    id: "zone"
                });
            rightlongzonepath = court
                .path(
                    "M846,144.5L846,50L594,50L594,306L811,306A396,396, 1 0,0 846,144.5"
                )
                .attr({
                    fill: "none",
                    id: "zone"
                });
            keyzonepath = court
                .path("M306,50L306,392L594,392L594,50L306,50")
                .attr({
                    fill: "none",
                    id: "zone"
                });
            longcenterzonepath = court
                .path("M594,515L594,392L306,392L306,515A396,396 1 0,0 594,515")
                .attr({
                    fill: "none",
                    id: "zone"
                });
            insideleftarcpath = court
                .path("M89,306L306,306L306,515A396,396 1 0,1 89,306")
                .attr({
                    fill: "none",
                    id: "zone"
                });
            insiderightarcpath = court
                .path("M811,306L594,306L594,515A396,396 1 0,0 811,306")
                .attr({
                    fill: "none",
                    id: "zone"
                });
            leftarcpath = court
                .path("M269,497L186,664L0,664L0,306L89,306A396,396 0 0,0 269,497")
                .attr({
                    fill: "none",
                    id: "zone"
                });
            rightarcpath = court
                .path("M631,497L714,664L900,664L900,306L811,306A396,396 0 0,1 631,497")
                .attr({
                    fill: "none",
                    id: "zone"
                });
            centerarcpath = court
                .path("M269,497L186,664L714,664L631,497A396,396 0 0,1 269,497")
                .attr({
                    fill: "none",
                    id: "zone"
                });

            // grouping and applying attributes
            courtlines = court.group(
                key_outer_left,
                key_outer_right,
                key_inner_left,
                key_inner_right,
                key_top,
                baseline_tick_left,
                baseline_tick_right,
                ft_tick_left,
                ft_tick_right,
                backboard,
                nocharge_tick_left,
                nocharge_tick_right,
                key_left_tick1,
                key_left_tick2,
                key_left_tick3,
                key_left_tick4,
                key_right_tick1,
                key_right_tick2,
                key_right_tick3,
                key_right_tick4,
                left_threeline,
                right_threeline,
                three_arc,
                inner_ft_circle,
                outer_ft_circle,
                hoop,
                nocharge,
                baseline
            );
            courtlines.attr({
                stroke: "#ffffff",
                fill: "none",
                strokeWidth: 1
            });

        },
        drawshots(startdate, enddate) {
                                this.shotsloading = true;

            var self = this;
            if (court) {
                court.selectAll("rect").remove();
                court.selectAll("text").remove();
                court.selectAll("line").remove();
                court.selectAll("circle").remove();
                court.selectAll("path").remove();
                court.selectAll("image").remove();
            }

            this.drawCourt();

            this.$store
                .dispatch("getshots", {
                    playername: this.player.PLAYER_NAME,
                    startdate: startdate,
                    enddate: enddate,
                    shortype:this.selectedones
                })
                .then(response => {
                    var data = response.data.result;
                    this.shotsloading = false;

                    if (data.length == 0) {
                        this.noshots = true;
                    }
                    this.chartdata = data;

                    var shadow = court.filter(Snap.filter.shadow(0, 0, 3, "black", 1));
                    var z1d = self.zonecolor(data, 1);
                    left3zonepath.attr({
                        fill: z1d.color,
                        opacity: 0.4,
                        class: "absg"
                    });
                    //  var left3zonepathimg=left3zonepath.image(d3.select('.imghidden').select('img').attr('src'), 20,60, 25,25)

                    var l3zp = court.group(left3zonepath);
                    var _dopac = 0.6;

                    l3zp.attr({
                        opacity: _dopac,
                        locked: 0,
                        id: "zone1"
                    });
                    l3zp.hover(function (event) {
                        self.zone_hover(event, z1d);
                    }, self.zone_unhover);
                    l3zp.click(self.lock);
                    var z2d = self.zonecolor(data, 2);

                    right3zonepath.attr({
                        fill: z2d.color,
                        opacity: 0.4
                    });
                    // var  right3zoneimg=court.image(d3.select('.imghidden').select('img').attr('src'), 0,0, 25,25)

                    var r3zp = court.group(right3zonepath);
                    r3zp.attr({
                        opacity: _dopac,
                        locked: 0,
                        id: "zone2"
                    });
                    r3zp.hover(function (event) {
                        self.zone_hover(event, z2d);
                    }, self.zone_unhover);
                    r3zp.click(self.lock);

                    var z3d = self.zonecolor(data, 3);

                    leftlongzonepath.attr({
                        fill: z3d.color,
                        opacity: _dopac
                    });
                    var llzp = court.group(leftlongzonepath);
                    llzp.attr({
                        opacity: _dopac,
                        locked: 0,
                        id: "zone3"
                    });
                    llzp.hover(function (event) {
                        self.zone_hover(event, z3d);
                    }, self.zone_unhover);
                    llzp.click(self.lock);

                    var z4d = self.zonecolor(data, 4);

                    rightlongzonepath.attr({
                        fill: z4d.color,
                        opacity: _dopac
                    });
                    var rlzp = court.group(rightlongzonepath);
                    rlzp.attr({
                        opacity: _dopac,
                        locked: 0,
                        id: "zone4"
                    });
                    rlzp.hover(function (event) {
                        self.zone_hover(event, z4d);
                    }, self.zone_unhover);
                    rlzp.click(self.lock);

                    var z5d = self.zonecolor(data, 5);

                    keyzonepath.attr({
                        fill: z5d.color,
                        opacity: _dopac
                    });
                    var kzp = court.group(keyzonepath);
                    kzp.attr({
                        opacity: _dopac,
                        locked: 0,
                        id: "zone5"
                    });
                    kzp.hover(function (event) {
                        self.zone_hover(event, z5d);
                    }, self.zone_unhover);
                    kzp.click(self.lock);

                    var z8d = self.zonecolor(data, 8);

                    longcenterzonepath.attr({
                        fill: z8d.color,
                        opacity: _dopac
                    });
                    var lczp = court.group(longcenterzonepath);
                    lczp.attr({
                        opacity: _dopac,
                        locked: 0,
                        id: "zone8"
                    });
                    lczp.hover(function (event) {
                        self.zone_hover(event, z8d);
                    }, self.zone_unhover);
                    lczp.click(self.lock);
                    var z6d = self.zonecolor(data, 6);

                    insideleftarcpath.attr({
                        fill: z6d.color,
                        opacity: _dopac
                    });
                    var ilap = court.group(insideleftarcpath);
                    ilap.attr({
                        opacity: _dopac,
                        locked: 0,
                        id: "zone6"
                    });
                    ilap.hover(function (event) {
                        self.zone_hover(event, z6d);
                    }, self.zone_unhover);
                    ilap.click(self.lock);

                    var z7d = self.zonecolor(data, 7);
                    insiderightarcpath.attr({
                        fill: z8d.color,
                        opacity: _dopac
                    });
                    var irap = court.group(insiderightarcpath);
                    irap.attr({
                        opacity: _dopac,
                        locked: 0,
                        id: "zone7"
                    });
                    irap.hover(function (event) {
                        self.zone_hover(event, z7d);
                    }, self.zone_unhover);
                    irap.click(self.lock);

                    var z10d = self.zonecolor(data, 10);

                    leftarcpath.attr({
                        fill: z10d.color,
                        opacity: _dopac
                    });
                    var lap = court.group(leftarcpath);
                    lap.attr({
                        opacity: _dopac,
                        locked: 0,
                        id: "zone10"
                    });
                    lap.hover(function (event) {
                        self.zone_hover(event, z10d);
                    }, self.zone_unhover);
                    lap.click(self.lock);
                    var z11d = self.zonecolor(data, 11);

                    rightarcpath.attr({
                        fill: z11d.color,
                        opacity: _dopac
                    });
                    var rap = court.group(rightarcpath);
                    rap.attr({
                        opacity: _dopac,
                        locked: 0,
                        id: "zone11"
                    });
                    rap.hover(function (event) {
                        self.zone_hover(event, z11d);
                    }, self.zone_unhover);
                    rap.click(self.lock);
                    var z9d = self.zonecolor(data, 9);

                    centerarcpath.attr({
                        fill: z9d.color,
                        opacity: _dopac
                    });
                    var cap = court.group(centerarcpath);
                    cap.attr({
                        opacity: _dopac,
                        locked: 0,
                        id: "zone9"
                    });
                    cap.hover(function (event) {
                        self.zone_hover(event, z9d);
                    }, self.zone_unhover);
                    cap.click(self.lock);
                    courtimage = court
                        .image(
                            d3
                            .select(".imghidden")
                            .select("img")
                            .attr("src"),
                            -50,
                            -50,
                            25,
                            25
                        )
                        .attr("id", "analytics");

                    var imgrap = court.group(courtimage);
                    imgrap.attr({
                        opacity: 1,
                        locked: 1
                    });
                    imgrap.hover(function (event) {
                        var shots = self._.filter(self.chartdata, function (i) {
                            return i.zone == self.szone;
                        });
                        var mapped = self._.map(shots, self._.partialRight(self._.pick, ['date', 'result']));

                        var result = self._.chain(mapped)
                            .groupBy(datum => moment(new Date(datum.date)).startOf('day').format())
                            .map((platform, id) => ({
                                date: id,
                                missed: self._.sumBy(platform, function (o) {
                                    return o.result == 'missed' ? 1 : 1;
                                }),
                                made: self._.sumBy(platform, function (o) {
                                    return o.result != 'missed' ? 1 : 0;
                                })
                            })).value()

                        if (result.length > 0) self.drawChart(result);

                        var doc = document.documentElement;
                        var left = (window.pageXOffset || doc.scrollLeft) - (doc.clientLeft || 0);
                        var top = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
                        d3.select(".hovercharttip")
                            .style("display", "block")
                            .style("left", (event.clientX + 20 - 150) + "px")
                            .style("top", event.clientY + top - 70 + "px");

                    }, function (event) {
                        d3.select('.hovercharttip').style('display', 'none')

                        self.ana_unhover(event)
                    });

                    data.forEach(function (d) {
                        if (d.x != null && d.x != undefined) {
                            var nx = d.x * 1.8 + 450 + 9;
                            var ny = d.y * 1.8 + 144.5 + 9;
                            var color23 = self._.sample([
                                "#d73027",
                                "#f46d43",
                                "#fdae61",
                                "#fee090",
                                "#bfe2ee",
                                "#abd9e9",
                                "#74add1",
                                "#4575b4"
                            ]);

                            var color = "#008000";
                            var opac = 1
                            if (d.result == "missed") {
                                color = "#FF8F00";
                                opac = 1
                            }

                            var square_fg = court.rect(nx, ny, 0, 0, 2, 2).attr({
                                id: "temp",
                                fill: color,
                                opacity: opac,
                                strokeWidth: 0,
                                "shape-rendering": "crispEdges"
                            });

                            square_fg.animate({
                                x: nx,
                                y: ny,
                                height: 12,
                                width: 12
                            }, 1000);
                        }
                    });

                });

                self.shotss = false;
        },
        dateRange(startDate, endDate) {
  var start      = startDate.split('-');
  var end        = endDate.split('-');
  var startYear  = parseInt(start[0]);
  var endYear    = parseInt(end[0]);
  var dates      = [];

  for(var i = startYear; i <= endYear; i++) {
    var endMonth = i != endYear ? 11 : parseInt(end[1]) - 1;
    var startMon = i === startYear ? parseInt(start[1])-1 : 0;
    for(var j = startMon; j <= endMonth; j = j > 12 ? j % 12 || 11 : j+1) {
      var month = j+1;
      var displayMonth = month < 10 ? '0'+month : month;
      dates.push([i, displayMonth, '01'].join('-'));
    }
  }
  return dates;
},

        drwaYeasrScrollbar() {


            var self= this;
         //self.drawshots(new Date("2020-01-01"), new Date());

            var chart = am4core.create("zchartdiv", am4charts.XYChart);
            // Add data
             var startdate = moment(new Date())
            var edatesdd = moment(new Date()).format('YYYY-MM-DD')
            var _dates = this.dateRange('2010-01-01', edatesdd)

            var data = [];
            _dates.forEach(function(item){

                data.push({
                    date:item,
                    value:0
                })

            })

            chart.data = data;

            // Create axes
            var dateAxis = chart.xAxes.push(new am4charts.DateAxis());

            dateAxis.dataFields.category = "Date";
            dateAxis.renderer.grid.template.location = 0.5;
            dateAxis.dateFormatter.inputDateFormat = "yyyy-MM-dd";
            dateAxis.renderer.minGridDistance = 50;


            var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

                        valueAxis.renderer.labels.template.visible = false;
                        dateAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");

            // Create series
            var series = chart.series.push(new am4charts.LineSeries());
            series.dataFields.valueY = "value";
            series.dataFields.dateX = "date";
            series.strokeWidth = 2
            series.strokeOpacity = 0.3;
            chart.plotContainer.visible = false;

            chart.scrollbarX = new am4core.Scrollbar();
            chart.scrollbarX.parent = chart.bottomAxesContainer;
            chart.zoomOutButton.disabled = true;

         




         chart.events.on("ready", function () {
                    dateAxis.zoomToDates(
                        new Date("2020-01-01"),
                        new Date()
                    );
                });

   dateAxis.events.on("startendchanged", categoryAxisZoomed);
var _startdate;
var _enddate;
function categoryAxisZoomed(ev) {
  let start = ev.target.minZoomed;
  let end = ev.target.maxZoomed;
  self.startdate = new Date(start);
   self.enddate = new Date(end)
   self.seletedrange.s = moment(self.startdate).format("MMM Y")
   self.seletedrange.e = moment(self.enddate).format("MMM Y")
  if(self.shotss!=true){
  self.shotss = true;
    setTimeout(function(){

self.drawshots(self.startdate, self.enddate);

    },1500) 
  }
}


            chart.scrollbarX.stroke = am4core.color("#3F4C76");
            chart.scrollbarX.strokeOpacity = 0.6
            chart.scrollbarX.background.fill = am4core.color("#3F4C76");
            chart.scrollbarX.background.fillOpacity = 0.6
            chart.scrollbarX.startGrip.background.fill = am4core.color("#3F4C76");
            chart.scrollbarX.endGrip.background.fill = am4core.color("#3F4C76");

        }
    },
    mounted() {
        this.drwaYeasrScrollbar();

    }
};
</script>

