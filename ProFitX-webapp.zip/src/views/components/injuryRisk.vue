<template>
<div class="h-100">
    <div class="widget_block injury_block">
        <div class="widget_title">
            <h3>INJURY RISK

                <v-tooltip bottom>
                    <template v-slot:activator="{ on, attrs }">
                        <v-btn class="info_btn" v-bind="attrs" v-on="on">
                            <v-icon>mdi-information-outline</v-icon>
                        </v-btn>
                    </template>
                    <span>Dynamic AI model displays athlete’s current season injury history, injury status, injury risk rating, injury time, and real-time financial impact each injury has had throughout his career. </span>
                </v-tooltip>

            </h3>
            <div>
                <v-row class="align-center">
                    <v-col v-if="player">
                        <injury-History v-if="player!=null" class="history_btn" :player="player" />
                    </v-col>

                </v-row>
            </div>
        </div>

        <div class="loading-page" v-if="isloading">
            <figure>
                <img src="@/assets/images/loader.gif">
            </figure>Loading
        </div>
        <div class="widget_body  injury-body" v-if="player.injuries && player.injuries.length > 0">

            <div class="injury_cnt">
                <div class="front_body face-head">
                    <figure><img src="@/assets/images/front_body.svg"></figure>

                      <template v-for="(injury, index) in injuryParts">

                        <span v-bind:key='index' :class="injury.cssclass"><img :src="injury.image">
                                <span class="itooltip">
                                 {{injury.bodyPart}}
                                <span>  {{injury.percent  | percent(2)}} </span>
                              </span>
                        
                        </span>

                    </template> 
                     

                </div>
                <div class="back_body">
                    <figure><img src="@/assets/images/back_body.svg"></figure>
                     <template v-for="(injury, index) in injuryPartsback">
                        <span v-bind:key='index' :class="injury.cssclass">
                            <img :src="injury.image">
                             <span class="itooltip">
                                 {{injury.bodyPart}}
                                <span>  {{injury.percent  | percent(2)}} </span>
                              </span>
                            </span>
                    </template>                     
                </div>
            </div>
            <div class="injuryRisk">

                <div class="injury_status active" v-bind:class="{ inactive: (player.ninjuries && player.ninjuries.length > 0 && player.ninjuries[player.ninjuries.length-1].Status == 'Out for Season') || (player.ninjuries && player.ninjuries.length > 0 && player.ninjuries[0].FinishDate == null)}">
                    <div class="sick_time">
                        <span>Injury Time</span>
                        <label>{{SickTime | percent(2)}}</label>
                    </div>
                    <div class="sick_status">
                        <div class="status_switch"><span>Health</span>
                            <p v-if="(player.ninjuries && player.ninjuries.length > 0 && player.ninjuries[player.ninjuries.length-1].Status == 'Out for Season') || (player.ninjuries && player.ninjuries.length > 0 && player.ninjuries[0].FinishDate == null)">Out<v-icon>mdi-arrow-down-circle</v-icon>
                            </p>
                            <p v-else>Active<v-icon>mdi-arrow-up-circle</v-icon>
                            </p>

                        </div>
                        <div class="status_progress">
                            <v-progress-linear :value="SickTime"></v-progress-linear>
                            <p><span>Durable</span><span>Injury Risk</span><span>Injury Prone</span></p>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="widget_body  injury-body" v-if="player.injuries && player.injuries.length == 0">

                  <div class="injury_cnt">
                <div class="front_body face-head">
                    <figure><img src="@/assets/images/front_body.svg"></figure>

                      <template v-for="(injury, index) in injuryParts">

                        <span v-bind:key='index' :class="injury.cssclass"><img :src="injury.image">
                                <span class="itooltip">
                                 {{injury.bodyPart}}
                                <span>  {{injury.percent  | percent(2)}} </span>
                              </span>
                        
                        </span>

                    </template>

                </div>
                <div class="back_body">
                    <figure><img src="@/assets/images/back_body.svg"></figure>
                    <template v-for="(injury, index) in injuryPartsback">

                        <span v-bind:key='index' :class="injury.cssclass">
                                           

                            <img :src="injury.image">
                             <span class="itooltip">
                                 {{injury.bodyPart}}
                                <span>  {{injury.percent  | percent(2)}} </span>
                              </span>
                            </span>
              
              
                    </template>
                  
                </div>
            </div>
            <div class="injuryRisk">

                <div class="injury_status active" v-bind:class="{ inactive: (player.ninjuries && player.ninjuries.length > 0 && player.ninjuries[player.ninjuries.length-1].Status == 'Out for Season') || (player.ninjuries && player.ninjuries.length > 0 && player.ninjuries[0].FinishDate == null)}">
                    <div class="sick_time">
                        <span>Injury Time</span>
                        <label>{{SickTime | percent(2)}}</label>
                    </div>
                    <div class="sick_status">
                        <div class="status_switch"><span>Health</span>
                            <p v-if="(player.ninjuries && player.ninjuries.length > 0 && player.ninjuries[player.ninjuries.length-1].Status == 'Out for Season') || (player.ninjuries && player.ninjuries.length > 0 && player.ninjuries[0].FinishDate == null)">Out<v-icon>mdi-arrow-down-circle</v-icon>
                            </p>
                            <p v-else>Active<v-icon>mdi-arrow-up-circle</v-icon>
                            </p>

                        </div>
                     
                    </div>
                </div>
            </div>


           

        </div>

    </div>
    <!-- <v-row>
          <v-col></v-col>
        </v-row> -->
</div>
</template>

<script>
import moment from 'moment'

import injuryHistory from '@/views/components/injuryHistory.vue';
export default {
    name: "injury-Risk",
    components: {
        injuryHistory,
    },
    props: {
        player: null,
        history: null
    },
    data: () => ({
        isloading: false,
        SickTime: 0,
        frontlist: [{
            injury: "Head",
            css: "head"
        }, {
            injury: "Neck",
            css: "neck"
        }, {
            injury: "Left Shoulder",
            css: "left_shoulder"
        }, {
            injury: "Right Shoulder",
            css: "right_shoulder"
        }, {
            injury: "Left Arm",
            css: "left_arm"
        }, {
            injury: "Right Arm",
            css: "right_arm"
        }, {
            injury: "Right Wrist",
            css: "right_wrist"
        }, {
            injury: "Left Wrist",
            css: "left_wrist"
        }, {
            injury: "Right Hand",
            css: "right_hand"
        }, {
            injury: "Left Hand",
            css: "left_hand"
        }, {
            injury: "Left Oblique",
            css: "left_obligue"
        }, {
            injury: "Right Obligue",
            css: "right_obligue"
        }, {
            injury: "Abdominal",
            css: "abdominal"
        }, {
            injury: "Left Hip",
            css: "left_hip"
        }, {
            injury: "Right Hip",
            css: "right_hip"
        }, {
            injury: "Groin",
            css: "groin"
        }, {
            injury: "Left Knee",
            css: "left_knee"
        }, {
            injury: "Right Knee",
            css: "right_knee"
        }, {
            injury: "Left Leg",
            css: "left_leg"
        }, {
            injury: "Right Leg",
            css: "right_leg"
        }, {
            injury: "Right Ankle",
            css: "right_ankle"
        }, {
            injury: "Left Ankle",
            css: "left_ankle"
        }, {
            injury: "Right Foot",
            css: "right_foot"
        }, {
            injury: "Left Foot",
            css: "left_foot"
        }, {
            injury: "Right Bicep",
            css: "right_bicep"
        }, {
            injury: "Left Bicep",
            css: "left_bicep"
        }, {
            injury: "Right Pectoral",
            css: "right_waist"
        }, {
            injury: "Left Pectoral",
            css: "left_waist"
        }],
        backlist: [{
            injury: "Upper Back",
            css: "upper_back"
        },{
            injury: "Lower Back",
            css: "lower_back"
        }, {
            injury: "Left Elbow",
            css: "left_elbow"
        }, {
            injury: "Right Elbow",
            css: "right_elbow"
        }, {
            injury: "Tailbone",
            css: "tail_bone"
        }, {
            injury: "Left Hamstring",
            css: "left_hamstring"
        }, {
            injury: "Right Hamstring",
            css: "right_hamstring"
        }, {
            injury: "Left Calf",
            css: "left_calf"
        }, {
            injury: "Right Calf",
            css: "right_calf"
        }, {
            injury: "Left Achillies",
            css: "left_achilles"
        }, {
            injury: "Right Achiliies",
            css: "right_achilles"
        }, {
            injury: "Lower Back",
            css: "tail_bone"
        }],
        injuryParts: [],
        injuryPartsback: [],
    }),
    methods: {

    },
    mounted() {

        var _self = this;
        if (this.player.injuries && this.player.injuries.length > 0 && _self.player._matches.length > 0) {

            var groupbyparts = _self.lodash.groupBy(this.player.injuries, "front");
            var groupbypartsBack = _self.lodash.groupBy(this.player.injuries, "back");

            const totalmissed = this.lodash.sumBy(this.player.injuries, injury => {
                return parseInt(injury.missed);
            });
            var filterd = _self.lodash.filter(_self.player._matches, function (o) {
                return moment(o.gamedate).startOf('day').isSameOrBefore(moment().startOf('day'))
            })

            this.SickTime = (totalmissed / filterd.length) * 100;

            Object.keys(groupbyparts).forEach((key) => {
                let injury = key;
                if (key != null) {
                    let _injuries = groupbyparts[key]
                    let _missed = 0;
                    if (_injuries.length > 0) {
                        _injuries.forEach(function (item) {
                            _missed = _missed + item.missed;

                        })
                        let currenteam = _self._.find(_self.frontlist, function (obj) {
                            return obj.injury === key;
                        });
                       

                        if (currenteam) {

                            _self.injuryParts.push({
                                bodyPart: key,
                                cssclass: currenteam.css,
                                image: "https://profitx.ai/api/viewfile?path=injury/" + currenteam.css + ".svg",
                                percent: (_missed / filterd.length) * 100
                            })
                        }

                    }

                }

            })

            Object.keys(groupbypartsBack).forEach((key) => {
                let injury = key;
                if (key != null) {

                    let _injuries = groupbypartsBack[key]
                    let _missed = 0;
                    if (_injuries && _injuries.length > 0) {
                        _injuries.forEach(function (item) {
                            _missed = _missed + item.missed;

                        })

                        let currenteam = _self._.find(_self.backlist, function (obj) {
                            return obj.injury === key;
                        });
                        if (currenteam) {

                            _self.injuryPartsback.push({
                                bodyPart: key,
                                cssclass: currenteam.css,
                                image: "https://profitx.ai/api/viewfile?path=injury/" + currenteam.css + ".svg",
                                percent: (_missed / filterd.length) * 100
                            })

                        }

                    }

                }

            })


        }

    }
}
</script>
