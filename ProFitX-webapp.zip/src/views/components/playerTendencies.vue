<template>
<div>
    <div class="widget_block" v-if="player">
        <div class="widget_title">
            <h3>TENDENCIES

                <v-tooltip bottom>
                    <template v-slot:activator="{ on, attrs }">
                        <v-btn class="info_btn" v-bind="attrs" v-on="on">
                            <v-icon>mdi-information-outline</v-icon>
                        </v-btn>
                    </template>
                    <span>Time series model displays athlete’s game by game 18 individual tendency ratings and  trajectory of overall areas of development throughout their career.  </span>
                </v-tooltip>

            </h3>
            <div></div>
        </div>
        <div class="widget_body tendencies_widget flex-direction-column">
            <div class="shotsloading" v-if="shotsloading">
                <img src="../../assets/images/shotsloading.svg" />
            </div>
            <div class="d-flex">
                <div class="tendencies_list">
                    <ul v-slimscroll="options">
                        <li @click="_redraw()" v-for="(tendency,index) in atendencies" v-bind:key='tendency'>
                            <v-checkbox v-model="selectedones[index]" :label="tendency" :color="colors[index]" :border-color="colors[index]" :value="tendency" hide-details></v-checkbox>
                        </li>
                    </ul>
                </div>

                <div class="tendencies_graph_wrap">
                    <div class="tendencies_graph">

                        <div id="tendencieschartdiv" class="timeserieschart"></div>

                    </div>

                </div>
            </div>

        </div>

    </div>
</div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);
var _tendencieschart;
export default {
    name: "player-tendencies",
    components: {},
    props: {
        player: null,
        playerid: null
    },
    data: function () {
        return {
            firstloading: true,
            timeInterval: 'D',
            selecteddates: null,
            shotsloading: false,
            noshots: false,
            tdateperiod: null,
            tselectedvalues: {},
            options: {
                height: '100%',
                size: 5
            },
            selectedones: [],
            tendencies: [
                "Pick & Drive",
                "Pick & Roll",
                "Defensive Rebounds",
                "Offensive Rebounds",
                "Blocks",
                "Steals",
                "Center 3PT",
                "Left 3PT",
                "Right 3PT",
                "High Post",
                "Drive to Basket",
                "Mid Range",
                "Low Post",
                "Isolation",
                "Putbacks",
                "Catch & Shoot 3PT",
                "Cut to Basket",
                "Fastbreak Scoring"
            ],
            colors: [],
            atendencies: [],
            tendenciesdata: []
        };
    },
    methods: {
        _redraw() {
           this._drawtendencies();

        },
          _setSeason(startDate,endDate,dateAxis,color,title,opacity){

          

                    let offrange = dateAxis.axisRanges.create();

                    offrange.date = new Date(startDate);
                    offrange.endDate = new Date(endDate);
                    offrange.axisFill.fill = am4core.color(color);
                    offrange.axisFill.fillOpacity = opacity;

                    offrange.label.inside = true
                    offrange.label.text = title;
                    offrange.label.textAlign = "end"
                    offrange.label.height = 310
                    offrange.label.rotation = 270;
                    offrange.label.dy = -125
                    offrange.label.dx = -5
                    offrange.label.adapter.add("horizontalCenter", function () {
                        return "middle";
                    });
                    offrange.label.fill = am4core.color("#000");

                    offrange.label.fontFamily = 'rajdhanisemibold';

        },
        _drawtendencies() {
            var _self = this;
            if (_tendencieschart) _tendencieschart.dispose()
            setTimeout(function () {
                var results = _self.tendenciesdata;
                var data = [];
                results.forEach((d, index) => {
                    var _cd = {};
                    _cd.Date = new Date(d.Date);
                    _self.selectedones.forEach(function (_role) {
                        _cd[_role] = +(d[_role] * 100).toFixed(2);
                    });

                    data.push(_cd);
                });

                // Create chart instance
                _tendencieschart = am4core.create("tendencieschartdiv", am4charts.XYChart);
                data = _self.lodash.sortBy(data, "Date");
                _tendencieschart.data = data;
                _tendencieschart.svgContainer.autoResize = false;
                _tendencieschart.preloader.background.fill = am4core.color("#000000");
                _tendencieschart.preloader.background.fillOpacity = 0.1;
                let dateAxis = _tendencieschart.xAxes.push(new am4charts.DateAxis());
                dateAxis.renderer.grid.template.location = 0;
                dateAxis.renderer.minGridDistance = 60;
                dateAxis.fillOpacity = 0.6;

                let valueAxis = _tendencieschart.yAxes.push(new am4charts.ValueAxis());
                valueAxis.fillOpacity = 0.6;
                valueAxis.max = 100;
                valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
                var series;
                var _colors = _self.colors;
                var _types = _self.tendencies;
                var ttip = `<ul>`;
                _self.tendencies.forEach(function (_role, index) {

                    ttip = ttip + `<li class='aaaaval{` + _role + `}'><em style='background:` + _colors[index] + `'></em> <span>` + _role + `: {` + _role + `}</span></li>`;

                })
                ttip = ttip + `</ul>`;
                var _tipseries;
                _types.forEach(function (_role, index) {
                    series = _tendencieschart.series.push(new am4charts.LineSeries());
                    series.dataFields.valueY = _role;
                    series.dataFields.dateX = "Date";
                    series.stroke = am4core.color(_colors[index]);
                    series.connect = true;
                    series.strokeWidth = 2;
                    series.tooltipHTML=null;
                    if (index == _self.selectedones.length-1) {
                        _tipseries = series;
                    }
                        series.tensionX = 2;

                });

                _tipseries.tooltipHTML = `<div class="roleslist_tooltips twocolumn" ><div><div style="color:#ffffff" class="dateperiod">{dateX.formatDate("MMM d, yyyy")}</div>` + ttip + `</div></div>`;
                _tipseries.tooltip.pointerOrientation = "horizontal";
                _tipseries.tooltip.background.strokeWidth = 0;
                _tipseries.tooltip.getFillFromObject = false;
                _tipseries.tooltip.background.fill = am4core.color("#11172B");
                _tipseries.tooltip.background.fillOpacity = 0.7;

                _tendencieschart.events.on("ready", function (ev) {
                    valueAxis.min = valueAxis.minZoomed;
                    valueAxis.max = valueAxis.maxZoomed;
                });

                _tendencieschart.scrollbarX = new am4core.Scrollbar();
                _tendencieschart.scrollbarX.parent = _tendencieschart.bottomAxesContainer;
                _tendencieschart.zoomOutButton.disabled = true;

                _tendencieschart.scrollbarX.stroke = am4core.color("#3F4C76");
                _tendencieschart.scrollbarX.strokeOpacity = 0.6
                _tendencieschart.scrollbarX.background.fill = am4core.color("#3F4C76");
                _tendencieschart.scrollbarX.background.fillOpacity = 0.6
                _tendencieschart.scrollbarX.startGrip.background.fill = am4core.color("#3F4C76");
                _tendencieschart.scrollbarX.endGrip.background.fill = am4core.color("#3F4C76");

                var formatredranges = _self.lodash.sortBy(data, "Date")

                var _datestart = 2009;

                for (var i = 2009; i < 2023; i++) {
                    var _sdate = i + "-09-30";
                    var _edate = (i + 1) + "-05-30";

                    let range = dateAxis.axisRanges.create();

                    range.date = new Date(_sdate);
                    range.endDate = new Date(_edate);
                    range.axisFill.fill = am4core.color('#8790b1cc');
                    range.axisFill.fillOpacity = 0.4;

                }

                for (var ix = 2009; ix < 2023; ix++) {

                    let _sdate = ix + "-06-01";
                    let _edate = (ix + 1) + "08-30";

                    let offrange = dateAxis.axisRanges.create();

                    offrange.date = new Date(_sdate);
                    offrange.endDate = new Date(_edate);
                    offrange.axisFill.fill = am4core.color('#000000');
                    offrange.axisFill.fillOpacity = 1;

                    offrange.label.inside = true
                    offrange.label.text = "Offseason";
                    offrange.label.textAlign = "end"
                    offrange.label.height = 310
                    offrange.label.rotation = 270;
                    offrange.label.dy = -125
                    offrange.label.dx = -5
                    offrange.label.adapter.add("horizontalCenter", function () {
                        return "middle";
                    });
                    offrange.label.fill = am4core.color("#7484a1cc");

                    offrange.label.fontFamily = 'rajdhanisemibold';

                }

                 /* PLAY OFFS */
            _self._setSeason("2010-04-17","2010-06-17",dateAxis,'#8790b1',"PLAYOFFS",1)    
             _self._setSeason("2011-04-16","2011-06-12",dateAxis,'#8790b1',"PLAYOFFS",1)    
            _self._setSeason("2012-04-28","2012-06-21",dateAxis,'#8790b1',"PLAYOFFS",1)    
             _self._setSeason("2013-04-20","2013-06-20",dateAxis,'#8790b1',"PLAYOFFS",1)    
               _self._setSeason("2014-04-19","2014-06-15",dateAxis,'#8790b1',"PLAYOFFS",1)  
              _self._setSeason("2015-04-18","2015-06-16",dateAxis,'#8790b1',"PLAYOFFS",1)  

                _self._setSeason("2016-04-16","2016-06-19",dateAxis,'#8790b1',"PLAYOFFS",1)  

                _self._setSeason("2017-04-15","2017-06-12",dateAxis,'#8790b1',"PLAYOFFS",1)  
                _self._setSeason("2018-04-15","2018-06-12",dateAxis,'#8790b1',"PLAYOFFS",1) 
                _self._setSeason("2018-04-14","2018-06-08",dateAxis,'#8790b1',"PLAYOFFS",1) 
               _self._setSeason("2019-04-13","2019-06-12",dateAxis,'#8790b1',"PLAYOFFS",1)
               _self._setSeason("2020-08-17","2020-10-30",dateAxis,'#8790b1',"PLAYOFFS",1)
               _self._setSeason("2021-05-22","2021-07-30",dateAxis,'#8790b1',"PLAYOFFS",1)
_self._setSeason("2022-04-16","2022-06-16",dateAxis,'#8790b1',"PLAYOFFS",1)


                dateAxis.renderer.labels.template.textAlign = "middle";
                dateAxis.dateFormats.setKey("month", "MMM-yy");
              
                _tendencieschart.cursor = new am4charts.XYCursor();

            }, 150);
        },
        _showhideline(_index) {
            let series = _tendencieschart.series.getIndex(_index);
            if (series.isHiding || series.isHidden) {
                series.show();
            } else {
                series.hide();
            }
        },
        _gettendencies() {
            this.noshots = false;
            this.shotsloading = true;
            var self = this;
            var postdata = {
                timeInterval: this.timeInterval,
                type: "Tendencies",
                playerName: this.player.PLAYER_NAME
            };
            this.$store.dispatch("getTendencies", postdata).then(response => {
                var results = JSON.parse(response.data);
                if (results.length > 0) {
                    this.shotsloading = false;
                    this.tendenciesdata = results;
                    this._drawtendencies();
                } else {
                    this.shotsloading = false;
                    this.noshots = true;
                }

            });

        },
    },
    watch: {

        player: function (value) {}
    },
    mounted() {
        this.colors = this.chartcolors;
        var self = this;
        var attrss = this.tendencies.sort();
        this.atendencies = attrss;
        this.selectedones = attrss.slice(0, 5);
        this._gettendencies();

    }
};
</script>

<style>
.aaaaval {

    display: none;
}
</style>
