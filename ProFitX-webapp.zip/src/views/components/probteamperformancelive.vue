<template>
  <div class="player_performance_cnt">
    <div class="performance_block">
      <div class="team_title">
        <figure>
          <img :src="game.HomeTeam.logo" />
        </figure>
        <figcaption>{{ game.HomeTeam.Name }} Scoring</figcaption>
      </div>
           <div class="perfomance_subtabs">
        <ul>
            <li  v-bind:class="{ active: selectedhtype == 1 }"  @click="reloadCharrHome('Points',1)" >Scoring</li> 
            <li  v-bind:class="{ active: selectedhtype == 2 }"  @click="reloadCharrHome('Steals',2)" >Steals</li> 
            <li  v-bind:class="{ active: selectedhtype == 3 }"  @click="reloadCharrHome('DefensiveRebounds',3)" >Defensive <br/>Rebounds</li> 
            <li  v-bind:class="{ active: selectedhtype ==4 }"  @click="reloadCharrHome('OffensiveRebounds',4)" >Offensive <br/>Rebounds</li> 
            <li  v-bind:class="{ active: selectedhtype == 5 }"  @click="reloadCharrHome('Assists',5)" >Assists</li> 
            <li  v-bind:class="{ active: selectedhtype == 7 }"  @click="reloadCharrHome('BlockedShots',7)" >Blocks</li> 

                      
        </ul> 
      </div>
      <div class="perfomance_chart">
        <div
          id="chartdiv"
          class="oddschart"
          style="min-height: auto; height: 320px; padding-top: 60px"
        ></div>
      </div>
    </div>
    <div class="performance_block">
      <div class="team_title">
        <figure>
          <img :src="game.AwayTeam.logo" />
        </figure>
        <figcaption>{{ game.AwayTeam.Name }} Scoring</figcaption>
      </div>
            <div class="perfomance_subtabs">
        <ul>
         
   <li  v-bind:class="{ active: selectedatype == 1 }"  @click="reloadCharrAwy('Points',1)" >Scoring</li> 
            <li  v-bind:class="{ active: selectedatype == 2 }"  @click="reloadCharrAwy('Steals',2)" >Steals</li> 
            <li  v-bind:class="{ active: selectedatype == 3 }"  @click="reloadCharrAwy('DefensiveRebounds',3)" >Defensive <br/>Rebounds</li> 
            <li  v-bind:class="{ active: selectedatype ==4 }"  @click="reloadCharrAwy('OffensiveRebounds',4)" >Offensive <br/>Rebounds</li> 
            <li  v-bind:class="{ active: selectedatype == 5 }"  @click="reloadCharrAwy('Assists',5)" >Assists</li> 
            <li  v-bind:class="{ active: selectedatype == 7 }"  @click="reloadCharrAwy('BlockedShots',7)" >Blocks</li> 

    

        </ul> 
      </div>
      <div class="perfomance_chart">
        <div id="chartdiv2spb" class="oddschart"  style="min-height: auto; height: 320px; padding-top: 60px"></div>
      </div>
    </div>
  </div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";

am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);
var _starsystemchart;
export default {
  props: {
    game: null,
    gameId: null,
  },
  data: function () {
    return {
          selectedhtype:1,
      selectedatype:1,
      activeitem:1,
      activeitem1:1,
      htab: 1,
      firstloading: true,
      timeInterval: "D",
      selecteddates: null,
      shotsloading: false,
      noshots: false,
      tdateperiod: null,
      tselectedvalues: {},

      Prediction: null,
      options: {
        height: "100%",
        size: 5,
      },
      selectedones: ["awayscore", "homescore"],
      tendencies: ["awayscore", "homescore"],
      colors: [],
      tendenciesdata: [],
    };
  },
  beforeDestroy() {
    clearInterval(this.polling);
  },
  methods: {
        reloadCharrHome(typpe,selectedhtype){
    var alineup= this.lodash.filter(this.game.PlayerGames,function(item){
           return item.HomeOrAway == "HOME"
        })
        this._drawodds(
          alineup,
          this.game.HomeTeam.PrimaryColor,
          "chartdiv",
          typpe
        );
        this.selectedhtype = selectedhtype
    },
    reloadCharrAwy(typpe,selectedhtype){
     var balineup= this.lodash.filter(this.game.PlayerGames,function(item){
          return item.HomeOrAway != "HOME"
        })
        this._drawodds(
   balineup,
          this.game.AwayTeam.PrimaryColor,
          "chartdiv2spb",
          typpe
        );
        this.selectedatype = selectedhtype
    },
    pollData() {
      this.polling = setInterval(() => {
        this._getodds();

        //this.$emit("reloadProb",{date:this.dateslist[this.selectedIndex].date,edate:this.dateslist[this.selectedIndex].edate,reload:true})
      }, 36000);
    },
    _drawodds(lineup, PrimaryColor, divId, type) {
      var _self = this;
      if (_starsystemchart) _starsystemchart.dispose();
      setTimeout(function () {
   
        var sorteddata = _self.lodash.orderBy(lineup, "Points", "desc");

        var chart = am4core.create(divId, am4charts.XYChart);
        chart.hiddenState.properties.opacity = 0; // this creates initial fade-in

        chart.paddingBottom = 30;

        var _usersdata = [];
        sorteddata.forEach(function (item, index) {
          if (index <= 4) {
            _usersdata.push({
              name: item.Name,
              points: item[type],
              color: am4core.color("#" + PrimaryColor),
              bullet:
                "https://profitx.ai/api/viewfile?path=playerimages/sportsdataio/" +
                item.PlayerID +
                ".png",
            });
          }
        });
        chart.data = _usersdata;
        // Create axes
        var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
        categoryAxis.dataFields.category = "name";
        categoryAxis.renderer.grid.template.disabled = true;
        categoryAxis.renderer.minGridDistance = 30;
        categoryAxis.renderer.labels.template.fill = am4core.color("#fff");
        categoryAxis.renderer.labels.template.fontSize = 6;
        let label = categoryAxis.renderer.labels.template;

        label.wrap = true;
        label.textAlign = "middle";
        label.maxWidth = 120;

        var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
        valueAxis.renderer.grid.template.strokeDasharray = "4,4";
        valueAxis.renderer.labels.template.disabled = true;
        valueAxis.min = 0;

        // Do not crop bullets
        chart.maskBullets = false;

        // Remove padding
        chart.paddingBottom = 0;

        // Create series
        var series = chart.series.push(new am4charts.ColumnSeries());
        series.dataFields.valueY = "points";
        series.dataFields.categoryX = "name";
        series.columns.template.propertyFields.fill = "color";
        series.columns.template.propertyFields.stroke = "color";

        series.columns.template.tooltipText = "{categoryX}: [bold]{valueY} "+type+"[/b]";

        // Add bullets
        var bullet = series.bullets.push(new am4charts.Bullet());
        var image = bullet.createChild(am4core.Image);
        image.horizontalCenter = "middle";
        image.width = "100%";
        image.verticalCenter = "bottom";
        //image.dy = 100;

        bullet.adapter.add("dy", function (dy, target) {
          // console.log(target.dataItem.itemHeight)
          return target.dataItem.itemHeight + 8;
        });

        image.propertyFields.href = "bullet";
        image.tooltipText = series.columns.template.tooltipText;
        image.propertyFields.fill = "color";
        image.filters.push(new am4core.DropShadowFilter());

        //  categoryAxis.renderer.labels.template.location = 0.0001;
      }, 200);
    },
    _showhideline(_index) {
      let series = _starsystemchart.series.getIndex(_index);
      if (series.isHiding || series.isHidden) {
        series.show();
      } else {
        series.hide();
      }
    },
    changeLineup(lineup) {
      this._drawodds(lineup);
    },
    _getodds() {


        var alineup= this.lodash.filter(this.game.PlayerGames,function(item){
           return item.HomeOrAway == "HOME"
        })
        console.log(alineup)
        this._drawodds(
          alineup,
          this.game.HomeTeam.PrimaryColor,
          "chartdiv",
           "Points"
        );

         var balineup= this.lodash.filter(this.game.PlayerGames,function(item){
          return item.HomeOrAway != "HOME"
        })
        this._drawodds(
          balineup,
          this.game.AwayTeam.PrimaryColor,
          "chartdiv2spb",
           "Points"
        );
    },
  },
  watch: {},
  mounted() {
    var self = this;
    this.colors = this.chartcolors;

    this._getodds();
    this.pollData()
  },
};
</script>
