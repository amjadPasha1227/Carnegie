<template>
<div>
    <div class="widget_block" v-if="player">
        <div class="widget_title">
            <h3>ATTRIBUTES


                   <v-tooltip bottom>
                <template v-slot:activator="{ on, attrs }">
                    <v-btn class="info_btn"
                    v-bind="attrs"
                    v-on="on"
                    >
                    <v-icon>mdi-information-outline</v-icon>
                    </v-btn>
                </template>
                <span>Time series model displays athlete’s game by game 12 overall performance attribute ratings broken down into Offense, Defense, and Playmaking and the trajectory of overall areas of development throughout their career.  </span>
                </v-tooltip>


            </h3>
            <div></div>
        </div>
        <div class="widget_body tendencies_widget flex-direction-column">
            <div class="shotsloading" v-if="shotsloading">
                <img src="../../assets/images/shotsloading.svg" />
            </div>
            <div class="d-flex">
                <div class="tendencies_list" style="height:auto;">
                    <ul  style="height:auto;">
                        <li @click="_redraw()" v-for="(tendency,index) in attributes" v-bind:key='tendency'>
                            <template v-if="index == 0">
                           <v-checkbox v-model="selectedonesa" label="OVERALL DEFENSE" :color="colors[index]" :border-color="colors[index]" :value="tendency" hide-details></v-checkbox>

                             </template>
                               <template v-if="index == 5">                            <v-checkbox v-model="selectedonesa" label="OVERALL OFFENSE" :color="colors[index]" :border-color="colors[index]" :value="tendency" hide-details></v-checkbox>

                             </template>
                                     <template v-if="index == 10">                           
                                         
                                          <v-checkbox v-model="selectedonesa" label="OVERALL PLAYMAKING" :color="colors[index]" :border-color="colors[index]" :value="tendency" hide-details></v-checkbox>

                             </template>
                          <template v-if="index != 0 && index != 5 && index != 10">

                            <v-checkbox v-model="selectedonesa" :label="tendency" :color="colors[index]" :border-color="colors[index]" :value="tendency" hide-details></v-checkbox>
                          </template>
                        </li>
                    </ul>
                </div>

                <div class="tendencies_graph_wrap">
                    <div class="tendencies_graph">

                        <div id="attributeschartdiv" class="timeserieschartattributes"></div>

                    </div>

                </div>
            </div>

        </div>

    </div>
</div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import * as am4plugins_timeline from "@amcharts/amcharts4/plugins/timeline"; 

am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);
var _attributeschart;
export default {
    name: "player-attributes",
    components: {},
    props: {
        player: null,
        playerid: null
    },
    data: function () {
        return {
            firstloading: true,
            timeInterval: 'D',
            selecteddates: null,
            shotsloading: false,
            noshots: false,
            tdateperiod: null,
            tselectedvalues: {},
            options: {
                height: '100%',
                size: 5
            },
            selectedonesa: [
                'Defense', 'Offense', 'Playmaking' 
            ],
            attributes: [
                'Defense', 'Defensive IQ', 'Interior Defense', 'Perimeter Defense',"Defensive Impact",'Offense', 'Offensive Impact', 'Interior Scoring', 'Attacking the Basket', 'Perimeter Scoring','Playmaking','Ball Handing', 'Perimeter Assists', 'Interior Assists','Free Throws'    
            ],  
            dattributes:['Defensive IQ', 'Interior Defense', 'Perimeter Defense',"Defensive Impact"],
            oattributes:['Ball Handing', 'Perimeter Assists', 'Interior Assists', 'Free Throws'],
            pattributes:['Defensive IQ', 'Interior Defense', 'Perimeter Defense'],
            colors: [],
            attributesdata: []
        };
    },
    methods: {
              _redraw() {
           this._drawattributes();

        },
        
        _setSeason(startDate,endDate,dateAxis,color,title,opacity){

          

                    let offrange = dateAxis.axisRanges.create();

                    offrange.date = new Date(startDate);
                    offrange.endDate = new Date(endDate);
                    offrange.axisFill.fill = am4core.color(color);
                    offrange.axisFill.fillOpacity = opacity;

                    offrange.label.inside = true
                    offrange.label.text = title;
                    offrange.label.textAlign = "end"
                    offrange.label.height = 310
                    offrange.label.rotation = 270;
                    offrange.label.dy = -125
                    offrange.label.dx = -5
                    offrange.label.adapter.add("horizontalCenter", function () {
                        return "middle";
                    });
                    offrange.label.fill = am4core.color("#000");

                    offrange.label.fontFamily = 'rajdhanisemibold';

        },
        _drawattributes() {
            var _self = this;
            if (_attributeschart) _attributeschart.dispose()
            setTimeout(function () {
                var results = _self.attributesdata;
                var data = [];
                results.forEach((d, index) => {
                    var _cd = {};
                    _cd.Date = new Date(d.Date);
                    _self.selectedonesa.forEach(function (_role) {
                        _cd[_role] = +(d[_role] * 100).toFixed(2);
                    });

                    data.push(_cd);
                });

                _attributeschart = am4core.create("attributeschartdiv", am4charts.XYChart);
                //_attributeschart = chart;
                data = _self.lodash.sortBy(data, "Date");
                _attributeschart.data = data;
                _attributeschart.preloader.background.fill = am4core.color("#000000");
                _attributeschart.preloader.background.fillOpacity = 0.1;
                _attributeschart.svgContainer.autoResize = false;
                let dateAxis = _attributeschart.xAxes.push(new am4charts.DateAxis());
                dateAxis.renderer.grid.template.location = 0;
                dateAxis.renderer.minGridDistance = 60;
                dateAxis.fillOpacity = 0.6;
                let valueAxis = _attributeschart.yAxes.push(new am4charts.ValueAxis());
                valueAxis.fillOpacity = 0.6;
                valueAxis.max = 100;
                valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");

                var series;
                var _colors = _self.colors;
                var _types = _self.attributes;
                 var _tipseries;

                var ttip = `<ul>`;
                _self.selectedonesa.forEach(function (_role, index) {
                    series = _attributeschart.series.push(new am4charts.LineSeries());
                    series.dataFields.valueY = _role;
                    series.dataFields.dateX = "Date";
                        var sindex = _self.attributes.indexOf(_role);
                    series.stroke = am4core.color(_colors[sindex]);
                    series.connect = true;
                    series.strokeWidth = 2; 
                    ttip = ttip + `<li class='aaaaval{` + _role + `}'><em style='background:` + _colors[sindex] + `'></em> <span>` + _role + `: {` + _role + `}</span></li>`;

                    
                     if (index ==_self.selectedonesa.length-1) {
                        _tipseries = series;
                    }
                    
              
               
               });

                ttip = ttip + `</ul>`;
                _tipseries.tooltipHTML = `<div class="roleslist_tooltips twocolumn" ><div><div style="color:#ffffff" class="dateperiod">{dateX.formatDate("MMM d, yyyy")}</div>` + ttip + `</div></div>`;
                _tipseries.tooltip.pointerOrientation = "horizontal";
                _tipseries.tooltip.background.strokeWidth = 0;
                _tipseries.tooltip.getFillFromObject = false;
                _tipseries.tooltip.background.fill = am4core.color("#11172B");
                _tipseries.tooltip.background.fillOpacity = 0.7;
                _attributeschart.events.on("ready", function (ev) {
                    valueAxis.min = valueAxis.minZoomed;
                    valueAxis.max = valueAxis.maxZoomed;
                });

                for (var i = 2009; i < 2023; i++) {
                    var _sdate = i + "-09-30";
                    var _edate = (i + 1) + "-05-30";

                    let range = dateAxis.axisRanges.create();

                    range.date = new Date(_sdate);
                    range.endDate = new Date(_edate);
                    range.axisFill.fill = am4core.color('#8790b1cc');
                    range.axisFill.fillOpacity = 0.4;

                }

                  for (var ix = 2009; ix < 2023; ix++) {

                    let _sdate = ix + "-06-01";
                    let _edate = (ix + 1) + "08-30";

                    let offrange = dateAxis.axisRanges.create();

                    offrange.date = new Date(_sdate);
                    offrange.endDate = new Date(_edate);
                    offrange.axisFill.fill = am4core.color('#000000');
                    offrange.axisFill.fillOpacity = 1;

                    offrange.label.inside = true
                    offrange.label.text = "Offseason";
                    offrange.label.textAlign = "end"
                    offrange.label.height = 310
                    offrange.label.rotation = 270;
                    offrange.label.dy = -195
                    offrange.label.dx = -5
                    offrange.label.adapter.add("horizontalCenter", function () {
                        return "middle";
                    });
                    offrange.label.fill = am4core.color("#7484a1cc");

                    offrange.label.fontFamily = 'rajdhanisemibold';

                }

                 /* PLAY OFFS */
            _self._setSeason("2010-04-17","2010-06-17",dateAxis,'#8790b1',"PLAYOFFS",1)    
             _self._setSeason("2011-04-16","2011-06-12",dateAxis,'#8790b1',"PLAYOFFS",1)    
            _self._setSeason("2012-04-28","2012-06-21",dateAxis,'#8790b1',"PLAYOFFS",1)    
             _self._setSeason("2013-04-20","2013-06-20",dateAxis,'#8790b1',"PLAYOFFS",1)    
               _self._setSeason("2014-04-19","2014-06-15",dateAxis,'#8790b1',"PLAYOFFS",1)  
              _self._setSeason("2015-04-18","2015-06-16",dateAxis,'#8790b1',"PLAYOFFS",1)  

                _self._setSeason("2016-04-16","2016-06-19",dateAxis,'#8790b1',"PLAYOFFS",1)  

                _self._setSeason("2017-04-15","2017-06-12",dateAxis,'#8790b1',"PLAYOFFS",1)  
                _self._setSeason("2018-04-15","2018-06-12",dateAxis,'#8790b1',"PLAYOFFS",1) 
                _self._setSeason("2018-04-14","2018-06-08",dateAxis,'#8790b1',"PLAYOFFS",1) 
               _self._setSeason("2019-04-13","2019-06-12",dateAxis,'#8790b1',"PLAYOFFS",1)
               _self._setSeason("2020-08-17","2020-10-30",dateAxis,'#8790b1',"PLAYOFFS",1)
               _self._setSeason("2021-05-22","2021-07-30",dateAxis,'#8790b1',"PLAYOFFS",1)
_self._setSeason("2022-04-16","2022-06-16",dateAxis,'#8790b1',"PLAYOFFS",1)


                dateAxis.renderer.labels.template.textAlign = "middle";
                dateAxis.dateFormats.setKey("month", "MMM-yy");

                _attributeschart.scrollbarX = new am4core.Scrollbar();
                _attributeschart.scrollbarX.parent = _attributeschart.bottomAxesContainer;
                _attributeschart.zoomOutButton.disabled = true;

                _attributeschart.scrollbarX.stroke = am4core.color("#3F4C76");
                _attributeschart.scrollbarX.strokeOpacity = 0.6
                _attributeschart.scrollbarX.background.fill = am4core.color("#3F4C76");
                _attributeschart.scrollbarX.background.fillOpacity = 0.6
                _attributeschart.scrollbarX.startGrip.background.fill = am4core.color("#3F4C76");
                _attributeschart.scrollbarX.endGrip.background.fill = am4core.color("#3F4C76");

         
                _attributeschart.cursor = new am4charts.XYCursor();
            }, 150);
        },
        _showhideline(_index) {
            let series = _attributeschart.series.getIndex(_index);
            if (series.isHiding || series.isHidden) {
                series.show();
            } else {
                series.hide();
            }
        },
        _getattributes() {
            this.noshots = false;
            this.shotsloading = true;
            var self = this;
            var postdata = {
                timeInterval: this.timeInterval,
                type: "Attributes",
                playerName: this.player.PLAYER_NAME
            };
            this.$store.dispatch("getAttributes", postdata).then(response => {
                var results = JSON.parse(response.data);
                if (results.length > 0) {
                    this.shotsloading = false;
                    this.attributesdata = results;
                    this._drawattributes();
                } else {
                    this.shotsloading = false;
                    this.noshots = true;
                }

            });

        }
    },
    watch: {

        player: function (value) {}
    },
    mounted() {
        this.colors = this.chartcolors;
        var self = this;
        this._getattributes();

    }
};
</script>
