

<template>  
    <div>
        <v-row>
            <v-col class="col-md-5 pt-0 pr-0">
                <div class="widget_block timeimpact_widget">                    
                    <div class="widget_body">
                        <h2 class="small-heading">REAL TIME IMPACT</h2>
                    </div>
                </div>
            </v-col>
            <v-col class="col-md-7 pt-0 pl-0">
               <div class="impact_list">
                   <ul>
                       <li>
                           <h6>Offense</h6>
                           <div>                               
                               <figure><img src="../../assets/images/profile_dp-1.png"></figure>
                           </div>
                       </li>
                       <li>
                           <h6>Defense</h6>
                           <div>                               
                               <figure><img src="../../assets/images/profile_dp-1.png"></figure>
                           </div>
                       </li>
                       <li>
                           <h6>Potential</h6>
                           <div>                               
                               <figure><img src="../../assets/images/profile_dp-1.png"></figure>
                           </div>
                       </li>
                       <li>
                           <h6>Rebounding</h6>
                           <div>                               
                               <figure><img src="../../assets/images/profile_dp-1.png"></figure>
                           </div>
                       </li>
                   </ul>
               </div>
            </v-col>
        </v-row>
    </div>
</template>

<script>
export default {
    name: "real-time-impact",
    
}
</script>
