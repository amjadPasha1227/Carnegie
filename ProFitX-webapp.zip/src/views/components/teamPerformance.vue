

<template>  
    <div>
        <v-row>
            <v-col class="col-md-8 pt-0">
                <div class="widget_block teamperformance_widget">
                    <div class="widget_title">
                        <h3>TEAM VALUE</h3>
                        <div class="d-flex">
                            <div class="offensive_defensive">
                                <ul>
                                    <li class="active">Offensive</li>
                                    <li>Defensive</li>
                                </ul>
                            </div>
                            <v-select
                                :items="itemsC"
                                v-model="sseason"
                                label="Stats Categories"
                                solo
                                ></v-select>
                        </div>
                    </div>
                    <div class="widget_body">
                        <div></div>
                        <div class="teamperformance_bottom">
                            <div class="teamperformance_left">
                                <ul>
                                    <li class="player"><p>Player Performance</p></li>
                                    <li class="team"><p>Team Performance</p></li>
                                </ul>
                            </div>
                            <div class="teamperformance_right"><p>Team Importance<span>45%<v-icon>mdi-menu-up</v-icon></span></p></div>
                        </div>
                    </div>
                </div>
            </v-col>
            <v-col class="col-md-4 pt-0">
                <div class="team_performance_list">                
                    <v-list>
                        <p>Composite Score</p><span>7.2</span>
                    </v-list>
                     <v-list>
                        <p>Rebounding</p><span>9.8</span>
                    </v-list>
                     <v-list>
                        <p>Defense</p><span>8.9</span>
                    </v-list>
                     <v-list>
                        <p>Impact</p><span>7.3</span>
                    </v-list>
                </div>
            </v-col>
        </v-row>
    </div>
</template>

<script>
export default {
    name: "team-performance",
    data: () => ({
         
         sseason:"Stats Categories",
      itemsC:['category 1','category 2', 'category 3', 'category 4', 'category 5'],
      picker: new Date().toISOString().substr(0, 10),
    }),
}
</script>
