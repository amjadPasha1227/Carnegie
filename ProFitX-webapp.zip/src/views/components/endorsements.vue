

<template>  
    <div>
        <h2 class="small-heading">ENDORSEMENTS</h2>
        <div class="endorsements-list">
            <v-simple-table dark class="dark-table">
                <template>
                    <thead>
                    <tr>
                        <th>BRAND ENDORSE</th>
                        <th>VALUE</th>
                        <th>CONTRACT LEANTH</th>
                        <th>AVERAGE PER YEAR</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>APPLE</td>
                        <td>$153,000,000</td>
                        <td>3 years (2019–2022)</td>
                        <td>$9,538,461</td>
                    </tr>
                    <tr>
                        <td>NIKE</td>
                        <td>$124,000,000</td>
                        <td>3 years (2019–2022)</td>
                        <td>$9,583,333</td>
                        </tr>
                        <tr>
                        <td>Small Forward</td>
                        <td>$118,103,446</td>
                        <td>3 years (2019–2022)</td>
                        <td>$13,305,555</td>
                        </tr>
                        <tr>
                        <td>McDonald’s</td>
                        <td>$134,000,000</td>
                        <td>3 years (2019–2022)</td>
                        <td>$15,125,000</td>
                        </tr>
                        <tr>
                        <td>BMW</td>
                        <td>$120,000,000</td>
                        <td>3 years (2019–2022)</td>
                        <td>$16,875,000</td>
                        </tr>
                    </tbody>
                </template>
                </v-simple-table>  
            <ul class="endorsements-list-details">
                <li>
                    <span>NON NBA</span>
                    <p>$37,436,858</p>
                </li>
                <li>
                    <span>TV Shows</span>
                    <p>$37,436,858</p>
                </li>
                <li>
                    <span>Sport Value</span>
                    <p>$37,436,858</p>
                </li>
                <li>
                    <span>Endorsement Value</span>
                    <p>$37,436,858</p>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
export default {
    name: "endorsements",
    
}
</script>
