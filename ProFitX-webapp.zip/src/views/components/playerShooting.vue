

<template>  
    <div>
        <div class="widget_block">
            <div class="widget_title">
                <h3>SHOOTING</h3>
                <div>
                                   
                </div>
            </div>
            <div class="widget_body">
                
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "player-shooting",
    
}
</script>
