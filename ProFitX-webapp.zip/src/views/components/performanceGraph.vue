<template>
<div>
    <div class="widget_block performance_widget">
        <div class="widget_title">
            <h3> ATHLETE PERFORMANCE


                <v-tooltip bottom>
                <template v-slot:activator="{ on, attrs }">
                    <v-btn class="info_btn"
                    v-bind="attrs"
                    v-on="on"
                    >
                    <v-icon>mdi-information-outline</v-icon>
                    </v-btn>
                </template>
                <span>Time-Series model displays the match type (HOME/AWAY+CLUTCH TIME), weekly, monthly, and yearly LOW-HI Ratings to track overall performance trajectory throughout athlete’s career. </span>
                </v-tooltip>


            </h3>
            <div class="d-flex">
                <div class="performance_header">
                    <ul>
                            <li>
                            Stats
                            <v-select @change="_reloadChart" :items="matchtypestats" v-model="mts" label="Home" solo></v-select>
                        </li>
                        <li>
                            Match Type
                            <v-select @change="_reloadChart" :items="matchtypes" v-model="mt" label="Home" solo></v-select>
                        </li>
                        <li>
                            <v-select @change="_reloadChart" :items="frequency" v-model="fr" label="Frequency" solo></v-select>
                        </li>

                    </ul>
                </div>

                <v-menu offset-y :close-on-content-click="false">
                    <template v-slot:activator="{ on }">
                        <v-btn v-on="on" class="performance_filter_btn">
                            Filters
                            <v-icon>mdi-chevron-down</v-icon>
                        </v-btn>

                    </template>
                    <div class="performance_list">
                        <!-- <div class="performance_header">
                            <ul>
                                <li>
                                    Match Type
                                    <v-select @change="_reloadChart" :items="matchtypes" v-model="mt" label="Home" solo></v-select>
                                </li>
                                <li>
                                    Frequency
                                    <v-select @change="_reloadChart" :items="frequency" v-model="fr" label="Frequency" solo></v-select>
                                </li>

                            </ul>
                        </div> -->
                        <v-row class="performance_content">
                            <v-col>
                                <h6>Tendencies</h6>

                                <v-list-item v-for="(tendency,index) in tendencies" v-bind:key='index'>
                                    <v-checkbox @change="_reloadChart" :class="'color'+(index+1)" v-model="selectedones[index]" :label="tendency" :value="tendency" hide-details></v-checkbox>
                                </v-list-item>

                            </v-col>

                        </v-row>
                    </div>
                </v-menu>
            </div>
        </div>
        <div class="widget_body">
            <div class="shotsloading" v-if="shotsloading">
                <img src="../../assets/images/shotsloading.svg" />
            </div>

            <div class="performance_graph">

                <div class="impact_tooltip" id="impact_tooltip" style="display:none">
                    <h5>
                        Overall
                        <span class="low">{{selectedHoverItem.start}}</span> - <span class="high">{{selectedHoverItem.value}}</span>
                    </h5>
                    <ul>
                        <li v-for="(tendency,index) in selectedones" v-bind:key='index'>
                            {{tendency}}
                            <span class="low" v-if="selectedHoverItem[tendency]">{{selectedHoverItem[tendency]['min'] | percentagecustom}}</span> -<span v-if="selectedHoverItem[tendency]" class="high">{{selectedHoverItem[tendency]['max'] | percentagecustom}}</span>
                        </li>
                    </ul>
                </div>

                <div class="common_tooltip" id="performancetooltip" style="display:none">
                    <label><span>{{selectedHoverItem.start}}</span> - <span>{{selectedHoverItem.value}}</span></label>
                </div>

                <div id="performancechartdiv" style="height:400px" class="timeserieschart"></div>

            </div>
        </div>
    </div>
</div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);
var _performancechart;

import moment from "moment";

export default {
    name: "performance-graph",
    props: {
        player: null,
        playerid: null
    },
    data: () => ({
        firstloading: true,
        selecteddates: null,
        shotsloading: false,
        selectedHoverItem: {},
        noshots: false,
        options: {
            height: '100%',
            size: 5
        },
        selectedones: ["Mid Range",
"Blocks", 
"Defensive Rebounds", 
"High Post", 
"Offensive Rebounds", 
"Putbacks", 
"Fastbreak Scoring", 
"Low Post", 
"Drive to Basket", 
"Isolation", 
"Center 3PT", 
"Steals", 
"Pick & Roll", 
"Pick & Drive", 
"Pull Up 3PT", 
"Catch & Shoot 3PT",
"Right 3PT", 
"Left 3PT"
        ],
        tendencies: ["Mid Range",
"Blocks", 
"Defensive Rebounds", 
"High Post", 
"Offensive Rebounds", 
"Putbacks", 
"Fastbreak Scoring", 
"Low Post", 
"Drive to Basket", 
"Isolation", 
"Center 3PT", 
"Steals", 
"Pick & Roll", 
"Pick & Drive", 
"Pull Up 3PT", 
"Catch & Shoot 3PT",
"Right 3PT", 
"Left 3PT"
        ],
        matchtypestats:["Regular", "Clutch"], 
        matchtypes: ["All", "Home", "Away"],
        frequency: ["Weekly","Monthly", "Yearly"],
        mts: "Regular",
        mt: "All",
        fr: "Monthly",
        colors: [],

    }),
    mounted() {
        this.colors = this.chartcolors;

        this._getAttributes();
    },
    methods: {
        _reloadChart() {
            this._getAttributes();
        },

        _getAttributes() {
            this.noshots = false;
            this.shotsloading = true;
            var _seletedones = this.lodash.without(this.selectedones,undefined,null);
            var self = this;
            var postdata = {
                fr: this.fr,
                mts:this.mts,
                mt: this.mt,
                selectedones:_seletedones,
                playerName: this.player.PLAYER_NAME
            };
            this.$store.dispatch("getPerformance", postdata).then(response => {
                var results = response.data.data;
                if (results.length > 0) {
                    this.shotsloading = false;
                    var chart = am4core.create("performancechartdiv", am4charts.XYChart);
                    //chart.hiddenState.properties.opacity = 0; 
                    var uresult = [];
                    results.forEach(function (item, index) {
                        var nitem = item;
                        if (item.Overall.max != '' && item.Overall.max != 0) {
                            nitem["Overallmax"] = item.Overall.max * 100
                            nitem["Overallmin"] = item.Overall.min * 100
                            nitem.color = am4core.color("#8D350D")
                            uresult.push(nitem)

                        }

                    })

                    // using math in the data instead of final values just to illustrate the idea of Waterfall chart
                    // a separate data field for step series is added because we don't need last step (notice, the last data item doesn't have stepValue)
                    chart.data = uresult;

                    var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
                    categoryAxis.dataFields.category = "Date";
                    categoryAxis.renderer.minGridDistance = 50;

                    var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

                    var columnSeries = chart.series.push(new am4charts.ColumnSeries());
                    columnSeries.dataFields.categoryX = "Date";
                    columnSeries.dataFields.valueY = "Overallmax";
                    columnSeries.dataFields.openValueY = "Overallmin";

                    var columnTemplate = columnSeries.columns.template;
                    columnTemplate.strokeOpacity = 0;
                    columnTemplate.propertyFields.fill = 'color';
                    columnTemplate.maxWidth = 30;
                    columnTemplate.cursorOverStyle = am4core.MouseCursorStyle.pointer;
                    var _colors = self.colors;
                    let hoverState = columnTemplate.states.create("hover");
                    hoverState.properties.fill = am4core.color("#E94F37");
                     hoverState.properties.fillOpacity = 0.8;


                    columnTemplate.events.on("hit", function (ev) {
                        chart.closeAllPopups();
                        var ttip = `<ul>`;
                        var _object = ev.target.dataItem.dataContext;
                        Object.keys(_object).forEach(function (key, index) {

                            if (key && key!="UNfroamtDate" && key!="Date" && key!="Overall" && key!="Overallmax" && key!="Overallmin" &&  key!="color") {

                                ttip = ttip + `<li><em style='background:` + _colors[index] + `'></em> <span>` + key + `:  ` + (_object[key].min*100).toFixed(2)  + ` - ` + (_object[key].max*100).toFixed(2)  + `</span></li>`;

                            }

                        })

                        ttip = ttip + `</ul>`;
                        var tooltipHTML = `<div class="roleslist_tooltips fourcolumn" ><div>` + ttip +  ` </div></div>`;
                        var popup = chart.openPopup(tooltipHTML);
                        popup.showCurtain = true;
                        popup.verticalAlign = "top"

                        if(ev.target.dataItem.dataContext.UNfroamtDate){
                        popup.title = ev.target.dataItem.dataContext.UNfroamtDate + " (LOW-HI)"

                        }else{
                          popup.title = ev.target.dataItem.dataContext.Date + " (LOW-HI)"

                        }
                     
                    });

                    valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
                    categoryAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
                    if(self.fr == "Weekly"){
categoryAxis.renderer.labels.template.rotation = 270;

                    }

                    chart.scrollbarX = new am4core.Scrollbar();
                    chart.scrollbarX.parent = chart.bottomAxesContainer;
                    chart.zoomOutButton.disabled = true;

                     chart.scrollbarX.stroke = am4core.color("#3F4C76");
                     chart.scrollbarX.strokeOpacity = 0.6
                     chart.scrollbarX.background.fill = am4core.color("#3F4C76");
                     chart.scrollbarX.background.fillOpacity = 0.6
                    chart.scrollbarX.startGrip.background.fill = am4core.color("#3F4C76");
                    chart.scrollbarX.endGrip.background.fill = am4core.color("#3F4C76");
                
              

                    // Add cursor
                    chart.cursor = new am4charts.XYCursor();

                    //self._drawChart(results);
                } else {

                    this.shotsloading = false;
                    this.noshots = true;

                }

            });
        }

    }
};
</script>
