

<template>  
    <div>
        <div class="widget_block">
            <div class="widget_title">
                <h3>DEVELOPMENT AREAS</h3>
                <div class="d-flex align-center">
                    <div class="status_lables pr-8">
                        <label class="real_time">Real Time</label>
                        <label class="projections">Projections</label>
                    </div>                    
                   <v-menu
                        v-model="menu"
                        :close-on-content-click="false"
                        :nudge-width="200"
                        offset-x
                        >
                        <template v-slot:activator="{ on }">
                            <v-btn
                            color="indigo base_button"
                            dark
                            v-on="on"
                            >
                            Customize
                            </v-btn>
                        </template>
                            <div class="drop_menu">
                                <v-row class="marr-5 marl-5">
                                    <v-col cols="12" sm="6" md="6" class="pad5">
                                        <v-text-field
                                            label="Games Played"
                                            solo
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="12" sm="6" md="6" class="pad5">
                                        <v-text-field
                                            label="Minutes"
                                            solo
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="12" sm="6" md="6" class="pad5">
                                        <v-text-field
                                            label="Positions"
                                            solo
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="12" sm="6" md="6" class="pad5">
                                        <v-text-field
                                            label="Usage"
                                            solo
                                        ></v-text-field>
                                    </v-col>                
                                </v-row>
                                <v-btn text @click="menu = false">Submit</v-btn>
                                
                            </div>
                    </v-menu>                  
                </div>
            </div>
            <div class="widget_body pl-0 pb-0 pr-0">
                <v-row>
                    <v-col class="pr-0 pb-0">
                        <div class="area_graphs_block">
                            <div class="area_graph">
                                <!-- <div id="chart">
                                    <apexchart type="bar" height="350" :options="chartOptions" :series="series"></apexchart>
                                </div> -->
                                <div id="areachart"> </div>
                            </div>
                            <div class="widget_bottom">
                                <v-card-title class="offensive">
                                    <ul class="skill_list">
                                        <li><v-checkbox
                                  v-model="checkbox"
                                  label="Blocking"
                                  required
                                ></v-checkbox>
                                </li>
                                        <li><v-checkbox
                                  v-model="checkbox"
                                  label="Stealing"
                                  required
                                ></v-checkbox>
                                </li>
                                        <li><v-checkbox
                                  v-model="checkbox"
                                  label="Again"
                                  required
                                ></v-checkbox>
                                </li>
                                <li><v-checkbox
                                  v-model="checkbox"
                                  label="Rebounding"
                                  required
                                ></v-checkbox>
                                </li>
                                    </ul>
                                    Offense 
                                </v-card-title>
                                <v-card-title class="defensive">
                                     <ul class="skill_list">
                                        <li><v-checkbox
                                  v-model="checkbox"
                                  label="Shooting"
                                  required
                                ></v-checkbox>
                                </li>
                                        <li><v-checkbox
                                  v-model="checkbox"
                                  label="Rebounding"
                                  required
                                ></v-checkbox>
                                </li>
                                        <li><v-checkbox
                                  v-model="checkbox"
                                  label="Passing"
                                  required
                                ></v-checkbox>
                                </li>
                                <li><v-checkbox
                                  v-model="checkbox"
                                  label="Dribbling"
                                  required
                                ></v-checkbox>
                                </li>
                                    </ul>
                                    Defensive skills</v-card-title>
                            </div>
                        </div>
                    </v-col>
                    <!-- <v-col class="pl-0 pb-0">
                        <div class="area_graphs_block">
                            <div class="area_graph">

                            </div>
                            <v-card-title class="defensive">Defensive skills</v-card-title>
                        </div>
                    </v-col> -->
                </v-row>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "development-areas",
    data: () => ({
      dataforchart: [
                 { key: 1, values:
                    [
                        {grpName:'EXPERIENCE', grpValue:2.5},
                        {grpName:'BALLHANDLING', grpValue:4.2},
                    ]
                 },
                 { key: 2, values:
                    [
                        {grpName:'EXPERIENCE', grpValue:4.5},
                        {grpName:'BALLHANDLING', grpValue:3.2},
                    ]
                 },
                 { key: 3, values:
                    [
                        {grpName:'EXPERIENCE', grpValue:4.1},
                        {grpName:'BALLHANDLING', grpValue:2.2},
                    ]
                 } ,
                 { key: 4, values:
                    [
                        {grpName:'EXPERIENCE', grpValue:4.1},
                        {grpName:'BALLHANDLING', grpValue:2.2},
                    ]
                 },
                 { key: 5, values:
                    [
                        {grpName:'EXPERIENCE', grpValue:4.1},
                        {grpName:'BALLHANDLING', grpValue:2.2},
                    ]
                 },
                 { key: 6, values:
                    [
                        {grpName:'EXPERIENCE', grpValue:4.1},
                        {grpName:'BALLHANDLING', grpValue:2.2},
                    ]
                 },
                 { key: 7, values:
                    [
                        {grpName:'EXPERIENCE', grpValue:4.1},
                        {grpName:'BALLHANDLING', grpValue:2.2},
                    ]
                 },
                 { key: 8, values:
                    [
                        {grpName:'EXPERIENCE', grpValue:4.1},
                        {grpName:'BALLHANDLING', grpValue:2.2},
                    ]
                 }                   
                  ],
      itemsB: ['Foo', 'Bar', 'Fizz', 'Buzz']
     
    }),
     mounted(){
          var d3 = window.d3;
          var groupData = this.dataforchart;
              var margin = {top: 10, right: 20, bottom: 30, left: 20},
    width = '1200' - margin.left - margin.right,
    height = 300 - margin.top - margin.bottom;

    
   
    var x0  = d3.scaleBand().rangeRound([0, width], .5);
    var x1  = d3.scaleBand();
    var y   = d3.scaleLinear().rangeRound([height, 0]);

    var xAxis = d3.axisBottom().scale(x0)
                                .tickFormat(function(d) { 

                                    if(d == 1){

                                        return "Shooting"
                                    }
                                   if(d == 2){

                                        return "Rebounding"
                                    }
                                    if(d == 3){

                                        return "Passing"
                                    }
                                    if(d == 4){

                                        return "Dribbling"
                                    }
                                    if(d == 5){

                                        return "Blocking"
                                    }
                                    if(d == 6){

                                        return "Stealing"
                                    }
                                    if(d == 7){

                                        return "Again"
                                    }
                                    if(d == 8){

                                        return "Rebounding"
                                    }
                                 })
                                .tickValues(groupData.map(d=>d.key));

   // var yAxis = d3.axisLeft().scale(y);

    const color =  d3.scaleOrdinal()
    .range(["#E72122", "#0A8C42",]);
    

    var svg = d3.select('#areachart').append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    var categoriesNames = groupData.map(function(d) { return d.key; });
    var rateNames       = groupData[0].values.map(function(d) { return d.grpName; });

    x0.domain(categoriesNames);
    x1.domain(rateNames).rangeRound([0, x0.bandwidth()]);
    y.domain([0, d3.max(groupData, function(key) { return d3.max(key.values, function(d) { return d.grpValue; }); })]);

    svg.append("g")
      .attr("class", "x axis")
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis);


    svg.append("g")
      .attr("class", "y axis")
      .style('opacity','0')
    //   .call(yAxis)
    //     .append("text")
    //         .attr("transform", "rotate(-90)")
    //         .attr("y", 6)
    //         .attr("dy", ".71em")
    //         .style("text-anchor", "end")
    //         .style('font-weight','bold')
    //         .text("Value");

    //svg.select('.y').transition().duration(500).delay(1300).style('opacity','1');

    var slice = svg.selectAll(".slice")
      .data(groupData)
      .enter().append("g")
      .attr("class", "g")
      .attr("transform",function(d) { return "translate(" + x0(d.key) + ",0)"; });

      slice.selectAll("rect")
      .data(function(d) { return d.values; })
        .enter().append("rect")
            .attr("width", x1.bandwidth())
            .attr("x", function(d) { return x1(d.grpName); })
             .style("fill", function(d) { return color(d.grpName) })
             .attr("y", function() { return y(0); })
              .attr("transform", "translate(10,0)")   
             .attr("height", function() { return height - y(0); })
            .on("mouseover", function(d) {
                var ds3= d;
                      d3.tip()
                      .attr("class", "d3-tip")
                      .offset([-8, 0])
                      .html(function(d) { 
                            return ds3.grpName  + " - " + ds3.grpValue ; 
                        });
                d3.select(this).style("fill", '#1F6139');

              //  d3.select(this).style("fill", d3.rgb(color(d.grpName)).darker(2));
            })
            .on("mouseout", function(d) {
                d3.select(this).style("fill", color(d.grpName));
            });


    slice.selectAll("rect")
      .transition()
      .delay(function () {return Math.random()*1000;})
      .duration(1000)
      .attr("y", function(d) { return y(d.grpValue); })
      .attr("height", function(d) { return height - y(d.grpValue); });



      }
}
</script>
