<template>
<div>
    <div class="widget_block" v-if="player">
        <div class="widget_title">
            <h3>STAR System</h3>
            <div></div>
        </div>
        <div class="widget_body tendencies_widget flex-direction-column">
            <div class="shotsloading" v-if="shotsloading">
                <img src="../../assets/images/shotsloading.svg" />
            </div>
            <div class="d-flex">
                <div class="tendencies_graph_wrap" style="width:100%">
                    <div class="tendencies_graph">

                        <div id="starsystemchartdiv" class="timeserieschart"></div>

                    </div>

                </div>
            </div>

        </div>

    </div>
</div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);
var _starsystemchart;
export default {
    name: "star-system",
    components: {},
    props: {
        player: null,
        playerid: null
    },
    data: function () {
        return {
            firstloading: true,
            timeInterval: 'D',
            selecteddates: null,
            shotsloading: false,
            noshots: false,
            tdateperiod: null,
            tselectedvalues: {},
            options: {
                height: '100%',
                size: 5
            },
            selectedones: [
                 "RTP",
                "TRTP"
            ],
            tendencies: [
                "RTP",
                "TRTP"
            ],
            colors: [],
            tendenciesdata: []
        };
    },
    methods: {
        _drawtendencies(_type) {
            var _self = this;
            if(_starsystemchart) _starsystemchart.dispose()
            setTimeout(function () {
                var results = _self.tendenciesdata;
                var data = [];


                results.forEach((d, index) => {
                    var _cd = {};

                    if(d['RTP'] && d['TRTP'] ){
                    _cd.Date = new Date(d.Date);

                    _self.tendencies.forEach(function (_role) {
                        _cd[_role] = +(d[_role]).toFixed(2);
                       

                       // _cd[_role] = +d[_role].toFixed(2);
                    });
                    if(d['star']){
                     _cd['playertype'] = 'Star Player';
                    }else{
                     _cd['playertype'] = 'System Player';
                    }
                    data.push(_cd);
                    }
              
                });
                


                // Create chart instance
                let chart = am4core.create("starsystemchartdiv", am4charts.XYChart);
                _starsystemchart= chart;
                data = _self.lodash.sortBy(data, "Date");
                chart.data = data;
                chart.svgContainer.autoResize = false;
                chart.preloader.background.fill = am4core.color("#000000");
                chart.preloader.background.fillOpacity = 0.1;
                let dateAxis = chart.xAxes.push(new am4charts.DateAxis());
                dateAxis.renderer.grid.template.location = 0;
                dateAxis.renderer.minGridDistance = 60;
                dateAxis.fillOpacity = 0.6;
                let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
                valueAxis.fillOpacity = 0.6;
                valueAxis.max = 100;
                valueAxis.min = 0;
                valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
                var teamseries;
                var playerseries;
                var _colors = _self.colors;
                var _types = _self.tendencies;
                teamseries= chart.series.push(new am4charts.LineSeries());
                teamseries.dataFields.valueY = "TRTP";
                teamseries.dataFields.dateX = "Date";
                teamseries.stroke = am4core.color(_colors[0]);
                teamseries.connect = true;

                playerseries= chart.series.push(new am4charts.LineSeries());
                playerseries.dataFields.valueY = "RTP";
                playerseries.dataFields.dateX = "Date";
                playerseries.stroke = am4core.color(_colors[1]);
                playerseries.connect = true;
            

                var ttip = `<ul>`;
                 ttip = ttip + `<li><em style='background:` + _colors[1] + `'></em> <span>Player: {RTP}</span></li>`;
                 ttip = ttip + `<li><em style='background:` + _colors[0] + `'></em> <span>Team: {TRTP}</span></li>`;
                 ttip = ttip + `<li > <img  src="https://www.amcharts.com/lib/images/star.svg"  width="20"> <span>{playertype}</li>`;
                 ttip = ttip + `</ul>`;

                playerseries.tooltipHTML = `<div class="roleslist_tooltips " ><div><div style="color:#ffffff" class="dateperiod">{dateX.formatDate("MMM d, yyyy")}</div>` + ttip + `</div></div>`;
                playerseries.tooltip.pointerOrientation = "horizontal";
                playerseries.tooltip.background.strokeWidth = 0;
                playerseries.tooltip.getFillFromObject = false;
                playerseries.tooltip.background.fill = am4core.color("#11172B");
                playerseries.tooltip.background.fillOpacity = 0.7;
                chart.events.on("ready", function (ev) {
                    valueAxis.min = valueAxis.minZoomed;
                    valueAxis.max = valueAxis.maxZoomed;
                });

              
                chart.scrollbarX = new am4core.Scrollbar();
                chart.scrollbarX.parent = chart.bottomAxesContainer;
                chart.zoomOutButton.disabled = true;

                chart.scrollbarX.stroke = am4core.color("#3F4C76");
                     chart.scrollbarX.strokeOpacity = 0.6
                     chart.scrollbarX.background.fill = am4core.color("#3F4C76");
                     chart.scrollbarX.background.fillOpacity = 0.6
                    chart.scrollbarX.startGrip.background.fill = am4core.color("#3F4C76");
                    chart.scrollbarX.endGrip.background.fill = am4core.color("#3F4C76");

                chart.cursor = new am4charts.XYCursor();
            }, 150);
        },
        _showhideline(_index){
            let series = _starsystemchart.series.getIndex(_index);
            if (series.isHiding || series.isHidden) {
            series.show();
            }
            else {
            series.hide();
            }
        },
        _gettendencies() {
            this.noshots = false;
            this.shotsloading = true;
            var self = this;
            var postdata = {
                timeInterval: this.timeInterval,
                type: "Tendencies",
                playerName: this.player.PLAYER_NAME
            };
            this.$store.dispatch("getStarSystem", postdata).then(response => {
                var results = JSON.parse(response.data);
                if (results.length > 0) {
                    this.shotsloading = false;
                    this.tendenciesdata = results;
                    this._drawtendencies();
                } else {
                    this.shotsloading = false;
                    this.noshots = true;
                }

            });

        },
    },
    watch: {

        player: function (value) {
        }
    },
    mounted() {
        this.colors = this.chartcolors;
              var self = this;
        setTimeout(function(){
            self._gettendencies();
        },500)
    }
};
</script>
