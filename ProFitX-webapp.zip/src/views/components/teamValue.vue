

<template>  
    <div>
        <div class="widget_block">
            <div class="widget_title">
                <h3>TEAM VALUE</h3>
                <div class="teamvalue_status">
                    <ul>
                        <li class="current_status"><p>Current Stats</p></li>
                        <li class="expected_status"><p>Expected Stats</p></li>
                    </ul>     
                </div>
            </div>
            <div class="widget_body">
                
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "team-Value",
    
}
</script>
