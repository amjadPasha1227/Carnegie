<template>
<div>
    <div class="widget_block visible">
        <div class="widget_title">
            <h3>TRADE VALUE
                <v-tooltip bottom>
                    <template v-slot:activator="{ on, attrs }">
                        <v-btn class="info_btn" v-bind="attrs" v-on="on">
                            <v-icon>mdi-information-outline</v-icon>
                        </v-btn>
                    </template>
                    <span>Dynamic AI model that will project the top 3 trade packages for each athlete and project his real-time asset value with all 30 team rosters based on team CBA salary matching thresholds and athlete’s financial and performance elements. </span>
                </v-tooltip>
            </h3>
            <div class="assets-teams">
                <span class="selectlbl"> Choose Team </span> <span>
                    <multiselect :select-label="''" deselect-label="" v-model="selectedteam" @input="onChange" :options="teams" label="TEAM_NAME" :searchable="true" :close-on-select="true" placeholder="Pick a Team"></multiselect>
                </span>
            </div>
        </div>
        <div class="widget_body trade_widget">
            <div class="trade_wrap">
                <v-row>
                    <v-col class="col-lg-5 col-md-6 col-sm-12 pt-0 pb-0">

                        <div class="trade_info">
                            <div class="trade_asset_title">
                                <figure>
                                    <img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+player.goalserveDetails.PlayerID+".png"' class="align-self-center" :alt="player.PLAYER_NAME">

                                </figure>
                                <h6>{{player.PLAYER_NAME}}<label>{{getposition(player.POSITION)}}</label>

                                    <label v-if="player.FA"> Free Agency Year - {{player.FA}} </label>
                                </h6>
                            </div>
                            <div class="trade_details_wrap">
                                <ul class="trade_details"  v-if="checkWidgetsPermessions('PLAYER_CONTRACTS')" >
                                    <li  v-if="checkWidgetsPermessions('PLAYER_CONTRACTS')" >
                                        <p>Real-Time Contract<span>{{player.RTC | currency}}</span></p>
                                        <p>Team Contract<span>{{player.TC | currency }}</span></p>

                                    </li>
                                </ul>
                                <ul class="trade_profit">
                                    <li><label>ProFitX Rating </label>
                                        <p>{{player.RTP | roundme}}</p>
                                    </li>
                                </ul>
                            </div>
                            <TradeRoles v-if="player" :player="player" />

                        </div>
                    </v-col>
                    <v-col class="col-lg-7 col-md-6 col-sm-12 pb-0">
                        <div class="profit_asset">
                            <h3></h3>
                            <div class="p_assets_content package_tabs">
                                   <div class="shotsloading"  v-if="shotsloading">
                                        <img src="@/assets/images/shotsloading.svg" />
                                    </div>

                                <div v-if="!shotsloading && tradeassetsdata.length == 0">

                                    <p class="npfound" v-if="!player.tradeRestrict" style="    font-size: 24px !important;
    text-align: center;">No Suitable Trade Packages Available </p>
                                    <p class="npfound" v-if="player.tradeRestrict" style="    font-size: 24px !important;
    text-align: center;"> Trade Restricted</p>

                                </div>
                                <div>
                                    <v-tabs background-color="white" color="deep-purple accent-4" right>
                                        <template v-for="(players,index,keys) in tradeassetsdata">
                                            <v-tab :key="index">Package {{keys+1}}</v-tab>
                                        </template>

                                        <v-tab-item v-for="(players,index) in tradeassetsdata" :key="index">
                                            <v-expansion-panels v-model="players.panel" :key="index">
                                                <v-expansion-panel v-for="(item,i) in players" :key="i">
                                                    <v-expansion-panel-header>
                                                        <div class="p_assets_profile">
                                                            <figure><img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+item.goalserveDetails[0].PlayerID+".png"'></figure>
                                                            <h6>{{item.PLAYER_NAME}}<label>{{getposition(item.POSITION)}}</label>
                                                            
                                                             <label v-if="item.FA"> Free Agency Year - {{item.FA}} </label>
                                                            </h6>
                                                        </div>
                                                    </v-expansion-panel-header>
                                                    <v-expansion-panel-content>
                                                        <div class="trade_details_wrap">
                                                            <ul class="trade_details d"  v-if="checkWidgetsPermessions('PLAYER_CONTRACTS')" >

                                                                <li  v-if="checkWidgetsPermessions('PLAYER_CONTRACTS')" >
                                                                    <p>Real-Time Contract<span>{{item.RTC | currency}}</span></p>
                                                                    <p>Team Contract<span>{{item.TC | currency }}</span></p>

                                                                </li>
                                                            </ul>
                                                            <ul class="trade_profit">
                                                                <li><label>ProFitX Rating</label>
                                                                    <p>{{item.RTP | roundme}}</p>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <TradeRoles :player="item" />

                                                    </v-expansion-panel-content>
                                                </v-expansion-panel>
                                            </v-expansion-panels>
                                            <template v-if="!shotsloading && tradeassetsdata.length == 0">
                                                <p class="npfound"> No Suitable Trade Packages Available </p>
                                            </template>
                                        </v-tab-item>
                                    </v-tabs>
                                </div>

                            </div>
                        </div>
                    </v-col>
                </v-row>
            </div>
        </div>
    </div>
</div>
</template>

<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>

<script>
import teamslist from './../../data/teams.json'
import TradeRoles from './../popovers/traderoles'

export default {
    name: "trade-assets",
    components: {
        TradeRoles
    },
    props: {
        player: null,
        playerid: null
    },
    filters: {
        roundme: function (value) {
            if (!value) return ''
            value = Math.round(value).toFixed(0)
            return value
        }
    },
    data() {
        return {
            teams: [],
            selectedteam: null,
            shotsloading: false,
            tradeassetsdata: [],
            currentPlayerroles: [],
            panel: 0,
            positions: [{
                name: "Power Forward",
                value: "F-C"

            }, {
                name: "Forward",
                value: "F"
            }, {
                name: "Versatile Center",
                value: "C-F"
            }, {
                name: "Center",
                value: "C"
            }, {
                name: "Combo Guard",
                value: "G-F"
            }, {
                name: "Guard",
                value: "G"
            }, {
                name: "Wing",
                value: "F-G"
            }]
        }
    },
    mounted() {
        if (this.player.ROLES) {

            var current = this;
            var tlist = this._.filter(teamslist, function (item) {

                return item.TEAM_ID != current.player.TEAM_ID
            })
            this.teams = this._.orderBy(tlist, 'TEAM_NAME')
            this.selectedteam = this.teams[0];
            this._gettradeassets();

        }
    },
    methods: {
               getposition(type) {
            var _p = this.lodash.find(this.positions, function (my) {

                return my.value == type
            })
            return _p.name;

        },
        onChange() {
            this._gettradeassets();
        },
        _gettradeassets() {
            this.shotsloading = true;
            var self = this;
            var postdata = {
                TEAM: this.selectedteam.TEAM_NAME,
                player: this.player.PLAYER_NAME
            };
            this.$store.dispatch("getTradeassets", postdata).then(response => {
                var results = response.data.data;

                if (results != "No Matches" && results.length > 0) {
                    this.shotsloading = false;
                    this.tradeassetsdata = this.lodash.groupBy(results, 'group');

                } else {
                    this.tradeassetsdata = [];
                    this.shotsloading = false;
                }

            });

        }
    }

}
</script>
