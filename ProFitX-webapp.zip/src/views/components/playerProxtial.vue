<template>
<div>
    <div class="widget_block proxtial_widget">
        <div class="widget_title">
            <div class="d-flex align-items-center">
                <h3>PROXTIAL

                    <v-tooltip bottom>
                        <template v-slot:activator="{ on, attrs }">
                            <v-btn class="info_btn" v-bind="attrs" v-on="on">
                                <v-icon>mdi-information-outline</v-icon>
                            </v-btn>
                        </template>
                        <span>TOP ATHLETE DEVELOPMENT AREAS- Provides previous 2 seasons & current season for top 8 athlete development areas and growth % in each skillset where the athlete has improved the most each season.
                            <br />
                            PROJECTED IMPROVEMENT AREAS- Dynamic AI model that displays projections on top 8 athlete development areas that are underdeveloped and the HI-LOW % growth range of improvement for next two seasons.
                        </span>
                    </v-tooltip>

                </h3>
                <ul class="tab_buttons" style="display:none">
                    <li v-bind:class="{ active: selectedtab=='Offensive'  }" @click="setChart(odata,'protential','Offensive')">
                        <a>Offense</a>
                    </li>
                    <li v-bind:class="{ active: selectedtab=='Defensive'  }" @click="setChart(ddata,'protential','Defensive')">
                        <a>Defense</a>
                    </li>
                </ul>
            </div>
            <div>
            </div>
        </div>
        <div class="widget_body" style="height:auto">
            <div class="shotsloading" v-if="shotsloading">
                <img src="../../assets/images/shotsloading.svg" />
            </div>
            <div id="proxtialdiv" class="timeserieschart" style="height:420px; padding-top:0px; "></div>

        </div>
    </div>
</div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);
var _chart;
var xAxis, yAxis;
// import VueApexCharts from 'vue-apexcharts';

export default {
    name: "player-proxtial",
    props: {
        player: null,
        playerid: null
    },
    data: () => ({
        shotsloading: false,
        selectedtab: "Offensive",
        colors: [],
        proxtial: [],
        attributes: [

        ],
        odata: [],
        ddata: [],
        selectedTeams: ["Mid Range",
            "Blocks",
            "Defensive Rebounds",
            "High Post",
            "Offensive Rebounds",
            "Putbacks",
            "Fastbreak Scoring",
            "Low Post",
            "Drive to Basket",
            "Isolation",
            "Center 3PT",
            "Steals",
            "Pick & Roll",
            "Pick & Drive",
            "Pull Up 3PT",
            "Catch & Shoot 3PT",
            "Right 3PT",
            "Left 3PT"
        ],
        selectedpop: {
            name: null,
            value: null
        }

    }),
    methods: {
        _createSeries(value) {
            var series = _chart.series.push(new am4charts.ColumnSeries())
            series.dataFields.valueY = value
            series.dataFields.categoryX = 'group'

            series.columns.template.tooltipText = value + ": {valueY}";

            series.events.on("hidden", this._arrangeColumns);
            series.events.on("shown", this._arrangeColumns);
            //xAxis.sortBySeries = series;
            return series;
        },
        _arrangeColumns() {

            var series = _chart.series.getIndex(0);
            var w = 1 - xAxis.renderer.cellStartLocation - (1 - xAxis.renderer.cellEndLocation);
            if (series.dataItems.length > 1) {
                var x0 = xAxis.getX(series.dataItems.getIndex(0), "categoryX");
                var x1 = xAxis.getX(series.dataItems.getIndex(1), "categoryX");
                var delta = ((x1 - x0) / _chart.series.length) * w;

                if (am4core.isNumber(delta)) {
                    var middle = _chart.series.length / 2;

                    var newIndex = 0;
                    _chart.series.each(function (series) {
                        if (!series.isHidden && !series.isHiding) {
                            series.dummyData = newIndex;
                            newIndex++;
                        } else {
                            series.dummyData = _chart.series.indexOf(series);
                        }
                    })
                    var visibleCount = newIndex;
                    var newMiddle = visibleCount / 2;

                    _chart.series.each(function (series) {
                        var trueIndex = _chart.series.indexOf(series);
                        var newIndex = series.dummyData;

                        var dx = (newIndex - trueIndex + middle - newMiddle) * delta
                        //  xAxis.sortBySeries = series;
                        // series.clustered = false;
                        series.animate({
                            property: "dx",
                            to: dx
                        }, series.interpolationDuration, series.interpolationEasing);

                    })
                }
            }

        },
        _getAttributes() {
            this.noshots = false;
            this.shotsloading = true;
            var self = this;
            var postdata = {
                player: this.player.PLAYER_NAME
            };
            this.$store.dispatch("getproxtial", postdata).then(response => {
                var results = response.data;

                var _unsorted = [];
                var npdate;
                if (results.data.length > 5) {
                    _unsorted = results.data.slice(Math.max(results.data.length - 5, 1))
                    npdate = _unsorted.slice(0, 3);
                } else {
                    _unsorted = results.data;
                    npdate = results.data.slice(0, (results.data.length - 2));

                }
                var _currentseason = results.data[results.data.length - 3];
                var _projectedYear1 = results.data[results.data.length - 2];
                var _projectedYear2 = results.data[results.data.length - 1];
                var nnewdatas = [];
                npdate.forEach((key, index) => {

                    nnewdatas[key.group] = [];
                    var subsort = []
                    Object.keys(key).forEach((skey, sindex) => {
                        if (skey != 'group') {

                            subsort.push({
                                label: skey,
                                value: parseFloat(key[skey].toFixed(2)),
                                uvalue: parseFloat(key[skey].toFixed(2)),
                                lvalue: 0,
                                growth: 0
                            })
                        }

                    })

                    var _sitems = this.lodash.orderBy(subsort, item => item.value, ['desc']);
                    nnewdatas[key.group] = _sitems.slice(0, 20)

                })

                    var pnnewdatas= nnewdatas;
                                    var xnnewdatas = [];

               Object.keys(pnnewdatas).forEach((pskey, psindex) => {

 
    if(pnnewdatas[pskey-1]){

          xnnewdatas[pskey] = [];
                    var subsort = [];
                   pnnewdatas[pskey].forEach((skey, sindex) => {
                          subsort.push({
                                label: skey.label,
                                value: skey.value,
                                uvalue: skey.uvalue,
                                lvalue:skey.lvalue,
                                growth: skey.value-pnnewdatas[pskey-1][sindex].value,
                            })

                    })

                    var _sitems = self.lodash.orderBy(subsort, item => item.growth, ['desc']);
                    xnnewdatas[pskey] = _sitems.slice(0, 8)


    }
   


               })

                var _gsorrtarray1 = [];
                var _ngsorrtarray1 = [];
                Object.keys(_projectedYear1).forEach((key, index) => {
                    if (typeof _projectedYear1[key] === 'object') {
                        var growth = parseFloat((_projectedYear1[key]['value'].toFixed(2) - _currentseason[key]).toFixed(2));
                        if (growth > 0) {
                            _gsorrtarray1.push({
                                label: key,
                                value: _projectedYear1[key]['value'].toFixed(2),
                                uvalue: _projectedYear1[key]['uvalue'].toFixed(2),
                                lvalue: _projectedYear1[key]['vvalue'].toFixed(2),
                                growth: _projectedYear1[key]['value'].toFixed(2) - _currentseason[key].toFixed(2)
                            })
                        } else {
                            _ngsorrtarray1.push({
                                label: key,
                                value: _projectedYear1[key]['value'].toFixed(2),
                                uvalue: _projectedYear1[key]['uvalue'].toFixed(2),
                                lvalue: _projectedYear1[key]['vvalue'].toFixed(2),
                                growth: _projectedYear1[key]['value'].toFixed(2) - _currentseason[key].toFixed(2)
                            })

                        }
                    }

                })

                var _projectedYear1gsorted = this.lodash.orderBy(_gsorrtarray1, item => item.growth, ['desc']);
                var _projectedYear1ngsorted = this.lodash.orderBy(_ngsorrtarray1, item => item.value, ['desc']);
                var finaprojection1 = _projectedYear1gsorted.concat(_projectedYear1ngsorted)

                var _gsorrtarray2 = [];
                var _ngsorrtarray2 = [];
                Object.keys(_projectedYear2).forEach((key, index) => {
                    if (typeof _projectedYear2[key] === 'object') {
                        var growth = parseFloat((_projectedYear2[key]['value'].toFixed(2) - _projectedYear1[key]['value'] ).toFixed(2));
                        if (growth > 0) {
                            _gsorrtarray2.push({
                                label: key,
                                value: _projectedYear2[key]['value'].toFixed(2),
                                uvalue: _projectedYear2[key]['uvalue'].toFixed(2),
                                lvalue: _projectedYear2[key]['vvalue'].toFixed(2),
                                growth: _projectedYear2[key]['value'].toFixed(2) - _projectedYear1[key]['value'].toFixed(2)
                            })
                        } else {
                            _ngsorrtarray2.push({
                                label: key,
                                value: _projectedYear2[key]['value'].toFixed(2),
                                uvalue: _projectedYear2[key]['uvalue'].toFixed(2),
                                lvalue: _projectedYear2[key]['vvalue'].toFixed(2),
                                growth: _projectedYear2[key]['value'].toFixed(2) - _projectedYear1[key]['value'].toFixed(2)
                            })

                        }
                    }

                })

                var _projectedYear2gsorted = this.lodash.orderBy(_gsorrtarray2, item => item.growth, ['desc']);
                var _projectedYear2ngsorted = this.lodash.orderBy(_ngsorrtarray2, item => item.value, ['desc']);
                var finaprojection2 = _projectedYear2gsorted.concat(_projectedYear2ngsorted)
                nnewdatas = xnnewdatas;
                nnewdatas[2023] = finaprojection1.slice(0, 8)
                nnewdatas[2024] = finaprojection2.slice(0, 8)

                var _finalfinaldata = [];
                Object.keys(nnewdatas).forEach((key, index) => {

                    var _items = [];
                    _items["starting"] = -100

                    nnewdatas[key].forEach(function (item, index) {

                        _items[item['label']] = {
                            value: item['value'],
                            uvalue: item['uvalue'],
                            lvalue: item['lvalue'],
                            growth: item['growth'],
                        }

                    })
                    _items["ending"] = -100
                    var _pl = parseInt(key);
                    var _pld = (_pl-1) + "-" + (_pl);
                    _finalfinaldata[_pld] = _items;

                })

              
                var _totla = Object.keys(_finalfinaldata).length;

                var chart = am4core.create("proxtialdiv", am4charts.XYChart);

                //  _.mapValues(_.invert(_.invert(obj)),parseInt);

                chart.paddingBottom = 50;

                chart.cursor = new am4charts.XYCursor();

                // will use this to store colors of the same items
                var colors = {};

                var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
                categoryAxis.dataFields.category = "category";
                categoryAxis.renderer.minGridDistance = 60;
                categoryAxis.renderer.grid.template.location = 0;
                categoryAxis.dataItems.template.text = " {realName}";
                categoryAxis.tooltip.disabled = true;
                categoryAxis.adapter.add("tooltipText", function (tooltipText, target) {
                    if (categoryAxis.tooltipDataItem.dataContext.realName != "starting" && categoryAxis.tooltipDataItem.dataContext.realName != "ending") {
                        return categoryAxis.tooltipDataItem.dataContext.realName;

                    }
                    return ' '
                })

                var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
                valueAxis.tooltip.disabled = true;
                valueAxis.min = 0;
                valueAxis.max = 100;

                // single column series for all data
                var columnSeries = chart.series.push(new am4charts.ColumnSeries());
                columnSeries.tooltipText = "{realName}:{valueY}";
                columnSeries.dataFields.categoryX = "category";
                columnSeries.dataFields.valueY = "value";
                columnSeries.fill = am4core.color("#ff0000")
                columnSeries.fillOpacity = 1;

                columnSeries.adapter.add("tooltipText", function (tooltipText, target) {

                    if (columnSeries.tooltipDataItem.dataContext.lvalue != 0) {
                        return columnSeries.tooltipDataItem.dataContext.realName + " \n GROWTH: " + (columnSeries.tooltipDataItem.dataContext.growth).toFixed(2) + "\n HI: " + columnSeries.tooltipDataItem.dataContext.value + "\n LO: " + columnSeries.tooltipDataItem.dataContext.lvalue;

                    }
                     if (columnSeries.tooltipDataItem.dataContext.lvalue == 0) {
                        return "GROWTH: " + (columnSeries.tooltipDataItem.dataContext.growth).toFixed(2) + "\n "+columnSeries.tooltipDataItem.dataContext.realName+": "+ columnSeries.tooltipDataItem.dataContext.value;

                    }
                })

                var columnSeries2 = chart.series.push(new am4charts.ColumnSeries());
                columnSeries2.dataFields.categoryX = "category";
                columnSeries2.dataFields.valueY = "lvalue";
                columnSeries2.fillOpacity = 0;
                columnSeries2.strokeWidth = 0;
                columnSeries2.strokeOpacity = 0.1;
                columnSeries2.columns.template.width = 12
                columnSeries2.columns.template.dx = -6

                categoryAxis.renderer.minGridDistance = 30;
                columnSeries.columns.template.width = 12
                categoryAxis.renderer.cellStartLocation = 0
                categoryAxis.renderer.cellEndLocation = 0.6

                categoryAxis.renderer.labels.template.disabled = true;

                // fill adapter, here we save color value to colors object so that each time the item has the same name, the same color is used
                columnSeries.columns.template.adapter.add("fill", function (fill, target) {
                    var name = target.dataItem.dataContext.realName;
                    var index = self.selectedTeams.indexOf(name); // 1

                    colors[name] = self.colors[index];
                    target.stroke = colors[name];
                    return colors[name];
                })

                columnSeries2.columns.template.adapter.add("fill", function (fill, target) {
                    var name = target.dataItem.dataContext.realName;
                    var index = self.selectedTeams.indexOf(name); // 1

                    if (!colors[name]) {
                        colors[name] = self.colors[index];
                    }
                    target.stroke = colors[name];
                    return colors[name];
                })

                var rangeTemplate = categoryAxis.axisRanges.template;

                ///// DATA
                var chartData = [];
                var lineSeriesData = [];
                // process data ant prepare it for the chart
                var arraval = []
                var arravale = []
                for (var providerName in _finalfinaldata) {

                    var providerData = _finalfinaldata[providerName];

                    // add data of one provider to temp array
                    var tempArray = [];
                    var count = 0;
                    // add items
                    for (var itemName in providerData) {
                        if (itemName != "quantity") {
                            count++;
                            // we generate unique category for each column (providerName + "_" + itemName) and store realName
                            tempArray.push({
                                category: providerName + "_" + itemName,
                                realName: itemName,
                                value: providerData[itemName]['value'],
                                uvalue: providerData[itemName]['uvalue'],
                                lvalue: providerData[itemName]['lvalue'],
                                growth: providerData[itemName]['growth'],
                                provider: providerName
                            })
                        }
                    }

                    // add quantity and count to middle data item (line series uses it)
                    var lineSeriesDataIndex = Math.floor(count / 2);
                    tempArray[lineSeriesDataIndex].quantity = providerData.quantity;
                    tempArray[lineSeriesDataIndex].count = count;
                    // push to the final data
                    am4core.array.each(tempArray, function (item) {
                        chartData.push(item);
                    })

                    // create range (the additional label at the bottom)
                    var range = categoryAxis.axisRanges.create();
                    arraval.push(tempArray[0].category)
                    arravale.push(tempArray[tempArray.length - 1].category)
                    range.category = tempArray[0].category;
                    range.endCategory = tempArray[tempArray.length - 1].category;
                    range.label.text = tempArray[0].provider;
                    range.label.dy = 30;
                    range.label.truncate = true;
                    range.label.fontWeight = "bold";
                    range.label.tooltipText = tempArray[0].provider;
                    range.label.fill = am4core.color("#7484a1cc");

                    range.axisFill.fill = am4core.color("#000000");
                    range.axisFill.fillOpacity = 0.2;

                    range.label.adapter.add("maxWidth", function (maxWidth, target) {
                        var range = target.dataItem;
                        var startPosition = categoryAxis.categoryToPosition(range.category, 0);
                        var endPosition = categoryAxis.categoryToPosition(range.endCategory, 1);
                        var startX = categoryAxis.positionToCoordinate(startPosition);
                        var endX = categoryAxis.positionToCoordinate(endPosition);
                        return endX - startX;
                    })
                }

                let offrange = categoryAxis.axisRanges.create();
                offrange.category = arraval[0];
                offrange.endCategory = arravale[arravale.length - 3];
                offrange.axisFill.fill = am4core.color('#cf0025');
                offrange.axisFill.fillOpacity = 0;
                offrange.label.rotation = 360
                offrange.label.dy = -320
                offrange.label.inside = true
                offrange.label.text = "Top Athlete Development Areas";
                offrange.label.fill = am4core.color("#7484a1cc");

                let offrange2 = categoryAxis.axisRanges.create();
                offrange2.category = arraval[arraval.length - 2];
                offrange2.endCategory = arravale[arravale.length - 1];
                offrange2.axisFill.fill = am4core.color('#cf0025');
                offrange2.axisFill.fillOpacity = 0.2;
                offrange2.label.rotation = 360
                offrange2.label.dy = -320
                offrange2.label.dx = 10
                offrange2.label.inside = true
                offrange2.label.text = "Projected Improvement Areas";
                offrange2.label.fill = am4core.color("#7484a1cc");

                chart.data = chartData;
                chart.paddingTop = 60;
                valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
                self.shotsloading = false;
            });
        }
    },
    mounted() {
        this.colors = this.chartcolors;
        this._getAttributes();

    }
};
</script>
