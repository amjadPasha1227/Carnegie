<template>
<div>
<v-snackbar
            v-model="snackbar"
            :vertical="true"  
            right
            shaped
            top 
            >
            
            <v-icon v-if="isError">mdi-close-octagon-outline </v-icon>
            <v-icon v-else>mdi-check-decagram</v-icon>
            {{ msg }} 

            <template v-slot:action="{ attrs }">
                <v-btn
                color="indigo"
                text
                v-bind="attrs"
                @click="snackbar = false"
                >
                Close
                </v-btn>
            </template>
            </v-snackbar>
                </div>
</template>
<script>
export default {
   
    props:{
        snackbar:{ type: Boolean, required: false },
        msg:{ type: String, required: true },
        isError:{ type: Boolean, required: false }


    }
}

</script>