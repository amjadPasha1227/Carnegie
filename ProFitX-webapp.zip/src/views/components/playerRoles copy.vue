<template>
<div>
    <div class="widget_block role_widget" v-if="player">
        <div class="widget_title">
            <h3>PLAYER ROLES</h3>
            <div>
                <div class="text-center">
                    <v-dialog v-model="dialog" width="1130" class="role_history">
                        <template v-slot:activator="{ on }">
                            <v-btn @click="getHistoryRoles('yearbrush',getplayerrolesbyplayer,'o')" color="modal_btn" v-on="on">Historical Roles</v-btn>
                        </template>

                        <v-card>
                            <v-row class="mar0">
                                <v-col class="pad0">
                                    <div class="widget_block marb0 role_modal">
                                        <div class="widget_title modal_header">
                                            <div class="modal_title">
                                                <h3>PLAYER ROLES</h3>
                                                <ul class="tab_buttons">

                                                    <li v-bind:class="{ active: offensiveact  }" @click="offensiveact=true;defffensiveact=false"><a>Offensive</a></li>
                                                    <li v-bind:class="{ active: defffensiveact  }" @click="defffensiveact=true;offensiveact=false;getHistoryRoles('yearbrush2',getplayerrolesbyplayer,'d')"><a>Defensive</a></li>

                                                </ul>
                                            </div>
                                            <div>
                                                <v-btn color="primary" text @click="dialog = false">
                                                    <img src="../../assets/images/close.svg" />
                                                </v-btn>
                                            </div>
                                        </div>
                                        <div class="widget_body">
                                            <div class="year_filters" style="display:none">
                                                <ul>
                                                    <li><a class="active">Daily</a></li>
                                                    <li><a>Weekly</a></li>
                                                    <li><a>Monthly</a></li>
                                                </ul>
                                            </div>
                                            <div class="role_graph"></div>
                                            <div class="role_footer">
                                                <div class="year_wise">
                                                    <svg width="1046" v-show="offensiveact" height="400" id="yearbrush" />
                                                    <svg width="1046" v-show="defffensiveact" height="400" id="yearbrush2" />

                                                    <div id='rolestooltip' class="newtip" style="display:none">
                                                        <ul class="roleslist_tooltip" >
                                                                       <div style="color:#ffffff" class="dateperiod"> {{dateperiod | formatDate}}</div>
                                <li v-for="(tendency,key,index) in selectedvaluesout" v-bind:key="key">
                                    <div v-if='key !== "Date" '>
                                        <p>
                                            <em v-bind:style="{ background: colors[index]}"></em>
                                            {{key}}
                                        </p>
                                        <span :id="'v'+index">{{ Math.round(tendency)}}</span>
                                    </div>
                                </li>

                             

                                                        </ul>

                                               

                                                    </div>

                                                </div>

                                                <ul class="status_list" v-show="offensiveact">

                                                    <li v-for="(orole,oroleindex) in offensive" v-bind:key='oroleindex'>

                                                        <span v-bind:style="{ background: colors[oroleindex]}"></span>
                                                        <p>{{orole}}</p>
                                                    </li>
                                                </ul>

                                                <ul class="status_list" v-show="defffensiveact">

                                                    <li v-for="(drole,droleindex) in defensive" v-bind:key='droleindex'>

                                                        <span v-bind:style="{ background: colors[droleindex+6]}"></span>
                                                        <p>{{drole}}</p>
                                                    </li>
                                                </ul>

                                            </div>
                                        </div>
                                    </div>
                                </v-col>
                            </v-row>
                   
                        </v-card>
                    </v-dialog>
                </div>
            </div>
        </div>
        <div class="widget_body role_body" style="min-height:400px">
        
            <div class="shotsloading" v-if="!rolesloaded">
                <img src="../../assets/images/shotsloading.svg" />
            </div>
            <v-row class="mar0">
                <v-col md="6" cols="12" class="pad0">
                    <div class="role_content">
                        <h6>Offensive skills</h6>
                        <ul>
                            <li v-for="(role,index) in currentplayerroles.o" :key="index">
                                <span v-bind:style="{ borderColor: colors[index] }">{{role.v | percentazec  }}</span>
                                <div class="role_status" v-bind:style="{ background: colors[index], width:role.v+'%' }"></div>
                                <label>{{role.k}}</label>
                            </li>
                        </ul>
                    </div>
                </v-col>
                <v-col md="6" cols="12" class="pad0">
                    <div class="role_content defensive_content">
                        <h6>Defensive skills</h6>

                        <ul>
                            <li v-for="(role,index) in currentplayerroles.d" :key="index">
                                <span v-bind:style="{ borderColor: colors[index+6] }">{{role.v | percentazec  }}</span>
                                <div class="role_status" v-bind:style="{ background: colors[index+6], width:role.v+'%' }"></div>
                                <label>{{role.k}}</label>
                            </li>
                        </ul>

                    </div>
                </v-col>
            </v-row>
        </div>
    </div>
</div>
</template>

<script>

import VueApexCharts from "vue-apexcharts";
import moment from "moment";
import { scaleDiscontinuous, discontinuityRange } from 'd3fc-discontinuous-scale';
import { scaleLinear, axisBottom } from 'd3-scale';

export default {
    name: "player-roles",
    props: {
        player: {},
        playerid: null
    },
    data: () => ({
        rolesloaded: false,
        rolesgroup: [],
        currentplayerroles: {},
        getplayerrolesbyplayer: [],
        dialog: false,
        offensiveact: true,
        defffensiveact: false,
        chartloaded: false,
        dateperiod: null,
        selectedvaluesout: [],
        innerdata: [],
        selectedtype: [], 
        offensive: ["Sharp Shooter", "Floor Spacer", "Slasher", "Interior Finisher", "Primary Ball Handler", "High Volume scorer"],
        defensive: ["Turnover Specialist", "Rebouding Specialist", "Rim Protector", "Shutdown Defender", "Perimeter Defender", "High Motor"],
        colors: []
    }),
    methods: {
        playerrole(playername) {
            let returnvalues = [];
            let filter = this.lodash.find(this.rolesgroup, function (o) {
                return o.player == playername
            })

            if (filter != undefined) {
                returnvalues["o"] = [{
                        k: 'Sharp Shooter',
                        v: filter["SHARP SHOOTER"] * 100
                    },
                    {
                        k: 'Floor Spacer',
                        v: filter["FLOOR SPACER"] * 100
                    },
                    {
                        k: 'Slasher',
                        v: filter["SLASHER"] * 100
                    },
                    {
                        k: 'Interior Finisher',
                        v: filter["INTERIOR FINISHER"] * 100
                    },
                    {
                        k: 'Primary Ball Handler',
                        v: filter["PRIMARY BALL HANDLER"] * 100
                    },
                    {
                        k: 'High Volume Scorer',
                        v: filter["HIGH VOLUME SCORER"] * 100
                    }
                ]
                returnvalues["d"] = [{
                        k: 'Turnover Specialist',
                        v: filter["TURNOVER SPECIALIST  "] * 100
                    },
                    {
                        k: 'Rebouding Specialist',
                        v: filter["REBOUNDING SPECIALIST"] * 100
                    },
                    {
                        k: 'Rim Protector',
                        v: filter["RIM PROTECTOR"] * 100
                    },
                    {
                        k: 'Shutdown Defender',
                        v: filter["SHUTDOWN DEFENDER"] * 100
                    },
                    {
                        k: 'Perimeter Defender',
                        v: filter["PERIMETER DEFENDER"] * 100
                    },
                    {
                        k: 'High Motor',
                        v: filter["HIGH MOTOR"] * 100
                    }

                ]

                returnvalues["d"] = this.lodash.orderBy(returnvalues["d"], ['v'], ['desc']);
                returnvalues["o"] = this.lodash.orderBy(returnvalues["o"], ['v'], ['desc']);

            }
            return returnvalues;
        },
        getplayerroles() {
            this.$store
                .dispatch("getplayerroles", {})
                .then(response => {
                    var results = JSON.parse(response.data);
                    this.rolesgroup = results;
                    this.currentplayerroles = this.playerrole(this.player.PLAYER_NAME);
                    this.rolesloaded = true;
                });
            this.$store
                .dispatch("getplayerrolesbyplayer", {
                    playerName: this.player.PLAYER_NAME
                })
                .then(response => {
                    var results = JSON.parse(response.data);
                    this.getplayerrolesbyplayer = results;
                });

        },
        getHistoryRoles(id, ndata, type) {

            var self = this;
            var d3 = window.d3;
            var checkexisting = d3.select("#" + id).select('rect');
            d3.select("#" + id).selectAll("*").remove();
            if (checkexisting._groups[0][0] == null) {
                setTimeout(function () {
                    var svg = d3.select("#" + id),
                        margin = {
                            top: 20,
                            right: 40,
                            bottom: 110,
                            left: 40
                        },
                        margin2 = {
                            top: 330,
                            right: 10,
                            bottom: 30,
                            left: 40
                        },
                        width = +svg.attr("width") - margin.left - margin.right,
                        height = +svg.attr("height") - margin.top - margin.bottom,
                        height2 = +svg.attr("height") - margin2.top - margin2.bottom;

                    var parseDate = d3.timeParse("%b %Y");

                               var c1 = new Date(2019, 5, 30),
                          c2 = new Date(2019, 9, 30),
                          c3 = new Date(2018, 5, 30),
                          c4 = new Date(2018, 9, 30),
                          c5 = new Date(2017, 5, 30),
                          c6 = new Date(2017, 9, 30),
                          c7 = new Date(2016, 5, 30),
                          c8 = new Date(2016, 9, 30),
                          c9 = new Date(2015, 5, 30),
                          c10 = new Date(2015, 9, 30),
                          c11 = new Date(2014, 5, 30),
                          c12 = new Date(2014, 9, 30),
                          c13 = new Date(2013, 5, 30),
                          c14 = new Date(2013, 9, 30),
                          c15 = new Date(2012, 5, 30),
                          c16 = new Date(2012, 9, 30),
                          c17 = new Date(2011, 5, 30),
                          c18 = new Date(2011, 9, 30),
                          c19 = new Date(2010, 5, 30),
                          c20 = new Date(2010, 9, 30);
                          

             var x = scaleDiscontinuous(d3.scaleTime())
                     .discontinuityProvider(discontinuityRange([c1,c2],[c3,c4],[c5,c6],[c7,c8],[c9,c10],[c11,c12],[c13,c14],[c15,c16],[c17,c18],[c19,c20])).range([0, width]),
                        x2 = d3.scaleTime().range([0, width]),
                        y = d3.scaleLinear().range([height, 0]),
                        y2 = d3.scaleLinear().range([height2, 0]);

                    var color = d3.scaleOrdinal().range(self.colors);
                    if(type=="d"){
                        color = d3.scaleOrdinal().range(self.colors.splice(6,12));
                    }
                    const tooltip = d3.select('#rolestooltip');
                    const tooltipLine = svg.append('line');

                    var xAxis = d3.axisBottom(x),
                        xAxis2 = d3.axisBottom(x2),
                        yAxis = d3.axisLeft(y);

                    var brush = d3
                        .brushX()
                        .extent([
                            [0, 0],
                            [width, height2]
                        ])
                        .on("brush end", function () {
                            if (d3.event.sourceEvent && d3.event.sourceEvent.type === "zoom")
                                return; 
                            var s = d3.event.selection || x2.range();
                            x.domain(s.map(x2.invert, x2));

                            focus.selectAll(".line").attr("d", function (d) {
                                return line(d.values)
                            });
                            focus.select(".axis--x").call(xAxis);
                        });

                    var line = d3
                        .line()
                        .x(function (d) {
                            return x(d.Date);
                        }).y(function (d) {
                            return y(d.close);
                        }).curve(d3.curveMonotoneX);

                    svg
                        .append("defs")
                        .append("clipPath")
                        .attr("id", "clip")
                        .append("rect")
                        .attr("width", width)
                        .attr("height", height);

                    var focus = svg
                        .append("g")
                        .attr("class", "focus")
                        .attr(
                            "transform",
                            "translate(" + margin.left + "," + margin.top + ")"
                        );

                    var context = svg
                        .append("g")
                        .attr("class", "context")
                        .attr(
                            "transform",
                            "translate(" + margin2.left + "," + margin2.top + ")"
                        );
                    let states, tipBox;
                    var data = [];
                    ndata.forEach((d, index) => {
                        if (type == "d") {

                            data.push({
                                Date:new Date(d.date),
                                'Turnover Specialist': +d["TURNOVER SPECIALIST  "] * 100,
                                'Rebouding Specialist': +d["REBOUNDING SPECIALIST"] * 100,
                                'Rim Protector': +d["RIM PROTECTOR"] * 100,
                                'Shutdown Defender': +d["SHUTDOWN DEFENDER"] * 100,
                                'Perimeter Defender': +d["PERIMETER DEFENDER"] * 100,
                                'High Motor': +d["HIGH MOTOR"] * 100
                            })

                        } else {

                            data.push({
                                Date: new Date(d.date),
                                'Sharp Shooter': +d["SHARP SHOOTER"] * 100,
                                'Floor Spacer': +d["FLOOR SPACER"] * 100,
                                'Slasher': +d["SLASHER"] * 100,
                                'Interior Finisher': +d["INTERIOR FINISHER"] * 100,
                                'Primary Ball Handler': +d["PRIMARY BALL HANDLER"] * 100,
                                'High Volume Scorer': +d["HIGH VOLUME SCORER"] * 100
                            })

                        }

                    });

        

                    color.domain(
                        d3.keys(data[0]).filter(function (key) {
                            return key !== "Date";
                        })
                    );

                    var stocks = color.domain().map(function (name) {
                        return {
                            name: name,
                            values: data.map(function (d) {
                                // console.log(d[name]);
                                return {
                                    Date: d.Date, 
                                    close: d[name]
                                };
                            })
                        };
                    });

                    x.domain([
                        d3.min(stocks, function (c) {
                            return d3.min(c.values, function (v) {
                                return v.Date;
                            });
                        }),
                        d3.max(stocks, function (c) {
                            return d3.max(c.values, function (v) {
                                return v.Date;
                            });
                        })
                    ]);
                    y.domain([
                           d3.max(stocks, function (c) {
                            return d3.min(c.values, function (v) {
                                return v.close;
                            });
                        }), 
                        d3.max(stocks, function (c) {
                            return d3.max(c.values, function (v) {
                                return v.close;
                            });
                        })
                    ]);
            

                    x2.domain(x.domain());
                    y2.domain(y.domain());

                    var stock = focus
                        .append("g").selectAll(".stockXYZ").data(stocks).enter().append("g").attr("class", "stockXYZ");

                    stock.append("path").attr("class", "line").attr("id", function (d, i) {
                        return "id" + i;
                    }).attr("d", function (d) {
                        return line(d.values);
                    }).style("stroke", function (d) {
                        return color(d.name);
                    });

                    focus
                        .append("g")
                        .attr("class", "axis axis--x axisyear")
                        .attr("transform", "translate(0," + height + ")")
                        .call(xAxis);

                    focus
                        .append("g")
                        .attr("class", "axis axis--y altox axisyearleft")
                        .call(yAxis)

                    var mouseG = svg.append("g")
                        .attr("class", "mouse-over-effects");

                    mouseG.append("path") // this is the black vertical line to follow mouse
                        .attr("class", "mouse-line")
                        .style("stroke", "white")
                        .style("stroke-width", "1px")
                        .style("opacity", "0");

                    var lines = document.getElementsByClassName('line');
                    var pos;
                    var mousePerLine = mouseG.selectAll('.mouse-per-line')
                        .data(stocks)
                        .enter()
                        .append("g")
                        .attr("class", "mouse-per-line");

                    mousePerLine.append("circle")
                        .attr("r", 7)
                        .style("stroke", function (d) {
                            return color(d.name);
                        })
                        .style("fill", "none")
                        .style("stroke-width", "1px")
                        .style("opacity", "0");

                    mousePerLine.append("text")
                        .attr("transform", "translate(10,3)");

                    mouseG.append('svg:rect') // append a rect to catch mouse movements on canvas
                        .attr('width', width+margin.left+margin.right) // can't catch mouse events on a g element
                        .attr('height', height)
                        .attr('fill', 'none')
                        .attr('pointer-events', 'all')
                        .on('mouseout', function () { // on mouse out hide line, circles and text
                            d3.select(".mouse-line")
                                .style("opacity", "0");
                            d3.selectAll(".mouse-per-line circle")
                                .style("opacity", "0");
                            d3.selectAll(".mouse-per-line text")
                                .style("opacity", "0");
                            tooltip.style("display", "none");
                        })
                        .on('mouseover', function () { // on mouse in show line, circles and text
                            d3.select(".mouse-line")
                                .style("opacity", "0.3");
                            tooltip.style("display", "block");

                        }).on('mousemove', function () { // mouse moving over canvas
                            var mouse = d3.mouse(this)

                              var xDate = x.invert(mouse[0]) 


                            d3.selectAll(".mouse-per-line")
                                .attr("transform", function (d, i) {
                                    var xDate = x.invert(mouse[0]) // use 'invert' to get date corresponding to distance from mouse position relative to svg


                                    self.selectedvaluesout=[];
                                  var fselected = self.lodash.find(data, function (o) {
                                        return moment(o['Date']) <= moment(xDate);
                                    });

                                    if (fselected) {
                                        self.dateperiod = fselected['Date'];
                                        self.selectedvaluesout = self._.pickBy(fselected, function (item, key) {
                                            return key !== "Date";
                                        });


                                    }
                                        var lx = mouse[0]-320;
                                        if(lx < 0 ){
                                            lx = mouse[0]+30;
                                        }
                                        tooltip.select('.roleslist_tooltip').style("left", lx + 'px');
                                        tooltip.style("display", "block");
                                    return "translate(" + mouse[0] + ",0)";

                                });

                        });

                    var zx = height2 - 33;
                    context
                        .append("rect")
                        .attr("class", "yearbar")
                        .attr("height", 40)
                        .attr("width", width + 60)
                        .attr("transform", "translate(-35,0)")

                    context
                        .append("g")
                        .attr("class", "axis axis--x axisyear")
                        .attr("transform", "translate(0," + zx + ")")
                        .call(xAxis2);

                    context
                        .append("g")
                        .attr("class", "brush")
                        .call(brush)
                        .call(brush.move, [400, width]);

                }, 500);
 
            }

        },

    },
    watch: {
        selectedvaluesout: function (vvv) {

        },
        player: function (value) {
            var self = this;
            this.selectedtype = this.offensive;
        }
    },
    mounted() {
        this.colors = this.chartcolors;

        var self = this;
        setTimeout(function () {
            self.getplayerroles()
        }, 500)
    }
};
</script>
