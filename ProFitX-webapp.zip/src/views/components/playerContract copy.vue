<template>
<div style="position:relative">

    <div class="widget_block profit_widget">
        <div class="widget_title">
            <h3>Contract Analysis</h3>

        </div>
        <div class="widget_body">

            <div class="yearsFlexwrap">

                <div id="pcchart" class="timeserieschart"></div>

            </div>
            <!--  -->
        </div>
    </div>
</div>
</template>

<script>
import moment from "moment";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);

export default {
    props: {
        player: {}
    },
    data: () => ({
        outlook: [],
        selectedvaluesout: [],
        pioffensive: true,
        pidefensive: false,
        impactdata: [],
        top5picks: []
    }),
    methods: {
        gettop5picks() {

            this.$store
                .dispatch("top5picks", {
                    'SEASON': "2020-2021",
                    'POSITION': this.player.POSITION,
                    'PLAYER_ID': this.player.PLAYER_ID
                })
                .then(response => {

                    this.top5picks = JSON.parse(response.data)

                })

        },

        getprofitimpact() {
            var d3 = window.d3;
            this.isloading = true
            var self = this;
            this.serach = {
                "page": 1,
                "perpage": 5,
                "matcher": {
                    "playerId": this.player.PLAYER_ID
                }
            };

            this.$store
                .dispatch("getProfitImpact", this.serach)
                .then(response => {
                    if (response.error) {
                        Object.assign(this.formerrors, {
                            msg: response.error.message
                        });
                    } else {
                        this.totalCount = response.data.result.totalCount;
                        this.impactdata = response.data.result.list;

                        var data = [{
                                name: "Actual Earnings",
                                values: []
                            },
                            {
                                name: "Projected Earnings",
                                values: []
                            }
                        ];

                        var age = [{
                            name: "Age",
                            values: []
                        }];

                        var p = 0;
                        var _hr = 0;

                        var routlook = []
                        var freeagentYear = "2023";

                        this.impactdata.forEach(function (ide) {
                            var _cs = parseInt(ide.SEASON.split('-')[1]);
                            if (p == 0 && ide.projectionDetails && ide.projectionDetails.PR.length > 0) {

                                data[1].values.push({
                                    date: (_cs + 2).toString(),
                                    price: ide.projectionDetails.PR[1].V,
                                    U: ide.projectionDetails.PR[1].U,
                                    L: ide.projectionDetails.PR[1].L
                                })
                                _hr = ide.projectionDetails.PR[1].U
                                data[1].values.push({
                                    date: (_cs + 1).toString(),
                                    price: ide.projectionDetails.PR[0].V,
                                    U: ide.projectionDetails.PR[0].U,
                                    L: ide.projectionDetails.PR[0].L
                                })

                                data[0].values.push({
                                    date: (_cs + 2).toString(),
                                    price: ide.TC,
                                    U: ide.TC,
                                    L: ide.TC
                                })

                                data[0].values.push({
                                    date: (_cs + 1).toString(),
                                    price: ide.TC,
                                    U: ide.TC,
                                    L: ide.TC
                                })
                                age[0].values.push({
                                    date: (_cs + 2).toString(),
                                    age: ide.AGE + 2
                                })

                                age[0].values.push({
                                    date: (_cs + 1).toString(),
                                    age: ide.AGE + 1
                                })

                                if (ide.outlook) routlook.push(ide.outlook.OUTLOOK)
                                if (ide.outlook) routlook.push(ide.outlook.OUTLOOK)

                            }

                            if (ide.outlook) routlook.push(ide.outlook.OUTLOOK)
                            data[0].values.push({
                                date: (_cs).toString(),
                                price: ide.TC,
                                U: ide.TC,
                                L: ide.TC
                            })
                            data[1].values.push({
                                date: (_cs).toString(),
                                price: ide.RTC,
                                U: ide.RTC,
                                L: ide.RTC
                            })
                            age[0].values.push({
                                date: (_cs).toString(),
                                age: ide.AGE
                            })

                            p++;

                        })

                        var _dt = routlook.reverse();

                        if (_dt.length > 0) {
                            var _t = _dt[_dt.length - 1];
                            _dt.push(_t);
                            var _at = _dt[_dt.length - 1];
                            _dt.push(_at)
                            var _aat = _dt[_dt.length - 1];
                            _dt.push(_aat)
                        }

                        this.outlook = routlook.reverse();

                        var _hrtc = this.lodash.maxBy(data[1].values, 'price').price;
                        var _htc = this.lodash.maxBy(data[0].values, 'price').price;
                        if (_hrtc < _htc) _hrtc = _htc
                        if (_hr > _hrtc) _hrtc = _hr

                        var _mrtc = this.lodash.minBy(data[1].values, 'price').price;
                        var _mtc = this.lodash.minBy(data[0].values, 'price').price;
                        if (_mrtc > _mtc) _mrtc = _mtc

                        /* Format Data */
                        var parseDate = d3.timeParse("%Y");
                        var ndats = [];
                        data[0].values.forEach(function (d) {

                            var _n = 0;

                            if (freeagentYear == moment(d.date).format("Y")) {
                                _n = _hrtc
                            }
                            ndats.push({
                                category: moment(d.date).format("Y"),
                                tc: d.price,
                                tcu: d.U,
                                tcl: d.L,
                                rtc: 0,
                                rcu: 0,
                                rcl: 0,
                                freeagent: _n
                            })

                        });

                        data[1].values.forEach(function (d, index) {
                            ndats[index]['rtc'] = d.price;
                            ndats[index]['rcu'] = d.U;
                            ndats[index]['rcl'] = d.L

                        });
                        var _oneyear = data[1].values[0].price;
                        var _twoyear = data[1].values[0].price + data[1].values[1].price
                        var _threeyear = data[1].values[0].price + data[1].values[1].price + data[1].values[2].price
                        ndats = ndats.reverse();
                   

                       

                       
// Create chart instance
var chart = am4core.create("pcchart", am4charts.XYChart);

// Add data
chart.data = ndats;

// Create axes
var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "category";

      categoryAxis.renderer.grid.template.location = 0;
                        categoryAxis.renderer.minGridDistance = 5;
                        categoryAxis.renderer.labels.template.horizontalCenter = "right";
                        categoryAxis.renderer.labels.template.verticalCenter = "middle";
                        categoryAxis.renderer.labels.template.rotation = 0;


//categoryAxis.renderer.minGridDistance = 30;

categoryAxis.renderer.labels.template.events.on("over", function(ev) {
  var point = categoryAxis.categoryToPoint(ev.target.dataItem.category);
  chart.cursor.triggerMove(point, "soft");
});

categoryAxis.renderer.labels.template.events.on("out", function(ev) {
  var point = categoryAxis.categoryToPoint(ev.target.dataItem.category);
  chart.cursor.triggerMove(point, "none");
});

var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
valueAxis.tooltip.disabled = true;


valueAxis.title.text = "Minutes Player & Performance";
valueAxis.title.rotation = 270;
valueAxis.title.align = "center";
valueAxis.title.valign = "top";
valueAxis.title.fontWeight = 600;
          valueAxis.title.fill = am4core.color("#7484a1cc");            


// Create series
var series = chart.series.push(new am4charts.ColumnSeries());
series.dataFields.valueY = "freeagent";
series.dataFields.categoryX = "category";




 series.adapter.add('tooltipText', (text, target) => {
  let data = target.tooltipDataItem.dataContext;
  let dataeee = target.tooltipDataItem.dataContext[self.selectedones.field];
  return `${self.selectedones.label}: ${Math.round(dataeee)}\nTime: ${data.playsecs}`;
});


   series.tooltip.pointerOrientation = "horizontal";
                series.tooltip.background.strokeWidth = 0;
                series.tooltip.getFillFromObject = false;
                series.tooltip.background.fill = am4core.color("#11172B");
                series.tooltip.background.fillOpacity = 0.7;


              series.fill = am4core.color("#7484a1cc");
                        series.stroke = am4core.color("#7484a1cc");


chart.cursor = new am4charts.XYCursor();
chart.cursor.lineY.disabled = true;
chart.cursor.lineX.disabled = true;




                    }

                });

        }

    },
    mounted() {
        this.gettop5picks();
        this.getprofitimpact();

    }
};
</script>

<style>
.contractspopup {

    width: 800px;

}
</style>
