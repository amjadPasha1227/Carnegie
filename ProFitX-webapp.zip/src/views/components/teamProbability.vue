<template>
  <div class="pI_match_block">
    <div
      @click="gotoIndexdetail(gamedata)"
      class="pI_match_info"
      style="cursor: pointer"
      v-bind:class="{ prematch: gamedata.Status != 'InProgress' }"
    >
      <!-- <span class="match_status" v-if="gamedata.Status == 'InProgress'">
        <template>LIVE</template>
      </span> -->
      <div class="live-alert" v-if="gamedata.Status == 'InProgress'">
        <div class="waveWrapper left">
          <div class="waveWrapperInner delay1">
            <div class="wave"></div>
          </div>
          <div class="waveWrapperInner delay2">
            <div class="wave"></div>
          </div>
          <div class="waveWrapperInner delay3">
            <div class="wave"></div>
          </div>
        </div>
        <div class="wave-text">
          <div class="text-wrapper">
            <h2>Live</h2>
          </div>
        </div>
        <div class="waveWrapper right">
            <div class="waveWrapperInner delay1">
              <div class="wave"></div>
            </div>
            <div class="waveWrapperInner delay2">
              <div class="wave"></div>
            </div>
            <div class="waveWrapperInner delay3">
              <div class="wave"></div>
            </div>
        </div>
      </div>
      <div class="PI_match_teams">
        <figcaption>{{ gamedata.HomeTeam.Name }}</figcaption>
        <figure v-if="gamedata.HomeTeam">
          <img :src="gamedata.HomeTeam.logo" />
        </figure>
        <span
          v-if="gamedata.LiveProb"
          >{{ gamedata.LiveProb.home_score}}</span
        >
        <label v-if="gamedata.Status == 'InProgress' && gamedata.LiveProb"
          ><small>SCORES</small><b>{{ gamedata.LiveProb.elapsed }}</b></label
        >
        <label v-else-if="gamedata.Status == 'Scheduled'"
          ><small>Starts In</small><b>{{ startsIn }} hrs</b></label
        >
        <label v-else-if="gamedata.Status != 'InProgress' && gamedata.Status != 'Scheduled'"
          ><small>Status</small><b>{{gamedata.Status}}</b></label
        >

        <span
          v-if="gamedata.LiveProb"
          >{{ gamedata.LiveProb.away_score }}</span
        >
        <figure v-if="gamedata.AwayTeam">
          <img :src="gamedata.AwayTeam.logo" />
        </figure>
        <figcaption>{{ gamedata.AwayTeam.City }}</figcaption>
      </div>
      <div class="PI_team_scores">
        <div class="team1_score">
          <div
            class="score_value"
            v-bind:class="{
              high: HomeWinPer * 100 > 60,
              low: HomeWinPer * 100 < 30,
              medium:
                HomeWinPer * 100 > 30 &&
                HomeWinPer * 100 < 60,
            }"
          >
            <label
              >{{ HomeWinPer | percentagecustom(1)
              }}<sub>%</sub></label
            >
            <span>H</span>
          </div>
          <div
            class="score_progress"
            v-bind:class="{
              high: HomeWinPer * 100 > 60,
              low: HomeWinPer * 100 < 30,
              medium:
                HomeWinPer * 100 > 30 &&
                HomeWinPer * 100 < 60,
            }"
            v-bind:style="{ width: HomeWinPer * 100 + '%' }"
          ></div>
        </div>
        <div class="team2_score">
          <div
            class="score_progress"
            v-bind:class="{
              high: AwayWinPer * 100 > 60,
              low: AwayWinPer * 100 < 30,
              medium:
                AwayWinPer * 100 > 30 &&
                AwayWinPer * 100 < 60,
            }"
            v-bind:style="{ width: AwayWinPer * 100 + '%' }"
          ></div>
          <div
            class="score_value"
            v-bind:class="{
              high: AwayWinPer * 100 > 60,
              low: AwayWinPer * 100 < 30,
              medium:
                AwayWinPer * 100 > 30 &&
                AwayWinPer * 100 < 60,
            }"
          >
            <span>A</span>
            <label
              >{{ AwayWinPer | percentagecustom(1)
              }}<sub>%</sub></label
            >
          </div>
        </div>
        <strong class="trophy"><img src="@/assets/images/trophy.png" /></strong>
      </div>
    </div>
    <div class="PI_match_details">
      <v-tabs class="pro_tabs" dark v-model="tab">
        <v-tab><span>Wins</span></v-tab>
        <v-tab><span>Season Stats </span></v-tab>

        <v-tab-item>
          <div>
            <v-simple-table>
              <template v-slot:default>
                <thead>
                  <tr>
                    <!-- <th>&nbsp;</th> -->
                    <th ></th>
                    <th>This Season</th>
                    <th>Previous Matches</th>
                  </tr>
                </thead>
                <tbody>
                  <template>
                    <tr>
                      <td class="team_logo">
                        <figure class="team_logo">
                          <img width="50" :src="gamedata.HomeTeam.logo" />
                        </figure>
                      </td>
             
                      <td>
                        <div class="seassion_matches">
                          <p>
                            <b>{{ gamedata.HomeTeam.stats[0].Wins }}</b
                            ><br />WINS
                          </p>
                          <p>
                            <b>{{ gamedata.HomeTeam.stats[0].Losses }}</b
                            ><br />Losses
                          </p>
                         
                        </div>
                      </td>
                      <td>
                        <div
                          class="Previous_matches"
                          v-bind:class="{
                            match1:
                              gamedata.HomeTeam.lastgame.AwayTeamScore >
                              gamedata.HomeTeam.lastgame.HomeTeamScore,
                            match2:
                              gamedata.HomeTeam.lastgame.AwayTeamScore <
                              gamedata.HomeTeam.lastgame.HomeTeamScore,
                          }"
                        >
                          <figure>
                            <img
                              width="50"
                              :src="
                                'https://profitx.ai/api/viewfile?path=teams/' +
                                gamedata.HomeTeam.lastgame.AwayTeamID +
                                '.png'
                              "
                            />
                            <figcaption>
                              {{ gamedata.HomeTeam.lastgame.AwayTeamScore }}
                            </figcaption>
                          </figure>
                          <span><img src="@/assets/images/vs.svg" /></span>
                          <figure>
                            <figcaption>
                              {{ gamedata.HomeTeam.lastgame.HomeTeamScore }}
                            </figcaption>
                            <img
                              width="50"
                              :src="
                                'https://profitx.ai/api/viewfile?path=teams/' +
                                gamedata.HomeTeam.lastgame.HomeTeamID +
                                '.png'
                              "
                            />
                          </figure>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td class="team_logo">
                        <figure class="team_logo">
                          <img width="50" :src="gamedata.AwayTeam.logo" />
                        </figure>
                      </td>
                     
                      <td>
                        <div class="seassion_matches">
                          <p>
                            <b>{{ gamedata.AwayTeam.stats[0].Wins }}</b
                            ><br />WINS
                          </p>
                                 <p>
                            <b>{{ gamedata.AwayTeam.stats[0].Losses }}</b
                            ><br />Losses
                          </p>
                  
                        </div>
                      </td>
                      <td>
                        <div
                          class="Previous_matches"
                          v-bind:class="{
                            match1:
                              gamedata.AwayTeam.lastgame.AwayTeamScore >
                              gamedata.AwayTeam.lastgame.HomeTeamScore,
                            match2:
                              gamedata.AwayTeam.lastgame.AwayTeamScore <
                              gamedata.AwayTeam.lastgame.HomeTeamScore,
                          }"
                        >
                          <figure>
                            <img
                              width="50"
                              :src="
                                'https://profitx.ai/api/viewfile?path=teams/' +
                                gamedata.AwayTeam.lastgame.AwayTeamID +
                                '.png'
                              "
                            />
                            <figcaption>
                              {{ gamedata.AwayTeam.lastgame.AwayTeamScore }}
                            </figcaption>
                          </figure>
                          <span><img src="@/assets/images/vs.svg" /></span>
                          <figure>
                            <figcaption>
                              {{ gamedata.AwayTeam.lastgame.HomeTeamScore }}
                            </figcaption>
                            <img
                              width="50"
                              :src="
                                'https://profitx.ai/api/viewfile?path=teams/' +
                                gamedata.AwayTeam.lastgame.HomeTeamID +
                                '.png'
                              "
                            />
                          </figure>
                        </div>
                      </td>
                    </tr>
                  </template>
                  <!-- <template v-else>
                              <tr>
                                  <td colspan="6" class="center-align no-data">No Users Found!</td>
                              </tr>
                          </template> -->
                </tbody>
              </template>
            </v-simple-table>
          </div>
        </v-tab-item>

        <v-tab-item>
          <div class="stats_table"> 
            <v-simple-table >
              <template v-slot:default>
                <thead>
                  <tr>
                    <th>&nbsp;</th>
                    <th>GP</th>
                    <th>Total Points</th>
                    <th>Points</th>
                    <th>3PTA</th>
                    <th>3PT%</th>
                    <th>FGA</th>
                    <th>FG%</th>
                     <th>FTA</th>
                    <th>FT%</th>
                    <th>BLK</th>
                    <th>AST</th>
                    <th>STL</th>
                     <th>Rebounds</th>
                      <th>Fouls</th>
                  </tr>
                </thead>
                <tbody>
                  <template>
                    <tr>
                      <td class="team_logo">
                        <figure class="team_logo" v-if="gamedata.HomeTeam">
                          <img width="30" :src="gamedata.HomeTeam.logo" />
                        </figure>
                      </td>
                      <td>{{ gamedata.HomeTeam.stats[0].Games }}</td>
                      <td>{{ gamedata.HomeTeam.stats[0].Points }}</td>
                      <td>{{ Math.round(gamedata.HomeTeam.stats[0].Points/gamedata.HomeTeam.stats[0].Games) }}</td>
                      <td>{{ Math.round(gamedata.HomeTeam.stats[0]["ThreePointersAttempted"]/gamedata.HomeTeam.stats[0].Games) }}</td>

                         <td>
                        {{ gamedata.HomeTeam.stats[0]["ThreePointersPercentage"] }}
                      </td>
                                            <td>{{ Math.round(gamedata.HomeTeam.stats[0]["FieldGoalsAttempted"]/gamedata.HomeTeam.stats[0].Games) }}</td>

                      <td>
                        {{gamedata.HomeTeam.stats[0]["FieldGoalsPercentage"] }}
                      </td>
                                                                  <td>{{ Math.round(gamedata.HomeTeam.stats[0]["FreeThrowsAttempted"]/gamedata.HomeTeam.stats[0].Games) }}</td>

                      <td>
                        {{ gamedata.HomeTeam.stats[0]["FreeThrowsPercentage"] }}
                      </td>
                    
                      <td>{{ Math.round(gamedata.HomeTeam.stats[0].BlockedShots/gamedata.HomeTeam.stats[0].Games) }}</td>
                      <td>{{ Math.round(gamedata.HomeTeam.stats[0].Assists/gamedata.HomeTeam.stats[0].Games) }}</td>
                      <td>{{ Math.round(gamedata.HomeTeam.stats[0].Steals/gamedata.HomeTeam.stats[0].Games) }}</td>
                      <td>{{ Math.round(gamedata.HomeTeam.stats[0].Rebounds/gamedata.HomeTeam.stats[0].Games) }}</td>
                      <td>{{ Math.round(gamedata.HomeTeam.stats[0].PersonalFouls/gamedata.HomeTeam.stats[0].Games) }}</td>


                   
                    </tr>
                    <tr>
                      <td class="team_logo">
                        <figure class="team_logo" v-if="gamedata.AwayTeam">
                          <img width="30" :src="gamedata.AwayTeam.logo" />
                        </figure>
                      </td>
                           <td>{{ gamedata.AwayTeam.stats[0].Games }}</td>
                      <td>{{ gamedata.AwayTeam.stats[0].Points }}</td>
                      <td>{{ Math.round(gamedata.AwayTeam.stats[0].Points/gamedata.AwayTeam.stats[0].Games) }}</td>
                      <td>{{ Math.round(gamedata.AwayTeam.stats[0]["ThreePointersAttempted"]/gamedata.AwayTeam.stats[0].Games) }}</td>

                         <td>
                        {{ gamedata.AwayTeam.stats[0]["ThreePointersPercentage"] }}
                      </td>
                                            <td>{{ Math.round(gamedata.AwayTeam.stats[0]["FieldGoalsAttempted"]/gamedata.AwayTeam.stats[0].Games) }}</td>

                      <td>
                        {{gamedata.AwayTeam.stats[0]["FieldGoalsPercentage"] }}
                      </td>
                                                                  <td>{{ Math.round(gamedata.AwayTeam.stats[0]["FreeThrowsAttempted"]/gamedata.AwayTeam.stats[0].Games) }}</td>

                      <td>
                        {{ gamedata.AwayTeam.stats[0]["FreeThrowsPercentage"] }}
                      </td>
                    
                      <td>{{ Math.round(gamedata.AwayTeam.stats[0].BlockedShots/gamedata.AwayTeam.stats[0].Games) }}</td>
                      <td>{{ Math.round(gamedata.AwayTeam.stats[0].Assists/gamedata.AwayTeam.stats[0].Games) }}</td>
                      <td>{{ Math.round(gamedata.AwayTeam.stats[0].Steals/gamedata.AwayTeam.stats[0].Games) }}</td>
                      <td>{{ Math.round(gamedata.AwayTeam.stats[0].Rebounds/gamedata.AwayTeam.stats[0].Games) }}</td>
                      <td>{{ Math.round(gamedata.AwayTeam.stats[0].PersonalFouls/gamedata.AwayTeam.stats[0].Games) }}</td>


                    </tr>
                  </template>
                  <!-- <template v-else>
                              <tr>
                                  <td colspan="6" class="center-align no-data">No Users Found!</td>
                              </tr>
                          </template> -->
                </tbody>
              </template>
            </v-simple-table>
          </div>
        </v-tab-item>

        <v-tab-item>
          <div class="team_lineup_cnt">
            <div class="team_lineup">
              <div class="team_logo">
                <figure class="team_logo">
                  <img width="50" :src="gamedata.HomeTeam.logo" />
                </figure>
              </div>
              <div class="linup_slider">
                <swiper ref="mySwiper" :options="linupslider1">
                  <swiper-slide
                    v-for="(player, index) in gamedata.HomeLineup"
                    :key="index"
                  >
                    <figure>
                      <img
                        :src="
                          siteUrl +
                          '/api/viewfile?path=playerimages/sportsdataio/' +
                          player.PlayerID +
                          '.png'
                        "
                      />
                      <p>
                        {{ player.FirstName }} {{ player.LastName
                        }}<span>{{ player.Position }}</span>
                      </p>
                    </figure>
                  </swiper-slide>
                </swiper>
                <div>
                  <div class="swiper-button-prev prev1">
                    <span class="icon-play-flip"></span>
                  </div>
                  <div class="swiper-button-next next1">
                    <span class="icon-play"></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="team_lineup">
              <div class="team_logo">
                <figure class="team_logo">
                  <img width="50" :src="gamedata.AwayTeam.logo" />
                </figure>
              </div>
              <div class="linup_slider">
                <swiper ref="mySwiper" :options="linupslider2">
                  <swiper-slide
                    v-for="(player, index) in gamedata.AwayLineup"
                    :key="index"
                  >
                    <figure>
                      <img
                        :src="
                          siteUrl +
                          '/api/viewfile?path=playerimages/sportsdataio/' +
                          player.PlayerID +
                          '.png'
                        "
                      />
                      <p>
                        {{ player.FirstName }} {{ player.LastName
                        }}<span>{{ player.Position }}</span>
                      </p>
                    </figure>
                  </swiper-slide>
                </swiper>
                <div>
                  <div class="swiper-button-prev prev2">
                    <span class="icon-play-flip"></span>
                  </div>
                  <div class="swiper-button-next next2">
                    <span class="icon-play"></span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </v-tab-item>
      </v-tabs>
    </div>
  </div>
</template>

<script>
import teams from "@/data/teams.json";
import "swiper/dist/css/swiper.css";
import { swiper, swiperSlide } from "vue-awesome-swiper";
import moment from "moment";

export default {
  components: {
    swiper,
    swiperSlide,
  },
  props: {
    gamedata: null,
  },
  methods: {
    gotoIndexdetail(data) {
      this.$router.push({
        name: "probability-details",
        params: { id: data.gameid },
      });
    },
  },
  mounted() {
    this.siteUrl = process.env.VUE_APP_API_URL;
  },
  computed: {
    HomeWinPer(){
      if(this.gamedata.Status == "InProgress" || this.gamedata.Status == "Final"){

        return this.gamedata.LiveProb.home_win_pct
      }
      return this.gamedata.home_win_pct
    },
    AwayWinPer(){
      if(this.gamedata.Status == "InProgress" || this.gamedata.Status == "Final"){

        return this.gamedata.LiveProb.away_win_pct
      }
      return this.gamedata.away_win_pct
    },
    startsIn() {
      if (
        moment
          .utc(this.gamedata.gamedate)
          .isAfter(moment().utc())
      ) {
        return moment
          .utc(this.gamedata.gamedate)
          .diff(moment().utc(), "hours");
      }
      return moment()
        .utc()
        .diff(moment(this.gamedata.gamedate), "hours");
    },
    iscompleted() {
      return moment().isBefore(moment(this.gamedatadatee));
    },
    livematch() {
      return (
        moment().isSameOrAfter(moment(this.gamedatadate)) &&
        moment().isSameOrBefore(moment(this.gamedatadatee))
      );
    },
    getHTeamlogo() {
      return this.gamedata.HomeTeam.NbaDotComTeamID;
    },
    getaTeamlogo() {
      return this.gamedata.AwayTeam.NbaDotComTeamID;
    },
  },

  data() {
    return {
      tab: null,
      siteUrl: null,
      linupslider1: {
        slidesPerView: "auto",
        spaceBetween: 0,
        pagination: {
          el: ".swiper-pagination",
        },
        navigation: {
          nextEl: ".next1",
          prevEl: ".prev1",
        },
      },
      linupslider2: {
        slidesPerView: "auto",
        spaceBetween: 0,
        pagination: {
          el: ".swiper-pagination",
        },
        navigation: {
          nextEl: ".next2",
          prevEl: ".prev2",
        },
      },
    };
  },
};
</script>
