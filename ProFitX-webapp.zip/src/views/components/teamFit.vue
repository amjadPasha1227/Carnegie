<template>
  <div>
    <div class="widget_block teamfit_block">
      <div class="widget_title">
        <div class="team_title" v-if="teamfitdata.currentteam">
          <h3>
            TEAMFIT

            <v-tooltip bottom>
              <template v-slot:activator="{ on, attrs }">
                <v-btn class="info_btn" v-bind="attrs" v-on="on">
                  <v-icon>mdi-information-outline</v-icon>
                </v-btn>
              </template>
              <span
                >Dynamic AI model that will display the athlete’s current team
                and 5 best team fits based on his skillset, strengths and
                weaknesses in his game while analyzing team style of play and
                team needs to project ratings. Option to select rest of teams
                broken down into Offense, Defense, and Playmaking areas is
                available in toolbar.
              </span>
            </v-tooltip>
          </h3>
          <ul class="tab_buttons">
            <li
              v-bind:class="{ active: selectedtab == 'Offensive' }"
              @click="setChart(odata, 'teamFit', 'Offensive')"
            >
              <a>Offense</a>
            </li>
            <li
              v-bind:class="{ active: selectedtab == 'Defensive' }"
              @click="setChart(ddata, 'teamFit', 'Defensive')"
            >
              <a>Defense</a>
            </li>
            <li
              v-bind:class="{ active: selectedtab == 'Playmaking' }"
              @click="setChart(pdata, 'teamFit', 'Playmaking')"
            >
              <a>Playmaking</a>
            </li>
             <li
              v-bind:class="{ active: selectedtab == 'Custom' }"
              @click="setChart(pdata, 'teamFit', 'Custom')"
            >
              <a>Custom</a>
            </li>
          </ul>
        </div>
        <div>
          <v-row>
            <v-col>

                 <div class="assets-teams" v-if="selectedtab == 'Custom' ">
          <span class="selectlbl"> Select an Attribute</span>
          <span>
            <multiselect
              :select-label="''"
              deselect-label=""
              v-model="sattribute"
              :options="attributeslist"
              :close-on-select="true"
              @input="filterPlayers"
              placeholder="Select an Attribute"
            ></multiselect>
          </span>
        </div>

              <div class="dropdown_menu" v-if="selectedtab != 'Custom' ">
                <v-menu offset-y :close-on-content-click="false">
                  <template v-slot:activator="{ on }">
                    <!-- <v-btn >
                                Dropdown
                    </v-btn>-->
                    <v-text-field
                      v-on="on"
                      placeholder="Select Team"
                      :rules="rules"
                      hide-details="auto"
                    ></v-text-field>
                    <v-icon>mdi-chevron-down</v-icon>
                  </template>
                  <v-list class="dropdown_list">
                    <v-list-item class="reset_wrap"> </v-list-item>
                    <template v-for="(team, index) in teams">
                      <v-list-item
                        :key="index"
                        v-if="teamfitdata.currentteam[0].TEAM != team.TEAM_NAME"
                      >
                        <v-checkbox
                          :disabled="
                            selectedTeams.length > 4 &&
                            selectedTeams.indexOf(team.TEAM_NAME) === -1
                          "
                          name="teamarray"
                          :value="team.TEAM_NAME"
                          v-model="selectedTeams"
                          :label="team.TEAM_NAME"
                        ></v-checkbox>
                      </v-list-item>
                    </template>
                  </v-list>
                </v-menu>
              </div>
            </v-col>
          </v-row>
        </div>
      </div>
      <div class="widget_body pad0" v-if="teamfitdata">
        <div class="teamfit_widget">
          <div class="skill_list">
            <ul class="row mar0" v-if="selectedtab != 'Custom' ">
              <li class="col active">
                <p>
                  <em
                    v-bind:style="{
                      background: setdarkmode(
                        teamfitdata.currentteam[0].TEAM,
                        0
                      ),
                    }"
                  ></em
                  >{{ teamfitdata.currentteam[0].TEAM }}
                </p>
                <span>CURRENT TEAM</span>
              </li>
              <!-- <li 
              v-for="team in randomteams" :key="team" class="col" v-bind:style="{ background: team.color}">
                <p>{{team.TEAM_NAME}}</p>
              </li> -->
              <template  v-for="(team, index) in selectedTeams">
              <li
                class="col"
                v-if="teamfitdata.currentteam[0].TEAM!=team"
                v-bind:key="index"
              >
                <p >
                  <em
                    v-bind:style="{ background: setdarkmode(team, index + 1) }"
                  ></em
                  >{{ team }}
                </p>
              </li>
              </template>
            </ul>
          </div>
          <div class="teamfit_graph">
            <div
              class="common_tooltip"
              id="teamfittooltip"
              style="display: none"
            >
              <label>
                {{ selectedpop.name }}
                <span>{{ selectedpop.value }} %</span>
              </label>
            </div>

            <div id="teamFit"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>

<script>
import teamslist from "./../../data/teams.json";

export default {
  name: "team-fit",
  props: {
    player: null,
    playerid: null,
  },
  data: () => ({
    sattribute:"Offensive Impact",
    teams: [],
    selectedTeams: [],
    selectedtab: "Offensive",
    randomteams: [],
    teamselected: [],
    odata: [],
    ddata: [],
    pdata: [],
    sseason: [],
    checkbox: [],
    teamfitdata: {},
    attributeslist: [
      "Offensive Impact",
      "Interior Scoring",
      "Attacking the Basket",
      "Perimeter Scoring",
      "Ball Handing",
      "Perimeter Assists",
      "Interior Assists",
      "Free Throws",
      "Defensive IQ",
      "Interior Defense",
      "Perimeter Defense",
      "Defensive Impact",
    ],
    selectedpop: {
      name: null,
      value: null,
    },
    array: [],
    colors: [
      {
        color: "#248B43",
      },
      {
        color: "#C9AB2E",
      },
      {
        color: "#27B2DB",
      },
      {
        color: "#8434E2",
      },
      {
        color: "#739025",
      },
      {
        color: "#2FA7A7",
      },
      {
        color: "#C73434",
      },
    ],
    boolean: false,
    string: null,
    novalue: null,
    disabled: true,
    obj1: {
      name: "obj1",
    },
    obj2: {
      name: "obj2",
    },
    obj: null,
    indeterminate: true,
    items: ["By Player", "By Team", "By Player", "By Team"],
  }),
  methods: {
    filterPlayers(){

      this.setChart(this.pdata, 'teamFit', 'Custom')
    },
    setdarkmode(index, a) {
      var d3 = window.d3;

      var color =  this.colors[a];

      return d3.rgb(color).darker(0);
    },
    setChart(data, id, selectedtab) {
      this.selectedtab = selectedtab;
      var self = this;
      if(selectedtab == "Custom"){

           data = [];
         var currentitem = {};
        currentitem.key = this.sattribute;
        var avalues = [];

        avalues.push({
          name: self.teamfitdata.currentteam[0].TEAM,
          value: (self.teamfitdata.currentteam[0][self.sattribute] * 100).toFixed(2),
        });

        self.teams.forEach(function (item) {
          var ci = self.lodash.find(self.teamfitdata.data, function (o) {
            return o.TEAM == item.TEAM_NAME && o.TEAM!=self.teamfitdata.currentteam[0].TEAM;
          });
         if(ci){
          avalues.push({
            name: item.TEAM_NAME,
            value: (ci[self.sattribute] * 100).toFixed(2),
          });
          }
        });
        currentitem.values = avalues;

        data.push(currentitem);


      }
        
  


      var d3 = window.d3;

      var vh = 270;
      var bwidth  = 18;
       if(selectedtab == "Custom"){
         vh = 320;
         bwidth  = 19;
       }
      var margin = {
          top: 20,
          right: 20,
          bottom: 30,
          left: 40,
        },
        width = window.innerWidth - 331 - margin.left - margin.right,
        height = vh - margin.top - margin.bottom;
      var x0 = d3.scaleBand().rangeRound([0, width], 0.5);
      var x1 = d3.scaleBand();
      var y = d3.scaleLinear().rangeRound([height, 0]);
      var xAxis = d3
        .axisBottom()
        .scale(x0)
        .tickValues(data.map((d) => d.key));
      var yAxis = d3.axisLeft().scale(y);
      d3.select("#" + id)
        .select("svg")
        .remove();
      var svg = d3
        .select("#" + id)
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

      var values = data.map(function (d) {
        return d.key;
      });
      var groups = data[0].values.map(function (d) {
        return d.name;
      });

      x0.domain(values);
      x1.domain(groups).rangeRound([0, x0.bandwidth()]);
      y.domain([0, 100]);

      svg
        .append("g")
        .attr("class", "axis axis--x axisyear")
        .attr("transform", "translate(-55," + height + ")")
        .call(xAxis);

      svg
        .append("g")
        .attr("class", "axis axis--y altox axisyearleft")
        .call(yAxis.ticks(5))
        .append("text");

      svg
        .select(".y")
        .transition()
        .duration(500)
        .delay(1300)
        .style("opacity", "1");

      var slice = svg
        .selectAll(".slice")
        .data(data)
        .enter()
        .append("g")
        .attr("class", "g")
        .attr("width", 90)
        .attr("transform", function (d) {
          return "translate(" + x0(d.key) + ",0)";
        });

      var datsp = slice
        .selectAll("rect")
        .data(function (d) {
          return d.values;
        })
        .enter()
        .append("rect");

      datsp
        .attr("width", bwidth)
        .attr("x", function (d, i) {
          var px = x1(d.name);
          if(selectedtab == "Custom"){
          px = i * (bwidth+10);
          }else{
            if (i != 0) {
            px = i * (bwidth+10);
          }

          }
         

          return px;
        })
        .style("fill", function (d, p) {
          var color =  self._.find(self.colors, function (obj, index) {
              return index === p;
            });
          return d3.rgb(color).darker(0);
        })
        .attr("y", function (d) {
          return y(0);
        })
        .attr("height", function (d) {
          return height - y(0);
        })
        .on("mouseover", function (d) {
          var color = self._.result(
            self._.find(teamslist, function (obj) {
              return obj.TEAM_NAME === d.name;
            }),
            "color"
          );

          // d3.select(this).style("fill", d3.rgb(color).brighter(2));
          d3.select("#teamfittooltip")
            .style("display", "block")
            .style("opacity", 0);
          self.selectedpop.name = d.name;
          self.selectedpop.value = d.value;
          var currentbar = this;
          setTimeout(function () {
            let pos = d3.select(currentbar).node().getBoundingClientRect();
            var leftspace = d3
              .select(".content-wrapper")
              .node()
              .getBoundingClientRect();
            var dwidth = Math.round(
              Number(d3.select("#teamfittooltip").style("width").slice(0, -2))
            );
            var pxy = pos["x"] - leftspace["x"] - dwidth / 2 - 20;

            d3.select("#teamfittooltip")
              .style("opacity", 1)
              .style("left", pxy + "px")
              .style("top", y(d.value) + 140 + "px");
          }, 100);
        })
        .on("mouseout", function (d) {
          var color = self._.result(
            self._.find(teamslist, function (obj) {
              return obj.TEAM_NAME === d.name;
            }),
            "color"
          );

          d3.select("#teamfittooltip")
            .style("display", "none")
            .style("opacity", 0);
          // d3.select(this).style("fill", d3.rgb(color).brighter(0));
        });

      slice
        .selectAll("rect")
        .transition()
        .delay(function (d) {
          return Math.random() * 1000;
        })
        .duration(1000)
        .attr("y", function (d) {
          return y(d.value);
        })
        .attr("height", function (d) {
          return height - y(d.value);
        });
    },
    _redraw(data) {
      var self = this;

      var offensivedata = [
        "Offensive Impact",
        "Interior Scoring",
        "Attacking the Basket",
        "Perimeter Scoring",
      ];
      this.odata = [];
      var slodash = this.lodash;
      offensivedata.forEach(function (oitem) {
        var currentitem = {};
        currentitem.key = oitem;
        var values = [];

        values.push({
          name: self.teamfitdata.currentteam[0].TEAM,
          value: (self.teamfitdata.currentteam[0][oitem] * 100).toFixed(2),
        });

        self.selectedTeams.forEach(function (item) {
          var ci = slodash.find(data, function (o) {
            return o.TEAM == item && o.TEAM!=self.teamfitdata.currentteam[0].TEAM;
          });
          if(ci){
            
          values.push({
            name: item,
            value: (ci[oitem] * 100).toFixed(2),
          });
          }
        });
        currentitem.values = values;

        self.odata.push(currentitem);
      });

      var playmakingdata = [
        "Ball Handing",
        "Perimeter Assists",
        "Interior Assists",
        "Free Throws",
      ];
      this.pdata = [];
      playmakingdata.forEach(function (oitem) {
        var currentitem = {};
        currentitem.key = oitem;
        var values = [];

        values.push({
          name: self.teamfitdata.currentteam[0].TEAM,
          value: (self.teamfitdata.currentteam[0][oitem] * 100).toFixed(2),
        });

        self.selectedTeams.forEach(function (item) {
          var ci = slodash.find(data, function (o) {
            return o.TEAM == item && o.TEAM!=self.teamfitdata.currentteam[0].TEAM;
          });
         if(ci){
            
          values.push({
            name: item,
            value: (ci[oitem] * 100).toFixed(2),
          });
          }
        });
        currentitem.values = values;

        self.pdata.push(currentitem);
      });

      var deffensivedata = [
        "Defensive IQ",
        "Interior Defense",
        "Perimeter Defense",
        "Defensive Impact",
      ];

      this.ddata = [];
      deffensivedata.forEach(function (oitem) {
        var currentitem = {};
        currentitem.key = oitem;
        var values = [];

        values.push({
          name: self.teamfitdata.currentteam[0].TEAM,
          value: (self.teamfitdata.currentteam[0][oitem] * 100).toFixed(2),
        });

        self.selectedTeams.forEach(function (item) {
          var ci = slodash.find(data, function (o) {
            return o.TEAM == item && o.TEAM!=self.teamfitdata.currentteam[0].TEAM;
          });
         if(ci){
            
          values.push({
            name: item,
            value: (ci[oitem] * 100).toFixed(2),
          });
          }
        });
        currentitem.values = values;

        self.ddata.push(currentitem);
      });

      setTimeout(function () {
        self.setChart(self.odata, "teamFit", "Offensive");
      }, 100);
    },
    _getAttributes(startdate, enddate) {
      this.noshots = false;
      this.shotsloading = true;
      var self = this;
      var postdata = {
        player: this.player.PLAYER_NAME,
      };
      this.$store.dispatch("getTeamfit", postdata).then((response) => {
        var results = response.data;
        this.teamfitdata = response.data;
        this.selectedTeams = response.data.teams;
      });
    },
  },
  watch: {
    selectedTeams() {
      this._redraw(this.teamfitdata.data);
    },
  },
  mounted() {
    // this.setChart();
     this.colors = this.chartcolors;
    this._getAttributes();

    this.teams = teamslist;
  },
};
</script>
