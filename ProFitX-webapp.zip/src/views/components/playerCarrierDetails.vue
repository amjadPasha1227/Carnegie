<template>
<div>
    <div class="widget_block career_widget">
        <div class="widget_title">
            <h3>Career Data</h3>
            <div>
                <div class="toggle_switch pr-8">
                </div>
            </div>
        </div>
        <div class="widget_body table_tabs">
            <div class="v-data-table elevation-1 theme--light">
                <div class="v-data-table__wrapper">
                    <table style="width:100%">
                        <thead class="v-data-table-header">
                            <tr>
                                <td> SEASON </td>
                                <td> GP </td>
                                <td> MINUTES </td>
                                <td> POINTS </td>
                                <td> FGM </td>
                                <td> FGA </td>
                                <td> FG% </td>
                                <td> FTM </td>
                                <td> FTA </td>
                                <td> FT% </td>
                                <td> 3PTM </td>
                                <td> 3PTA </td>
                                <td> 3PT% </td>
                                <td> OREB </td>
                                <td> DREB </td>
                                <td> AST </td>
                                <td> BLK </td>
                                <td> STL </td>

                            </tr>
                        </thead>
                        <tbody>
                            <tr :key="index" v-for="(season,index) in seasonsdata">
                                <td> {{season.SEASON}} </td>
                                <td> {{season.GP}} </td>
                                <td> {{roundvali(roundvali(season.PLAYSECS/60)/season.GP)}} </td>
                                <td> {{roundvali(season.POINTS/season.GP)}} </td>
                                <td> {{roundvali(season.FGM/season.GP)}} </td>
                                <td> {{roundvali(season.FGA/season.GP)}} </td>
                                <td> {{calper(season.FGM,season.FGA,season.GP)}} </td>
                                <td> {{roundvali(season.FTM/season.GP)}} </td>
                                <td> {{roundvali(season.FTA/season.GP)}} </td>
                                 <td> {{calper(season.FTM,season.FTA,season.GP)}} </td>

                                <td> {{roundvali(season["3PTM"]/season.GP)}} </td>
                                <td> {{roundvali(season["3PTA"]/season.GP) }}</td>
                                 <td> {{calper(season["3PTM"],season["3PTA"],season.GP)}} </td>
               
                                <td> {{roundvali(season.OREB/season.GP)}} </td>
                                <td> {{roundvali(season.DREB/season.GP)}} </td>
                                <td> {{roundvali(season.AST/season.GP) }}</td>
                                <td> {{roundvali(season.BLK/season.GP)}} </td>
                                <td> {{roundvali(season.STL/season.GP)}} </td>

                            </tr>
                        </tbody>

                    </table>
                </div>

            </div>
        </div>
    </div>

</div>
</template>

<script>
export default {
    name: "player-carrier-details",
    props: {
        player: {},
    },
    data() {
        return {
            switch1: true,
            expanded: [],
            singleExpand: true,
            headers: [{
                    text: 'Season',
                    value: 'name',
                    align: 'left',
                    sortable: false,
                },
                {
                    text: 'Age',
                    value: 'Age'
                },
                {
                    text: 'GP',
                    value: 'GP'
                },
                {
                    text: 'MIN',
                    value: 'MIN'
                },
                {
                    text: 'PTS',
                    value: 'PTS'
                },
                {
                    text: 'FGM',
                    value: 'FGM'
                },
                {
                    text: 'FG%',
                    value: 'FG'
                },
                {
                    text: '3PM',
                    value: 'PM'
                },
                {
                    text: '3PA',
                    value: 'PA'
                },
                {
                    text: '3P%',
                    value: 'P'
                },
                {
                    text: 'FTM',
                    value: 'FTM'
                },
                {
                    text: 'FTA',
                    value: 'FTA'
                },
                {
                    text: 'FT%',
                    value: 'FT'
                },
                {
                    text: 'REB',
                    value: 'REB'
                },
                {
                    text: 'AST',
                    value: 'AST'
                },
                {
                    text: 'STL',
                    value: 'STL'
                },
                {
                    text: 'BLK',
                    value: 'BLK'
                },
                //{ text: '', value: 'data-table-expand' },
            ],
            desserts: [],

            subheaders: [{
                    text: 'Game',
                    value: 'sub1',
                    sortable: false,
                    align: 'left'
                },
                {
                    text: 'Team',
                    value: 'sub2'
                },
                {
                    text: 'GP',
                    value: 'sub3'
                },
                {
                    text: 'MIN',
                    value: 'sub4'
                },
                {
                    text: 'PTS',
                    value: 'sub5'
                },
                {
                    text: 'FGM',
                    value: 'sub6'
                },
                {
                    text: 'FGA',
                    value: 'sub7'
                },
                {
                    text: 'FG%',
                    value: 'sub8'
                },
                {
                    text: '3PM',
                    value: 'sub9'
                },
                {
                    text: '3PA',
                    value: 'sub10'
                },
                {
                    text: '3P%',
                    value: 'sub11'
                },
                {
                    text: 'FTM',
                    value: 'sub12'
                },
                {
                    text: 'FTA',
                    value: 'sub13'
                },
                {
                    text: 'FT%',
                    value: 'sub14'
                },
                {
                    text: 'REB',
                    value: 'sub15'
                },
                {
                    text: 'AST',
                    value: 'sub16'
                },
                {
                    text: 'STL',
                    value: 'sub17'
                },
                {
                    text: 'BLK',
                    value: 'sub18'
                },
                {
                    text: 'DD2',
                    value: 'sub19'
                },
                {
                    text: 'PER',
                    value: 'sub20'
                },
            ],
            subdesserts: [{
                    sub1: 'Oct 18th',
                    sub2: 159,
                    sub3: 6.0,
                    sub4: 24,
                    sub5: 4.0,
                    sub6: 4.0,
                    sub7: 159,
                    sub8: 6.0,
                    sub9: 24,
                    sub10: 4.0,
                    sub11: 4.0,
                    sub12: 159,
                    sub13: 6.0,
                    sub14: 24,
                    sub15: 4.0,
                    sub16: 4.0,
                    sub17: 6.0,
                    sub18: 24,
                    sub19: 4.0,
                    sub20: 4.0,
                },

            ],
            options: {
                height: '100%',
                width: '100%',
                size: 0,
                axis: "yx"
            },
            seasonsdata: []
        }
    },
    methods: {
        calper(m, a, total) {
            return ((  (m / total))/((a / total) ) * 100).toFixed(2)
        },
        roundvali(val) {

            if (val) return val.toFixed(2)

            return 0
        },

        getseasonsdata() {
            this.$store
                .dispatch("getseasonsdata", {
                    player: this.player.PLAYER_NAME
                })
                .then(response => {
                    this.seasonsdata = JSON.parse(response.data.data)
                });
        }

    },
    mounted() {
        this.getseasonsdata()
    }
}
</script>
