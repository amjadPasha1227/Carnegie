<template>
    <ul>
        <li :class="{'active':currentRouteName=='profile'}"><router-link to="/profile">Profile</router-link></li>
        
        <li v-if="[1,2].indexOf(getRole) >-1" :class="{'active':currentRouteName=='users-list'}"><router-link to="/users-list">Users</router-link></li>
        <li v-if="[4].indexOf(getRole) >-1" :class="{'active':currentRouteName=='plan'}"><router-link to="/plan">Plan</router-link></li>
        <li v-if="[1,2,4].indexOf(getRole) >-1" :class="{'active':currentRouteName=='payments'}"><router-link to="/payments">Payments</router-link></li>
        <li v-if="[1,2,4 ,3].indexOf(getRole) >-1"  :class="{'active':currentRouteName=='support'}"><router-link to="/support">Support</router-link></li>
        <li v-if="[1,2].indexOf(getRole) >-1"  :class="{'active':currentRouteName=='enquiries'}"><router-link to="/enquiries">Enquiries</router-link></li>
      
    </ul>
</template>
<script>
export default {
    
computed: {
    getRole(){
           return this.$store.state.userRole;
        },
    currentRouteName(){
        return this.$route.name;
    }
}
}
</script>