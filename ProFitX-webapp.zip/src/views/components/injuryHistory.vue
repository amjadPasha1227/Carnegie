<template>
<div>
    <v-row justify="center">
        <v-btn style="margin-top:12px;margin-right:20px;" color="primary" dark @click.stop="dialog = true">
            Injury History
        </v-btn>

        <v-dialog v-model="dialog" max-width="1000" class="injury-dialog-block">
            <v-card class="injury-content-block">
                <v-row>
                    <v-col cols="12" sm="12" md="9" class="injury-left-block">
                        <div class="widget_block radius_0">
                            <div class="widget_title">
                                <h3>INJURY HISTORY</h3>
                             
                            </div>
                            <div class="widget_body">

                                <div class="loading-page" v-if="isloading">
                                    <figure>
                                        <img src="@/assets/images/loader.gif">
                                    </figure>Loading
                                </div>

                                <v-simple-table v-if="!isloading">
                                    <template v-slot:default>
                                        <thead>
                                            <tr>
                                                <th class="text-left">Season</th>
                                                <th class="text-left" >Injury</th>
                                                <th class="text-left">From-Until </th>
                                                <th class="text-left">Financial Loss</th>
                                                <th class="text-left">Games Missed </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr v-for="(injury, index) in history" v-bind:key='index'>
                                                <td>{{sseason}}</td>
                                                <td >{{ injury.injury}}</td>
                                                <td>{{ injury['From-Until']}}</td>
                                                <td>

                                                    <span v-if="injury['GamesMissed'] > 0">
                                                        {{ (player.TC/82)*injury['GamesMissed'] | currency}}
                                                    </span>

                                                </td>

                                                <td>{{ injury['GamesMissed']}}</td>
                                            </tr>
                                        </tbody>
                                    </template>
                                </v-simple-table>
                            </div>
                        </div>
                    </v-col>
                    <v-col cols="12" v-if="!isloading" sm="12" md="3" class="injury-right-block">
                        <div class="injury-contact-block">
                            <ul>
                                <li>
                                    <label>Real-Time Contract </label>
                                    <span> {{player.RTC | currency}}</span>
                                </li>
                                <li>
                                    <label>Team Contract </label>
                                    <span> {{player.TC | currency}}</span>
                                </li>
                                <li>
                                    <label>Financial Injury Loss</label>
                                    <span>{{tlosss | currency}}</span>
                                </li>
                                <li>
                                    <label>Adjusted Real-Time Contract </label>
                                    <span>{{(player.RTC-tlosss) | currency}}</span>
                                </li>
                            </ul>
                        </div>
                    </v-col>
                </v-row>
                <v-btn color="primary" text @click="dialog = false" class="close-btn">
                    <v-icon>mdi-close</v-icon>
                </v-btn>
            </v-card>
        </v-dialog>
    </v-row>
</div>
</template>

<script>
import moment from 'moment'

export default {
    name: "injury-History",
    props: {
        player: null,
        history: null,
        season: null,
    },
    watch: {
        sseason: function (value) {
            this.isloading = true;
            this.season = this.sseason;
            this.getInjuryhistory();
        },
        player: function (value) {

        }
    },
    methods: {
        getInjuryhistory() {
                 var self = this;
            if(this.sseason   ==  "2021-2022"){


        var _currentinjuries = [];

      

        setTimeout(function () {


              self.player.injuries.forEach(function (item) {
            var todates = moment(item.startDate, 'DD-MM-YYYY').format("MMMM Do YYYY");
            if (item.endDate != null) todates = todates + " - " + moment(item.endDate, 'DD-MM-YYYY').format("MMMM Do YYYY")

            _currentinjuries.push({
                "SEASON": "2021-2022",
                "injury": item.details,
                "GamesMissed": item.missed,
                Treatment: item.TREATMENT,
                "From-Until": todates

            })

        })
        self.history = _currentinjuries;

        var thistory = self.history;
        var tlosss = 0;

        thistory.forEach(element => {

            if (element.GamesMissed > 0) {
                tlosss = tlosss + ((self.player.TC / 82) * element.GamesMissed)
            }

        });
        self.tlosss = tlosss;

                self.isloading = false;


        }, 1000)


            }else{


                 let params = {
                playerid: this.player.PLAYER_ID,
                season: this.sseason
            }
            this.$store.dispatch("getInjury", params).then(response => {

                if (response.data && response.data.result) {
                    self.history = JSON.parse(response.data.result.list.injuryHistory);

                    var thistory = self.history;
                    var tlosss = 0;
                    thistory.forEach(element => {

                        if (element.GamesMissed > 0) {
                            tlosss = tlosss + ((self.player.TC / 82) * element.GamesMissed)
                        }

                    });
                    self.tlosss = tlosss;

                }

                self.isloading = false;
            });



            }

           

        },

    },
    data: () => ({
        sseason: "2021-2022",
        itemsC: ["2020-2021", '2019-2020', '2018-2019', '2017-2018', '2016-2017', '2015-2016'],
        tlosss: 0,
        dialog: false,
        isloading:false,
        injuries: [],
    }),
    mounted() {
        var self = this;

        var _currentinjuries = [];

      

        setTimeout(function () {


              self.player.injuries.forEach(function (item) {
            var todates = moment(item.startDate).format("MMMM Do YYYY");
            if (item.endDate != null) todates = todates + " - " + moment(item.endDate).format("MMMM Do YYYY")

            _currentinjuries.push({
                "SEASON": "2021-2022",
                "injury": item.details,
                "GamesMissed": item.missed,
                "From-Until": todates

            })

        })
        self.history = _currentinjuries;

        var thistory = self.history;
        var tlosss = 0;

        thistory.forEach(element => {

            if (element.GamesMissed > 0) {
                tlosss = tlosss + ((self.player.TC / 82) * element.GamesMissed)
            }

        });
        self.tlosss = tlosss;

                self.isloading = false;


      



        }, 1000)

    }
}
</script>
