

<template>  
    <div>
        <div class="widget_block">            
            <div class="widget_body">
                <h2 class="small-heading">PLAYER PRODUCTIVITY</h2>
                <div class="productivity_year">
                    <v-select
                            :items="years"
                            label="2019"
                            solo
                            ></v-select>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "player-productivity",
    data: () => ({
      years:['2018', '2017', '2016', '2015'],
      picker: new Date().toISOString().substr(0, 10),
    }),
}
</script>
