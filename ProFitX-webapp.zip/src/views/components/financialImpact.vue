<template>
<div>
    <div class="widget_block contract_widget">
        <div class="widget_title">
            <h3>Financial Impact




         <v-tooltip bottom>
                <template v-slot:activator="{ on, attrs }">
                    <v-btn class="info_btn"
                    v-bind="attrs"
                    v-on="on"
                    >
                    <v-icon>mdi-information-outline</v-icon>
                    </v-btn>
                </template>
                <span>Time-Series model that displays weekly, monthly, and yearly real-time contract value financial value broken down into performance skillsets throughout athlete's career.  </span>
                </v-tooltip>


            </h3>

         <ul class="tab_buttons" >
                    <li v-bind:class="{ active: selectedtab=='Monthly'  }"  @click="selectedtab='Monthly';_getAttributes(); " >
                        <a>Monthly</a>
                    </li>
                    <li v-bind:class="{ active: selectedtab=='Yearly'  }" @click="selectedtab='Yearly';_getAttributes(); " >
                        <a>Yearly</a>
                    </li>
                </ul>

        </div>
        <div class="widget_body">
            <div class="shotsloading" v-if="shotsloading">
                <img src="../../assets/images/shotsloading.svg" />
            </div>
            <div class="contract_graph" style="height:auto; padding-left:0px;padding-right:0px;">
                <div id="financialimpactchartdiv" style="height:400px" class="timeserieschart"></div>

                <div class="financial_tooltip" id="impact_tooltip" style="display:none">
                    <h5>
                        Real Time Contract Value
                        <span>{{selectedbar.RTM | currency}}</span>
                    </h5>
                    <ul>
                        <li v-for="(column,index) in columns" v-bind:key='index'>
                            {{column}} <span v-bind:style="{ color: colors[index]}">{{selectedbar[column] | percentazec}} %</span>
                        </li>

                    </ul>
                </div>
            </div>

        </div>
    </div>
</div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
am4core.useTheme(am4themes_dark);
var _financialchart;

import moment from "moment";

export default {
    name: "financial-impact",
    props: {
        player: null,
        playerid: null
    },
    data: function () {
        return {
            selectedtab:"Monthly", 
            ptypes: ['Defense','Rebounding','Scoring','Shooting','Passing'],
            itypes: ['Defense','Rebounding','Scoring','Shooting','Passing'],
            selectedbar: {},
            columns: [],
            colors: [],
            shotsloading: false,
        };
    },
    methods: {
        _getAttributes() {
            this.noshots = false;
            this.shotsloading = true;
            var _self = this;
            var postdata = {
                fr: this.fr,
                mt: this.mt,
                freq:this.selectedtab,
                selectedones: this.selectedones,
                player: this.player.PLAYER_NAME
            };
            this.$store.dispatch("getFinacialimpact", postdata).then(response => {
                var results = response.data;

                //console.log(results)
                if (results.length > 0) {
                    this.shotsloading = false;
                    _financialchart = am4core.create("financialimpactchartdiv", am4charts.XYChart);
                    var _nresults=[]
                    results.forEach(function (item,index) {
                            var _sitem={};
                            _sitem['group']=item['group']
                          _sitem['rtm']=item['RTM']

                    _self.itypes.forEach(function (sitem,sindex) {
                        _sitem[sitem]=(item[sitem]/item['RTM'])*100
                        _sitem[sitem+"VALUE"]=item[sitem]

                        })
                        _nresults.push(_sitem)
                    })
                    
                    _financialchart.data = _nresults;
                  
                    var categoryAxis = _financialchart.xAxes.push(new am4charts.CategoryAxis());
                    categoryAxis.dataFields.category = "group";
                    categoryAxis.renderer.grid.template.location = 0;
                    var valueAxis = _financialchart.yAxes.push(new am4charts.ValueAxis());
                    //valueAxis.renderer.inside = true;
                                       

                                           categoryAxis.start = 0.8;
                    categoryAxis.end = 1;
                    categoryAxis.keepSelection = true;
                    valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
                    //valueAxis.renderer.labels.template.disabled = true;
                      valueAxis.max =100;
                    var self = this;
                    var selfs  = 1;
                    var i = 0;
                    var _colors = [
                       
                        am4core.color("#2D70CE"),
                        am4core.color("#739025"),
                        am4core.color("#2FA7A7"),
                        am4core.color("#C73434"),
                        am4core.color("#ff8f00"),
                        am4core.color("#27B2DB"),
                        am4core.color("#B51F9E"),

                         am4core.color("#e0916c"),
                        am4core.color("#954b6d"),
                        am4core.color("#c3ae70"),
                        am4core.color("#77c28b"),
                        am4core.color("#70692c"),
                        am4core.color("#e3808f"),

                    ];

                    var ttip = `<ul>`;
                    var series;
                    var colorSet = new am4core.ColorSet();
                    var _tipseries;
                    _self.itypes.forEach(function (item,index) {
                       
                        series = _financialchart.series.push(new am4charts.ColumnSeries());
                        if(index == 0)  _tipseries =series;
                        series.name = _self.ptypes[index];
                        series.dataFields.valueY = item;
                        series.dataFields.rtm = 'RTM';
                        series.dataFields.categoryX = "group";
                        series.sequencedInterpolation = true;
                        series.fillOpacity = 0.8;
                        series.stacked = true;
                        series.columns.template.width = am4core.percent(65);
                        series.columns.template.maxWidth = 100;
                        var _color = _colors[index];
                        series.columns.template.fill  = _color;

                        ttip = ttip + `<li> <em style='background:` + _color + `'></em> <span>` + _self.ptypes[index] + `:&nbsp;&nbsp;&nbsp;$ {` + item + `VALUE}</span></li>`;
                        i++;
                    })

                    ttip = ttip + `</ul>`;
                    _tipseries.tooltipHTML = `<div class="financial_tooltip" > <h5>
                        Real Time Contract Value
                        <span>$ {rtm}</span>
                    </h5>` + ttip + `</div>`;
                    _financialchart.numberFormatter.numberFormat = "#,###.";

                    _tipseries.tooltip.pointerOrientation = "horizontal";
                    _tipseries.tooltip.background.strokeWidth = 0;
                    _tipseries.tooltip.getFillFromObject = false;
                    _tipseries.tooltip.background.fill = am4core.color("#11172B");
                    _tipseries.tooltip.background.fillOpacity = 0;
                    let shadow = series.tooltip.background.filters.getIndex(0);
                    shadow.dx = 10;
                    shadow.dy = 10;
                    shadow.blur = 5;
                    series.tooltip.getFillFromObject = false;
                    series.tooltip.background.filters.clear();
                    valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
                    categoryAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
                    if(self.selectedtab == "Yearly"){
                    categoryAxis.renderer.minGridDistance = 20;

                    }

                    _financialchart.scrollbarX = new am4core.Scrollbar();
                    _financialchart.scrollbarX.parent = _financialchart.bottomAxesContainer;
                    _financialchart.zoomOutButton.disabled = true;

      

                          _financialchart.scrollbarX.stroke = am4core.color("#3F4C76");
                     _financialchart.scrollbarX.strokeOpacity = 0.6
                     _financialchart.scrollbarX.background.fill = am4core.color("#3F4C76");
                     _financialchart.scrollbarX.background.fillOpacity = 0.6
                    _financialchart.scrollbarX.startGrip.background.fill = am4core.color("#3F4C76");
                    _financialchart.scrollbarX.endGrip.background.fill = am4core.color("#3F4C76");



                    _financialchart.cursor = new am4charts.XYCursor();
                } else {
                    this.shotsloading = false;
                    this.noshots = true;
                }

            });
        }
    },
    mounted() {
        this.colors = this.chartcolors;
        this._getAttributes();
    }
};
</script>
