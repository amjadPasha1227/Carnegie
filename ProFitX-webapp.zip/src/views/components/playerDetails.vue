<template>
<div class="player_details_wrap">
    <div class="player_details_header">
        <div class="details_left">
            
            <template v-if="player.PLAYER_IMAGE">

                     <div class="player_dp" v-if="player.PLAYER_IMAGE">
                <div class="badge-logo"><img :src='"https://profitx.ai/api/viewfile?path=teams/"+player.TEAM_ID+".png"'></div>
                <figure>
                    <img :src='player.PLAYER_IMAGE' class="align-self-center" :alt="player.PLAYER_NAME">
                </figure>
            </div>

            </template>
             <template v-else>

                      <div class="player_dp" v-if="player.goalserveDetails">
                <div class="badge-logo"><img :src='"https://profitx.ai/api/viewfile?path=teams/"+player.goalserveDetails.TeamID+".png"'></div>
                <figure>
                    <img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+player.goalserveDetails.PlayerID+".png"' class="align-self-center" :alt="player.PLAYER_NAME">
                </figure>
            </div>

            </template>
       


            <div class="player_profile_details">
                <div class="details_top">
                    <div class="player_title">
                        <h4> {{player.PLAYER_NAME}}
                         
                            <AddToFav v-if="loaded" :favslist="favslist" :player="player" />
              
                            <span class="outofseason" v-if="player.injuries && player.injuries.length > 0 && player.injuries[player.injuries.length-1].Status == 'Out for Season'">Out for Season</span>
                            <span class="outofseason" v-else-if="player.injuries && player.injuries.length > 0 && player.injuries[player.injuries.length-1].endDate == null">Active Injury</span>
                        </h4>
                        <h6>{{player.TEAM_ABBREVIATION}} - <span v-if="player.POSITION">{{getposition(player.POSITION)}} </span> </h6>
                    </div>
                    <!-- <div class="player-solcial_media d-none d-sm-flex">
                    <ul>                        
                        <li>
                            <span><v-icon>mdi-twitter</v-icon></span>
                            <article>101.2K</article>
                        </li>
                        <li>                            
                            <span><v-icon>mdi-instagram</v-icon></span>
                            <article>4.3M</article>
                        </li>
                        <li>
                            <span><v-icon>mdi-facebook</v-icon></span>
                            <article>65.9K</article>
                        </li>
                    </ul>

                </div> -->
                </div>
                <div class="details-middle" v-if="player">
                    <ul>
                        <li>
                            <label>AGE<span>{{player.AGE | number}} yrs</span></label>
                        </li>
                        <li>
                            <label>HEIGHT<span>{{player.FHEIGHT}}</span></label>
                        </li><!--  -->
                        <li>
                            <label>WEIGHT<span>{{player.WEIGHT}}</span></label>
                        </li>
                        <li v-if="player.FA!=null">
                            <label>Free Agency Year<span>{{player.FA}}</span></label>
                        </li>
                        <li v-if="player.PRO">
                            <label>Years Pro<span>{{player.PRO}}</span></label>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
        <div class="details_right" v-if="player.RTP">
            <div class="profile_rating_wrap">
                <h3>ProFitX Rating </h3>
                <div class="profile_rating">
                    {{player.RTP | roundme}}/<span style="font-size:30px; line-height:30px">100</span>
                </div>
            </div>
            <div class="profile_status">

            </div>
        </div>

    </div>
    <v-row class="d-sm-none">
        <v-col class="padt0">
            <div class="player-solcial_media">
                <!-- <div class="grade">
                        <label>GRADE B</label>
                        <p><a href="#"><img src="../../assets/images/like-icon.svg"></a>
                        <a href="#"><img src="../../assets/images/dislike-icon.svg"></a></p>
                    </div> -->
                <ul>
                    <li>
                        <span>
                            <v-icon>mdi-twitter</v-icon>
                        </span>
                        <article>101.2K</article>
                    </li>
                    <li>
                        <span>
                            <v-icon>mdi-instagram</v-icon>
                        </span>
                        <article>4.3M</article>
                    </li>
                    <li>
                        <span>
                            <v-icon>mdi-facebook</v-icon>
                        </span>
                        <article>65.9K</article>
                    </li>
                </ul>
            </div>
            <div class="details-bottom">
                <h3>CAREER AWARDS</h3>
                <swiper ref="awesomeSwiperA" :options="swiperOption" @set-translate="onSetTranslate">
                    <!-- @someSwiperEvent="callback" -->
                    <!-- slides -->
                    <swiper-slide :key="awardd" v-for="awardd in awards">
                        <div class="awards_list">
                            <p>{{awardd.award}}</p>
                            <label>{{awardd.date}}</label>
                        </div>
                    </swiper-slide>

                    <!-- Optional controls -->
                </swiper>
                <!-- <swiper
                    ref:swiper
                    direction="horizontal"
                    :mousewheel-control="true"
                    :performance-mode="false"
                    :pagination-visible="true"
                    :pagination-clickable="true"
                    :loop="true"
                    @slide-change-start="onSlideChangeStart"
                    @slide-change-end="onSlideChangeEnd">
                <div>Page 1</div>
                <div>Page 2</div>
                <div>Page 3</div>
            </swiper> -->
            </div>
        </v-col>
    </v-row>
    <div>
      
    </div>
</div>
</template>

<script>
import AddToFav from "./addtofav";

import 'swiper/dist/css/swiper.css';
import {
    swiper,
    swiperSlide
} from 'vue-awesome-swiper';
import moment from "moment";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);

export default {
    components: {
        swiper,
        swiperSlide,
        AddToFav
    },
    filters: {
        roundme: function (value) {
            if (!value) return ''
            value = Math.round(value).toFixed(0)
            return value
        }
    },
    props: {
        player: null,
    },
    computed: {
        swiper() {
            return this.$refs.mySwiper.swiper
        }
    },
    methods: {

        getposition(type) {
            var _p = this.lodash.find(this.positions, function (my) {

                return my.value == type
            })
            return _p.name;

        },
        getawards() {
            var playerID = this.player.PLAYER_ID;
            if (this.player && this.player.seasons && this.player.seasons.length > 1) {

                playerID = this.player.seasons[this.player.seasons.length - 2].PLAYER_ID
            }
            this.$store.dispatch("getawards", playerID).then(response => {

                if (response.data && response.data.result && response.data.result.list.resultSets[0].rowSet) {

                    var sdata = response.data.result.list.resultSets[0].rowSet;
                    var data = [];
                    sdata.forEach(function (a) {

                        var xd = a[a.length - 7];
                        var yd = a[a.length - 6];
                        data.push({
                            "award": a[4],
                            "date": a[6],
                            "SUBTYPE1": a[11]
                        })

                    })

                    this.awards = data.slice().reverse();

                }

            })
        }

    },
    watch: {
        player: function (value) {

        }
    },
    mounted() {

        var userid = this.$store.state.user._id;


        // console.log(this.$options.name+' component successfully mounted');
        var self = this;
        var sticky = document.getElementById("sticky");
        //sticky.style.border = '10px solid red';
        //let stickyTop = sticky.getBoundingClientRect().top;
        if (sticky) {

            let stickyTop = sticky.offsetTop;
            let scrolled = false;
            let $window = window;

            window.addEventListener('scroll', function (e) {
                scrolled = true;
            });

            let timeout = setInterval(function () {
                /* If the page was scrolled, handle the scroll */
                if (scrolled) {
                    scrolled = false;
                    if (window.pageYOffset > stickyTop) {
                        self.isScrolled = true;
                    } else {
                        self.isScrolled = false;
                    }
                }
            });
        }

        // current swiper instance

        this.getawards();

    },

    data() {
        return {
            loaded: false,
            favslist: null,
            isScrolled: false,
            positions: [{
                name: "Power Forward",
                value: "F-C"

            }, {
                name: "Forward",
                value: "F"
            }, {
                name: "Versatile Center",
                value: "C-F"
            }, {
                name: "Center",
                value: "C"
            }, {
                name: "Combo Guard",
                value: "G-F"
            }, {
                name: "Guard",
                value: "G"
            }, {
                name: "Wing",
                value: "F-G"
            }],
            valueDeterminate: 50,
            awards: [],
            swiperOption: {
                slidesPerView: 'auto',
                spaceBetween: 10,
                pagination: {
                    el: '.swiper-pagination'
                },
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev'
                    // nextEl: this.$el.querySelector('.swiper-button-next'),
                    // prevEl: this.$el.querySelector('.swiper-button-prev')
                },
            }
        }
    }
}
</script>
