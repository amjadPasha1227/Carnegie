<template>
<div>
    <div class="newsletter_widget">
        <div class="block_title">
            <h2>DEVELOPMENT</h2>             
        </div>
        <div class="development_cnt">
             
        </div>
    </div>
</div>
</template> 

<script> 
 
export default {
    name: "synergy-seacrh",
    components: { 
        
    }, 
     
    data() {
        return {
             
             
        };
    }
};
</script>
