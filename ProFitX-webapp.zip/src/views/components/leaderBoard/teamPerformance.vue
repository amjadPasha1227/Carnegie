<template>
<div>
    <div class="teamperformance_widget" > 
        
        <div class="block_title">
            <h2>TEAM PERFORMANCE</h2>
            <div class="slider_navigation">
                <div class="swiper-button-prev"><span class="icon-play-flip"></span></div>
                <div class="swiper-button-next"><span class="icon-play"></span></div>
            </div>
        </div>
        <swiper  :options="swiperOption">
            <swiper-slide  v-for="i in 10" :key="i">
                <div class="performance_block">
                     
                </div>
            </swiper-slide>  
        </swiper>
    </div>
</div>
</template> 

<script> 

import "swiper/dist/css/swiper.css"; 

import {
    swiper,
    swiperSlide
} from "vue-awesome-swiper";

export default {
    name: "synergy-seacrh",
    components: {
        swiper,
        swiperSlide, 
    }, 
    computed: {
      
       
    },
    
    watch: {
      
    },
    mounted() {
         

    },
    data() {
        return {
             
            swiperOption: {
                slidesPerView:2,
                spaceBetween: 15,
                pagination: {
                    el: '.swiper-pagination'
                },
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev'
                },
            }
        };
    }
};
</script>
