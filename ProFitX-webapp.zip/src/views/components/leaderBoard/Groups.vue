<template>
<div>
    <div class="playerslist_widget teamgroups_widget" > 
        
        <v-tabs class="pro_tabs" dark
            v-model="tabs"
            right
            >
            <v-tab><span class="tab1">MVP CANDIDATE</span></v-tab>
            <v-tab><span class="tab2">NBA</span></v-tab>
            <v-tab><span class="tab3">ALL STAR</span></v-tab>
            
            <v-tab-item>
                <div class="slider_navigation">
                    <div class="swiper-button-prev tab_prev"><span class="icon-play-flip"></span></div>
                    <div class="swiper-button-next tab_next"><span class="icon-play"></span></div>
                </div>
                <swiper  :options="swiperOption">
                    <swiper-slide v-for="i in 10" :key="i" >
                        <div class="playerslist">
                            <div class="player_info">
                                <figure>
                                    <img src="../../../assets/images/profile_dp-1.png">
                                    <span><img src="../../../assets/images/bull_img.png"></span>
                                </figure>
                                    <div class="player_into_rt">
                                        <p>BRADLEY BEAL</p>
                                        <small>Phoenix Suns - Guard</small>
                                        <strong><v-icon>mdi-menu-up</v-icon>8.1%</strong>
                                    </div> 
                            </div>
                            <div class="player_data">
                                <ul>
                                    <li>
                                        <p>
                                            <v-icon>mdi-thumb-up-outline</v-icon>
                                            <span>102.2K</span>
                                        </p>
                                        <p>
                                            <v-icon>mdi-thumb-down-outline</v-icon>
                                            <span>43M</span>
                                        </p>
                                    </li>
                                    <li>
                                        <v-rating
                                            v-model="rating"
                                            icon-label="custom icon label text {0} of {1}"
                                            ></v-rating>
                                    </li>
                                </ul>
                            </div> 
                        </div>
                    </swiper-slide>  
                </swiper>
            </v-tab-item>

            <v-tab-item>
                 <div class="slider_navigation">
                    <div class="swiper-button-prev tab_prev"><span class="icon-play-flip"></span></div>
                    <div class="swiper-button-next tab_next"><span class="icon-play"></span></div>
                </div>
                <swiper  :options="swiperOption">
                    <swiper-slide v-for="i in 10" :key="i" >
                        <div class="playerslist">
                            <div class="player_info">
                                <figure>
                                    <img src="../../../assets/images/profile_dp-1.png">
                                    <span><img src="../../../assets/images/bull_img.png"></span>
                                </figure>
                                    <div class="player_into_rt">
                                        <p>BRADLEY BEAL</p>
                                        <small>Phoenix Suns - Guard</small>
                                        <strong><v-icon>mdi-menu-up</v-icon>8.1%</strong>
                                    </div> 
                            </div>
                            <div class="player_data">
                                <ul>
                                    <li>
                                        <p>
                                            <v-icon>mdi-thumb-up-outline</v-icon>
                                            <span>102.2K</span>
                                        </p>
                                        <p>
                                            <v-icon>mdi-thumb-down-outline</v-icon>
                                            <span>43M</span>
                                        </p>
                                    </li>
                                    <li>
                                        <v-rating
                                            v-model="rating"
                                            icon-label="custom icon label text {0} of {1}"
                                            ></v-rating>
                                    </li>
                                </ul>
                            </div> 
                        </div>
                    </swiper-slide>  
                </swiper>
            </v-tab-item>

            <v-tab-item>
                 <div class="slider_navigation">
                    <div class="swiper-button-prev tab_prev"><span class="icon-play-flip"></span></div>
                    <div class="swiper-button-next tab_next"><span class="icon-play"></span></div>
                </div>
                <swiper  :options="swiperOption">
                    <swiper-slide v-for="i in 10" :key="i" >
                        <div class="playerslist">
                            <div class="player_info">
                                <figure>
                                    <img src="../../../assets/images/profile_dp-1.png">
                                    <span><img src="../../../assets/images/bull_img.png"></span>
                                </figure>
                                    <div class="player_into_rt">
                                        <p>BRADLEY BEAL</p>
                                        <small>Phoenix Suns - Guard</small>
                                        <strong><v-icon>mdi-menu-up</v-icon>8.1%</strong>
                                    </div> 
                            </div>
                            <div class="player_data">
                                <ul>
                                    <li>
                                        <p>
                                            <v-icon>mdi-thumb-up-outline</v-icon>
                                            <span>102.2K</span>
                                        </p>
                                        <p>
                                            <v-icon>mdi-thumb-down-outline</v-icon>
                                            <span>43M</span>
                                        </p>
                                    </li>
                                    <li>
                                        <v-rating
                                            v-model="rating"
                                            icon-label="custom icon label text {0} of {1}"
                                            ></v-rating>
                                    </li>
                                </ul>
                            </div> 
                        </div>
                    </swiper-slide>  
                </swiper>
            </v-tab-item>
            
        </v-tabs>
       
        
    </div>
</div>
</template> 

<script> 

import "swiper/dist/css/swiper.css"; 

import {
    swiper,
    swiperSlide
} from "vue-awesome-swiper";
export default {
    name: "synergy-seacrh",
    components: {
        swiper,
        swiperSlide, 
    }, 
    computed: {
      
       
    },
    
    watch: {
      
    },
    mounted() {
         

    },
    data() {
        return {
             
            swiperOption: {
                slidesPerView:"auto",
                spaceBetween: 15,
                pagination: {
                    el: '.swiper-pagination'
                },
                navigation: {
                    nextEl: '.tab_next',
                    prevEl: '.tab_prev'
                },
            }
        };
    }
};
</script>
