<template>
<div>
    <div class="aboutprofitX_widget" > 
        
        <div class="block_title">
            <h2>ABOUT PROFITX</h2>
            <div class="slider_navigation">
                <div class="swiper-button-prev about_prev"><span class="icon-play-flip"></span></div>
                <div class="swiper-button-next about_next"><span class="icon-play"></span></div>
            </div>
        </div>
        <swiper  :options="swiperOption">
            <swiper-slide  v-for="i in 10" :key="i">
                <div class="aboutprofitX_block">
                    <figure><img src="../../../assets/images/about_banner.png"></figure>
                    <div class="about_details">
                        <h3>MAXIMIZE<br/> CONTRACT VALUE</h3>
                        <p>ProFitX gauges real-time client value based on on-court production. Find the opportunity where your client will thrive the most using the Team Fit tool.</p>
                        <a class="more" href="#">READ MORE</a>
                    </div>
                </div>
            </swiper-slide>  
        </swiper>
    </div>
</div>
</template> 

<script> 

import "swiper/dist/css/swiper.css"; 

import {
    swiper,
    swiperSlide
} from "vue-awesome-swiper";
export default {
    name: "synergy-seacrh",
    components: {
        swiper,
        swiperSlide, 
    }, 
    computed: {
      
       
    },
    
    watch: {
      
    },
    mounted() {
         

    },
    data() {
        return {
             
            swiperOption: {
                slidesPerView:1,
                spaceBetween: 15,
                pagination: {
                    el: '.swiper-pagination'
                },
                navigation: {
                    nextEl: '.about_next',
                    prevEl: '.about_prev'
                },
            }
        };
    }
};
</script>
