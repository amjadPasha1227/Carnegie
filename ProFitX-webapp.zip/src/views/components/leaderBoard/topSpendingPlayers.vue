<template>
<div>
    <div class="topplayers_widget">
        <div class="block_title">
            <h2>TOP SPENDING PLAYERS</h2>             
        </div>
        <div class="topplayers_list">
            <ul>
                <li>
                    <figure>
                        <span> <img src="../../../assets/images/profile_dp-1.png"></span>
                        <figcaption>STEPHEN CURRY</figcaption>
                    </figure>
                    <label>$ 40, 231,758</label>
                </li>
                <li>
                    <figure>
                        <span> <img src="../../../assets/images/profile_dp-1.png"></span>
                        <figcaption>STEPHEN CURRY</figcaption>
                    </figure>
                    <label>$ 40, 231,758</label>
                </li>
                <li>
                    <figure>
                        <span> <img src="../../../assets/images/profile_dp-1.png"></span>
                        <figcaption>STEPHEN CURRY</figcaption>
                    </figure>
                    <label>$ 40, 231,758</label>
                </li>
                <li>
                    <figure>
                        <span> <img src="../../../assets/images/profile_dp-1.png"></span>
                        <figcaption>STEPHEN CURRY</figcaption>
                    </figure>
                    <label>$ 40, 231,758</label>
                </li>
                <li>
                    <figure>
                        <span> <img src="../../../assets/images/profile_dp-1.png"></span>
                        <figcaption>STEPHEN CURRY</figcaption>
                    </figure>
                    <label>$ 40, 231,758</label>
                </li>
            </ul>   
        </div>
    </div>
</div>
</template> 

<script> 
 
export default {
    name: "synergy-seacrh",
    components: { 
    }, 
    computed: {
      
       
    },
    
    watch: {
      
    },
    mounted() {
         

    },
    data() {
        return {
             
             
        };
    }
};
</script>
