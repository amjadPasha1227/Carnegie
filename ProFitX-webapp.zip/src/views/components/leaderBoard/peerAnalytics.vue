<template>
<div>
    <div class="teamperformance_widget" > 
        
        <div class="block_title">
            <h2>PEER ANALYSIS</h2> 
        </div>
        <div class="performance_block">
                     
        </div>
    </div>
</div>
</template> 

<script> 
 
export default {
    name: "synergy-seacrh",
    components: {
         
    }, 
    computed: {
      
       
    },
    
    watch: {
      
    },
    mounted() {
         

    },
    data() {
        return {
             
            
        };
    }
};
</script>
