<template>
<div>
    <div class="teamlist_widget" >

        <vue-marquee style="height:140px" :showProgress="false">
            <vue-marquee-slide v-for="i in 30" :key="i">
                <div class="teamlist">
                    <label class="live"><img src="../../../assets/images/live2.svg"></label>
                    <div class="teamlist_cnt ">
                        <div class="team_details">
                            <figure><img src="../../../assets/images/ATL_logo.svg"></figure>
                            <p>60<sub>%</sub></p>
                        </div>                                    
                        <span class="vs">VS</span>
                            <div class="team_details">
                            <figure><img src="../../../assets/images/DET_logo.svg"></figure>
                            <p>40<sub>%</sub></p>
                        </div>
                    </div>
                </div>
            </vue-marquee-slide>
            </vue-marquee>
    </div>
</div>
</template> 

<script> 
import Vue from 'vue'
import VueMarquee from 'vue-marquee-component'
 
Vue.use(VueMarquee)

 
export default {
    name: "synergy-seacrh",
    components: {
  
    }, 
    computed: {
      
       
    },
    
    watch: {
      
    },
    mounted() {
         

    },
    data() {
        return {
 
        };
    }
};
</script>
