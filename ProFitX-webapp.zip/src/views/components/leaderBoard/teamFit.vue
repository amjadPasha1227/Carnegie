<template>
<div>
    <div class="teamFit_sec_widget" >         
        <div class="block_title">
            <h2>TEAM FIT EVALUATION</h2>
            <v-select :items="items" label="Select Player" solo></v-select>
        </div>
        <div class="teamFit_cnt">

        </div>
    </div>
</div>
</template> 

<script> 

 
 
export default {
    name: "synergy-seacrh",
    components: { 
    }, 
    computed: {
      
       
    },
    
    watch: {
      
    },
    mounted() {
         

    },
    data() {
        return {
             items: ['Player 1', 'Player 2', 'Player 3', 'Player 4'],
            
        };
    }
};
</script>
