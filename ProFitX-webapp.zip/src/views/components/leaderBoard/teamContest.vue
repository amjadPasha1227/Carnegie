<template>
<div>
    <div class="teamcontest_widget">
        <div class="block_title">
            <h2>TEAMS POLLS/CONTEST</h2>             
        </div>
        <div class="teamcontest_cnt">
            <h6>Which team do you support?</h6>
            <div class="contest_teams">
                <div class="contest_team">
                    <figure class="team_logo"><img src="../../../assets/images/bull_img.png"></figure>
                    <div class="contest_teams_cnt">
                        <span><v-icon>mdi-thumb-up-outline</v-icon></span>
                        <p><small>Support</small>CHARLOTTE HORNETS</p>
                    </div>
                </div>
                <div class="contest_team">
                    <figure class="team_logo"><img src="../../../assets/images/bull_img.png"></figure>
                    <div class="contest_teams_cnt">
                        <span><v-icon>mdi-thumb-down-outline</v-icon></span>
                        <p><small>Support</small>CHARLOTTE HORNETS</p>
                    </div>
                </div>
            </div>
            <div class="teams_voting">
                <div class="team_voting">
                    <p>188 Votes <span>66%</span></p>
                    <div class="team_progress">
                        <div class="team_progress_bar" style="width:66%"></div>
                    </div>
                </div>
                <div class="team_voting">
                    <p><span>34%</span>188 Votes</p>
                    <div class="team_progress">
                        <div class="team_progress_bar" style="width:34%"></div>
                    </div>
                </div>
                <div class="tatal_count">288 <br/>VOTES</div>
            </div>
        </div>
    </div>
</div>
</template> 

<script> 
 
export default {
    name: "synergy-seacrh",
    components: { 
        
    }, 
     
    data() {
        return {
             
             
        };
    }
};
</script>
