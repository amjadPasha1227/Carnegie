<template>
<div>
    <div class="newsletter_widget">
        <div class="block_title">
            <h2>REGISTER FOR NEWSLETTER</h2>             
        </div>
        <div class="newsletter_cnt">
            <p>Receive e-mails from us featuring new content that matches your interests.</p>
            <div class="newsletter_form">
                <input type="text" placeholder="Enter your email">
                <button>SEND</button>
            </div>
        </div>
    </div>
</div>
</template> 

<script> 
 
export default {
    name: "synergy-seacrh",
    components: { 
    }, 
    computed: {
      
       
    },
    
    watch: {
      
    },
    mounted() {
         

    },
    data() {
        return {
             
             
        };
    }
};
</script>
