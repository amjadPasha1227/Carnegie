<template>
<div>
    <div class="playerslist_widget" >        
        <vue-marquee style="height:112px" direction="right" :showProgress="false">
            <vue-marquee-slide v-for="i in 30" :key="i">
                <div class="playerslist">
                    <div class="player_info">
                        <figure>
                            <img src="../../../assets/images/profile_dp-1.png">
                            <span><img src="../../../assets/images/bull_img.png"></span>
                        </figure>
                            <div class="player_into_rt">
                                <p>RUSSELL WESTBROOK<span class="color1">FG</span></p>
                                <div class="d-flex">
                                    <label class="rt"><em>RT</em>$ 30,235,572</label>
                                    <label class="tc"><em>TC</em>40,426,012</label>
                                </div>
                            </div> 
                    </div>
                    <div class="player_data">
                        <ul>
                            <li>
                                <p>
                                    <v-icon>mdi-thumb-up-outline</v-icon>
                                    <span>102.2K</span>
                                </p>
                                <p>
                                    <v-icon>mdi-thumb-down-outline</v-icon>
                                    <span>43M</span>
                                </p>
                            </li>
                            <li>
                                 <v-rating
                                    v-model="rating"
                                    icon-label="custom icon label text {0} of {1}"
                                    ></v-rating>
                            </li>
                        </ul>
                    </div> 
                </div>
            </vue-marquee-slide>
        </vue-marquee>


    </div>
</div>
</template> 

<script> 
import Vue from 'vue'
import VueMarquee from 'vue-marquee-component'
 
Vue.use(VueMarquee)
 
export default {
    name: "synergy-seacrh",
    components: { 
    }, 
    computed: {
      
       
    },
    
    watch: {
      
    },
    mounted() {
         

    },
    data() {
        return {
              
        };
    }
};
</script>
