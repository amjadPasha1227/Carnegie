<template>
<div>
    <div class="newsletter_widget"> 
        <div class="banner_cnt">
           <v-tabs class="pro_tabs" dark
            v-model="tabs"
            bottom
            >
            <v-tab><img src="../../../assets/images/player_icon.png"><span>ProFitX Aims To Provide Real- …</span></v-tab>
            <v-tab><img src="../../../assets/images/player_icon.png"><span>ProFitX Aims To Provide Real- …</span></v-tab>
            <v-tab><img src="../../../assets/images/player_icon.png"><span>ProFitX Aims To Provide Real- …</span></v-tab>
            
            <v-tab-item>
               <div class="banner_block">
                   <ul>
                       <li>PROFITX</li>
                       <li>FORBES</li>
                       <li>NBA</li>
                   </ul>
                   <label>ProFitX Aims To Provide Real-Time NBA Contract Data To Teams, Agents, Fans</label>
               </div>
            </v-tab-item>

            <v-tab-item>
                <div class="banner_block">
                   <ul>
                       <li>PROFITX</li>
                       <li>FORBES</li>
                       <li>NBA</li>
                   </ul>
                   <label>ProFitX Aims To Provide Real-Time NBA Contract Data To Teams, Agents, Fans</label>
               </div>
            </v-tab-item>

            <v-tab-item>
                <div class="banner_block">
                   <ul>
                       <li>PROFITX</li>
                       <li>FORBES</li>
                       <li>NBA</li>
                   </ul>
                   <label>ProFitX Aims To Provide Real-Time NBA Contract Data To Teams, Agents, Fans</label>
               </div>
            </v-tab-item>            
        </v-tabs>
        </div>
    </div>
</div>
</template> 

<script>  

export default {
    name: "synergy-seacrh",
    components: {  
    }, 
     
    data() {
        return {
             
             
        };
    },
    methods: {
     
    }
};
</script>  