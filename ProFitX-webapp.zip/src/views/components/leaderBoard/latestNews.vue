<template>
<div>
    <div class="newsletter_widget">
        <div class="block_title">
            <h2>THE LATEST NEWS</h2>             
        </div>
        <v-row>
            <v-col class="col-sm-4">
                <div class="news_block">
                    <figure><img src="../../../assets/images/news1.png"></figure>
                    <div class="news_details">
                        <h4>HEADING 1</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the</p>
                        <ul> 
                            <li>
                                <span><v-icon>mdi-thumb-up</v-icon>112</span>
                                <span><v-icon>mdi-thumb-down</v-icon>19</span>
                            </li> 
                        </ul>
                    </div>
                </div>
            </v-col>
            <v-col class="col-sm-4">
                <div class="news_block">
                    <figure><img src="../../../assets/images/news2.png"></figure>
                    <div class="news_details">
                        <h4>HEADING 1</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and</p>
                        <ul> 
                            <li>
                                <span><v-icon>mdi-thumb-up</v-icon>112</span>
                                <span><v-icon>mdi-thumb-down</v-icon>19</span>
                            </li> 
                        </ul>
                    </div>
                </div>
            </v-col>
            <v-col class="col-sm-4">
                <div class="news_block">
                    <figure><img src="../../../assets/images/news1.png"></figure>
                    <div class="news_details">
                        <h4>HEADING 1</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and</p>
                        <ul> 
                            <li>
                                <span><v-icon>mdi-thumb-up</v-icon>112</span>
                                <span><v-icon>mdi-thumb-down</v-icon>19</span>
                            </li> 
                        </ul>
                    </div>
                </div>
            </v-col>
        </v-row>
        <div class="news_list">
            <div class="news_block">
                <figure><img src="../../../assets/images/news3.png"></figure>
                <div class="news_details">
                    <h4>HEADING 1</h4>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    <ul> 
                        <li>
                            <span><v-icon>mdi-thumb-up</v-icon>112</span>
                            <span><v-icon>mdi-thumb-down</v-icon>19</span>
                        </li> 
                    </ul>
                </div>
            </div>
            <div class="news_block">
                <figure><img src="../../../assets/images/news3.png"></figure>
                <div class="news_details">
                    <h4>HEADING 1</h4>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    <ul> 
                        <li>
                            <span><v-icon>mdi-thumb-up</v-icon>112</span>
                            <span><v-icon>mdi-thumb-down</v-icon>19</span>
                        </li> 
                    </ul>
                </div>
            </div>
            <div class="news_block">
                <figure><img src="../../../assets/images/news3.png"></figure>
                <div class="news_details">
                    <h4>HEADING 1</h4>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    <ul> 
                        <li>
                            <span><v-icon>mdi-thumb-up</v-icon>112</span>
                            <span><v-icon>mdi-thumb-down</v-icon>19</span>
                        </li> 
                    </ul>
                </div>
            </div>
            <div class="news_block">
                <figure><img src="../../../assets/images/news3.png"></figure>
                <div class="news_details">
                    <h4>HEADING 1</h4>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    <ul> 
                        <li>
                            <span><v-icon>mdi-thumb-up</v-icon>112</span>
                            <span><v-icon>mdi-thumb-down</v-icon>19</span>
                        </li> 
                    </ul>
                </div>
            </div>
            
        </div>
    </div>
</div>
</template> 

<script> 
 
export default {
    name: "synergy-seacrh",
    components: { 
        
    }, 
     
    data() {
        return {
             
             
        };
    }
};
</script>
