<template>
<div>
    <div class="contestlist_widget">
        <div class="block_title">
            <h2>ATHLETE POLLS/CONTESTS</h2>             
        </div>
        <div class="contestlist_list athlete_contest_list">
            <h6>1. Which is best basket player ?</h6>
            <ul>
                <li>
                    <div class="contest_data">
                        <figure>
                            <img src="../../../assets/images/profile_dp-1.png">
                            <span><img src="../../../assets/images/bull_img.png"></span>
                        </figure> 
                        <div class="contests_data">
                            <h4>RUSSELL WESTBROOK</h4>
                            <div class="contests_progress">
                                <label style="left:25%">25%</label>
                            </div>
                            <div class="contests_ratings">
                                <div class="votings">
                                    <p><v-icon>mdi-thumb-up-outline</v-icon>VOTED</p>
                                    <span>54,250</span>
                                </div> 
                            </div>
                        </div>
                    </div>
                </li>
                 <li>
                    <div class="contest_data">
                        <figure>
                            <img src="../../../assets/images/profile_dp-1.png">
                            <span><img src="../../../assets/images/bull_img.png"></span>
                        </figure> 
                        <div class="contests_data">
                            <h4>RUSSELL WESTBROOK</h4>
                            <div class="contests_progress">
                                <label style="left:45%">45%</label>
                            </div>
                            <div class="contests_ratings">
                                <div class="votings">
                                    <p><v-icon>mdi-thumb-up-outline</v-icon>VOTED</p>
                                    <span>54,250</span>
                                </div> 
                            </div>
                        </div>
                    </div>
                </li>
                 <li>
                    <div class="contest_data">
                        <figure>
                            <img src="../../../assets/images/profile_dp-1.png">
                            <span><img src="../../../assets/images/bull_img.png"></span>
                        </figure> 
                        <div class="contests_data">
                            <h4>RUSSELL WESTBROOK</h4>
                            <div class="contests_progress">
                                <label style="left:50%">50%</label>
                            </div>
                            <div class="contests_ratings">
                                <div class="votings">
                                    <p><v-icon>mdi-thumb-up-outline</v-icon>VOTED</p>
                                    <span>54,250</span>
                                </div> 
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
</template> 

<script> 
 
export default {
    name: "synergy-seacrh",
    components: { 
    }, 
    computed: {
      
       
    },
    
    watch: {
      
    },
    mounted() {
         

    },
    data() {
        return {
                options: {
                height: '100%',
                size: 0,
                wheelStep :7,
            }

        };
    }
};
</script>
