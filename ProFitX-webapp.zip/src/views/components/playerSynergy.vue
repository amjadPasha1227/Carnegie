<template>
<div>

    <div class="widget_block synergy_widget" v-if="synergyplayers.length > 0"> 
        <div class="widget_title">
            <div class="d-flex">
                <h3>PLAYER SYNERGY

                    <v-tooltip bottom>
                        <template v-slot:activator="{ on, attrs }">
                            <v-btn class="info_btn" v-bind="attrs" v-on="on">
                                <v-icon>mdi-information-outline</v-icon>
                            </v-btn>
                        </template>
                        <span>Dynamic AI model that actively identifies ideal 2 & 3-MAN combinations from around the league and 2-MAN Team Combinations that are best suited to play together and will complement their respective skillsets.
</span>
                    </v-tooltip>

                </h3>
                <ul class="tab_buttons" v-if="teamcombotab == false">
                    <li  v-bind:class="{ active: playercombo2  }" @click="playercombo2=true;playercombo3=false;playercomboteam=false"><a>2 Player Combo</a></li>

                    <li v-bind:class="{ active: playercombo3  }" @click="playercombo3=true;playercombo2=false;playercomboteam=false"><a>3 Player Combo</a></li>
                    <li v-if="teamcombo && teamcombo.length > 0" v-bind:class="{ active: playercomboteam  }" @click="playercomboteam=true;playercombo2=false;playercombo3=false"><a>Team Combo</a></li>

                </ul>
                <ul class="tab_buttons" v-if="teamcombotab">


                </ul>
            </div>
            <div>
                <div class="slider_navigation">
                    <div class="swiper-button-prev"><span class="icon-play-flip"></span></div>
                    <div class="swiper-button-next"><span class="icon-play"></span></div>
                </div>
            </div>
        </div>

        <div v-if="playercombo2" class="playercombo2">

            <div class="widget_body pl-0 pt-0 pb-0 pr-0">
                <div class="synergy_slider">
                    <div class="synergy_slider_menu">
                        <v-list-item style="height:180px"></v-list-item>
                        <v-list-item  v-if="teamcombotab == false" style="height:95px">CONTRACT</v-list-item>
                        <v-list-item style="height:75px">Offense </v-list-item>
                        <v-list-item style="height:75px">Defense </v-list-item>
                    </div>
                    <swiper ref="awesomeSwiperA" :options="swiperOption">
                        <swiper-slide :key="ind" v-for="(splayer ,ind) in synergyplayers">
                            <v-card class outlined>
                                <v-card-title class="card_title" v-if="player">
                                    <div class="title_block"> <img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+player.goalserveDetails.PlayerID+".png"' class="align-self-center pl" :alt="player.PLAYER_NAME">

                                        <p>

                                            {{player.PLAYER_NAME}}

                                        </p>

                                        <span> Points: {{(player.POINTS/player.GP).toFixed(2)}} <br />
                                            Rebounds: {{(player.REB/player.GP).toFixed(2)}} <br />
                                            Assists: {{(player.AST/player.GP).toFixed(2)}} </span>
                                    </div>

                                    <span>
                                        <img src="../../assets/images/check-mark.svg" />
                                    </span>

                                    <div class="title_block"> <img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+splayer.goalserveDetails.PlayerID+".png"' class="align-self-center pl" :alt="splayer.PLAYER_NAME">

                                        <p> {{splayer.PLAYER_NAME}}

                                        </p>
                                        <span> Points: {{(splayer.POINTS/splayer.GP).toFixed(2)}} <br />
                                            Rebounds: {{(splayer.REB/splayer.GP).toFixed(2)}} <br />
                                            Assists: {{(splayer.AST/splayer.GP).toFixed(2)}} </span>
                                    </div>
                                </v-card-title>
                                <v-list-item>
                                    <v-list-item-content>
                                        <v-list-item v-if="teamcombotab == false">
                                            <v-col class="devider contact">
                                                <label class="currentsalary">
                                                    <small>TC</small>
                                                    {{player.TC | currency}}
                                                </label>

                                                <label v-bind:class="{ state2: player.TC > player.RTC, state1: player.TC < player.RTC }">
                                                    <small>rt</small>
                                                    {{player.RTC | currency}}
                                                </label>
                                            </v-col>

                                            <v-col class="contact">
                                                <label class="currentsalary">
                                                    <small>TC</small>
                                                    {{splayer.TC | currency}}
                                                </label>

                                                <label v-bind:class="{ state2: splayer.TC > splayer.RTC, state1: splayer.TC < splayer.RTC }">
                                                    <small>rt</small>
                                                    {{splayer.RTC | currency}}
                                                </label>
                                            </v-col>
                                        </v-list-item>
                                        <v-list-item>

                                            <v-col class="devider">

                                                <PlayerDNA :roles="player.ROLES" />
                                                <!-- <span> {{player.ATTR.Defense | percentagecustom(2) }}</span> -->
                                            </v-col>
                                            <v-col>

                                                <span>
                                                    <PlayerDNA :roles="splayer.ROLES" />

                                                </span>
                                            </v-col>
                                        </v-list-item>

                                    </v-list-item-content>
                                </v-list-item>
                            </v-card>
                        </swiper-slide>
                    </swiper>
                </div>
            </div>

        </div>
    <div v-if="playercomboteam" class="playercombo2">

            <div class="widget_body pl-0 pt-0 pb-0 pr-0">
                <div class="synergy_slider">
                    <div class="synergy_slider_menu">
                        <v-list-item style="height:180px"></v-list-item>
                        <v-list-item  v-if="teamcombotab == false" style="height:95px">CONTRACT</v-list-item>
                        <v-list-item style="height:75px">Offense </v-list-item>
                        <v-list-item style="height:75px">Defense </v-list-item>
                    </div>
                    <swiper ref="awesomeSwiperA" :options="swiperOption">
                        <template v-for="(splayer, index) in teamcombo">
                                 <swiper-slide :key="index" v-if="player && player.PLAYER_NAME!=splayer.PLAYER_NAME">
                            <v-card class outlined >
                                <v-card-title class="card_title" >
                                    <div class="title_block"> <img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+player.goalserveDetails.PlayerID+".png"' class="align-self-center pl" :alt="player.PLAYER_NAME">

                                        <p>

                                            {{player.PLAYER_NAME}}

                                        </p>

                                        <span> Points: {{(player.POINTS/player.GP).toFixed(2)}} <br />
                                            Rebounds: {{(player.REB/player.GP).toFixed(2)}} <br />
                                            Assists: {{(player.AST/player.GP).toFixed(2)}} </span>
                                    </div>

                                    <span>
                                        <img src="../../assets/images/check-mark.svg" />
                                    </span>

                                    <div class="title_block"> <img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+splayer.goalserveDetails.PlayerID+".png"' class="align-self-center pl" :alt="splayer.PLAYER_NAME">

                                        <p> {{splayer.PLAYER_NAME}}

                                        </p>
                                        <span> Points: {{(splayer.POINTS/splayer.GP).toFixed(2)}} <br />
                                            Rebounds: {{(splayer.REB/splayer.GP).toFixed(2)}} <br />
                                            Assists: {{(splayer.AST/splayer.GP).toFixed(2)}} </span>
                                    </div>
                                </v-card-title>
                                <v-list-item>
                                    <v-list-item-content>
                                        <v-list-item v-if="teamcombotab == false">
                                            <v-col class="devider contact">
                                                <label class="currentsalary">
                                                    <small>TC</small>
                                                    {{player.TC | currency}}
                                                </label>

                                                <label v-bind:class="{ state2: player.TC > player.RTC, state1: player.TC < player.RTC }">
                                                    <small>rt</small>
                                                    {{player.RTC | currency}}
                                                </label>
                                            </v-col>

                                            <v-col class="contact">
                                                <label class="currentsalary">
                                                    <small>TC</small>
                                                    {{splayer.TC | currency}}
                                                </label>

                                                <label v-bind:class="{ state2: splayer.TC > splayer.RTC, state1: splayer.TC < splayer.RTC }">
                                                    <small>rt</small>
                                                    {{splayer.RTC | currency}}
                                                </label>
                                            </v-col>
                                        </v-list-item>
                                        <v-list-item>

                                            <v-col class="devider">

                                                <PlayerDNA :roles="player.ROLES" />
                                                <!-- <span> {{player.ATTR.Defense | percentagecustom(2) }}</span> -->
                                            </v-col>
                                            <v-col>

                                                <span>
                                                    <PlayerDNA :roles="splayer.ROLES" />

                                                </span>
                                            </v-col>
                                        </v-list-item>

                                    </v-list-item-content>
                                </v-list-item>
                            </v-card>
                        </swiper-slide>

                        </template>
                   
                    </swiper>
                </div>
            </div>

        </div>
        <div v-if="playercombo3" class="playercombo3">

            <div class="widget_body pl-0 pt-0 pb-0 pr-0">
                <div class="synergy_slider">
                    <div class="synergy_slider_menu">
                        <v-list-item style="height:180px"></v-list-item>
                        <v-list-item  v-if="teamcombotab == false" style="height:95px">CONTRACT</v-list-item>
                        <v-list-item style="height:75px">Offense </v-list-item>
                        <v-list-item style="height:75px">Defense </v-list-item>
                    </div>
                    <swiper ref="awesomeSwiperA" :options="swiperOption">
                        <swiper-slide :key="indx" v-for="(splayer ,indx) in synergycombo3">

                            <v-card class outlined v-if="splayer ">
                                <v-card-title class="card_title">
                                    <div class="title_block"> <img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+player.goalserveDetails.PlayerID+".png"' class="align-self-center pl" :alt="player.PLAYER_NAME">

                                        <p>

                                            {{player.PLAYER_NAME}}

                                        </p>

                                        <span> Points: {{(player.POINTS/player.GP).toFixed(2)}} <br />
                                            Rebounds: {{(player.REB/player.GP).toFixed(2)}} <br />
                                            Assists: {{(player.AST/player.GP).toFixed(2)}} </span>

                                    </div>

                                    <span>
                                        <img src="../../assets/images/check-mark.svg" />
                                    </span>

                                    <div class="title_block"> <img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+splayer[0].goalserveDetails.PlayerID+".png"' class="align-self-center pl" :alt="splayer[0].PLAYER_NAME">

                                        <p> {{splayer[0].PLAYER_NAME}}

                                        </p>

                                        <span> Points: {{(splayer[0].POINTS/splayer[0].GP).toFixed(2)}} <br />
                                            Rebounds: {{(splayer[0].REB/splayer[0].GP).toFixed(2)}} <br />
                                            Assists: {{(splayer[0].AST/splayer[0].GP).toFixed(2)}} </span>

                                    </div>

                                    <span>
                                        <img src="../../assets/images/check-mark.svg" />
                                    </span>

                                    <div class="title_block"> <img :src='"https://profitx.ai/api/viewfile?path=playerimages/"+splayer[1].goalserveDetails.PlayerID+".png"' class="align-self-center pl" :alt="splayer[1].PLAYER_NAME">

                                        <p> {{splayer[1].PLAYER_NAME}}</p>

                                        <span> Points: {{(splayer[1].POINTS/splayer[1].GP).toFixed(2)}} <br />
                                            Rebounds: {{(splayer[1].REB/splayer[1].GP).toFixed(2)}} <br />
                                            Assists: {{(splayer[1].AST/splayer[1].GP).toFixed(2)}} </span>
                                    </div>
                                </v-card-title>
                                <v-list-item>
                                    <v-list-item-content>
                                        <v-list-item v-if="teamcombotab == false">
                                            <v-col class="devider contact">
                                                <label class="currentsalary">
                                                    <small>TC</small>
                                                    {{player.TC | currency}}
                                                </label>

                                                <label v-bind:class="{ state2: player.TC > player.RTC, state1: player.TC < player.RTC }">
                                                    <small>rt</small>
                                                    {{player.RTC | currency}}
                                                </label>
                                            </v-col>

                                            <v-col class="contact devider">
                                                <label class="currentsalary">
                                                    <small>TC</small>
                                                    {{splayer[0].TC | currency}}
                                                </label>

                                                <label v-bind:class="{ state2: splayer[0].TC > splayer[0].RTC, state1: splayer[0].TC < splayer[0].RTC }">
                                                    <small>rt</small>
                                                    {{splayer[0].RTC | currency}}
                                                </label>
                                            </v-col>
                                            <v-col class="contact">
                                                <label class="currentsalary">
                                                    <small>TC</small>
                                                    {{splayer[1].TC | currency}}
                                                </label>

                                                <label v-bind:class="{ state2: splayer[1].TC > splayer[1].RTC, state1: splayer[1].TC < splayer[1].RTC }">
                                                    <small>rt</small>
                                                    {{splayer[1].RTC | currency}}
                                                </label>
                                            </v-col>

                                        </v-list-item>

                                        <v-list-item>
                                            <v-col class="devider">
                                                <PlayerDNA :roles="player.ROLES" />

                                            </v-col>
                                            <v-col class="devider">
                                                <PlayerDNA :roles="splayer[0].ROLES" />

                                            </v-col>
                                            <v-col>
                                                <PlayerDNA :roles="splayer[1].ROLES" />

                                            </v-col>
                                        </v-list-item>

                                    </v-list-item-content>
                                </v-list-item>
                            </v-card>
                        </swiper-slide>
                    </swiper>
                </div>
            </div>

        </div>

    </div>
</div>
</template>

<script>
import "swiper/dist/css/swiper.css";
import PlayerDNA from "../popovers/playerrolessyn";

import {
    swiper,
    swiperSlide
} from "vue-awesome-swiper";
export default {
    name: "player-synergy",
    components: {
        swiper,
        swiperSlide,
        PlayerDNA
    },
    props: {
        player: {},
        playerid: null,
        teamcombotab:{
             type: Boolean,
             default:false
        },
    },
    computed: {

        swiper() {
            return this.$refs.mySwiper.swiper;
        }
    },
    methods: {
        orderedOffense(obj) {
            return this.lodash.mapValues(this.lodash.invert(this.lodash.invert(obj)), parseInt).slice(0, 2);

        },
        getSynergy() {
            this.$store
                .dispatch("getsynergy", this.player.PLAYER_ID)
                .then(response => {
                    this.synergyplayers = response.data.result.list;
                });
            this.swiper.slideTo(0, 1000, false);
        },

        setplayer(player) {
            if (player.contracts && player.contracts.CONTRACT) {
                return Math.round(
                    player.contracts.CONTRACT +
                    (player.contracts.CONTRACT * player.Regular_Season.Bio.NET_RATING) /
                    100
                );
            }

            return 0;
        }
    },
    watch: {
        player: function (value) {

            //  this.getSynergy();
        }
    },
    mounted() {

        var value = this.player;
        this.synergyplayers = value.comobo2Details;
        this.teamcombo= value.teamcomobo3Details;

        this.synergycombo3[0] = [];
        this.synergycombo3[1] = [];
        this.synergycombo3[2] = [];

        this.synergycombo3[0].push(this.lodash.find(value.comobo3Details, function (o) {
            return o['PLAYER_NAME'] == value.SYN3[0];
        }));
        this.synergycombo3[0].push(this.lodash.find(value.comobo3Details, function (o) {
            return o['PLAYER_NAME'] == value.SYN3[1];
        }));
        this.synergycombo3[1].push(this.lodash.find(value.comobo3Details, function (o) {
            return o['PLAYER_NAME'] == value.SYN3[2];
        }));
        this.synergycombo3[1].push(this.lodash.find(value.comobo3Details, function (o) {
            return o['PLAYER_NAME'] == value.SYN3[3];
        }));

        this.synergycombo3[2].push(this.lodash.find(value.comobo3Details, function (o) {
            return o['PLAYER_NAME'] == value.SYN3[4];
        }));
        this.synergycombo3[2].push(this.lodash.find(value.comobo3Details, function (o) {
            return o['PLAYER_NAME'] == value.SYN3[5];
        }));

                if(this.teamcombotab){
                    this.playercomboteam = true;
                     this.playercombo2 = false;
                      this.playercombo3 = false;

                }
          


    },

    data() {
        return {
            playercomboteam:false,
            playercombo2: true,
            playercombo3: false,
            synergyplayers: [],
            synergycombo3: [],
            teamcombo:[],
            swiperOption: {
                slidesPerView: "auto",
                spaceBetween: 10,
                pagination: {
                    el: '.swiper-pagination'
                },
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev'
                    // nextEl: this.$el.querySelector('.swiper-button-next'),
                    // prevEl: this.$el.querySelector('.swiper-button-prev')
                },
            }
        };
    }
};
</script>
