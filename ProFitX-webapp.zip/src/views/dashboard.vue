<template>
  <div class="dashboard_wrap" v-if="!firstLoading">
    <v-row>
      <v-col cols="8">
        <div class="performer">
          <h1 class="dashboard_title">Dashboard</h1>

          <div class="widget_block" style="overflow: none; position: relative">
            <div class="widget_title">
              <h3>Top Free Agents 2021</h3>

              <div class="assets-teams">
                <span class="selectlbl"> Position </span>
                <span>
                  <multiselect
                    :select-label="''"
                    deselect-label=""
                    v-model="selectedposition"
                    @input="positionchange"
                    :options="positions"
                    :close-on-select="true"
                    placeholder="Pick a Position"
                    label="name"
                  ></multiselect>
                </span>
              </div>
            </div>

            <div class="performer_list_wrap">
              <div
                class="performer_list"
                :key="index"
                v-for="(player, index) in topperformaerfa"
              >
                <router-link
                  :to="{
                    name: 'Team Dynamic',
                    params: { id: player.playerDetails.PLAYER_ID },
                  }"
                >
                  <div class="performance_details">
                    <label
                      ><small>
                        {{ player.playerDetails.RTC | currency }}</small
                      ></label
                    >
                  </div>
                  <div class="performance_data" style="height: 100px"></div>
                  <div
                    class="performer"
                    v-if="
                      player.goalserveDetails &&
                      player.goalserveDetails.length > 0
                    "
                  >
                    <figure>
                      <img
                        :src="
                          'https://profitx.ai/api/viewfile?path=playerimages/' +
                          player.goalserveDetails[0].PlayerID +
                          '.png'
                        "
                        class="align-self-center"
                        :alt="player.PLAYER_NAME"
                      />
                    </figure>
                    <span>
                      <img
                        :src="
                          'https://profitx.ai/api/viewfile?path=teams/' +
                          player.goalserveDetails[0].TeamID +
                          '.png'
                        "
                      />
                    </span>
                  </div>
                  <label>{{ player.PLAYER_NAME }}</label>

                  <span v-if="player.POSITION"
                    >{{ getposition(player.POSITION) }}
                  </span>
                </router-link>
              </div>
            </div>
          </div>
        </div>
        <div class="d-player_role">
          <div class="widget_block">
            <div class="widget_title">
              <h3>Top Player Roles - Weekly</h3>

              <div class="assets-teams">
                <span class="selectlbl"> Role </span>
                <span>
                  <multiselect
                    :select-label="''"
                    deselect-label=""
                    v-model="selectedroles"
                    @input="onChange"
                    :options="roleslist"
                    :close-on-select="true"
                    placeholder="Pick a Role"
                  ></multiselect>
                </span>
              </div>

              <div style="display: none">
                <ul class="tab_buttons">
                  <li
                    v-bind:class="{ active: toprolestab == 'Offense' }"
                    @click="toprolestab = 'Offense'"
                  >
                    <a>Offense</a>
                  </li>
                  <li
                    v-bind:class="{ active: toprolestab == 'Defense' }"
                    @click="toprolestab = 'Defense'"
                  >
                    <a>Defense</a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="widget_body" style="min-height: auto">
              <div class="shotsloading" v-if="shotsloading">
                <img src="@/assets/images/shotsloading.svg" />
              </div>
              <div
                class="role_graph performer d_performer"
                v-if="!shotsloading"
              >
                <div class="performer_list_wrap" style="padding-bottom: 0px">
                  <div
                    class="performer_list"
                    :key="index"
                    v-for="(player, index) in topperformaerroles"
                  >
                    <router-link
                      :to="{
                        name: 'Team Dynamic',
                        params: { id: player.PLAYER_ID },
                      }"
                    >
                      <div class="performance_details">
                        <label
                          ><small> {{ player.RTC | currency }}</small></label
                        >
                      </div>
                      <div class="performance_data" style="height: 40px"></div>
                      <div class="performer">
                        <figure>
                          <img
                            :src="
                              'https://profitx.ai/api/viewfile?path=playerimages/' +
                              player.goalserveDetails[0].PlayerID +
                              '.png'
                            "
                            class="align-self-center"
                            :alt="player.PLAYER_NAME"
                          />
                        </figure>
                        <span>
                          <img
                            :src="
                              'https://profitx.ai/api/viewfile?path=teams/' +
                              player.goalserveDetails[0].TeamID +
                              '.png'
                            "
                          />
                        </span>
                      </div>
                      <label>{{ player.PLAYER_NAME }}</label>
                      <PlayerDNA
                        v-if="player.ROLES && selectedroles"
                        :selectedrole="selectedroles"
                        :roles="player.ROLES"
                      />
                    </router-link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="d-player_versatility" style="display: none">
          <div class="widget_block">
            <div class="widget_title modal_header">
              <div class="modal_title">
                <h3>Player Versatility</h3>
              </div>
              <div></div>
            </div>
            <div class="widget_body">
              <div class="d-versatility-graph"></div>
              <div class="d-versatility-list">
                <ul>
                  <li>
                    <div class="versatility_profile">
                      <figure>
                        <img src="../assets/images/profile_dp-1.png" />
                      </figure>
                      <span
                        ><img src="../assets/images/profile_dp-1.png"
                      /></span>
                    </div>
                    <label
                      >Grayson Allen
                      <em>Forward-Guard</em>
                    </label>
                  </li>
                  <li>
                    <div class="versatility_profile">
                      <figure>
                        <img src="../assets/images/profile_dp-1.png" />
                      </figure>
                      <span
                        ><img src="../assets/images/profile_dp-1.png"
                      /></span>
                    </div>
                    <label
                      >Grayson Allen
                      <em>Forward-Guard</em>
                    </label>
                  </li>
                  <li>
                    <div class="versatility_profile">
                      <figure>
                        <img src="../assets/images/profile_dp-1.png" />
                      </figure>
                      <span
                        ><img src="../assets/images/profile_dp-1.png"
                      /></span>
                    </div>
                    <label
                      >Grayson Allen
                      <em>Forward-Guard</em>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </v-col>
      <v-col cols="4">
        <a href="/athletes" class="athelete_link"
          >ATHLEDEX <v-icon>mdi-arrow-right</v-icon></a
        >
        <div class="top_performer_list">
          <div class="widget_block">
            <div class="widget_title">
              <div class="modal_title">
                <h3>Top ProFitX Ratings - Daily</h3>
              </div>
            </div>

            <div class="widget_body">
              <div class="performer_list">
                <ul v-if="topperformaers && topperformancetab == 'Offense'">
                  <li :key="index" v-for="(player, index) in orderedOffense">
                    <div class="performer">
                      <div class="performer_title">
                        <figure>
                          <img
                            :src="
                              'https://profitx.ai/api/viewfile?path=playerimages/' +
                              player.goalserveDetails[0].PlayerID +
                              '.png'
                            "
                            class="align-self-center"
                            :alt="player.PLAYER_NAME"
                          />
                        </figure>
                        <span>
                          <img
                            :src="
                              'https://profitx.ai/api/viewfile?path=teams/' +
                              player.goalserveDetails[0].TeamID +
                              '.png'
                            "
                          />
                        </span>
                      </div>
                      <label>
                        <router-link
                          :to="{
                            name: 'Team Dynamic',
                            params: { id: player.PLAYER_ID },
                          }"
                        >
                          {{ player.PLAYER_NAME }}
                        </router-link>
                      </label>
                    </div>
                    <div class="d-contract_details">
                      <div
                        v-if="
                          player.playerDetails &&
                          player.RTP > player.playerDetails[0].RTP
                        "
                        class="d-contract_value"
                      >
                        <label
                          >{{
                            Math.round(
                              ((player.RTP - player.playerDetails[0].RTP) /
                                player.playerDetails[0].RTP) *
                                100
                            )
                          }}<em>%</em></label
                        ><span><v-icon>mdi-menu-up</v-icon></span>
                      </div>
                      <div class="d-contract_right">
                        <label> {{ player.RTP | roundme }}</label>
                      </div>
                    </div>
                  </li>
                </ul>
                <ul v-if="topperformaers && topperformancetab == 'Defense'">
                  <li :key="index" v-for="(player, index) in orderedDefnse">
                    <div class="performer">
                      <div class="performer_title">
                        <figure>
                          <img
                            :src="
                              'https://profitx.ai/api/viewfile?path=playerimages/' +
                              player.goalserveDetails[0].PlayerID +
                              '.png'
                            "
                            class="align-self-center"
                            :alt="player.PLAYER_NAME"
                          />
                        </figure>
                        <span>
                          <img
                            :src="
                              'https://profitx.ai/api/viewfile?path=teams/' +
                              player.goalserveDetails[0].TeamID +
                              '.png'
                            "
                          />
                        </span>
                      </div>
                      <label>
                        <router-link
                          :to="{
                            name: 'Team Dynamic',
                            params: { id: player.PLAYER_ID },
                          }"
                        >
                          {{ player.PLAYER_NAME }}
                        </router-link>
                      </label>
                    </div>

                    <div class="d-contract_details">
                      <div
                        v-if="
                          player.playerDetails &&
                          player.RTP > player.playerDetails[0].RTP
                        "
                        class="d-contract_value"
                      >
                        <label
                          >{{
                            Math.round(
                              ((player.RTP - player.playerDetails[0].RTP) /
                                player.playerDetails[0].RT) *
                                100
                            )
                          }}<em>%</em></label
                        ><span><v-icon>mdi-menu-up</v-icon></span>
                      </div>
                      <div class="d-contract_right">
                        <label> {{ player.RTP | roundme }}</label>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="d_injury" style="display: none">
          <div class="widget_block">
            <div class="widget_title">
              <div class="modal_title">
                <h3>Injury Risk</h3>
              </div>
              <div></div>
            </div>
            <div class="widget_body">
              <div class="d-injury_details">
                <div class="d_injury_profile">
                  <img src="../assets/images/profile_dp-1.png" />
                  <label>Stephen Curry</label>
                </div>
                <div class="d_injury_details">
                  <label>13.6%</label>
                  <span>Last Week 7%</span>
                </div>
                <figure><img src="../assets/images/player.png" /></figure>
              </div>
            </div>
          </div>
        </div>
      </v-col>
    </v-row>
  </div>
</template>

<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>

<script>
import PlayerDNA from "./popovers/playerroles";

export default {
  components: {
    PlayerDNA,
  },
  methods: {
    getposition(type) {
      var _p = this.lodash.find(this.positions, function (my) {
        return my.value == type;
      });
      return _p.name;
    },
    positionchange() {
      this.$store
        .dispatch("dashboarddatatopfa", {
          position: this.selectedposition.value,
        })
        .then((response) => {
          this.topperformaerfa = response.data.data;
        });
    },
    onChange() {
      var self = this;
      this.shotsloading = true;
      this.$store
        .dispatch("topperformaerroles", {
          selectedroles: this.selectedroles,
        })
        .then((response) => {
          self.shotsloading = false;
          this.topperformaerroles = response.data.data;
        });
    },
    gettopperformaers() {
      this.firstLoading = false;
      var self = this;
      this.shotsloading = true;
      this.$store
        .dispatch("dashboardstats", {
        })
        .then((response) => {
          this.topperformaers = response.data;
        });
      this.$store
        .dispatch("dashboardstatstop", {
        })
        .then((response) => {
          this.topperformaersc = response.data;
        });

      this.$store
        .dispatch("dashboarddatatopfa", {
          position: this.selectedposition.value,
        })
        .then((response) => {
          this.topperformaerfa = response.data.data;
        });

      this.$store
        .dispatch("topperformaerroles", {
          selectedroles: this.selectedroles,
        })
        .then((response) => {
          self.shotsloading = false;
          this.topperformaerroles = response.data.data;
        });
    },
  },
  computed: {
    orderedOffense: function () {
      return this.lodash.orderBy(
        this.topperformaers.offensedata,
        ["RTP"],
        ["desc"]
      );
    },
    orderedDefnse: function () {
      return this.lodash.orderBy(
        this.topperformaers.defensedata,
        ["RTP"],
        ["desc"]
      );
    },
    orderedOffensec: function () {
      return this.lodash.orderBy(
        this.topperformaersc.raisers,
        ["RTC"],
        ["desc"]
      );
    },
  },
  filters: {
    roundme: function (value) {
      if (!value) return "";
      value = Math.round(value).toFixed(0);
      return value;
    },
  },
  mounted() {
      var $self = this;
    let user = this.$store.state.user;
    let userRole = this.$store.state.userRole;
    let currentPlan = this.$store.getters["subscription/getSubscriptions"];
    this.usersubscription = this.$store.state.subscription;
    let subscription = this.$store.state.subscription;

  
    if (userRole == 4 && currentPlan[0].invoiceDetails == null) {
        
      $self.$router.push("/plan");
    } else if (userRole == 4) {
         
      if (
        currentPlan &&
        currentPlan.length > 0 &&
        currentPlan[0].invoiceDetails > 0 &&
        currentPlan[0].invoiceDetails.statusId == 2
      ) {
        $self.gettopperformaers();
      } else {
        $self.$router.push("/plan");
      }
    } else {
      $self.gettopperformaers();
    }

    this.setPageTitle("ProFitX - Dashboard");

  },
  data() {
    return {
      firstLoading: true,
      roleslist: [
        "Sharpshooter",
        "Slasher",
        "Playmaker",
        "High Volume Scorer",
        "High Motor",
        "Rebounding Specialist",
        "Rim Protector",
      ],
      selectedroles: "Sharpshooter",
      shotsloading: false,

      positions: [
        {
          name: "Power Forward",
          value: "F-C",
        },
        {
          name: "Forward",
          value: "F",
        },
        {
          name: "Versatile Center",
          value: "C-F",
        },
        {
          name: "Center",
          value: "C",
        },
        {
          name: "Combo Guard",
          value: "G-F",
        },
        {
          name: "Guard",
          value: "G",
        },
        {
          name: "Wing",
          value: "F-G",
        },
      ],
      selectedposition: {
        name: "Guard",
        value: "G",
      },
      toprolestab: "Offense",
      topperformancetab: "Offense",
      topperformancetabc: "Offense",
      topperformaers: [],
      topperformaersc: [],
      topperformaerfa: [],
      topperformaerroles: [],
    };
  },
};
</script>

<style>
</style>
