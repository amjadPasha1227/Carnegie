<template>
  <div class="content-body" v-if="!firstisloading">
    <the-filter @updatefilters="filtersupdated" />
    <div class="content-wrapper athelets_content">
      <div class="athletes-list">
        <div class="top-bar">
          <div class="top-bar-left">
            <h3>
              ATHLEDEX<label
                >Total Players : <b>{{ totalCount }} </b></label
              >
            </h3>
          </div>
          <div class="top-bar-right">
            <ul>
              <li>
                <input
                  v-on:keyup="searchPlayer($event.target.value)"
                  type="text"
                  class="search"
                  placeholder="Search Athletes"
                />
              </li>
            </ul>
          </div>
        </div>
        <div class="athletes-alphabets">
          <ul>
            <li
              v-bind:class="{
                active: startswith == '' && searchString == 'All',
              }"
            >
              <a href="javascript:;" @click="searchPlayer('All')">All</a>
            </li>

            <li
              v-bind:class="{ active: startswith == item }"
              v-for="item in alphabets"
              :key="item"
            >
              <a @click="searchsPlayer(item)" href="javascript:;">{{ item }}</a>
            </li>
          </ul>
        </div>
        <div class="athletes-details-list padt10">
          <div class="svgperformance"></div>

          <div class="athletes_table">
            <div class="athletes_table_content">
              <div class="athletetable_head">
                <div class="athletetable_thr">
                  <div class="athletetable_th col1 text-left">PLAYERS</div>
                  <div v-if="checkWidgetsPermessions('PLAYER_CONTRACTS')" class="athletetable_th col2 text-left">
                    TEAM/REAL-TIME
                  </div>
                  <div v-if="checkWidgetsPermessions('PLAYER_CONTRACTS')"  class="athletetable_th col4 text-left">
                    CONTRACT TRAJECTORY
                  </div>
                </div>
              </div>

              <div class="athletetable_body list-group-wrapper">
                <!-- <div class="loading-page" v-if="isloading">
                                <figure>
                                    <img src="@/assets/images/loader.gif">
                                </figure>Loading
                            </div> -->
                <div
                  class="loading-page"
                  v-if="!isloading && players.length == 0"
                >
                  No Results Found
                </div>

                <div class="list_wrap list-group" id="infinite-list">
                  <div
                    v-for="(player, index) in players"
                    v-bind:key="player"
                    class="list_block list-group-item"
                  >
                    <v-lazy
                      v-model="player['isactive']"
                      :options="{
                        threshold: 0.1,
                      }"
                      min-height="110"
                      :data="index"
                    >
                      <div class="athletetable_tdr">
                        <div class="athletetable_td col1">
                          <div class="player-info">
                            <template v-if="player.PLAYER_IMAGE">
                                    <div class="media" v-if="player.PLAYER_IMAGE">
                              <figure>
                                <img
                                  :src="player.PLAYER_IMAGE"
                                  class="align-self-center"
                                  :alt="player.PLAYER_NAME"
                                />
                              </figure>
                              <div class="badge-logo">
                                <img
                                  :src="
                                    siteUrl+'/api/viewfile?path=teams/' +
                                    player.TEAM_ID+
                                    '.png'
                                  "
                                />
                              </div>
                            </div>
                            </template>
                            <template v-else>

                                    <div class="media" v-if="player.goalserveDetails">
                              <figure>
                                <img
                                  :src="
                                    siteUrl+'/api/viewfile?path=playerimages/' +
                                    player.goalserveDetails.PlayerID +
                                    '.png'
                                  "
                                  class="align-self-center"
                                  :alt="player.PLAYER_NAME"
                                />
                              </figure>
                              <div class="badge-logo">
                                <img
                                  :src="
                                    siteUrl+'/api/viewfile?path=teams/' +
                                    player.goalserveDetails.TeamID +
                                    '.png'
                                  "
                                />
                              </div>
                            </div>
                                </template>

                      

                            <div class="players-info-list">
                              <h2>
                                <router-link
                                  :to="{
                                    name:'Team Dynamic',
                                    params: { id: player.PLAYER_ID },
                                  }"
                                  >{{ player.PLAYER_NAME }}
                                </router-link>
                                <span v-if="player.positionDetails">{{
                                  player.POSITION
                                }}</span>
                                <div class="athlete_info_wrap">
                                  <div class="info-title">INFO</div>
                                  <div class="athlete_info">
                                    <ul>
                                      <li>
                                        <label>AGE</label>
                                        <p>{{ player.AGE | number }} yrs</p>
                                      </li>
                                      <li v-if="player.HEIGHT">
                                        <label>HEIGHT</label>
                                        <p>{{ player.FHEIGHT }}</p>
                                      </li>
                                      <li v-if="player.WEIGHT">
                                        <label>WEIGHT</label>
                                        <p>{{ player.WEIGHT }} lbs</p>
                                      </li>
                                      <li v-if="player.WINGSPAN">
                                        <label>WINGSPAN</label>
                                        <p>{{ player.WINGSPAN }}</p>
                                      </li>
                                      <li v-if="player.PRO">
                                        <label>Years Pro</label>
                                        <p>{{ player.PRO }}</p>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="fav_list">
                                  <AddToFav
                                   
                                    :favslist="favslist"
                                    :player="player"
                                  /> 
                                  <!-- <v-icon>mdi-star</v-icon> -->
                                </div>
                              </h2>
                              <ul>
                                <li>
                                  <p>FG%</p>
                                  <span
                                    >{{
                                      ((player.FGM / player.FGA) * 100)
                                        | percent(2)
                                    }}
                                  </span>
                                </li>
                                <li>
                                  <p>3PT%</p>
                                  <span>{{
                                    ((player["3PTM"] / player["3PTA"]) * 100)
                                      | percent(2)
                                  }}</span>
                                </li>
                                <li>
                                  <p>FT%</p>
                                  <span>{{
                                    ((player["FTM"] / player["FTA"]) * 100)
                                      | percent(2)
                                  }}</span>
                                </li>
                                <li>
                                  <p>Games Played</p>
                                  <span>{{ player.GP }}</span>
                                </li>
                                <li>
                                  <p>PTS</p>
                                  <span>{{
                                    (player.POINTS / player.GP).toFixed(1)
                                  }}</span>
                                </li>
                                <li v-if="player.PRO">
                                  <p>Years Pro</p>
                                  <span>{{ player.PRO }}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div
                          v-if="checkWidgetsPermessions('PLAYER_CONTRACTS') && player.TGP > 40"
                          class="athletetable_td col2"
                        >
                          <div v-if="player.TC" class="team-contract">
                            <ul
                              @mouseover="
                                _drawperformance(
                                  'contract_graph' + index,
                                  player.attributes
                                );
                                _drawrtc(
                                  'contract_graphm' + index,
                                  player.realtime
                                );
                              "
                            >
                              <li v-if="player.TC" class="team_blue">
                                <v-chip>
                                  <v-avatar>TC</v-avatar>
                                  {{ player.TC | currency }}
                                </v-chip>
                              </li>

                              <li
                                v-bind:class="{
                                  team_green: player.RTC > player.TC,
                                  team_red: player.RTC < player.TC,
                                }"
                              >
                                <v-chip>
                                  <v-avatar>RT</v-avatar>
                                  {{ player.RTC | currency }}
                                </v-chip>
                              </li>
                            </ul>

                            <div class="contract_details_wrap">
                              <div
                                class="contract_details contract_performance"
                              >
                                <div
                                  class="ct_details_header"
                                  v-if="player.ATTR"
                                >
                                  <h4>Performance - Past 10 Games</h4>
                                  <div>
                                    <label class="green"
                                      >Offense -
                                      {{
                                        player.ATTR.Offense
                                          | percentagecustom(2)
                                      }}</label
                                    >
                                    <label class="red"
                                      >Defense -
                                      {{
                                        player.ATTR.Defense
                                          | percentagecustom(2)
                                      }}</label
                                    >
                                  </div>
                                </div>
                                <div class="contract_graph axixcolors">
                                  <div
                                    :id="'contract_graph' + index"
                                    style="height: 210px; margin-top: 20px"
                                    class="performancegraph"
                                  ></div>

                                  <div class="ct_details_header">
                                    <h4>Real-Time Contract Trajectory - Past 10 Games</h4>
                                    <div></div>
                                  </div>

                                  <div
                                    :id="'contract_graphm' + index"
                                    style="height: 210px; margin-top: 20px"
                                    class="performancegraph"
                                  ></div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="team-contract" v-else>
                            <ul>
                              <li class="team_green">
                                <v-chip>
                                  <v-avatar>RC</v-avatar>
                                  {{ player.RTC | currency }}
                                </v-chip>
                              </li>
                            </ul>
                          </div>
                        </div>

                        <div
                          v-if="checkWidgetsPermessions('PLAYER_CONTRACTS') && player.TGP > 40"
                          class="athletetable_td col4"
                        >
                          <div
                            class="carrer_info carrer_up"
                            v-bind:class="{
                              carrer_up:
                                getPercentageChange(player.RTC, player.TC) > 0,
                              carrer_down:
                                getPercentageChange(player.RTC, player.TC) < 0,
                            }"
                          >
                            <label
                              >{{
                                getPercentageChange(player.RTC, player.TC)
                              }}
                              %</label
                            ><span></span>
                          </div>
                          <!-- <div class="carrer_info carrer_down">
                  <label>100%</label><span></span>
                </div> -->
                        </div>
                      </div>
                    </v-lazy>
                  </div>
                  <div class="loading-list" v-if="isloading">
                    <figure>
                      <img src="@/assets/images/loader.gif" />
                    </figure>
                    Loading
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_dark from "@amcharts/amcharts4/themes/dark";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_dark);
am4core.useTheme(am4themes_animated);
import moment from "moment";

import TheFilter from "./../layouts/components/TheFilter.vue";
import AddToFav from "./popovers/addtofav";

var _performancechart;
var _performancecharta;

//  import VueApexCharts from 'vue-apexcharts';
export default {
  components: {
    TheFilter,
    AddToFav,
  },
  methods: {
    initMethod() {
      let user = this.$store.state.user;
      if ([1, 2, 3, 5].indexOf(user.roleId) > -1) {
        this.firstisloading = false;
        this.getplayers();
      }

      var $self = this;
      this.$store.dispatch("getuserDetails", {}).then((response) => {
        if (response.roleId != 4) {
          this.firstisloading = false;
          this.getplayers();
        } else {
          var user = $self.$store.state.user;
          var payLoad = {
            subscriber: {
              name: user.name,
              email: user.email,
              phone: user.phoneNo,
              phoneCode: "+1",
            },
            page: 1,
            perpage: 100,
            appActivity: true,
          };
          this.$store
            .dispatch("subscription/getSelectedPlan", payLoad)
            .then((currentPlan) => {
              if (currentPlan[0].invoiceDetails == null) {
                this.$router.push("/plan");
              } else {
                if (
                  currentPlan &&
                  currentPlan.length > 0 &&
                  currentPlan[0].invoiceDetails != null &&
                  currentPlan[0].invoiceDetails.statusId != 2
                ) {
                  this.$router.push("/plan");
                } else {
                  if (
                    response.subscriptionDetails &&
                    response.subscriptionDetails.length > 0 &&
                    response.subscriptionDetails[0].athletes.length > 0
                  ) {
                    this.passplayers = response.subscriptionDetails[0].athletes;
                    this.getplayers();
                  } else {
                    this.$router.push("/athlete-selection");
                  }
                }
              }
            });
        }
      });
    },
    getFav() {
      var userid = this.$store.state.user._id;

      const obja = {
        matcher: {},
        userId: userid,
        page: 1,
        perpage: 10000,
      };

      this.favslist = [];
      this.$store
        .dispatch("getusefav", obja)
        .then((response) => {
          this.favslist = response["list"];
           this.getplayers();
        })
        .catch((err) => {});
    },

    _drawrtc(id, ndata) {
      var _self = this;
      if (_performancecharta) _performancecharta.dispose();

      var chart = am4core.create(id, am4charts.XYChart);
      _performancecharta = chart;
      // The following would work as well:
      // var chart = am4core.create("chartdiv", "XYChart");

      var results = ndata;
      var data = [];

      results.forEach((d, index) => {
        var _cd = {};
        _cd["date"] = moment(d["date"]).format("MMM, DD");
        _cd["RTM"] = d["RTM"].toFixed(2);
        data.push(_cd);
      });

      // Add Data
      chart.data = data.reverse();

      // Add category axis
      var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
      categoryAxis.dataFields.category = "date";
      categoryAxis.renderer.grid.template.location = 0;
      categoryAxis.renderer.minGridDistance = 5;
      categoryAxis.renderer.labels.template.horizontalCenter = "right";
      categoryAxis.renderer.labels.template.verticalCenter = "middle";
      categoryAxis.renderer.labels.template.rotation = 270;
      // Add value axis
      let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
      valueAxis.fillOpacity = 0.6;
      valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
      // Add series
      var series = chart.series.push(new am4charts.LineSeries());
      series.dataFields.categoryX = "date";
      series.dataFields.valueY = "RTM";
      series.stroke = am4core.color("green");
      series.strokeWidth = 4;
      categoryAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
    },
    _drawperformance(id, ndata) {
      var _self = this;
      if (_performancechart) _performancechart.dispose();

      var chart = am4core.create(id, am4charts.XYChart);
      _performancechart = chart;
      // The following would work as well:
      // var chart = am4core.create("chartdiv", "XYChart");

      var results = ndata;
      var data = [];

      results.forEach((d, index) => {
        var _cd = {};
        _cd["date"] = moment(d["date"]).format("MMM, DD");
        _cd["DEFENSE"] = +(d["Defense_rank"] * 100).toFixed(2);
        _cd["OFFENSE"] = +(d["Offense_rank"] * 100).toFixed(2);
        data.push(_cd);
      });

      // Add Data
      chart.data = data.reverse();

      // Add category axis
      var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
      categoryAxis.dataFields.category = "date";
      categoryAxis.renderer.grid.template.location = 0;
      categoryAxis.renderer.minGridDistance = 5;
      categoryAxis.renderer.labels.template.horizontalCenter = "right";
      categoryAxis.renderer.labels.template.verticalCenter = "middle";
      categoryAxis.renderer.labels.template.rotation = 270;
      // Add value axis
      let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
      valueAxis.fillOpacity = 0.6;

      valueAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
      // Add series
      var series = chart.series.push(new am4charts.LineSeries());
      series.dataFields.categoryX = "date";
      series.dataFields.valueY = "OFFENSE";
      series.stroke = am4core.color("green");
      series.strokeWidth = 4;

      var series2 = chart.series.push(new am4charts.LineSeries());
      series2.dataFields.categoryX = "date";
      series2.dataFields.valueY = "DEFENSE";
      series2.stroke = am4core.color("red");
      series2.strokeWidth = 4;
      categoryAxis.renderer.labels.template.fill = am4core.color("#7484a1cc");
    },
    defaultImage(event) {
      event.target.src = this.siteUrl+"/player_demo.svg";
    },
    setplayer(player) {
      return 0;
    },
    searchPlayer(char) {
      this.startswith = "";
      this.searchString = char;
      this.page = 1;
      this.players = [];
      this.getplayers();
    },
    searchsPlayer(char) {
      this.page = 1;
      this.players = [];
      this.searchString = "";
      this.startswith = char;
      this.getplayers();
    },
    filtersupdated: function (filterdata) {
      this.experience = filterdata.experience;
      this.playerweight = filterdata.playerweight;
      this.playerheight = filterdata.playerheight;
      this.playerage = filterdata.playerage;
      this.player_role = filterdata.player_role;
      this.exp = filterdata.exp;
      this.RTC = filterdata.RTC;
      this.FA = filterdata.fa;

      this.playerposition = filterdata.player_position;
      this.playerage = filterdata.playerage;
      this.playerteam = filterdata.player_team;
      this.page = 1;
      this.players = [];
      this.getplayers();
    },
    getPercentageChange(a, b) {
      var rt = ((a - b) * 100) / b;
      return rt.toFixed(2);
    },
    getplayers() {
      this.firstisloading = false;
      this.isloading = true;

      this.serach = {
        page: this.page,
        perpage: this.perpage,
        matcher: {
          startswith: this.startswith,
          searchString: this.searchString,
          playerage: this.playerage,
          playerteam: this.playerteam,
          playerposition: this.playerposition,
          exp: this.exp,
          RTC: this.RTC,
          playerweight: this.playerweight,
          playerheight: this.playerheight,
          player_role: this.player_role,
          FA: this.FA,
        },
      };

      if (
        this.$store.state &&
        this.$store.state.user &&
        this.$store.state.user.roleId == 4
      ) {

        if (this.passplayers != null) {
          Object.assign(this.serach.matcher, {
            filterplayers: this.passplayers,
          });
        }
      }

        if (
        this.$store.state &&
        this.$store.state.user &&
        this.$store.state.user.roleId == 6
      ) {

        if (this.passplayers != null) {
          Object.assign(this.serach.matcher, {
            filterplayers: this.passplayers,
          });
        }
      }

       if(this.$store.state.user.email == 'warren@shawsports.net'){
                   this.passplayers = ["Robert Williams III","Payton Pritchard","Jayson Tatum"];

                Object.assign(this.serach.matcher, {
            filterplayers: this.passplayers,
          });


       }


      this.$store.dispatch("getplayers", this.serach).then((response) => {
        this.totalCount = response.data.result.totalCount;
        let finaldata = response.data.result.list;
        // this.players = finaldata;

        this.lodash.forEach(finaldata, (item, index) => {
          let isExists = this.lodash.find(this.players, {
            PLAYER_NAME: item["PLAYER_NAME"],
          });
          if (!isExists) {
            this.players.push(item);
          }
        });

        var self = this;
        self.isloading = false;
      });
    },
  },
  mounted() {
    let user = this.$store.state.user;
    let userRole = this.$store.state.userRole;
    let currentPlan = this.$store.getters["subscription/getSubscriptions"];
    this.usersubscription = this.$store.state.subscription;
    let subscription = this.$store.state.subscription;
    this.setPageTitle("ProFitX - Athletes ");
    this.siteUrl = process.env.VUE_APP_API_URL;

    if(this.usersubscription && this.usersubscription.passType && this.usersubscription.passType =="Limited Access"){

       if (
          subscription != null &&
          subscription.athletes != null &&
          subscription.athletes.length > 0
        ) {
          this.passplayers = subscription.athletes;
          this.getFav();
         // this.getplayers();
        } else {
          this.$router.push("/athlete-selection");
        }

    }

    if (user != null && userRole == 4) {
      if (
        currentPlan != null &&
        currentPlan.length > 0 &&
        currentPlan[0].invoiceDetails != null &&
        currentPlan[0].invoiceDetails.statusId == 2
      ) {

          if(currentPlan[0].planDetails.uniqueId =='LEAGUEPASS'){
                  this.getFav();   

          }else{

               if (
          subscription != null &&
          subscription.athletes != null &&
          subscription.athletes.length > 0
        ) {
          this.passplayers = subscription.athletes;
          this.getFav();
         // this.getplayers();
        } else {
          this.$router.push("/athlete-selection");
        }

          }

       

      } else {
        this.$router.push("/plan");
      }
    }
    if (user != null && [1, 2, 3, 5].indexOf(userRole) > -1) {
      window.onscroll = () => {
        if (
          window.innerHeight + Math.ceil(window.pageYOffset) >=
          document.body.offsetHeight
        ) {
          if (this.players.length < this.totalCount) {
            this.page++;
            this.getplayers();
          }
        }
      };
  
      if(user.email == 'warren@shawsports.net'){
          this.passplayers = ["Robert Williams","Payton Pritchard","Jayson Tatum"];

        this.getplayers();
      }else{
                  this.getplayers();

      }

      this.getFav();   
     
    }
  },
  data: () => ({
    firstisloading: true,
    nextItem: 1,
    items: [],
    siteUrl:null,
    totalCount: 0,
    passplayers: null,
    favslist: null,
    user: null,
    hoverchart: [],
    searchString: "",
    startswith: null,
    isloading: true,
    disable: false,
    serach: {},
    players: [],
    rolesgroup: {},
    playerposition: {},
    playerteam: {},
    playerage: {},
    experience: null,
    playerweight: null,
    playerheight: null,
    player_role: null,
    exp: null,
    RTC: null,
    FA: null,
    alphabets: [
      "a",
      "b",
      "c",
      "d",
      "e",
      "f",
      "g",
      "h",
      "i",
      "j",
      "k",
      "l",
      "m",
      "n",
      "o",
      "p",
      "q",
      "r",
      "s",
      "t",
      "u",
      "v",
      "w",
      "x",
      "y",
      "z",
    ],
    currentalphabet: "",
    page: 1,
    perpage: 25,
    fav: true,
    menu: false,
    message: false,
    hints: true,
    usersubscription: null,
  }),
};
</script>
