<template>
<div class="flex w-full bg-img vx-row no-gutter  justify-center" id="page-login">
    <!-- <div class="login-support-wrap">
        <form style="padding:0px;" @submit.prevent="retrunFalse">
            <h4>Cancel Plan</h4>
            <div class="login-inputs">

                <div style="color:#fff">
                    Are you sure want to cancel the plan?
                    Please note next there will no refund and the current plan will continue till end of the plan.

                </div>

                <div class=" cancel_actions">
                    <input value="Cancel" type="button" class="secondary_btn" @click="discardPlanchange()" />

                    <input value="Continue" type="submit" :disabled="signuphit" class="primary_btn" @click="cancelPlan()" />

                </div>
            </div>

        </form>
    </div> -->


    <div class="success_dialogue border-0">
        <form style="padding:0px;" @submit.prevent="retrunFalse">
            <div class="success_dialogue_title">
                <h4>Cancel Plan</h4>
                <!-- <v-btn v-if="closebutton" color="primary" text @click="closePopup()" class="close-btn close-btn2">
                    <v-icon>mdi-close</v-icon>
                </v-btn> -->
            </div>
            <div class="success_dialogue_cnt">
                <p>Sorry that you are opting to cancel the plan.</p> <p>
Please note that there won't be any refund. However, you will have access to the plan you bought till it is time for plan renewal. 
Are you sure you want to cancel the plan?<br/>
                  
                </p>
                <div class=" cancel_actions">
                    <input value="Cancel" type="button" class="secondary_btn" @click="discardPlanchange()" />
                    <input value="Continue" type="submit" :disabled="signuphit" class="primary_btn" @click="cancelPlan()" />
                </div>
            </div>
        </form>
    </div>






</div>
</template>

<script>
import moment from "moment";

//import VuePhoneNumberInput from 'vue-phone-number-input';
export default {

    props: {
        plan: null,
    },
    components: {
        //     VuePhoneNumberInput
    },
    mounted() {

    },
    computed: {
        checkNewUser() {
            if ((this.newUser['firstName'] == '' || this.newUser['firstName'] == null || this.newUser['firstName'] == undefined) ||
                (this.newUser['middleName'] == '' || this.newUser['middleName'] == null || this.newUser['middleName'] == undefined) ||
                (this.newUser['lastName'] == '' || this.newUser['lastName'] == null || this.newUser['lastName'] == undefined)
            ) {
                return true;

            } else {
                return false;

            }

        }
    },
    data() {
        return {
            signuphit: false,
            test: true,
            user: {
                email: "",
                password: ""
            },
            newUser: {
                firstName: "",
                middleName: "",
                lastName: "",
                name: "",
                email: "",
                password: "",
                cnfrmPassword: "",
                phoneCode: "",
                phoneNo: "",
                roleId: 4,
                passType: "",
                athletes: [],
                athletescount: 0,
                paymentAmt: 0,
                frequency: null
            },
            checkbox_remember_me: false,
            formmessage: {
                msg: ""
            },
            formerrors: {
                msg: ""
            }
        };
    },
    methods: {
        retrunFalse() {

            return false;
        },
        discardPlanchange() {
            this.$emit('closeCancelcard', true)
        },
        cancelPlan() {
            var _self= this;
            var user = this.$store.state.user;

            var payLoad = {
                subscriber: {
                    name: user.name,
                    email: user.email,
                    phone: user.phoneNo,
                    phoneCode: "+1"
                }
            };
            this.$store.dispatch("subscription/getSelectedPlan", payLoad).then((oldPlan) => {
                var spayLoad = {
                    planId: oldPlan[0]._id,
                    subscriber: {
                        name: user.name,
                        email: user.email,
                        phone: user.phoneNo,
                        phoneCode: "+1"
                    },
                    today: _self.$moment(new Date()).format("YYYY-MM-DD"),
                    timezone: _self.$moment.tz.guess(),
                    browserTS: _self.$moment(new Date())
                };

                this.$store.dispatch("subscription/cancelPlan", spayLoad).then((oldPlan) => {

                    


            this.$emit('completeCancelcard', true)

                    const unsubobj = {
                        email: this.$store.state.user.email,
                        name: this.$store.state.user.name,
                        listId: 36007
                    };
                    const subobj = {
                        email: this.$store.state.user.email,
                        name: this.$store.state.user.name,
                        listId: 36005
                    };
                    this.$store.dispatch("unsubscribetoemaillist", unsubobj).then(unsubobj => {})

                    this.$store.dispatch("subscribetoemaillist", subobj).then(response => {})

                })
            })

        }
    }
};
</script>

<style scoped>
.body {
    overflow: hidden;
}
</style>
