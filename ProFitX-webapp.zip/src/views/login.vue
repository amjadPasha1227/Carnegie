<template>
  <div
    class="
      flex
      w-full
      bg-img
      vx-row
      justify-center
      login-wrapper
      page-login-wrapper
    "
    id="page-login"
  >
    <div class="login-support-wrap">
      <!-- <div class="login-logo-img">
            <img src="@//assets/images/logo.svg" alt="ProFitX" class="login-logo-img">

        </div> -->
      <template v-if="lastLogInClosed">
        <h2>Sign In</h2>
      </template>
      <template v-else>
        <h2>Security Alert</h2>
      </template>

      <form style="padding: 0px" @submit.prevent="printToConsole">
        <div
          class="text-danger text-sm formerrors"
          v-if="formerrors && formerrors.msg != ''"
        >
          {{ formerrors.msg }}
        </div>
        <div
          class="text-success text-sm formerrors"
          v-if="formmessage && formmessage.msg != ''"
        >
          {{ formmessage.msg }}
        </div>

        <div class="login-inputs">
          <template v-if="lastLogInClosed">
            <div class="inputbix name">
              <v-text-field
                @click="rememberMe()"
                data-vv-as="Email"
                name="email"
                class="text_field"
                placeholder="Email"
                v-validate="'required|email'"
                v-model="user.email"
                single-line
                outlined
              ></v-text-field>
              <span class="error-text" v-show="errors.has('email')">{{
                errors.first("email")
              }}</span>
            </div>
            <div class="inputbix password">
              <v-text-field
                name="password"
                @click="rememberMe()"
                type="password"
                class="text_field"
                placeholder="Password"
                v-validate="'required'"
                v-model="user.password"
                single-line
                outlined
              ></v-text-field>
              <span class="error-text" v-show="errors.has('password')">{{
                errors.first("password")
              }}</span>
              <em class="eye"><img src="@//assets/images/view.svg" /></em>
            </div>

            <div class="input_actions">
              <v-checkbox
                v-model="checkbox_remember_me"
                :label="`Remember Me`"
              ></v-checkbox>
              <a @click="showFP()">Forgot Your Password?</a>
            </div>
          </template>
          <template v-else>
            <template v-if="!setVerificationCode">
              <div class="alertnotify">
                We have detected that the account being used is on another
                device/location. As per ProFitX Policy, subscriptions are for
                personal use and can only be used by one user. If you are a
                different person, we urge you not to proceed to prevent a
                flagging of your account for further verification. <br /><br />
                If you are the same person, you may proceed and follow the
                instructions to authenticate yourself.
              </div>
            </template>
            <template v-else
              ><div>
                <div class="alertnotify">
                  Please input the OTP received to your email.
                </div>
                <div class="inputbix name">
                  <v-text-field
                    name="Verification Code"
                    type="text"
                    class="text_field"
                    placeholder="Verification Code"
                    v-validate="'required'"
                    v-model="user.verifyCode"
                    single-line
                    outlined
                  ></v-text-field>
                  <span
                    class="error-text"
                    v-show="errors.has('Verification Code')"
                    >{{ errors.first("Verification Code") }}</span
                  >
                </div>
              </div>
            </template>
          </template>

          <div class="action_btns d-block">
            <template v-if="lastLogInClosed">
              <input
                type="submit"
                class="primary_btn"
                @click="submitForm()"
                value="Sign In"
              />
            </template>
            <template v-else>
              <template v-if="!setVerificationCode">
                <div class="actionswrapper">
                  <input
                    type="submit"
                    class="primary_btn"
                    @click="verificationcode()"
                    value="Continue"
                  />
                  <input
                    type="submit"
                    class="secondary_btn"
                    @click="initUser()"
                    value="Cancel"
                  />
                </div>
              </template>
              <template v-else>
                <div class="actionswrapper">
                  <input
                    type="submit"
                    class="primary_btn"
                    @click="submitForm()"
                    value="Verify"
                  />
                  <input
                    type="submit"
                    class="secondary_btn"
                    @click="verificationcode(true)"
                    value="Resend"
                  />
                </div>
              </template>
            </template>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>


<style scoped>
.theme--dark.v-overlay {
  z-index: 1000;
}
</style>
<script>
import _ from "lodash";

import Vue from "vue";
import VueCryptojs from "vue-cryptojs";

Vue.use(VueCryptojs);
import VueCookies from "vue-cookies";
Vue.use(VueCookies);

export default {
  data() {
    return {
      lastLogInClosed: true,
      setVerificationCode: false,
      setVerificationCodeLoading: false,
      test: true,
      user: {
        email: "",
        password: "",
        verifyCode: "",
      },
      checkbox_remember_me: false,
      formmessage: {
        msg: "",
      },
      formerrors: {
        msg: "",
      },
    };
  },
  methods: {
    rememberMe(email = "", pwd = "") {
      const timestamp = new Date().getTime(); // current time
      const exp = timestamp + 60 * 60 * 24 * 1000 * 7;

      if (email != "" && pwd != "") {
        //remember_me
        this.$cookies.set("remember_me", true, exp);
        const encryptedEmailText = this.CryptoJS.AES.encrypt(
          email,
          "FV$HSEDEEPV@JUG"
        ).toString();
        const encryptedPwdText = this.CryptoJS.AES.encrypt(
          pwd,
          "FV$HSEDEEPV@JUG"
        ).toString();

        this.$cookies.set("server_Js", encryptedPwdText, exp);
        this.$cookies.set("email", encryptedEmailText, exp);
      } else {
        this.$cookies.remove("remember_me");
        this.$cookies.remove("email");
        this.$cookies.remove("server_Js");
      }

      //let email =this.CryptoJS.AES.decrypt(this.$cookies.get("email"),"FV$HSEDEEPV@JUG" ).toString(this.CryptoJS.enc.Utf8);
    },
    setRemember() {
      var email = this.CryptoJS.AES.decrypt(
        this.$cookies.get("email"),
        "FV$HSEDEEPV@JUG"
      ).toString(this.CryptoJS.enc.Utf8);
      var password = this.CryptoJS.AES.decrypt(
        this.$cookies.get("server_Js"),
        "FV$HSEDEEPV@JUG"
      ).toString(this.CryptoJS.enc.Utf8);
      if (email) {
        this.user.email = email;
      }
      if (password) {
        this.user.password = password;
      }
      if (
        this.$cookies.get("remember_me") ||
        this.$cookies.get("remember_me") == "true"
      ) {
        this.checkbox_remember_me = true;
      }
    },

    printToConsole() {
      return false;
    },
    showFP() {
      this.$emit("showFP", true);
    },
    showSignup() {
      this.$emit("showSignup", true);
    },
    clearfields() {
      Object.assign(this.user, {
        email: "",
        password: "",
      });
    },
    requestAgain() {
      this.$vs.loading();

      const obj = {
        apiKey: "FV$HSE@JUGUUGU$J5L@HE",
        tenantId: "5db7d79d6032453bd060ed9c",
        email: this.user.email,
      };

      Object.assign(this.formerrors, {
        msg: "",
      });
      Object.assign(this.formmessage, {
        msg: "",
      });
      this.$store
        .dispatch("petitioner/requestactivationEmail", obj)
        .then((response) => {
          this.$vs.loading.close();
          Object.assign(this.formerrors, {
            msg: "",
          });
          Object.assign(this.formmessage, {
            msg: "",
          });
          if (response.error) {
            Object.assign(this.formerrors, {
              msg: response.error.message,
            });
          } else {
            Object.assign(this.formmessage, {
              msg: response.data.result.message,
            });
          }
        })
        .catch(() => {});
    },
    initUser() {
      this.$emit("securityalert", true);

      this.lastLogInClosed = true;
      this.setVerificationCode = false;
      (this.setVerificationCodeLoading = false),
        (this.user = {
          email: "",
          password: "",
          verifyCode: "",
        });
    },
    verificationcode(showMessage = false) {
      (this.formmessage = {
        msg: "",
      }),
        (this.formerrors = {
          msg: "",
        });
      this.setVerificationCodeLoading = false;
      //alert("hsdkfhs fshf");
      this.$store
        .dispatch("setVerificationcode", this.user)
        .then((res) => {
          this.lastLogInClosed = false;
          this.setVerificationCode = true;
          this.setVerificationCodeLoading = false;
          if (showMessage) {
            this.formmessage.msg = res.data.message;
          }
        })
        .catch((err) => {
          this.setVerificationCodeLoading = false;
          if (showMessage) {
            this.formerrors.msg = err.message;
          }
        });
    },
    submitForm() {
      var _self = this;
      Object.assign(this.formerrors, {
        msg: "",
      });
      Object.assign(this.formmessage, {
        msg: "",
      });
      this.$validator.validateAll().then((result) => {
        if (result) {
          const obj = {
            email: this.user.email,
            password: this.user.password,
            verifyCode: this.user.verifyCode.trim(),
          };
          let eml = "";
          let pwd = "";
          if (this.checkbox_remember_me) {
            eml = this.user.email;
            pwd = this.user.password;
          }
          this.rememberMe(eml, pwd);
          this.$store
            .dispatch("login", obj)
            .then((response) => {
              if (response.error) {
                Object.assign(this.formerrors, {
                  msg: response.error.message,
                });
              } else {
                _self.$router.push("/");
              }
            })
            .catch(() => {});
        }
      });
    },
  },
  mounted() {
    this.setRemember();
  },
};
</script>

<style scoped>
.body {
  overflow: hidden;
}
</style>
