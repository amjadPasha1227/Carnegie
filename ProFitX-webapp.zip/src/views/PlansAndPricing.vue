<template>
  <div>


    <plans-list ref="planlist" :shwologin="shwologin" />
    <section class="plans_comparison plans_comparisonv2">
      <div class="container">
        <div class="row">
          <div class="comparison_cnt">
            <h3 class="subtitle" data-aos="fade-up">Comparison</h3>
            <h5 class="tag_line" data-aos="fade-up">
              Human Performance Intelligence, custom-made & calibrated to the
              finest detail built for everyone in the sports ecosystem at
              critical junctures of the year. The Financial and Performance
              packages are designed to track and evaluate<br />
              your favorite athletes and teams during the Season and Off-season.
            </h5>
            <ul data-aos="fade-up">
              <li>
                <h6>Features</h6>
                <h3>League Pass</h3>
                <h3>In-Season</h3>
                <h3>Off-Season</h3>
              </li>
              <li>
                <label>Star/System Reliance</label>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>
              </li>
              <li>
                <label>Player Roles</label>
                <span><img src="@/assets/images/check.png" /></span>

                <span><img src="@/assets/images/check.png" /></span>
                <span></span>
              </li>
              <li>
                <label>Career Outlook</label>
                <span><img src="@/assets/images/check.png" /></span>

                <span></span>
                <span><img src="@/assets/images/check.png" /></span>
              </li>
              <li>
                <label>Opportunity</label>
                <span><img src="@/assets/images/check.png" /></span>

                <span><img src="@/assets/images/check.png" /></span>
                <span></span>
              </li>
              <li>
                <label>Team Fit</label>
                <span><img src="@/assets/images/check.png" /></span>

                <span></span>
                <span><img src="@/assets/images/check.png" /></span>
              </li>
              <li>
                <label>Athlete Performance</label>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>
                <span></span>
              </li>
              <li>
                <label>Trade Value</label>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>
              </li>
              <li>
                <label>Player Synergy</label>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>
              </li>
              <li>
                <label>Attributes</label>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>

                <span></span>
              </li>
              <li>
                <label>Tendencies</label>
                <span><img src="@/assets/images/check.png" /></span>
                <span></span>

                <span><img src="@/assets/images/check.png" /></span>
              </li>
              <li>
                <label>Injury Risk</label>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>

                <span></span>
              </li>
              <li>
                <label>Load Management</label>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>
                <span></span>
              </li>
              <li>
                <label>Player Contracts</label>
                <span><img src="@/assets/images/check.png" /></span>
                <span></span>

                <span><img src="@/assets/images/check.png" /></span>
              </li>
              <li>
                <label>Financial Impact</label>
                <span><img src="@/assets/images/check.png" /></span>
                <span></span>

                <span><img src="@/assets/images/check.png" /></span>
              </li>
              <li>
                <label>Athlete Impact</label>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>

                <span></span>
              </li>
              <li>
                <label>Position Versatility</label>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>

                <span></span>
              </li>
              <li>
                <label>ProXtial</label>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>
                <span><img src="@/assets/images/check.png" /></span>
              </li>
            </ul>
          </div>
        </div>
      </div>

    </section>

    <v-dialog
      v-if="signuptoApp"
      v-model="signuptoApp"
      max-width="400"
      fullscreen
      persistent
      
    >
      <div class="dialog_body signup signup_body">
        <v-btn
          color="primary"
          text
          @click="closeSignup()"
          class="close-btn close-btn2"
        >
          <v-icon>mdi-close</v-icon>
        </v-btn>
        <signup-temp :loadedFromPopup="true"  @updateNewUser="updateNewUser"  @showLogin="loadlogin()"/>
      </div>
    </v-dialog>
    <v-dialog v-if="showPlans" v-model="showPlans" fullscreen persistent>
      <div class="dialog_body signup plans_modal_body">
        <v-btn
          color="primary"
          text
          @click="skipPaymentProcess()"
          class="close-btn close-btn2"
        >
          <v-icon>mdi-close</v-icon>
        </v-btn>




        <plans-list
          ref="planlist_popup"
          @skipPaymentProcess="skipPaymentProcess"
          @onPlanSelect="onPlanSelect"
          :shwologin="false"
          :loadedFromPopup="true"
          @continueTosubscribe="continueTosubscribe"
          :userData="newUser"
          @closePlanPopup="closePlanPopup"
        />
      </div>
    </v-dialog>

    <!----- openSetPassword ---->

   
  </div>
</template>

<style lang="scss">
</style>

<script>
import plansList from "@/views/plans.vue";
import signupTemp from "@/views/sign-up.vue";
import setPasswordPopup from "@/views/setPasswordPopup.vue";
import _ from "lodash";
export default {
  
  data() {
    return {

       
        setPasswordhit:false,
      openSetPassword: false,
      showPlans: false,
      websiteurl: null,
      shwologin: false,
      loggedinview: false,
      signuptoApp: false,
      plan: null,
      newUser: {

         "pin":'', 
         "action": "set-password",
         'newPassword': "",
        'confirmPassword': "",
        "userId":'',
        "notUsingEmailLink": true, 

        acceptedTerms: false,
        activateUser: true,
        firstName: "",
        middleName: "",
        lastName: "",
        name: "",
        email: "",
        phoneCode: "",
        phoneNo: "",
        roleId: 4,
        passType: "",
        athletes: [],
        athletescount: 0,
        paymentAmt: 0,
        frequency: null,
      },
      formmessage: {
        msg: "",
      },
      formerrors: {
                msg: ""
            },
      selectedPlans:{
        probabilityPlan:null ,plan:null
      }      
    };
  },
  components: {
    plansList,
    signupTemp,
   // setPasswordPopup,
  },
  mounted() {
    this.websiteurl = process.env.VUE_APP_WEBSITE_URL;
    //if user logged in
    if (
      this.$store.state &&
      this.$store.state.user &&
      this.$store.state.user._id
    ) {
      var user = this.$store.state.user;
      this.loggedinview = true;
    }
  },
  computed: {},
  methods: {
      
      closePlanPopup(){
        this.showPlans =false

      },
    login(){
      Object.assign(this.formerrors, { msg: '' });
      let self = this;
          const obj = {
            email: this.newUser.email,
            password: this.newUser.newPassword,
          };
        this.$store
            .dispatch("login", obj)
            .then((response) => {
              if (response.error) {
                Object.assign(this.formerrors, {
                  msg: response.error.message,
                });
              } else {
                this.$refs["planlist"].showMessages(1);
              
               setTimeout(()=>{ 
                 
                 self.showPlans = false; 
                 self.$router.push("/plan");
               
               } ,10)
                
              }
            })
            .catch((err) => {
             
                 Object.assign(this.formerrors, { msg: err });
            });
    },
    updateNewUser(user) {
      this.newUser = user;
      this.signuptoApp = false;
      this.showPlans = true;
      this.setPasswordhit =false;
      this.openSetPassword =false;
      setTimeout(()=>{
         this.$refs["planlist"].updateNewUserPlansAndPricing(this.newUser);
      } ,5)
      
    },

    onPlanSelect(plan) {
      this.selectedPlans =plan;
      if(_.has(this.selectedPlans ,"plan")){
         this.plan = this.selectedPlans['plan'];

      }
     

      if (this.plan) {
        this.newUser.passType = this.plan.uniqueId;
        this.newUser.athletescount = this.plan.criteria[0].qty;
        this.newUser.frequency = this.plan.frequencyDetails.__id;
        this.newUser.paymentAmt = this.plan.criteria[0].amount;
      }
      this.setPasswordhit =false;
      //alert(JSON.stringify(this.selectedPlans))
      
    },
    continueTosubscribe(){
        if((_.has(this.newUser ,"userId") && this.newUser['userId'] ) && (_.has(this.newUser ,"pin") && this.newUser['pin'] )){
          this.setPasswordhit =false;
          this.openSetPassword =false;
           this.finalSubmit()

        }else{
        
          this.loadSignUp();

        }
        
    },
    setPasswordOpen(){
        this.setPasswordhit =false;
        this.openSetPassword =true;

    },

    finalSubmit() {
      let self =this;
          if (this.plan) {
            this.newUser.passType = this.plan.uniqueId;
            this.newUser.athletescount = this.plan.criteria[0].qty;
            this.newUser.frequency = this.plan.frequencyDetails.__id;
            this.newUser.paymentAmt = this.plan.criteria[0].amount;
          }
          const obj = {
            email: this.newUser.email,
            password: this.newUser.password,
          };
          const subobj = {
            email: this.newUser.email,
            name: this.newUser.firstName,
            listId: 36008,
          };
         // this.$store.dispatch("subscribetoemaillist", subobj).then((response) => {});

          var subscribepayLoad = {
            selPlanIds: [],
            plans: [],
            source: null,
            serviceTypeId: 1,
            methodTypeId: 1,
            newSource: true,
            subscriber: {
              name: self.newUser.firstName,
              email: self.newUser.email,
              phone: self.newUser.phoneNo,
              phoneCode: "+1",
            },
            today: self.$moment(new Date()).format("YYYY-MM-DD"),
            timezone: self.$moment.tz.guess(),
            browserTS: self.$moment(new Date()),
          };

          subscribepayLoad.plans.push({
            planId: self.plan._id,
            criteria: self.plan.criteria,
            frequencyDays: 0,
          });


          if(_.has(self.selectedPlans ,"probabilityPlan")){
            let probabilityPlan = self.selectedPlans["probabilityPlan"];
            if(_.has(probabilityPlan ,'_id') && _.has(probabilityPlan ,'criteria')  ){

                       
                subscribepayLoad.plans.push({
                planId: probabilityPlan._id,
                criteria: probabilityPlan.criteria,
                frequencyDays: 0,
              });
          }

          }

          this.$store
            .dispatch("subscription/subscribe", subscribepayLoad)
            .then((res) => {
                this.setPasswordOpen();

            }).catch((err) => {
              console.log(err);
               this.$refs["planlist"].showMessages(4,err);
               setTimeout(()=>{  this.showPlans = false;   } ,10)
            })

          
      
    },

    skipPaymentProcess() {
     
      this.$refs["planlist"].showMessages(1);
      setTimeout(()=>{  this.showPlans = false;   } ,10)
     
    },
    loadForm() {
      this.$refs["planlist"].enquiryApp = true;
      this.$refs["planlist"].et = 1;

      this.$refs["planlist"].enquirytype = "Request For Athlete Pass";
    },
    loadlogin() {
     this.signuptoApp =false;
    this.showPlans =false;
      this.$refs["planlist"].logintoApp = true;
    },
    loadSignUp() {
      //this.showPlans =true;
      this.signuptoApp = true;
      
      this.$refs["planlist"].resetSelectedPlans();
      

      // this.$refs["planlist"].signuptoApp = true;
    },

     closeSignup() {
      //this.showPlans =true;
      this.signuptoApp = false;
      
      this.$refs["planlist"].resetSelectedPlans();
      

      // this.$refs["planlist"].signuptoApp = true;
    },
  },
};
</script>
