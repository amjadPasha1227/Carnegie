<template>
<div class="">
    <div v-if="player" class="trade_roles">
        <h6>PLAYER ROLES </h6>
        <ul v-if="getRoles">
            <li style="background:#283A6D" :key="roleo" v-for="roleo in  getRoles.o.slice(0, 1)">
                <span>{{roleo.v | percentazec  }}</span>
                <p>{{roleo.k}}</p>
            </li>

            <li style="background:#283A6D" :key="roleo" v-for="roleo in  getRoles.d.slice(0, 1)">
                <span>{{roleo.v | percentazec  }}</span>
                <p>{{roleo.k}}</p>
            </li>

        </ul>
    </div>
    <div v-if="player" class="trade_roles">
        <h6>PLAYER ATTRIBUTES</h6>
        <ul v-if="getAttributes">
            <li style="background:#283A6D" :key="roleo" v-for="roleo in  getAttributes.o.slice(0, 1)">
                <span>{{roleo.v | percentazec  }}</span>
                <p>{{roleo.k}}</p>
            </li>

            <li style="background:#283A6D" :key="roleo" v-for="roleo in  getAttributes.d.slice(0, 1)">
                <span>{{roleo.v | percentazec  }}</span>
                <p>{{roleo.k}}</p>
            </li>

        </ul>
    </div>

</div>
</template>

<script>
export default {
    props: ['player'],
    computed: {
        getAttributes() {
            let returnvalues = [];
            var filter = this.player.ATTR;
            if (filter != undefined) {
                returnvalues["o"] = [{
                        k: 'Offensive Impact',
                        v: filter["Offensive Impact"] * 100
                    },
                    {
                        k: 'Interior Scoring',
                        v: filter["Interior Scoring"] * 100
                    },
                    {
                        k: 'Attacking the Basket',
                        v: filter["Attacking the Basket"] * 100
                    },
                    {
                        k: 'Perimeter Scoring ',
                        v: filter["Perimeter Scoring"] * 100
                    }
                ]
                returnvalues["d"] = [{
                        k: 'Defensive IQ',
                        v: filter["Defensive IQ"] * 100
                    },
                    {
                        k: 'Interior Defense',
                        v: filter["Interior Defense"] * 100
                    },
                    {
                        k: 'Perimeter Defense',
                        v: filter["Perimeter Defense"] * 100
                    },
                    {
                        k: 'Defensive Impact',
                        v: filter["Defensive Impact"] * 100
                    }

                ]

                returnvalues["d"] = this.lodash.orderBy(returnvalues["d"], ['v'], ['desc']);
                returnvalues["o"] = this.lodash.orderBy(returnvalues["o"], ['v'], ['desc']);

            }
            return returnvalues;
        },

        getRoles() {
            var filter = this.player.ROLES;
            let returnvalues = [];
            if (filter != undefined) {
                returnvalues["o"] = [{
                        k: 'Sharpshooter',
                        v: filter["Sharpshooter"] * 100
                    },
                    {
                        k: 'Interior Finisher',
                        v: filter["Interior Finisher"] * 100
                    },
                    {
                        k: 'High Volume Scorer',
                        v: filter["High Volume Scorer"] * 100
                    },
                    {
                        k: 'Playmaker',
                        v: filter["Playmaker"] * 100
                    }
                ]
                returnvalues["d"] = [{
                        k: 'Versatile Defender',
                        v: filter["Versatile Defender"] * 100
                    },
                    {
                        k: 'Rim Protector',
                        v: filter["Rim Protector"] * 100
                    },
                    {
                        k: 'Rebounding Specialist',
                        v: filter["Rebounding Specialist"] * 100
                    },
                    {
                        k: 'Turnover Specialist',
                        v: filter["Turnover Specialist"] * 100
                    },
                    {
                        k: 'High Motor',
                        v: filter["High Motor"] * 100
                    }

                ]

                returnvalues["d"] = this.lodash.orderBy(returnvalues["d"], ['v'], ['desc']);
                returnvalues["o"] = this.lodash.orderBy(returnvalues["o"], ['v'], ['desc']);

            }
            return returnvalues;
        },

    },
    watch: {

        player: function (newVal, oldVal) {

        }

    },
    mounted() {

    },
    methods: {

    }
}
</script>
