<template>
<div style="cursor:pointer;">
    <v-icon v-if="loaded && !currenteam" @click="addFav(player)">mdi-star-outline</v-icon>
    <v-icon v-if="loaded && currenteam" @click="removeFav(player)">mdi-star</v-icon>

</div>
</template>

<script>
export default {
    props: {
        player: {},
        favslist: null,
    },
    mounted() {
        var self = this;
        this.currenteam = self._.find(this.favslist, function (obj) {
            return obj.playerName === self.player["PLAYER_NAME"];
        });

        this.loaded = true;

    },
    data: () => ({
        currenteam: null,
        loaded: false
    }),
    methods: {
        addFav(obj) {
            var userid = this.$store.state.user._id;
            const obja = {
                name: this.player["PLAYER_NAME"],
                userId: userid
            };
            this.$store
                .dispatch("addTofav", obja)
                .then(response => {
                    this.currenteam = response;
                    this.$emit("getPlayers");
                })

        },
        removeFav(obj) {
                    this.currenteam = null;

            var userid = this.$store.state.user._id;
            const obja = {
                name: this.player["PLAYER_NAME"],
                userId: userid
            };
            this.$store
                .dispatch("removeFromfav", obja)
                .then(response => {
                    this.$emit("getPlayers");

                })

        }
    }
}
</script>
