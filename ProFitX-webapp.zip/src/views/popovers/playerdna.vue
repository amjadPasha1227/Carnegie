<template>
<div>
    <div class="player_dna_details_wrap">
        <div class="player_dna_details">
            <div class="player_dna_list_wrap">
                <label>Player Roles</label>
                <div class="player_dna_list">
                    <div class="player_dna_block red_block">
                        <h6>Offense</h6>
                        <ul class="dnalist">
                            <li :key="roleo" v-for="roleo in  roles.o.slice(0, 3)">
                                {{roleo.k}} - {{roleo.v | percentazec  }}
                            </li>

                        </ul>
                    </div>
                    <div class="player_dna_block green_block">
                        <h6>Defense</h6>
                        <ul class="dnalist" >
                            <li :key="rolef" v-for="rolef in  roles.d.slice(0, 3)">
                                {{rolef.k}} - {{rolef.v  | percentazec  }}
                            </li>

                        </ul>

                    </div>
                </div>
            </div>
    
        </div>
    </div>
</div>
</template>

<script>
export default {
    props: {
   roles:{}
    }
}
</script>
