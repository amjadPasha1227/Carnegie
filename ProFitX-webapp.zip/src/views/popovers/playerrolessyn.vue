<template>
<div class="role_content pad0">

    <ul class="dnalist">

        <li v-for="(role, index) in offensivesort.slice(0,1)" :key="index">
            <span v-bind:style="{ borderColor: colors[index + 6] }">{{
                    role.v | percentazec
                  }}</span>
            <div class="role_status" v-bind:style="{
                      background: colors[index],
                      width: role.v + '%',
                    }"></div>
            <label>{{ role.k }}</label>
        </li>

        <li v-for="(role, index) in defensivesort.slice(0,1)" :key="100000+index">
            <span v-bind:style="{ borderColor: colors[index + 6] }">{{
                    role.v | percentazec
                  }}</span>
            <div class="role_status" v-bind:style="{
                      background: colors[index + 6],
                      width: role.v + '%',
                    }"></div>
            <label>{{ role.k }}</label>
        </li>

    </ul>

</div>
</template>

<script>
export default {
    data: () => ({
        offensive: [
            "Sharpshooter",
            "Slasher",
            "Interior Finisher",
            "High Volume Scorer",
            "Playmaker",
        ],
        defensive: [
            "Versatile Defender",
            "Rim Protector",
            "Rebounding Specialist",
            "Turnover Specialist",
            "High Motor",
        ],
        offensivesort: [],
        colors: [],
        defensivesort: [],
    }),
    props: {
        roles: {},
        selectedrole: null,
    },
    mounted() {
        this.colors = this.chartcolors;

        var _offensive = [];

        this.offensive.forEach(element => {

            if (this.selectedrole && this.selectedrole != null) {

                if (this.selectedrole == element) {
                    _offensive.push({
                        k: element,
                        v: this.roles[element] * 100
                    })

                }

            } else {

                _offensive.push({
                    k: element,
                    v: this.roles[element] * 100
                })

            }

        });

        this.offensivesort = this.lodash.orderBy(_offensive, "v",["desc"])

        var _defensive = [];

        this.defensive.forEach(element => {

            if (this.selectedrole && this.selectedrole != null) {

                if (this.selectedrole == element) {
                    _defensive.push({
                        k: element,
                        v: this.roles[element] * 100
                    })

                }

            } else {

                _defensive.push({
                    k: element,
                    v: this.roles[element] * 100
                })

            }

        });

        this.defensivesort = this.lodash.orderBy(_defensive, "v",["desc"])

    }
}
</script>
