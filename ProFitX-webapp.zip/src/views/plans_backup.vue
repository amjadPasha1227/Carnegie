<template>
<section class="pricing_banner">
    <div class="container">
        <h3 class="subtitle" v-if="!upgradeplan" data-aos="fade-up" data-aos-delay="500">Plans and Pricing</h3>
        <h5 class="tag_line" v-if="!upgradeplan" data-aos="fade-up" data-aos-delay="500">Powerful technology. Simple Pricing. Everything you need to see the evolution of the athlete with front office optics.</h5>
        <div class="pricing_plans">
            <div class="pricing_title">
                <h4 data-aos="fade-up" data-aos-delay="500">Athlete Pass</h4>

                 <div class="switch_wrap" data-aos="fade-up" data-aos-delay="500">
                    <span v-bind:class="{ activefre: !freq }">In-Season</span>
                    <label class="switch">
                        <input @change="changeplan(selectedplan)" type="checkbox" v-model="freq" id="togBtn">
                        <div class="slider round"></div>
                    </label>
                    <em v-bind:class="{ activefre: freq }">Off-Season</em>
                </div>

                <div class="offer_label"  data-aos="fade-left" data-aos-delay="1000">
                    <p></p>
                </div>
            </div>

            <v-container>
                <v-row class="mobile_row" v-if="!freq">
                    <v-col class="padtb0 plan-list">
                        <div class="plans_block plan1" v-on:click="changeplan(1)" v-bind:class="{ active: selectedplan==1 }" data-aos="fade-up" data-aos-delay="800">
                            <div class="plans_block_cnt ">
                                <label>15 Athletes</label>
                                <h5>${{p1amount}}
                                </h5>
                                <!-- <button class="subscribe_btn">Subscribe</button> -->
                                <button class="subscribe_btn" id="subscribe_btn1">
                                    <span>{{seasontype}} </span>
                                </button>
                                <ul class="slected_options">
                                    <li>In-Season</li>
                                    <li>Off-Season</li>
                                </ul>
                            </div>
                        </div>
                    </v-col>
                    <v-col class="padtb0 plan-list">
                        <div class="plans_block plan2" v-on:click="changeplan(2)" v-bind:class="{ active: selectedplan==2 }" data-aos="fade-up" data-aos-delay="800">
                            <div class="plans_block_cnt">
                                <label>20 Athletes</label>
                                <h5>${{p2amount}}</h5>
                                <button class="subscribe_btn" id="subscribe_btn2">
                                                                   <span>{{seasontype}} </span>

                                    </button>
                                <ul class="slected_options">
                                    <li>In-Season</li>
                                    <li>Off-Season</li>
                                </ul>
                            </div>
                        </div>
                    </v-col>
                    <v-col class="padtb0 plan-list">
                        <div class="plans_block plan3" v-on:click="changeplan(3)" v-bind:class="{ active: selectedplan==3 }" data-aos="fade-up" data-aos-delay="800">
                            <div class="plans_block_cnt">
                                <label>25 Athletes</label>
                                <h5>${{p3amount}}</h5>
                                <button class="subscribe_btn" id="subscribe_btn3">
                                                            <span>{{seasontype}} </span>

                                    </button>
                                <ul class="slected_options">
                                    <li>In-Season</li>
                                    <li>Off-Season</li>
                                </ul>
                            </div>
                        </div>
                    </v-col>

                </v-row>

                <v-row style="margin-top: -12px;" v-bind:class="{ inseasonsbox: freq}" class="mob_plan_actions">

                    <v-col>

                        <div class="plan_actions " v-bind:class="{ action3: selectedplan==3, action2: selectedplan==2, action1: selectedplan==1 }" data-aos="fade-up">
                            
                            
                            
                            <ul v-if="!financial">
                                <li v-if="financial">
                                    <div class="checkbox-group" >
                                        <input v-bind:disabled="true" type="checkbox"  @change="changeplan(selectedplan)" v-model="financial" id="inseason">
                                        <label   for="inseason">Financial </label>
                                    </div>
                                </li>
                                <li >

                            <span v-if="!freq && selectedplan == 1" class="swapino">Select 15 Athletes for $25 and receive up to 60 athlete swaps during the season. In-Season pack will expire by the end of July 2022. </span>
                             <span v-if="!freq && selectedplan == 2" class="swapino">Select 20 athletes for $35 and receive up to 80 athlete swaps during the season. In-Season pack will expire by the end of July 2022.</span>
                            <span v-if="!freq && selectedplan == 3" class="swapino">Select 25 athletes for $40 and receive up to 100 athlete swaps during the season. In-Season pack will expire by the end of July 2022.</span>
                            <span style="margin-top:-25px;" v-if="freq" class="swapino">* Off-Season packs will be available for subscription when the season ends in July 2022.</span>

                                    <div class="checkbox-group "   style="visibility:hidden;height:0px;padding:0px;">
                                        <input v-bind:disabled="freq" type="checkbox" @change="changeplan(selectedplan)" v-model="performance" id="offseason">
                                        <label v-bind:class="{ disabled: freq}" class="Off_Season" for="offseason">Performance</label>
                                    </div>
                                </li>
                                <li  v-if="!freq && cuser==null"> 
                                    <button v-on:click="proceedtocard()" class="secondary_btn" v-bind:disabled="!offseason && !inseason" id="proceed">Proceed</button>
                                </li>
                                 <li  v-else-if="!freq && !usercurrentPlan && usercurrentPlan.length == 0 && cuser && cuser.email" > 
                                    <router-link  to="plan" ><button class="secondary_btn">Proceed</button></router-link >
                                </li>
                                 <li  v-if="!freq && usercurrentPlan && usercurrentPlan.length > 0 && usercurrentPlan[0].statusId == 2"> 
                                    <button v-on:click="firsttime=false;upgradeplan=true;proceedtocard()" class="secondary_btn"  id="proceed">Proceed</button>

                                 </li>

                            </ul>
                           
                        </div>
                    </v-col>

                </v-row>

                <v-row>

                    <v-col>
                        <div class="league_block" data-aos="fade-up">
                            <div class="league_block_cnt">
                                <h5>League Pass</h5>
                                <p>The League Pass provides full access to our software for the duration of the NBA regular season, playoffs, and off-season. With this option you receive 480+ NBA Athletes and 17 Artificial Intelligence and Time Series Models that help us better understand an athlete’s performance, contractual value, and Team decision making process.</p>
                                <label @click="et=2;enquiryApp =true;enquirytype='Request For League Pass'"><a href="javascript:;" class="primary_btn">Contact Us</a></label>
                                <p>Please inquire further about League Pass pricing, short-term off-season packages, and consulting options.</p>
                            </div>
                        </div>

                    </v-col>

                </v-row>

            </v-container>

            <div class="row">
                <div class="col padtb0">

                </div>
            </div>
        </div>
    </div>
    <v-dialog v-if="logintoApp" v-model="logintoApp" max-width="400" content-class="items_middle" fullscreen persistent>
        <div class="dialog_body signup" v-bind:class="{ expandsignup: loginexpand }">
            <v-btn color="primary" text @click="initUser(); logintoApp = false" class="close-btn close-btn2">
                <v-icon>mdi-close</v-icon>
            </v-btn>
            <login-temp @securityalert="securityalert" @showFP="showFP" @showSignup="proceedtocard" />
        </div>
    </v-dialog>

    <v-dialog v-if="forgotpassword" v-model="forgotpassword" max-width="400" content-class="items_middle" fullscreen persistent>
        <div class="dialog_body">
            <v-btn color="primary" text @click="initUser(); logintoApp = false" class="close-btn close-btn2">
                <v-icon>mdi-close</v-icon>
            </v-btn>
            <forgot-password />
        </div>
    </v-dialog>

    <v-dialog v-if="signuptoApp" v-model="signuptoApp" max-width="400" fullscreen persistent>
        <div class="dialog_body signup signup_body">
            <v-btn color="primary" text @click="securityalert();initUser(); signuptoApp = false" class="close-btn close-btn2">
                <v-icon>mdi-close</v-icon>
            </v-btn>
            <signup-temp @showResult="showResult" @showLogin="logintoApp=true" :plan="finalplan" />
        </div>
    </v-dialog>

    <v-dialog v-if="enquiryApp" v-model="enquiryApp" max-width="400" class="card_dialog" fullscreen persistent>
        <div class="dialog_body signup">
            <v-btn color="primary" text @click="initUser(); enquiryApp = false" class="close-btn close-btn2">
                <v-icon>mdi-close</v-icon>
            </v-btn>
            <enquiryTemp :selectedplan="finalplan" :et="et" :enquirytype="enquirytype" @closeEnquiry="closeEnquiryForm" @showFP="showFP" @showSignup="proceedtocard" />
        </div>
    </v-dialog>

    <success-popup @closePopup="showoverlay=false" :closebutton="closebutton" :showoverlay="showoverlay" :title="messagetitle" :description="messagecontent" />
    <snakebar v-if="snackbar" :snackbar="snackbar" :msg="text" :isError="isError" />

    <v-overlay v-if="showLoading">
        <v-progress-circular indeterminate size="64"></v-progress-circular>
    </v-overlay>

</section>
</template>

<script>
import enquiryTemp from "@/views/enquiry.vue";
import loginTemp from "@/views/login.vue";
import signupTemp from "@/views/sign-up.vue";
import forgotPassword from "@/views/forgotpassword.vue";
import moment from "moment";
import successPopup from "@/views/success.vue";
import snakebar from "@/views/components/snakebar.vue";

export default {
    props: {
        defaultselected: null,
        shwologin: null,
        shwoSignup: null,
        upgradeplan: null,
        firsttime: null
    },
    watch: {
        shwoSignup: function (value) {

            if (value) {
                this.signuptoApp = true
            }

        },
        shwologin: function (value) {

            if (value) {
                this.logintoApp = true
            }

        },

    },
    data() {
        return {
            financial:false,
            performance:true,
            seasontype:null,
            et: null,
            enquirytype: null,
            closebutton: false,
            showLoading: false,
            enquiryApp: false,
            snackbar: false,
            text: null,
            isError: false,
            showoverlay: false,
            messagetitle: null,
            messagecontent: null,
            logintoApp: false,
            forgotpassword: false,
            signuptoApp: false,
            planselected: false,
            selectedplan: 1,
            p1amount: 25,
            p2amount: 35,
            p3amount: 40,
            freq: false,
            inseason: true,
            offseason: false,
            planslist: null,
            finalplan: null,
            loggedinview: false,
            showcardinfo: false,
            userplan: null,
            usercurrentPlan:null,
            cuser:null,
            loginexpand:false
        };
    },
    components: {
        enquiryTemp,
        loginTemp,
        signupTemp,
        forgotPassword,
        successPopup
    },

    computed: {

    },
    methods: {
        securityalert(){
            this.loginexpand = !this.loginexpand;
        },
        closeEnquiryForm(data) {
            this.enquiryApp = data['action'];
        },
        showResult() {
            this.initUser()
            this.showoverlay = true;
            this.messagetitle = "Registered Successfully";
            this.messagecontent = "Registration is successful. Please add your card information.";

        },
        initUser() {
            this.logintoApp = false

            this.forgotpassword = false;
            this.signuptoApp = false;

        },
        showFP() {

            this.forgotpassword = true;

        },
        proceedtocard() {
           
            var self = this;
            this.closebutton = false;
            this.snackbar = false;
            this.text = null;
            if (!this.firsttime && this.upgradeplan) {
                this.showLoading = true;
                var user = this.$store.state.user;

                var payLoad = {
                    oldPlanId: null,
                    newPlanId: null,
                    criteria: null,
                    frequencyDays: 0,
                    "serviceTypeId": 1,
                    "methodTypeId": 1,
                    "newSource": true,
                    subscriber: {
                        name: user.name,
                        email: user.email,
                        phone: user.phoneNo,
                        phoneCode: "+1"
                    },
                           today: self.$moment(new Date()).format("YYYY-MM-DD"),
                    timezone: self.$moment.tz.guess(),
                    browserTS: self.$moment(new Date())
                };

                payLoad.newPlanId = this.finalplan._id;
                payLoad.criteria = this.finalplan.criteria;

                this.$store.dispatch("subscription/getSelectedPlan", payLoad).then((oldPlan) => {
                    payLoad.oldPlanId = oldPlan[0]._id
                    this.$store.dispatch("subscription/upgradeplan", payLoad).then((res) => {

                        var chargepayload = {
                            passType: this.finalplan.uniqueId,
                            athletescount: this.finalplan.criteria[0].qty
                        }
                       this.showLoading = false;
                            this.showoverlay = true;
                            this.messagetitle = "Payment Successfully";
                            this.messagecontent = "Congrats, your plan has been upgraded successfully";
                            this.$emit("closetheplan")

                            setTimeout(function () {

                                self.$router.go('/plan');
                            }, 2000)

                    }).catch((err) => {
                        this.closebutton = true;
                        this.showoverlay = true;
                        this.messagetitle = "Plan Change";
                        this.messagecontent = "Sorry but a plan cannot be downgrade";

                        this.showLoading = false;
                        this.snackbar = true;
                        this.text = err.error_message.message;
                    });
                })

            } else {

                if (this.firsttime) {

                    this.$emit("changetheplan", this.finalplan)

                } else {

                    this.signuptoApp = true;

                }

            }
        },
        changeplan(selectedplan) {
            this.selectedplan = selectedplan;
            var _planid = "OFFSEASON";
            var plan1box;
            var plan2box;
            var plan3box;
          
            if (this.inseason) {
                _planid = "INSEASON"
            }
            if (this.offseason) {
                _planid = "OFFSEASON"
            }
          
            plan1box = _planid + "15";
            plan2box = _planid + "20";
            plan3box = _planid + "25";

            if (this.selectedplan == 1) {
                _planid = _planid + "15"
            }
            if (this.selectedplan == 2) {
                _planid = _planid + "20"
            }
            if (this.selectedplan == 3) {
                _planid = _planid + "25"
            }
             
        
            var selectedItem = this.lodash.find(this.planslist, function (item) {
                return item.uniqueId == _planid
            })
            var plan1boxItem = this.lodash.find(this.planslist, function (item) {
                return item.uniqueId == plan1box
            })
            var plan2boxItem = this.lodash.find(this.planslist, function (item) {
                return item.uniqueId == plan2box
            })
            var plan3boxItem = this.lodash.find(this.planslist, function (item) {
                return item.uniqueId == plan3box
            })

            if (plan1boxItem) {
                this.p1amount = plan1boxItem.criteria[0].amount;
            }
            if (plan2boxItem) {
                this.p2amount = plan2boxItem.criteria[0].amount;
            }
            if (plan3boxItem) {
                this.p3amount = plan3boxItem.criteria[0].amount;
            }
     
            this.finalplan = selectedItem;

        },
        _getplanslist() {
            let payLoad = {
                page: 1,
                perpage: 2500,
                today:this.$moment()
            };
            this.$store.dispatch("subscription/getplans", payLoad).then((res) => {
                this.planslist = res.list;
               this.seasontype= this.planslist[0].description

              

              
                if (this.defaultselected && this.defaultselected.frequencyId == 4) {
                    this.freq = true;
                }
                if (this.defaultselected) {
                    var planuniqueid = this.defaultselected.planDetails.uniqueId;

                    this.offseason = false;
                    this.inseason = false;
                    if (planuniqueid.includes("OFFIN")) {
                        this.offseason = true;
                        this.inseason = true;
                    }
                    if (planuniqueid.includes("IN")) {
                        this.inseason = true;
                    }
                    if (planuniqueid.includes("OFF")) {
                        this.offseason = true;
                    }

                    var _currentcriteria = this.defaultselected.criteria[0].qty;
                    if (_currentcriteria == 15) this.selectedplan = 1;
                    if (_currentcriteria == 20) this.selectedplan = 2;
                    if (_currentcriteria == 25) this.selectedplan = 3;

                    this.changeplan(this.selectedplan);

                } else {

                    this.changeplan(1);

                }

                if (this.$store.state && this.$store.state.user) {
                    var user = this.$store.state.user;
                    this.loggedinview = true;
                    if (user && user.subscription && user.subscription.paymentStatusId == 1) {

                        var selectedItem = this.lodash.find(this.planslist, function (item) {
                            return item.uniqueId == user.subscription.passType
                        })

                        this.userplan = selectedItem;

                        this.showcardinfo = true;

                    }

                }
            });
        }

    },
    mounted() {
        //if user logged in
     this.usercurrentPlan= this.$store.getters['subscription/getSubscriptions'];

        var user = this.$store.state.user;
        if(user.email) this.cuser=user;
        if (this.$route.query && this.$route.query.show && this.$route.query.show == "subscribe" && (user == '' || user == undefined)) {
            this.enquiryApp = true;
            this.et = 1;
            this.enquirytype = 'Request For Athlete Pass'
        }
        if (this.$route.query && this.$route.query.show && this.$route.query.show == "login" && (user == '' || user == undefined)) {
            this.logintoApp = true;
        }
        if (this.$route.query && this.$route.query.show && this.$route.query.show == "signup" && (user == '' || user == undefined)) {
            this.signuptoApp = true;
        }
        // this.logintoApp=true;
        this._getplanslist()
    }
}
</script>
