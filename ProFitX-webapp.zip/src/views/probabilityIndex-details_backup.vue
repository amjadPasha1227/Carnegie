<template>
<div>
    <div class="probability_details">
        <div class="loading-page" v-if="isloading">
            <figure>
                <img src="@/assets/images/loader.gif" />
            </figure>
            Loading
        </div>
        <div class="head_head_sec">

            <div class="head_head_wrap" v-if="gamedata">
                <!-- <router-link 
                    class="return__back"
                    to="/probabilityIndex"
                    >
                    <v-icon>mdi-arrow-left</v-icon>
                    Back
                    </router-link> -->
                <div class="head_head_cnt">
<div class="bgcolors">
<div class="teambg" v-bind:class="{ high: gamedata.home_win_pct*100 > 60, low: gamedata.home_win_pct*100 < 30, medium: (gamedata.home_win_pct*100 > 30 && gamedata.home_win_pct*100 < 60 ) }">

</div>
<div class="teambg" v-bind:class="{ high: gamedata.away_win_pct*100 > 60, low: gamedata.away_win_pct*100 < 30, medium: (gamedata.away_win_pct*100 > 30 && gamedata.away_win_pct*100 < 60 ) }">

</div>
</div>
                    <div class="live_teams">
                        <v-row>
                            <v-col cols="12" lg="3" md="3" sm="3" class="pt-0 pb-0">
                                <div class="team_details home" style="color:#fff">
                                    <figure v-if="gamedata.HomeTeam">
                                        <img :src='gamedata.HomeTeam.logo'>
                                    </figure>
                                    <label>
                                        {{gamedata.HomeTeam.City}} {{gamedata.HomeTeam.Name}}
                                        <template v-if="gamedata.home_score"> ({{gamedata.home_score}})</template>
                                    </label>
                                    <p>
                                        <span>{{gamedata.home_win_pct | percentagecustom(1)}}<sub>%</sub></span>
                                        <em>H</em>
                                    </p>
                                </div>
                            </v-col>
                            <v-col cols="12" lg="6" md="6" sm="6" class="pt-0 pb-0">
                                <div class="head_table">
                                    <div v-if="gamedata.Game.Status=='InProgress' " class="live_title">
                                        <div class="live_txt">
                                            <h5>Live</h5>
                                            <div class="circle_wrap">
                                                <div class="circle" style="animation-delay: -3s"></div>
                                                <div class="circle" style="animation-delay: -2s"></div>
                                                <div class="circle" style="animation-delay: -1s"></div>
                                                <div class="circle" style="animation-delay: 0s"></div>
                                            </div>

                                        </div>
                                        <template v-if="gamedata.period">
                                            <div class="time-count">
                                                {{gamedata.elapsed}} - Q{{gamedata.period}}
                                            </div>
                                        </template>
                                    </div>
                                    <div v-else>
                                        <div class="head_table">
                                            <h5>HEAD TO HEAD</h5>
                                        </div>
                                    </div>
                               <div v-if="gamedata.Game.Status=='InProgress' " class="live_title live_match">

                                    <v-simple-table dark class="pro_tables">
                                        <thead>
                                            <tr>
                                                <th>TEAM</th>
                                                <th class="wins">POINTS</th>
 <th >FGP</th>
  <th >3PT%</th>
  <th >AST</th>
  <th >STL</th>


                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <figure v-if="gamedata.HomeTeam">
                                                        <img :src='gamedata.HomeTeam.logo'>
                                                    </figure>
                                                </td>
                                                <td>{{gamedata.home_score}}</td>
                                             <td>{{gamedata.TeamGames[1].FieldGoalsPercentage}}</td>
                                             <td>{{gamedata.TeamGames[1].ThreePointersPercentage}}</td>
                                             <td>{{gamedata.TeamGames[1].Assists}}</td>

                                             <td>{{gamedata.TeamGames[1].Steals}}</td>

                                            </tr>
                                            <tr>
                                                <td>
                                                    <figure v-if="gamedata.AwayTeam">
                                                        <img :src='gamedata.AwayTeam.logo'>
                                                    </figure>
                                                </td>
                                                <td>{{gamedata.away_score}}</td>
                                              <td>{{gamedata.TeamGames[0].FieldGoalsPercentage}}</td>
                                             <td>{{gamedata.TeamGames[0].ThreePointersPercentage}}</td>
                                             <td>{{gamedata.TeamGames[0].Assists}}</td>

                                             <td>{{gamedata.TeamGames[0].Steals}}</td>

                                            </tr>
                                        </tbody>
                                    </v-simple-table>

                                  </div>
                                    <div v-else>
                                        <v-simple-table dark class="pro_tables">
                                        <thead>
                                            <tr>
                                                <th>TEAM</th>
                                                <th class="wins">WINS</th>

                                     
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <figure v-if="gamedata.HomeTeam">
                                                        <img :src='gamedata.HomeTeam.logo'>
                                                    </figure>
                                                </td>
                                                <td>{{gamedata.HomeTeamWins}}</td>
                                 

                                            </tr>
                                            <tr>
                                                <td>
                                                    <figure v-if="gamedata.AwayTeam">
                                                        <img :src='gamedata.AwayTeam.logo'>
                                                    </figure>
                                                </td>
                                                <td>{{gamedata.AwayTeamWins}}</td>
                                

                                            </tr>
                                        </tbody>
                                    </v-simple-table>
                                    </div>



                                </div>
                            </v-col>
                            <v-col cols="12" lg="3" md="3" sm="3" class="pt-0 pb-0">
                                <div class="team_details away" style="color:#fff">
                                    <figure v-if="gamedata.AwayTeam">
                                        <img :src='gamedata.AwayTeam.logo'>
                                    </figure>
                                    <label>
                                        {{gamedata.AwayTeam.City}} {{gamedata.AwayTeam.City}}
                                        <template v-if="gamedata.away_score"> ({{gamedata.away_score}})</template>
                                    </label>
                                    <p>
                                        <em>A</em>
                                        <span>{{gamedata.away_win_pct | percentagecustom(1)}}<sub>%</sub></span>
                                    </p>
                                </div>
                            </v-col>
                        </v-row>
                    </div>
                   
                    <div class="players_wrap">
                        <v-row>
                            <v-col cols="12" lg="6" md="6" sm="6" class="pt-0 pb-0 col padr-8">
                                <template>
                                    <div class="tabsList">
                                        <span @click="awaytab=1" v-bind:class="{'active':awaytab == 1}" class="tabItem">ACTIVE ROSTER</span>
                                        <span @click="awaytab=2" v-bind:class="{'active':awaytab == 2}" class="tabItem">INJURED PLAYERS</span>
                                        <span @click="awaytab=3" v-bind:class="{'active':awaytab == 3}" class="tabItem">ALL PLAYERS</span>
                                    </div>

                                    <div class="tabswrap">

                                        <div v-if="awaytab == 1">
                                            <div >

                                                <div class="players_list left">
                                                    <template v-for="(player,index) in gamedata.HomeLineup">
                                                        <span :key="index" v-if="(gamedata.Game.Status=='InProgress'  && homePlayerplaying(player.Name) ) || (gamedata.Game.Status!='InProgress'  && player.InjuryStatus==null)" @click="dialog = true;getplayers(player)">
                                                            <playerInfo :player="player" :PlayerGames="gamedata.PlayerGames" :live="gamedata.Game.Status=='InProgress'" :siteUrl="siteUrl" :key="index"></playerInfo>

                                                        </span>
                                                    </template>
                                                </div>
                                            </div>
                                        </div>

                                        <div v-if="awaytab == 2">
                                            <div >
                                                <div class="players_list left">
                                                    <template v-for="(player,index) in gamedata.HomeLineup">
                                                        <span :key="index"  v-if="(gamedata.Game.Status=='InProgress'  && player.InjuryStatus!=null && !homePlayerplaying(player.Name)) || (gamedata.Game.Status!='InProgress'  && player.InjuryStatus!=null ) " @click="dialog = true;getplayers(player)">
                                                            <playerInfo :player="player" :PlayerGames="gamedata.PlayerGames"  :showinjury="true" :siteUrl="siteUrl" :key="index"></playerInfo>

                                                        </span>
                                                    </template>
                                                </div>
                                            </div>
                                        </div>

                                        <div v-if="awaytab == 3">
                                            <div >
                                                <div class="players_list left">
                                                    <template v-for="(player,index) in gamedata.HomeLineup">
                                                        <span :key="index" @click="dialog = true;getplayers(player)">
                                                            <playerInfo :player="player" :PlayerGames="gamedata.PlayerGames"  :siteUrl="siteUrl" :key="index"></playerInfo>

                                                        </span>
                                                    </template>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </template>
                                <!-- <template>
                                    <div class="players_list left">
                                        <template v-for="(player,index) in gamedata.hometeamdata" >
                                            <span :key="index" @click="dialog = true;getplayers(player)" >
                                                <playerInfo :player="player"  :siteUrl="siteUrl" :key="index"></playerInfo>
                                            </span>
                                        </template>
                                    </div>
                                </template> -->
                            </v-col>
                            <v-col cols="12" lg="6" md="6" sm="6" class="pt-0 pb-0 col padl-8">
                              
                              
                              
                                     <template>
                                    <div class="tabsList">
                                        <span @click="htab=1" v-bind:class="{'active':htab == 1}" class="tabItem">ACTIVE ROSTER</span>
                                        <span @click="htab=2" v-bind:class="{'active':htab == 2}" class="tabItem">INJURED PLAYERS</span>
                                        <span @click="htab=3" v-bind:class="{'active':htab == 3}" class="tabItem">ALL PLAYERS</span>
                                    </div>

                                    <div class="tabswrap">

                                        <div v-if="htab == 1">
                                            <div >

                                                <div class="players_list left">
                                                    <template v-for="(player,index) in gamedata.AwayLineup">
                                                        <span :key="index" v-if="(gamedata.Game.Status=='InProgress'  && awayPlayerplaying(player.Name)) || (gamedata.Game.Status!='InProgress'  && player.InjuryStatus==null)" @click="dialog = true;getplayers(player)">
                                                            <playerInfo :player="player" :PlayerGames="gamedata.PlayerGames" :live="gamedata.Game.Status=='InProgress'" :siteUrl="siteUrl" :key="index"></playerInfo>

                                                        </span>
                                                    </template>
                                                </div>
                                            </div>
                                        </div>

                                        <div v-if="htab == 2">
                                            <div >
                                                <div class="players_list left">
                                                    <template v-for="(player,index) in gamedata.AwayLineup">
                                                        <span :key="index" v-if="(gamedata.Game.Status=='InProgress'  && player.InjuryStatus!=null && !awayPlayerplaying(player.Name)) || (gamedata.Game.Status!='InProgress'  && player.InjuryStatus!=null ) " @click="dialog = true;getplayers(player)">
                                                            <playerInfo :player="player" :PlayerGames="gamedata.PlayerGames"  :showinjury="true" :siteUrl="siteUrl" :key="index"></playerInfo>

                                                        </span>
                                                    </template>
                                                </div>
                                            </div>
                                        </div>

                                        <div v-if="htab == 3">
                                            <div >
                                                <div class="players_list left">
                                                    <template v-for="(player,index) in gamedata.AwayLineup">
                                                        <span :key="index" @click="dialog = true;getplayers(player)">
                                                            <playerInfo :player="player"  :siteUrl="siteUrl" :key="index"></playerInfo>

                                                        </span>
                                                    </template>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </template>
                              
                              
                              
                         
                            </v-col>
                        </v-row>
                    </div>
                </div>
            </div>
        </div>
        <div class="probability_graphs" v-if="gamedata">
                <div class="graph" v-if="gamedata.Game.Status!='InProgress' ">
                  <probpeform :game="gamedata" :gameId="gamedata.Game.GameID"  />
                  <teamperformance :game="gamedata" :gameId="gamedata.Game.GameID"  />

                <!-- <h5>TEAM PERFORMANCE - CURRENT SEASON</h5>
                <div class="graph_cnt">

                </div> -->
            </div>
            
            <div class="graph" v-if="gamedata.Game.Status=='InProgress' ">
              <odds :game="gamedata" :gameId="gamedata.Game.GameID"  />

                                <probpeform :game="gamedata" :gameId="gamedata.Game.GameID"  />
                  <teamperformance :game="gamedata" :gameId="gamedata.Game.GameID"  />

            </div>



        </div>
    </div>
    <div class="modaldialog" v-if="dialog" width="1130">
        <div class="wrapperdivbg">
        </div>
        <div class="wrapperdiv">
            <v-card>
                <v-row class="mar0">
                    <v-col class="pad0">
                        <div class="widget_block marb0 role_modal player_infomodal" v-if="selectedplayer">
                            <div class="widget_title modal_header">
                                <div class="modal_title">
                                    <h3>{{selectedplayer.PLAYER_NAME}}
                                    </h3>
                                    <ul class="tab_buttons">
                                        <li v-bind:class="{ active: atab=='Opportunity' }" @click="atab ='Opportunity'">
                                            <a>Opportunity</a>
                                        </li>
                                        <li v-bind:class="{ active: atab=='Position Versatility' }" @click="atab ='Position Versatility'">
                                            <a>Position Versatility</a>
                                        </li>
                                        <li v-bind:class="{ active: atab=='Trade Assets' }" @click="atab ='Trade Assets'">
                                            <a>Trade Assets </a>
                                        </li>
                                        <li v-bind:class="{ active: atab=='Player Synergy' }" @click="atab ='Player Synergy'">
                                            <a>Player Synergy </a>
                                        </li>
                                    </ul>
                                </div>
                                <div>
                                    <v-btn color="primary" text @click="dialog = false">
                                        <img src="@/assets/images/close.svg" />
                                    </v-btn>
                                </div>
                            </div>
                            <div class="widget_body" style="padding:0px;">
                                <div v-if="atab=='Opportunity'">
                                    <opportunity v-if="selectedplayer!=null" :player=selectedplayer />
                                </div>
                                <div v-if="atab=='Position Versatility'">
                                    <player-position-versatility v-if="selectedplayer!=null" :player=selectedplayer />
                                </div>
                                <div v-if="atab=='Trade Assets'">
                                    <trade-assets v-if="selectedplayer!=null" :player=selectedplayer />
                                </div>
                                <div v-if="atab=='Player Synergy'">
                                    <player-synergy v-if="selectedplayer!=null" :player=selectedplayer />
                                </div>
                            </div>
                        </div>
                    </v-col>
                </v-row>
            </v-card>
        </div>
    </div>
</div>
</template>

<script>
import playerInfo from "@/views/components/playerInfo.vue";

import moment from "moment";
import opportunity from '@/views/components/opportunity.vue';
import playerPositionVersatility from "@/views/components/playerPositionVersatility.vue";
import tradeAssets from "@/views/components/tradeAssets.vue";
import playerSynergy from "@/views/components/playerSynergy.vue";
import odds from "@/views/components/odds.vue";

import probpeform from "@/views/components/probteamperformance.vue";

import teamperformance from "@/views/components/teamperformancepro.vue";

export default {
    name: "synergy-seacrh",
    components: {
        playerInfo,
        opportunity,
        playerPositionVersatility,
        tradeAssets,
        playerSynergy,
        odds,
        teamperformance,
        probpeform

    },

    computed: {
        iscompleted() {

            return moment().isBefore(moment(this.gamedata.gamedatee))
        },
        livematch() {

            return moment().isSameOrAfter(moment(this.gamedata.gamedate)) && moment().isSameOrBefore(moment(this.gamedata.gamedatee))
        },

    },
    beforeDestroy() {
        clearInterval(this.polling)
    },
    mounted() {
        this.siteUrl = process.env.VUE_APP_API_URL;
        this.isloading = true;

        this.reloadData()
        this.pollData()
    },
    methods: {
            homePlayerplaying(n) {
      return this.gamedata.ahometeamlist.indexOf(n) > -1
    }, awayPlayerplaying(n) {
      return this.gamedata.aawayteamlist.indexOf(n) > -1
    },
        pollData() {
            this.polling = setInterval(() => {
                this.reloadData()
            }, 36000)
        },
        reloadData() {
            this.$store.dispatch("gettodayprobability2", {
                gameId: this.$route.params.id
            }).then((response) => {
                this.gamedata = []
                response.forEach(element => {
                    var _e = element;

                    this.gamedata = _e
                });

                if(this.gamedata && this.gamedata.Game && this.gamedata.Game.Status!='InProgress'){
                 clearInterval(this.polling)

                }

                this.isloading = false;
            })

        },

        getplayers(s) {
            if(s.PLAYER_ID){

                 this.atab = 'Opportunity'
            this.isloading = true
            this.serach = {
                "page": 1,
                "perpage": 1,
                "matcher": {
                    "playerId": s.PLAYER_ID
                }
            };

            this.$store
                .dispatch("getplayerdetails", this.serach)
                .then(response => {
                    if (response.error) {
                        Object.assign(this.formerrors, {
                            msg: response.error.message
                        });
                    } else {
                        this.totalCount = response.data.result.totalCount;
                        let nitem = response.data.result.list[0];

                        var totalgames = 0

                        nitem['seasons'].forEach(function (tem) {

                            totalgames = totalgames + tem.GP;
                        })
                        nitem.totalgames = totalgames;

                        this.selectedplayer = nitem;

                    }
                    var self = this;
                    setTimeout(function () {

                        self.isloading = false;
                    }, 1000)

                });
            }
           

        }
    },
    data() {
        return {
            awaytab: 1,
            htab: 1,

            options: {
                height: '100%',
                size: 0
            },
            polling: null,
            atab: 'Opportunity',
            isloading: false,
            selectedplayer: null,
            dialog: false,
            siteUrl: null,
            gamedata: null,
            tabs: null,
            //   options: {
            //         height: '100%',
            //         size: 5,
            //         wheelStep : 5,
            //     }
        };
    }
};
</script>
