<template>
<div class="content-body"> 
  <sidebar v-if="player!=null" :player=player />
  <div class="content-wrapper">
  <div class="athlete_content_wrap">
    <v-row>
      <v-col ><player-details v-if="player"  :player="player" /></v-col>
    </v-row>
     <div class="nodataBox" v-if="player && player.RTC == null">

                No Data Available
            </div>
            <div class="athlete_body_content" v-if="player && player.RTC">
      <!-- <v-row>
          <v-col><team-performance/></v-col>
      </v-row> -->

       <v-row v-if="checkWidgetsPermessions('ATHLETE_PERFORMANCE')">
      <v-col><performance-graph v-if="player!=null" :player=player /></v-col>    
    </v-row>

      <v-row v-if="checkWidgetsPermessions('PERFORMANCE_IMPACT')">
          <v-col><performance-impact v-if="player!=null"  :player=player  /></v-col>
      </v-row>

       <v-row v-if="checkWidgetsPermessions('OPPORTUNITY')">
        <v-col><opportunity v-if="player!=null" :player=player  /></v-col>
      </v-row>
    
      <v-row v-if="checkWidgetsPermessions('CAREER_DATA')">
        <v-col><player-carrier-details v-if="player!=null"  :player=player  /></v-col>
      </v-row>
      <!-- <v-row>
        <v-col><real-time-impact/></v-col>
      </v-row> -->
      <!-- <v-row>
        <v-col class="col-mg-6"><player-shooting/></v-col>
        <v-col class="col-mg-6"><player-shooting/></v-col>
      </v-row>     -->


      
    </div>
  </div>
  </div>
</div>
</template>

<script>
import playerDetails from "@/views/components/playerDetails.vue";
//import teamPerformance from "@/views/components/teamPerformance.vue";
import playerCarrierDetails from "@/views/components/playerCarrierDetails.vue";
//import realTimeImpact from "@/views/components/realTimeImpact.vue";
//import playerShooting from "@/views/components/playerShooting.vue";
import opportunity from '@/views/components/opportunity.vue';
import performanceImpact from "@/views/components/performanceImpact.vue";
import Sidebar from "@/layouts/components/Sidebar.vue";
import performanceGraph from "@/views/components/performanceGraph.vue";



export default {
  components: {
    performanceGraph,
    opportunity,
    playerDetails,
    playerCarrierDetails,
    performanceImpact,
    Sidebar
  },
  methods: {
  

 getplayers() {
            this.isloading = true
            this.serach = {
                "page": 1,
                "perpage": 1,
                "matcher": {
                    "playerId": this.$route.params.id
                }
            };

            this.$store
                .dispatch("getplayerdetails", this.serach)
                .then(response => {
                    if (response.error) {
                        Object.assign(this.formerrors, {
                            msg: response.error.message
                        });
                    } else {
                        this.totalCount = response.data.result.totalCount;
                            let nitem = response.data.result.list[0];

                              var totalgames = 0
                            
                            nitem['seasons'].forEach(function(tem){

                                totalgames =totalgames+tem.GP;
                            })
                            nitem.totalgames = totalgames;

                            
                            this.player = nitem;



                    }
                    var self = this;
                    setTimeout(function () {

                        self.isloading = false;
                    }, 1000)

                });

        }
  },
  mounted() {
    this.getplayers();
  },
  data() {
    return {
      player: null
    };
  }
};
</script>

<style>

</style>