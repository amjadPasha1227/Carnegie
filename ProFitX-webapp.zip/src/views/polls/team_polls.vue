<template>
<div>
    <div class="team_polls">
        <div class="team_polls_content">
            <h3>Team Polls</h3>
           
            <div class="team_polls_cnt">
                <template v-for="(item, ind) in polls" >
                  <div class="team_polls_block" v-if="ind<=1" :key="ind">
                     <pollItem  :pollItem="item"  @reloadpollsList="reloadpollsList" :loadedFromList="'list'" />
                </div>
                </template>
               <!--
                <div class="team_polls_block">
                    <div class="polls_block">
                        <div class="poll_title">
                            <h5>Who is the best point guard in NBA history?<span>8 hours left</span></h5>
                            <a><img src="@/assets/images/share.svg"></a>
                        </div>
                        <h6>ProFitX Choice <span>Magic Johnson</span></h6>
                        <ul>
                            <li>
                                <div class="player">
                                    <figure><img src="@/assets/images/player_dp.png"></figure>
                                    <figcaption>Isiah Thomas</figcaption>
                                </div>
                            </li>
                            <li>
                                <div class="player">
                                    <figure><img src="@/assets/images/player_dp.png"></figure>
                                    <figcaption>Isiah Thomas</figcaption>
                                </div>
                            </li>
                            <li>
                                <div class="player voted">
                                    <figure><img src="@/assets/images/player_dp.png"></figure>
                                    <figcaption>Isiah Thomas</figcaption>
                                </div>
                            </li>
                            <li>
                                <div class="player">
                                    <figure><img src="@/assets/images/player_dp.png"></figure>
                                    <figcaption>Isiah Thomas</figcaption>
                                </div>
                            </li>
                            <li>
                                <div class="player">
                                    <figure><img src="@/assets/images/player_dp.png"></figure>
                                    <figcaption>Isiah Thomas</figcaption>
                                </div>
                            </li>
                            <li>
                                <div class="player">
                                    <figure><img src="@/assets/images/player_dp.png"></figure>
                                    <figcaption>Isiah Thomas</figcaption>
                                </div>
                            </li>
                        </ul>
                        <button class="vote_btn"><span>VOTE</span></button>
                    </div> 
                </div>
                <div class="team_polls_block">
                    <div class="polls_block">
                        <div class="poll_title">
                            <h5>Who is the best point guard in NBA history?<span>8 hours left</span></h5>
                            <a><img src="@/assets/images/share.svg"></a>
                        </div>
                        <h6>ProFitX Choice <span>Magic Johnson</span></h6>
                        <ul>
                            <li>
                                <div class="player">
                                    <figure><img src="@/assets/images/player_dp.png"></figure>
                                    <figcaption>Isiah Thomas</figcaption>
                                </div>
                            </li>
                            <li>
                                <div class="player">
                                    <figure><img src="@/assets/images/player_dp.png"></figure>
                                    <figcaption>Isiah Thomas</figcaption>
                                </div>
                            </li>
                            <li>
                                <div class="player voted">
                                    <figure><img src="@/assets/images/player_dp.png"></figure>
                                    <figcaption>Isiah Thomas</figcaption>
                                </div>
                            </li>
                            <li>
                                <div class="player">
                                    <figure><img src="@/assets/images/player_dp.png"></figure>
                                    <figcaption>Isiah Thomas</figcaption>
                                </div>
                            </li>
                            <li>
                                <div class="player">
                                    <figure><img src="@/assets/images/player_dp.png"></figure>
                                    <figcaption>Isiah Thomas</figcaption>
                                </div>
                            </li>
                            <li>
                                <div class="player">
                                    <figure><img src="@/assets/images/player_dp.png"></figure>
                                    <figcaption>Isiah Thomas</figcaption>
                                </div>
                            </li>
                        </ul>
                        <button class="vote_btn"><span>VOTE</span></button>
                    </div> 
                </div> 
                -->
                <div class="team_polls_block">
                    <div class="polls_block">
                        <div class="poll_title">
                            <h5>Who is the best point guard in NBA history?<span>8 hours left</span></h5>
                            <a><img src="@/assets/images/share.svg"></a>
                        </div> 
                        <div class="profitx_rating">
                            <div class="polls_header">
                                <figure><img src="@/assets/images/player_dp.png"></figure>
                                <span>?</span>
                                <figure><img src="@/assets/images/ATL_logo.svg"></figure>
                            </div>
                            <label>ProFitX Rating<b>36</b></label>                        
                        </div>
                        <div class="rating_actions">
                                <a class="action_btn exercise">Exercise</a>
                                <a class="action_btn decline">Decline</a>
                            </div>
                        
                    </div>
                </div>
                
           
            </div>
        </div>
    </div>
</div>
</template>



<script> 
 
import pollItem from "./pollItem.vue";  

export default {
    components: {  
        pollItem
    },
    methods: {
         reloadpollsList(){
           
            this.$emit("reloadpollsList")

        },
    
        
       
        
    },
    data: () => ({
         
         
    }),
    mounted() {
 

    },
    computed: {
  
    },
     props:{
      polls:{
          type:Array,
          default:new Array()
      }
  },
}
</script> 
