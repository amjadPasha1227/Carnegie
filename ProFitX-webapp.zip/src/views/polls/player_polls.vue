<template>
<div>
    <div class="player_polls">
        <div class="player_polls_cnt">
            <h3>Player Polls</h3>
            <ul>
                <li>
                    <div>
                        <h5>Do you expect Kyrie Irving to be allowed to play in home games by the start of the playoff?</h5>
                        <span>8 hours left</span>
                    </div>
                    <div class="d-flex align-items-center">
                        <p>
                            <button class="like"><img src="@/assets/images/like.svg">Yes</button>
                            <button class="like"><img src="@/assets/images/dislike.svg">No</button>
                        </p>
                        <a class="share"><img src="@/assets/images/share.svg"></a>
                    </div>
                </li>
                <li>
                    <div>
                        <h5>Do you expect Kyrie Irving to be allowed to play in home games by the start of the playoff?</h5>
                        <span>8 hours left</span>
                    </div>
                    <div class="d-flex align-items-center">
                        <p>
                            <button class="like"><img src="@/assets/images/like.svg">Yes</button>
                            <button class="like"><img src="@/assets/images/dislike.svg">No</button>
                        </p>
                        <a class="share"><img src="@/assets/images/share.svg"></a>
                    </div>
                </li>
                <li>
                    <div>
                        <h5>Do you expect Kyrie Irving to be allowed to play in home games by the start of the playoff?</h5>
                        <span>8 hours left</span>
                    </div>
                    <div class="d-flex align-items-center">
                        <p>
                            <button class="like"><img src="@/assets/images/like.svg">Yes</button>
                            <button class="like"><img src="@/assets/images/dislike.svg">No</button>
                        </p>
                        <a class="share"><img src="@/assets/images/share.svg"></a>
                    </div>
                </li>
                <li>
                    <div>
                        <h5>Do you expect Kyrie Irving to be allowed to play in home games by the start of the playoff?</h5>
                        <span>8 hours left</span>
                    </div>
                    <div class="d-flex align-items-center">
                        <p>
                            <button class="like"><img src="@/assets/images/like.svg">Yes</button>
                            <button class="like"><img src="@/assets/images/dislike.svg">No</button>
                        </p>
                        <a class="share"><img src="@/assets/images/share.svg"></a>
                    </div>
                </li>
                <li>
                    <div>
                        <h5>Do you expect Kyrie Irving to be allowed to play in home games by the start of the playoff?</h5>
                        <span>8 hours left</span>
                    </div>
                    <div class="d-flex align-items-center">
                        <p>
                            <button class="like"><img src="@/assets/images/like.svg">Yes</button>
                            <button class="like"><img src="@/assets/images/dislike.svg">No</button>
                        </p>
                        <a class="share"><img src="@/assets/images/share.svg"></a>
                    </div>
                </li>
                <li>
                    <div>
                        <h5>Do you expect Kyrie Irving to be allowed to play in home games by the start of the playoff?</h5>
                        <span>8 hours left</span>
                    </div>
                    <div class="d-flex align-items-center">
                        <p>
                            <button class="like"><img src="@/assets/images/like.svg">Yes</button>
                            <button class="like"><img src="@/assets/images/dislike.svg">No</button>
                        </p>
                        <a class="share"><img src="@/assets/images/share.svg"></a>
                    </div>
                </li>
            </ul>
            <div class="loading">
                Loading…
            </div>
        </div>
    </div>
</div>
</template>



<script> 
 
  

export default {
    components: {  
   
    },
    methods: {
        
       
        
    },
    data: () => ({
         
         
    }),
    mounted() {
 

    },
    computed: {
  
    }
}
</script> 
