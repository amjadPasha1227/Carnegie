<template>
    <div class="polls_page">
        <div class="polls_header">
            <div class="polls_header_cnt">
                <ul class="polls_header_left">
                    <li class="active">Performance Polls</li>
                    <!-- <li>Expired Polls</li> -->
                </ul>
                <div class="polls_header_right">
                    <ul>
                        <!--- <li class="profile" >
                           
                            <figure >
                            <img   :src="checkProperty(getProfileData, 'profilePicture')"   @error="getProfilePhoto($event)"  />
                                                     
                            </figure>
                            <figcaption>
                            
                             {{ checkProperty(getProfileData ,'name') }}
                                
                            </figcaption>
                        </li>-->
                        <!--
                        <li>
                            <div class="redeem">
                                <label><img src="@/assets/images/medal2.svg">{{pllStats['playerLikeCount']}}</label>
                                <span>Redeem</span>
                            </div>
                        </li>
                        -->
                         <template v-if="pollsList.length>0">
                        <li>
                           <p>{{pllStats['pollVoteCount']}}</p>
                            <h5><img src="@/assets/images/check2.svg">Voted</h5>
                        </li>
                         <li>
                            <p>{{pllStats['pollShareCount']}}</p>
                            <h5><img src="@/assets/images/share2.svg">Shared</h5>
                        </li>
                        </template>  
                    </ul>
                </div>
            </div>
        </div>
        <div class="expired_filters d-none">
            <ul>
                <li>
                    Filters
                </li>
                <li>
                    <v-select :items="items" label="Year" solo></v-select>
                </li>
                <li>
                    <v-select :items="items" label="Month" solo></v-select>
                </li> 
            </ul>
        </div>
        <div class="polls_content">
      
            <latestPolls :polls="pollsList" @reloadpollsList="reloadpollsList"></latestPolls>
            <!--
            <teamPolls :polls="pollsList" @reloadpollsList="reloadpollsList"></teamPolls>
            <playerPolls :polls="pollsList" @reloadpollsList="reloadpollsList" ></playerPolls>
            -->
        </div>    
    </div>
</template>

<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>

<script> 
 
import latestPolls from "@/views/polls/latest_polls.vue"; 

 import moment from "moment";
import teams from "@/data/teams.json";
import players from "@/data/players.json";
import _ from "lodash";

 
export default {
    components: {  
     latestPolls,
    // teamPolls,
    // playerPolls
    
    },
    methods: {
        reloadpollsList(){
            this.getPolsList()
            this.getPollsstatsByUser();

        },
        
    //    makeRed: function() {
    //     this.isActive = !this.isActive;
    //     },
    //     sidebaropen: function() {
    //         this.isActive = !this.isActive;
    //     }
    getPollsstatsByUser(){
        let payLoad = {};
        this.pllStats= {
            "pollVoteCount": 0,
            "pollShareCount": 0,
            "playerLikeCount": 0,
        },
           this.$store.dispatch("getPollsstatsByUser", payLoad).then((res) => {
               this.pllStats = res;
        
           
           });

    },

      getPolsList() {
      let _self = this;
      let payLoad = {
        page: _self.page,
        perpage: _self.perPage,
        matcher: {
             "typeIds": [1,2],
            "subTypeIds": [],
          statusList: [true, false],
          createdByIds: [],
          createdDateRange: [],
        },
        getForPublish: true,
        getOpinionStats: true,
        timezone: moment.tz.guess(),
        sorting:{
            path:"customId",
            order:-1

        }
      };
      this.listLoading =true;
        this.$store.dispatch("getPolsList", payLoad).then((res) => {
          this.pollsList =_.shuffle(res['list']);
          this.listLoading =false;

        }) .catch((err) => {
            this.listLoading =false;
        });
    },
        
    },
    data: () => ({
        
        pllStats:{
            "pollVoteCount": 0,
            "pollShareCount": 0,
            "playerLikeCount": 0,
        },
        listLoading:false,
        page: 1,
        perPage: 20,
        pollsList: [],
        isActive: false,
        items: ['2022', '2021', '2020', '2019'],
        options: ['list', 'of', 'options']
    }),
    mounted() {
     
        this.getPolsList();
        this.getPollsstatsByUser();
 

    },
    computed: {
        getProfileData() {
      return this.$store.state.user;
    },
  
    }
}
</script> 
