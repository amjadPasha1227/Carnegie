<template>
    <div>
  
        <div v-if="loadedFromList=='list'" class="polls_block"  :ref="pollItem['_id']" >
        
            <div class="poll_title">
                <h5>{{pollItem['question']}}<span>{{timeAgo(pollItem['startDate'])}}</span></h5>
                <div class="share_btn">
                 <v-progress-circular v-if="pollsSharing"  indeterminate size="25"></v-progress-circular>
                <a @click="shareMe()"><img src="@/assets/images/share.svg"></a>
                </div>
            </div>
          
            <!--<h6>ProFitX Choice <span>SR</span></h6>-->
            <ul>
        <!--  {{pollItem.option5Percentage}}-->
               
                <template v-if="pollItem['option1']" >
                    <li v-for=" (opt ,ind) in pollItem['option1']"  :key="'option1'+ind"  @click="selectForVote(pollItem['option1'] ,'option1')">
                        <div class="player" :class="{'voted':pollItem['option1votedByme'] || opinionSelect=='option1' }">
                            <figure v-if="pollItem['option1Image']"><img   :src="pollItem['option1Image']" @error="setDefaultPlayerImage($event )"></figure>
                            <figcaption>{{opt}}</figcaption>
                        </div>
                    </li>
                </template>
                <template v-if="pollItem['option2']" >
                    <li v-for=" (opt ,ind) in pollItem['option2']"   :key="'option2'+ind" @click="selectForVote(pollItem['option2'] ,'option2')">
                        <div class="player" :class="{'voted':pollItem['option2votedByme'] || opinionSelect=='option2'}">
                            <figure v-if="pollItem['option2Image']" ><img :src="pollItem['option2Image']" @error="setDefaultPlayerImage($event )" ></figure>
                            <figcaption>{{opt}}</figcaption>
                        </div>
                    </li>
                </template>
                
                <template v-if="pollItem['option3']" >
                    <li v-for=" (opt ,ind) in pollItem['option3']"  :key="'option3'+ind" @click="selectForVote(pollItem['option3'] ,'option3')">
                        <div class="player" :class="{'voted':pollItem['option3votedByme'] || opinionSelect=='option3'}">
                            <figure v-if="pollItem['option3Image']"><img :src="pollItem['option3Image']" @error="setDefaultPlayerImage($event )"></figure>
                            <figcaption>{{opt}}</figcaption>
                        </div>
                    </li>
                </template>
                <template v-if="pollItem['option4']" >
                    <li v-for=" (opt ,ind) in pollItem['option4']"  :key="'option4'+ind" @click="selectForVote(pollItem['option4'] ,'option4')">
                        <div class="player" :class="{'voted':pollItem['option4votedByme'] || opinionSelect=='option4'}">
                            <figure v-if="pollItem['option4Image']" ><img :src="pollItem['option4Image']" @error="setDefaultPlayerImage($event )"></figure>
                            <figcaption>{{opt}}</figcaption>
                        </div>
                    </li>
                </template>
                <template v-if="pollItem['option5']" >
                    <li v-for=" (opt ,ind) in pollItem['option5']"  :key="'option5'+ind" @click="selectForVote(pollItem['option5'] ,'option5')">
                        <div class="player" :class="{'voted':pollItem['option5votedByme'] || opinionSelect=='option5'}">
                            <figure v-if="pollItem['option5Image']" ><img :src="pollItem['option5Image']" @error="setDefaultPlayerImage($event )"></figure>
                            <figcaption>{{opt}}</figcaption>
                        </div>
                    </li>
                </template>
                <template v-if="pollItem['option6']" >
                    <li v-for=" (opt ,ind) in pollItem['option6']" :key="'option6'+ind" @click="selectForVote(pollItem['option6'] ,'option6')">
                        <div class="player" :class="{'voted':pollItem['option6votedByme'] || opinionSelect=='option6'}" >
                            <figure v-if="pollItem['option6Image']" ><img :src="pollItem['option6Image']" @error="setDefaultPlayerImage($event )"></figure>
                            <figcaption>{{opt}}</figcaption>
                        </div>
                    </li>
                </template>
                
            </ul>
            <!--<button class="vote_btn"  v-if="pollItem['selfVoting'] && pollItem['selfVoting'].length>0 " @click="removeVote()" ><span>Delete Vote</span></button>-->
            <button class="vote_btn" :disabled="!selecedOptionForVote" v-if="(pollItem['selfVoting'] && pollItem['selfVoting'].length<=0 )"  @click="vote()" ><span>VOTE</span></button>
            

          

        <!--<img :src="imageSrc" v-if="imageSrc" />-->
    
    
        </div>
        <div v-else-if="loadedFromList=='home'" class="players__list">
                    <h5>{{pollItem['question']}}</h5>
                    <em v-if="pollItem['option1votedByme']" class="youvoted">You Voted</em>
                    <ul>
                     <template v-if="pollItem['option1']" >
                        <li  :class="{'voted-byme':pollItem['option1votedByme'] || opinionSelect=='option1'}">
                            <div class="player_list">
                                <span class="votingprogress" :style="'width:'+pollItem['option1Percentage']+'%'"></span>
                                <div class="player_info">
                                    <figure v-if="pollItem['option1Image']" ><img :src="pollItem['option1Image']" @error="setDefaultPlayerImage($event )"></figure>
                                    <figcaption>{{pollItem['option1'][0]}}</figcaption>
                                </div>
                                <div class="player_result"  >
                                         <label> <template v-if="pollItem['option1Percentage']>0">{{pollItem['option1Percentage']}}%</template></label>
                                    <button class="vote"  v-if="(pollItem['selfVoting'] && pollItem['selfVoting'].length<=0 )"  @click="selectForVote(pollItem['option1'] ,'option1')"><img src="@/assets/images/like-icon5.svg">Vote</button>
                                </div>
                            </div>
                        </li>
                     </template>
                     <template v-if="pollItem['option2']" >
                        <li :class="{'voted-byme':pollItem['option2votedByme'] || opinionSelect=='option2'}" >
                            <div class="player_list">
                                <span class="votingprogress" :style="'width:'+pollItem['option2Percentage']+'%'"></span>
                                <div class="player_info">
                                    <figure v-if="pollItem['option2Image']" ><img :src="pollItem['option2Image']" @error="setDefaultPlayerImage($event )" ></figure>
                                    <figcaption>{{pollItem['option2'][0]}}</figcaption>
                                </div>
                                <div class="player_result" >
                                       <label> <template v-if="pollItem['option2Percentage']>0">{{pollItem['option2Percentage']}}%</template></label>
                                    <button class="vote"  v-if="(pollItem['selfVoting'] && pollItem['selfVoting'].length<=0 )"  @click="selectForVote(pollItem['option2'] ,'option2')"><img src="@/assets/images/like-icon5.svg">Vote</button>
                                </div>
                            </div>
                        </li>
                     </template>
                     <template v-if="pollItem['option3']" >
                        <li :class="{'voted-byme':pollItem['option3votedByme'] || opinionSelect=='option3'}" >
                            <div class="player_list">
                                 <span class="votingprogress" :style="'width:'+pollItem['option3Percentage']+'%'"></span>
                                <div class="player_info">
                                    <figure v-if="pollItem['option3Image']"  ><img :src="pollItem['option3Image']" @error="setDefaultPlayerImage($event )"></figure>
                                    <figcaption>{{pollItem['option3'][0]}}</figcaption>
                                </div>
                                <div class="player_result" >
                                      <label> <template v-if="pollItem['option3Percentage']>0">{{pollItem['option3Percentage']}}%</template></label>
                                    <button class="vote"  v-if="(pollItem['selfVoting'] && pollItem['selfVoting'].length<=0 )"  @click="selectForVote(pollItem['option3'] ,'option3')"><img src="@/assets/images/like-icon5.svg">Vote</button>
                                </div>
                            </div>
                        </li>
                     </template>
                     <template v-if="pollItem['option4']" >
                        <li  :class="{'voted-byme':pollItem['option4votedByme'] || opinionSelect=='option4'}"  >
                            <div class="player_list">
                                <span class="votingprogress" :style="'width:'+pollItem['option4Percentage']+'%'"></span>
                                <div class="player_info">
                                    <figure v-if="pollItem['option4Image']" ><img :src="pollItem['option4Image']" @error="setDefaultPlayerImage($event )"></figure>
                                    <figcaption>{{pollItem['option4'][0]}}</figcaption>
                                </div>
                                <div class="player_result">
                                     <label> <template v-if="pollItem['option4Percentage']>0">{{pollItem['option4Percentage']}}%</template></label>
                                    <button class="vote"  v-if="(pollItem['selfVoting'] && pollItem['selfVoting'].length<=0 )"  @click="selectForVote(pollItem['option4'] ,'option4')"><img src="@/assets/images/like-icon5.svg">Vote</button>
                                </div>
                            </div>
                        </li>
                     </template>
                     <template v-if="pollItem['option5']" >
                        <li :class="{'voted-byme':pollItem['option5votedByme'] || opinionSelect=='option5'}" >
                            <div class="player_list">
                                 <span class="votingprogress" :style="'width:'+pollItem['option5Percentage']+'%'"></span>
                                <div class="player_info">
                                    <figure v-if="pollItem['option5Image']"><img :src="pollItem['option5Image']" @error="setDefaultPlayerImage($event )"></figure>
                                    <figcaption>{{pollItem['option5'][0]}}</figcaption>
                                </div>
                                <div class="player_result " >
                                    <label> <template v-if="pollItem['option5Percentage']>0">{{pollItem['option5Percentage']}}%</template></label>
                                    <button class="vote"  v-if="(pollItem['selfVoting'] && pollItem['selfVoting'].length<=0 )"  @click="selectForVote(pollItem['option5'] ,'option5')"><img src="@/assets/images/like-icon5.svg">Vote</button>
                                </div>
                            </div>
                        </li>
                     </template>
                     <template v-if="pollItem['option6']" >
                        <li  :class="{'voted-byme':pollItem['option6votedByme'] || opinionSelect=='option6'}" >
                            <div class="player_list">
                                 <span class="votingprogress" :style="'width:'+pollItem['option6Percentage']+'%'"></span>
                                <div class="player_info">
                                    <figure v-if="pollItem['option6Image']" ><img src="@/assets/images/profile_dp-1.png"></figure>
                                    <figcaption>{{pollItem['option6'][0]}}</figcaption>
                                </div>
                                <div class="player_result " >
                                    <label>
                                       <template v-if="pollItem['option6Percentage']>0">{{pollItem['option6Percentage']}}%</template>
                                    </label>
                                  
                                    <button class="vote"  v-if="(pollItem['selfVoting'] && pollItem['selfVoting'].length<=0 )"  @click="selectForVote(pollItem['option6'] ,'option6')"><img src="@/assets/images/like-icon5.svg">Vote</button>
                                </div>
                            </div>
                        </li>
                     </template>
                       
                    </ul>
        </div>
        <div class="poll_block" v-else-if="loadedFromList=='home_player_options'">
            <div class="polls_header">
                <figure v-if="pollItem['playerImage']" >
                    <img  :src="pollItem['playerImage']" @error="setDefaultPlayerImage($event )">
                </figure>
                <span v-if="pollItem['playerImage'] && pollItem['teamImage']"  >?</span> 
                <figure v-if=" pollItem['teamImage']" ><img :src="pollItem['teamImage']" @error="setDefaultTeamImage($event )"></figure>
            </div>
            <label>{{pollItem['question']}}
                
                <!-- <b>36</b>
                -->
                </label>
            <div class="poll_actions">
                <a  @click="selectForVote(pollItem['option1'] ,'option1')" v-if="pollItem['option1'] && pollItem['option1'].length > 0" class="action_btn exercise">{{pollItem['option1'][0]}} </a>
                <a  @click="selectForVote(pollItem['option2'] ,'option2')" v-if="pollItem['option2'] && pollItem['option2'].length > 0" class="action_btn decline">{{pollItem['option2'][0]}} </a>
            </div>
        </div>

          <success-popup
        @closePopup="showoverlay =false"
        :closebutton="closebutton"
        :showoverlay="showoverlay"
        :title="messagetitle"
        :description="messagecontent"

        />

        

        <v-dialog
    v-if="showSharingNetworks"
      v-model="showSharingNetworks"
      max-width="400"
      class="card_dialog"
      
      
    >
      <div class="dialog_body social_media_body">
        <v-btn
          color="primary"
          text
          @click="showSharingNetworks=false " class="close-btn close-btn2"
        >
          <v-icon>mdi-close</v-icon>
        </v-btn>
            <div class="flex w-full bg-img vx-row no-gutter  justify-center login-wrapper" id="page-login">
                <div class="madal_social_media">
                <ul>
                    <ShareNetwork
                        v-for="network in networks"
                        :network="network.network"
                        :key="network.network"
                        :style="{backgroundColor: network.color}"
                        :url="sharing.url"
                        :title="sharing.title"
                        :description="sharing.description"
                        :quote="sharing.quote"
                        :hashtags="sharing.hashtags"
                        :twitterUser="sharing.twitterUser"
                        tag="li"
                    >
                        <i :class="network.icon"></i>
                        <span>{{ network.name }}</span>
                    </ShareNetwork>
                </ul>
            </div>
            </div>

        </div>
      </v-dialog>
       


       
      
     </div>
</template>

<script>
 import moment from "moment";
 import html2canvas from 'html2canvas'
 import VueSocialSharing from 'vue-social-sharing'
import Vue from 'vue'
Vue.use(VueSocialSharing);

import _ from "lodash";
import successPopup from "@/views/success.vue";
export default {
   props:{
      loadedFromList:{
           type:String,
          default:'list'

      }, 
      pollItem:{
          type:Object,
          default:null
      }
  },
    components: {  
        successPopup,
      
    
    },
    methods: {
        pollsShareAction(){
           let self =this;
            if(this.pollsShareObject.length>0){
               let paYload = {
                   "pollId":"",
                   "document":{}
               }
                paYload["pollId"] = this.pollItem["_id"];
              paYload["document"]= this.pollsShareObject[0]
             
              this.sharing['url'] = "https://profitx.ai/polls/"; // "http://localhot:8080/polls";//paYload["document"]['path']
              this.sharing['title'] = "Profitx"
              this.sharing['description'] =  this.pollItem["question"];
              this.sharing['quote'] =  this.pollItem["question"];
              this.sharing['hashtags'] =  this.pollItem["question"];
            //  this.sharing['twitterUser'] =  this.pollItem["qution"];



         var ogmetatag = document.querySelector("meta[property~='og:image']");
        if (!ogmetatag) {
            ogmetatag = document.createElement('meta');
           document.head.appendChild(ogmetatag);
             
        }
        ogmetatag.setAttribute('property', 'og:image');
        ogmetatag.setAttribute('content',  self.pollItem["question"]);
        ogmetatag.setAttribute('title', self.pollItem["question"]);
        ogmetatag.setAttribute('url',  "https://beta.profitx.ai/polls/");
        ogmetatag.setAttribute('image', this.sharing['url']);
     

           
             this.showSharingNetworks =true;
             this.pollsSharing =false;
        

                /*
                this.$store.dispatch("pollsShare" ,paYload)
                .then((res)=>{
                    self.pollsSharing =false;
                     self.messagetitle ="Poll Sharing";
                     self.messagecontent =res['message'];
                    self.showoverlay = true;
                    self.pollsShareObject =[];

                })
                .catch((err)=>{
                     self.pollsShareObject =[];
                     self.pollsSharing =false;
                     self.messagetitle ="Poll Sharing";
                     self.messagecontent= err['message'];
                    self.showoverlay = true;
                    
                })
               */

            }
            

        },
        upload(files , type=''){
        let model = _.cloneDeep(files);
         this.documents =[];
         this.pollsShareObject = [];

        let temp_count = 0;
        let formData = new FormData();
                
        let mapper = model.map(
            item =>
            (item = {
                name: item.name,
                file: item,
                path: item.url ? item.url : "",
                url:item.url ? item.url : "",
                extn: item.name.split('.').pop(),
                mimetype: item.type ? item.type : item.mimetype,
                
            })
        );

        //var ext = mapper[0].extn.split('.').pop();

            
            if (mapper.length > 0) {
                this.isloading =true;
            mapper.forEach((doc, index) => {
                formData.append("files", doc.file);
                formData.append("secureType", "public");
                this.$store.dispatch("uploadS3File", formData).then(response => {
                    temp_count++;
                
                    response.data.result.forEach(urlGenerated => {

                          
                    
                        if(_.has(urlGenerated ,"path") && !( _.has(urlGenerated ,"url"))){
                            urlGenerated['url'] = urlGenerated ['path'];
                            
                        }
                        if(_.has(urlGenerated ,"url") && !( _.has(urlGenerated ,"path")) ){
                            urlGenerated['path'] = urlGenerated ['url'];
                            
                        }  

                         this.pollsShareObject.push(urlGenerated);
                         if(type=="share"){
                             this.pollsSharing =true;
                             this.pollsShareAction();

                         }
                                       
                        

                        doc.url = urlGenerated;
                        delete doc.file;
                        mapper[index] = doc;

                    });
                });

            });
            model.splice(0, mapper.length, ...mapper);
        }else{
            this.pollsSharing =false;
        }


        },
       async shareMe(){
           let self =this;
              let el = this.$refs[self.pollItem['_id']]; // You have to call $el if your ref is Vue component
             
            let output = (await html2canvas(el)).toDataURL();
           this.imageSrc =output;

            function dataURLtoFile(dataurl, filename) {

            var arr = dataurl.split(','),
            mime = arr[0].match(/:(.*?);/)[1],
            bstr = atob(arr[1]), 
            n = bstr.length, 
            u8arr = new Uint8Array(n);

            while(n--){
            u8arr[n] = bstr.charCodeAt(n);
            }

            return new File([u8arr], filename, {type:mime});
            }

           let file = dataURLtoFile(output ,this.pollItem['question']+".png");
                     
          this.documents =[];
          this.documents.push( file);
          this.pollsSharing =true;
          this.upload(this.documents ,"share");
        
      

           
        },
        timeAgo(value){
               return moment(String(value)).fromNow()

        },
     
        checkIsotedByme(optionItem){

            if((this.pollItem['selfVoting'] && this.pollItem['selfVoting'].length>0 )){

                

                return true;
                
            }else{
                return false;
            }
        },
        selectForVote(item ,opinionSelect=''){
           // alert(this.loadedFromList)

        if(this.loadedFromList =="home" || this.loadedFromList =='home_player_options'){
            this.opinionSelect = opinionSelect;
            this.selecedOptionForVote = item;
            this.vote();

        }else {
            if(this.opinionSelect ==opinionSelect ){
              this.opinionSelect ='';
              this.selecedOptionForVote = null;
           }else{

               this.opinionSelect = opinionSelect;
               this.selecedOptionForVote = item;

           }
        }
           
            
        },
        reloadpollsList(){
            this.opinionSelect ='';
            this.selecedOptionForVote =null;
            this.$emit("reloadpollsList")

        },
        vote(){
          
            if (!this.$store.getters.isLoggedIn){
                this.$router.push('/pricing?show=signup')
                
            }else{
            let self =this;
            if(this.selecedOptionForVote){
                let payLoad = {
                    "pollId":self.pollItem['_id'],
                    "timezone": moment.tz.guess(),
                    "opinion":self.selecedOptionForVote

                }
                this.$store.dispatch("submitVoting" ,payLoad).then((res)=>{
                    //self.messagetitle ="Submit Vote";
                    //self.messagecontent =res['message'];
                  //  self.showoverlay = true;
                    self.reloadpollsList();
                })
                .catch((err)=>{
                    self.messagetitle ="Submit Vote";
                    self.messagecontent =err['message'];
                    self.showoverlay = true;
                    
                })

            } 
        }         
          

            
        }
        
       
        
    },
    data: () => ({
         showSharingNetworks:false,
        isloading:false,   
        documents:[],
        imageSrc:'',
        opinionSelect:'',
        showoverlay:false,
        closebutton: true,
        messagetitle:'',
        messagecontent:'',
        selecedOptionForVote:null,
        pollsShareObject:[],
        pollsSharing:false,

        sharing: {
        url: 'https://news.vuejs.org/issues/180',
        title: 'Say hi to Vite! A brand new, extremely fast development setup for Vue.',
        description: 'This week, I’d like to introduce you to "Vite", which means "Fast". It’s a brand new development setup created by Evan You.',
        quote: 'The hot reload is so fast it\'s near instant. - Evan You',
        hashtags: 'vuejs,vite,javascript',
      },
      networks: [
     //   { network: 'baidu', name: 'Baidu', icon: 'fas fah fa-lg fa-paw', color: '#2529d8' },
     //   { network: 'buffer', name: 'Buffer', icon: 'fab fah fa-lg fa-buffer', color: '#323b43' },
       // { network: 'email', name: 'Email', icon: 'far fah fa-lg fa-envelope', color: '#333333' },
       // { network: 'evernote', name: 'Evernote', icon: 'fab fah fa-lg fa-evernote', color: '#2dbe60' },
        { network: 'facebook', name: 'Facebook', icon: 'fas fa-facebook-f', color: '#1877f2' },
      //  { network: 'flipboard', name: 'Flipboard', icon: 'fab fah fa-lg fa-flipboard', color: '#e12828' },
       // { network: 'hackernews', name: 'HackerNews', icon: 'fab fah fa-lg fa-hacker-news', color: '#ff4000' },
      //  { network: 'instapaper', name: 'Instapaper', icon: 'fas fah fa-lg fa-italic', color: '#428bca' },
       // { network: 'line', name: 'Line', icon: 'fab fah fa-lg fa-line', color: '#00c300' },
        { network: 'linkedin', name: 'LinkedIn', icon: 'fab fah fa-lg fa-linkedin', color: '#007bb5' },
      //  { network: 'messenger', name: 'Messenger', icon: 'fab fah fa-lg fa-facebook-messenger', color: '#0084ff' },
      //  { network: 'odnoklassniki', name: 'Odnoklassniki', icon: 'fab fah fa-lg fa-odnoklassniki', color: '#ed812b' },
      //  { network: 'pinterest', name: 'Pinterest', icon: 'fab fah fa-lg fa-pinterest', color: '#bd081c' },
     //   { network: 'pocket', name: 'Pocket', icon: 'fab fah fa-lg fa-get-pocket', color: '#ef4056' },
      //  { network: 'quora', name: 'Quora', icon: 'fab fah fa-lg fa-quora', color: '#a82400' },
      //  { network: 'reddit', name: 'Reddit', icon: 'fab fah fa-lg fa-reddit-alien', color: '#ff4500' },
     //   { network: 'skype', name: 'Skype', icon: 'fab fah fa-lg fa-skype', color: '#00aff0' },
      //  { network: 'sms', name: 'SMS', icon: 'far fah fa-lg fa-comment-dots', color: '#333333' },
     //   { network: 'stumbleupon', name: 'StumbleUpon', icon: 'fab fah fa-lg fa-stumbleupon', color: '#eb4924' },
      //  { network: 'telegram', name: 'Telegram', icon: 'fab fah fa-lg fa-telegram-plane', color: '#0088cc' },
      //  { network: 'tumblr', name: 'Tumblr', icon: 'fab fah fa-lg fa-tumblr', color: '#35465c' },
        { network: 'twitter', name: 'Twitter', icon: 'fab fah fa-lg fa-twitter', color: '#1da1f2' },
     //   { network: 'viber', name: 'Viber', icon: 'fab fah fa-lg fa-viber', color: '#59267c' },
      //  { network: 'vk', name: 'Vk', icon: 'fab fah fa-lg fa-vk', color: '#4a76a8' },
      //  { network: 'weibo', name: 'Weibo', icon: 'fab fah fa-lg fa-weibo', color: '#e9152d' },
      //  { network: 'whatsapp', name: 'Whatsapp', icon: 'fab fah fa-lg fa-whatsapp', color: '#25d366' },
      //  { network: 'wordpress', name: 'Wordpress', icon: 'fab fah fa-lg fa-wordpress', color: '#21759b' },
       // { network: 'xing', name: 'Xing', icon: 'fab fah fa-lg fa-xing', color: '#026466' },
      //  { network: 'yammer', name: 'Yammer', icon: 'fab fah fa-lg fa-yammer', color: '#0072c6' },
      //  { network: 'fakeblock', name: 'Custom Network', icon: 'fab fah fa-lg fa-vuejs', color: '#41b883' }
      ]
        
         
    }),
    mounted() {


    },
    computed: {
        
  
    }
}

</script>