<template>
  <div>
    <div class="latest_polls_sec">
      <div class="latest_polls_cnt">
        <!-- <div class="polls_title">
          <h3>Latest Polls</h3>
          
        </div> -->
         <div class="home_main_slider polls_block_wrap" v-if="polls.length>0">
          <div v-for="(item, ind) in polls" :key="ind" class="polls_block_list">
            <pollItem  :pollItem="item"  @reloadpollsList="reloadpollsList" />
          </div>

         
        </div>
          
   
        
      </div>
    </div>
  </div>
</template>



<script> 
import pollItem from "./pollItem.vue"; 
import moment from "moment";

export default {
  components: { 
    pollItem,
  },
  methods: {
       reloadpollsList(){
           
            this.$emit("reloadpollsList")

        },
    
  },
  props:{
      polls:{
          type:Array,
          default:new Array()
      }
  },
  data: () => ({
  
 
   
  }),
  mounted() {
     
    
  
  },
  computed: {},
};
</script> 
