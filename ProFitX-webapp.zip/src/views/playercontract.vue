<template>
  <div class="content-body">
    <sidebar v-if="player!=null" :player="player" />
    <div class="content-wrapper">
      <div class="athlete_content_wrap">
        <v-row>
          <v-col>
            <player-details v-if="player"  :player="player" />
          </v-col>
        </v-row>
        <div class="nodataBox" v-if="player && player.RTC == null">

                No Data Available
            </div>
            <div class="athlete_body_content" v-if="player && player.RTC">
          <v-row>
            <v-col>
              <playerContract  v-if="player" :player="player" />
            </v-col>
          </v-row>
            <v-row v-if="checkWidgetsPermessions('FINANCIAL_IMPACT')">
          <v-col><financial-impact v-if="player!=null"  :player=player  /></v-col>
      </v-row>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import playerDetails from "@/views/components/playerDetails.vue";
import playerContract from "@/views/components/playerContract.vue";
import Sidebar from "@/layouts/components/Sidebar.vue";
import financialImpact from "@/views/components/financialImpact.vue";
export default {
  components: {
    playerDetails,
    playerContract,
    financialImpact,
    Sidebar
  },

  methods: {
   
 getplayers() {
            this.isloading = true
            this.serach = {
                "page": 1,
                "perpage": 1,
                "matcher": {
                    "playerId": this.$route.params.id
                }
            };

            this.$store
                .dispatch("getplayerdetails", this.serach)
                .then(response => {
                    if (response.error) {
                        Object.assign(this.formerrors, {
                            msg: response.error.message
                        });
                    } else {

                                                  let nitem = response.data.result.list[0];


    var totalgames = 0
                            
                            nitem['seasons'].forEach(function(tem){

                                totalgames =totalgames+tem.GP;
                            })
                            nitem.totalgames = totalgames;
                            
                            this.player = nitem;



                    }
                    var self = this;
                    setTimeout(function () {

                        self.isloading = false;
                    }, 1000)

                });

        }
  },
  mounted() {
    this.getplayers();
  },
  data() {
    return {
      player: null
    };
  }
};
</script>

<style>
</style>