
<template>
  <div v-if="gamedata">
    <div class="prev_matches_sec">
      <div class="prev_matches_tabs">
        <ul>
          <li>
            <a   @click="awaytab = 1;gototab(1)" v-bind:class="{ active: awaytab == 1 }"
              >Player Performance</a
            >
          </li>
          <li>
            <a @click="awaytab = 2;gototab(2)" v-bind:class="{ active: awaytab == 2 }"
              >
              <template v-if="gamedata.Status != 'InProgress'">
              Pre-Match Analysis
              </template>
                    <template v-else>
              Real-Time Analysis
              </template>
              
              
              </a
            >
          </li>
          <li>
            <a   @click="awaytab = 3;gototab(3)" v-bind:class="{ active: awaytab == 3 }"
              >Best Combinations</a
            >
          </li>
          <li>
            <a @click="awaytab = 4;gototab(4)" v-bind:class="{ active: awaytab == 4 }"
              >Performance Attributes</a
            >
          </li>
        </ul>
      </div>
      <div class="prev_matches_cnt">
        <div  id="gototab1"  >
          <label class="tab__title">Player Performance</label>
          <probpeform v-if="gamedata.Status != 'InProgress'" :game="gamedata" :gameId="gamedata.gameid" />
          <probpeformlive v-if="gamedata.Status == 'InProgress'" :game="gamedata" :gameId="gamedata.gameid" />

          
        </div>
        <div id="gototab2" >
          <label class="tab__title" v-if="gamedata.Status != 'InProgress'" >Pre-Match Analysis</label>
          <label class="tab__title" v-if="gamedata.Status == 'InProgress'" >Real-Time Analysis</label>

          <teamperformance v-if="gamedata.Status != 'InProgress'" :game="gamedata" :gameId="gamedata.gameid" />
           <teamperformancelive v-if="gamedata.Status == 'InProgress'" :game="gamedata" :gameId="gamedata.gameid" />
        </div>
        <div id="gototab3" >
          <label class="tab__title">Best Combinations</label>
          <playersynergycombo :gamedata="gamedata" :gameId="gamedata.gameid"  />
        </div>
          <div  id="gototab4" >
          <label class="tab__title">Performance Attributes</label>
          <bestcombos :gamedata="gamedata" :gameId="gamedata.gameid"  />
        </div>
        
      </div>
    </div>
  </div>
</template>

<script>
import moment from "moment";
import probpeform from "@/views/components/probteamperformance.vue";

import probpeformlive from "@/views/components/probteamperformancelive.vue";
import teamperformance from "@/views/components/teamperformancepro.vue";
import playersynergycombo from "./synergyprematch.vue";
import bestcombos from "./bestcomboprematch.vue";
import teamperformancelive from "@/views/components/teamperformanceprolive.vue";

export default {
  components: {
    probpeform,
    teamperformance,
    teamperformancelive,
    playersynergycombo,
    bestcombos,
    probpeformlive
  },
  data() {
    return {
      awaytab: 1,
      angle: "246",
      color1: "red",
      color2: "blue",
    };
  },
  computed: {
    startsIn() {
      if (
        moment
          .utc(this.gamedata.Game.DateTimeUTC + ".128Z")
          .isAfter(moment().utc())
      ) {
        return moment
          .utc(this.gamedata.Game.DateTimeUTC + ".128Z")
          .diff(moment().utc(), "hours");
      }
      return moment()
        .utc()
        .diff(moment(this.gamedata.Game.DateTimeUTC), "hours");
    },
    homebackgroundcolors() {
      if (this.gamedata) {
        return `transparent linear-gradient(${this.angle}deg, #${this.gamedata.HomeTeam.PrimaryColor} 0%, #${this.gamedata.HomeTeam.SecondaryColor} 100%) 0% 0% no-repeat padding-box`;
      }
      return "";
    },
    awaybackgroundcolors() {
      if (this.gamedata) {
        return `transparent linear-gradient(${this.angle}deg, #${this.gamedata.AwayTeam.PrimaryColor} 0%, #${this.gamedata.AwayTeam.SecondaryColor} 100%) 0% 0% no-repeat padding-box`;
      }
      return "";
    },
  }, mounted() {

        window.addEventListener('scroll', this.updateScroll);
    },
    methods: {
      updateScroll(){
        if(document.getElementById("gototab1")){
            if (window.scrollY > document.getElementById("gototab1").offsetTop-160) {
                this.awaytab = 1;
            } 
            if (window.scrollY > document.getElementById("gototab2").offsetTop-160) {
                this.awaytab = 2;
            } 
                if (window.scrollY > document.getElementById("gototab3").offsetTop-160) {
                this.awaytab = 3;
            } 

                if (window.scrollY > document.getElementById("gototab4").offsetTop-170) {
                this.awaytab = 4;
            } 


        }
            
      },
        
      gototab(tab){
       var ele =  document.getElementById("gototab"+tab);
//ele.scrollIntoView({behavior: "smooth", block: "start"});
  var top = ele.offsetTop;
    //window.scrollTo(0, top)
     window.scrollTo({ top: top-150, behavior: 'smooth' });
      }
    },
  props: {
    gamedata: null,
    gameId: null,
  },
};
</script>

