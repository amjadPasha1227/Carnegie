<template>
   <div class="profile_section" @click="snackbar =false">
        <div class="prfile_nav">
           <menuItems />
        </div>
        <div class="profile_body">
            <div class="profile_dp">
            
                <figure>
                    <label><img :src="checkProperty(getProfileData,'profilePicture')" @error="getProfilePhoto($event )"></label>
                    
                    <file-upload v-model="documents" class="file-upload-input"
                            :accept="'.jpg,.jpeg,.png'"  :name="'logo'" data-vv-as=" documents"
                            :multiple="false" @input="upload(documents)" >
                             <span @click="documents=[]"><v-icon>mdi-border-color</v-icon></span>
                            </file-upload>
                </figure>
                <figcaption>{{checkProperty(getProfileData ,"name")}}</figcaption>
            </div>
            <div class="form_section">
            
                <form v-on:submit.prevent>
                    <div class="row">
                        <div class="col col-sm-6">
                            <div class="form-group">
                                <label class="form_label">Email</label>
                                <input type="text" class="form_control" name="email" :disabled="true"  v-validate="'required|email'" v-model="profileData.email">
                                <!-- <span class="error-text" v-show="errors.has('email')">{{ errors.first("email") }}</span> -->
                            </div>
                        </div> 
                        <div class="col col-sm-6">
                            <div class="form-group">
                                <label class="form_label">First Name</label>
                                <input type="text" class="form_control" name="First Name"  v-validate="'required'" v-model="profileData.firstName">
                               <span class="error-text" v-show="errors.has('First Name')">{{ errors.first("First Name") }}</span>
                            </div>
                        </div>    
                    </div> 

                    <div class="row">
                        <div class="col col-sm-6">
                            <div class="form-group">
                                <label class="form_label">Last Name</label>
                                <input type="text" class="form_control" name="Last Name"  v-validate="'required'" v-model="profileData.lastName">
                               <span class="error-text" v-show="errors.has('Last Name')">{{ errors.first("Last Name") }}</span>
                            </div>
                        </div> 
                        <div class="col col-sm-6">
                            <div class="form-group">
                                <label class="form_label">Contact Number <small>(Optional)</small></label>
                                <input type="text" v-on:keypress="checkPhonenumber($event)" class="form_control" name="Phone"  v-validate="'required'|'max:15'|'min:10'" v-model="profileData.phoneNo">
                               <span class="error-text" v-show="errors.has('Phone')">{{ errors.first("Phone") }}</span>
                            
                               <!-- <VuePhoneNumberInput 
                                    autocomplete="nope"
                                default-country-code="US"
                                :no-example="true"
                                :no-country-selector="false"
                                @update="updatePhoneNumber"  
                                :required="true"
                                v-model="profileData.phoneNo" />-->
                            
                            </div>
                        </div>    
                    </div>
                    <div class="form_actions">
                        <button class="save-btn" :disabled="checkUpdateProfile"  @click="updateProfile()" href="javascript:;">
                            Update Details
                        </button>
                    </div> 
                    <div class="devider"></div>
                    <div class="form_title">Change Password</div>
                    <div class="row">
                        <div class="col col-sm-4">
                            <div class="form-group">
                                <label class="form_label">Current Password</label>
                                <input v-validate="'required'" name="current password" type="password" class="form_control" ref="cpassword" v-model="currentPassword" >
                                <span class="error-text" v-show="errors.has('current password')">{{ errors.first("current password") }}</span>
                        
                            </div>
                        </div> 
                        <div class="col col-sm-4">
                            <div class="form-group">
                                <label class="form_label">New Password </label>
                                 <input v-validate="'required'" name="password" type="password" class="form_control" ref="npassword" v-model="newPassword" >
                                 <span class="error-text" v-show="errors.has('password')">{{ errors.first("password") }}</span>
                        
                             </div>
                        </div>
                        <div class="col col-sm-4">
                            <div class="form-group">
                                <label class="form_label">Confirm Password </label>
                                <input v-validate="'required|confirmed:npassword'" name="confirm password" type="password" class="form_control" ref="cfpassword" v-model="confirmPassword" >
                                 <span class="error-text" v-show="errors.has('confirm password')">{{ errors.first("confirm password") }}</span>
                            </div>
                        </div>    
                    </div>  
                    <div class="form_actions">
                        <button :disabled="checkpasswordUpdateform || updatingpwd" class="save-btn"  @click="updatePassword()" href="javascript:;">
                            Change Password 
                        </button>
                    </div>
                </form>                                
            </div>
        </div>

<!-- <v-snackbar
v-model="snackbar"
:vertical="vertical"
    right
shaped
top 
>
{{ text }}

<template v-slot:action="{ attrs }">
    <v-btn
    color="indigo"
    text
    v-bind="attrs"
    @click="snackbar = false"
    >
    Close
    </v-btn>
</template>
</v-snackbar> -->
<snakebar v-if="snackbar" :snackbar="snackbar" :msg="text" :isError="isError" />
   
                <div class="loading-page" v-if="isloading">
                <figure>
                    <img src="@/assets/images/loader.gif">
                </figure>Loading
            </div>
                
   </div>
</template>

 

<script>
 
import FileUpload from "vue-upload-component/src";
import _ from "lodash"
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import menuItems from "@/views/components/menuItems.vue";
 import snakebar from "@/views/components/snakebar.vue";
 
export default {
    components: {
        snakebar,
        FileUpload,
        //VuePhoneNumberInput,
        menuItems
        
    },
  methods:{
      initUpdateProfile(){
            this.text= '';
           this.snackbar = false;
           this.isError =false;
           let udata = _.cloneDeep(this.user);
            //"phoneNo": "",
            //this.profileData= {  "firstName": this.user['firstName'],"middleName": this.user['middleName'], "lastName":  this.user['lastName'], "name":  this.user['name'], "email": this.user['email'] ,"phoneCode":this.user['phoneCode'] ,"phoneNo":this.user['phoneCode']};
                this.profileData['firstName'] = this.checkProperty(udata ,"firstName");
                this.profileData['middleName'] = this.checkProperty(udata ,"middleName");
                this.profileData['lastName'] = this.checkProperty(udata ,"lastName");
                this.profileData['name'] = this.checkProperty(udata ,"name");
                this.profileData['email'] = this.checkProperty(udata ,"email");
                this.profileData['phoneNo'] = this.checkProperty(udata ,"phoneNo");
                this.profileData['phoneCode'] = this.checkProperty(udata ,"phoneCode");
                this.profileData['profilePicture'] = this.checkProperty(udata ,"profilePicture");
            

            this.$validator.reset();
        },
        updateProfile(){
            
            let postData = this.profileData;
            postData['userId'] = "userID";
            this.isloading = true;

             this.$store.dispatch("updateProfile", this.profileData).then((response) => {
                  this.isloading = false;
              //alert(JSON.stringify(response));
                this.snackbar = true;
                this.isError =false;
                this.text = response.message;
                this.user = JSON.parse(localStorage.getItem('user'));
                                
                this.profileData['firstName'] = this.checkProperty(this.user ,"firstName");
                this.profileData['middleName'] = this.checkProperty(this.user ,"middleName");
                this.profileData['lastName'] = this.checkProperty(this.user ,"lastName");
                this.profileData['name'] = this.checkProperty(this.user ,"name");
                this.profileData['email'] = this.checkProperty(this.user ,"email");
                this.profileData['phoneNo'] = this.checkProperty(this.user ,"phoneNo");
                this.profileData['phoneCode'] = this.checkProperty(this.user ,"phoneCode");
                 this.$validator.reset();

                       
            })
            .catch((err) => {
                this.text =err;
                 this.isError = false
                this.snackbar = true;
               
                        
            });
        },
      
        updatePassword(){
             let udata = _.cloneDeep(this.user);
             var self = this;
            let postData= { "userId":udata['_id'],email :udata['email'],currentPassword:this.currentPassword, newPassword:this.newPassword,confirmPassword:this.confirmPassword};
           // alert(JSON.stringify(postData)); updateProfilePassword
            this.updatingpwd =true;
            this.isloading = true;
             this.$store.dispatch("updateProfilePassword", postData).then((response) => {
               this.updatingpwd =false;
               this.isloading = false;
                this.text = response.message;
                 this.isError = false;
                this.snackbar = true;
                this.currentPassword = '';
                this.newPassword ='';
                this.confirmPassword = '';
                this.$validator.reset();

                 setTimeout(function () {

               this.$store.dispatch("logout").then(() => {
                    self.$router.go('/pricing?show=login');
                });

            }, 2000)
                 
                
                                     

            })
            .catch((err) => {
                
                this.isloading = false;
                this.updatingpwd =false;
                this.text =err;
                 this.isError = true
                this.snackbar = true;
                this.$validator.reset()
                        
            });

        },
      upload(files){
           let model = _.cloneDeep(files);
           this.documents =[];
          
          let temp_count = 0;
          let formData = new FormData();
                    
          let mapper = model.map(
              item =>
              (item = {
                  name: item.name,
                  file: item.file ? item.file : null,
                  path: item.url ? item.url : "",
                  url:item.url ? item.url : "",
                  extn: item.name.split('.').pop(),
                  mimetype: item.type ? item.type : item.mimetype,
                  
              })
          );
         
           //var ext = mapper[0].extn.split('.').pop();
           
             
              if (mapper.length > 0) {
                  this.isloading =true;
              mapper.forEach((doc, index) => {
                  formData.append("files", doc.file);
                  formData.append("secureType", "public");
                  this.$store.dispatch("uploadS3File", formData).then(response => {
                      temp_count++;
                   
                      response.data.result.forEach(urlGenerated => {
                          try{
                          if(_.has(urlGenerated ,"path") && !( _.has(urlGenerated ,"url"))){
                              urlGenerated['url'] = urlGenerated ['path'];
                              
                          }
                           if(_.has(urlGenerated ,"url") && !( _.has(urlGenerated ,"path")) ){
                              urlGenerated['path'] = urlGenerated ['url'];
                              
                          }
                           
                            
                            this.$store.dispatch("updateProfilePicture" ,{"profilePicture":urlGenerated['path'] ,"userId":this.user['_id']})
                            .then((res)=>{
                                this.isloading =false;
                            })
                            
                          }catch(err){
                              //alert(err);
                              this.isloading =false;
                          }
                          
                               
                          if (temp_count >= mapper.length) {
                               
                             this.documents=[];
                          }

                          doc.url = urlGenerated;
                          delete doc.file;
                          mapper[index] = doc;

                      });
                  });

              });
              model.splice(0, mapper.length, ...mapper);
          }
            
      
      },
      updatePhoneNumber(item ) {
            if (item.isValid) {
                this.profileData.phoneCode = item.countryCallingCode;
                this.profileData.phoneNo = item.nationalNumber;
            }
        }

  },  
  data() {
        return { 
            isloading:false,
            documents:[],
            user: null,
           snackbar:false,
           isError:false,
           vertical: true,
           text: '',
           currentPassword:'',
            newPassword:'',
            confirmPassword:'',
            profileData:{ "firstName": "","middleName": "", "lastName": "", "name": "", "email": "", "password": "","phoneNo": "", "phoneCode": ""},
            updatingpwd:false
        };
 },mounted(){
      this.setPageTitle("ProFitX - Profile");
     this.user = this.$store.state.user;
     this.initUpdateProfile();
 },
 computed: {
     getProfileData(){
         return this.$store.state.user;
     },

     checkUpdateProfile(){
         //profileData:{ "firstName": "","middleName": "", "lastName": "", "name": "", "email": "", "password": "","phoneNo": "", "roleId": "6"},
        if(
        //(this.profileData['phoneNo'] =='' || this.profileData['phoneNo'] ==null || this.profileData['phoneNo'] ==undefined) ||
          (this.profileData['firstName'] =='' || this.profileData['firstName'] ==null || this.profileData['firstName'] ==undefined)
       // || (this.profileData['middleName'] =='' || this.profileData['middleName'] ==null || this.profileData['middleName'] ==undefined)
        || (this.profileData['lastName'] =='' || this.profileData['lastName'] ==null || this.profileData['lastName'] ==undefined)


        ){
            
            return true;

        }else{
            return false;

        }
        
     },
     checkpasswordUpdateform(){

         
        if(( this.currentPassword=='' || this.currentPassword ==null) 
          || (  this.newPassword=='' || this.newPassword ==null) 
          || ( this.confirmPassword=='' || this.confirmPassword==null) 
          || (this.confirmPassword !=this.newPassword )
          ){
            return true;
        }else{
            return false;
        }

     }

 }
}
</script>

<style>

</style>
