<template>
<div>
    <v-row>
        <probabilityPeriod @reloadProb="reloadProb"></probabilityPeriod>
    </v-row>
    <div class="teamProbability_sec">
              <div class="loading-page" v-if="isloading">
          <figure>
            <img src="@/assets/images/loader.gif" />
          </figure>
          Loading
        </div>
        <template v-else>

              <v-row>

            <template v-for="(game,index) in gameslist" >

            <teamProbability :gamedata="game" :key="index"></teamProbability>
            
          

            </template>
           
        </v-row>
        </template>

      
    </div>
     
</div>
</template>

<script>
import teamProbability from "@/views/components/teamProbability.vue";
import probabilityPeriod from "@/views/components/probabilityPeriod.vue";
 import moment from "moment";

export default {
    name: "synergy-seacrh",
    components: {
       teamProbability,
       probabilityPeriod
    },
        methods: {
   reloadProb(date){
       if(!date.reload){
       this.isloading = true;

       }
      this.$store.dispatch("gettodayprobability2", {gamedate:date.date,gameenddate:date.edate}).then((response) => {
         this.gameslist = []
         var _games = []
         if (response && response.length > 0){
              
               response.forEach(element => {
              var _e = element;
                       _e["sortdate"] = moment(_e.Game.DateTimeUTC)
             _games.push(_e)


          });
         _games = this.lodash.orderBy(_games,"sortdate",["asc"])
           this.gameslist = _games;
       this.isloading = false;

         }else{
             var _aresponse = JSON.parse(response)
            
               _aresponse.forEach(element => {
              var _e = element;
              _e["awayteamdata"] = JSON.parse(_e.awayteamdata)
              _e["cheadtoheada"] = JSON.parse(_e.cheadtoheada)
              _e["headtoheada"] = JSON.parse(_e.headtoheada)
              _e["headtoheadh"] = JSON.parse(_e.headtoheadh)
              _e["hometeamdata"] = JSON.parse(_e.hometeamdata)
               _e["gamedatee"] = moment(_e.gamedate).add(150,'minutes')
               _e["sortdate"] = moment(_e.gamedate)

             _games.push(_e)
          });
        
            _games = this.lodash.sortBy(_games,"sortdate")
           this.gameslist = _games;
    if(!date.reload){
       this.isloading = false;

       }
         }
       
      })


        }

    },
    mounted() {

     

         


    },
    data() {
        return {
            isloading:true,
            gameslist:null
            
        };
    }
};
</script>
