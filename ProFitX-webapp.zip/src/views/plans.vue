<template>
  <section class="pricing_banner pricing_bannerv2">
    <div class="container">
      <h3 class="subtitle" v-if="!upgradeplan">Pricing</h3>
      <!-- <h5 class="tag_line" v-if="!upgradeplan" data-aos="fade-up" data-aos-delay="500">Powerful technology. Simple Pricing. Everything you need to see the evolution of the athlete with front office optics.</h5> -->
      <div class="pricing_plans_wrap">
        <div class="pricing_plans">
          <div class="pricing_title">
            <h4>Athlete Pass</h4>
            <h5><strong>In-Season </strong> Rest of the Season (2021-22)</h5>
          </div>

          <v-container>
            <v-row v-if="!freq">
              <v-col class="plan-list">
                <div
                  class="plans_block plan1"
                  v-on:click="changeplan(1)"
                  v-bind:class="{ active: selectedplan == 1 }"
                  data-aos="fade-up"
                  data-aos-delay="800"
                >
                  <div class="plans_block_cnt">
                    <label><b>15 </b> Athletes</label>
                    <h5><sub>$</sub>{{ p1amount }}</h5>
                    <!-- <button class="subscribe_btn">Subscribe</button> -->
                    <button class="subscribe_btn" id="subscribe_btn1">
                      <!-- {{seasontype}} -->
                      Choose
                    </button>
                  </div>
                </div>
              </v-col>
              <v-col class="plan-list">
                <div
                  class="plans_block plan2"
                  v-on:click="changeplan(2)"
                  v-bind:class="{ active: selectedplan == 2 }"
                  data-aos="fade-up"
                  data-aos-delay="800"
                >
                  <div class="plans_block_cnt">
                    <label><b>20</b> Athletes</label>
                    <h5><sub>$</sub>{{ p2amount }}</h5>
                    <button class="subscribe_btn" id="subscribe_btn2">
                      <!-- {{seasontype}} -->
                      Choose
                    </button>
                  </div>
                </div>
              </v-col>
              <v-col class="plan-list">
                <div
                  class="plans_block plan3"
                  v-on:click="changeplan(3)"
                  v-bind:class="{ active: selectedplan == 3 }"
                  data-aos="fade-up"
                  data-aos-delay="800"
                >
                  <div class="plans_block_cnt">
                    <label><b>25</b> Athletes</label>
                    <h5><sub>$</sub>{{ p3amount }}</h5>
                    <button class="subscribe_btn" id="subscribe_btn3">
                      <!-- {{seasontype}} -->
                      Choose
                    </button>
                  </div>
                </div>
              </v-col>
            </v-row>
            <v-row class="pdr-6 pdl-6">
              <div class="offseasson_block">
                <h3>Off-Season Pass</h3>
                <p>Offers access to financial models on your favorite players. Available August 2022</p>
              </div>
            </v-row>
          </v-container> 
        </div>
         <!-- <div class="probability_platform pricing_banner pricing_bannerv2">
          <h3>Sports Probability</h3>

          <p>
            The Sports Probability Platform (SPP) is a predicative outcome
            platform that offers real-time pre-match and live game predictions
            for the next 5 days.
          </p>

                <div>
        <div class="pricing_plans">
        

             <v-container>
            <v-row >
              <v-col class="plan-list">
                <div
                  class="plans_block plan1 "
                  v-on:click="onSelectProbabilityPlan(1)"
                  v-bind:class="{ active: selectedprobabilityPlan == 1 }"
                  data-aos="fade-up"
                  data-aos-delay="800"
                >
             <div class="plans_block_cnt">
                    <label><b>Season</b> </label>
                      <p style="font-size:10px"> Ends in June 2022</p>
                    <h5><sub>$</sub>250</h5>
                    <button class="subscribe_btn" id="subscribe_btn3">
                      
                      Choose
                    </button>
                   
                  </div>
                </div>
              </v-col>

              <v-col class="plan-list">
                <div
                  class="plans_block plan3"
                  v-on:click="onSelectProbabilityPlan(2)"
                  v-bind:class="{ active: selectedprobabilityPlan == 2 }"
                  data-aos="fade-up"
                  data-aos-delay="800"
                >
                  <div class="plans_block_cnt">
                    <label><b>Monthly</b> </label>
                      <p style="font-size:10px">Recurring - Ends in June 2022</p>
                    <h5><sub>$</sub>{{ probabilityAmount }}</h5>
                    <button class="subscribe_btn" id="subscribe_btn3">
                      
                      Choose
                    </button>
                   
                  </div>
                </div>
              </v-col>
            </v-row>
            <v-row class="pdr-6 pdl-6">
              <div class="offseasson_block" >
                <h3>Free Trial</h3>
                <p>
Free 2-day trial of the most dynamic sports technology on the market              </p>

              </div>
            </v-row>
          </v-container>

    
<small class="notes">

* If you don’t cancel before the end of the free trial, we will automatically bill you for the subscription fee after the trial ends. Free trials require a credit card that automatically converts to active account unless canceled before trial period ends.
</small>

          </div>
      </div>
        
   
        </div>  -->
      </div>
      <v-row v-if="!loadedFromPopup">
        <v-col>
          <div class="league_block" data-aos="fade-up">
            <div class="league_block_cnt">
              <div class="league_block_left">
                <h5>Looking for League Pass or Custom Plan?</h5>
                <p>
                  The NBA Athledex/League Pass is the most versatile and
                  complete package. This option delivers insights and analysis
                  into the athlete and team dynamic by evaluating performance
                  and financial information within these five areas.
                </p>
                <ul>
                  <li>Team Dynamic</li>
                  <li>Performance Trajectory</li>
                  <li>Player DNA</li>
                  <li>Contract Analysis</li>
                  <li>Player Development</li>
                </ul>
              </div>
              <div
                @click="
                  et = 2;
                  enquiryApp = true;
                  enquirytype = 'Request For League Pass';
                "
              >
                <a href="javascript:;" class="gradient_btn"
                  ><span>Contact</span></a
                >
              </div>
            </div>
          </div>
        </v-col>
      </v-row>
      <v-row v-if="finalplan || probabilityPlan">
        <div class="selected_plans">
          <div class="selected_plans_cnt">
            <div class="selected_list">
              <div class="athletes_selection" v-if="finalplan">
                <p>
                  In Season<br />
                  {{ finalplan["criteria"][0]["qty"] }}
                  <span>{{ finalplan["criteria"][0]["label"] }}</span>
                </p>
                <label
                  ><sub>$</sub>{{ finalplan["criteria"][0]["amount"] }}</label
                >

                <em
                  ><img
                    src="@/assets/images/close.svg"
                    @click="removeSelectedPlan()"
                /></em>
              </div>
              <template v-if="probabilityPlan">
                <div class="athletes_selection">
                  <p>Probability Pass</p>
                  <label
                    ><sub>$</sub>
                    {{ probabilityPlan["criteria"][0]["amount"] }}</label
                  >
                  <em
                    ><img
                      src="@/assets/images/close.svg"
                      @click="removeProbabilityPlan()"
                  /></em>
                </div>

                 
              </template>
            </div>
            <div class="selected_actions">
              <v-progress-circular
                v-if="hitContinueTosubscribe"
                indeterminate
                size="25"
              ></v-progress-circular>
              <button
                v-if="loadedFromPopup"
                class="skip"
                id="subscribe_skip"
                @click="skipPaymentProcess()"
              >
                Skip
              </button>
              <button
                class="gradient_btn"
                id="subscribe_Continue"
                @click="continueTosubscribe()"
              >
                <span>Continue</span>
              </button>
            </div>
          </div>
        </div>
      </v-row>
    </div>
    <v-dialog
      v-if="logintoApp"
      v-model="logintoApp"
      max-width="400"
      content-class="items_middle"
      fullscreen
      persistent
    >
      <div
        class="dialog_body signup"
        v-bind:class="{ expandsignup: loginexpand }"
      >
        <v-btn
          color="primary"
          text
          @click="
            initUser();
            logintoApp = false;
          "
          class="close-btn close-btn2"
        >
          <v-icon>mdi-close</v-icon>
        </v-btn>
        <login-temp
          @securityalert="securityalert"
          @showFP="showFP"
          @showSignup="proceedtocard"
        />
      </div>
    </v-dialog>

    <v-dialog
      v-if="forgotpassword"
      v-model="forgotpassword"
      max-width="400"
      content-class="items_middle"
      fullscreen
      persistent
    >
      <div class="dialog_body">
        <v-btn
          color="primary"
          text
          @click="
            initUser();
            logintoApp = false;
          "
          class="close-btn close-btn2"
        >
          <v-icon>mdi-close</v-icon>
        </v-btn>
        <forgot-password />
      </div>
    </v-dialog>

    <v-dialog
      v-if="signuptoApp"
      v-model="signuptoApp"
      max-width="400"
      fullscreen
      persistent
    >
      <div class="dialog_body signup signup_body">
        <v-btn
          color="primary"
          text
          @click="
            securityalert();
            initUser();

            resetSelectedPlans();
            signuptoApp = false;
          "
          class="close-btn close-btn2"
        >
          <v-icon>mdi-close</v-icon>
        </v-btn>
        <signup-temp
          @showResult="showResult"
          @showLogin="logintoApp = true"
          :plan="finalplan"
          :selectedPlans="selectedPlans"
          @updateNewUser="updateNewUser"
        />
      </div>
    </v-dialog>

    <v-dialog
      v-if="enquiryApp"
      v-model="enquiryApp"
      max-width="400"
      class="card_dialog"
      fullscreen
      persistent
    >
      <div class="dialog_body signup">
        <v-btn
          color="primary"
          text
          @click="
            initUser();
            enquiryApp = false;
          "
          class="close-btn close-btn2"
        >
          <v-icon>mdi-close</v-icon>
        </v-btn>
        <enquiryTemp
          :selectedplan="finalplan"
          :et="et"
          :enquirytype="enquirytype"
          @closeEnquiry="closeEnquiryForm"
          @showFP="showFP"
          @showSignup="proceedtocard"
        />
      </div>
    </v-dialog>

    <success-popup
      @closePopup="showoverlay = false"
      :closebutton="closebutton"
      :showoverlay="showoverlay"
      :title="messagetitle"
      :description="messagecontent"
    />
    <snakebar
      v-if="snackbar"
      :snackbar="snackbar"
      :msg="text"
      :isError="isError"
    />

    <v-overlay v-if="showLoading">
      <v-progress-circular indeterminate size="64"></v-progress-circular>
    </v-overlay>

    <v-dialog
      v-if="openSetPassword"
      v-model="openSetPassword"
      max-width="400"
      fullscreen
      persistent
    >
      <setPasswordPopup
        ref="setPasswordPopup"
        :newUser="newUser"
        @setPasswordSuccess="setPasswordSuccess"
        @closedSetPassword="closedSetPassword"
      />
    </v-dialog>

    <signupAlert  v-if="showsignupAlert" />
  </section>
</template>

<script>
import enquiryTemp from "@/views/enquiry.vue";
import loginTemp from "@/views/login.vue";
import signupTemp from "@/views/sign-up.vue";
import forgotPassword from "@/views/forgotpassword.vue";
import moment from "moment";
import successPopup from "@/views/success.vue";
import snakebar from "@/views/components/snakebar.vue";
import setPasswordPopup from "@/views/setPasswordPopup.vue";
import _ from "lodash";
import signupAlert from "@/views/common/signupalert.vue";

export default {
  props: {
    userData: null,
    loadedFromPopup: {
      type: Boolean,
      default: false,
    },
    defaultselected: null,
    shwologin: null,
    shwoSignup: null,
    upgradeplan: null,
    firsttime: null,
  },
  watch: {
    shwoSignup: function (value) {
      if (value) {
        this.signuptoApp = true;
      }
    },
    shwologin: function (value) {
      if (value) {
        this.logintoApp = true;
      }
    },
  },
  data() {
    return {
      showsignupAlert:false,
      newUser: {
        pin: "",
        action: "set-password",
        newPassword: "",
        confirmPassword: "",
        userId: "",
        notUsingEmailLink: true,

        acceptedTerms: false,
        activateUser: true,
        firstName: "",
        middleName: "",
        lastName: "",
        name: "",
        email: "",
        phoneCode: "",
        phoneNo: "",
        roleId: 4,
        passType: "",
        athletes: [],
        athletescount: 0,
        paymentAmt: 0,
        frequency: null,
      },
      openSetPassword: false,

      probabilityPlan: null,
      selectedprobabilityPlan:null,
      hitContinueTosubscribe: false,
      financial: false,
      performance: true,
      seasontype: null,
      et: null,
      enquirytype: null,
      closebutton: false,
      showLoading: false,
      enquiryApp: false,
      snackbar: false,
      text: null,
      isError: false,
      showoverlay: false,
      messagetitle: null,
      messagecontent: null,
      logintoApp: false,
      forgotpassword: false,
      signuptoApp: false,
      planselected: false,
      selectedplan: 1,
      p1amount: 25,
      p2amount: 35,
      p3amount: 40,
      probabilityAmount: 100,
      freq: false,
      inseason: true,
      offseason: false,
      planslist: null,
      finalplan: null,
      loggedinview: false,
      showcardinfo: false,
      userplan: null,
      usercurrentPlan: null,
      cuser: null,
      loginexpand: false,
      selectedPlans: {
        plan: null,
        probabilityPlan: null,
      },
      formmessage: {
        msg: "",
      },
      formerrors: {
        msg: "",
      },
    };
  },
  components: {
    signupAlert,
    enquiryTemp,
    loginTemp,
    signupTemp,
    forgotPassword,
    successPopup,
    setPasswordPopup,
  },

  computed: {},
  methods: {
    resetSelectedPlans() {
      this.selectedPlans = {
        plan: null,
        probabilityPlan: null,
      };
      this.finalplan = null;
      this.probabilityPlan = null;
      this.selectedplan = 0;
      this.signuptoApp = false;

      this.hitContinueTosubscribe = false;
    },
    cardProcessing() {
      console.log("Card Processing");

      this.showResult();
      this.openSetPassword = false;
      this.signuptoApp = false;
      let payLoad = {
        subscriber: {
          name: "",
          email: "",
          phone: "",
          phoneCode: "+1",
        },
      };

      payLoad["subscriber"] = this.newUser;
      payLoad["subscriber"]["name"] =
        this.newUser["firstName"] +
        " " +
        this.newUser.middleName +
        " " +
        this.newUser["lastName"];
      this.$store
        .dispatch("subscription/getSelectedPlan", payLoad)
        .then((oldPlan) => {
          this.$router.push("/plan");
        });
    },

    login() {
      Object.assign(this.formerrors, { msg: "" });
      let self = this;
      let obj = { email: "", password: "" };
      obj["email"] = this.newUser.email;
      obj["password"] = this.newUser.newPassword;

      this.$store
        .dispatch("login", obj)
        .then((response) => {
          if (response.error) {
            this.showResult();
            Object.assign(self.formerrors, {
              msg: response.error.message,
            });
          } else {
            self.$router.push("/plan");

            self.cardProcessing();
            if (this.loadedFromPopup) {
              this.$emit("closePlanPopup");
            }
          }
        })
        .catch((err) => {
          this.showResult();
          Object.assign(this.formerrors, { msg: err });
        });
    },

    setPasswordSuccess(user) {
      this.newUser = user;
      this.login();
    },
    closedSetPassword() {
      this.openSetPassword = false;
      this.showResult();
    },
    updateNewUserPlansAndPricing(user) {
      this.newUser = user;
    },

    updateNewUser(user) {
      this.newUser = user;

      if (_.has(this.newUser, "pin") && _.has(this.newUser, "userId")) {
        this.signuptoApp = false;
        this.processSubscription();
      }
    },

    processSubscription() {
      let self = this;
      if (this.finalplan) {
        this.newUser.passType = this.finalplan.uniqueId;
        this.newUser.athletescount = this.finalplan.criteria[0].qty;
        this.newUser.frequency = this.finalplan.frequencyDetails.__id;
        this.newUser.paymentAmt = this.finalplan.criteria[0].amount;
      }
      const obj = {
        email: this.newUser.email,
        password: this.newUser.newPassword,
      };
      const subobj = {
        email: this.newUser.email,
        name: this.newUser.firstName,
        listId: 36008,
      };
      // this.$store.dispatch("subscribetoemaillist", subobj).then((response) => {});

      var subscribepayLoad = {
        selPlanIds: [],
        plans: [],
        source: null,
        serviceTypeId: 1,
        methodTypeId: 1,
        newSource: true,
        subscriber: {
          name: self.newUser.firstName,
          email: self.newUser.email,
          phone: self.newUser.phoneNo,
          phoneCode: "+1",
        },
        today: self.$moment(new Date()).format("YYYY-MM-DD"),
        timezone: self.$moment.tz.guess(),
        browserTS: self.$moment(new Date()),
      };


    if(self.finalplan){

          subscribepayLoad.plans.push({
        planId: self.finalplan._id,
        criteria: self.finalplan.criteria,
        frequencyDays: 0,
      });

    }
  
      if (_.has(self.selectedPlans, "probabilityPlan")) {
        let probabilityPlan = self.selectedPlans["probabilityPlan"];
        if (
          _.has(probabilityPlan, "_id") &&
          _.has(probabilityPlan, "criteria")
        ) {
          subscribepayLoad.plans.push({
            planId: probabilityPlan._id,
            criteria: probabilityPlan.criteria,
            frequencyDays: 0,
          });
        }
      }

      this.$store
        .dispatch("subscription/subscribe", subscribepayLoad)
        .then((res) => {
          //this.openSetPassword = true;

          this.$store.commit("auth_success", {
            token: self.newUser["pin"],
            user: self.newUser,
            userRole: 5,
          });
          this.cardProcessing();
        })
        .catch((err) => {
          console.log(err);
          this.showResult();
        });
    },

    removeSelectedPlan() {
      this.finalplan = null;
      this.selectedplan = 0;
      // probabilityPlan ,plan
      this.selectedPlans["plan"] = null;
      this.$emit("onPlanSelect", this.selectedPlans);
    },

    removeProbabilityPlan() {
      this.probabilityPlan = null;
      // probabilityPlan ,plan
      this.selectedPlans["probabilityPlan"] = null;
      this.$emit("onPlanSelect", this.selectedPlans);
    },

    onSelectProbabilityPlan(type) {
      let _planid = "PROBABILITY";
      this.selectedprobabilityPlan = type
      if(type == 1){
         _planid = "PROBABILITYSEASON";
      }
      var selectedItem = this.lodash.find(this.planslist, function (item) {
        return item.uniqueId == _planid;
      });

      //  if (selectedItem) {
      //     this.p3amount += selectedItem.criteria[0].amount;
      // }

      this.probabilityPlan = selectedItem;
      // probabilityPlan ,plan
      this.selectedPlans["probabilityPlan"] = this.probabilityPlan;
      this.$emit("onPlanSelect", this.selectedPlans);
    },

    skipPaymentProcess() {
      // probabilityPlan ,plan
      this.selectedPlans["probabilityPlan"] = null;
      this.selectedPlans["plan"] = null;
      this.$emit("skipPaymentProcess");
    },
    continueTosubscribe() {
      if (this.loadedFromPopup) {
        this.hitContinueTosubscribe = true;
        this.processSubscription();
        //this.$emit("continueTosubscribe");
      } else {
        this.hitContinueTosubscribe = false;
        this.signuptoApp = false;
        this.signuptoApp = true;
      }
    },

    securityalert() {
      this.loginexpand = !this.loginexpand;
    },
    closeEnquiryForm(data) {
      this.enquiryApp = data["action"];
    },
    showResult() {
      this.initUser();
      this.showoverlay = true;
      this.messagetitle = "Registered Successfully";
      this.messagecontent =
        "Registration is successful. Please add your card information.";
    },

    showMessages(type = 1, error = "") {
      // type==1 skip
      if (type == 1) {
        this.messagetitle = "Registered Successfully";
        this.messagecontent =
          "Registration is successful. Please add your card information.";
      }
      //set Password closed
      if (type == 2) {
        this.messagetitle = "Registered Successfully";
        this.messagecontent =
          "Registration is successful. Please add your card information.";
      }

      //type ==3 password set success
      if (type == 3) {
        this.messagetitle = "Registered Successfully";
        this.messagecontent =
          "Registration is successful. Please add your card information.";
      }

      //subscription error
      if (type == 4) {
        this.messagetitle = "Registered Successfully";
        this.messagecontent =
          "Registration is successful. Please add your card information.";
        if (error) {
          this.messagecontent = error;
        }
      }
      this.showoverlay = true;
    },
    togleshowLoading(type = false) {
      this.showLoading = type;
    },
    initUser() {
      this.logintoApp = false;
      this.$router.replace({'query': null});

      this.forgotpassword = false;
      this.signuptoApp = false;
    },
    showFP() {
      this.forgotpassword = true;
    },
    proceedtocard() {
      var self = this;
      this.closebutton = false;
      this.snackbar = false;
      this.text = null;
      if (!this.firsttime && this.upgradeplan) {
        this.showLoading = true;
        var user = this.$store.state.user;

        var payLoad = {
          oldPlanId: null,
          newPlanId: null,
          criteria: null,
          frequencyDays: 0,
          serviceTypeId: 1,
          methodTypeId: 1,
          newSource: true,
          subscriber: {
            name: user.name,
            email: user.email,
            phone: user.phoneNo,
            phoneCode: "+1",
          },
          today: self.$moment(new Date()).format("YYYY-MM-DD"),
          timezone: self.$moment.tz.guess(),
          browserTS: self.$moment(new Date()),
        };

        payLoad.newPlanId = this.finalplan._id;
        payLoad.criteria = this.finalplan.criteria;

        this.$store
          .dispatch("subscription/getSelectedPlan", payLoad)
          .then((oldPlan) => {
            payLoad.oldPlanId = oldPlan[0]._id;
            this.$store
              .dispatch("subscription/upgradeplan", payLoad)
              .then((res) => {
                var chargepayload = {
                  passType: this.finalplan.uniqueId,
                  athletescount: this.finalplan.criteria[0].qty,
                };
                this.$store
                  .dispatch("updatePaymentstatus", chargepayload)
                  .then((finalresponse) => {
                    this.showLoading = false;
                    this.showoverlay = true;
                    this.messagetitle = "Payment Successfully";
                    this.messagecontent =
                      "Congrats, your plan has been upgraded successfully";
                    this.$emit("closetheplan");

                    setTimeout(function () {
                      self.$router.go("/plan");
                    }, 2000);
                  });
              })
              .catch((err) => {
                this.closebutton = true;
                this.showoverlay = true;
                this.messagetitle = "Plan Change";
                this.messagecontent = "Sorry but a plan cannot be downgrade";

                this.showLoading = false;
                this.snackbar = true;
                this.text = err.error_message.message;
              });
          });
      } else {
        if (this.firsttime) {
          this.$emit("changetheplan", this.finalplan);
        } else {
          this.signuptoApp = true;
        }
      }
    },
    changeplan(selectedplan) {
      this.selectedplan = selectedplan;
      var _planid = "OFFSEASON";
      var plan1box;
      var plan2box;
      var plan3box;

      if (this.inseason) {
        _planid = "INSEASON";
      }
      if (this.offseason) {
        _planid = "OFFSEASON";
      }

      plan1box = _planid + "15";
      plan2box = _planid + "20";
      plan3box = _planid + "25";

      if (this.selectedplan == 1) {
        _planid = _planid + "15";
      }
      if (this.selectedplan == 2) {
        _planid = _planid + "20";
      }
      if (this.selectedplan == 3) {
        _planid = _planid + "25";
      }

      var selectedItem = this.lodash.find(this.planslist, function (item) {
        return item.uniqueId == _planid;
      });
      var plan1boxItem = this.lodash.find(this.planslist, function (item) {
        return item.uniqueId == plan1box;
      });
      var plan2boxItem = this.lodash.find(this.planslist, function (item) {
        return item.uniqueId == plan2box;
      });
      var plan3boxItem = this.lodash.find(this.planslist, function (item) {
        return item.uniqueId == plan3box;
      });

      if (plan1boxItem) {
        this.p1amount = plan1boxItem.criteria[0].amount;
      }
      if (plan2boxItem) {
        this.p2amount = plan2boxItem.criteria[0].amount;
      }
      if (plan3boxItem) {
        this.p3amount = plan3boxItem.criteria[0].amount;
      }

      //

      var pln = this.lodash.find(this.planslist, function (item) {
        return item.uniqueId == "PROBABILITY";
      });
      if (pln) {
        this.probabilityAmount = pln.criteria[0].amount;
      }

      this.finalplan = selectedItem;

      // probabilityPlan ,plan
      this.selectedPlans["plan"] = this.finalplan;
      this.$emit("onPlanSelect", this.selectedPlans);
    },
    _getplanslist() {
      let payLoad = {
        page: 1,
        perpage: 2500,
        today: this.$moment(),
      };
      this.$store.dispatch("subscription/getplans", payLoad).then((res) => {
        this.planslist = res.list;
        this.seasontype = this.planslist[0].description;

        if (this.defaultselected && this.defaultselected.frequencyId == 4) {
          this.freq = true;
        }
        if (this.defaultselected) {
          var planuniqueid = this.defaultselected.planDetails.uniqueId;

          this.offseason = false;
          this.inseason = false;
          if (planuniqueid.includes("OFFIN")) {
            this.offseason = true;
            this.inseason = true;
          }
          if (planuniqueid.includes("IN")) {
            this.inseason = true;
          }
          if (planuniqueid.includes("OFF")) {
            this.offseason = true;
          }

          var _currentcriteria = this.defaultselected.criteria[0].qty;
          if (_currentcriteria == 15) this.selectedplan = 1;
          if (_currentcriteria == 20) this.selectedplan = 2;
          if (_currentcriteria == 25) this.selectedplan = 3;

          this.selectedplan = 0;
          //this.changeplan(this.selectedplan);
        } else {
          this.selectedplan = 0;
          //this.changeplan(1);
        }

        if (this.$store.state && this.$store.state.user) {
          var user = this.$store.state.user;
          this.loggedinview = true;
          if (
            user &&
            user.subscription &&
            user.subscription.paymentStatusId == 1
          ) {
            var selectedItem = this.lodash.find(
              this.planslist,
              function (item) {
                return item.uniqueId == user.subscription.passType;
              }
            );

            this.userplan = selectedItem;

            this.showcardinfo = true;
          }
        }
      });
    },
  },
  mounted() {
    //if user logged in
    this.usercurrentPlan = this.$store.getters["subscription/getSubscriptions"];

    var user = this.$store.state.user;
    if (user.email) this.cuser = user;
    if (
      this.$route.query &&
      this.$route.query.show &&
      this.$route.query.show == "subscribe" &&
      (user == "" || user == undefined)
    ) {
      this.enquiryApp = true;
      this.et = 1;
      this.enquirytype = "Request For Athlete Pass";
    }
    if (
      this.$route.query &&
      this.$route.query.show &&
      this.$route.query.show == "login" &&
      (user == "" || user == undefined)
    ) {
      this.logintoApp = true;

    }
    if (
      this.$route.query &&
      this.$route.query.show &&
      this.$route.query.show == "subscribepopup" &&
      (user == "" || user == undefined)
    ) {
      this.showsignupAlert = true;

    }
    if (
      this.$route.query &&
      this.$route.query.show &&
      this.$route.query.show == "signup" &&
      (user == "" || user == undefined)
    ) {
      this.signuptoApp = true;
    }
    // this.logintoApp=true;
    this._getplanslist();
    if (this.loadedFromPopup && this.userData) {
      this.newUser = this.userData;
    }
  },
};
</script>

