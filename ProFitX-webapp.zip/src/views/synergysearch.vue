<template>
  <div>
    <div class="widget_block synergy_widget searchwidget ssearchwidget">
      <div class="widget_title">
        <div class="d-flex">
          <h3>
            PLAYER SYNERGY

            <v-tooltip bottom>
              <template v-slot:activator="{ on, attrs }">
                <v-btn class="info_btn" v-bind="attrs" v-on="on">
                  <v-icon>mdi-information-outline</v-icon>
                </v-btn>
              </template>
              <span
                >Dynamic AI model that actively identifies ideal 2 & 3-MAN
                combinations from around the league and 2-MAN Team Combinations
                that are best suited to play together and will complement their
                respective skillsets.
              </span>
            </v-tooltip>
          </h3>
        </div>
      </div>
      <div class="shotsloading" v-if="shotsloading">
        <img src="@/assets/images/shotsloading.svg" />
      </div>

      <div class="d-flex align-items-center searchsynergy">
        <div class="assets-teams">
          <span class="selectlbl"> Combo Type </span>
          <ul class="tab_buttons" style="width: 380px">
            <li
              v-bind:class="{ active: combotype == 1 }"
              @click="setCombotype(1)"
            >
              <a>1 Player Combo</a>
            </li>
            <li
              v-bind:class="{ active: combotype == 2 }"
              @click="setCombotype(2)"
            >
              <a>2 Player Combo</a>
            </li>
            <li
              v-bind:class="{ active: combotype == 3 }"
              @click="setCombotype(3)"
            >
              <a>3 Player Combo</a>
            </li>
          </ul>
        </div>

        <div class="assets-teams">
          <span class="selectlbl"> Combination </span>

          <ul class="tab_buttons">
            <li
              @click="combooutput = 1"
              v-bind:class="{ active: combooutput == 1 }"
            >
              <a>1 </a>
            </li>
            <li
              @click="combooutput = 2"
              v-bind:class="{ active: combooutput == 2 }"
            >
              <a>2 </a>
            </li>
            <li
              @click="combooutput = 3"
              v-if="combotype != 3"
              v-bind:class="{ active: combooutput == 3 }"
            >
              <a>3 </a>
            </li>
          </ul>
        </div>

        <div class="assets-teams">
          <span class="selectlbl"> League/Team Filter  </span>
          <span>
            <multiselect
              :select-label="''"
              deselect-label=""
              v-model="steam"
              :options="teamsList"
              :close-on-select="true"
              @input="filterPlayers"
              placeholder="Select a Team"
              label="TEAM_NAME"
            ></multiselect>
          </span>
        </div>
      </div>

      <div class="playerselectionBlock d-flex align-items-center searchsynergy">
        <div class="assets-teams" style="width: 548px">
          <span class="selectlbl"> Players </span>
          <span>
            <multiselect
              :select-label="''"
              deselect-label=""
              v-model="splayer"
              :options="playersList"
              :multiple="true"
              trackBy="PLAYER_ID"
              :max="combotype"
              :close-on-select="true"
              placeholder="Choose Player(s)"
              label="PLAYER_NAME"
            ></multiselect>
          </span>
        </div>

        <div class="assets-teams">
          <span class="selectlbl"> Player Synergy Search </span>
          <span>
            <multiselect
              :select-label="''"
              deselect-label=""
              v-model="synergyteamteam"
              :options="teamsList"
              :close-on-select="true"
              @input="sfilterPlayers"
              placeholder="Select a Team"
              label="TEAM_NAME"
            ></multiselect>
          </span>
        </div>
      </div>

      <div class="actionBtns">
        <div
          class="selcted_actions"
          v-if="
            splayer &&
            splayer.length > 0 &&
            ((combotype == 1 && splayer.length == 1) ||
              (combotype == 2 && splayer.length == 2) ||
              (combotype == 3 && splayer.length == 3))
          "
        >
          <button @click="generateSynergy()" class="primary_btn">
            Generate
          </button>
        </div>
      </div>

      <div class="slider_navigation" v-if="synergyplayers.length > 0">
        <div class="swiper-button-prev">
          <span class="icon-play-flip"></span>
        </div>
        <div class="swiper-button-next"><span class="icon-play"></span></div>
      </div>

      <div
        v-if="playercombo2 && synergyplayers.length > 0"
        class="playercombo3"
      >
        <div class="widget_body pl-0 pt-0 pb-0 pr-0">
          <div class="synergy_slider">
            <div class="synergy_slider_menu">
              <v-list-item style="height: 180px"></v-list-item>
              <v-list-item style="height: 95px">CONTRACT</v-list-item>
              <v-list-item style="height: 75px">Offense </v-list-item>
              <v-list-item style="height: 75px">Defense </v-list-item>
            </div>
            <swiper ref="awesomeSwiperA" :options="swiperOption">
              <swiper-slide
                :key="ind"
                v-for="(ssplayer, ind) in synergyplayers"
              >
                <v-card
                  class
                  outlined
                  :key="sind"
                  v-for="(splayer, sind) in ssplayer"
                >
                  <v-card-title class="card_title">
                    <template>
                      <template>
                        <span
                          class="checkMark"
                          v-if="sind != 0 || sind - 1 == ssplayer.length"
                        >
                          <img src="@/assets/images/check-mark.svg" />
                        </span>

                        <div class="title_block" :key="sind">
                          <img
                            v-if="splayer.goalserveDetails"
                            :src="
                              'https://profitx.ai/api/viewfile?path=playerimages/' +
                              splayer.goalserveDetails.PlayerID +
                              '.png'
                            "
                            class="align-self-center pl"
                            :alt="splayer.PLAYER_NAME"
                          />

                          <p>{{ splayer.PLAYER_NAME }}</p>
                          <span>
                            Points:
                            {{ (splayer.POINTS / splayer.GP).toFixed(2) }}
                            <br />
                            Rebounds:
                            {{ (splayer.REB / splayer.GP).toFixed(2) }} <br />
                            Assists: {{ (splayer.AST / splayer.GP).toFixed(2) }}
                          </span>
                        </div>
                      </template>
                    </template>
                  </v-card-title>
                  <v-list-item>
                    <v-list-item-content>
                      <v-list-item>
                        <v-col class="contact" :key="ind">
                          <label class="currentsalary">
                            <small>TC</small>
                            {{ splayer.TC | currency }}
                          </label>

                          <label
                            v-bind:class="{
                              state2: splayer.TC > splayer.RTC,
                              state1: splayer.TC < splayer.RTC,
                            }"
                          >
                            <small>rt</small>
                            {{ splayer.RTC | currency }}
                          </label>
                        </v-col>
                      </v-list-item>
                      <v-list-item>
                        <v-col>
                          <span>
                            <PlayerDNA :roles="splayer.ROLES" />
                          </span>
                        </v-col>
                      </v-list-item>
                    </v-list-item-content>
                  </v-list-item>
                </v-card>
              </swiper-slide>
            </swiper>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>

<script>
import teams from "@/data/teams.json";

import "swiper/dist/css/swiper.css";
import PlayerDNA from "./../views/popovers/playerrolessyn";

import { swiper, swiperSlide } from "vue-awesome-swiper";
export default {
  name: "synergy-seacrh",
  components: {
    swiper,
    swiperSlide,
    PlayerDNA,
  },
  props: {
    player: {},
    playerid: null,
  },
  computed: {
    swiper() {
      return this.$refs.mySwiper.swiper;
    },
  },
  methods: {
    setCombotype(combo) {
      this.combotype = combo;
      this.combooutput = 1;
    },
    generateSynergy() {
      this.shotsloading = true;
      //seacrhSynergy  synergyselectedplayers
      var postData = {
        synergyteamteam: this.lodash.map(
          this.synergyselectedplayers,
          "PLAYER_NAME"
        ),
        players: this.lodash.map(this.splayer, "PLAYER_NAME"),
        combooutput: this.combooutput,
      };
      this.$store
        .dispatch("seacrhSynergy", postData)
        .then((response) => {
          this.shotsloading = false;
          if (response.error) {
            this.synergyplayers = [];
          } else {
            this.selectedplayers = this.splayer;
            var synergyplayers = [];
            var poptions = this.lodash.cloneDeep(this.baseplayersList);
            response.data.forEach((element) => {
              var _childplayers = [];

              //COMBO1
              if (
                element.player &&
                this.splayer[0].PLAYER_NAME != element.player
              ) {
                var _ca = this.lodash.find(poptions, function (p) {
                  return p.PLAYER_NAME == element.player;
                });

                if (_ca) _childplayers.push(_ca);
              }

              if (
                element.player1 &&
                this.splayer[0].PLAYER_NAME != element.player1
              ) {
                var _c = this.lodash.find(poptions, function (p) {
                  return p.PLAYER_NAME == element.player1;
                });

                if (_c) _childplayers.push(_c);
              }
              if (
                element.player2 &&
                this.splayer[0].PLAYER_NAME != element.player2
              ) {
                var _c2 = this.lodash.find(poptions, function (p) {
                  return p.PLAYER_NAME == element.player2;
                });

                if (_c2) _childplayers.push(_c2);
              }

              if (
                element.player3 &&
                this.splayer[0].PLAYER_NAME != element.player3
              ) {
                var _c3 = this.lodash.find(poptions, function (p) {
                  return p.PLAYER_NAME == element.player3;
                });

                if (_c3) _childplayers.push(_c3);
              }

              if (_childplayers.length == this.combooutput) {
                this.splayer.forEach((selement) => {
                  _childplayers.push(selement);
                });

                synergyplayers.push(_childplayers);
              }
            });
            this.synergyplayers = synergyplayers;
          }
        })
        .catch((err) => {
          this.shotsloading = false;
          this.synergyplayers = [];
        });
    },
    checkplayer(player) {
      var _d = this.lodash.find(this.selectedplayers, function (a) {
        return a.PLAYER_NAME == player.PLAYER_NAME;
      });

      return !_d;
    },
    selectPlayer(player) {
      var _d = this.lodash.find(this.selectedplayers, function (a) {
        return a.PLAYER_NAME == player.PLAYER_NAME;
      });

      if (!_d && this.selectedplayers.length <= 5) {
        this.selectedplayers.push(player);
      }

      if (this.synergyplayers.length > 0) {
        this.generateSynergy();
      }

      this.playersList = [];
      this.serch_title = null;
    },
    sfilterPlayers() {
      var _s = this;

      var options = this.lodash.cloneDeep(this.baseplayersList);
      if (_s.synergyteamteam.TEAM_NAME != "Entire League") {
        this.synergyselectedplayers = this.lodash.filter(options, function (p) {
          return p.TEAM_ABBREVIATION == _s.synergyteamteam.TEAM_NAME;
        });
      } else {
        this.synergyselectedplayers = [];
      }
    },
    filterPlayers() {
      var _s = this;
      this.playersList = [];
      this.splayer = null;
      var options = this.lodash.cloneDeep(this.baseplayersList);
      if (_s.steam.TEAM_NAME != "Entire League") {
        this.playersList = this.lodash.filter(options, function (p) {
          return p.TEAM_ABBREVIATION == _s.steam.TEAM_NAME;
        });
      } else {
        this.playersList = options;
      }
    },
    getPlayersList() {
      this.playersList = [];
      this.loading = false;

      const postData = {
        page: 1,
        perpage: 500,
        matcher: {
          startswith: "",
          searchString: null,
        },
      };

      this.loading = true;
      this.$store
        .dispatch("getplayers", postData)
        .then((response) => {
          if (response.error) {
            this.playersList = [];
          } else {
            this.playersList = response.data.result.list;
            this.baseplayersList = response.data.result.list;
          }

          this.loading = false;
        })
        .catch((err) => {
          this.playersList = [];
          this.loading = false;
        });
    },
  },
  watch: {},
  mounted() {
    var _defaultoption = [
      {
        TEAM_ID: 0,
        TEAM_NAME: "Entire League",
        TEAM_ABBREVIATION: "Entire League",
      },
    ];

    _defaultoption = _defaultoption.concat(teams);

    this.teamsList = _defaultoption;
    this.siteUrl = process.env.VUE_APP_API_URL;
    this.getPlayersList();
  },
  data() {
    return {
      shotsloading: false,
      combotype: 1,
      combooutput: 1,
      splayer: null,
      steam: {
        TEAM_ID: 0,
        TEAM_NAME: "Entire League",
        TEAM_ABBREVIATION: "Entire League",
      },
      synergyteamteam: {
        TEAM_ID: 0,
        TEAM_NAME: "Entire League",
        TEAM_ABBREVIATION: "Entire League",
      },
      teamsList: [],
      siteUrl: null,
      selectedplayers: [],
      synergyselectedplayers: [],
      serch_title: null,
      asplayer: null,
      playersList: [],
      baseplayersList: [],
      loading: false,
      playercomboteam: false,
      playercombo2: true,
      playercombo3: false,
      synergyplayers: [],
      synergycombo3: [],
      teamcombo: [],
      swiperOption: {
        slidesPerView: "auto",
        spaceBetween: 10,
        pagination: {
          el: ".swiper-pagination",
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
      },
    };
  },
};
</script>
