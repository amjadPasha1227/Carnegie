<template>
<div class="col padtb0" @click="snackbar =false">
    <div class="card_information show" id="card_information">
        <h3 v-if="!updatecard">Card Information</h3>
        <h3 v-if="updatecard">Update Card Information</h3>

        <span class="form">
            <div class='credit-card-inputs payment-simple' :class='{ complete }'>
                <ul class="card_form">
                    <li>
                        <div class="form-group num">
                            <label class="form_label">Card number</label>
                            <div class="form-control">

                                <card-number class='stripe-element card-number' ref='cardNumber' :stripe='stripe' :options='options' @change='number = $event.complete' />
                            </div>
                        </div>
                        <div class="form-group date">
                            <label class="form_label">Expire Date</label>
                            <div class="form-control">
                                <card-expiry class='stripe-element card-expiry' ref='cardExpiry' :stripe='stripe' :options='options' @change='expiry = $event.complete' />
                            </div>
                        </div>
                        <div class="form-group cvv">
                            <label class="form_label d-flex">CVV<p>
                                    <v-icon>mdi-information</v-icon><small>A CVV is the three- or four-digit number on your card</small>
                                </p></label>
                            <div class="form-control">
                                <card-cvc class='stripe-element card-cvc' ref='cardCvc' :stripe='stripe' :options='options' @change='cvc = $event.complete' />
                            </div>
                        </div>

                    </li>

                    <!-----Apply Cupon Code ---->

                    <li>
                        <div class="card_actions">
                            <button v-if="!updatecard" type="button" @click="completepayment()" class="update_btn">Proceed</button>
                            <button v-if="updatecard" type="button" @click="updateCardDetails()" class="update_btn">Update</button>
                            <button v-if="cancelbtn != false" class="cancel_btn" @click="cancelop" id="cancel_btn">Cancel</button>
                        </div>
                    </li>
                </ul>
                <div class="coupons_sec" v-if="!updatecard">
                    <a v-if="!applyCuponCode" @click="applyCuponCode=true" > Do you have coupon code?</a>
                    <ul class="card_form" v-if="applyCuponCode">
                        <li>
                            <div class="form-group">
                                <label class="form_label">Cuppon Code</label>
                                <input type="text" placeholder="Enter Coupon Code" class="form-control" name="cuppon code" v-model="cuponCode" v-validate="'required'|'max:15'|'min:10'">
                            </div>
                            <span class="error-text" v-show="errors.has('cuppon code')">{{ errors.first("cuppon code") }}</span>
                        </li>
                        <li>
                            <div class="card_actions">
                                <button :disabled="!cuponCode" class="update_btn" @click="checkCuponvalidation()"> Apply </button>
                                <button class="cancel_btn" @click="cuponCode=null;validCoupon=false;cuponError=false;applyCuponCode=false;cuponValidationMsg=''"> Cancel </button>
                            </div>
                        </li>
                    </ul>
                    <div  class="error-text" v-if="cuponValidationMsg!='' && validCoupon">Congratulations - You have got ${{cuponValidationMsg}} offer on your selected package</div>
                    <div  class="error-text" v-if="cuponValidationMsg!='' && cuponError">{{cuponValidationMsg}}</div>
                </div>

                <!-- <ul class="card_form">
                    <li>
                        <div class="form-group">
                        <template>
                            <div class="input_actions justify-content-start" v-if="!applyCuponCode">
                                <span></span>
                                    <v-checkbox v-model="applyCuponCode" ></v-checkbox>

                                    Apply Cupon Code

                            </div> 
                        </template>
                         <template v-if="applyCuponCode">
                            <label class="form_label">Cuppon Code</label>
                                <div class="form-control">
                                    <input type="text" class="form_control" name="cuppon code"  v-model="cuponCode" v-validate="'required'|'max:15'|'min:10'"  >
                                    <span class="error-text" v-show="errors.has('cuppon code')" >{{ errors.first("cuppon code") }}</span>                                     
                                </div>
                                <div class="card_actions">
                                    <button  :disabled="!cuponCode" class="update_btn" @click="checkCuponvalidation()"> Apply </button>
                                </div>

                            </template>

                        </div>
                    </li>
                </ul> -->

                <v-overlay v-if="showoverlay">
                    <v-progress-circular indeterminate size="64"></v-progress-circular>
                </v-overlay>
                <snakebar v-if="snackbar" :snackbar="snackbar" :msg="text" :isError="isError" />
                <success-popup :showoverlay="showsuccess" :title="messagetitle" :description="messagecontent" />

                <toaster-popup :toaster="toasteshow" :description="toastecontent" />
            </div>
        </span>
    </div>
</div>
</template>

<script>
import {
    CardNumber,
    CardExpiry,
    CardCvc,
    createSource
} from '@noahlozevski/vue-stripe-elements-plus'
import moment from "moment";
import toasterPopup from "@/views/toster.vue";
import snakebar from "@/views/components/snakebar.vue";
import successPopup from "@/views/success.vue";

export default {
    props: ['stripe', 'userplan', "updatecard", "cancelbtn","selectedPlan"],
    data() {
        return {
            cuponError: false,
            cuponValidationMsg: '',
            cuponCode: "",
            validCoupon: false,
            applyCuponCode: false,

            options: {
                style: {
                    base: {

                        iconColor: '#c4f0ff',
                        color: '#8790B1',
                        fontSize: "13px",
                        fontWeight: '500',
                        padding: 15,
                        fontSmoothing: 'antialiased',
                        ':-webkit-autofill': {
                            color: '#8790B1',
                        },
                        '::placeholder': {
                            color: '#8790B1',
                        },
                    },
                    invalid: {
                        iconColor: '#FFC7EE',
                        color: '#FF8F00',
                    },
                },
            },
            complete: false,
            number: false,
            expiry: false,
            cvc: false,
            showoverlay: false,
            toasteshow: false,
            toastecontent: null,
            text: null,
            snackbar: false,
            isError: false,
            showsuccess: null,
            messagetitle: null,
            messagecontent: null
        }
    },
    components: {
        CardNumber,
        CardExpiry,
        CardCvc,
        toasterPopup,
        snakebar,
        successPopup
    },
    mounted() {

    },
    methods: {
        checkCuponvalidation() {
            var user = this.$store.state.user;
            this.showoverlay = true;
            //cuponError
            //  cuponValidationMsg:'',
            // cuponCode:"FLAT30",
            // validCoupon:false,
            // applyCuponCode:false,
            this.cuponError = false;
            this.validCoupon = false;
            this.cuponValidationMsg = "";
            var _self = this;
            let payLoad = {
                "planId": (_self.userplan!=null)?_self.userplan._id:_self.selectedPlan.planId,
                "code": this.cuponCode,
                subscriber: {
                    name: user.name,
                    email: user.email,
                    phone: user.phoneNo,
                    phoneCode: "+1"
                },
                  today: _self.$moment(new Date()).format("YYYY-MM-DD"),
                    timezone: _self.$moment.tz.guess(),
                    browserTS: _self.$moment(new Date())

            };
            this.$store.dispatch("subscription/validateCupon", payLoad)
                .then((res) => {
                    this.showoverlay = false;
                    this.cuponError = false;
                    this.validCoupon = true;
                    this.cuponValidationMsg = res["amount"];

                })
                .catch((err) => {
                    this.showoverlay = false;
                    this.cuponError = true;
                    this.validCoupon = false;
                    this.cuponValidationMsg = err;

                });

        },
        updateCardDetails() {
            this.text = null;
            this.showoverlay = true;
            this.snackbar = false;
            var user = this.$store.state.user;
            var _self = this;
            createSource().then(result => {

                var payLoad = {
                    selPlanIds: [],
                    plans: [],
                    source: null,
                    "serviceTypeId": 1,
                    "methodTypeId": 1,
                    "newSource": true,
                    subscriber: {
                        name: user.name,
                        email: user.email,
                        phone: user.phoneNo,
                        phoneCode: "+1"
                    },
                    today: _self.$moment(new Date()).format("YYYY-MM-DD"),
                    timezone: _self.$moment.tz.guess(),
                    browserTS: _self.$moment(new Date())
                };
                var paymethod = payLoad;

                paymethod.source = result.source;
                this.$store.dispatch("subscription/attachpaymentmethod", paymethod).then((cardResponse) => {

                    this.showoverlay = false;
                    this.toasteshow = true;
                    this.toastecontent = "Card details are updated successfully";
                    this.$router.go('/payments');

                }).catch((err) => {
                    this.showoverlay = false;
                    this.text = "Please enter valid card details";
                    this.isError = true;
                    this.snackbar = true;

                });

            })

        },
        cancelop() {
            this.$emit('cancelop', true)
        },
        completepayment() {
            this.showoverlay = true;
            var user = this.$store.state.user;
            var _self = this;
            this.text = null;
            this.snackbar = false;
            createSource().then(result => {

                var payLoad = {
                    selPlanIds: [],
                    plans: [],
                    source: null,
                    serviceTypeId: 1,
                    methodTypeId: 1,
                    newSource: true,
                    subscriber: {
                        name: user.name,
                        email: user.email,
                        phone: user.phoneNo,
                        phoneCode: "+1"
                    },
                    today: _self.$moment(new Date()).format("YYYY-MM-DD"),
                    timezone: _self.$moment.tz.guess(),
                    browserTS: _self.$moment(new Date())
                };
                var paymethod = payLoad;
                var chargepayload = payLoad;
                this.$store.dispatch("subscription/getSelectedPlan", payLoad).then((currentPlan) => {
                    if (currentPlan && currentPlan.length > 0 && _self.userplan == null) {
                        //User subscribed plan and the current plan from selection are same in this case just charge for the plan direcly

                        payLoad.plans.push({
                            planId: currentPlan[0].planId,
                            criteria: currentPlan[0].criteria,
                            frequencyDays: 0
                        })

                        chargepayload.source = result.source;
                        chargepayload.selPlanIds.push(currentPlan[0]._id)

                        paymethod.source = result.source;
                        this.$store.dispatch("subscription/attachpaymentmethod", paymethod).then((cardResponse) => {

                            if (this.validCoupon && this.cuponCode) {
                                chargepayload = Object.assign(chargepayload, {
                                    "code": this.cuponCode
                                });
                            }

                            this.$store.dispatch("subscription/chargeforplan", chargepayload).then((finalres) => {

                         this.showoverlay = false;
                                    this.toasteshow = true;

                                    this.showsuccess = true;
                                    this.messagetitle = "Payment completed successfully";
                                    this.messagecontent = "All set with your account. Start exploring ProFitX.";

                                    var subobj = {
                                        email: user.email,
                                        name: user.name,
                                        listId: 36007
                                    }
                                    this.$store.dispatch("subscribetoemaillist", subobj).then(response => {})
                                    var unsubobj = {
                                        email: user.email,
                                        name: user.name,
                                        listId: 36008
                                    }
                                    this.$store.dispatch("unsubscribetoemaillist", unsubobj).then(response => {})

                                    setTimeout(function () {
                                        _self.$router.push('/athlete-selection');
                                    }, 2000)

                            })

                        }).catch((err) => {
                            this.showoverlay = false;
                            this.text = "Please enter valid card details";
                            this.isError = true;
                            this.snackbar = true;

                        });

                    } else {

                        payLoad.plans.push({
                            planId: _self.userplan._id,
                            criteria: _self.userplan.criteria,
                            frequencyDays: 0
                        })

                        chargepayload.source = result.source;

                        paymethod.source = result.source;
                        this.$store.dispatch("subscription/attachpaymentmethod", paymethod).then((cardResponse) => {

                            this.$store.dispatch("subscription/subscribe", payLoad).then((res) => {

                                if (res) {
                                    chargepayload.selPlanIds = res._id;
                                }

                                if (this.validCoupon && this.cuponCode) {
                                    chargepayload = Object.assign(chargepayload, {
                                        "code": this.cuponCode
                                    });
                                }

                                this.$store.dispatch("subscription/chargeforplan", chargepayload).then((finalres) => {

                            this.showoverlay = false;
                                        this.toasteshow = true;

                                        this.showsuccess = true;
                                        this.messagetitle = "Payment completed successfully";
                                        this.messagecontent = "All set with your account. Start exploring ProFitX. ";

                                        var subobj = {
                                            email: user.email,
                                            name: user.name,
                                            listId: "a52492f4-3235-464a-97e9-ddce3110ff6d"
                                        }
                                        this.$store.dispatch("subscribetoemaillist", subobj).then(response => {})
                                        var unsubobj = {
                                            email: user.email,
                                            name: user.name,
                                            listId: "bfb8eb5e-d3a1-431b-bbe1-0c9b1dfcb407"
                                        }
                                        this.$store.dispatch("unsubscribetoemaillist", unsubobj).then(response => {})

                                        setTimeout(function () {
                                            _self.$router.push('/athlete-selection');
                                        }, 2000)

                                })

                            })

                        }).catch((err) => {
                            this.showoverlay = false;
                            this.text = "Please enter valid card details";
                            this.isError = true;
                            this.snackbar = true;

                        });

                    }

                })

            })

        },
        update() {
            this.complete = this.number && this.expiry && this.cvc

            // field completed, find field to focus next
            if (this.number) {
                if (!this.expiry) {
                    this.$refs.cardExpiry.focus()
                } else if (!this.cvc) {
                    this.$refs.cardCvc.focus()
                }
            } else if (this.expiry) {
                if (!this.cvc) {
                    this.$refs.cardCvc.focus()
                } else if (!this.number) {
                    this.$refs.cardNumber.focus()
                }
            }
            // no focus magic for the CVC field as it gets complete with three
            // numbers, but can also have four
        }
    },
    watch: {
        number() {
            this.update()
        },
        expiry() {
            this.update()
        },
        cvc() {
            this.update()
        }
    }
}
</script> 

<style>

</style>
