<template>
  <div>
    <div class="thankyou">
        <figure><img src="@/assets/images/Checked.svg" /></figure>
        <h4>Your Payment was successful</h4>
        <h5>Thank you for your payment.</h5>
    </div>

     

   
  </div>
</template>

 

<script>
 
import _ from "lodash";
export default {
  
  data() {
     
  }
  
  
}
</script>
