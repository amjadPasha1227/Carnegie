<template>
<div>
    <div class="polls_slider" >
        <h3>Polls</h3>

        <template v-if="pollsList.length > 0">       
        <swiper ref="awesomeSwiperA" :options="swiperOption" > 
           <template v-for="(poll ,ind) in pollsList">
            <swiper-slide :key="ind">
                
                 <pollItem  :pollItem="poll"  @reloadpollsList="reloadpollsList" :loadedFromList="'home_player_options'" />             
            </swiper-slide>
           </template>
           <!--
            <swiper-slide>
                <div class="poll_block">
                    <div class="polls_header">
                        <figure><img src="@/assets/images/player_dp.png"></figure>
                        <span>?</span>
                        <figure><img src="@/assets/images/ATL_logo.svg"></figure>
                    </div>
                    <label>ProFitX Rating<b>36</b></label>
                    <div class="poll_actions">
                       <a class="action_btn exercise">Exercise</a>
                       <a class="action_btn decline">Decline</a>
                    </div>
                </div>             
            </swiper-slide>
            <swiper-slide>
                <div class="poll_block">
                    <div class="polls_header">
                        <figure><img src="@/assets/images/player_dp.png"></figure>
                        <span>?</span>
                        <figure><img src="@/assets/images/ATL_logo.svg"></figure>
                    </div>
                    <label>ProFitX Rating<b>36</b></label>
                    <div class="poll_actions">
                       <a class="action_btn exercise">Exercise</a>
                       <a class="action_btn decline">Decline</a>
                    </div>
                </div>             
            </swiper-slide>
            <swiper-slide>
                <div class="poll_block">
                    <div class="polls_header">
                        <figure><img src="@/assets/images/player_dp.png"></figure>
                        <span>?</span>
                        <figure><img src="@/assets/images/ATL_logo.svg"></figure>
                    </div>
                    <label>ProFitX Rating<b>36</b></label>
                    <div class="poll_actions">
                       <a class="action_btn exercise">Exercise</a>
                       <a class="action_btn decline">Decline</a>
                    </div>
                </div>             
            </swiper-slide> 
            -->           
            <!-- <div class="swiper-pagination" slot="pagination"></div> -->            
        </swiper>
        <div class="slider_navigation">
            <div class="swiper-button-prev polls_left"></div>
            <div class="swiper-pagination" slot="pagination"></div>
            <div class="swiper-button-next polls_right"></div>
        </div>
        </template>
    </div>
    
    

    
</div>
</template>



<script> 
import pollItem from "@/views/polls/pollItem.vue";  

import "swiper/dist/css/swiper.css"; 
import { swiper, swiperSlide } from "vue-awesome-swiper";
 import _ from "lodash";
import moment from "moment";

export default {
    components: {  
    swiper,
    swiperSlide,
    pollItem
    },
    methods: {
        reloadpollsList(){
            
            this.getPolsList()
          

        },
        getPolls(type=1){
             this.subTypeId =type;
             this.getPolsList();
        },

    getPolsList() {
    let _self = this;
    let payLoad = {
    page: _self.page,
    perpage: _self.perPage,
    matcher: {
         "typeIds": [3],
         "subTypeIds": [1],
        statusList: [true, false],
        createdByIds: [],
        createdDateRange: [],
    },
    getForPublish: true,
    getOpinionStats: true,
    timezone: moment.tz.guess(),
    sorting:{
        path:"customId",
        order:-1

    }
    };
    payLoad['matcher']['subTypeIds'] = [this.subTypeId];
   
    this.listLoading =true;
    this.$store.dispatch("getPolsList", payLoad).then((res) => {
        this.pollsList =_.shuffle(res['list']);
        this.listLoading =false;

    }) .catch((err) => {
        this.listLoading =false;
    });
    },
        
       
        
    },
    data: () => ({
       
        subTypeId:1,
        pollsList:[],
        page:1,
        perPage:25,
        swiperOption: {
            effect: 'cube',
            grabCursor: true,
            cubeEffect: {
                shadow: true,
                slideShadows: true,
                shadowOffset: 20,
                shadowScale: 0.94
            },
            navigation: {
                nextEl: ".polls_left",
                prevEl: ".polls_right",
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true
            }
        },
         
    }),
    mounted() {
       
       this.subTypeId =1;
        this.getPolsList();

    },
    computed: {
  
    }
}
</script> 
