<template>
  <div>
    <div class="teams_homeslider" :class="{'noslides': gameslist.length<=3 }" v-if="!isloading">
      <div class="teams_slider_menu" v-if="!isloading">
        <ul>
          <li>
            <a
              v-bind:class="{ active: selectetype == -1 }"
              @click="loadMatches(-1, null)"
              >All</a
            >
          </li>
          <li
            v-on:click="loadMatches(index, date)"
            v-for="(date, index) in dateslist"
            :key="index"
          >
            <a v-bind:class="{ active: index == selectetype }">{{
              date.dateno
            }}</a>
          </li>
        </ul>
      </div>
      <div class="slider_navigation">
        <div class="swiper-button-prev home-slider1_left"></div>
        <div class="swiper-button-next home-slider1_right"></div>
      </div>
      <swiper
        ref="awesomeSwiperA"
        :options="swiperOption"
        class="home_main_slider"
      >
        <template v-for="(game, index) in gameslist">
          <swiper-slide :key="index">
            <game @triggerSignup="triggerSignup" :gamedata="game" getHomepageOdds />
          </swiper-slide>
        </template>
      </swiper>
    </div>
    <div class="skeleton_loder mart80 marb50" v-if="isloading">
      <v-sheet class="pa-3">
        <v-skeleton-loader
          class="mx-auto"
          max-width="370"
          type="card"
        ></v-skeleton-loader>
        <v-skeleton-loader
          class="mx-auto"
          max-width="370"
          type="card"
        ></v-skeleton-loader>
        <v-skeleton-loader
          class="mx-auto"
          max-width="370"
          type="card"
        ></v-skeleton-loader>
        <v-skeleton-loader
          class="mx-auto"
          max-width="370"
          type="card"
        ></v-skeleton-loader>
      </v-sheet>
    </div>
  </div>
</template>



<script>
import "swiper/dist/css/swiper.css";
import { swiper, swiperSlide } from "vue-awesome-swiper";
import game from "@/views/common/game.vue";
import moment from "moment";

export default {
  components: {
    game,
    swiper,
    swiperSlide,
  },
  methods: {
    loadMatches(option, selecteddate) {
      clearInterval(this.polling);
      this.selectetype = option;

      if (this.isUserloggeIn) {
        if (option == -1) {
          this.$router.push({
            name: "probability",
          });
        } else {
          this.homeProbability(selecteddate.date, selecteddate.edate);
          this.pollData();
        }
      } else {
             this.$emit("triggerSignup");
      
      }
    },
    triggerSignup(){
             this.$emit("triggerSignup");

    },
    homeProbability(startdate, enddate) {
      this.$store
        .dispatch("getHomepageOdds", {
          startdate: startdate,
          enddate: enddate,
        })
        .then((response) => {
          this.isloading = false;

          this.gameslist = [];
          var _games = [];
          if (response && response.length > 0) {
            this.gameslist = response;
          } else {
            this.isloading = false;
          }
        });
    },
    pollData() {
      this.polling = setInterval(() => {
        this.homeProbability(
          this.dateslist[this.selectetype].date,
          this.dateslist[this.selectetype].edate
        );
      }, 36000);
    },
    reloadData(date, index) {
      this.selectedIndex = index;
      this.$emit("reloadProb", {
        date: date.date,
        edate: date.edate,
        reload: false,
      });
    },
  },

  beforeDestroy() {
    clearInterval(this.polling);
  },
  mounted() {
    var a = moment();
    var _s = this;
    var _ds = [0, 1, 2, 3, 4];

    var m = moment().utc();
    var usatime = moment().utcOffset("+05:30").format("H");
    var offset = new Date().getTimezoneOffset();
    if (usatime > 16 && offset == -330) {
      _ds = [1, 2, 3, 4, 5];
    }
    m.set({ hour: 4, minute: 0, second: 0, millisecond: 0 });

    var time1 = moment().utc().format("YYYY-MM-DD");
    var time2 = moment().tz("Asia/Calcutta").format("YYYY-MM-DD");

    _ds.forEach((ekement) => {
      var s = moment().add(ekement, "days").startOf("day"),
        e = moment().add(ekement, "days").endOf("day");
      var asa = s;

      if (
        moment()
          .add(ekement, "days")
          .startOf("day")
          .isAfter(moment().add(1, "days").startOf("day"))
      ) {
        asa = s.format("MMM-DD");
      }

      if (moment().add(1, "days").startOf("day").isSame(s)) {
        asa = "Tomorrow";
      }
      if (moment().add(0, "days").startOf("day").isSame(s)) {
        asa = "Today";
      }
      if (moment().add(2, "days").startOf("day").isSame(s)) {
        asa = "Next Day";
      }

      this.dateslist.push({ dateno: asa, date: s, edate: e });
    });
    this.isloading = true;

    this.homeProbability(
      this.dateslist[0].date,
      this.dateslist[this.dateslist.length - 1].edate
    );

    this.pollData();
  },
  data: () => ({
    isloading: false,
    selectetype: 0,
    selectedIndex: 0,
    dateslist: [],
    polling: null,
    gameslist: [],
    swiperOption: {
      slidesPerView: "auto",
      spaceBetween: 20, 
      pagination: {
        el: ".swiper-pagination",
      },
      navigation: {
        nextEl: ".home-slider1_right",
        prevEl: ".home-slider1_left",
      },
    },
  }),
  computed: {
    isUserloggeIn() {
      return this.$store.state && this.$store.state.user != "";
    },
  },
};
</script>
