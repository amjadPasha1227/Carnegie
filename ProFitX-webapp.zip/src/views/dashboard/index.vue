<template>
  <div>
    <!-- <probabilitySlider  @triggerSignup="triggerSignup" /> -->
    <div class="home_middle_sec">
      <div class="home_middle_cnt" v-bind:class="{ nosidebar: isActive }">
        <div class="home_middle_left">
          <TopPerformer @triggerSignup="triggerSignup"></TopPerformer>
          <fieldGoalPerformance @triggerSignup="triggerSignup"></fieldGoalPerformance>
          <playerPerformance @triggerSignup="triggerSignup"></playerPerformance>
          <profitXrating @triggerSignup="triggerSignup"></profitXrating>
        </div>
        <div class="home_middle_right">
          <span class="hide" v-on:click="makeRed"></span>
          <aboutProfitx />
          <div class="playerpools_wrap">
            <span class="showall" v-on:click="sidebaropen">View All</span>
            <playerPolls></playerPolls>
          </div>

          <template v-for="(item, ind) in pollsList">
            <pollItem
              v-if="ind <= 1"
              :key="ind"
              :pollItem="item"
              @reloadpollsList="reloadpollsList"
              :loadedFromList="'home'"
            />
          </template>
        </div>
      </div>
    </div>
    <section class="home_articles_sec">
      <articles></articles>
    </section>

    <signupAlert  v-if="showsignupalert" />
  </div>
</template>



<script>
// import probabilitySlider from "@/views/dashboard/probabilitySlider.vue";
import signupAlert from "@/views/common/signupalert.vue";
import aboutProfitx from "@/views/dashboard/aboutus.vue";

import TopPerformer from "@/views/dashboard/topperformers.vue";
import fieldGoalPerformance from "@/views/dashboard/topshooters.vue";
import playerPerformance from "@/views/dashboard/playerPerformance.vue";
import profitXrating from "@/views/dashboard/profitXrating.vue";
import articles from "@/views/dashboard/resources.vue";
import playerPolls from "@/views/dashboard/polls.vue";
import moment from "moment";
import pollItem from "@/views/polls/pollItem.vue";

import _ from "lodash";

export default {
  components: {
    aboutProfitx,
    //probabilitySlider,
    signupAlert,
    TopPerformer,
    fieldGoalPerformance,
    playerPerformance,
    profitXrating,
    articles,
    playerPolls,
    pollItem,
  },
  methods: {
    triggerSignup(){
      this.showsignupalert = true
    },
    reloadpollsList() {
      this.getPolsList();
    },

    getPolsList() {
      let _self = this;
      let payLoad = {
        page: _self.page,
        perpage: _self.perPage,
        matcher: {
          typeIds: [1, 2],
          subTypeIds: [],
          statusList: [true, false],
          createdByIds: [],
          createdDateRange: [],
        },
        getForPublish: true,
        getOpinionStats: true,
        timezone: moment.tz.guess(),
        sorting: {
          path: "customId",
          order: -1,
        },
      };
      this.listLoading = true;
      this.$store
        .dispatch("getPolsList", payLoad)
        .then((res) => {
          this.pollsList = _.shuffle(res["list"]);
          this.listLoading = false;
        })
        .catch((err) => {
          this.listLoading = false;
        });
    },

    makeRed: function () {
      this.isActive = !this.isActive;
    },
    sidebaropen: function () {
      this.isActive = !this.isActive;
    },
  },
  data: () => ({
    pollsList: [],
    page: 1,
    perPage: 25,
    showsignupalert:false,
    isActive: false,
  }),
  mounted() {
    this.reloadpollsList();
  },
  computed: {},
};
</script> 
