<template>
<div>
    <!-- <div class="home_articles_cnt">
        <h3>Latest Articles</h3>
        <ul>
            <li>
                <div class="article_block">
                    <figure><img src="@/assets/images/news1.png"></figure>
                    <div class="article_cnt">
                        <h5>Simmons saga far from over as trade deadline nears</h5>
                        <p>By sitting out of Tuesday's trade action, the Sixers show no sign of dealing Ben Simmons before Thursday's deadline.</p>
                        <h6>Source : <a href="#">https://www.nba.com/news</a></h6>
                    </div>
                </div>
            </li>
            <li>
                <div class="article_block">
                    <figure><img src="@/assets/images/news1.png"></figure>
                    <div class="article_cnt">
                        <h5>Simmons saga far from over as trade deadline nears</h5>
                        <p>By sitting out of Tuesday's trade action, the Sixers show no sign of dealing Ben Simmons before Thursday's deadline.</p>
                        <h6>Source : <a href="#">https://www.nba.com/news</a></h6>
                    </div>
                </div>
            </li>
            <li>
                <div class="article_block">
                    <figure><img src="@/assets/images/news1.png"></figure>
                    <div class="article_cnt">
                        <h5>Simmons saga far from over as trade deadline nears</h5>
                        <p>By sitting out of Tuesday's trade action, the Sixers show no sign of dealing Ben Simmons before Thursday's deadline.</p>
                        <h6>Source : <a href="#">https://www.nba.com/news</a></h6>
                    </div>
                </div>
            </li>
            <li>
                <div class="article_block">
                    <figure><img src="@/assets/images/news1.png"></figure>
                    <div class="article_cnt">
                        <h5>Simmons saga far from over as trade deadline nears</h5>
                        <p>By sitting out of Tuesday's trade action, the Sixers show no sign of dealing Ben Simmons before Thursday's deadline.</p>
                        <h6>Source : <a href="#">https://www.nba.com/news</a></h6>
                    </div>
                </div>
            </li>
            <li>
                <div class="article_block">
                    <figure><img src="@/assets/images/news1.png"></figure>
                    <div class="article_cnt">
                        <h5>Simmons saga far from over as trade deadline nears</h5>
                        <p>By sitting out of Tuesday's trade action, the Sixers show no sign of dealing Ben Simmons before Thursday's deadline.</p>
                        <h6>Source : <a href="#">https://www.nba.com/news</a></h6>
                    </div>
                </div>
            </li>
            <li>
                <div class="article_block">
                    <figure><img src="@/assets/images/news1.png"></figure>
                    <div class="article_cnt">
                        <h5>Simmons saga far from over as trade deadline nears</h5>
                        <p>By sitting out of Tuesday's trade action, the Sixers show no sign of dealing Ben Simmons before Thursday's deadline.</p>
                        <h6>Source : <a href="#">https://www.nba.com/news</a></h6>
                    </div>
                </div>
            </li>
            <li>
                <div class="article_block">
                    <figure><img src="@/assets/images/news1.png"></figure>
                    <div class="article_cnt">
                        <h5>Simmons saga far from over as trade deadline nears</h5>
                        <p>By sitting out of Tuesday's trade action, the Sixers show no sign of dealing Ben Simmons before Thursday's deadline.</p>
                        <h6>Source : <a href="#">https://www.nba.com/news</a></h6>
                    </div>
                </div>
            </li>
            <li>
                <div class="article_block">
                    <figure><img src="@/assets/images/news1.png"></figure>
                    <div class="article_cnt">
                        <h5>Simmons saga far from over as trade deadline nears</h5>
                        <p>By sitting out of Tuesday's trade action, the Sixers show no sign of dealing Ben Simmons before Thursday's deadline.</p>
                        <h6>Source : <a href="#">https://www.nba.com/news</a></h6>
                    </div>
                </div>
            </li>
            <li>
                <div class="article_block">
                    <figure><img src="@/assets/images/news1.png"></figure>
                    <div class="article_cnt">
                        <h5>Simmons saga far from over as trade deadline nears</h5>
                        <p>By sitting out of Tuesday's trade action, the Sixers show no sign of dealing Ben Simmons before Thursday's deadline.</p>
                        <h6>Source : <a href="#">https://www.nba.com/news</a></h6>
                    </div>
                </div>
            </li>
            <li>
                <div class="article_block">
                    <figure><img src="@/assets/images/news1.png"></figure>
                    <div class="article_cnt">
                        <h5>Simmons saga far from over as trade deadline nears</h5>
                        <p>By sitting out of Tuesday's trade action, the Sixers show no sign of dealing Ben Simmons before Thursday's deadline.</p>
                        <h6>Source : <a href="#">https://www.nba.com/news</a></h6>
                    </div>
                </div>
            </li>
        </ul>
        <a href="#" class="view_all">VIEW ALL</a>
    </div> -->

     <div class="resources_wrap">
            <div class="resources_head">
                <h2>Resources</h2>
                <ul>
                    <li><a 
                     v-bind:class="{
                active: selectedcat == 'all',
              }"
                    
                    @click="loadpost('all')" >All</a></li>
                    <li><a 
                    
                       v-bind:class="{
                active: selectedcat == 'blogs',
              }"
                    
                    @click="loadpost('blogs')" >Blog</a></li>
                    <li><a     v-bind:class="{
                active: selectedcat == 'inmedia',
              }"
                     @click="loadpost('inmedia')" >In the Media</a></li>
                    <li><a    v-bind:class="{
                active: selectedcat == 'case-studies',
              }"
                     @click="loadpost('case-studies')">Case Studies</a></li>
                    <li><a    v-bind:class="{
                active: selectedcat == 'updates',
              }"
                     @click="loadpost('updates')">Updates</a></li> 
                </ul>
            </div>
            <div class="resources_cnt">
                <ul>
                    <template v-for="(post,index) in posts">
                <li :key="index" class="" v-bind:class="{'head_blocks': index <= 3}">
                    <div class="Portfolio" style="height:auto" v-bind:class="{'bg-1': index <= 3}">
                        <figure>
                           <a :href="post.link"> <div class="card-img" style="background-position:center;
                        background-repeat:no-repeat;width: 100%;
    background-size: 80%; height:200px; background-color:#000"
    
    v-bind:style="{ backgroundImage: 'url(' + post.image + ')' }"
    >

                             </div></a>
                        </figure>                            
                        <div class="content">
                            <small>{{post.type}}</small>
                          <a :href="post.link">   <p>{{post.title}}</p></a>
                          
                        </div>
                    </div>
                </li>
                    </template>
               
                </ul>
                <a @click="gotoPage()" class="view_all">View all</a>
            </div>
        
        </div> 
</div>
</template>



<script>  
  import axios from 'axios'


export default {
    components: {  
 
    },
    methods: {
        gotoPage(){

            if(this.selectedcat == 'all'){

                window.location ="/corporate/resources/"
            }

               if(this.selectedcat == 'blogs'){

                window.location ="/corporate/blogs/"
            }
                 if(this.selectedcat == 'inmedia'){

                window.location ="/corporate/inmedia/"
            }
                    if(this.selectedcat == 'inmedia'){

                window.location ="/corporate/case-studies/"
            }

  if(this.selectedcat == 'updates'){

                window.location ="/corporate/updates/"
            }

        },
       loadpost(type){
           this.selectedcat = type;
 axios.get(`https://profitx.ai/corporate/wp-json/profitx/v1/latest-posts/${this.selectedcat}`)
  .then(response => {
    const { title, content, link } = response.data[0];
    console.log(title, content, link)
    this.posts = response.data.slice(0,16);

  })
  .catch(err => {
    console.log(`${err} whilst contacting the quote API.`)
  })


       }
        
    },
    data: () => ({
        selectedcat:"all", 
        posts:[]
         
    }),
    mounted() {

        this.loadpost("all")


    },
    computed: {
  
    }
}
</script> 
