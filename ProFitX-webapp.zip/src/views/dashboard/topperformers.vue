<template>
  <div class="top-performer">
    <div class="home_slider">
      <div class="slider__header">
        <h3>Top Performers</h3>
        <div class="slider__header_actions">
          <ul>
            <li><a class="active">Last Week</a></li>
            <li><router-link to="/top-performers">Last Three Months</router-link></li>
            <li>
              <router-link to="/top-performers">Current Season</router-link>
            </li>
          </ul>
          <div class="slider_navigation">
            <div class="swiper-button-prev home-slider2__left"></div>
            <div class="swiper-button-next home-slider2__right"></div>
          </div>
        </div>
      </div>

      <swiper ref="awesomeSwiperA" :options="swiperOption">
        <template v-for="(player, index) in playerslist">
          <swiper-slide :key="index">
            <div class="performer_block topperformer_block">
              <div class="player_profile">
                <div class="player_dp">
                  <figure>
                    <template v-if="player.PLAYER_IMAGE">
                      <img
                        :src="player.PLAYER_IMAGE"
                        class="align-self-center"
                        :alt="player.PLAYER_NAME"
                      />
                    </template>
                    <template v-else>
                      <img
                        :src="
                          'https://profitx.ai/api/viewfile?path=playerimages/' +
                          player.GPlayerID +
                          '.png'
                        "
                        class="align-self-center"
                        :alt="player.PLAYER_NAME"
                      />
                    </template>
                  </figure>
                  <span class="teamLogo" v-if="player.team"><img :src="player.team.logo" /></span>
                </div>
                <div class="player_info">
                  <h4>{{ player.PLAYER_NAME }}</h4>
                  <p>
                    {{ getposition(player.Position) }} | {{ player.AGE }} Years
                  </p>
                  <p>
                    Top Roles<span>{{ getroles(player.ROLES) }}</span>
                  </p>
               
                </div>
              </div>
              <div class="player_actions">
                <div class="gradient_btn">
                  <p>
                    <span> ProFitX Ranking</span>{{ player.RANK }}<sub></sub>
                  </p>
                </div>
   
              </div>
            </div>
          </swiper-slide>
        </template>
      </swiper>
    </div>
  </div>
</template>



<script>
import "swiper/dist/css/swiper.css";
import { swiper, swiperSlide } from "vue-awesome-swiper";

export default {
  components: {
    swiper,
    swiperSlide,
  },
  methods: {
    getroles(type) {
      const keys = Object.keys(type);
      var returnvalues = [];
      keys.forEach((key, index) => {
        returnvalues.push({
          k: key,
          v: type[key] * 100,
        });
      });

      var formated = this.lodash.orderBy(returnvalues, ["v"], ["desc"]);

      var finals = "";

      formated.forEach(function (_role, index) {
        if (index <= 2) {
          if (finals != "") {
            finals = finals + " | " + _role["k"];
          } else {
            finals = _role["k"];
          }
        }
      });

      return finals;
    },
    getposition(type) {
      var _p = this.lodash.find(this.positions, function (my) {
        return my.value == type;
      });
      return _p.name;
    },
  },
  data: () => ({
    positions: [
      {
        name: "Power Forward",
        value: "F-C",
      },
      {
        name: "Forward",
        value: "F",
      },
      {
        name: "Versatile Center",
        value: "C-F",
      },
      {
        name: "Center",
        value: "C",
      },
      {
        name: "Combo Guard",
        value: "G-F",
      },
      {
        name: "Guard",
        value: "G",
      },
      {
        name: "Wing",
        value: "F-G",
      },
    ],
    playerslist: [],
    swiperOption: {
      slidesPerView: "auto",
      spaceBetween: 20,
      pagination: {
        el: ".swiper-pagination",
      },
      navigation: {
        nextEl: ".home-slider2__right",
        prevEl: ".home-slider2__left",
      },
    },
  }),
  mounted() {
    this.$store.dispatch("getTopPerfomers").then((response) => {
      this.playerslist = [];
      var _games = [];
      if (response && response.length > 0) {
        this.playerslist = response;
      }
    });
  },
  computed: {},
};
</script> 
