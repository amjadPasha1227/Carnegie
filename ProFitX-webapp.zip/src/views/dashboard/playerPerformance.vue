<template>
  <div class="top-performer">
    <div class="home_slider">
      <div class="slider__header border">
        <ul class="slider_tabs">
          <li>
            <a v-bind:class="{ active: currentab == 1 }" @click="setTab(1)"
              >Rising Stocks</a
            >
          </li>
          <li>
            <a v-bind:class="{ active: currentab == 2 }" @click="setTab(2)"
              >Hidden Gems</a
            >
          </li>
        </ul>
        <div class="slider__header_actions">
          <ul v-if="currentab == 1">
            <li>
              <a>Last Week</a>
            </li>
            <li>
              <router-link to="/top-performers">Current Season</router-link>
            </li>
          </ul>
          <div class="slider_navigation">
            <div class="swiper-button-prev home-slider2_left"></div>
            <div class="swiper-button-next home-slider2_right"></div>
          </div>
        </div>
      </div>

      <swiper ref="awesomeSwiperA" :options="swiperOption">
        <template v-for="(player, index) in playerslist">
          <swiper-slide :key="index">
            <div class="performer_block stock">
              <div class="player_profile">
                <div class="player_dp">
                  <figure>
                    <template v-if="player.PLAYER_IMAGE">
                      <img
                        :src="player.PLAYER_IMAGE"
                        class="align-self-center"
                        :alt="player.PLAYER_NAME"
                      />
                    </template>
                    <template v-else>
                      <img
                        :src="
                          'https://profitx.ai/api/viewfile?path=playerimages/' +
                          player.GPlayerID +
                          '.png'
                        "
                        class="align-self-center"
                        :alt="player.PLAYER_NAME"
                      />
                    </template>
                  </figure>
                  <span class="teamLogo"><img :src="player.team.logo" /></span>
                </div>
                <div class="player_info">
                  <h4>{{ player.PLAYER_NAME }}</h4>
                  <p>
                    {{ getposition(player.Position) }} | {{ player.AGE }} Years
                  </p>
                  <div class="gradient_btn">
                    
                        <span>
                          <img class="up" src="@/assets/images/up_arrow.png">
                          <!-- <img src="@/assets/images/down_arrow.png"> -->
                          
                        <template v-if="currentab == 1">
                          <strong>{{ player.MRTCchange.toFixed(0) }}<sub>%</sub></strong>
                        </template>
                          <template v-else>
                          <strong>{{ player.TCchange.toFixed(0) }}<sub>%</sub></strong>
                        </template>
                        </span>
                       
                  </div>
 
                </div>
              </div> 
            </div>
          </swiper-slide>
        </template>
      </swiper>
    </div>
  </div>
</template>



<script>
import "swiper/dist/css/swiper.css";
import { swiper, swiperSlide } from "vue-awesome-swiper";

export default {
  components: {
    swiper,
    swiperSlide,
  },
  methods: {
    getroles(type) {
      const keys = Object.keys(type);
      var returnvalues = [];
      keys.forEach((key, index) => {
        returnvalues.push({
          k: key,
          v: type[key] * 100,
        });
      });

      var formated = this.lodash.orderBy(returnvalues, ["v"], ["desc"]);

      var finals = "";

      formated.forEach(function (_role, index) {
        if (index <= 3) {
          if (finals != "") {
            finals = finals + " | " + _role["k"];
          } else {
            finals = _role["k"];
          }
        }
      });

      return finals;
    },
    getposition(type) {
      var _p = this.lodash.find(this.positions, function (my) {
        return my.value == type;
      });
      if (_p) return _p.name;
      return "";
    },
    setTab(tab) {
      this.playerslist = [];
      this.currentab = tab;
      if (tab == 1) {
        this.$store.dispatch("getStockrisers").then((response) => {
          this.playerslist = [];
          var _games = [];
          if (response && response.length > 0) {
            this.playerslist = response;
          }
        });
      } else {
        this.$store.dispatch("getHiddengems").then((response) => {
          this.playerslist = [];
          var _games = [];
          if (response && response.length > 0) {
            this.playerslist = response;
          }
        });
      }
    },
  },
  data: () => ({
    positions: [
      {
        name: "Power Forward",
        value: "F-C",
      },
      {
        name: "Forward",
        value: "F",
      },
      {
        name: "Versatile Center",
        value: "C-F",
      },
      {
        name: "Center",
        value: "C",
      },
      {
        name: "Combo Guard",
        value: "G-F",
      },
      {
        name: "Guard",
        value: "G",
      },
      {
        name: "Wing",
        value: "F-G",
      },
    ],
    currentab: 1,
    playerslist: [],
    swiperOption: {
      slidesPerView: "auto",
      spaceBetween: 20,
      pagination: {
        el: ".swiper-pagination",
      },
      navigation: {
        nextEl: ".home-slider2_right",
        prevEl: ".home-slider2_left",
      },
    },
  }),
  mounted() {
    this.setTab(1);
  },
  computed: {},
};
</script> 