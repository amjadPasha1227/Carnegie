<template>
  <div class="goal_performance">
    <div class="home_slider">
      <div class="slider__header">
        <h3>Top Shooters</h3>
        <div class="slider__header_actions">
          <ul>
            <li><a class="active">Last Week</a></li>
            <li><router-link to="/top-performers">Last Three Months</router-link></li>
            <li>
              <router-link to="/top-performers">Current Season</router-link>
            </li>
          </ul>
          <div class="slider_navigation">
            <div class="swiper-button-prev home-slider3-left"></div>
            <div class="swiper-button-next home-slider3-right"></div>
          </div>
        </div>
      </div>

      <swiper ref="awesomeSwiperA" :options="swiperOption">
        <template v-for="(player, index) in playerslist">
          <swiper-slide :key="index">
            <div class="goal_block">
              <div class="player_profile">
                <div class="player_dp">
                  <figure>
                    <template v-if="player.PLAYER_IMAGE">
                      <img
                        :src="player.PLAYER_IMAGE"
                        class="align-self-center"
                        :alt="player.PLAYER_NAME"
                      />
                    </template>
                    <template v-else>
                      <img
                        :src="
                          'https://profitx.ai/api/viewfile?path=playerimages/' +
                          player.GPlayerID +
                          '.png'
                        "
                        class="align-self-center"
                        :alt="player.PLAYER_NAME"
                      />
                    </template>
                  </figure>
                  <span class="teamLogo"><img :src="player.team.logo" /></span>
                </div>
                <div class="player_info">
                  <h4>{{ player.PLAYER_NAME }}</h4>
                  <p>{{ getposition(player.Position) }}</p>
                </div>
              </div>
              <div class="goal_graph" style="position: relative">
                <figure class="nbacourt">
                  <div class="left3pt">
                    <ul>
                      <li>
                        <span> LEFT 3PT Rating</span
                        ><strong>
                          {{ (player.left3pt * 100).toFixed(0) }}</strong
                        >
                      </li>
                    </ul>
                  </div>

                      <div class="right3pt">
                    <ul>
                      <li>
                        <span> RIGHT 3PT Rating</span
                        ><strong>
                          {{ (player.right3pt * 100).toFixed(0) }}</strong
                        >
                      </li>
                    </ul>
                  </div>

                        <div class="mid3pt">
                    <ul>
                      <li>
                        <span> MIDRANGE Rating</span
                        ><strong>
                          {{ (player.midrange * 100).toFixed(0) }}</strong
                        >
                      </li>
                    </ul>
                  </div>


                         <div class="center3pt">
                    <ul>
                      <li>
                        <span> CENTER 3PT Rating</span
                        ><strong>
                          {{ (player.center3pt * 100).toFixed(0) }}</strong
                        >
                      </li>
                    </ul>
                  </div>
           
                </figure>
                <ul>
                  <li>
                    <span>SharpShooting Rating</span>
                    <strong
                      >{{ (player.ROLES.Sharpshooter * 100).toFixed(0) }}<sub
                      ></sub
                    ></strong>
                  </li>
                  <li>
                    <span>3PT%</span>
                    <strong
                      >{{
                        ((player["3PTM"] / player["3PTA"]) * 100) | percent(2)
                      }}<sub></sub
                    ></strong>
                  </li>
                </ul>
              </div>
            </div>
          </swiper-slide>
        </template>
      </swiper>
    </div>
  </div>
</template>



<script>
import "swiper/dist/css/swiper.css";
import { swiper, swiperSlide } from "vue-awesome-swiper";
export default {
  components: {
    swiper,
    swiperSlide,
  },
  methods: {
    getposition(type) {
      var _p = this.lodash.find(this.positions, function (my) {
        return my.value == type;
      });
      return _p.name;
    },
  },
  data: () => ({
    playerslist: [],
    positions: [
      {
        name: "Power Forward",
        value: "F-C",
      },
      {
        name: "Forward",
        value: "F",
      },
      {
        name: "Versatile Center",
        value: "C-F",
      },
      {
        name: "Center",
        value: "C",
      },
      {
        name: "Combo Guard",
        value: "G-F",
      },
      {
        name: "Guard",
        value: "G",
      },
      {
        name: "Wing",
        value: "F-G",
      },
    ],
    swiperOption: {
      slidesPerView: "auto",
      spaceBetween: 20,
      pagination: {
        el: ".swiper-pagination",
      },
      navigation: {
        nextEl: ".home-slider3-right",
        prevEl: ".home-slider3-left",
      },
    },
  }),
  mounted() {
    this.$store.dispatch("getTopshooters").then((response) => {
      this.playerslist = [];
      var _games = [];
      if (response && response.length > 0) {
        this.playerslist = response;
      }
    });
  },
  computed: {},
};
</script> 
