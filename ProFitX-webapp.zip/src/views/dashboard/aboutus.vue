<template>
  <div class="aboutus_wrap">
      <!-- <div class="slider_navigation">
        <div class="swiper-button-prev about_prev"><span class="icon-play-flip"></span></div>
        <div class="swiper-button-next about_next"><span class="icon-play"></span></div>
      </div> -->
      <div class="aboutus">        
        <swiper 
         ref="awesomeSwiperA" 
         :options="swiperOption" 
           
         >
        <swiper-slide>
          <div class="slide1">
            <h4>About ProFitX</h4>
            <p>
              ProFitX is committed to creating balance within sports by democratizing
              information and continuing to defy the limits of performance and financial
              analytics. Our innovative technology is supported by Artificial
              Intelligence and allows us to do the hard work while you make informed
              decisions on the fly.
            </p>
            <div class="btns">
              <router-link to="/pricing" class="btn">Subscribe</router-link>
              <a href="/corporate" class="btn">Explore</a>
            </div>
            <div class="slider_navigation">
        <div class="swiper-button-prev about_prev"><span class="icon-play-flip"></span></div>
        <div class="swiper-button-next about_next"><span class="icon-play"></span></div>
      </div>
          </div>
        </swiper-slide>
          <swiper-slide>
          <div class="slide2">
            <h4>Sports Probability Platform</h4>
            <p>
Allow the technology to give you the most up-to-date, back tested, and accurate real-time basketball analytics on the market.             </p>
            <p>Access pre-game and in-game injury assessments and scouting tools that update in real-time and show you the impact they have on the overall game play and outcome.  </p>
            <div class="btns">
              <router-link to="/pricing" class="btn">Subscribe</router-link>
              <a href="/corporate" class="btn">Explore</a>
            </div>
            <div class="slider_navigation">
        <div class="swiper-button-prev about_prev"><span class="icon-play-flip"></span></div>
        <div class="swiper-button-next about_next"><span class="icon-play"></span></div>
      </div>
          </div>
        </swiper-slide>
        <swiper-slide>
          <div class="slide2">
            <h4>Performance Projections & Scouting Tools</h4>
            <!-- <p>Our team synergy lineups show how much better teams can be, their live game analysis & projections rate in real-time, and allow users to see just how well their favorite players work with each other.</p> -->
            <p>AI athlete performance projections shows how well a player is projected to play during pre-match and live game updates.</p>
            <div class="btns">
              <router-link to="/pricing" class="btn">Subscribe</router-link>
              <a href="/corporate" class="btn">Explore</a>
            </div>
            <div class="slider_navigation">
        <div class="swiper-button-prev about_prev"><span class="icon-play-flip"></span></div>
        <div class="swiper-button-next about_next"><span class="icon-play"></span></div>
      </div>
          </div>
        </swiper-slide>
        <swiper-slide>
          <div class="slide3">
            <h4>Synergy Lineups</h4>
            <p>
                Our team synergy lineups show how much better teams can be, their live game analysis & projections rate in real-time, and allow users to see just how well their favorite players work with each other. 
              
            </p>
            <div class="btns">
              <router-link to="/pricing" class="btn">Subscribe</router-link>
              <a href="/corporate" class="btn">Explore</a>
            </div>
            <div class="slider_navigation">
        <div class="swiper-button-prev about_prev"><span class="icon-play-flip"></span></div>
        <div class="swiper-button-next about_next"><span class="icon-play"></span></div>
      </div>
          </div>
        </swiper-slide>
      </swiper>
      
      </div>
      
    </div>
</template>

<script>
import "swiper/dist/css/swiper.css";
import { swiper, swiperSlide } from "vue-awesome-swiper";
export default {
   components: { 
      swiper,
      swiperSlide,
    },
    data: () => ({    
      swiperOption: { 
        slidesPerView:1,
        spaceBetween: 20,
        autoHeight: true,        
        navigation: {
          nextEl: ".about_next",
          prevEl: ".about_prev",
        },
        autoplay:{
          delay:8000,
          disableOnInteraction: false
        },
        loop: true, 
      },
    }),

};
</script>