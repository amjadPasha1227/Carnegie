<template>
  <div class="content-body">
    <sidebar v-if="player != null" :player="player" />

    <div class="content-wrapper">
      <div class="athlete_content_wrap">
        <v-row>
          <v-col><player-details v-if="player" :player="player" /></v-col>
        </v-row>
        <div class="nodataBox" v-if="player && player.RTC == null">
          No Data Available
        </div>

         <div class="nodataBox" v-if="player && player.totalgames <  40">

                Profile will display once player has met minimum data threshold to ensure accuracy.
            </div>
            
        <div class="athlete_body_content" v-if="player && player.RTC">
          <team-fit
            v-if="player != null && checkWidgetsPermessions('TEAMFIT')"
            :player="player"
          />

          <v-row>
            <v-col cols="12">
              <start-system
                v-if="
                  player.PLAYER_NAME != null &&
                  checkWidgetsPermessions('STAR_SYSTEM')
                "
                :player="player"
              />
            </v-col>
          </v-row>

          <v-row v-if="checkWidgetsPermessions('TRADE_VALUE')">
            <v-col
              ><trade-assets v-if="player != null" :player="player"
            /></v-col>
          </v-row>
          <v-row>
            <v-col>
              <player-synergy
                v-if="
                  player.PLAYER_NAME != null &&
                  checkWidgetsPermessions('PLAYER_SYNERGY')
                "
                :player="player"
                :playerid="player.PLAYER_ID"
              />
            </v-col>
          </v-row>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import playerDetails from "@/views/components/playerDetails.vue";

import Sidebar from "@/layouts/components/Sidebar.vue";
import startSystem from "@/views/components/startSystem.vue";
import teamFit from "@/views/components/teamFit.vue";
import tradeAssets from "@/views/components/tradeAssets.vue";
import playerSynergy from "@/views/components/playerSynergy.vue";
import moment from "moment";

export default {
  components: {
    startSystem,
    teamFit,
    tradeAssets,
    playerSynergy,
    Sidebar,
    playerDetails,
  },
  methods: {
    getplayers() {
      this.isloading = true;
      this.serach = {
        page: 1,
        perpage: 1,
        matcher: {
          playerId: this.$route.params.id,
        },
      };

      this.$store.dispatch("getplayerdetails", this.serach).then((response) => {
        if (response.error) {
          Object.assign(this.formerrors, {
            msg: response.error.message,
          });
        } else {
          this.totalCount = response.data.result.totalCount;
          let nitem = response.data.result.list[0];

          var totalgames = 0;

          nitem["seasons"].forEach(function (tem) {
            totalgames = totalgames + tem.GP;
          });
          nitem.totalgames = totalgames;
          nitem._matches =  this.lodash.orderBy(nitem.matches, o => moment(o.gamedate));

          this.player = nitem;
        }
        var self = this;
        setTimeout(function () {
          self.isloading = false;
        }, 1000);
      });
    },
  },
  mounted() {
    this.getplayers();
  },
  data() {
    return {
      player: null,
    };
  },
};
</script>