/////////// Common ///////////////////
$(document).ready(function(){
  $("html, body").animate({
      scrollTop: 0
  });
  return false;
});
$(window).scroll(function() {
  if ($(this).scrollTop() > 100) {
      $('.scroll-top').fadeIn();
  } else {
      $('.scroll-top').fadeOut();
  }
});


$('.subnav_cnt').hide();
$('.subnav_cnt:first').show()
$(document).on('click','nav ul li a', function(event) {
  $(this).parent().addClass('active');
  $(this).parent().siblings().removeClass('active');
  var t = $(this).attr('href');
    $('#tabs li a').addClass('inactive');        
    $(this).removeClass('inactive');
    $('.subnav_cnt').hide();
    $(t).fadeIn('slow');
    return false;
});

$('.subnav_cnt h2').click(function(){
  $(this).parent().find('.nav_details_wrap').slideToggle();
  $(this).toggleClass('active');
  $(this).parent().siblings().find('.nav_details_wrap').slideUp();
  $(this).parent().siblings().find('h2').removeClass('active');
});


$('.scroll-top').click(function () {
  $("html, body").animate({
      scrollTop: 0
  }, 300);
  return false;
});


$('.menu_icon').click(function(){
  $('#nav-icon').toggleClass('open');
  $('body').toggleClass('navopen');
   
});

/////////// Home Page /////////////////
var swiper = new Swiper(".testimonial_swiper", {
  navigation: {
  nextEl: ".swiper-button-next",
  prevEl: ".swiper-button-prev",
  },
});

var nav = document.getElementById("mynav");
var sticky = nav.offsetTop;
window.onscroll = function() {myFunction() , focusFunction ()};
function myFunction() {
    if (window.pageYOffset > sticky) {
        nav.classList.add("stickynav");
    } else {
        nav.classList.remove("stickynav");
    }
};

var header = document.getElementById("myheader");
var stickyheader = header.offsetTop;

function focusFunction() {
    if (window.pageYOffset > stickyheader) {
      header.classList.add("stickyheader");
    } else {
      header.classList.remove("stickyheader");
    }
};
 
