import { mapMarkerSolid } from 'config/icons'
import Div from 'shared/Basic/Div'
import dayjs                             from 'dayjs'
import S3Img                             from 'shared/Basic/S3Img'
import Gravatar                          from 'react-gravatar'

import Icon from 'shared/Basic/Icon'
import LinkSwitch
    from 'shared/Basic/LinkSwitch'
import InclusiveScore from './InclusiveScore'
import { placeCardInclusiveScoreInfoStyle, placeCardInclusiveScoreWrapperStyle, placeCardStyle } from './styles'
import { CDN } from 'config/variables'
import MapImg from '../../../assets/map.svg'
import StarImg from '../../../assets/star.svg'
// import Welcome from 'features/user/views/dashboard/Welcome'
import Safe from '../../../assets/places_safe.svg'
import Welcome from '../../../assets/places_welcome.svg'
import Celebrated from '../../../assets/places_celebrated.svg'

const assembleAddress = (address, city, state) => {
    let components = [address, city, state].filter(Boolean); // This will filter out any null, undefined or empty strings
    return components.join(', ');
}

const PlaceCard = ({
    place,
    address,
    city,
    name,
    state,
    safe,
    celebrated,
    welcome,
    inclusiveScore,
    linkCard,
    url,
    isPending = false,
    styleType = 1,
    hideScore,
    theme,
    reviews = []
}) => {
    console.log(place)
    return (
        <Div className='no-underline-link business_reviews' id="business_reviews">
            <LinkSwitch url={!!linkCard ? url : ''} >

            { styleType === 3 &&
            <div className='swiper_cnt cnt_top'>
                                    <div className='cnt_left'>
                                        <div className='search_name'>{place?.name}</div>

                                        { !place?.address &&
                      <div className='location'><img src={MapImg} />{place?.geojson?.[0]?.properties.address}, {place?.geojson?.[0]?.properties.city}, {place?.geojson?.[0]?.properties.state}</div>
                    }
                      { place?.address &&

<div className='location'><img src={MapImg} />{place?.address}, {place?.city}, {place?.state}</div>
                   } 
                                    </div>
                                    <span className='category'>{place?.type}</span>
                                </div>

            }

                <div className='swiper_image'>
                    {place?.photo &&

                            <div
                            style={{
                            backgroundImage: `url(${CDN + place?.photo})`,
                            backgroundSize: 'cover', 
                            backgroundPosition: 'center',
                            backgroundRepeat: 'no-repeat',
                            width: '100%',
                            height: '100%',
                            }}
                            />

                    }
                    {!place?.photo &&
                        <div class="no-img-placeholder"> </div>

                    }
                    <span className='category'>{place?.type}</span>
                </div>
                { styleType != 3 &&
                <div className='swiper_cnt'>
                    <div className='search_name'> <LinkSwitch
                        url={!linkCard ? url : ''}
                        theme={{ ...placeCardStyle.name, ...theme.name }}
                    >
                            

                        {name}
                    </LinkSwitch></div>
              

{
    place && (
        place.address || (place.geojson && place.geojson[0]?.properties) ? 
        <div className='location'>
            <img src={MapImg} />
            {place.address ? 
                assembleAddress(place.address, place.city, place.state) : 
                assembleAddress(place.geojson[0].properties.address, place.geojson[0].properties.city, place.geojson[0].properties.state)
            }
        </div> : 
        null
    )
}

                    <div className='rating'><img src={StarImg} /> {place?.inclusiveScore} <em>({place?.reviews?.length} reviews)</em></div>

                    {
                    styleType === 1 ? (
                        <div className='comments_ratings' >
                        <ul>
                            <li>
                                <div className="progress_bar">
                                    <div className="percent">
                                        <svg>
                                            <circle cx="19" cy="19" r="17"></circle>
                                            <circle cx="19" cy="19" r="17" style={{ strokeDashoffset: `calc(105px - (105px * ${safe}) / 5)` }}></circle>
                                        </svg>
                                        <div className="number">
                                            <h3>{safe}</h3>
                                        </div>
                                    </div>
                                </div>
                                <em>Safe</em>
                            </li>
                            <li>
                                <div className="progress_bar">
                                    <div className="percent">
                                        <svg>
                                            <circle cx="19" cy="19" r="17"></circle>
                                            <circle cx="19" cy="19" r="17" style={{ strokeDashoffset: `calc(105px - (105px * ${welcome}) / 5)` }}></circle>
                                        </svg>
                                        <div className="number">
                                            <h3>{welcome}</h3>
                                        </div>
                                    </div>
                                </div>
                                <em>Welcome</em>
                            </li>
                            <li>
                                <div className="progress_bar">
                                    <div className="percent">
                                        <svg>
                                            <circle cx="19" cy="19" r="17"></circle>
                                            <circle cx="19" cy="19" r="17" style={{ strokeDashoffset: `calc(105px - (105px * ${celebrated}) / 5)` }}></circle>
                                        </svg>
                                        <div className="number">
                                            <h3>{celebrated}</h3>
                                        </div>
                                    </div>
                                </div>
                                <em>Celebrated</em>
                            </li>
                        </ul>
                    </div>
                    ) : (
                        <div className='comments_ratings rating'>
                        <ul>
                            <li>
                               <img src={Safe} />
                               <span>{safe}</span>  
                               <em>Safe</em>
                            </li>
                            <li>
                               <img src={Welcome} />
                               <span>{welcome}</span>
                               <em>Welcome</em>
                            </li>
                            <li>
                               <img src={Celebrated} />
                               <span>{celebrated}</span>
                               <em>Celebrated</em>
                            </li>
                        </ul>
                    </div>
                    )
                }
           

               
                </div>

               }
                { styleType === 3 &&

                <div className='swiper_cnt cnt_bottom'>
                <span className='days_count'>  {dayjs(place?.firstTopRatedReview?.updated).format('MMMM DD, YYYY')}</span>
                <div className='profile_icon'>
                {((place?.firstTopRatedReview?.reviewerAvatar && !place?.firstTopRatedReview?.isAnon) && (
                                        <div className='reviewer_icon'>
                                            <S3Img url={place?.firstTopRatedReview?.reviewerAvatar} />
                                        </div>
                                    )) || (
                                        <Div  className='reviewer_icon'>
                                            <Gravatar
                                                email={!place?.firstTopRatedReview?.isAnon ? place?.firstTopRatedReview?.reviewerEmail : ''} size={200}/>
                                        </Div>
                                    )}
                </div>
                <div className='cnt_right'>
                    <div className='search_name'>{place?.firstTopRatedReview?.reviewerName}</div>
                    <div className='rating'><img src={StarImg} /> {place?.inclusiveScore} <em>({place?.reviews?.length} reviews)</em></div>
                    <div className='comments_ratings' >
                        <ul>
                            <li>
                                <div className="progress_bar">
                                    <div className="percent">
                                        <svg>
                                            <circle cx="19" cy="19" r="17"></circle>
                                            <circle cx="19" cy="19" r="17" style={{ strokeDashoffset: `calc(105px - (105px * ${safe}) / 5)` }}></circle>
                                        </svg>
                                        <div className="number">
                                            <h3>{safe}</h3>
                                        </div>
                                    </div>
                                </div>
                                <em>Safe</em>
                            </li>
                            <li>
                                <div className="progress_bar">
                                    <div className="percent">
                                        <svg>
                                            <circle cx="19" cy="19" r="17"></circle>
                                            <circle cx="19" cy="19" r="17" style={{ strokeDashoffset: `calc(105px - (105px * ${welcome}) / 5)` }}></circle>
                                        </svg>
                                        <div className="number">
                                            <h3>{welcome}</h3>
                                        </div>
                                    </div>
                                </div>
                                <em>Welcome</em>
                            </li>
                            <li>
                                <div className="progress_bar">
                                    <div className="percent">
                                        <svg>
                                            <circle cx="19" cy="19" r="17"></circle>
                                            <circle cx="19" cy="19" r="17" style={{ strokeDashoffset: `calc(105px - (105px * ${celebrated}) / 5)` }}></circle>
                                        </svg>
                                        <div className="number">
                                            <h3>{celebrated}</h3>
                                        </div>
                                    </div>
                                </div>
                                <em>Celebrated</em>
                            </li>
                        </ul>
                    </div>
                </div>
                </div>
                }




            </LinkSwitch>
        </Div>
    )
}

PlaceCard.defaultProps = {
    theme: {}
}

export default PlaceCard
