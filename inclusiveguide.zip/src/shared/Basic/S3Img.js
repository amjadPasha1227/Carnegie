import {CDN} from 'config/variables'
import Img   from './Img'

const S3Img = ({url, alt, theme, ...props}) => url ? (
    <Img
        src={`${CDN}${url}`}
        alt={alt}
        theme={{maxWidth: '100%', width: 'auto', ...theme}}
        {...props}
    />
) : null


S3Img.defaultProps = {
    theme: {},
}

export default S3Img
