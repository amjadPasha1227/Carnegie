import {AnimatePresence}          from 'framer-motion'
import {useEffect}                from 'react'
import {
    useDispatch,
    useSelector
}                                 from 'react-redux'
import {
    resolvedPromise,
    timeoutAsync
}                                 from 'utils/helpers'
import MotionDiv                  from 'shared/Basic/MotionDiv'
import Div                                                       from '../Basic/Div'
import {notificationInnerWrapperStyle, notificationWrapperStyle} from './styles'

const Notification = () => {
    const dispatch = useDispatch()
    const {notification, notificationTheme, notificationDelay} = useSelector(state => state.site)

    //TODO: can improve
    const clearNotification = async () => {
        await timeoutAsync(notificationDelay ? notificationDelay : 3000)
        await resolvedPromise(dispatch({type: 'site/clearNotification'}))
        await clearTimeout(timeoutAsync)
    }

    useEffect(() => {
        if(notification)
           clearNotification()

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [notification])

    return (
        <AnimatePresence>
            {notification && (
                <MotionDiv
                    key={'notification'}
                    initial={{
                        y: 20,
                        x: -480,
                        height: 0,
                        opacity: 0
                    }}
                    animate={{
                        height: 'auto',
                        y: 20,
                        x: 20,
                        opacity: 1,
                        transition: {
                            duration: 0.25,
                            ease: 'easeOut'
                        }
                    }}
                    exit={{
                        height: 0,
                        opacity: 0,
                        transition: {
                            duration: 0.15,
                            ease: 'easeOut'
                        }
                    }}
                    theme={notificationWrapperStyle(notificationTheme)}
                >
                    <Div theme={notificationInnerWrapperStyle}>
                        {notification}
                    </Div>
                </MotionDiv>
            )}
        </AnimatePresence>
    )
}

export default Notification
