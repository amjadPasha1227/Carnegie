import {bookmark}                 from 'config/icons'
import {useEffect}                from 'react'
import {useDispatch, useSelector} from 'react-redux'
import Div                        from 'shared/Basic/Div'
import DashboardContent           from 'shared/Layout/Dashboard/DashboardContent'
import {dashboardStyle}           from 'shared/Layout/Dashboard/styles'
import DashboardMenu              from 'shared/Menus/DashboardMenu'
import DashboardBusiness          from './DashboardBusiness'

const DashboardWrapper = ({menu, children}) => {
    const dispatch = useDispatch()
    const {user} = useSelector(state => state.user)
    const {slug} = useSelector(state => state.site)

    const {placesOwned} = user
    const myBusinessMenuOption = {
        url: '/dashboard/my-businesses',
        icon: bookmark,
        title: 'My Business',
        active: ['business'],
    }

    useEffect(() => {
        if (placesOwned?.length > 0) {
            dispatch({
                type: 'place/getPlacesByIds',
                payload: {
                    ids: placesOwned,
                    caller: 'my-businesses'
                }
            })
        }else{


        }

        document.body.classList.add('dashboad_pages')
            return () => {
            document.body.classList.remove('dashboad_pages')
        }
    }, [placesOwned, dispatch])

    return (
        <Div id="dashboard-wrap" theme={dashboardStyle}>
            <DashboardMenu menu={placesOwned?.length > 0 ? [...menu, myBusinessMenuOption] : menu}/>
            { slug  != 'dashboard' &&
                <DashboardContent content={children}/>
            }
            { slug  == 'dashboard' && placesOwned?.length == 0 &&
                    <DashboardContent content={children}/>
            }
            { slug  == 'dashboard' && placesOwned?.length > 0 &&
                    <DashboardBusiness content={children}/>
            }
          
        </Div>
    )
}


export default DashboardWrapper
