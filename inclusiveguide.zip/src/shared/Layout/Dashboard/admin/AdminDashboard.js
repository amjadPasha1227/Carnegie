import {adminDashboardMenu}       from 'config/menus/dashboard/admin'
import {useDispatch, useSelector}              from 'react-redux'
import ContentWrapper             from 'shared/Layout/ContentWrapper'
import DashboardInfo              from 'shared/Layout/Dashboard/DashboardInfo'
import DashboardWrapper           from 'shared/Layout/Dashboard/DashboardWrapper'
import {adminContentWrapperStyle} from '../../styles'
import Div   from 'shared/Basic/Div'
import { useEffect } from 'react'

const AdminDashboard = () => {
    const {nameFirst, tel} = useSelector(state => state.user)
    // const {coords} = useContext(mapContext)
    // /geocoding/v5/{endpoint}/{longitude},{latitude}.json
    const { adminstats } = useSelector(state => state.place)
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch({ type: 'place/getAdminstats' })

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    return (
        <ContentWrapper theme={adminContentWrapperStyle}>
        <DashboardWrapper menu={adminDashboardMenu}>
            <DashboardInfo
                heading={`Hey, ${nameFirst}`}
                description={`${tel}`}
            />
            <Div className='db_count'>
                <ul>
                    <li>
                        <label>Total Reviews</label>
                        <span>{adminstats?.reviews || 0}</span>
                    </li>
                    <li>
                        <label>Total Users</label>
                        <span>{adminstats?.users || 0}</span>
                    </li>
                    <li>
                        <label>Total Businesses</label>
                        <span>{adminstats?.totalPlaces || 0}</span>
                    </li>
                    <li>
                        <label>Claimed Businesses</label>
                        <span>{adminstats?.claimedPlaces || 0}</span>
                    </li>
                </ul>
            </Div>
        </DashboardWrapper>
    </ContentWrapper>
    
    )
}

export default AdminDashboard
