import {adminDashboardMenu} from 'config/menus/dashboard/admin'
import {userDashboardMenu}  from 'config/menus/dashboard/user'
import PropTypes            from 'prop-types'
import {useSelector}        from 'react-redux'
import DashboardWrapper     from 'shared/Layout/Dashboard/DashboardWrapper'

const AdminDashboardWrapper = ({children, title, description}) => {
    const {isAdmin} = useSelector(state => state.user)
    return (
        <DashboardWrapper
            menu={isAdmin ? adminDashboardMenu : userDashboardMenu}
            title={title}
            description={description}
        >
            {children}
        </DashboardWrapper>

    )
}

AdminDashboardWrapper.propTypes = {
    children: PropTypes.oneOfType([
        PropTypes.array,
        PropTypes.object,
    ]).isRequired,
    title: PropTypes.string,
    description: PropTypes.string
}

export default AdminDashboardWrapper
