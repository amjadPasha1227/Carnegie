import React, { useEffect, useMemo, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import Select from 'react-select'
import Div from 'shared/Basic/Div'
import { dashboardStyle } from 'shared/Layout/Dashboard/styles'
import Img from 'shared/Basic/Img'
import Pointer from 'assets/map_pointer.png'
import Upload from 'assets/upload.svg'
import { Carousel } from 'react-carousel-minimal';
import S3Img from 'shared/Basic/S3Img'
import LinkSwitch from 'shared/Basic/LinkSwitch'
import ReviewContainer from 'features/place/views/Place/ReviewContainer'
import dayjs              from 'dayjs'
import RichText                          from 'shared/Basic/RichText'
import {CDN} from 'config/variables'
import {doorOpen, handHoldingHeart, spa} from 'config/icons'
import Icon                              from 'shared/Basic/Icon'
import InviteUser from '../../../features/site/views/Invite.js';
import Gravatar                          from 'react-gravatar'

const DashboardBusiness = ({ menu, children }) => {
    const {globalReviews, demographicoverview, businessAdmins, reviews} = useSelector(state => state.place)
    const dispatch = useDispatch()
    const { slug, _id, token, user, businesses } = useSelector(state => state.user)
    const { placesOwned } = user
    const [busines, setBusines] = useState([])
    const [scorecolor, setScorecolor] = useState([])
    const [imglist, setimglistList] = useState([]);
    const [demogrpahicdata, setDemogrpahicdata] = useState(null)
    const [currentBusinessId, setcurrentBusinessId] = useState(null)
    
    const hubSpotScriptURL = '//js-na1.hs-scripts.com/22167180.js';
    // console.log("business owners ",busines.businessOwner)

    useEffect(() => {
      // Dynamically create a script element for the HubSpot script
      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.id = 'hs-script-loader';
      script.async = true;
      script.defer = true;
      script.src = hubSpotScriptURL;
  
      // Append the script to the document's head
      document.head.appendChild(script);
  
      // Cleanup: Remove the script when the component unmounts
      return () => {
        document.head.removeChild(script);
      };
    }, []); // The empty dependency array ensures this effect runs only once
  
    const calculatePercentages = (body) => {
        var  reviewsData = body.data;
        const totalReviews = reviewsData.length;
      
        // Initialize counters for each group
        let maleCount = 0;
        let femaleCount = 0;
        let nonBinaryCount = 0;
        let ableCount = 0;
        let disabilityCount = 0;
        let whiteCount = 0;
        let bipocCount = 0;
      
        reviewsData.forEach((review) => {
          const gender = review.users.identity.gender[0].name;
          const disability =
            review.users.identity.blind ||
            review.users.identity.deaf ||
            review.users.identity.hearingImpairment ||
            review.users.identity.guideAnimal ||
            review.users.identity.visualImpairment;
          const race = review.users.identity.race.length > 0 ? review.users.identity.race[0].name : null;
      
          // Counting gender groups
          if (gender === 'Male') {
            maleCount++;
          } else if (gender === 'Female') {
            femaleCount++;
          } else if (gender === 'Non-binary') {
            nonBinaryCount++;
          }
      
          // Counting ability/disability groups
          if (disability) {
            disabilityCount++;
          } else {
            ableCount++;
          }
      
          // Counting race groups
          if (race === 'White') {
            whiteCount++;
          } else if (race !== null) {
            bipocCount++;
          }
        });
      
        // Calculate percentages
        const malePercentage = ((maleCount / totalReviews) * 100).toFixed(2);
        const femalePercentage = ((femaleCount / totalReviews) * 100).toFixed(2);
        const nonBinaryPercentage = ((nonBinaryCount / totalReviews) * 100).toFixed(2);
        const ablePercentage = ((ableCount / totalReviews) * 100).toFixed(2);
        const disabilityPercentage = ((disabilityCount / totalReviews) * 100).toFixed(2);
        const whitePercentage = ((whiteCount / totalReviews) * 100).toFixed(2);
        const bipocPercentage = ((bipocCount / totalReviews) * 100).toFixed(2);
      
        return {
          malePercentage,
          femalePercentage,
          nonBinaryPercentage,
          ablePercentage,
          disabilityPercentage,
          whitePercentage,
          bipocPercentage,
        };
      };
      
    const formattedBusinessList = useMemo(() => {
        return businesses?.map((eachBusiness) => ({
            value: eachBusiness._id,
            label: eachBusiness.name,
        }))

    })

    function SemiCircleChart({value}){
        const angle = (value / 100) * 180; // Dividing by 100 since max is always 100
        const style = {'--angle': angle + 'deg'};
      
        return (
          <div className="sc-gauge">
            <div className="sc-background">
              <div className="sc-percentage" style={style}></div>
              <div className="sc-mask"></div>
              <span className="sc-value">{ value }</span>
            </div>
          </div>
        );
      }

      
    const formatScore = (score) => {
        let formattedScore = parseFloat((score * 20).toFixed(2));
        if (isNaN(formattedScore)) return '0';
        return formattedScore % 1 === 0 ? formattedScore.toString() : formattedScore.toFixed(2);
    };

    useEffect(() => {
        dispatch({
            type: 'place/setCurrentPlaceId',
            payload: {
                placeId: currentBusinessId
            }
        })
        if(!!currentBusinessId){
            dispatch({type: 'place/getReviews', payload: { token, placeId: currentBusinessId}})
        }
    },[currentBusinessId])

    useEffect(() => {
        setcurrentBusinessId(businesses?.[0] ? businesses[0]?._id : "")
    },[businesses])
    useEffect(() => {

        dispatch({
            type: 'user/getUser',
            payload: {
                slug: slug,
                _id: _id,
                token: token
            }
        })

        document.body.classList.add('dashboad_pages')
        return () => {
            document.body.classList.remove('dashboad_pages')
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        
    }, [])

    useEffect(() => {
        if(demographicoverview && demographicoverview?.data){
            setDemogrpahicdata(demographicoverview?.data);
        }
       
    }, [demographicoverview, currentBusinessId])
    useEffect(() => {
        if (businesses?.length > 0 && (!!currentBusinessId) ) {
            setBusines(() => (businesses.filter((eachBusiness) => eachBusiness?._id == currentBusinessId))?.[0])
            // setBusines(businesses[0])
            dispatch({
                type: 'place/getGlobalReviews',
                 payload: {
                     lat: busines?.lat,
                     _id: busines?._id,
                     token: token,
                     lng: busines?.lng
                 }
                     }
                 )
                 setDemogrpahicdata(null)
            if (currentBusinessId) {
                dispatch({
                    type: 'place/getDemographicoverviews',
                    payload: {
                        _id: currentBusinessId
                    }
                })

                dispatch({
                    type: 'place/getBusinessAdmins',
                    payload: {
                        _id: currentBusinessId,
                    }
                })
            }

            if (busines?.inclusiveScore * 20 < 30) {
                setScorecolor('count low')
            }
            if (busines?.inclusiveScore * 20 > 30 && busines.inclusiveScore < 60) {
                setScorecolor('count medium')
            }
            if (busines?.inclusiveScore * 20 > 60) {
                setScorecolor('count high')
            }
            var imgl = [];
            if(busines?.photo){
                imgl.push({'image':CDN+busines?.photo})

            }
            setimglistList(imgl)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps

    }, [currentBusinessId])

    const modalOpen = () => {    
        document.body.classList.add('modal_open');
      };
      const modalclose = () => { 
        document.body.classList.remove('modal_open');
    };

    const AvatarComponent = ({ eachAdmin }) => {
        if (eachAdmin?.avatar) {
            return (
                <div className='reviewer_icon'>
                    <S3Img url={eachAdmin.avatar} />
                </div>
            );
        }
    
        if (eachAdmin?.email) {
            return <Gravatar email={eachAdmin.email} size={200} />;
        }
    
        // Handle case where neither avatar nor reviewerEmail is present
        return null;
    };

    const captionStyle = {
        fontSize: '2em',
        fontWeight: 'bold',
      }
      const slideNumberStyle = {
        fontSize: '20px',
        fontWeight: 'bold',
      }
      const [galaryOpen, setIsActive] = useState(false);

        const handleClick = event => {     
          
            
            setIsActive(current => !current);
            if(!galaryOpen){
                document.body.classList.add('gallery-open')

            } else{
                document.body.classList.remove('gallery-open')

            } 
            
        };

        const handleSelect = event => {
            setcurrentBusinessId(event.value)
        }

        // console.log("business admin details ", businessAdmins)
        const isCurrentUserABusinessOwner = busines?.businessOwner?.includes(_id);

    return (
        <React.Fragment>
            <Div id="dashboard-cnt" theme={dashboardStyle}>
                <div className='page_subheader 2'>
                    <div className='page_subheader_cnt'>
                        <div className='custom_slect'>
                            {(formattedBusinessList?.length > 1) && <Select
                                name={"business"}
                                onChange={handleSelect}
                                placeholder="Select a Business"
                                value={formattedBusinessList.filter(eachOption => eachOption.value === currentBusinessId)}
                                options={formattedBusinessList} 
                                theme={(theme) => ({
                                    ...theme,
                                    colors: {
                                      ...theme.colors,
                                      primary25: 'rgba(255, 180, 0, 0.2)',
                                      primary: 'rgba(255, 180, 0, 0.7)',
                                    }
                                  })}
                                />}
                        </div>
                        <div className='d-flex align-center'>                        
                           
                        {
                isCurrentUserABusinessOwner && (
                    <div className='admins_list'>
                        {
                            businessAdmins?.length > 0 && <>
                                {
                                    businessAdmins.map((eachAdmin) =>
                                        <ul>
                                            <li>
                                                <figure>
                                                    <AvatarComponent eachAdmin={eachAdmin} />
                                                    
                                                    <p>
                                                        {
                                                            (eachAdmin.nameFirst) ? (
                                                                <Div theme={''} className='reviewer_name'>
                                                                    {eachAdmin.nameFirst}
                                                                </Div>
                                                            ) : (
                                                                <Div theme={''} className='reviewer_name'>
                                                                    Inclusive Guide Member
                                                                </Div>
                                                            )
                                                        }
                                                    </p>
                                                </figure>
                                            </li>
                                        </ul>
                                    )
                                }
                            </>
                        }
                        <label>Your <br />Business Admins</label>
                        <span className='add_accounts' onClick={modalOpen}>+</span>
                    </div>
                )
            }
            
                            <div className="chat_block">
                                <LinkSwitch  url={`/commingsoon`} >
                                    Customer Chat
                                </LinkSwitch>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='businesspage_wrap'>
                    <div id='bp_left'>

                        <div className='bp_left-top'>
                            <div className='gallery-sec'>
                                <div className='gallery-head'>
                                    <h5>{busines?.name}</h5>
                                    <span><Img src={Pointer} />{busines?.geojson?.[0]?.properties?.city}, {busines?.geojson?.[0]?.properties?.state}</span>
                                </div>
                                <div className='gallery-image'>
                                    <ul>
                                        <li className='imageupload'>
                                            <LinkSwitch url={`/user/business/update/${busines?.slug}`} >
                                                <input className='imgupload' type='file' />
                                                <span className='uploadcnt'>
                                                    <Img src={Upload} />
                                                    Upload
                                                </span>
                                            </LinkSwitch>
                                        </li>
                                        <li className='gallery-item' onClick={handleClick} >
                                            <figure>
                                                <S3Img url={busines?.photo} itemId={`${busines?.photo}`} key={`${busines?.photo}`} />

                                            </figure>
                                        </li>
                                    </ul>
                                </div>

                                <div className='score-list'>
                                    <div className={scorecolor} >
                               
{ busines?.inclusiveScore && 
<SemiCircleChart
    value={formatScore(busines?.inclusiveScore)}
  />

}

                                    </div>
                                    <div className='score-right'>
                                        <ul>
                                            <li>
                                            <Icon icon={spa}/>
                                                <label>{busines?.averageSafe}</label>
                                                <em>Safe</em>
                                            </li>
                                            <li>
                                            <Icon icon={doorOpen}/>
                                                <label>{busines?.averageWelcome}</label>
                                                <em>Welcome</em>
                                            </li>
                                            <li>
                                            <Icon icon={handHoldingHeart}/>
                                                <label>{busines?.averageCelebrated}</label>
                                                <em>Celebrated</em>
                                            </li>
                                        </ul>
                                        <span className='devider'></span>

                                        <LinkSwitch url={`/places/${busines?.slug}`} >

                                            <a className='all-reviews' >
                                                {busines?.reviews?.length} Reviews ❯
                                            </a>

                                        </LinkSwitch>
                                    </div>
                                </div>
                            </div>
                            <div className="dg_preview">
                                <h4>Demographic Preview</h4>

                                {demogrpahicdata ? (
                                    <div>
            <p className='progress_legends'><span className='high'>WHITE</span><span className='medium'>BIPOC</span></p>                          
            <div className='progress'>
                <span style={{ width: `${demogrpahicdata.whitePercentage}%` }} className='progress_cnt high'>
                    {demogrpahicdata.whitePercentage}%
                </span>
                <span style={{ width: `${demogrpahicdata.bipocPercentage}%` }} className='progress_cnt medium'>
                    {demogrpahicdata.bipocPercentage}%
                </span>
            </div>
            <p className='progress_legends'><span className='high'>ABILITY</span><span className='medium'>DISABILITY</span></p>
            <div className='progress'>
            <span style={{ width: `${demogrpahicdata.ablePercentage}%` }} className='progress_cnt high'>
                {demogrpahicdata.ablePercentage}%
            </span>
            <span style={{ width: `${demogrpahicdata.disabilityPercentage}%` }} className='progress_cnt medium'>
                {demogrpahicdata.disabilityPercentage}%
            </span>
            </div>
            <p className='progress_legends'><span className='high'>MEN</span><span className='medium'>WOMEN</span><span className='low'>NONBINARY</span></p>
            <div className='progress'>
            <span style={{ width: `${demogrpahicdata.malePercentage}%` }} className='progress_cnt high'>
                {demogrpahicdata.malePercentage}%
            </span>
            <span style={{ width: `${demogrpahicdata.femalePercentage}%` }} className='progress_cnt medium'>
                 {demogrpahicdata.femalePercentage}%
            </span>
            <span style={{ width: `${demogrpahicdata.nonBinaryPercentage}%` }} className='progress_cnt low'>
                {demogrpahicdata.nonBinaryPercentage}%
            </span>
            </div>
                                </div>
) : (
    <div>No data available</div>
)}
                    
                            </div>
                        </div>
                        <div className='newest_reviews_sec'>
                            <div className='reviews_head'>
                                <h4>Newest Reviews</h4>
                            </div>
                            <div className='reviews_cnt'>
                                {
                                    (busines?.reviews?.length > 0 && (
                                        <ReviewContainer
                                            // reviewIds={busines.reviews}
                                        />
                                    ))
                                }


                            </div>
                        </div>
                        <LinkSwitch className='view_all' url={`/places/${busines?.slug}`} >
                            VIEW ALL
                        </LinkSwitch>
                    </div>


                    <div id='bp_right'>
                        <div className='global_feed'>
                            <div className='feed_title'>
                                <h4>Global Feed</h4>
                            </div>
                            <div className='feed_cnt_wrap'>
                                <div className='feed_cnt'>
                                {globalReviews && globalReviews.map((review) => (
                                    
                                    review && review.placecategories.length > 0 &&

                                    <div className='feed_item'>
                                    <h5><RichText>{review.review}</RichText></h5>
                                    <p>{review.placecategories.map(item => item['name']).join(', ')}</p>
                                    <span>{dayjs(review.updated).format('MMMM DD, YYYY')}</span>
                                    </div>

                                
                            ))}

                                
                            
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                                    {
                                        imglist?.length > 0 &&
                                        <div id="gallary_thumbs"  className={galaryOpen ? 'gallary-open' : ''} >
                                        <Carousel
                                            data={imglist}
                                            time={2000}
                                            width="850px"
                                            height="500px"
                                            captionStyle={captionStyle}
                                            radius="10px"
                                            slideNumber={true}
                                            slideNumberStyle={slideNumberStyle}
                                            captionPosition="bottom"
                                            automatic={true}
                                            dots={false}
                                            pauseIconColor="white"
                                            pauseIconSize="40px"
                                            slideBackgroundColor="darkgrey"
                                            slideImageFit="cover"
                                            thumbnails={true}
                                            thumbnailWidth="100px"
                                            style={{
                                            textAlign: "center",
                                            maxWidth: "850px",
                                            maxHeight: "500px",
                                            margin: "40px auto",
                                            }}
                                        />
                                
                                        <span className='closegallary' onClick={handleClick}>X</span>
                                        </div>
                                    }

            

            </Div>
            {currentBusinessId &&<Div id="modal_wrap">
                <div className='modal_cnt'>
                    { 
                    currentBusinessId &&
                    
                         <InviteUser   placeId={currentBusinessId} />

                                }
                    <span className='modallayer' onClick={modalclose}></span>
                </div> 
            </Div>}
        </React.Fragment>

        
    )
}



export default DashboardBusiness
