import Div    from 'shared/Basic/Div'
import Routes from 'shared/Containers/Routes'

const Main = ({theme}) =>
    <Div id="main-body" theme={theme} className="main_body">
        <Routes/>
    </Div>

export default Main