import logo                                          from 'assets/logo.png'
import Div                                           from 'shared/Basic/Div'
import Img                                           from 'shared/Basic/Img'
import LinkSwitch                                    from 'shared/Basic/LinkSwitch'
import {headerLogoLinkStyle, headerLogoWrapperStyle} from './styles/header'

const Logo = () => {
    return (
        <Div theme={headerLogoWrapperStyle} className="logo">
            <LinkSwitch url="/" theme={headerLogoLinkStyle}>
                <Img src={logo}/>
            </LinkSwitch>
        </Div>
    )
}

export default Logo
