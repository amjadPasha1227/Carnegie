import {instagram, twitter}                                                  from 'config/icons'
import {siteDisplayName, siteInstagramUrl, siteTwitterUrl}                   from 'config/variables'
import moment                                                                from 'moment'
import PropTypes                                                             from 'prop-types'
import Div                                                                   from 'shared/Basic/Div'
import Icon                                                                  from 'shared/Basic/Icon'
import LinkSwitch                                                            from 'shared/Basic/LinkSwitch'
import Span                                                                  from 'shared/Basic/Span'
import {footerContactStyle, footerIconStyle, footerSocialStyle, footerStyle} from './styles/footer'
import Logo                                            from './Logo'

const Footer = ({theme}) =>
    <Div as="footer" theme={{...footerStyle, ...theme}} className='footer_wrapper'>
        <Div theme={footerStyle.inner} className='footer_inner'>
            <Div theme={footerStyle.innerLinksWrapper} className='footer_menu'>
                <Logo className="footer_logo"/>
                <Div theme={footerStyle.linksWrapper} className='menu'>
                    <LinkSwitch
                        url={'/about'}
                        children={'About'}
                    />
                    <LinkSwitch
                        url={'faq'}
                        children={'FAQ'}
                    />
                    <LinkSwitch
                        url={'https://inclusive-guide.s3.us-east-2.amazonaws.com/assets/InclusiveGuide-PrivacyPolicy-11.18.21.pdf'}
                        children={'Privacy Policy '}
                    />
                    <LinkSwitch
                        url={'https://inclusive-guide.s3.us-east-2.amazonaws.com/assets/InclusiveGuide-TermsOfService-01.18.21.pdf'}
                        children={'Terms of Service'}
                    />
                </Div>
                <LinkSwitch
                        theme={footerStyle.feedback}
                        url={'https://docs.google.com/forms/d/1jVOQmYLDvdTEiGICDmZY9wmSmKirNo1oYNZxO-UjylE/edit?ts=60c78b0f'}
                        children={'Leave us Feedback'}
                        className="feedback_btn"
                    />
            </Div>
        </Div>
        <Div theme={footerStyle.inner}  className='footer_social_sec'>
            <Span theme={footerStyle.copy} className="copyright">&copy; {moment().format('YYYY')} {siteDisplayName}</Span>
            <Div theme={footerSocialStyle} className="footerSocialStyle">
                <LinkSwitch url={siteTwitterUrl}>
                    <Icon icon={twitter} theme={footerIconStyle}/>
                </LinkSwitch>
                <LinkSwitch url={siteInstagramUrl}>
                    <Icon icon={instagram} theme={footerIconStyle}/>
                </LinkSwitch>
            </Div>
        </Div>
    </Div>


Footer.propTypes = {
    theme: PropTypes.object,
}

Footer.defaultProps = {
    theme: {}
}

export default Footer
