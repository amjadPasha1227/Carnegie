import Div                   from 'shared/Basic/Div'
import {contentWrapperStyle} from './styles'

const ContentWrapper = ({children, theme}) =>
    <Div id="content_wrap" theme={{...contentWrapperStyle, ...theme}}>
        {children}
    </Div>

ContentWrapper.defaultProps = {
    theme: {}
}

export default ContentWrapper
