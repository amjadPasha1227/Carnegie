export const fadeIn = {opacity: 1, transition: {delay: .10, ease: 'easeIn'}}
export const fadeOut = {opacity: 0, transition: {ease: 'easeIn'}}
export const nOpacity = {opacity: 0}