import {placeSearchField}                                   from 'features/place/admin/fields/search'
import {placeSearchFormWrapperStyle, placesSearchFormStyle} from 'features/place/views/styles'
import {useContext}                                         from 'react'
import {useSelector}                                        from 'react-redux'
import Div                                                  from 'shared/Basic/Div'
import {mapContext}                                         from 'shared/Containers/MapController'
import {searchContext}                                      from 'shared/Containers/SearchController'
import Form                                                 from 'shared/Fields/Form'
import {unslugify}                                          from 'utils/helpers'

const Search = ({theme}) => {
    const {coords} = useContext(mapContext)
    const {placesIndex} = useContext(searchContext)
    const {slug, url} = useSelector(state => state.site)
    const radius = 1609

    return (
        <Div theme={{...placeSearchFormWrapperStyle, ...theme}} className='home_search_style'>
            <Form
                theme={{...placesSearchFormStyle, ...theme.form}}
                initialValues={{input: url.includes('search') ? unslugify(slug) : ''}}
                fields={placeSearchField}
                dispatchAction={'place/searchAllPlaces'}
                formHeading={'Search'}
                buttonText={"Search"}
                payload={{
                    longitude: coords.lon,
                    latitude: coords.lat,
                    radius: radius,
                    index: placesIndex
                }}
            />
        </Div>
    )
}

Search.defaultProps = {
    theme: {}
}

export default Search
