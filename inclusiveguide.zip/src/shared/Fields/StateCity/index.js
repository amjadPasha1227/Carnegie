import {MAPBOX_PUBLIC}                    from 'config/variables'
import {memo, useEffect, useState}        from 'react'
import Div                                from 'shared/Basic/Div'
import zipcodes                           from 'zipcodes'
import CitySelect                         from './CitySelect'
import StateSelect                        from './StateSelect'

const mapboxGeo = require('@mapbox/mapbox-sdk/services/geocoding');
const geocodingClient = mapboxGeo({accessToken: MAPBOX_PUBLIC});

const StateCity = memo(({name, field, formik, options, theme, value}) => {
    const [filterCityInput, setFilteredCityInput] = useState('')
    const [filteredCityArray, setFilteredCityArray] = useState([])
    const [selectedState, setSelectedState] = useState('')

    useEffect(() => {
        if (value.address1?.length > 0
            && value.city?.length > 0
            && value.state?.length > 0) {
            geocodingClient.forwardGeocode({
                query: `${value.address1} ${value.city} ${value.state}`,
                mode: 'mapbox.places-permanent',
                limit: 2
            })
                .send()
                .then(response => {
                    const match = response.body;
                    const long = match.features[0].center[0]
                    const lat = match.features[0].center[1]
                    formik.setFieldValue('longitude', long)
                    formik.setFieldValue('latitude', lat)
                })

            formik.setFieldValue('zip', zipcodes.lookupByName(value.city, value.state)?.[0]?.zip)
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [value.address1, value.city, value.state])

    return (
        <Div>
            <StateSelect
                className={formik.touched[field.name[0]] && formik.errors[field.name[0]] ? 'error' : ''}
                errorMessage={formik.touched[field.name[0]] && formik.errors[field.name[0]] ? formik.errors[field.name[0]] : null}
                formik={formik}
                name={name}
                theme={theme}
                value={value[name[0]]}
                setSelectedState={setSelectedState}
                selectedState={selectedState}
                setFilteredCityArray={setFilteredCityArray}
            />
            <CitySelect
                className={formik.touched[field.name[1]] && formik.errors[field.name[1]] ? 'error' : ''}
                errorMessage={formik.touched[field.name[1]] && formik.errors[field.name[1]] ? formik.errors[field.name[1]] : null}
                formik={formik}
                name={name}
                theme={theme}
                value={value[name[1]]}
                filteredCityArray={filteredCityArray}
                filterCityInput={filterCityInput}
                setFilteredCityInput={setFilteredCityInput}
                setFilteredCityArray={setFilteredCityArray}
            />
        </Div>
    )
})

export default StateCity
