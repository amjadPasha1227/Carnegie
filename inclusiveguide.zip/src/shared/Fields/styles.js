import {colorPalette, globals} from 'config/styles'
import {
    absolute,
    auto,
    black,
    block,
    borderBox,
    center,
    column,
    fixed,
    flex,
    flexStart,
    grid,
    hidden,
    inherit,
    inlineBlock,
    none,
    pointer,
    relative,
    sv,
    transparent,
    uppercase,
    white
}                              from 'utils/themer'

/** Default **/

export const invisibleStyle = {
    fieldset: {
        visibility: 'hidden',
        height: 0
    }
}

export const defaultFormStyle = {
    display: flex,
    alignItems: flexStart,
    flexDirection: column,
    borderRadius : 10,
    width: auto,
    padding: [50, .7, 25],
    border: `1px solid ${colorPalette.gray}`,
    position: relative,
    height: auto,
    boxSizing: borderBox,
    margin: '0 auto',
    backgroundColor:'#fff',
    inner: {
        width: '100%'
    },
    heading: {
        margin: 0,
        fontFamily: globals.fonts.sans,
        alignSelf: flexStart,
        size: [30, .7, 30],
        letterSpacing: [-1.75, .7, -0.5],
        weight: 800,
        marginBottom: 20,
        empty: {
            display: none
        }
    },
    button: {
        padding: '20px 60px',
        transition: 'background 250ms ease',
        size: [16, .7, 16],
        hover: {
            background: globals.colors.buttonHoverColor
        }
    },
    error: {
        position: fixed,
        background: '#901313',
        padding: `${sv(10)} ${sv(35)}`,
        color: '#fff',
        zIndex: 10,
    },
    mobile:{
        padding: 15
    }
}

export const defaultFieldsetStyle = {
    position: relative,
    width: '100%',
    border: `1px solid ${colorPalette.gray}`,
    borderRadius: '5px',
    boxSizing: borderBox,
    padding: 0,
    margin: 0,
    marginBottom: [50, .7, 50],
    background: white,
    zIndex: 0,
    transition: 'padding-left 300ms cubic-bezier(0.0, 0, 0.3, 1) 0ms, ' +
        'border 300ms cubic-bezier(0.0, 0, 0.3, 1) 0ms',
    class: {
        name: 'error',
        borderColor: globals.colors.errorColor
    },
    mobile:{
        marginBottom: 25,
    }
}

export const defaultInputStyle = {
    display: inlineBlock,
    position: relative,
    height: [50, .7, 50],
    width: '100%',
    padding: `0 ${sv(25, globals.style.layoutScalingValue)}`,
    border: none,
    margin: 0,
    font: globals.fonts.sans,
    size: [16, .7, 16],
    lineHeight: [16, .7, 16],
    fontWeight: 400,
    textOverflow: 'ellipsis',
    backgroundColor: transparent,
    color: globals.colors.black,
    boxSizing: borderBox,
    webkitAppearance: none,
    letterSpacing: none,
    zIndex: 0,
    borderRadius: 10,
    mobile: {
        padding: '0 25px'
    },
    placeholder: {
        color: transparent,
        textTransform: none,
        weight: 500
    },
    focus: {
        outline: 'none'
    },
    internalAutoFillSelected: {
        backgroundColor: transparent + '!important'
    },
    icon: {
        color: globals.colors.black,
        position: absolute,
        top: 0,
        right: 20,
        height: '100%',
        marginRight: 0,

    },
    fieldOuter: {
        position: relative
    }
}

export const defaultInputLabelStyle = {
    color: globals.colors.inputLabelColor,
    position: absolute,
    top: 0,
    left: 25,
    transform: 'translate(0px, 100%) scale(1)',
    zIndex: 1,
    border: 0,
    weight: 500,
    transition: 'color 300ms cubic-bezier(0.0, 0, 0.3, 1) 0ms, ' +
        'transform 300ms cubic-bezier(0.0, 0, 0.3, 1) 0ms',
    transformOrigin: 'top left',
    pointerEvents: none,
    size: [14, .7, 14],
    lineHeight: [16, .7, 16]
}

export const defaultFocusedInputLabelStyle = {
    transform: `translate(-6%,-44%) scale(${globals.style.inputLabelShrinkRatio})`
}

export const defaultLegendStyle = {
    marginLeft: 17,
    padding: 0,
    height: 0,
    width: 0,
    margin: 0,
    transition: 'width 300ms cubic-bezier(0.0, 0, 0.3, 1) 0ms',
}

export const defaultFieldErrorStyle = {
    position: absolute,
    right: [5, .7, 5],
    top: [2, .7, 2],
    textTransform: uppercase,
    size: [11, .7, 11],
    color: globals.colors.errorColor
}

export const defaultFieldHeadingStyle = {
    size: [19, .7, 19],
    marginBottom: [10, .7, 10],
    weight: 400,
    margin: `0 0 ${sv(5)} 0`,
    empty: {
        display: none
    }
}

export const defaultHelperTextStyle = {
    size: [15, .7, 15],
    marginBottom: [30, .7, 30],
    weight: 400,
    color: '#232323'
}


/** Rich Text **/

export const richTextStyle = {
    position: relative,
    minHeight: 300,
    marginBottom: [50, .7, 50],
    width: '100%',
    color: globals.colors.textColor,
    size: [16, .7, 16],
    weight: 400,
    class: {
        name: 'error',
        child: [
            {
                selector: '.ck.ck-editor .ck-editor__main .ck-editor__editable',
                borderColor: `${colorPalette.brightRed}`
            }
        ]
    },
    child: [
        {
            selector: '.ck.ck-editor',
            font: globals.fonts.serif,
            height: '100%',
            minHeight: inherit,
            child: {
                selector: '.ck-editor__main',
                minHeight: inherit,
                child: {
                    selector: '.ck-editor__editable',
                    minHeight: inherit,
                }
            }
        }
    ]
}

export const richTextErrorMessageStyle = {
    ...defaultFieldErrorStyle,
    top: [15, .7, 15]
}


/** Upload **/

export const uploadErrorMessageStyle = {
    ...defaultFieldErrorStyle,
    top: [-36, .7, -36]
}

export const imageDropZoneWrapperStyle = {
    display: grid,
    gridTemplateColumns: '1fr 1fr',
    gridGap: sv(50, globals.style.layoutScalingValue),
    marginBottom: [50, .7, 50],
    mobile: {
        gridTemplateColumns: '1fr'
    },
    class: {
        name: 'error',
        child: [
            {
                selector: 'div:first-of-type',
                border: `1px solid ${colorPalette.brightRed}`,
                position: relative
            }
        ]
    },
    child: {
        selector: '> div',
        width: '100%',
        mobile:{
            marginTop: 0
        },
        child: [
            {
                selector: ':nth-of-type(1)',
                display: flex,
                alignItems: center,
                justifyContent: center,
                child: {
                    selector: '> p',
                    size: [24, .7, 24]
                }
            },
            {
                selector: ':nth-of-type(2)',
                display: flex,
                justifyContent: center,
                alignItems: center
            }
        ]
    }
}

export const imageDropZonePreviewStyle = {
    width: '100%'
}

export const imageDropZonePreviewMoreStyle = {
    position: absolute,
    textAlign: center,
    display: 'flex',
    flexDirection: 'column',
    color: white,
}

export const imageUploadGravatarWrapperStyle = {
    child: {
        selector: '.react-gravatar',
        height: '100%',
        width: '100%'
    }
}

export const imageUploadGravatarTooltipStyle = {
    position: absolute,
    top: [5, .7, 5],
    left: [5, .7, 5],
    width: auto
}

export const imageUploadRemoveImageIcon = {
    position: absolute,
    top: [12, .7, 12],
    left: [12, .7, 12],
    size: [25, .7, 25],
    hover: {
        cursor: pointer
    }
}

export const imageDropZonePreviewWrapperStyle = {
    position: relative,
    width: '50%',
    border: `1px solid ${colorPalette.gray}`,
    boxSizing: borderBox,
    padding: [35, globals.style.layoutScalingValue, 35],
    marginTop: [50, .7, 50],
    // mobile: {
    //     height: 300
    // }
}

export const audioUploadPreviewWrapperStyle = {
    display: flex,
    flexDirection: column
}

export const imageDropZoneStyle = {
    position: relative,
    display: block,
    marginTop: [50, .7, 50],
    width: '50%',
    background: '#fff',
    border: `1px solid ${globals.colors.borderColor}`,
    borderRadius: 10,
    paddingTop: [50, .7, 50],
    paddingBottom: [50, .7, 50],
    hover: {
        cursor: pointer
    },
    closeIcon: {
        size: [18, .7, 18],
        color: white
    },
    icon: {
        size: [28, .7, 28]
    },
    close: {
        display: flex,
        flexGrow: 1,
        alignItems: center,
        justifyContent: center,
        height: 50,
        width: 50,
        borderRadius: 25,
        backgroundColor: colorPalette.darkHoneyYellow,
        border: `1px solid ${colorPalette.darkHoneyYellow}`,
        hover: {
            cursor: pointer,
            backgroundColor: colorPalette.honeyYellow,
            borderColor: colorPalette.honeyYellow
        }
    },
    portal: {
        position: fixed,
        top: 0,
        width: '100vw',
        height: '100vh',
        zIndex: 12,
        child: [
            {
                selector: '.ReactCrop',
                display: flex,
                alignSelf: center,
                width: 500
            }
        ]
    },
    portalInner: {
        display: flex,
        justifyContent: 'space-between',
        borderTop: `1px solid #dadce0`,
        flexWrap: 'wrap',
        position: absolute,
        // maxWidth: 750,
        width: '100vw',
        height: '100vh',
        boxSizing: borderBox,
        left: 0,
        top: 0,
        padding: 50,
        backgroundColor: white
    },
    portalContent: {
        flexGrow: 1000,
        height: 'calc(100vh - 160px)',
        overflowY: 'scroll'
    },
    cropRow: {
        display: flex,
        justifyContent: 'space-evenly',
        marginBottom: 48
    },
    cropPreview: {
        child: {
            selector: '> img',
            height: '100%'
        }
    },
    removeButton: {
        backgroundColor: white,
        border: `1px solid ${colorPalette.gray}`,
        marginTop: 10,
        display: flex,
        alignItems: center,
        justifyContent: center,
        padding: 5,
        borderRadius: 5,
        textTransform: 'uppercase',
        letterSpacing: 1.5,
        hover: {
            color: white,
            backgroundColor: black,
            cursor: pointer
        }
    },
    child: [
        {
            selector: 'input',
            height: '100%',
        },
        {
            selector: '.dzu-inputLabel',
            display: flex,
            alignItems: center,
            justifyContent: center,
            width: '100%',
            height: '100%'
        },
        {
            selector: '.dzu-previewButton',
            cursor: pointer,
            display: block,
            height: 50,
            width: 50,

        },
        {
            selector: '.dzu-input',
            display: none
        },
        {
            selector: '.dzu-previewImage',
            width: '100%',
        }
    ]
}


/** Toggle **/

export const toggleFieldStyle = {
    display: 'flex',
    alignItems: center,
    width: [100, globals.style.layoutScalingValue, 100],
    height: [30, .7, 30],
    borderRadius: [20, .7, 20],
    background: globals.colors.borderColor,
    paddingTop: [20, .7, 20],
    paddingBottom: [20, .7, 20],
    paddingLeft: [10, .7, 10],
    paddingRight: [10, .7, 10],
    hover: {
        cursor: pointer
    }
}

export const toggleWrapperStyle = {
    marginBottom: [50, .7, 50]
}

export const toggleBallStyle = {
    height: [25, globals.style.layoutScalingValue, 25],
    width: [25, globals.style.layoutScalingValue, 25],
    borderRadius: [20, globals.style.layoutScalingValue, 20],
    background: white,
    opacity: `1 !important`
}

export const toggleErrorStyle = {
    left: 0,
    size: [14, .7, 14]
}

/** Country **/

export const countryFieldStyle = {
    height: [52, .7, 52],
    marginBottom: [50, .7, 50],
    child: [
        {
            selector: '.country-field',
            width: '100%',
            height: [50, .7, 50],
            borderRadius: [5, .7, 5],
            padding: `0 ${sv(25)}`,
            border: 0
        }
    ]
}


/** Region **/

export const regionFieldStyle = {
    height: [52, .7, 52],
    marginBottom: [50, .7, 50],
    child: [
        {
            selector: '.region-field',
            width: '100%',
            height: [50, .7, 50],
            borderRadius: [5, .7, 5],
            padding: `0 ${sv(25)}`,
            border: 0
        }
    ]
}


/** AutoComplete **/

export const AutoCompleteInputStyle = {
    ...defaultInputStyle,
    backgroundColor: white,
    marginBottom: [20, .7, 20],
    width: '100%',
    borderRadius: [5, .7, 5],
    placeholder: {
        color: black
    }
}

export const AutoCompleteFieldSetStyle = {
    height: [52, .7, 52]
}

export const AutoCompleteSuggestionStyle = active => {
    const baseStyle = {
        paddingTop: 15,
        paddingBottom: 15,
        paddingLeft: 20,
        paddingRight: 20,
        backgroundColor: white,
        cursor: 'pointer',
        size: [18, .7, 18],
        letterSpacing: [0.2, .7, 0.2],
        textTransform: none,
        hover: {
            backgroundColor: globals.colors.borderColor
        }
    }


    return {
        ...baseStyle
    }

}

export const AutoCompleteSuggestionWrapperStyle = {
    position: 'absolute',
    zIndex: 2,
    width: '100%',
    top: [52, .7, 52],
    border: `1px solid ${globals.colors.borderColor}`,
    borderRadius: [5, .7, 5],
    empty: {
        display: none
    }
}


/** Count **/

export const countFieldStyle = {
    display: flex,
    alignItems: center
}

export const countControlStyle = {
    size: [18, .7, 18],
    marginLeft: [10, .7, 10],
    hover: {
        cursor: pointer,
        color: colorPalette.honeyYellow
    }
}

export const countControlNumberStyle = {
    size: [40, .7, 30],
    marginLeft: 30
}

export const selectFieldStyle = {
    position: relative,
    width: '100%',
    marginBottom: [50, .7, 50],
    class: {
        name: 'error',
        child: {
            selector: 'select',
            borderColor: colorPalette.brightRed
        }
    },
    child: [
        {
            selector: 'select',
            width: '100%',
            height: [50, .7, 50],
            borderRadius: [5, .7, 5]
        },
        {
            selector: 'option',
            height: [50, .7, 50],
            paddingLeft: [25, .7, 25],
            size: [20, .7, 20]
        }
    ]
}

export const selectFieldErrorMessageStyle = {
    ...defaultFieldErrorStyle,
    top: [15, .7, 15]
}

export const textAreaWrapperStyle = {
    position: relative,
    child: {
        border: `1px solid ${globals.colors.borderColor}`,
        selector: 'textarea',
        width: '100%',
        minHeight: [250, .7, 250],
        resize: none,
    }
}

export const textAreaErrorMessageStyle = {
    position: absolute,
    right: [10, .7, 10],
    top: [10, .7, 10],
    size: [14, .7, 14],
    color: colorPalette.brightRed
}

export const textAreaStyle = {}


export const submittedByWrapperStyle = {
    border: `1px solid ${globals.colors.borderColor}`,
    padding: [20, .7, 20],
    borderRadius: [10, .7, 10],
    background: '#fff'
}

export const submittedByAvatarWrapperStyle = {
    display: 'flex',
    marginTop: [20, .7, 20]
}
export const submittedByAvatarStyle = {
    height: [100, .7, 100],
    width: [100, .7, 100],
    borderRadius: [50, .7, 50],
    overflow: hidden
}

export const submittedByInfoWrapperStyle = {
    display: 'flex',
    flexDirection: 'column',
    marginLeft: [20, .7, 20]
}

export const searchBarDividerStyle = {
    position: absolute,
    right: 0,
    top: [10, .7, 10],
    height: [30, .7, 30],
    width: [1, .7, 1],
    background: colorPalette.lightGray,
}

export const searchBarZipcodeInputStyle = {
    child: [
        {
            selector: '.mapboxgl-ctrl-geocoder',
            position: relative,
            paddingTop: [6, .7, 6],
            paddingBottom: [6, .7, 6],
            height: [52, .7, 52],
            borderTopLeftRadius: 0,
            borderBottomLeftRadius: 0,
            borderLeftWidth: '0 !important',
            //border: '1px solid #dadce0',
            boxShadow: none,
            width: '100%',
            textAlign: 'left',
            minWidth: 0,
            maxWidth: none,
            marginRight: 0,
            mobile: {
                borderRadius: 5,
                marginTop: 10
            }
        },
        {
            selector: '.mapboxgl-ctrl-geocoder svg',
            marginLeft: [16, globals.style.layoutScalingValue, 16],
            height: [20, .7, 20],
            marginTop: [-10, .7, -10],
            top: `50%`,
            width: auto,
            left: 0,
            fill: '#00000075',
            mobile: {
                top: '50%'
            }
        },
        {
            selector: '.mapboxgl-ctrl-geocoder input',
            outline: 'none !important',
            height: '100%',
            paddingLeft: [48, globals.style.layoutScalingValue, 48],
            paddingRight: [48, globals.style.layoutScalingValue, 48],
            size: [15, .7, 15],
            color: '#00000075',
            font: "'Open Sans', sans-serif",
            fontWeight: 600,
            placeholder: {
                color: '#666666',
                font: "'Open Sans', sans-serif",
                fontWeight: 600,
            }
        },
        {
            selector: '.mapboxgl-ctrl-geocoder--button',
            top: '15px !important'
        }
    ]
}

export const searchBarSearchIconStyle = {
    position: absolute,
    left: [15, .7, 15],
    color: '#757575',
    size: [16, .7, 16],
    // top: '50%',
    marginTop: [15, .7, 15]
}

export const searchBarFieldsetStyle = {
    fieldset: {
       // height: [52, .7, 52],

    }
}

export const searchBarInputStyle = {
    paddingLeft: [43, .7, 60],
    size: [15, .7, 15],
    mobile: {
        paddingLeft: 43
    },
    placeholder: {
        color: '#00000075'
    }
}

export const searchBarWrapperStyle = {
    display: 'flex',
    width: '100%',
    marginRight: [20, globals.style.layoutScalingValue, 20],
    mobile: {
        flexDirection: column
    }
}

export const serviceAreaWrapperStyle = {
    marginBottom: [50, .7, 50],
    child: {
        selector: '.mapboxgl-ctrl-geocoder.mapboxgl-ctrl',
        borderLeftWidth: `1px !important`,
        borderRadius: [5, .7, 7],
        zIndex: 2
    }
}
