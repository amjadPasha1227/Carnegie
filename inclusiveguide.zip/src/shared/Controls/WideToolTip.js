import {infoCircle}                                                                        from 'config/icons'
import {AnimatePresence}                                                                   from 'framer-motion'
import {useRef, useState}                                                                  from 'react'
import Div                                                                                 from 'shared/Basic/Div'
import Icon                                                                                from 'shared/Basic/Icon'
import MotionDiv                                                                           from 'shared/Basic/MotionDiv'
import {auto}                                                                              from 'utils/themer'
import {toolTipIconStyles, toolTipMessageInnerStyles, wideToolTipMessageStyles, toolTipStyles} from './styles'

const WideToolTip = ({message, children, theme}) => {
    const [isOpen, setIsOpen] = useState(false)
    const toolTipRef = useRef()
    const variants = {
        initial: {
            height: 0,
            padding: 0,
        },
        animate: {
            height: auto,
        },
        exit: {
            height: 0,
            padding: 0
        }
    }

    return (
        <Div theme={{...toolTipStyles, ...theme}}>
            <Icon
                icon={infoCircle}
                onMouseOver={() => setIsOpen(flag => !flag)}
                onMouseOut={() => setIsOpen(flag => !flag)}
                theme={{...toolTipIconStyles, ...theme.icon}}
            />
            <AnimatePresence>
                <MotionDiv
                    theme={{...wideToolTipMessageStyles, ...theme.message}}
                    variants={variants}
                    initial={'initial'}
                    exit={'exit'}
                    animate={isOpen ? 'animate' : 'exit'}
                    ref={toolTipRef}
                    onMouseOver={() => setIsOpen(true)}
                    onMouseOut={() => setIsOpen(false)}
                >
                    <Div theme={{...toolTipMessageInnerStyles, ...theme.messageInner}}>
                        {message || children}
                    </Div>
                </MotionDiv>
            </AnimatePresence>
        </Div>
    )
}

WideToolTip.defaultProps = {
    theme: {}
}

export default WideToolTip
