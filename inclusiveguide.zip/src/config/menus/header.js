export const headerMenu = [
    {
        url: '/places',
        title: 'Search Places',
        active: ['places'],
    }
]
