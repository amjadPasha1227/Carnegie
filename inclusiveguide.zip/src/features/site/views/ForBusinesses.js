import Div            from 'shared/Basic/Div'
import ContentWrapper from 'shared/Layout/ContentWrapper'

const ForBusinesses = () => {

    return (
        <ContentWrapper>
            <Div>For Businesses page</Div>
        </ContentWrapper>
    )
}

export default ForBusinesses
