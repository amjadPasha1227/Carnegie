import Div            from '../../../shared/Basic/Div'
import ContentWrapper from '../../../shared/Layout/ContentWrapper'

const Terms = () => {

    return (
        <ContentWrapper>
            <Div>Terms page</Div>
        </ContentWrapper>
    )
}

export default Terms
