import Div              from 'shared/Basic/Div'
import H2               from 'shared/Basic/H2'
import LinkSwitch       from 'shared/Basic/LinkSwitch'
import ContentWrapper   from 'shared/Layout/ContentWrapper'
import H1               from 'shared/Basic/H1'
import Img              from '../../../shared/Basic/Img'
import {aboutPageStyle} from './styles'
import Filter from '../../../assets/filter.svg'
import FilterArrow from '../../../assets/filter_arrow.svg'
import Hotels from '../../../assets/hotels.svg'
import Food from '../../../assets/food.svg'
import ShoppingBag from '../../../assets/shopping-bag.svg'
import TeaCup from '../../../assets/tea-cup.svg'
import Cart from '../../../assets/cart.svg'
import Gas from '../../../assets/natural-gas.svg'
import SelectAll from '../../../assets/select-all.svg'

import { fullContainerStyle } from './styles'

const Placesnew = () => {
    
    return (
        <Div theme={fullContainerStyle} className='places_area'>
            <div className='filter_sec'>
                <div className='filter_header'>
                    <img src={Filter} />
                    <span>Filters</span>
                    <img src={FilterArrow} />
                </div>
            </div>
            <div className='sorting_sec'>
                <div className='sorting_header'>
                    <span className='place_heading'><em>ShopRite</em> in New Jersey</span>
                    <select>
                        <option>Sort by</option>
                        <option>Sort by</option>
                        <option>Sort by</option>
                        <option>Sort by</option>
                    </select>
                </div>
                <div className='places_list'>
                    <ul> 
                        <li>
                            <span className='place_icon'><img src={SelectAll} /></span>
                            <span className='place_name'>All</span>
                        </li>
                        <li>
                            <span className='place_icon'><img src={Hotels} /></span>
                            <span className='place_name'>hotels</span>
                        </li>
                        <li>
                            <span className='place_icon'><img src={Food} /></span>
                            <span className='place_name'>food</span>
                        </li>
                        <li>
                            <span className='place_icon'><img src={ShoppingBag} /></span>
                            <span className='place_name'>shopping</span>
                        </li>
                        <li>
                            <span className='place_icon'><img src={TeaCup} /></span>
                            <span className='place_name'>coffee</span>
                        </li>
                        <li>
                            <span className='place_icon'><img src={Cart} /></span>
                            <span className='place_name'>grocery</span>
                        </li>
                        <li>
                            <span className='place_icon'><img src={Gas} /></span>
                            <span className='place_name'>gas</span>
                        </li>
                    </ul>
                </div>
                <div className='search_areas'>
                    <ul>
                        <li>
                            
                        </li>
                    </ul>
                </div>
            </div>
            <div className='map_sec'>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3050.154401480918!2d-74.29872501468176!3d40.13884429796347!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c17ebc740465ff%3A0xff366b61d66dd141!2sShopRite%20of%20Jackson!5e0!3m2!1sen!2sin!4v1688393786105!5m2!1sen!2sin" width="auto" height="auto" style={{ border: "0"}} allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </Div>
    )
}

export default Placesnew
