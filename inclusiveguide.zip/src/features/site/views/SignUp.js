import {confirmationCodeFields, signUpFields, validateSignup} from 'features/site/admin/fields/signUp'
import {signUpFormStyle}                                      from 'features/user/views/styles'
import {useSelector}                                          from 'react-redux'
import Form                                                   from 'shared/Fields/Form'
import ContentWrapper                                         from 'shared/Layout/ContentWrapper'

const SignUp = () => {
    const signUpInitialValues = {
        nameFirst: '',
        tel: '',
        email: '',
        password: '',
        passwordConfirm: '',
        acceptTerms: false
    }
    const {confirmationRequest} = useSelector(state => state.user)
    const confirmationCodeInitialValues = {verificationCode: '', ...confirmationRequest}

    return (
        <ContentWrapper>
            {(confirmationRequest && confirmationRequest.verificationToken === 'pending' && (
                <Form
                    initialValues={confirmationCodeInitialValues}
                    fields={confirmationCodeFields}
                    dispatchAction={'user/confirmUser'}
                    formHeading={'Verify Phone'}
                    buttonText={'Confirm'}
                    theme={signUpFormStyle}
                />
            )) || (
                <Form
                    initialValues={signUpInitialValues}
                    fields={signUpFields}
                    validationSchema={validateSignup}
                    dispatchAction={'user/signUp'}
                    formHeading={'Sign Up'}
                    buttonText={'Sign Up'}
                    theme={signUpFormStyle}
                    customErrors={
                        confirmationRequest &&
                        confirmationRequest.verificationToken === 'failed'
                            ? [{ name: 'tel', message: 'invalid phone' }]
                            : []
                    }
                />
            )}
        </ContentWrapper>
    )
}


export default SignUp
