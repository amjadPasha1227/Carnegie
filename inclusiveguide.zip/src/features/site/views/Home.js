import { useEffect } from 'react'
import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import Div from 'shared/Basic/Div'
import LinkSwitch from 'shared/Basic/LinkSwitch'
import PlaceCard from 'shared/Cards/Place'
import Tooltip from 'shared/Controls/ToolTip'
import ContentWrapper from 'shared/Layout/ContentWrapper'
import Search from 'shared/Layout/Search'
import SwiperImg1 from '../../../assets/swiper/slide1.png'
import SwiperImg2 from '../../../assets/swiper/slide2.png'
import SwiperImg3 from '../../../assets/swiper/slide3.png'
import MapImg from '../../../assets/map.svg'
import StarImg from '../../../assets/star.svg'
import ProfileIcon from '../../../assets/profile.png'
import Hotels from '../../../assets/hotels_white.svg'
import Food from '../../../assets/food_white.svg'
import ShoppingBag from '../../../assets/shopping-bag_white.svg'
import TeaCup from '../../../assets/tea-cup_white.svg'
import Cart from '../../../assets/cart_white.svg'
import Gas from '../../../assets/natural-gas_white.svg'
import {
    homeContentWrapperStyle,
    homeHeadlineStyle,
    homeImageStyle,
    homeImageWrapperStyle,
    homeSearchStyle,
    homeSearchWrapperStyle,
    homeSignupButtonStyle,
    homeSignupQuoteStyle,
    newContainerStyle,
    homeSignupQuoteWrapperStyle,
    homeSignupWrapperStyle,
    recentlyViewedPlaceCardStyle,
    recentlyViewedPlaceCardWrapperStyle,
    recentlyViewedPlacesHeadingStyle,
    recentlyViewedWrapperStyle
} from './styles'
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper";

import "swiper/swiper-bundle.min.css";


const Home = () => {
    const { isAuthenticated, isAdmin, recentlyViewedPlaces, user } = useSelector(state => state.user)
    const dispatch = useDispatch()
    const { toprateplaces } = useSelector(state => state.place)

    useEffect(() => {
        dispatch({ type: 'place/getTopRatedPlaces' })

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    useEffect(() => {
        dispatch({ type: 'place/listPlaceCategory' })

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    useEffect(() => {
        if (!!user.recentlyViewed)
            for (const recent of user?.recentlyViewed) {
                dispatch({
                    type: 'user/getRecentlyViewedPlace',
                    payload: { _id: recent }
                })
            }
    }, [user, dispatch])

    const [isActive, setActive] = useState(1);

    const toggleClass = (value) => {

        setActive(value);
    };

    return (
        <ContentWrapper theme={homeContentWrapperStyle}>
            <Div theme={homeImageWrapperStyle} className='homeImageWrapperStyle'>
                <Div theme={homeImageStyle} className='homeImageStyle' />
                <Div theme={homeSearchWrapperStyle} className='homeSearchWrapperStyle'>
                    <Div theme={homeHeadlineStyle} className='homeHeadlineStyle'>
                        Celebrating the places that<br /> celebrate you
                    </Div>
                    <Search theme={homeSearchStyle} />
                    <div className='places_list'>
                        <ul>
                            <li>
                            <LinkSwitch
                            url={'/places/search/hotels'}
                           
                            
                        >
                                <span className='place_icon'><img src={Hotels} /></span>
                                <span className='place_name'>hotels</span>

                                </LinkSwitch>
                            </li>
                            <li>
                            <LinkSwitch
                            url={'/places/search/food'}
                           
                            
                        >
                                <span className='place_icon'><img src={Food} /></span>
                                <span className='place_name'>food</span>
                                </LinkSwitch>
                            </li>
                            <li>
                            <LinkSwitch
                            url={'/places/search/shopping'}
                           
                            
                        >
                                <span className='place_icon'><img src={ShoppingBag} /></span>
                                <span className='place_name'>shopping</span>
                                </LinkSwitch>
                            </li>
                            <li>
                            <LinkSwitch
                            url={'/places/search/coffee'}
                           
                            
                        >
                                <span className='place_icon'><img src={TeaCup} /></span>
                                <span className='place_name'>coffee</span>
                                </LinkSwitch>
                            </li>
                            <li>
                            <LinkSwitch
                            url={'/places/search/grocery'}
                           
                            
                        >
                                <span className='place_icon'><img src={Cart} /></span>
                                <span className='place_name'>grocery</span>
                                </LinkSwitch>
                            </li>
                            <li>
                            <LinkSwitch
                            url={'/places/search/gas'}
                           
                            
                        >
                                <span className='place_icon'><img src={Gas} /></span>
                                <span className='place_name'>gas</span>
                                </LinkSwitch>
                            </li>
                        </ul>
                    </div>
                </Div>
                <Div theme={homeSignupQuoteStyle} className='homeSignupQuoteStyle'>
                    <span>
                        Join us on the Inclusive Guide to review and share the places that
                        foster welcoming spaces and celebrate all identities!
                    </span>
                    {!isAuthenticated && !isAdmin && (
                        <LinkSwitch
                            url={'/signup'}
                            theme={homeSignupButtonStyle}
                            className='homeSignupButtonStyle'
                        >
                            Create Account
                        </LinkSwitch>
                    )}
                </Div>
            </Div>
            {<Div theme={homeSignupWrapperStyle} className="recent_search_wrap">


                {recentlyViewedPlaces?.length > 0 && (

                    <Div theme={newContainerStyle} className='recent_search'>
                        <span className='header'>Recent Search</span>
                        <Swiper
                            autoHeight={true}
                            slidesPerView={1}
                            spaceBetween={10}
                            breakpoints={{
                                821: {
                                     slidesPerView: 2,
                                     spaceBetween: 20,
                                 },
                                 1024: {
                                     slidesPerView: 3,
                                     spaceBetween: 20,
                                 },
                            }}
                            navigation={{
                                clickable: true,
                            }}
                            modules={[Navigation]}
                            className="recentSearchSwiper"
                        >
                            {recentlyViewedPlaces?.map((p, i) => (
                                <SwiperSlide
                                    className={isActive == 1 ? 'active swiper_list' : "swiper_list"}
                                    onClick={() => toggleClass(1)}
                                >

                                    <PlaceCard
                                        place={p}
                                        key={p._id}
                                        name={p.name}
                                        address={p.address}
                                        city={p?.geojson?.[0]?.properties.city}
                                        state={p?.geojson?.[0]?.properties.state}
                                        safe={p.averageSafe}
                                        celebrated={p.averageCelebrated}
                                        welcome={p.averageWelcome}
                                        inclusiveScore={p.inclusiveScore}
                                        url={`/places/${p.slug}`}
                                        theme={recentlyViewedPlaceCardStyle}
                                        linkCard={true}
                                    />

                                </SwiperSlide>
                            ))}



                        </Swiper>
                    </Div>

                )}
            </Div>}


            {toprateplaces?.length > 0 && (

                <Div theme={newContainerStyle} className='recent_search top_business'>
                    <span className='header'>Top Rated Business</span>

                    <Swiper
                        autoHeight={true}
                        slidesPerView={1}
                        spaceBetween={10}
                        breakpoints={{
                            821: {
                                 slidesPerView: 2,
                                 spaceBetween: 20,
                             },
                             1024: {
                                 slidesPerView: 3,
                                 spaceBetween: 20,
                             },
                        }}
                        navigation={{
                            clickable: true,
                        }}
                        modules={[Navigation]}
                        className="recentSearchSwiper"
                    >
                        {toprateplaces?.map((p, i) => (
                            <SwiperSlide
                                className={isActive == 1 ? 'active swiper_list' : "swiper_list"}
                                onClick={() => toggleClass(1)}
                            >

                                <PlaceCard
                                    place={p}
                                    key={p._id}
                                    styleType={3}
                                    name={p.name}
                                    address={p.address}
                                    city={p?.geojson?.[0]?.properties.city}
                                    state={p?.geojson?.[0]?.properties.state}
                                    safe={p.averageSafe}
                                    celebrated={p.averageCelebrated}
                                    welcome={p.averageWelcome}
                                    inclusiveScore={p.inclusiveScore}
                                    url={`/places/${p.slug}`}
                                    theme={recentlyViewedPlaceCardStyle}
                                    linkCard={true}
                                />

                            </SwiperSlide>
                        ))}



                    </Swiper>
                </Div>

            )}

        </ContentWrapper>
    )
}

export default Home
