import { describe, expect, it } from '@jest/globals';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Privacy from '../Privacy';

describe('src/fetures/site/views Privacy', () => {
  it('renders Privacy component', () => {
    const screen = render(<Privacy />);
    expect(screen.getByText(/Privacy page/i)).toBeInTheDocument();
  });
});
