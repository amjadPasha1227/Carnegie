import { describe, expect, it } from '@jest/globals';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import NotFound from '../NotFound';

describe('src/fetures/site/views NotFound', () => {
  it('renders NotFound component', () => {
    const screen = render(<NotFound />);
    expect(screen.getByText(/nothing to see here.../i)).toBeInTheDocument();
  });
});
