import { describe, expect, it } from '@jest/globals';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import SignUp from '../SignUp';

describe('src/fetures/site/views SignUp', () => {
  const mockStore = configureStore();
  let store;
  it('renders SignUp component', () => {
    const initialState = {
      user: {
        confirmationRequest: undefined,
      },
    };
    store = mockStore(initialState);
    const { getByText, getAllByText } = render(
      <Provider store={store}>
        <SignUp />
      </Provider>
    );
    expect(getAllByText(/Sign Up/i).length).toBe(2);
    expect(getByText(/First Name/i)).toBeInTheDocument();
    expect(getByText(/Telephone/i)).toBeInTheDocument();
    expect(getByText(/Email/i)).toBeInTheDocument();
    expect(getAllByText(/Password/i).length).toBe(2);
    expect(getByText(/Confirm Password/i)).toBeInTheDocument();
    expect(getByText(/Accept Terms of Service/i)).toBeInTheDocument();
  });

  it('SignUp component with invalid phone number', async () => {
    const initialState = {
      user: {
        confirmationRequest: {
          verificationToken: 'failed',
        },
      },
    };
    store = mockStore(initialState);
    const { getByText, getAllByText } = render(
      <Provider store={store}>
        <SignUp />
      </Provider>
    );
    expect(getAllByText(/Sign Up/i).length).toBe(2);
    expect(getByText(/First Name/i)).toBeInTheDocument();
    expect(getByText(/Telephone/i)).toBeInTheDocument();
    expect(getByText(/Email/i)).toBeInTheDocument();
    expect(getAllByText(/Password/i).length).toBe(2);
    expect(getByText(/Confirm Password/i)).toBeInTheDocument();
    expect(getByText(/Accept Terms of Service/i)).toBeInTheDocument();
  });

  it('SignUp component for Confirmation Request', () => {
    const initialState = {
      user: {
        confirmationRequest: {
          verificationToken: 'pending',
        },
      },
    };
    store = mockStore(initialState);
    const { getByText } = render(
      <Provider store={store}>
        <SignUp />
      </Provider>
    );
    expect(getByText(/Verify Phone/i)).toBeInTheDocument();
    expect(getByText(/Verification Code/i)).toBeInTheDocument();
    expect(getByText(/Confirm/i)).toBeInTheDocument();
  });
});
