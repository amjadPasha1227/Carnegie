import { describe, expect, it } from '@jest/globals';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import About from '../About';

describe('src/fetures/site/views About', () => {
  it('renders About component', () => {
    const screen = render(<About />);
    expect(screen.getByText(/About us/i)).toBeInTheDocument();
    expect(screen.getByText(/Our Vision/i)).toBeInTheDocument();
    expect(screen.getByText(/Our Mission/i)).toBeInTheDocument();
    expect(screen.getByText(/Press Room/i)).toBeInTheDocument();
    expect(screen.getByText(/Support the Guide/i)).toBeInTheDocument();
    expect(screen.container.querySelector('img').src).toBe(
      'https://inclusive-guide.s3.us-east-2.amazonaws.com/assets/Parker+and+Crystal+on+Bridge.jpeg'
    );
  });
});
