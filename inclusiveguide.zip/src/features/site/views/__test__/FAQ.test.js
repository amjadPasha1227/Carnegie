import { describe, expect, it } from '@jest/globals';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import FAQ from '../FAQ';

describe('src/fetures/site/views FAQ', () => {
  it('renders FAQ component', () => {
    const screen = render(<FAQ />);
    expect(screen.getByText(/Frequently Asked Questions/i)).toBeInTheDocument();
    expect(
      screen.getByText(/How can I contact Inclusive Guide?/i)
    ).toBeInTheDocument();
    expect(
      screen.getByText(/How can I report an error on the site?/i)
    ).toBeInTheDocument();
    expect(
      screen.getByText(/How is my identity information used?/i)
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /My business received a negative review, what are my next steps?/i
      )
    ).toBeInTheDocument();
    expect(
      screen.getByText(/Can I report another user or review on the site?/i)
    ).toBeInTheDocument();
    expect(
      screen.getByText(/Can a business delete my review?/i)
    ).toBeInTheDocument();
    expect(
      screen.getByText(/Is my information being sold to advertisers?/i)
    ).toBeInTheDocument();
    expect(screen.container.querySelector('a').href).toBe(
      'mailto:hello@inclusiveguide.com'
    );
  });
});
