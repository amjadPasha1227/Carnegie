import { describe, expect, it } from '@jest/globals';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Terms from '../Terms';

describe('src/fetures/site/views Terms', () => {
  it('renders Terms component', () => {
    const screen = render(<Terms />);
    expect(screen.getByText(/Terms page/i)).toBeInTheDocument();
  });
});
