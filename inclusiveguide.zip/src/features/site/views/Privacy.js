import Div            from 'shared/Basic/Div'
import ContentWrapper from 'shared/Layout/ContentWrapper'

const Privacy = () => {

    return (
        <ContentWrapper>
            <Div>Privacy page</Div>
        </ContentWrapper>
    )
}

export default Privacy
