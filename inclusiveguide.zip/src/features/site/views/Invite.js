import {confirmationCodeFields, inviteFields, validateInvite} from 'features/site/admin/fields/signUp'
import {signUpFormStyle}                                      from 'features/user/views/styles'
import {useSelector}                                          from 'react-redux'
import Form                                                   from 'shared/Fields/Form'
import ContentWrapper                                         from 'shared/Layout/ContentWrapper'
import { useState,useEffect } from 'react'

const InviteUser = ({placeId}) => {
    const signUpInitialValues = {
        nameFirst: '',
        tel: '',
        email: '',
        password: '',
        passwordConfirm: '',
        inviteadmin:true,
        place:placeId
    }
    const {confirmationRequest} = useSelector(state => state.user)
    const confirmationCodeInitialValues = {place:placeId,verificationCode: '', ...confirmationRequest}
    return (
        <ContentWrapper>
            {(confirmationRequest && confirmationRequest.verificationToken === 'pending' && (
                <Form
                    initialValues={confirmationCodeInitialValues}
                    fields={confirmationCodeFields}
                    dispatchAction={'user/confirmUser'}
                    formHeading={'Verify Phone'}
                    buttonText={'Confirm'}
                    theme={signUpFormStyle}
                />
            )) || (
                <Form
                    initialValues={signUpInitialValues}
                    fields={inviteFields}
                    formsubheading={'Once invited, they can oversee the business directly from their account. If user already have an account with Inclusive Guide password details are not required'}
                    validationSchema={validateInvite}
                    dispatchAction={'user/signUp'}
                    formHeading={'Invite Business Admin'}
                    buttonText={'Submit'}
                    theme={signUpFormStyle}
                    customErrors={
                        confirmationRequest &&
                        confirmationRequest.verificationToken === 'failed'
                            ? [{ name: 'tel', message: 'invalid phone' }]
                            : []
                    }
                    enableReinitialize={true}
                />
            )}
        </ContentWrapper>
    )
}


export default InviteUser
