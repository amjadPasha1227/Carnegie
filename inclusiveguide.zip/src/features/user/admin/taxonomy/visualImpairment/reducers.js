export const visualImpairment = {
    listVisualImpairmentSuccess: (state, action) => {
        state.taxonomy.visualImpairment = action.payload
    },
    getVisualImpairmentSuccess: (state, action) => {
        state.taxonomy.visualImpairment = action.payload
    }
}
