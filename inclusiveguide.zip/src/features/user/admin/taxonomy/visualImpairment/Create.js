import {visualImpairmentField, validateVisualImpairment} from 'features/user/admin/taxonomy/visualImpairment/fields'
import {useSelector}             from 'react-redux'
import Form                      from 'shared/Fields/Form'

const Create = () => {
    const {_id, token} = useSelector(state => state.user)
    const initialValues = {
        _id,
        token,
        name: '',
        description: ''
    }

    return (
        <Form
            initialValues={initialValues}
            fields={visualImpairmentField}
            validationSchema={validateVisualImpairment}
            dispatchAction={'user/createVisualImpairment'}
            formHeading={'Create Visual Impairment'}
            buttonText={'Create'}
        />
    )
}

export default Create
