import BreadCrumb                 from 'features/user/admin/views/Breadcrumb'
import {useEffect}                from 'react'
import {useDispatch, useSelector} from 'react-redux'
import Div                        from 'shared/Basic/Div'
import LinkSwitch                 from 'shared/Basic/LinkSwitch'
import ContentWrapper             from 'shared/Layout/ContentWrapper'
import AdminDashboardWrapper      from 'shared/Layout/Dashboard/admin/AdminDashboardWrapper'
import DashboardInfo              from 'shared/Layout/Dashboard/DashboardInfo'
import {
    adminContentWrapperStyle,
    adminTaxonomyItemStyle,
    adminTaxonomyItemsWrapperStyle,
    adminTaxonomyTotalTextStyle,
    adminTotalTaxonomyInnerWrapperStyle,
    adminTotalTaxonomyWrapperStyle
}                                 from 'shared/Layout/styles'
import Create                     from './Create'

const ManageVisualImpairment = () => {
    const dispatch = useDispatch()
    const {visualImpairment} = useSelector(state => state.user.taxonomy)
    const {slug} = useSelector(state => state.site)

    useEffect(() => {
        dispatch({type: 'user/listVisualImpairment'})

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    return (
        <ContentWrapper theme={adminContentWrapperStyle}>
            <AdminDashboardWrapper>
                <DashboardInfo
                    heading={'Manage Visual Impairment Taxonomy'}
                    description={'Click to edit.'}
                />
                <BreadCrumb/>
                <Div theme={adminTotalTaxonomyWrapperStyle}>
                    {visualImpairment?.length > 0 && (
                        <Div theme={adminTotalTaxonomyInnerWrapperStyle}>
                            <Div theme={adminTaxonomyTotalTextStyle}>Total: {visualImpairment?.length}</Div>
                            <Div theme={adminTaxonomyItemsWrapperStyle}>
                                {visualImpairment?.map((item) => (
                                    <LinkSwitch
                                        url={`${slug}/update/${item.slug}`}
                                        key={item._id}
                                        theme={adminTaxonomyItemStyle}
                                    >
                                        {item.name}
                                    </LinkSwitch>
                                ))}
                            </Div>
                        </Div>
                    )}
                    <Create/>
                </Div>
            </AdminDashboardWrapper>
        </ContentWrapper>
    )
}

export default ManageVisualImpairment
