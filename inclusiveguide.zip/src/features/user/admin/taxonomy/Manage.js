import {useEffect}                                           from 'react'
import {useSelector}                                         from 'react-redux'
import Div                                                   from 'shared/Basic/Div'
import LinkSwitch                                            from 'shared/Basic/LinkSwitch'
import ContentWrapper                                        from 'shared/Layout/ContentWrapper'
import AdminDashboardWrapper                                 from 'shared/Layout/Dashboard/admin/AdminDashboardWrapper'
import DashboardInfo                                                                    from 'shared/Layout/Dashboard/DashboardInfo'
import {adminContentWrapperStyle, adminTaxonomyWrapperStyle, taxonomyButtonOptionStyle} from 'shared/Layout/styles'

const Manage = () => {
    const {confirmDelete} = useSelector(state => state.site)
    const TAX_PATH = '/admin/users/taxonomy'

    useEffect(() => {

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [confirmDelete])

    return (
        <ContentWrapper theme={adminContentWrapperStyle}>
            <AdminDashboardWrapper>
                <DashboardInfo
                    heading={'Manage User Taxonomy'}
                    description={'Click to edit.'}
                />

                <Div theme={adminTaxonomyWrapperStyle}>
                    <LinkSwitch url={`${TAX_PATH}/adaptive-equipment`}  theme={taxonomyButtonOptionStyle}>
                        Adaptive Equipment
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/body-modification`}  theme={taxonomyButtonOptionStyle}>
                        Body Modifications
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/gender`} theme={taxonomyButtonOptionStyle}>
                        Gender
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/hearing-impairment`} theme={taxonomyButtonOptionStyle}>
                        Hearing Impairment
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/language`} theme={taxonomyButtonOptionStyle}>
                        Language
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/method-of-communication`} theme={taxonomyButtonOptionStyle}>
                        Method of Communication
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/physical-appearance`} theme={taxonomyButtonOptionStyle}>
                        Physical Appearance
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/pronoun`} theme={taxonomyButtonOptionStyle}>
                        Pronoun
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/race`} theme={taxonomyButtonOptionStyle}>
                        Race
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/service-animal`} theme={taxonomyButtonOptionStyle}>
                        Service Animal
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/sexual-orientation`} theme={taxonomyButtonOptionStyle}>
                        Sexual Orientation
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/visual-impairment`} theme={taxonomyButtonOptionStyle}>
                        Visual Impairment
                    </LinkSwitch>
                </Div>
            </AdminDashboardWrapper>
        </ContentWrapper>
    )
}

export default Manage
