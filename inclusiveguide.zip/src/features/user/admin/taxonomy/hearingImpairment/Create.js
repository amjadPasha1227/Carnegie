import {hearingImpairmentField, validateHearingImpairment} from 'features/user/admin/taxonomy/hearingImpairment/fields'
import {useSelector}             from 'react-redux'
import Form                      from 'shared/Fields/Form'

const Create = () => {
    const {_id, token} = useSelector(state => state.user)
    const initialValues = {
        _id,
        token,
        name: '',
        description: ''
    }

    return (
        <Form
            initialValues={initialValues}
            fields={hearingImpairmentField}
            validationSchema={validateHearingImpairment}
            dispatchAction={'user/createHearingImpairment'}
            formHeading={'Create Hearing Impairment'}
            buttonText={'Create'}
        />
    )
}

export default Create
