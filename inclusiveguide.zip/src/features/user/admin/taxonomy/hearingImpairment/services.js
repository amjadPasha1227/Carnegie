import {API} from 'config/variables'

/**
 * to perform crud on admin
 * get all places
 * get a single admin
 * update single admin
 * delete single admin
 */

export const addHearingImpairment = ({_id, token, place}) =>
    fetch(`${API}/hearing-impairment/create/${_id}`, {
        method: 'POST',
        headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${token}`
        },
        body: place
    })
        .then(response => {
            return response.json()
        })
        .catch(error => {
            return error
        })

export const deleteHearingImpairment = ({_id, token, slug}) =>
    fetch(`${API}/hearing-impairment/${slug}/${_id}`, {
        method: 'DELETE',
        headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
        }
    })
        .then(response => {
            return response.json()
        })
        .catch(error => {
            return error
        })

export const getHearingImpairment = ({slug}) =>
    fetch(`${API}/hearing-impairment/${slug}`, {
        method: 'GET'
    })
        .then(response => {
            return response.json()
        })
        .catch(error => {
            return error
        })

export const updateHearingImpairment = ({slug, _id, token, hearingImpairment}) =>
    fetch(`${API}/hearing-impairment/${slug}/${_id}`, {
        method: 'PUT',
        headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${token}`
        },
        body: hearingImpairment
    })
        .then(response => {
            return response.json()
        })
        .catch(error => {
            return error
        })

export const getHearingImpairmentList = () =>
    fetch(`${API}/hearing-impairment?limit=undefined`, {
        method: 'GET'
    })
        .then(response => {
            return response.json()
        })
        .catch(error => {
            return error
        })
