export const hearingImpairment = {
    listHearingImpairmentSuccess: (state, action) => {
        state.taxonomy.hearingImpairment = action.payload
    },
    getHearingImpairmentSuccess: (state, action) => {
        state.taxonomy.hearingImpairment = action.payload
    }
}
