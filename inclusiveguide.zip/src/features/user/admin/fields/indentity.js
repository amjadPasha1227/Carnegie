import {MULTI_SELECT, SINGLE_SELECT} from 'config/variables'

export const identityFields = [
    {
        name: 'adaptiveEquipment',
        inputLabel: 'Accessibility Solutions',
        type: MULTI_SELECT,
        tooltipMessage: 'Accessibility solutions refers to tools, devices, and support systems that help with the tasks associated with daily living.' + 
        ' These may be used by people with short- or long-term disabilities.' +
        ' Rather than ask you to list individual disabilities, we thought it would be more beneficial to you and businesses to know which accommodations were available at different locations.' +
        ' For example, if you have a hearing impairment, it makes more sense in gauging a company’s inclusivity to know that that business supports individuals who use implants or aids to hear.' +
        ' It’s important for us to have information about any accessibility solutions you utilize so that we may gauge how well a business welcomes individuals who use their tools, devices, or support systems at a storefront.',
    },
    {
        name: 'bodyModification',
        inputLabel: 'Body Modification',
        type: MULTI_SELECT,
        tooltipMessage: 'Body modification refers to any change in a person’s physical appearance. People change their bodies for various reasons, ranging from beauty to religious beliefs and group membership. We encourage you to list any modifications you have so that we can better gauge how well a business celebrates individuals with different kinds of bodies and appearances.' ,
    },
    {
        name: 'gender',
        inputLabel: 'Gender',
        type: MULTI_SELECT,
        tooltipMessage: 'Gender is the range of characteristics pertaining to the presence or absence of femininity and/or masculinity and differentiating between or in contrast to them. Around ≈95% of people are cisgender, between 1.7-4% are intersex, and between 2-5% are transgender. Gender, an innate sense of self, and expression, how one wants to be perceived by others, can differ. Gender-based discrimination can come in the form of misogyny, misandry, transphobia, and more. Gender discrimination is also known as sex-based discrimination.',
    },
    {
        name: 'languagePrimary',
        inputLabel: 'Primary Language',
        type: SINGLE_SELECT,
        tooltipMessage: 'Primary language refers to the language somebody uses the most. A person’s primary language may be the language they learned to speak first, though this isn’t always the case. Because inclusion involves welcoming speakers of different primary languages, we ask that you include yours below so that our inclusivity ratings may be more accurate.',
    },
    {
        name: 'languageSecondary',
        inputLabel: 'Secondary Language',
        type: MULTI_SELECT,
        tooltipMessage: 'Secondary language refers to a language somebody may communicate with but not as frequently as their primary language. People who speak more than one language often communicate using different languages depending on the specific context. Secondary language diversity, much like the different primary languages people speak, is important to celebrate as part of an inclusive business setting.' ,
    },
    {
        name: 'methodOfCommunication',
        inputLabel: 'Method of Communication',
        type: MULTI_SELECT,
        tooltipMessage: 'Method of communication refers to speaking, writing, and other ways of communicating. Some people use methods like sign language or interpreter services to communicate. Method of communication may also relate to an individual’s physical or mental disability. Everybody communicates differently, so an inclusive business should be one that celebrates all methods of communication.' ,
    },
    {
        name: 'physicalAppearance',
        inputLabel: 'Is there anything about your physical body that may contribute to how people treat you? ',
        type: MULTI_SELECT,
        tooltipMessage: 'Use this space to list anything permanent about your physical body or appearance that isn’t covered by another category, such as Accessibility Solutions, Body Modification, etc. For example, somebody might have scarring, a certain body size, or other physical features that impact how they’re treated by businesses. We include this category so that we may have a clearer picture of the various ways a business might welcome somebody and make them feel safe.', 
    },
    {
        name: 'pronoun',
        inputLabel: 'Pronouns',
        type: MULTI_SELECT,
        tooltipMessage: 'Gender pronouns are the words individuals use to refer to you in the third person, for example, she/her/hers or they/them/theirs. Because what someone looks like doesn’t automatically signal a certain gender identity or expression, it’s important to let others know what pronouns you use. Using correct pronouns lets people of all gender identities and expressions feel welcome' ,
    },
    {
        name: 'race',
        inputLabel: 'Ethnicity',
        type: MULTI_SELECT,
        tooltipMessage: 'Ethnicity refers to a population of people who share cultural traditions and/or a nationality. As an example, individuals from the Philippines or within a Philippine immigrant community often refer to themselves as “Filipino” or “Filipinx” (the gender-neutral designation) to indicate a shared culture. While the word “race” is often used instead of “ethnicity,” the two terms are distinct in that the former emphasizes physical traits such as skin color. We use “ethnicity” as the more inclusive choice, as it allows you to select the culture(s) you identify with regardless of physical appearance.' ,
    },
    {
        name: 'serviceAnimal',
        inputLabel: 'Service Animal',
        type: MULTI_SELECT,
        tooltipMessage: 'A service animal, such as a dog or a miniature horse, is trained to perform special tasks for its handler. A service animal may be trained to assist an individual with mobility constraints, seizures, severe allergies, or diabetes, among other conditions. A service animal is different from an emotional support animal in that the former assists the handler with a task required for daily life. While service animals are federally protected in the United States, not all businesses welcome them with open arms. As such, it’s important for us to know if and how a business supports individuals who bring their service animals with them.',
    },
    {
        name: 'sexualOrientation',
        inputLabel: 'Sexual Orientation',
        type: MULTI_SELECT,
        tooltipMessage: 'Sexual orientation refers to the people you feel sexual attraction toward. A woman who’s only attracted to other women might identify as lesbian, for example, while somebody who finds themselves attracted to people across gender identities might call themselves queer or pansexual. Sexual orientation sometimes includes an individual’s romantic orientation, though the two don’t always go hand in hand. A person may be bisexual and homoromantic, for instance. People of all sexual and romantic orientations should be welcomed and celebrated by businesses.',
    }
]
