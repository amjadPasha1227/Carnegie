
import Div from 'shared/Basic/Div'
import { useState, useEffect } from 'react'

const Checkbox = ({ optionDetails, handleFilters, checkedStatus }) => {

    const [isChecked, setIsChecked] = useState(checkedStatus)
    const { _id, name, type } = optionDetails

    useEffect(() => {
        setIsChecked(checkedStatus)
    }, [checkedStatus])
    const handleChecked = (E) => {
        setIsChecked((prev) => !prev)
    }

    useEffect(() => {
        handleFilters(_id, isChecked, type)
    }, [isChecked])

    return (
        <Div className="form-group">
            <input type="checkbox" id={_id} value={_id} checked={isChecked} onChange={handleChecked} />
            <label for={_id} >{name}</label>
        </Div>
    )
}

export default Checkbox
