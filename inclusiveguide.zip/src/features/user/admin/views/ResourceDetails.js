 
import {useEffect}         from 'react'
import {useDispatch, useSelector} from 'react-redux'
import Div                        from 'shared/Basic/Div'  
import VimeoEmbed                                             from './VimeoEmbed'
import {placeReviewDescriptionStyle, userContentWrapperStyle} from './styles'
import {adminReviewStyle} from './styles'
import RichText                          from 'shared/Basic/RichText'
import LinkSwitch  from 'shared/Basic/LinkSwitch'
import {fileIcon} from 'config/icons'
import Icon                              from 'shared/Basic/Icon'
import {CDN} from 'config/variables'
import DownloadArrow from '../../../../assets/download.svg'
import Tag from '../../../../assets/tag.png'
 
const Resources = () => {
    const dispatch = useDispatch()
    const {_id, token, reviews, isVerified} = useSelector(state => state.user)
    const {resource, subjectsList, categoryList} = useSelector(state => state.place)
    const {slug} = useSelector(state => state.site)

    useEffect(() => {
        dispatch({
            type: 'report/getResource',
            payload: {
                slug: slug
            }
        })
        document.body.classList.add('dashboad_pages')
        return () => {
        document.body.classList.remove('dashboad_pages')
    }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])


    return (
            
         
            <Div id="resource_details_wrap">
                <LinkSwitch 
                    url='/dashboard/resources'
                    className='backto_list'>
                     Back
                     </LinkSwitch>
              <Div theme={{marginBottom: [20, .7, 20]}}>
                      <Div theme={{display: 'flex', flexDirection: 'column'}} id="resource_cnt">
                      {resource && 

                        <Div theme={adminReviewStyle} id="resource_item">
                            <Div id="resource_text">
                            <Div className='resource_item_sec'>
                                <h2 className='review_heading'>
                                    {resource.title}
                                </h2>
                                <Div className="filtered_list tags">
                                    {resource.subjects?.length > 0 && !!resource.subjects[0] && <>
                                        <img className='tag_img' src={Tag} />
                                        <ul>
                                            {resource.subjects?.map((sub) =>
                                                <li>
                                                    <p>{(subjectsList.filter((subject) => sub == subject._id))[0]?.["name"]}</p>
                                                </li>
                                            )}
                                        </ul>
                                    </>
                                    }
                                </Div>
                                <Div className="filtered_list categories">
                                { !!resource.category && <>
                                    <label>category :</label>
                                    <ul>
                                        <li>
                                        <p>{(categoryList.filter((category) => resource.category == category._id))[0]?.["name"]}</p>
                                    </li> 
                                    
                                    </ul>
                                </>     
                            }
                                </Div>
                                {
                                    resource.document!='null' && resource.document!=null &&
                                    <Div className="fileListsection">
                                    <a  target='_blank' className='fileListicon'  href={`${CDN}${resource.document}`}>
                                    <div class="tooltip_cnt">
                                        <p>Click here to download</p>
                                    </div>
                                    <img className='download_file' src={DownloadArrow} />
                                    <Icon icon={fileIcon}/>
                                    </a>
                                    </Div>
                                }
                            </Div>
                            <VimeoEmbed  vimeoLink={`${resource.videolink}`}   />
                            <RichText theme={placeReviewDescriptionStyle} className="review_desc">{resource.description}</RichText>
                            </Div>


                            
                        </Div>
                        
                      }</Div>
                        
              </Div>


            </Div>
         
    )
}

export default Resources
