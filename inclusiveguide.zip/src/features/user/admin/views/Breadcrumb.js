import LinkSwitch            from 'shared/Basic/LinkSwitch'
import {taxonomyButtonStyle} from 'shared/Layout/styles'

const BreadCrumb = () => {
    return (
        <LinkSwitch
            url={'/admin/users/taxonomy'}
            children={'Taxonomy List'}
            theme={taxonomyButtonStyle}
        />
    )
}

export default BreadCrumb
