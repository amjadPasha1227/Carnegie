import {identityFields}            from 'features/user/admin/fields/indentity'
import {useEffect}                 from 'react'
import {useDispatch, useSelector}  from 'react-redux'
import Form                        from 'shared/Fields/Form'
import {identityProfileFormStyles} from './styles'
import WideToolTip from 'shared/Controls/WideToolTip'
import Div                                                                                 from 'shared/Basic/Div'

const Identity = () => {
    const dispatch = useDispatch()
    const {_id, token, taxonomy, user} = useSelector(state => state.user)
    const {slug, identity} = user
    // const {slug} = useSelector(state => state.site)

    const {
        adaptiveEquipment,
        bodyModification,
        gender,
        hearingImpairment,
        language,
        methodOfCommunication,
        physicalAppearance,
        pronoun,
        race,
        serviceAnimal,
        sexualOrientation,
        visualImpairment
    } = taxonomy
    // const {description, avatar, email, ethnicHispanicOrigin, nameMiddle, nameFirst, nameLast, tel, role, type} = user

    const initialValues = {
        adaptiveEquipment: identity?.adaptiveEquipment || [],
        bodyModification: identity?.bodyModification || [],
        dateOfBirth: '',
        gender: identity?.gender || [],
        hearingImpairment: identity?.hearingImpairment || [],
        languagePrimary: identity?.languagePrimary || [],
        languageSecondary: identity?.languageSecondary || [],
        methodOfCommunication: identity?.methodOfCommunication || [],
        physicalAppearance: identity?.physicalAppearance || [],
        pronoun: identity?.pronoun || [],
        race: identity?.race || [],
        serviceAnimal: identity?.serviceAnimal || [],
        sexualOrientation: identity?.sexualOrientation || [],
        visualImpairment: identity?.visualImpairment || [],
        transgender: identity?.transgender,
        identity: true,
        slug,
        _id,
        token,
    }
    const options = [
        {
            name: 'adaptiveEquipment',
            options: adaptiveEquipment
        },
        {
            name: 'bodyModification',
            options: bodyModification
        },
        {
            name: 'gender',
            options: gender
        },
        {
            name: 'hearingImpairment',
            options: hearingImpairment
        },
        {
            name: 'languagePrimary',
            options: language
        },
        {
            name: 'languageSecondary',
            options: language
        },
        {
            name: 'methodOfCommunication',
            options: methodOfCommunication
        },
        {
            name: 'physicalAppearance',
            options: physicalAppearance
        },
        {
            name: 'pronoun',
            options: pronoun
        },
        {
            name: 'race',
            options: race
        },
        {
            name: 'serviceAnimal',
            options: serviceAnimal
        },
        {
            name: 'sexualOrientation',
            options: sexualOrientation
        },
        {
            name: 'visualImpairment',
            options: visualImpairment
        }
    ]
    useEffect(() => {
        dispatch({type: 'user/listAdaptiveEquipment'})
        dispatch({type: 'user/listBodyModification'})
        dispatch({type: 'user/listGender'})
        dispatch({type: 'user/listHearingImpairment'})
        dispatch({type: 'user/listLanguage'})
        dispatch({type: 'user/listMethodOfCommunication'})
        dispatch({type: 'user/listPhysicalAppearance'})
        dispatch({type: 'user/listPronoun'})
        dispatch({type: 'user/listRace'})
        dispatch({type: 'user/listServiceAnimal'})
        dispatch({type: 'user/listSexualOrientation'})
        dispatch({type: 'user/listVisualImpairment'})


        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    // useEffect(() => {
    //
    // }, [identity])

    return (
        <Div id="identity">
            <WideToolTip message={'We know that identity information can be private and you may not want to share, but we ask that you include this data below so that we may accurately and comprehensively gauge the inclusivity of various businesses in relation to individuals’ backgrounds. For example, seeing a user’s ability information or sexual and gender identity allows us to better assess how much a business not only accommodates but also celebrates individuals of that specific background. In order for us to best cultivate a culture of inclusivity, it’s important that we can point to specific identity information to show businesses how they’re doing—and to help them do better if customers of certain backgrounds feel excluded or experience discrimination. Your profile also allows other Inclusive Guide users to determine how welcoming businesses may be based on shared identity information.'

+'Rest assured that we won’t misuse your information or sell your data individually to third parties such as advertisers. All the user data on Inclusive Guide will be aggregated and anonymized. For instance, we might share with a company, “54 percent of the women of color who reported a negative experience at your business were 40 years of age or older.” This data doesn’t specifically mention any users, but it does allow us to highlight a population a business might have ignored or forgotten about. Additionally, you’ll always have the ability to update your profile and add or remove information, though we encourage you to represent yourself as fully as possible.'

+'If any of the terms below confuse you, no worries! We hope our explanations and resources will help you learn about the ways people identify themselves. Also, you don’t have to completely understand somebody’s identity to respect it. As long as you come to Inclusive Guide with a mindset of respect for people’s different backgrounds and identities, we’re happy to have you here.'

+'Finally, because we’re human and imperfect, we may have missed an identity or failed to use the best term for a certain background. Please let us know if you see something you think should be added or updated! The work of inclusion doesn’t occur in a vacuum, and we hope you’ll hold us accountable as we strive to make businesses more inclusive for all.'}/>

            {initialValues && (
                
                <Form
                    initialValues={initialValues}
                    fields={identityFields}
                    // validationSchema={validateUser}
                    dispatchAction={'user/updateUserIdentity'}
                    formHeading={'Update Identity'}
                    buttonText={'Update'}
                    theme={identityProfileFormStyles}
                    enableReinitialize={true}
                    options={options}
                />
            )}
            
        
            </Div>

    )
}

export default Identity
