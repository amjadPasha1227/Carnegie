import React from 'react';

function VimeoEmbed({ vimeoLink }) {
  // Extract video ID using regular expression
  console.log(vimeoLink)
  const videoIdMatch = vimeoLink.match(/vimeo\.com\/(\d+)/);
  const videoId = videoIdMatch ? videoIdMatch[1] : null;

  if (!videoId) return null; // Return null or some fallback component if videoId is not found

  return (
    <div className="video-responsive">
      <iframe 
        src={`https://player.vimeo.com/video/${videoId}`} 
        width="640" 
        height="360" 
        frameborder="0" 
        allow="autoplay; fullscreen" 
        allowfullscreen
      ></iframe>
    </div>
  );
}

export default VimeoEmbed;
