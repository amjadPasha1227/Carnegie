import { userDashboardMenu } from 'config/menus/dashboard/user'
import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import ContentWrapper from 'shared/Layout/ContentWrapper'
import DashboardInfo from 'shared/Layout/Dashboard/DashboardInfo'
import DashboardWrapper from 'shared/Layout/Dashboard/DashboardWrapper'
import { userContentWrapperStyle } from './styles'
import Div from 'shared/Basic/Div'
import moment from 'moment'

const ManagePayments = () => {
    const dispatch = useDispatch()
    const { user, paymentsList } = useSelector(state => state.user)
    const { _id, token, slug } = useSelector(state => state.user)

    useEffect(() => {
        dispatch({
            type: 'user/getUser',
            payload: {
                slug: slug,
                _id: _id,
                token: token
            }
        })

        // eslint-disable-next-line react-hooks/exhaustive-deps
        document.body.classList.add("dashboad_pages")
        return () => {
            document.body.classList.remove("dashboad_pages")
        }
    }, [])


    useEffect(() => {
        dispatch({
            type: 'user/getPaymentslist',
            payload: {
                slug: slug,
                _id: _id,
                token: token
            }
        })
    }, [_id])


    return (
        <ContentWrapper theme={userContentWrapperStyle}>
            <DashboardWrapper menu={userDashboardMenu}>
                <Div id="business_wrap">
                    <Div id="business_title">
                        <DashboardInfo
                            heading={`Manage Payments`}
                            description={'A list of your payments'}
                        />
                        <div>
                            {
                                paymentsList?.length > 0 && <table>
                                    <tr>
                                        <th>Amount ($)</th>
                                        <th>Payment Date</th>
                                        <th>Card Details</th>
                                        {user?.role == 0 && <>
                                            <th>Address</th>
                                        </>}
                                        <th>Reciept</th>

                                    </tr>

                                    {
                                        paymentsList.map((eachPayment) => <tr>
                                            <td>{eachPayment.amount}</td>
                                            <td>{eachPayment.paymentDate ? moment(eachPayment.paymentDate).format('LL') : ''}</td>
                                            <td>{eachPayment.cardDetails}</td>
                                            {user?.role == 0 && <>
                                                <td>
                                                    <span>{eachPayment.address?.street}</span><br />
                                                    <span>{eachPayment.address?.city} {eachPayment.address?.state} {eachPayment.address?.zip}</span><br />
                                                    <span>{eachPayment.address?.country}</span><br />
                                                </td>
                                            </>}
                                            <td><a href={`${eachPayment.receiptUrl}`} target='_blank'>click here to open receipt</a></td>
                                        </tr>)
                                    }
                                </table>
                            }
                        </div>
                    </Div>
                </Div>
            </DashboardWrapper>
        </ContentWrapper>
    )
}

export default ManagePayments
