import {userDashboardMenu} from 'config/menus/dashboard/user'
import {useEffect}         from 'react'
import {useDispatch, useSelector} from 'react-redux'
import Div                        from 'shared/Basic/Div'
import ContentWrapper             from 'shared/Layout/ContentWrapper'
import DashboardInfo              from 'shared/Layout/Dashboard/DashboardInfo'
import DashboardWrapper           from 'shared/Layout/Dashboard/DashboardWrapper'
import LinkSwitch                        from 'shared/Basic/LinkSwitch'
import Review                                             from './Review'
import {adminReviewWrapperStyle, userContentWrapperStyle} from './styles' 
import Img                                           from 'shared/Basic/Img'
import Yes                                    from '../../../../assets/yes.svg'
import {menuPanelContext}        from 'shared/Containers/MenuPanelController'
import {push}                    from 'connected-react-router'
import {useContext}              from 'react'

import PricingArrow                                    from '../../../../assets/pricing_arrow.svg' 
const Payments = () => {
    const {setPanel, currentPanel} = useContext(menuPanelContext)
    const dispatch = useDispatch()

    return (
        <ContentWrapper id="test" theme={userContentWrapperStyle}>
            {/* <Div className="payments_banner">
                
            </Div> */}
            <Div className='payments_wrap'>
                <Div className='payments_cnt'>
                    <h2>Inclusive Guide <span>Cost</span> Structure</h2>
                    <div className='payments_block'>
                        <table>
                            <thead>
                                <tr>
                                    <th className='image'>
                                        <Img src={PricingArrow}/>
                                    </th>
                                    <th className='free'>
                                        <label>ALWAYS FREE</label>
                                        <p><sub>$</sub>0<em></em></p>
                                        <span>Anyone</span>
                                        
                                    </th>
                                    <th className='freemium'>
                                        <label>Freemium</label>
                                        <p><sub>$</sub>0<em>1 month</em></p>
                                        <span>Trial</span>                                        
                                    </th>
                                    <th className='bronze selected'>
                                        <label>Bronze</label>
                                        <p><sub>$</sub>20<em>monthly</em></p> 
                                        <div className='features'>
                                            <span>Features</span>
                                            <div className='features_cnt'>
                                                <ul>
                                                    <li><em></em>Small businesses</li>
                                                    <li><em></em>Restaurants</li>    
                                                    <li><em></em>Low profit margins</li> 
                                                    <li><em></em>1-20 employees</li> 
                                                </ul>                                       
                                            </div>
                                        </div>
                                    </th>
                                    <th className='silver'>
                                        <label>Silver</label>
                                        <p><sub>$</sub>50<em>monthly<br/> /per location</em></p>                                         
                                        <div className='features'>
                                            <span>Features</span>
                                            <div className='features_cnt'>
                                                <ul>
                                                    <li><em></em>Mid-size businesses</li>
                                                    <li><em></em>Non-profit under 50 employees</li>    
                                                    <li><em></em>For profit under 100 employees</li> 
                                                </ul>                                       
                                            </div>
                                        </div>
                                    </th>
                                    <th className='gold'>
                                        <label>Gold</label>
                                        <p><sub>$</sub>100<em>monthly<br/> /per location</em></p>
                                        <div className='features'>
                                            <span>Features</span>
                                            <div className='features_cnt'>
                                                <ul>
                                                    <li><em></em>Franchized locations</li>
                                                    <li><em></em>Government organizations</li>    
                                                    <li><em></em>Municipalities</li>
                                                    <li><em></em>Non profits over 50 employees</li>
                                                    <li><em></em>For profits over 100 employees</li>
                                                    <li><em></em>Any business that wants it all</li>
                                                </ul>                                       
                                            </div>
                                        </div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className='title'>
                                    <td>Claiming your business</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th>Claim business</th>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr>
                                    <th>Claim multiple business locations</th>
                                    <td></td>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr className='title'>
                                    <td>Business Details</td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>                                  
                                </tr>
                                <tr>
                                    <th>Upload single photo</th>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    
                                </tr>
                                <tr>
                                    <th>Upload multiple photos</th>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr>
                                    <th>Change business hours</th>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr>
                                    <th>Add business details</th>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr>
                                    <th>On demand help w/ live chat support</th>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                    <td></td>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr>
                                    <th>On demand help w/ live video support</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr className='title'>
                                    <td>Customer Interactions</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th>Respond to reviews</th>
                                    <td></td>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr className='title'>
                                    <td>Resources/Tranings</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th>Best practices document</th>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr>
                                    <th>Access to resource library archive</th>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr>
                                    <th>Access to new resources monthly</th>
                                    <td></td>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr>
                                    <th>Custom resources based on your data</th>
                                    <td></td>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr>
                                    <th>On call chat support</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr>
                                    <th>On call video support</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr>
                                    <th>Annual industry report</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr className='title'>
                                    <td>Admin Controls</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th>1 admin per organization</th>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr>
                                    <th>1 admin per location</th>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                    <td><Img src={Yes}/></td>
                                </tr>
                                <tr>
                                    <th>Up to 5 admins per location</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><Img src={Yes}/></td>
                                </tr> 
                                <tr>
                                    <th></th>
                                    <td></td>
                                    <td><button onClick={true==true ? () => setPanel(
                !currentPanel
                    ? 'make-payment'
                    : null
            ) : () => dispatch(push('/dashboard'))} class="paymentBtn">Subscribe</button></td>
                                    <td><button onClick={true==true ? () => setPanel(
                !currentPanel
                    ? 'make-payment'
                    : null
            ) : () => dispatch(push('/dashboard'))}class="paymentBtn">Subscribe</button></td>
                                    <td><button onClick={true==true ? () => setPanel(
                !currentPanel
                    ? 'make-payment'
                    : null
            ) : () => dispatch(push('/dashboard'))}class="paymentBtn">Subscribe</button></td>
                                    <td><button onClick={true==true ? () => setPanel(
                !currentPanel
                    ? 'make-payment'
                    : null
            ) : () => dispatch(push('/dashboard'))}class="paymentBtn">Subscribe</button></td>
                                </tr>                                   
                            </tbody>
                        </table>
                    </div>
                    <div className='customized_plan'>
                        <div>
                            <h4>Customized Plan</h4>
                            <p>You’ve got very specific requirements? We are happy to offer customized services and functionalities</p>
                        </div>                         
                        <LinkSwitch
                            url={'/admin/users/taxonomy'}
                            children={'Contact Us'}                             
                        />
                    </div>
                </Div>
            </Div>
        </ContentWrapper>
    )
}

 


    //////////////////////////////////////////////////////

  

export default Payments
