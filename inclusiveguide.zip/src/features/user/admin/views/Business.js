import {userDashboardMenu} from 'config/menus/dashboard/user'
import {useEffect}         from 'react'
import {useDispatch, useSelector} from 'react-redux'
import Div                        from 'shared/Basic/Div'
import ContentWrapper             from 'shared/Layout/ContentWrapper'
import DashboardInfo              from 'shared/Layout/Dashboard/DashboardInfo'
import DashboardWrapper           from 'shared/Layout/Dashboard/DashboardWrapper'

import Review                                             from './Review'
import {adminReviewWrapperStyle, userContentWrapperStyle} from './styles'
import Img                                           from 'shared/Basic/Img'
import Gallery                                    from '../../../../assets/gallery-img.png'
import Pointer                                    from '../../../../assets/map_pointer.png'
import Safe                                          from '../../../../assets/safe.png'
import Star                                          from '../../../../assets/star.png'
import Welcome                                       from '../../../../assets/welcome.png'
import Celebrated                                    from '../../../../assets/celebrated.png'
import Profile                                    from '../../../../assets/profile.png'
import Upload                                    from '../../../../assets/upload.svg'
import { Carousel } from 'react-carousel-minimal';
import {useState} from 'react';
const Business = () => {
    const perc = 50;
   // let galaryOpen = false
    const dispatch = useDispatch()
    const {_id, token, reviews, isVerified} = useSelector(state => state.user)

    useEffect(() => {
        dispatch({type: 'user/getUserReviews', payload: {_id, token}})
        document.body.classList.add('dashboad_pages')
            return () => {
            document.body.classList.remove('dashboad_pages')
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    const data = [
        {
          image: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/GoldenGateBridge-001.jpg/1200px-GoldenGateBridge-001.jpg",
          //caption: "San Francisco"
        },
        {
          image: "https://cdn.britannica.com/s:800x450,c:crop/35/204435-138-2F2B745A/Time-lapse-hyper-lapse-Isle-Skye-Scotland.jpg",
         // caption: "Scotland"
        },
        {
          image: "https://static2.tripoto.com/media/filter/tst/img/735873/TripDocument/1537686560_1537686557954.jpg",
          //caption: "Darjeeling"
        },
        {
          image: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/Palace_of_Fine_Arts_%2816794p%29.jpg/1200px-Palace_of_Fine_Arts_%2816794p%29.jpg",
          //caption: "San Francisco"
        },
        {
          image: "https://i.natgeofe.com/n/f7732389-a045-402c-bf39-cb4eda39e786/scotland_travel_4x3.jpg",
          //caption: "Scotland"
        },
        {
          image: "https://www.tusktravel.com/blog/wp-content/uploads/2020/07/Best-Time-to-Visit-Darjeeling-for-Honeymoon.jpg",
          //caption: "Darjeeling"
        },
        {
          image: "https://www.omm.com/~/media/images/site/locations/san_francisco_780x520px.ashx",
          //caption: "San Francisco"
        },
        {
          image: "https://images.ctfassets.net/bth3mlrehms2/6Ypj2Qd3m3jQk6ygmpsNAM/61d2f8cb9f939beed918971b9bc59bcd/Scotland.jpg?w=750&h=422&fl=progressive&q=50&fm=jpg",
          //caption: "Scotland"
        },
        {
          image: "https://www.oyorooms.com/travel-guide/wp-content/uploads/2019/02/summer-7.jpg",
          //caption: "Darjeeling"
        }
      ];
    
      const captionStyle = {
        fontSize: '2em',
        fontWeight: 'bold',
      }
      const slideNumberStyle = {
        fontSize: '20px',
        fontWeight: 'bold',
      }
      const [galaryOpen, setIsActive] = useState(false);

        const handleClick = event => {           
            setIsActive(current => !current);
            
        };


    return (
        <div>
        <ContentWrapper id="test" theme={userContentWrapperStyle}>
            <DashboardWrapper menu={userDashboardMenu}>
                <div className='page_subheader'>
                    <div className='admins_list'>
                        <label>Your Business Admins</label>
                        <ul>
                            <li>
                                <figure>
                                    <Img src={Gallery}/> 
                                    <p>Lisa Murphy</p>
                                </figure>
                            </li>
                            <li>
                                <figure>
                                    <Img src={Gallery}/> 
                                    <p>Lisa Murphy</p>
                                </figure>
                            </li>
                            <li>
                                <figure>
                                    <Img src={Gallery}/> 
                                    <p>Lisa Murphy</p>
                                </figure>
                            </li>
                        </ul>
                        <span>+</span>
                    </div>
                    <div className='chat_block'>
                        <a href='#'>
                        Customer Chat
                        </a>
                    </div>
                </div>
                
                <div className='businesspage_wrap'>
                    <div id='bp_left'>
                        
                        <div className='bp_left-top'>
                            <div className='gallery-sec'>
                                <div className='gallery-head'>
                                    <h5>Coffe Shop & Co</h5>
                                    <span><Img src={Pointer}/>Arizona, USA</span>
                                </div>
                                <div className='gallery-image'>
                                    <ul>
                                        <li className='imageupload'>
                                            <input className='imgupload' type='file' onChange="readURL(this);" />           
                                            <span className='uploadcnt'>
                                                <Img src={Upload}/>
                                                Upload
                                            </span>
                                        </li>
                                        <li className='gallery-item'  onClick={handleClick}>
                                            <figure>
                                                <Img src={Gallery}/>
                                            </figure>
                                        </li> 
                                        <li className='gallery-item' onClick={handleClick}>
                                            <figure>
                                                <Img src={Gallery}/>
                                            </figure>
                                        </li> 
                                        <li className='gallery-item more'  onClick={handleClick}>
                                            <figure>
                                                <Img src={Gallery}/>
                                                <em>+25</em>
                                            </figure>
                                        </li>
                                    </ul>
                                </div>

                                <div className='score-list'>
                                    <div className='count'>
                                        <svg id="scorecount"  xmlns="http://www.w3.org/2000/svg" height="200" width="200" viewBox="0 0 200 200" data-value="70"> 
                                            <path class="bg" stroke="#F0F0F0" d="M41 149.5a77 77 0 1 1 117.93 0"  fill="none"/>
                                            <path class="meter" stroke="#B2D876" d="M41 149.5a77 77 0 1 1 117.93 0" fill="none" stroke-dasharray="350" stroke-dashoffset="350"/>
                                        </svg>
                                        <div className='scorevalue'>
                                            <label>4.17</label>
                                            <span>Score</span>
                                        </div>
                                    </div>
                                    <div className='score-right'>
                                        <ul>
                                            <li>
                                                <Img src={Safe}/>
                                                <label>4.5</label>
                                                <em>Safe</em>
                                            </li>
                                            <li>
                                                <Img src={Welcome}/>
                                                <label>4.5</label>
                                                <em>Welcome</em>
                                            </li>
                                            <li>
                                                <Img src={Celebrated}/>
                                                <label>3.5</label>
                                                <em>Celebrated</em>
                                            </li>
                                        </ul>
                                        <span className='devider'></span>
                                        <a className='all-reviews' href='#'>
                                            125 Reviews ❯
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div className="dg_preview">
                                <h4>Demographic Preview</h4>
                                <div>
                                    <div className='progress'>
                                        <span style={{ width: '66%' }} className='progress_cnt high'>WHITE - 66%</span>
                                        <span style={{ width: '34%' }} className='progress_cnt medium'>BIPOC - 34%</span>                                       
                                    </div>
                                    <div className='progress'>
                                        <span style={{ width: '80%' }} className='progress_cnt high'>ABILITY - 80%</span>
                                        <span style={{ width: '20%' }} className='progress_cnt medium'>DISABILITY - 20%</span> 
                                    </div>
                                    <div className='progress'>
                                        <span style={{ width: '15%' }} className='progress_cnt high'>MEN - 15%</span>
                                        <span style={{ width: '42%' }} className='progress_cnt medium'>WOMEN - 42%</span>
                                        <span style={{ width: '43%' }} className='progress_cnt low'>NONBINARY - 43%</span> 
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='newest_reviews_sec'>
                            <div className='reviews_head'>
                                <h4>Newest Reviews</h4> 
                                <div className='sort'>
                                    <label>Sort by</label>
                                    <select><Img src={Star}/>
                                        <option>Star Rating</option>
                                        <option>Star Rating</option>
                                        <option>Star Rating</option>
                                        <option>Star Rating</option>
                                    </select>
                                </div>
                            </div>
                            <div className='reviews_cnt'>
                                <div className='reviews_item'>
                                    <div className='r_profile'>
                                        <div className='dp_sec'>
                                            <figure>
                                                <Img src={Profile}/>
                                            </figure>
                                            <label>Lisa Murphy</label>
                                        </div>
                                        <div className='rating_sec'>
                                            <div className="rating">
                                                <span className='rated'></span>
                                                <span className='rated'></span>
                                                <span className='rated'></span>
                                                <span></span>
                                                <span></span>                                            
                                            </div>
                                            <p>4.5 <em>/5</em></p>
                                        </div>
                                        <span className='date'>14 March 2023</span>
                                    </div>
                                    <div className='r_comments'>
                                        <p>I came for the submit for Action a few weeks ago and felt welcomed and safe</p>
                                        <ul>
                                            <li>
                                                <div className="progress_bar">
                                                    <div className="percent">
                                                        <svg>
                                                            <circle cx="25" cy="25" r="23" ></circle>
                                                            <circle cx="25" cy="25" r="23" style={{ 'stroke-dashoffset' : 'calc(145px - (145px * 31) / 100)' }}></circle>
                                                        </svg>
                                                        <div className="number">
                                                            <h3>3.1</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <em>Safe</em>
                                            </li>
                                            <li>
                                                <div className="progress_bar">
                                                    <div className="percent">
                                                        <svg>
                                                            <circle cx="25" cy="25" r="23"></circle>
                                                            <circle cx="25" cy="25" r="23" style={{ 'stroke-dashoffset' : 'calc(145px - (145px * 46) / 100)' }}></circle>
                                                        </svg>
                                                        <div className="number">
                                                            <h3>4.6</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <em>Welcome</em>
                                            </li>
                                            <li>
                                                <div className="progress_bar">
                                                    <div className="percent">
                                                        <svg>
                                                            <circle cx="25" cy="25" r="23"></circle>
                                                            <circle cx="25" cy="25" r="23" style={{ 'stroke-dashoffset' : 'calc(145px - (145px * 56) / 100)' }} ></circle>
                                                        </svg>
                                                        <div className="number">
                                                            <h3>5.65</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <em>Celebrated</em>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className='reviews_item'>
                                    <div className='r_profile'>
                                        <div className='dp_sec'>
                                            <figure>
                                                <Img src={Profile}/>
                                            </figure>
                                            <label>Lisa Murphy</label>
                                        </div>
                                        <div className='rating_sec'>
                                            <div className="rating">
                                                <span className='rated'></span>
                                                <span className='rated'></span>
                                                <span className='rated'></span>
                                                <span></span>
                                                <span></span>                                            
                                            </div>
                                            <p>4.5 <em>/5</em></p>
                                        </div>
                                        <span className='date'>14 March 2023</span>
                                    </div>
                                    <div className='r_comments'>
                                        <p>I came for the submit for Action a few weeks ago and felt welcomed and safe</p>
                                        <ul>
                                            <li>
                                                <div className="progress_bar">
                                                    <div className="percent">
                                                        <svg>
                                                            <circle cx="25" cy="25" r="23"></circle>
                                                            <circle cx="25" cy="25" r="23" style={{ 'stroke-dashoffset' : 'calc(145px - (145px * 30) / 100)' }}></circle>
                                                        </svg>
                                                        <div className="number">
                                                            <h3>3.1</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <em>Safe</em>
                                            </li>
                                            <li>
                                                <div className="progress_bar">
                                                    <div className="percent">
                                                        <svg>
                                                            <circle cx="25" cy="25" r="23"></circle>
                                                            <circle cx="25" cy="25" r="23"  style={{ 'stroke-dashoffset' : 'calc(145px - (145px * 46) / 100)' }} ></circle>
                                                        </svg>
                                                        <div className="number">
                                                            <h3>4.6</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <em>Welcome</em>
                                            </li>
                                            <li>
                                                <div className="progress_bar">
                                                    <div className="percent">
                                                        <svg>
                                                            <circle cx="25" cy="25" r="23"></circle>
                                                            <circle cx="25" cy="25" r="23"  style={{ 'stroke-dashoffset' : 'calc(145px - (145px * 56) / 100)' }} ></circle>
                                                        </svg>
                                                        <div className="number">
                                                            <h3>5.6</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <em>Celebrated</em>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className='reviews_item'>
                                    <div className='r_profile'>
                                        <div className='dp_sec'>
                                            <figure>
                                                <Img src={Profile}/>
                                            </figure>
                                            <label>Lisa Murphy</label>
                                        </div>
                                        <div className='rating_sec'>
                                            <div className="rating">
                                                <span className='rated'></span>
                                                <span className='rated'></span>
                                                <span className='rated'></span>
                                                <span></span>
                                                <span></span>                                            
                                            </div>
                                            <p>4.5 <em>/5</em></p>
                                        </div>
                                        <span className='date'>14 March 2023</span>
                                    </div>
                                    <div className='r_comments'>
                                        <p>I came for the submit for Action a few weeks ago and felt welcomed and safe</p>
                                        <ul>
                                            <li>
                                                <div className="progress_bar">
                                                    <div className="percent">
                                                        <svg>
                                                            <circle cx="25" cy="25" r="23"></circle>
                                                            <circle cx="25" cy="25" r="23" style={{ 'stroke-dashoffset' : 'calc(145px - (145px * 31) / 100)' }}></circle>
                                                        </svg>
                                                        <div className="number">
                                                            <h3>3.1</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <em>Safe</em>
                                            </li>
                                            <li>
                                                <div className="progress_bar">
                                                    <div className="percent">
                                                        <svg>
                                                            <circle cx="25" cy="25" r="23"></circle>
                                                            <circle cx="25" cy="25" r="23" style={{ 'stroke-dashoffset' : 'calc(145px - (145px * 46) / 100)' }}></circle>
                                                        </svg>
                                                        <div className="number">
                                                            <h3>4.6</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <em>Welcome</em>
                                            </li>
                                            <li>
                                                <div className="progress_bar">
                                                    <div className="percent">
                                                        <svg>
                                                            <circle cx="25" cy="25" r="23"></circle>
                                                            <circle cx="25" cy="25" r="23" style={{ 'stroke-dashoffset' : 'calc(145px - (145px * 56) / 100)' }}></circle>
                                                        </svg>
                                                        <div className="number">
                                                            <h3>5.6</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <em>Celebrated</em>
                                            </li>
                                        </ul>
                                    </div>
                                </div>                                
                            </div>                            
                        </div>
                        <a href='#' className='view_all'>VIEW ALL</a>
                    </div>


                    <div id='bp_right'>
                        <div className='global_feed'>
                            <div className='feed_title'>
                                <h4>Global Feed</h4>
                                <a href='#'>A feed of all reviews</a>
                            </div>
                            <div className='feed_cnt_wrap'>
                                <div className='feed_cnt'>
                                    <div className='feed_item'>
                                        <h5>“Hello I has a great time!”</h5>
                                        <p>Bakery, Coffe Shop, Donut Shop, Restaurant</p>
                                        <span>3 Mar 2023</span>
                                    </div>
                                    <div className='feed_item'>
                                        <h5>“Hello I has a great time!”</h5>
                                        <p>Bakery, Coffe Shop, Donut Shop, Restaurant</p>
                                        <span>3 Mar 2023</span>
                                    </div>
                                    <div className='feed_item'>
                                        <h5>“Hello I has a great time!”</h5>
                                        <p>Bakery, Coffe Shop, Donut Shop, Restaurant</p>
                                        <span>3 Mar 2023</span>
                                    </div>
                                    <div className='feed_item'>
                                        <h5>“Hello I has a great time!”</h5>
                                        <p>Bakery, Coffe Shop, Donut Shop, Restaurant</p>
                                        <span>3 Mar 2023</span>
                                    </div>
                                    <div className='feed_item'>
                                        <h5>“Hello I has a great time!”</h5>
                                        <p>Bakery, Coffe Shop, Donut Shop, Restaurant</p>
                                        <span>3 Mar 2023</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

   
            </DashboardWrapper>
        </ContentWrapper>
        <div id="gallary_thumbs"  className={galaryOpen ? 'gallary-open' : ''} >
        <Carousel
            data={data}
            time={2000}
            width="850px"
            height="500px"
            captionStyle={captionStyle}
            radius="10px"
            slideNumber={true}
            slideNumberStyle={slideNumberStyle}
            captionPosition="bottom"
            automatic={true}
            dots={false}
            pauseIconColor="white"
            pauseIconSize="40px"
            slideBackgroundColor="darkgrey"
            slideImageFit="cover"
            thumbnails={true}
            thumbnailWidth="100px"
            style={{
              textAlign: "center",
              maxWidth: "850px",
              maxHeight: "500px",
              margin: "40px auto",
            }}
          />

          <span className='closegallary' onClick={handleClick}>X</span>
</div>
        </div>
        
    )
}

 
     /// Score Count script
    console.clear();

    // Get all the Meters
    const meters = document.querySelectorAll('svg#scorecount[data-value] .meter');
    
    meters.forEach(path => {
      // Get the length of the path
      let length = path.getTotalLength();
      // console.log(length) once and hardcode the stroke-dashoffset and stroke-dasharray in the SVG if possible 
      // or uncomment to set it dynamically
      // path.style.strokeDashoffset = length;
      // path.style.strokeDasharray = length;
    
      // Get the value of the meter
      let value = parseInt(path.parentNode.getAttribute('data-value'));
      // Calculate the percentage of the total length
      let to = length * ((100 - value) / 100);
      // Trigger Layout in Safari hack https://jakearchibald.com/2013/animated-line-drawing-svg/
      path.getBoundingClientRect();
      // Set the Offset
      path.style.strokeDashoffset = Math.max(0, to);
    });


    //////////////////////////////////////////////////////

  

export default Business
