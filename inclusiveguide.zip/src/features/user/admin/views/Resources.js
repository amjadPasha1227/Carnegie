import {userDashboardMenu} from 'config/menus/dashboard/user'
import {useEffect, useState }         from 'react'
import {useDispatch, useSelector} from 'react-redux'
import Div                        from 'shared/Basic/Div'
import ContentWrapper             from 'shared/Layout/ContentWrapper'
import DashboardInfo              from 'shared/Layout/Dashboard/DashboardInfo'
import DashboardWrapper           from 'shared/Layout/Dashboard/DashboardWrapper'
import VimeoEmbed                                             from './VimeoEmbed'
import LinkSwitch  from 'shared/Basic/LinkSwitch'
import {placeReviewDescriptionStyle, userContentWrapperStyle} from './styles'
import {adminReviewStyle} from './styles'
import RichText                          from 'shared/Basic/RichText'
import {CDN} from 'config/variables'
import {fileIcon} from 'config/icons'
import Icon                              from 'shared/Basic/Icon'
import DownloadArrow from '../../../../assets/download.svg'
import Tooltip                                                       from 'shared/Controls/ToolTip'
import {imageUploadGravatarTooltipStyle, imageUploadRemoveImageIcon} from 'shared/Fields/styles'
import Tag from '../../../../assets/tag.png'
  
import Checkbox from './checkbox'

const Resources = () => {
    const dispatch = useDispatch()
    const {_id, token, reviews, isVerified, payments, paymentsloaded} = useSelector(state => state.user)
    const {resources, subjectsList, categoryList} = useSelector(state => state.place)
    const [filters, setFilters] = useState({
        subjects: [],
        category: []
    })

    
    const handleFilters = (id, isChecked, type) => {
        setFilters((prev) => isChecked ? ({
            ...prev,
            [type]: [...prev[type], id ]
        }) : ({
            ...prev,
            [type]: prev?.[type].filter((eachId) => eachId !== id )
        }) )

    }

    console.log("filters  ",filters)

    useEffect(() => {

        dispatch({
            type: 'user/getUserPayments',
            payload: {
                _id: _id,
                token: token
            }
        })
        
        dispatch({
            type: 'report/getResources',
            pload: {
                filters: `subjects=${filters["subjects"].join("+")}&category=${filters["category"].join("+")}`
            }
        })
        document.body.classList.add('dashboad_pages','user_resources')
            return () => {
            document.body.classList.remove('dashboad_pages', 'user_resources')
        }       
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [filters])

    useEffect(() => {

        dispatch({
            type: 'user/getUserPayments',
            payload: {
                _id: _id,
                token: token
            }
        })
   
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    return (
        <ContentWrapper theme={userContentWrapperStyle}>
            <DashboardWrapper menu={userDashboardMenu}>

            {paymentsloaded && payments.length > 0 &&

                <DashboardInfo
                    heading={'Resources & Training'}
                    description={"Here are the Resources and Training"}
                />

            }
              
                    {paymentsloaded && payments.length == 0 &&
                    
                    <Div className='paymentblock'>
                        This is a paid feature for business subscribers.

                        <LinkSwitch 
  url={`/payments`}
   className='view_all'>
   Sign up! 
</LinkSwitch>
                        <LinkSwitch 
  url={`/dashboard`}
   className='return_back'>
   Maybe later   
</LinkSwitch>
                    </Div>
                    
                    }
                     {paymentsloaded && payments.length > 0 &&
              <Div theme={{marginBottom: [20, .7, 20]}} id="resource_wrap">
                    <Div className="r_filers">
                        <div className='r_filers_cnt'>
                            <div className='filters_list'>
                                <h6 className='filters_type'>Filter by subject</h6>
                                
                                <ul className='filters'>
                                    {
                                        subjectsList.map((subject) => <li>
                                            <Checkbox optionDetails={subject} checkedStatus={filters["subjects"].includes(subject["_id"])} handleFilters={handleFilters}></Checkbox>
                                        
                                        </li>)
                                    }
                                </ul>
                            </div>
                            <div className='filters_list'>
                                <h6 className='filters_type'>Filter by resource type</h6>
                                <ul className='filters'>
                                    {
                                        categoryList.map((category) => <li>
                                            <Checkbox optionDetails={category} checkedStatus={filters["category"].includes(category["_id"])}  handleFilters={handleFilters}></Checkbox>
                                        </li>)
                                    }


                                </ul>
                            </div>
                        </div>
                        <div className='filters_actions'>
                            <button className='btn reset' onClick={() => setFilters((prev)=>({
                                subjects: [],
                                category: []
                            }))}>Reset</button>
                            <button className='btn submit'>submit</button>
                        </div>
                    </Div>
                      <Div theme={{display: 'flex', flexDirection: 'column'}} id="resource_cnt">
                      <LinkSwitch 
  url={`/dashboard`}
   className='return_back'>
   Back to Dashboard   
</LinkSwitch>
                      {resources && resources.map((resource) => (

  <Div theme={adminReviewStyle} id="resource_item"
  
  className={resource.document !== 'null' && resource.document !== null ? 'has-document' : ''}

  >
    <Div id="resource_text">
    <LinkSwitch 
       url={`/dashboard/resources/${resource.slug}`}
        className='review_title'>
        {resource.title}
        
    </LinkSwitch>
    <Div className="filtered_list tags">
    {resource && resource.subjects && resource.subjects.length > 0 && resource.subjects[0] && (
        <>
            <img className='tag_img' src={Tag} />
            <ul>
                {resource.subjects.map((sub) => {
                    const matchedSubject = subjectsList.find((subject) => sub === subject._id);
                    const subjectName = matchedSubject ? matchedSubject.name : 'Unknown'; // Handle the case where the subject isn't found
                    return (
                        <li key={sub}>
                            <p>{subjectName}</p>
                        </li>
                    );
                })}
            </ul>
        </>
    )}
</Div>

    <Div className="filtered_list">
    { !!resource.category && <>
        <label>category :</label>
        <ul>
            <li>
            <p>{(categoryList.filter((category) => resource.category == category._id))[0]?.["name"]}</p>
        </li> 
        
        </ul>
    </>     
}
    </Div>
    <RichText theme={placeReviewDescriptionStyle} className="review_desc">
    {resource.description?.length > 100 ? resource.description.substring(0, 100) + "..." : resource.description}

        </RichText>
        <VimeoEmbed  vimeoLink={`${resource.videolink}`}   />
    </Div>
      {
         resource.document!='null' && resource.document!=null &&
         <Div>
         <a  target='_blank' className='fileListicon'  href={`${CDN}${resource.document}`}>
         <div class="tooltip_cnt">
            <p>Click here to download</p>
        </div>
         <img className='download_file' src={DownloadArrow} />
         <Icon icon={fileIcon}/>
         </a>
         </Div>
      }
  </Div>
                        
                      ))}</Div>
                        
              </Div>

    }


            </DashboardWrapper>
        </ContentWrapper>
    )
}

export default Resources
