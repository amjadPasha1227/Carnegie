import {userDashboardMenu} from 'config/menus/dashboard/user'
import {useEffect}         from 'react'
import {useDispatch, useSelector} from 'react-redux'
import Div                        from 'shared/Basic/Div'
import ContentWrapper             from 'shared/Layout/ContentWrapper' 
import {adminReviewWrapperStyle, userContentWrapperStyle} from './styles'  
import CommingSoon                                    from '../../../../assets/coming-soon.png' 
import Img     
                                      from 'shared/Basic/Img'
const Payments = () => {
    useEffect(() => {        

        // eslint-disable-next-line react-hooks/exhaustive-deps
        document.body.classList.add("comming_soon")
            return () => {
            document.body.classList.remove("comming_soon")
        }
    }, [])

    return (
        <ContentWrapper theme={userContentWrapperStyle}>
            <Div className='payments_wrap comming_wrap'>
                <Div className='comming_cnt'>                    
                    <h4>We're Comming Soon..</h4>
                </Div>
            </Div>
        </ContentWrapper>
    )
}

 


    //////////////////////////////////////////////////////

  

export default Payments
