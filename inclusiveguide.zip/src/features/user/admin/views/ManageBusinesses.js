import {userDashboardMenu}        from 'config/menus/dashboard/user'
import {useEffect}                from 'react'
import {useDispatch, useSelector} from 'react-redux'
import PlaceCard                  from 'shared/Cards/Place'
import ContentWrapper             from 'shared/Layout/ContentWrapper'
import DashboardInfo              from 'shared/Layout/Dashboard/DashboardInfo'
import DashboardWrapper           from 'shared/Layout/Dashboard/DashboardWrapper'
import {userContentWrapperStyle}  from './styles'
import Div from 'shared/Basic/Div'

const ManageBusinesses = () => {
    const dispatch = useDispatch()
    const {user, businesses} = useSelector(state => state.user)
    const {_id, token, slug} = useSelector(state => state.user)
    const {placesOwned} = user

    useEffect(() => {
        dispatch({
            type: 'user/getUser',
            payload: {
                slug: slug,
                _id: _id,
                token: token
            }
        })

        // eslint-disable-next-line react-hooks/exhaustive-deps
        document.body.classList.add("dashboad_pages")
            return () => {
            document.body.classList.remove("dashboad_pages")
        }
    }, [])


    return (
        <ContentWrapper theme={userContentWrapperStyle}>
            <DashboardWrapper menu={userDashboardMenu}>
                <Div id="business_wrap">
                    <Div id="business_title">
                        <DashboardInfo
                            heading={`Manage Your Business`}
                            description={'A list of your businesses'}
                        />
                    </Div>
                    <div className='business_reviews_wrap'>
                        {(businesses?.length > 0 && placesOwned?.length > 0) && businesses.map((business) => {
                            return (
                                <PlaceCard
                                    place={business}
                                    styleType={2}
                                    linkCard={true}
                                    safe={business.averageSafe}
                                    celebrated={business.averageCelebrated}
                                    welcome={business.averageWelcome}
                                    inclusiveScore={business.inclusiveScore}
                                    url={`/user/business/update/${business.slug}`}
                                    key={business._id}
                                    name={business.name}
                                    address={business.address1}
                                    city={business.city}
                                    state={business.state}
                                />
                            )
                        })}
                    </div>
                </Div>
            </DashboardWrapper>
        </ContentWrapper>
    )
}

export default ManageBusinesses
