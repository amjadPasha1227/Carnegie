import Gravatar                   from 'react-gravatar'
import Div                        from 'shared/Basic/Div'
import S3Img                      from 'shared/Basic/S3Img'
import {userDashboardAvatarStyle} from './styles'

const Avatar = ({avatar, email}) => {
    return (
        <Div theme={userDashboardAvatarStyle}>
            {((avatar && (
                <S3Img
                    url={avatar}
                    theme={{width: '100%'}}
                />
            )) || (
                <Gravatar email={email} size={200}/>
            ))}
        </Div>
    )
}

export default Avatar
