import {COUNT} from 'config/variables'

export const quantityFields = [
    {
        name: 'count',
        type: COUNT
    }
]
