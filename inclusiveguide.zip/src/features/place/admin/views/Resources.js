
import { adminDashboardMenu } from 'config/menus/dashboard/admin'
import {useEffect}                from 'react'
import {useDispatch, useSelector} from 'react-redux'
import Div                            from 'shared/Basic/Div'
import ContentWrapper             from 'shared/Layout/ContentWrapper'
import AdminDashboardWrapper      from 'shared/Layout/Dashboard/admin/AdminDashboardWrapper'
import {adminContentWrapperStyle} from 'shared/Layout/styles'
import DashboardInfo
                                                                                  from 'shared/Layout/Dashboard/DashboardInfo'
import ResourceDetail          from './ResourceDetail'
import Create        from './Create'
import {taxonomyButtonStyle} from 'shared/Layout/styles'
import LinkSwitch            from 'shared/Basic/LinkSwitch'
import {menuPanelContext}        from 'shared/Containers/MenuPanelController'   
import {push}                    from 'connected-react-router'
import {useContext}              from 'react'
const Resources = ({ userSlug}) => {
    const {place, addResourceSuccess, resources, updateResourceSuccess} = useSelector(state => state.place)

    const {setPanel, currentPanel} = useContext(menuPanelContext)
    const dispatch = useDispatch()

useEffect(() => {

    dispatch({
        type: 'report/getResources',
        pload: {
            filters: null
        }
    })

    // eslint-disable-next-line react-hooks/exhaustive-deps
}, [])


useEffect(() => {
    if (addResourceSuccess) {
        setPanel(null)
        // dispatch({type: 'place/closeReviewPanel'})
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
}, [addResourceSuccess])

useEffect(() => {
    if (updateResourceSuccess) {
        setPanel(null)
    }
}, [updateResourceSuccess])

    return (
        <ContentWrapper theme={adminContentWrapperStyle}>
           <AdminDashboardWrapper menu={adminDashboardMenu}>
       <DashboardInfo
              heading={'Manage Resources'}
              description={"Here you'll find the Resources."}
          />
          <LinkSwitch
                   onClick={true == true ? () => setPanel(
                    !currentPanel
                        ? 'post-resource'
                        : null
                ) : () => dispatch(push('/dashboard'))}
            
                    children={'Add Resource'}
                    theme={taxonomyButtonStyle}
                />
           
            <Div theme={{marginBottom: [20, .7, 20], width:"100%"}}>
                    <Div theme={{display: 'flex', flexDirection: 'column'}}>
                    {resources && resources.map((resource) => (

                    <ResourceDetail
                    key={resource._id}
                    id={resource.id}
                    slug={resource.slug}
                    document = {resource.document}
                    title = {resource.title}
                    description={resource.description}  
                    videolink={`${resource.videolink}`}      
                    created={resource.createdAt}
                    subjects={(resource?.subjects?.length > 0) ? resource.subjects : []}
                    category={resource.category ? resource.category : ""}
                    />
                    
                    ))}</Div>
                    
            </Div>
         </AdminDashboardWrapper>
        </ContentWrapper>
   
        
    )
}

export default Resources
