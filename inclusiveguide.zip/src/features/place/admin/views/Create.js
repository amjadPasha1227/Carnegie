import {validatePlace}                from 'features/place/admin/fields/update'
import React, {useContext, useEffect} from 'react'
import {useDispatch, useSelector}     from 'react-redux'
import {searchContext}                from 'shared/Containers/SearchController'
import Form                           from 'shared/Fields/Form'
import ContentWrapper                 from 'shared/Layout/ContentWrapper'
import AdminDashboardWrapper          from 'shared/Layout/Dashboard/admin/AdminDashboardWrapper'
import {createPlaceFields}            from '../fields/create'

const Create = () => {
    const dispatch = useDispatch()
    const {_id, token} = useSelector(state => state.user)
    const {taxonomy} = useSelector(state => state.place)

    const initialValues = {
        _id: _id,
        token: token,
        adaptiveEquipmentSolution: [],
        audioAvailable: false,
        address1: '',
        address2: '',
        city: '',
        zip: '',
        tel: '',
        country: '',
        state: '',
        latitude: 0,
        longitude: 0,
        bathrooms: [],
        businessOwner: [],
        braille: false,
        isBrickAndMortar: true,
        categories: [],
        communitiesServed: [],
        description: '',
        doorway: [],
        entryway: [],
        foodOptions: [],
        hearingImpairedSolution: [],
        isPublished: false,
        isRestaurant: false,
        languageSpoken: [],
        largeAdaptiveEquipment: false,
        name: '',
        onlyAccessibleByStairs: false,
        photo: '',
        photoFile: '',
        publicTransportation: [],
        signLanguageAccessible: false,
        website: '',
        wheelchairElevator: false,
        wheelchairParking: false,
        wheelchairRamps: false,
        wheelchairRestroom: false,
        visualImpairedSolution: [],
        ownerIdentity: [],
    }

    const {
        adaptiveEquipmentSolution,
        bathrooms,
        businessOwner,
        doorway,
        communitiesServed,
        entryway,
        foodOptions,
        hearingImpairedSolution,
        languageSpoken,
        placeCategory,
        publicTransportation,
        visualImpairedSolution,
        ownerIdentity
    } = taxonomy

    const {usersIndex} = useContext(searchContext)
    const options = [
        {
            name: 'adaptiveEquipmentSolution',
            options: adaptiveEquipmentSolution
        },
        {
            name: 'bathrooms',
            options: bathrooms
        },
        {
            name: 'businessOwner',
            options: businessOwner
        },
        {
            name: 'communitiesServed',
            options: communitiesServed
        },
        {
            name: 'doorway',
            options: doorway
        },
        {
            name: 'entryway',
            options: entryway
        },
        {
            name: 'foodOptions',
            options: foodOptions
        },
        {
            name: 'hearingImpairedSolution',
            options: hearingImpairedSolution
        },
        {
            name: 'languageSpoken',
            options: languageSpoken
        },
        {
            name: 'publicTransportation',
            options: publicTransportation
        },
        {
            name: 'visualImpairedSolution',
            options: visualImpairedSolution
        },
        {
            name: 'ownerIdentity',
            options: ownerIdentity
        },
        {
            name: 'categories',
            options: placeCategory
        }
    ]
    const algoliaSearchOptions = [
        {
            name: 'businessOwner',
            index: usersIndex,
            actions: {
                search: 'user/searchUserAlgoliaIndex',
                current: 'user/getBusinessOwners'
            }
        }
    ]


    useEffect(() => {
        dispatch({type: 'place/listBathroom'})
        dispatch({type: 'place/listBusinessOwner'})
        dispatch({type: 'place/listCommunitiesServed'})
        dispatch({type: 'place/listFoodOptions'})
        dispatch({type: 'place/listLanguageSpoken'})
        dispatch({type: 'place/listPlaceCategory'})

        dispatch({type: 'place/listAdaptiveEquipmentSolution'})
        dispatch({type: 'place/listEntryway'})
        dispatch({type: 'place/listDoorway'})
        dispatch({type: 'place/listHearingImpairedSolution'})
        dispatch({type: 'place/listPublicTransportation'})
        dispatch({type: 'place/listVisualImpairedSolution'})
        dispatch({type: 'place/listOwnerIdentity'})


        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])


    return (
        <ContentWrapper>
            <AdminDashboardWrapper>
                <Form
                    initialValues={initialValues}
                    fields={createPlaceFields()}
                    validationSchema={validatePlace}
                    dispatchAction={'place/createPlace'}
                    formHeading={'Create Place'}
                    buttonText={'Create'}
                    options={options}
                    enableReinitialize={true}
                    algoliaSearchOptions={algoliaSearchOptions}
                />
            </AdminDashboardWrapper>
        </ContentWrapper>
    )
}

export default Create
