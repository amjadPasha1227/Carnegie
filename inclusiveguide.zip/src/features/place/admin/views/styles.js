import {colorPalette, globals} from 'config/styles'
import {genericCardStyle}      from 'shared/Cards/styles'
import {defaultFormStyle}      from 'shared/Fields/styles'
import {
    absolute,
    black,
    center,
    column,
    flex,
    flexEnd,
    flexStart,
    grid,
    hidden,
    inlineFlex,
    none,
    pointer,
    relative,
    spaceBetween,
    sv,
    white
}                              from 'utils/themer'

export const dangerZoneButtonStyle = {
    border: `1px solid ${globals.colors.borderColor}`,
    borderRadius: [5, .7, 5],
    color: colorPalette.brightRed,
    alignSelf: center,
    padding: `${sv(10)} ${sv(20)}`,
    letterSpacing: [1, .7, 1],
    mobile: {
        width: '100%',
        backgroundColor: colorPalette.brightRed,
        color: white,
        weight: 500,
        display: flex,
        alignItems: center,
        justifyContent: center,
    },
    hover: {
        color: white,
        backgroundColor: colorPalette.brightRed,
        cursor: pointer
    }
}

export const submitPlaceButtonStyle = {
    border: `1px solid ${globals.colors.borderColor}`,
    borderRadius: [5, .7, 5],
    color: colorPalette.forestGreen,
    alignSelf: center,
    padding: `${sv(10)} ${sv(20)}`,
    letterSpacing: [1, .7, 1],
    mobile: {
        width: '100%',
        backgroundColor: colorPalette.forestGreen,
        color: white,
        weight: 500,
        display: flex,
        alignItems: center,
        justifyContent: center,
    },
    hover: {
        color: white,
        backgroundColor: colorPalette.forestGreen,
        cursor: pointer
    }
}