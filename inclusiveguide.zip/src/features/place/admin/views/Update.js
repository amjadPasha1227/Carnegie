import {placeFields, validatePlace} from 'features/place/admin/fields/update'
import {pendingPlaceFields}         from 'features/place/admin/fields/pending'
import React, {useContext, useEffect} from 'react'
import {useDispatch, useSelector}     from 'react-redux'
import {searchContext}                from 'shared/Containers/SearchController'
import DangerZone                     from 'shared/Controls/DangerZone'
import Form                           from 'shared/Fields/Form'
import ContentWrapper                 from 'shared/Layout/ContentWrapper'
import AdminDashboardWrapper          from 'shared/Layout/Dashboard/admin/AdminDashboardWrapper'
import {adminFormWrapperStyle}        from 'shared/Layout/Dashboard/admin/styles'
import {adminContentWrapperStyle}     from 'shared/Layout/styles'
import {history}                      from 'store'

const Update = () => {
    const dispatch = useDispatch()
    const {_id, token, isAdmin} = useSelector(state => state.user)
    const {slug} = useSelector(state => state.site)
    const {place, taxonomy, current} = useSelector(state => state.place)
    const {placesIndex, usersIndex} = useContext(searchContext)
    const {
        adaptiveEquipmentSolution,
        audioAvailable,
        bathrooms,
        businessOwner,
        categories,
        communitiesServed,
        description,
        doorway,
        entryway,
        foodOptions,
        hearingImpairedSolution,
        isPendingSubmission,
        isBrickAndMortar,
        languageSpoken,
        name,
        photo,
        publicTransportation,
        signLanguageAccessible,
        submittedBy,
        website,
        wheelchairElevator,
        wheelchairParking,
        wheelchairRamps,
        wheelchairRestroom,
        visualImpairedSolution,
        ownerIdentity,
        type,
        hours,
        phoneNumber,
        emailAddress
    } = place

    const initialValues = {
        adaptiveEquipmentSolution: adaptiveEquipmentSolution || [],
        audioAvailable: audioAvailable,
        address1: place.geojson?.[0]?.properties?.address,
        address2: place.geojson?.[0]?.properties?.address2 || '',
        city: place.geojson?.[0]?.properties?.city,
        zip: place.geojson?.[0]?.properties?.postalCode,
        country: place.geojson?.[0]?.properties?.country,
        state: place.geojson?.[0]?.properties?.state,
        tel: place.geojson?.[0]?.properties?.tel || '',
        longitude: place.geojson?.[0]?.geometry?.coordinates?.[0],
        latitude: place.geojson?.[0]?.geometry?.coordinates?.[1],
        bathrooms: bathrooms || [],
        businessOwner: businessOwner || [],
        categories: categories || [],
        communitiesServed: communitiesServed || [],
        description: description,
        doorway: doorway || [],
        entryway: entryway || [],
        foodOptions: foodOptions || [],
        hearingImpairedSolution: hearingImpairedSolution || [],
        isPendingSubmission: isPendingSubmission || undefined,
        isBrickAndMortar: isBrickAndMortar,
        languageSpoken: languageSpoken || [],
        name: name,
        photo: photo,
        photoFile: '',
        publicTransportation: publicTransportation || [],
        signLanguageAccessible: signLanguageAccessible,
        submittedBy: submittedBy || undefined,
        submittedByEmail: current?.submittedBy?.email,
        submittedByNameFirst: current?.submittedBy?.nameFirst,
        submittedPlaceSlug: current?.place?.slug,
        website: website || '',
        wheelchairElevator: wheelchairElevator,
        wheelchairParking: wheelchairParking,
        wheelchairRamps: wheelchairRamps,
        wheelchairRestroom: wheelchairRestroom,
        visualImpairedSolution: visualImpairedSolution || [],
        ownerIdentity: ownerIdentity || [],
        slug,
        _id,
        token,
        hours: !!hours ? hours : {},
        phoneNumber,
        emailAddress
    }

    useEffect(() => {
        setTimeout(() => {
            if (current?.place?.businessOwner?.filter(item => item === _id).length === 0 && !isAdmin) {
                history.push('/dashboard/my-businesses')
            }

        }, 2000)


        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [current])

    useEffect(() => {
        dispatch({
            type: 'place/getPlace',
            payload: {
                slug: slug
            }
        })

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])


    useEffect(() => {
        if (!place?.isPendingSubmission && !!place?.objectID) {
            if (!!place._id) {
                placesIndex.saveObject(place)
                    .then(() => {
                    })
                    .catch(error =>
                        console.log('error', error)
                    )
            }
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [place])


    const options = [
        {
            name: 'adaptiveEquipmentSolution',
            options: taxonomy.adaptiveEquipmentSolution
        },
        {
            name: 'bathrooms',
            options: taxonomy.bathrooms
        },
        {
            name: 'communitiesServed',
            options: taxonomy.communitiesServed
        },
        {
            name: 'doorway',
            options: taxonomy.doorway
        },
        {
            name: 'entryway',
            options: taxonomy.entryway
        },
        {
            name: 'foodOptions',
            options: taxonomy.foodOptions
        },
        {
            name: 'hearingImpairedSolution',
            options: taxonomy.hearingImpairedSolution
        },
        {
            name: 'languageSpoken',
            options: taxonomy.languageSpoken
        },
        {
            name: 'publicTransportation',
            options: taxonomy.publicTransportation
        },
        {
            name: 'visualImpairedSolution',
            options: taxonomy.visualImpairedSolution
        },
        {
            name: 'ownerIdentity',
            options: taxonomy.ownerIdentity
        },
        {
            name: 'categories',
            options: taxonomy.placeCategory
        }
    ]
    const algoliaSearchOptions = [
        {
            name: 'businessOwner',
            index: usersIndex,
            actions: {
                search: 'user/searchUserAlgoliaIndex',
                current: 'user/getBusinessOwners'
            }
        }
    ]

    useEffect(() => {
        dispatch({type: 'place/listBathroom'})
        dispatch({type: 'place/listBusinessOwner'})
        dispatch({type: 'place/listCommunitiesServed'})
        dispatch({type: 'place/listFoodOptions'})
        dispatch({type: 'place/listLanguageSpoken'})
        dispatch({type: 'place/listPlaceCategory'})

        dispatch({type: 'place/listAdaptiveEquipmentSolution'})
        dispatch({type: 'place/listEntryway'})
        dispatch({type: 'place/listDoorway'})
        dispatch({type: 'place/listHearingImpairedSolution'})
        dispatch({type: 'place/listPublicTransportation'})
        dispatch({type: 'place/listVisualImpairedSolution'})
        dispatch({type: 'place/listOwnerIdentity'})


        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    return (
        <ContentWrapper theme={adminContentWrapperStyle}>
            <AdminDashboardWrapper isAdmin={isAdmin}>
                <>
                    {(isAdmin || current?.place?.businessOwner?.filter(item => item === _id).length > 0) && (
                        <>
                            <Form
                                initialValues={initialValues}
                                fields={
                                    isPendingSubmission
                                        ? pendingPlaceFields(isBrickAndMortar)
                                        : placeFields(isBrickAndMortar)
                                }
                                validationSchema={validatePlace}
                                dispatchAction={'place/updatePlace'}
                                formHeading={!!name ? `Update ${name}` : 'Update'}
                                buttonText={'Update'}
                                theme={adminFormWrapperStyle}
                                enableReinitialize={true}
                                options={options}
                                algoliaSearchOptions={algoliaSearchOptions}
                            />
                            <DangerZone
                                attemptDestroyAction={'site/attemptDestroyEntity'}
                                destroyAction={'site/destroyEntity'}
                                slug={slug}
                                type={type}
                                objectID={place.objectID}
                                index={placesIndex}
                            />
                        </>
                    )}
                </>

            </AdminDashboardWrapper>
        </ContentWrapper>
    )
}

export default Update
