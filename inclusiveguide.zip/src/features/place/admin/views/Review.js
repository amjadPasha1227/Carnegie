import {reviewFields, validateReview} from 'features/place/admin/fields/review'
import {
    reviewFormHeadingStyle,
    reviewFormStyle,
    reviewFormWrapperStyle,
    reviewLeaveWrapperStyle
}                                     from 'features/place/views/styles'
import {useSelector}                  from 'react-redux'
import Div                            from 'shared/Basic/Div'
import H2                             from 'shared/Basic/H2'
import Form                           from 'shared/Fields/Form'

const Review = () => {
    const {_id, token, nameFirst, email, avatar} = useSelector(state => state.user)
    const {slug} = useSelector(state => state.site)
    const {place} = useSelector(state => state.place)

    const initialValues = {
        isAnon: false,
        review: '',
        photo: '',
        safe: undefined,
        celebrated: undefined,
        welcome: undefined,
        user: _id,
        reviewerName: nameFirst,
        reviewerAvatar: avatar,
        reviewerEmail: email,
        placeId: place._id,
        placeName: place.name,
        placeSlug: place.slug,
        _id,
        token,
        slug,
    }

    return (
        <Div theme={reviewFormWrapperStyle} className='leave_a_review_sec'>
            <Div theme={reviewLeaveWrapperStyle}>
                <H2 theme={reviewFormHeadingStyle}>
                    <Div>Leave a Review for</Div>
                    <span>{place.name}</span>
                </H2>
            </Div>
            <Form
                initialValues={initialValues}
                fields={reviewFields}
                validationSchema={validateReview}
                dispatchAction={'place/addReview'}
                buttonText={'Submit'}
                theme={reviewFormStyle}
                enableReinitialize={true}
            />
        </Div>
    )
}

export default Review
