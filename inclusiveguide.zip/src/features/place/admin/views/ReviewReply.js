import {replyFields, validateReview} from 'features/place/admin/fields/reply'
import {
    reviewFormHeadingStyle,
    reviewFormStyle,
    reviewFormWrapperStyle,
    reviewLeaveWrapperStyle
}                                     from 'features/place/views/styles'
import {useSelector}                  from 'react-redux'
import Div                            from 'shared/Basic/Div'
import H2                             from 'shared/Basic/H2'
import Form                           from 'shared/Fields/Form'

const ReviewReply = () => {
    const {_id, token, nameFirst, email, avatar} = useSelector(state => state.user)
    const {slug} = useSelector(state => state.site)
    const {place, currentReplyReviewId} = useSelector(state => state.place)

    const initialValues = {
        isAnon: false,
        review: '',
        user: _id,
        parentId:currentReplyReviewId._id,
        reviewerName: nameFirst,
        reviewerAvatar: avatar,
        reviewerEmail: email,
        placeId: place._id,
        placeName: place.name,
        placeSlug: place.slug,
        _id,
        token,
        slug,
    }

    return (
        <Div theme={reviewFormWrapperStyle} className='leave_a_review_sec'>
            <Div theme={reviewLeaveWrapperStyle}>
                <H2 theme={reviewFormHeadingStyle}>
                    <Div>Reply Review</Div>
                </H2>
            </Div>
            <Form
                initialValues={initialValues}
                fields={replyFields}
                validationSchema={validateReview}
                dispatchAction={'place/addReview'}
                buttonText={'Submit'}
                theme={reviewFormStyle}
                enableReinitialize={true}
            />
        </Div>
    )
}

export default ReviewReply
