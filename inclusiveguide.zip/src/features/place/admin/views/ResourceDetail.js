import dayjs              from 'dayjs'
import Div                from 'shared/Basic/Div'
import LinkSwitch         from 'shared/Basic/LinkSwitch'
import {adminReviewStyle, placeReviewDescriptionStyle} from '../../../user/admin/views/styles'
import RichText                          from 'shared/Basic/RichText'
import {CDN} from 'config/variables'
import {fileIcon} from 'config/icons'
import Icon                              from 'shared/Basic/Icon'
import DownloadArrow from '../../../../assets/download.svg'
import { dangerZoneButtonStyle, submitPlaceButtonStyle } from './styles'  
import {menuPanelContext}            from 'shared/Containers/MenuPanelController'
import { useContext, useEffect, useState } from 'react'
import {useDispatch, useSelector} from 'react-redux'
import {push}                    from 'connected-react-router'



const ResourceDetail = ({slug,id,title, description, document, videolink, created, subjects,category}) => {
    const {currentPanel, setPanel} = useContext(menuPanelContext)
    const dispatch = useDispatch()
    const { token} = useSelector(state => state.user)
    const { subjectsList, categoryList } = useSelector(state => state.place)
    const [subjectStr, setSubjectStr] = useState('')

    useEffect(() => {
        if (subjects && subjects.length > 0 && subjects[0]) {
            setSubjectStr(() => {
                return subjects.map((subject) => {
                    const matchedSubject = subjectsList.find((eachSub) => eachSub["_id"] === subject);
                    
                    // Return the subject name if it exists, otherwise return a default string 'Unknown'
                    return matchedSubject ? matchedSubject.name : 'Unknown';
                }).join(", ");
            });
        }
    }, [subjects]);
    

    const getUpdatePanel = () => {
        console.log("in the get panel  ",id)
         setPanel(
            !currentPanel
                ? 'update-resource'
                : null
        )
        dispatch({
            type: 'place/setEditResourceSlug',
            payload: {
                resourceSlug: slug,
            }
        }) 
    }

    const deleteRes = () => {
        console.log("delete action dispatched ",id)
        dispatch({
            type: 'place/deleteResource',
            payload: {
                resourceId: id,
                token: token
            }
        }) 
    }
      
        return (
            <LinkSwitch  theme={adminReviewStyle} id="reports_list" className="reports_list_sec">
                {/*<RichText>{review.review}</RichText>*/}
                <Div theme={adminReviewStyle.top} className="reports_list_inner">
                    <Div className='resource_item_sec mb-0'>
                        <Div theme={adminReviewStyle.name}>{title}</Div>
                        {
                            document!='null' && document!=null &&
                            <Div className="fileListsection">
                            <a  target='_blank' className='fileListicon'  href={`${CDN}${document}`}>
                            <div class="tooltip_cnt">
                                <p>Click here to download</p>
                            </div>
                            <img className='download_file' src={DownloadArrow} />
                            <Icon icon={fileIcon}/>
                            </a>
                            </Div>
                        }
                    </Div>

                    <RichText theme={placeReviewDescriptionStyle} className="review_desc">
                    {description?.length > 100 ? description.substring(0, 100) + "..." : description}

                        </RichText>

                    { videolink!=null && videolink!=''  && videolink!='null' 
                      &&
                     <Div theme={adminReviewStyle.name} className="video_link">{videolink}</Div> 
                    }
                    
                    { ( subjectStr?.length > 0) && <Div>
                        Subjects : {subjectStr}    
                    </Div>}
                   {!!category && <Div>Category :  {(categoryList.filter((categ) => category == categ._id))[0]?.["name"]}
                    </Div>}

                    <Div className="created_on" theme={adminReviewStyle.date}>Created on: {dayjs(created).format('MMMM DD, YYYY - hh:mm:ss')}
                        <Div className="actions_btns">
                            <Div
                              onClick={true == true ? getUpdatePanel : () => dispatch(push('/dashboard'))}
                                theme={submitPlaceButtonStyle}
                                className="btn"
                            >
                                Edit
                            </Div>
                            <Div
                              onClick={true == true ? deleteRes : () => dispatch(push('/dashboard'))}
                                theme={dangerZoneButtonStyle}
                                className="btn"
                            >
                                Delete
                            </Div>
                        </Div>
                    </Div>
                </Div>
                
            </LinkSwitch>
        )

}

export default ResourceDetail
