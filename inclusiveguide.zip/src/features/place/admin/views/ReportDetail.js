import dayjs              from 'dayjs'
import Div                from 'shared/Basic/Div'
import LinkSwitch         from 'shared/Basic/LinkSwitch'
import {adminReviewStyle} from '../../../user/admin/views/styles'


const ReportDetail = ({businessName, report, status, created, requestedBy, url}) => {
 
    {
      
        return (
            <LinkSwitch url={url} download={true} theme={adminReviewStyle} id="reports_list">
                {/*<RichText>{review.review}</RichText>*/}
                <Div theme={adminReviewStyle.top}>
                    <Div theme={adminReviewStyle.name} className="businessName">{businessName}</Div>
                    <Div theme={adminReviewStyle.date}>Created on: {dayjs(created).format('MMMM DD, YYYY - hh:mm:ss')}</Div>
                    <Div theme={adminReviewStyle.date}>Requested By: {requestedBy}</Div>
                </Div>
                <Div><strong>Status</strong>: {status}</Div>
                {/*<Div><strong>Celebrated</strong>: {review.celebrated[0]}</Div>*/}
                {/*<Div><strong>Welcome</strong>: {review.welcome[0]}</Div>*/}
            </LinkSwitch>
        )

}
}

export default ReportDetail
