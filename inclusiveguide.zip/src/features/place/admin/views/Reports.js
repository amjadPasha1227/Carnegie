
import { adminDashboardMenu } from 'config/menus/dashboard/admin'
import {useEffect}                from 'react'
import {useDispatch, useSelector} from 'react-redux'
import Div                            from 'shared/Basic/Div'
import ContentWrapper             from 'shared/Layout/ContentWrapper'
import AdminDashboardWrapper      from 'shared/Layout/Dashboard/admin/AdminDashboardWrapper'
import {adminContentWrapperStyle} from 'shared/Layout/styles'
import DashboardInfo
                                                                                  from 'shared/Layout/Dashboard/DashboardInfo'
import ReportDetail          from './ReportDetail'


const Reports = ({ userSlug}) => {
    const {place, reports} = useSelector(state => state.place)
    const dispatch = useDispatch()

useEffect(() => {
    dispatch({
        type: 'report/getReports'
    })

    // eslint-disable-next-line react-hooks/exhaustive-deps
}, [])



    return (
        <ContentWrapper theme={adminContentWrapperStyle}>
           <AdminDashboardWrapper menu={adminDashboardMenu}>
       <DashboardInfo
              heading={'Manage Reports'}
              description={"Here you'll find the generated reports."}
          />
          
          <Div>
              <Div theme={{marginBottom: [20, .7, 20]}}>
                      <Div theme={{display: 'flex', flexDirection: 'column'}}>
                      {reports && reports.map((report) => (
                        
                      <ReportDetail
                        key={report._id}
                        businessName = {report.businessName}
                        report={report}  
                        status={report.status}
                        created={report.createdAt}
                        requestedBy = {report.requestedBy}
                        url={`${report.url}`}                  />
                        
                      ))}</Div>
                        
              </Div>
          </Div>
         </AdminDashboardWrapper>
        </ContentWrapper>
   
        
    )
}

export default Reports
