import {
    ALGOLIA_SEARCH,
    IMAGE_UPLOAD,
    MULTI_SELECT,
    NUMBER,
    RICH_TEXT,
    SERVICE_AREA,
    STATE_CITY,
    SUBMITTED_BY,
    TEL,
    TEXT,
    TOGGLE,
    UPLOAD_PATHS,EMAIL,HOURS_OPEN
}               from 'config/variables'
import * as Yup from 'yup'
import {phoneRegExp}   from '../../../../utils/helpers'


const taxonomyFields = [
    {
        name: 'bathrooms',
        inputLabel: 'Bathrooms',
        type: MULTI_SELECT
    },
    {
        name: 'categories',
        inputLabel: 'Categories',
        type: MULTI_SELECT
    },
    {
        name: 'communitiesServed',
        inputLabel: 'Affinity Spaces',
        type: MULTI_SELECT
    },
    {
        name: 'foodOptions',
        inputLabel: 'Food Options',
        type: MULTI_SELECT
    },
    {
        name: 'languageSpoken',
        inputLabel: 'Language Spoken',
        type: MULTI_SELECT
    },
    {
        name: 'businessOwner',
        inputLabel: 'Owners',
        type: ALGOLIA_SEARCH
    },
    {
        name: 'adaptiveEquipmentSolution',
        inputLabel: 'Adaptive Equipment Solutions',
        type: MULTI_SELECT
    },
    {
        name: 'doorway',
        inputLabel: 'Doorway',
        type: MULTI_SELECT
    },
    {
        name: 'entryway',
        inputLabel: 'Entryway',
        type: MULTI_SELECT
    },
    {
        name: 'hearingImpairedSolution',
        inputLabel: 'Hearing Impaired Solutions',
        type: MULTI_SELECT
    },
    {
        name: 'publicTransportation',
        inputLabel: 'Public Transportation',
        type: MULTI_SELECT
    },
    {
        name: 'visualImpairedSolution',
        inputLabel: 'Visual Impaired Solutions',
        type: MULTI_SELECT
    },
    {
        name: 'ownerIdentity',
        inputLabel: 'Owner Identity',
        type: MULTI_SELECT
    },
    {
        name: 'wheelchairElevator',
        inputLabel: 'Wheelchair Accessible Elevator',
        type: TOGGLE
    },
    {
        name: 'wheelchairParking',
        inputLabel: 'Wheelchair Accessible Parking',
        type: TOGGLE
    },
    {
        name: 'wheelchairRamps',
        inputLabel: 'Wheelchair Accessible Ramps',
        type: TOGGLE
    },
    {
        name: 'wheelchairRestroom',
        inputLabel: 'Wheelchair Accessible Restrooms',
        type: TOGGLE
    }
]

const physicalLocationFields = [
    {
        name: 'address1',
        inputLabel: 'Address ',
        type: TEXT
    },
    {
        name: 'address2',
        inputLabel: 'Address 2 ',
        type: TEXT
    },
    {
        name: ['state', 'city'], // needs to be [state, city]
        inputLabel: 'City ',
        type: STATE_CITY
    },
    {
        name: 'zip',
        inputLabel: 'Zip ',
        type: TEXT
    },
]

const virtualLocationFields = [
    {
        name: 'serviceArea',
        inputLabel: 'Service Area',
        type: SERVICE_AREA
    }
]

const longLat = [
    {
        name: 'longitude',
        inputLabel: 'Longitude ',
        type: NUMBER
    },
    {
        name: 'latitude',
        inputLabel: 'Latitude ',
        type: NUMBER
    },
]

const fields = [
    {
        name: 'photo',
        file: 'photoFile',
        cropWidth: 1920,
        cropHeight: 1080,
        aspect: 16 / 9,
        s3Path: UPLOAD_PATHS.place,
        type: IMAGE_UPLOAD,
    },
    {
        name: 'name',
        inputLabel: 'Name',
        type: TEXT
    },
    {
        name: 'description',
        inputLabel: 'Description',
        type: RICH_TEXT,
        tooltip: 'Write a description for your business.'
    },
    {
        name: 'website',
        inputLabel: 'Website',
        type: TEXT
    },
    {
        name: 'isBrickAndMortar',
        inputLabel: 'Do you have a physical address?',
        type: TOGGLE
    },
    {
        name: 'hours',
        inputLabel: 'Open Hours',
        type: HOURS_OPEN

    },
    {
        name: 'phoneNumber',
        inputLabel: 'Phone Number',
        type: TEL

    },
    {
        name: 'emailAddress',
        inputLabel: 'email Address',
        type: EMAIL

    }
]

const pending = [
    {
        name: 'isPendingSubmission',
        inputLabel: 'Pending Submission',
        type: TOGGLE
    },
    {
        name: 'submittedBy',
        inputLabel: 'Submitted By',
        type: SUBMITTED_BY
    },
]

export const pendingPlaceFields = (isBrickAndMortar) => {
    const physical = [...fields, ...physicalLocationFields, ...longLat, ...taxonomyFields, ...pending]
    const virtual = [...fields, ...virtualLocationFields, ...longLat, ...taxonomyFields, ...pending]

    return isBrickAndMortar ? physical : virtual
}


/**
 *
 * Validation Objects written with Yup
 * https://github.com/jquense/yup#api
 *
 */

export const validatePlace = Yup.object().shape({
    photo: Yup
        .string(),
    name: Yup
        .string()
        .max(255)
        .required('Required'),
    description: Yup
        .string()
        .max(5000),
    phoneNumber: Yup
        .string()
        .matches(phoneRegExp, 'Phone number is not valid'),
    emailAddress: Yup.string()
        .email('invalid email')
})
