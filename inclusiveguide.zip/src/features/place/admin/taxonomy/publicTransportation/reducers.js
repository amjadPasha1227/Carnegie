export const publicTransportation = {
    listPublicTransportationSuccess: (state, action) => {
        state.taxonomy.publicTransportation = action.payload
    },
    getPublicTransportationSuccess: (state, action) => {
        state.taxonomy.publicTransportation = action.payload
    }
}
