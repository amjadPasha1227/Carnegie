import {
    publicTransportationField,
    validatePublicTransportation
}                    from 'features/place/admin/taxonomy/publicTransportation/fields'
import {useSelector} from 'react-redux'
import Form          from 'shared/Fields/Form'

const Create = () => {
    const {_id, token} = useSelector(state => state.user)
    const initialValues = {
        _id,
        token,
        name: '',
        description: ''
    }

    return (
        <Form
            initialValues={initialValues}
            fields={publicTransportationField}
            validationSchema={validatePublicTransportation}
            dispatchAction={'place/createPublicTransportation'}
            formHeading={'Create Public Transportation'}
            buttonText={'Create'}
        />
    )
}

export default Create
