export const entryway = {
    listEntrywaySuccess: (state, action) => {
        state.taxonomy.entryway = action.payload
    },
    getEntrywaySuccess: (state, action) => {
        state.taxonomy.entryway = action.payload
    }
}
