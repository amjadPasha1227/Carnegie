import {entrywayField, validateEntryway} from 'features/place/admin/taxonomy/entryway/fields'
import {useSelector}                     from 'react-redux'
import Form                              from 'shared/Fields/Form'

const Create = () => {
    const {_id, token} = useSelector(state => state.user)
    const initialValues = {
        _id,
        token,
        name: '',
        description: ''
    }

    return (
        <Form
            initialValues={initialValues}
            fields={entrywayField}
            validationSchema={validateEntryway}
            dispatchAction={'place/createEntryway'}
            formHeading={'Create Entryway Solution'}
            buttonText={'Create'}
        />
    )
}

export default Create
