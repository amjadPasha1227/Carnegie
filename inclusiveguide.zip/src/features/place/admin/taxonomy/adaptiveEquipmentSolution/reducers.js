export const adaptiveEquipmentSolution = {
    listAdaptiveEquipmentSolutionSuccess: (state, action) => {
        state.taxonomy.adaptiveEquipmentSolution = action.payload
    },
    getAdaptiveEquipmentSolutionSuccess: (state, action) => {
        state.taxonomy.adaptiveEquipmentSolution = action.payload
    }
}
