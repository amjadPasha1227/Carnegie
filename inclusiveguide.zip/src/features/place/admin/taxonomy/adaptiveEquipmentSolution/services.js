import {API} from 'config/variables'

/**
 * to perform crud on admin
 * get all places
 * get a single admin
 * update single admin
 * delete single admin
 */

export const addAdaptiveEquipmentSolution = ({_id, token, place}) =>
    fetch(`${API}/adaptive-equipment-solution/create/${_id}`, {
        method: 'POST',
        headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${token}`
        },
        body: place
    })
        .then(response => {
            return response.json()
        })
        .catch(error => {
            return error
        })

export const deleteAdaptiveEquipmentSolution = ({_id, token, slug}) =>
    fetch(`${API}/adaptive-equipment-solution/${slug}/${_id}`, {
        method: 'DELETE',
        headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
        }
    })
        .then(response => {
            return response.json()
        })
        .catch(error => {
            return error
        })

export const getAdaptiveEquipmentSolution = ({slug}) =>
    fetch(`${API}/adaptive-equipment-solution/${slug}`, {
        method: 'GET'
    })
        .then(response => {
            return response.json()
        })
        .catch(error => {
            return error
        })

export const updateAdaptiveEquipmentSolution = ({slug, _id, token, adaptiveEquipment}) =>
    fetch(`${API}/adaptive-equipment-solution/${slug}/${_id}`, {
        method: 'PUT',
        headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${token}`
        },
        body: adaptiveEquipment
    })
        .then(response => {
            return response.json()
        })
        .catch(error => {
            return error
        })

export const getAdaptiveEquipmentSolutionList = () =>
    fetch(`${API}/adaptive-equipment-solution?limit=undefined`, {
        method: 'GET'
    })
        .then(response => {
            return response.json()
        })
        .catch(error => {
            return error
        })
