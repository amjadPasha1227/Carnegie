import {
    adaptiveEquipmentSolutionField,
    validateAdaptiveEquipmentSolution
}                    from 'features/place/admin/taxonomy/adaptiveEquipmentSolution/fields'
import {useSelector} from 'react-redux'
import Form          from 'shared/Fields/Form'

const Create = () => {
    const {_id, token} = useSelector(state => state.user)
    const initialValues = {
        _id,
        token,
        name: '',
        description: ''
    }

    return (
        <Form
            initialValues={initialValues}
            fields={adaptiveEquipmentSolutionField}
            validationSchema={validateAdaptiveEquipmentSolution}
            dispatchAction={'place/createAdaptiveEquipmentSolution'}
            formHeading={'Create Adaptive Equipment Solution'}
            buttonText={'Create'}
        />
    )
}

export default Create
