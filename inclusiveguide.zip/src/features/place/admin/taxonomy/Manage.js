import {useEffect}                                                                      from 'react'
import {useSelector}                                                                    from 'react-redux'
import Div                                                                              from 'shared/Basic/Div'
import LinkSwitch                                                                       from 'shared/Basic/LinkSwitch'
import ContentWrapper
                                                                                        from 'shared/Layout/ContentWrapper'
import AdminDashboardWrapper
                                                                                        from 'shared/Layout/Dashboard/admin/AdminDashboardWrapper'
import DashboardInfo
                                                                                        from 'shared/Layout/Dashboard/DashboardInfo'
import {adminContentWrapperStyle, adminTaxonomyWrapperStyle, taxonomyButtonOptionStyle} from 'shared/Layout/styles'

const Manage = () => {
    const {confirmDelete} = useSelector(state => state.site)
    const TAX_PATH = '/admin/place/taxonomy'

    useEffect(() => {

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [confirmDelete])


    return (
        <ContentWrapper theme={adminContentWrapperStyle}>
            <AdminDashboardWrapper>
                <DashboardInfo
                    heading={'Manage Place Taxonomy'}
                    description={'Click to edit.'}
                />
                <Div theme={adminTaxonomyWrapperStyle}>
                    <LinkSwitch url={`${TAX_PATH}/adaptive-equipment-solution`} theme={taxonomyButtonOptionStyle}>
                        Adaptive Equipment Solution
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/bathroom`} theme={taxonomyButtonOptionStyle}>
                        Bathrooms
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/communities-served`} theme={taxonomyButtonOptionStyle}>
                        Communities Served
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/doorway`} theme={taxonomyButtonOptionStyle}>
                        Doorway
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/entryway`} theme={taxonomyButtonOptionStyle}>
                        Entryway
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/food-options`} theme={taxonomyButtonOptionStyle}>
                        Food Options
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/hearing-impaired-solution`} theme={taxonomyButtonOptionStyle}>
                        Hearing Impaired Solutions
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/language-spoken`} theme={taxonomyButtonOptionStyle}>
                        Languages Spoken
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/place-category`} theme={taxonomyButtonOptionStyle}>
                        Place Category
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/public-transportation`} theme={taxonomyButtonOptionStyle}>
                        Public Transportation
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/visual-impaired-solution`} theme={taxonomyButtonOptionStyle}>
                        Visual Impaired Solutions
                    </LinkSwitch>
                    <LinkSwitch url={`${TAX_PATH}/owner-identity`} theme={taxonomyButtonOptionStyle}>
                        Owner identities
                    </LinkSwitch>
                </Div>
            </AdminDashboardWrapper>
        </ContentWrapper>
    )
}

export default Manage
