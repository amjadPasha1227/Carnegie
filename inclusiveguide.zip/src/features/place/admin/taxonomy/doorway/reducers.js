export const doorway = {
    listDoorwaySuccess: (state, action) => {
        state.taxonomy.doorway = action.payload
    },
    getDoorwaySuccess: (state, action) => {
        state.taxonomy.doorway = action.payload
    }
}
