import {doorwayField, validateDoorway} from 'features/place/admin/taxonomy/doorway/fields'
import {useSelector}                   from 'react-redux'
import Form                            from 'shared/Fields/Form'

const Create = () => {
    const {_id, token} = useSelector(state => state.user)
    const initialValues = {
        _id,
        token,
        name: '',
        description: ''
    }

    return (
        <Form
            initialValues={initialValues}
            fields={doorwayField}
            validationSchema={validateDoorway}
            dispatchAction={'place/createDoorway'}
            formHeading={'Create Doorway Solution'}
            buttonText={'Create'}
        />
    )
}

export default Create
