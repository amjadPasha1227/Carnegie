export const hearingImpairedSolution = {
    listHearingImpairedSolutionSuccess: (state, action) => {
        state.taxonomy.hearingImpairedSolution = action.payload
    },
    getHearingImpairedSolutionSuccess: (state, action) => {
        state.taxonomy.hearingImpairedSolution = action.payload
    }
}
