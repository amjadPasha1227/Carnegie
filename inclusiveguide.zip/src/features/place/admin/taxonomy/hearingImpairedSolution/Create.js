import {
    hearingImpairedSolutionField,
    validateHearingImpairedSolution
}                    from 'features/place/admin/taxonomy/hearingImpairedSolution/fields'
import {useSelector} from 'react-redux'
import Form          from 'shared/Fields/Form'

const Create = () => {
    const {_id, token} = useSelector(state => state.user)
    const initialValues = {
        _id,
        token,
        name: '',
        description: ''
    }

    return (
        <Form
            initialValues={initialValues}
            fields={hearingImpairedSolutionField}
            validationSchema={validateHearingImpairedSolution}
            dispatchAction={'place/createHearingImpairedSolution'}
            formHeading={'Create Hearing Impaired Solution'}
            buttonText={'Create'}
        />
    )
}

export default Create
