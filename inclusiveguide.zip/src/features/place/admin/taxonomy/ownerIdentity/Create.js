import {ownerIdentityField, validateOwnerIdentity} from 'features/place/admin/taxonomy/ownerIdentity/fields'
import {useSelector}                                 from 'react-redux'
import Form                                          from 'shared/Fields/Form'

const Create = () => {
    const {_id, token} = useSelector(state => state.user)
    const initialValues = {
        _id,
        token,
        name: '',
        description: ''
    }

    return (
        <Form
            initialValues={initialValues}
            fields={ownerIdentityField}
            validationSchema={validateOwnerIdentity}
            dispatchAction={'place/createOwnerIdentity'}
            formHeading={'Create Owner Identity'}
            buttonText={'Create'}
        />
    )
}

export default Create
