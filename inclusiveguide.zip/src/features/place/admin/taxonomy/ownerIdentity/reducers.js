export const ownerIdentity = {
    listOwnerIdentitySuccess: (state, action) => {
        state.taxonomy.ownerIdentity = action.payload
    },
    getOwnerIdentitySuccess: (state, action) => {
        state.taxonomy.ownerIdentity = action.payload
    }
}
