import {
    validateVisualImpairedSolution,
    visualImpairedSolutionField
}                    from 'features/place/admin/taxonomy/visualImpairedSolution/fields'
import {useSelector} from 'react-redux'
import Form          from 'shared/Fields/Form'

const Create = () => {
    const {_id, token} = useSelector(state => state.user)
    const initialValues = {
        _id,
        token,
        name: '',
        description: ''
    }

    return (
        <Form
            initialValues={initialValues}
            fields={visualImpairedSolutionField}
            validationSchema={validateVisualImpairedSolution}
            dispatchAction={'place/createVisualImpairedSolution'}
            formHeading={'Create Visual Impaired Solution'}
            buttonText={'Create'}
        />
    )
}

export default Create
