export const visualImpairedSolution = {
    listVisualImpairedSolutionSuccess: (state, action) => {
        state.taxonomy.visualImpairedSolution = action.payload
    },
    getVisualImpairedSolutionSuccess: (state, action) => {
        state.taxonomy.visualImpairedSolution = action.payload
    }
}
