import React, { useEffect } from "react";
import FilterOption from "./FilterOption";

const FilterCategoryOptions = ({
  categoryOptions,
  mapFilterOpen,
  setIsOpen,
  setFilter,
  filter,
  setSelectedFilters,
  selectedFilters,
}) => {
  useEffect(() => {
    if (!!categoryOptions) {
      const optionIds = categoryOptions?.reduce((acc = [], cv) => {
        acc.push(cv.id);

        return acc;
      }, []);

      for (const option of optionIds) {
        if (filter?.includes(option)) {
          setIsOpen(true);
        }
      }
    }
  }, [mapFilterOpen, categoryOptions, filter, setIsOpen]);

  return (
    <>
      {categoryOptions?.map((option, i) => (
        <FilterOption
          key={i}
          option={option}
          setIsOpen={setIsOpen}
          setFilter={setFilter}
          filter={filter}
          setSelectedFilters={setSelectedFilters}
          selectedFilters={selectedFilters}
        />
      ))}
    </>
  );
};

export default FilterCategoryOptions;
