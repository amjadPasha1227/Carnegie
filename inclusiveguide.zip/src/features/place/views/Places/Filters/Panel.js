import React, {useEffect, useMemo, useState}                          from "react"
import {useDispatch, useSelector}                                     from 'react-redux'
import Div                                                            from 'shared/Basic/Div'
import MotionDiv                                                      from 'shared/Basic/MotionDiv'
import {unslugify}                                                    from 'utils/helpers'
import {hidden, sv}                                                   from 'utils/themer'
import {mapSidebarFilterByTextStyle, mapSidebarFilterPanelInnerStyle} from '../styles'
import FilterCategories                                               from './FilterCategories'


const Panel = ({mapFilterOpen,  setSelectedFilters,
    selectedFilters,}) => {
    const {slug} = useSelector(state => state.site)
    const [filter, setFilter] = useState(unslugify(slug))
  //  const [selectedFilters, setSelectedFilters] = useState('')
    const dispatch = useDispatch()
    const {taxonomy} = useSelector(state => state.place)


    const {
        adaptiveEquipmentSolution,
        bathrooms,
        communitiesServed,
        entryway,
        doorway,
        foodOptions,
        hearingImpairedSolution,
        visualImpairedSolution,
        ownerIdentity
    } = taxonomy

    const filterMenuVariants = {
        initial: {
            height: 0,
            width: '100%',
            background: '#F2F2F2',
            position: 'absolute',
            top: sv(80, .7),
            right: '0',
            zIndex: 1,
            overflow: hidden,
            transition: {
                duration: .3,
            }
        },
        animate: {
            height: '100%',
            overflowY: 'scroll',
            transition: {
                duration: .3,
            },
        }
    }


    const filterComponents = useMemo(() => {
        const filters = [
            adaptiveEquipmentSolution,
            bathrooms,
            communitiesServed,
            entryway,
            doorway,
            foodOptions,
            hearingImpairedSolution,
            visualImpairedSolution,
            ownerIdentity
        ]

        return filters.reduce((acc = [], cv) => {
            const components = {
                [cv?.[0]?.type]: cv?.map((b) => {
                        return {id: b.id, name: b.name}
                    }
                )
            }
            return {...acc, ...components}

        }, [])

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        adaptiveEquipmentSolution,
        bathrooms,
        communitiesServed,
        entryway,
        doorway,
        foodOptions,
        hearingImpairedSolution,
        visualImpairedSolution,
        ownerIdentity
    ])

    const filterCategories = useMemo(() => {
        return (
            [
                {
                    heading: 'Accessibility Solutions',
                    options: [filterComponents['visual-impaired-solution'], filterComponents['hearing-impaired-solution']]
                },
                {
                    heading: 'Affinity Space',
                    options: [filterComponents['communities-served']]
                },
                {
                    heading: 'Entry and Doorway',
                    options: [filterComponents['entryway'], filterComponents['doorway']]
                },
                {
                    heading: 'Bathrooms',
                    options: [filterComponents['bathroom']]
                },
                {
                    heading: 'Adaptive Equipment',
                    options: [filterComponents['adaptive-equipment-solution']]
                },
                {
                    heading: 'Food Options',
                    options: [filterComponents['food-options']]
                },
                {
                    heading: 'Owner Identity',
                    options: [filterComponents['owner-identity']]
                }
            ]
        )
    }, [filterComponents])

    useEffect(() => {

        dispatch({type: 'place/listHearingImpairedSolution'})
        dispatch({type: 'place/listVisualImpairedSolution'})

        dispatch({type: 'place/listCommunitiesServed'})
        dispatch({type: 'place/listEntryway'})
        dispatch({type: 'place/listDoorway'})
        dispatch({type: 'place/listBathroom'})
        dispatch({type: 'place/listAdaptiveEquipmentSolution'})

        dispatch({type: 'place/listFoodOptions'})
        dispatch({type: 'place/listLanguageSpoken'})
        dispatch({type: 'place/listOwnerIdentity'})


        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])


    return (
        <MotionDiv
            initial={'initial'}
            animate={mapFilterOpen ? 'animate' : 'animate'}
            variants={filterMenuVariants}
            theme={{overflowY: 'scroll', top: [80, .7, 80]}}
            className="filter_cnt"
        >
            <Div theme={mapSidebarFilterPanelInnerStyle} className='mapSidebarFilterPanelInnerStyle'>
                {/* <Div theme={mapSidebarFilterByTextStyle}>Filter By</Div> */}
                <Div>
                    {filterCategories?.map((cat, i) =>
                        <FilterCategories
                            key={i}
                            heading={cat.heading}
                            setFilter={setFilter}
                            mapFilterOpen={mapFilterOpen}
                            filter={filter}
                            filterCategoryOptions={cat.options}
                            setSelectedFilters={setSelectedFilters}
                            selectedFilters={selectedFilters}
                        />
                    )}
                </Div>
            </Div>
        </MotionDiv>
    )
}

export default Panel
