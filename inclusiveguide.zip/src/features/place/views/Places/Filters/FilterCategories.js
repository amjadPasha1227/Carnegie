import React, { useState } from "react";
import Div from "shared/Basic/Div";
import MotionDiv from "shared/Basic/MotionDiv";
import {
  filterItemWrapperStyle,
  mapSidebarFilterHeadingStyle,
} from "../styles";
import FilterCategoryOptions from "./FilterCategoryOptions";

const FilterCategories = ({
  setFilter,
  mapFilterOpen,
  filter,
  heading,
  filterCategoryOptions,
  setSelectedFilters,
  selectedFilters,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const variants = {
    initial: {
      height: 0,
    },
    open: {
      height: "auto",
    },
  };

  return (
    <>
      <Div
        theme={mapSidebarFilterHeadingStyle}
        onClick={() => setIsOpen((flag) => !flag)}
        // className='mapSidebarFilterHeadingStyle'
        className={`${isOpen ? "mapSidebarFilterHeadingStyle open" : "mapSidebarFilterHeadingStyle"}`}
      >
        {heading}
      </Div>
      <MotionDiv
        initial={isOpen ? "open" : "initial"}
        animate={isOpen ? "open" : "initial"}
        variants={variants}
        theme={filterItemWrapperStyle(isOpen)}
        className='FilterCategoryOptions'
      >
        {!!filterCategoryOptions &&
          filterCategoryOptions?.map((categoryOptions, i) => (
            <FilterCategoryOptions
              key={i}
              categoryOptions={categoryOptions}
              setIsOpen={setIsOpen}
              setFilter={setFilter}
              filter={filter}
              mapFilterOpen={mapFilterOpen}
              setSelectedFilters={setSelectedFilters}
              selectedFilters={selectedFilters}
            />
          ))}
      </MotionDiv>
    </>
  );
};

export default FilterCategories;
