import React, { useContext } from "react";
import { useDispatch, useSelector } from "react-redux";
import Div from "shared/Basic/Div";
import { mapContext } from "shared/Containers/MapController";
import { searchContext } from "shared/Containers/SearchController";
import { unslugify } from "utils/helpers";
import { filterItemStyle } from "../styles";

const FilterOption = ({
  option,
  setFilter,
  filter,
  setSelectedFilters,
  selectedFilters,
  className
}) => {
  const { slug } = useSelector((state) => state.site);
  const dispatch = useDispatch();
  const { coords } = useContext(mapContext);
  const { placesIndex } = useContext(searchContext);
  const radius = 1609;

  return (
    <Div
      key={option.id}
      theme={filterItemStyle(filter?.includes(option.id))}
      className={`${filter?.includes(option.id) ? "FilterOption selected" : "FilterOption"}`}
      onClick={() => {
        if (!filter?.includes(option.id)) {
          dispatch({
            type: "place/searchAlgoliaPlaceIndex",
            payload: {
              index: placesIndex,
              input: `${filter} ${option.id}`,
              latitude: coords.lat,
              longitude: coords.lon,
              radius: radius,
              isFilter: true,
            },
          });
          setFilter(`${filter} ${option.id}`);
          setSelectedFilters(`${selectedFilters} ${option.name}`);

        } else {
          const hasNoFilters =
            unslugify(slug) ===
            filter.replace(/\s/g, "").replace(option.id, "");
          //remove/deselect filters
          dispatch({
            type: hasNoFilters
              ? "place/searchAllPlaces"
              : "place/searchAlgoliaPlaceIndex",
            payload: {
              index: placesIndex,
              input: `${filter.replace(option.id, "")}`,
              latitude: coords.lat,
              longitude: coords.lon,
              radius: radius,
              isFilter: true,
            },
          });
          setFilter(`${filter.replace(option.id, "")}`);
          setSelectedFilters(`${selectedFilters.replace(option.name, "")}`);

        }
      }}
    >
      {option.name}
    </Div>
  );
};

export default FilterOption;
