import {cart, coffee, filter, gas, tree, utensils}                                            from 'config/icons'
import {useContext}                                                                           from 'react'
import {useDispatch}                                                                          from 'react-redux'
import Div                                                                                    from 'shared/Basic/Div'
import Icon                                                                                   from 'shared/Basic/Icon'
import {mapContext}                                                                           from 'shared/Containers/MapController'
import {searchContext}                                                                        from 'shared/Containers/SearchController'
import {placesFilterButtonIconStyle, placesFilterButtonStyle, placesFilterButtonWrapperStyle} from '../../styles'
import Hotels from '../../../../../assets/hotels.svg'
import Food from '../../../../../assets/food.svg'
import ShoppingBag from '../../../../../assets/shopping-bag.svg'
import TeaCup from '../../../../../assets/tea-cup.svg'
import Cart from '../../../../../assets/cart.svg'
import Gas from '../../../../../assets/natural-gas.svg'
import SelectAll from '../../../../../assets/select-all.svg'

const Filters = ({setMapFilterOpen, mapFilterOpen, isMobile}) => {
    const dispatch = useDispatch()
    const {coords} = useContext(mapContext)
    const {placesIndex} = useContext(searchContext)
    const radius = 1609

    const searchByCat = (input) =>
        dispatch({
            type: 'place/searchAllPlaces',
            payload: {
                longitude: coords.lon,
                latitude: coords.lat,
                radius: radius,
                index: placesIndex,
                input: input
            }
        })

    return (
        <Div theme={placesFilterButtonWrapperStyle} className='places_list'>
            <Div theme={{display: 'flex'}}>
                <Div
                    theme={placesFilterButtonStyle(mapFilterOpen)}
                    onClick={() => setMapFilterOpen(flag => !flag)}
                    className='places_list_item'
                >
                    <span className='place_icon selectall'><img src={SelectAll} /></span>
                    <span className='place_name'>All</span>
                </Div>
                {!isMobile && (
                  <>
                      <Div
                          theme={placesFilterButtonStyle()}
                          onClick={() => searchByCat('hotels')}
                          className='places_list_item'
                      >
                          <span className='place_icon hotels'><img src={Hotels} /></span>
                          <span className='place_name'>Hotels</span>
                      </Div>
                      <Div
                          theme={placesFilterButtonStyle()}
                          onClick={() => searchByCat('restaurant')}
                          className='places_list_item'
                      >
                          <span className='place_icon food'><img src={Food} /></span>
                          <span className='place_name'>food</span>
                      </Div>
                      <Div
                          theme={placesFilterButtonStyle()}
                          onClick={() => searchByCat('shopping')}
                          className='places_list_item'
                      >
                          <span className='place_icon shopping'><img src={ShoppingBag} /></span>
                          <span className='place_name'>shopping</span>
                      </Div>
                      <Div
                          theme={placesFilterButtonStyle()}
                          onClick={() => searchByCat('coffee')}
                          className='places_list_item'
                      >
                          <span className='place_icon coffee'><img src={TeaCup} /></span>
                          <span className='place_name'>coffee</span>
                      </Div>
                      <Div
                          theme={placesFilterButtonStyle()}
                          onClick={() => searchByCat('grocery')}
                          className='places_list_item'
                      >
                          <span className='place_icon grocery'><img src={Cart} /></span>
                          <span className='place_name'>grocery</span>
                      </Div>
                      <Div
                          theme={placesFilterButtonStyle()}
                          onClick={() => searchByCat('gas station')}
                          className='places_list_item'
                      >
                          <span className='place_icon gas'><img src={Gas} /></span>
                          <span className='place_name'>gas</span>
                      </Div>
                  </>
                )}
            </Div>
        </Div>
    )
}


export default Filters
