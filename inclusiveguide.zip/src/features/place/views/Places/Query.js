import {useSelector}                                       from 'react-redux'
import Div                                                 from 'shared/Basic/Div'
import {unslugify}                                         from 'utils/helpers'
import {placeQueryStyle, placeSearchResultsQueryTextStyle} from './styles'

const Query = ({noResults}) => {
    const {slug} = useSelector(state => state.site)

    return (
        <Div theme={placeQueryStyle}>
            {(slug !== 'places' && (
                <Div theme={placeSearchResultsQueryTextStyle}>
                    {(noResults && (
                        <>
                            <em>No results for </em><em>&ldquo; </em>{slug ? unslugify(slug) : ''}<em>&rdquo;</em>
                        </>
                    )) || (
                        <>
                            <em>Search results for </em><em>&ldquo; </em>{slug ? unslugify(slug) : ''}<em>&rdquo;</em>
                        </>
                    )}
                </Div>
            ))}
        </Div>
    )
}

export default Query
