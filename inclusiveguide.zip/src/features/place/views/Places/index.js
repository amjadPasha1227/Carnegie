import {
    placesContentInnerWrapperStyle,
    placesContentWrapperStyle,
    placesMapInnerWrapperStyle,
    placesFullContainerStyle
}                                        from 'features/place/views/styles'
import {mobileFlag}                      from 'features/site/slice'
import {useContext, useEffect, useState} from 'react'
import {useDispatch, useSelector}        from 'react-redux'
import Div                               from 'shared/Basic/Div'
import {mapContext}                      from 'shared/Containers/MapController'
import {searchContext}                   from 'shared/Containers/SearchController'
import ContentWrapper                    from 'shared/Layout/ContentWrapper'
import Map                               from 'shared/Map'
import {isEmpty, unslugify}              from 'utils/helpers'
import Filters                           from './Filters'
import MapSidebar                        from './MapSidebar'
import MapListing                        from './MapListing'

import NoResults                         from './NoResults'
import {placesMapStyle}                  from './styles'
import SwiperImg1 from '../../../../assets/swiper/slide1.png'
import SwiperImg2 from '../../../../assets/swiper/slide2.png'
import SwiperImg3 from '../../../../assets/swiper/slide3.png'
import Groceries from '../../../../assets/groceries.svg'
import Park from '../../../../assets/park.svg'
import MapImg from '../../../../assets/map.svg'
import Safe from '../../../../assets/places_safe.svg'
import Welcome from '../../../../assets/places_welcome.svg'
import Celebrated from '../../../../assets/places_celebrated.svg'

const Places = () => {
    const {
        mapboxPlaces,
        algoliaPlaces,
        current,
    } = useSelector(state => state.place)
    const {filteredPlaces} = current
    const {slug, url} = useSelector(state => state.site)

    const [filter] = useState(unslugify(slug))
    const [selectedFilters, setSelectedFilters] = useState('')

    const isMobile = useSelector(mobileFlag)
    const dispatch = useDispatch()
    const [allPlaces, setAllPlaces] = useState([])
    const [features, setFeatures] = useState([])
    const [geoJsonFeature, setGeoJsonFeature] = useState()
    const [mapFilterOpen, setMapFilterOpen] = useState(false)
    const {coords} = useContext(mapContext)
    const {placesIndex} = useContext(searchContext)
    const radius = 1609
    const createFeaturesFromAlgolia = (place) =>
        setFeatures(features => [...features, {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": place.geojson?.[0]?.geometry?.coordinates
            },
            "properties": {
                "averageSafe": place.averageSafe,
                "averageCelebrated": place.averageCelebrated,
                "averageWelcome": place.averageWelcome,
                "categories": place.categories,
                "inclusiveScore": place.inclusiveScore,
                "name": place.geojson[0]?.properties?.name,
                "description": place.geojson[0]?.properties?.description,
                "address": place.geojson[0]?.properties?.address,
                "city": place.geojson[0]?.properties?.city,
                "country": place.geojson[0]?.properties?.country,
                "postalCode": place.geojson[0]?.properties?.postalCode,
                "state": place.geojson[0]?.properties?.state,
                "slug": place?.slug,
                "photo": place?.photo,
                "_id": place._id
            }
        }])

    const algoliaPlaceHasCoordinates = (place) =>
        !!place?.geojson?.[0]?.geometry?.coordinates[0] && !!place?.geojson?.[0]?.geometry?.coordinates[1]

    const mapboxPlaceHasCoordinates = (place) =>
        Array.isArray(place?.center) && place.center.length === 2

    const isAlgoliaPlace = (place) =>
        !!place?._id

    /*  Initialize  */
    const init = () => {
        if (url.includes('search')) {
            if (!isEmpty(coords)) {
                dispatch({
                    type: 'place/searchAllPlaces',
                    payload: {
                        longitude: coords.lon,
                        latitude: coords.lat,
                        radius: radius,
                        index: placesIndex,
                        input: unslugify(slug)
                    }
                })
            }
        }

        setTimeout(() => {
            if (isEmpty(coords)) {
                dispatch({
                    type: 'place/searchAllPlaces',
                    payload: {
                        longitude: 104.9903, // default denver
                        latitude: 39.7392, // default denver
                        radius: radius,
                        index: placesIndex,
                        input: unslugify(slug)
                    }
                })
            }
        }, 5000)
    }
    useEffect(() => {
        init()

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])



    /*  Construct Places array from our database (mongo via algolia)
    *   and Mapbox search results.
    * */
    useEffect(() => {
        if (!!algoliaPlaces || !!mapboxPlaces) {
            setAllPlaces(
                !mapboxPlaces
                    ? [...algoliaPlaces]
                    : [...algoliaPlaces, ...mapboxPlaces]
                        .reduce(function (accumulator = [], currentValue) {
                            if (!currentValue.isPendingSubmission) {  //TODO: write this into the backend
                                if (currentValue.type === 'place') {
                                    accumulator.push(currentValue)
                                } else if (accumulator.filter(place =>
                                    place.geojson?.[0]?.properties?.address === currentValue?.properties?.address
                                ).length === 0) {
                                    accumulator.push(currentValue)
                                }
                            }

                            return accumulator
                        }, [])
            )
        }


    }, [algoliaPlaces, mapboxPlaces])


    /*  Construct Features Array Sanitize Data */
    useEffect(() => {
        setFeatures([])
        for (const place of allPlaces) {
            if (isAlgoliaPlace(place)) {
                if (algoliaPlaceHasCoordinates(place)) {
                    createFeaturesFromAlgolia(place)
                }
            } else {
                if (mapboxPlaceHasCoordinates(place)) {
                    setFeatures(features => [...features, {
                        "type": "Feature",
                        "geometry": {
                            "type": "Point",
                            "coordinates": [place?.center[0], place?.center[1]]
                        },
                        "properties": {
                            "name": place?.text,
                            "photo": place?.photo,
                            "address": place?.locations?.[0]?.address1,
                            "city": place?.context?.[2]?.text,
                            "country": place?.context?.[6]?.text,
                            "postalCode": place?.context?.[1]?.text,
                            "state": place?.context?.[5]?.text,
                            "slug": `${place?.center[0]},${place?.center[1]}`,
                            "_id": place.id.split('.').pop()
                        }
                    }])
                }
            }
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [allPlaces])

    /*  Construct GeoJSON FeatureCollection for display on Mapbox Map */
    useEffect(() => {
        setGeoJsonFeature({
            "type": "FeatureCollection",
            "features": features
        })

    }, [features])


    /* Filter
    *
    *   Filtering:
    *   allPlaces is a dependency in the useEffect hook that sets
    *   features, which is a prop of the Map component where it is also
    *   a dependency of a useEffect hook that runs the buildLocationList function.
    *
    *   So in order ro rebuild the list displayed we must simply setAllPlaces([arrayOfPlacesToDisplay])
    *
    *  */
    useEffect(() => {
        setFeatures([])
        if (!!filteredPlaces) {
            if (filteredPlaces.length > 0) {
                for (const place of filteredPlaces) {
                    if (algoliaPlaceHasCoordinates(place)) {
                        createFeaturesFromAlgolia(place)
                    }
                }
            }
        }
    }, [filteredPlaces])

    return (
        <ContentWrapper theme={placesFullContainerStyle}>
            <Div theme={placesContentInnerWrapperStyle} className='places_area'>
                <MapSidebar
                    noResults={features.length === 0}
                    mapFilterOpen={mapFilterOpen}
                    setMapFilterOpen={setMapFilterOpen}
                    setSelectedFilters={setSelectedFilters}
              selectedFilters={selectedFilters}
                />
                    <MapListing
                    noResults={features.length === 0}
                    mapFilterOpen={mapFilterOpen}
                    setMapFilterOpen={setMapFilterOpen}
                    setSelectedFilters={setSelectedFilters}
              selectedFilters={selectedFilters}
                />
                <Div className='place_map_area'>
                  

                   {((
                        features.length > 0 &&
                        !!features?.[0]?.geometry?.coordinates?.[0] &&
                        !!features?.[0]?.geometry?.coordinates?.[1]) && (
                        <Map
                            styles={'mapbox://styles/mapbox/light-v10'}
                            features={geoJsonFeature}
                            lon={features?.[0]?.geometry?.coordinates?.[0]}
                            lat={features?.[0]?.geometry?.coordinates?.[1]}
                            theme={placesMapStyle}
                            zoom={13}
                            scrollZoom={true}
                        />
                    )) || (
                        <>
                            {!isMobile && (
                                <Div theme={placesMapStyle} className='placesMapStyle'>
                                    <Div theme={placesMapStyle.inner}>
                                        <NoResults  
                                        search={unslugify(slug)} 
                                        selectedFilters={selectedFilters}
                                        filter={filter}
                              />
                                    </Div>
                                </Div>
                            )}
                        </>
                    )}
                 
                </Div>
               
            </Div>
        </ContentWrapper>
    )
}

export default Places
