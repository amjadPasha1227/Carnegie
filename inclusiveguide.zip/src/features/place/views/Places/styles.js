import {colorPalette, globals} from 'config/styles'
import {
    auto,
    borderBox,
    center,
    flex,
    flexStart,
    hidden,
    inlineFlex,
    none,
    pointer,
    relative,
    sv,
    white
}                              from 'utils/themer'

export const placeSearchResultsQueryTextStyle = {
    size: [22, .7, 16],
    weight: 700,
    color: colorPalette.honeyYellow,
    child: {
        selector: 'em',
        color: globals.colors.textColor
    }
}

export const placesSidebarHeadlineStyle = {
    size: [26, .7, 22],
    weight: 700,
    boxSizing: borderBox
}

export const placeSidebarListingsStyle = {
    height: '100%',
    overflow: auto,
    boxSizing: borderBox,
    paddingTop: [30, .7, 30],
    paddingLeft: [25, globals.style.layoutScalingValue, 20],
    paddingRight: [25, globals.style.layoutScalingValue, 20],
    paddingBottom: [150, .7, 50],
    child: {
        selector: '> div',
        mobile: {
            width: '100%'
        }
    },
    mobile: {}
}

export const placeSidebarCardWrapperStyle = {
    paddingBottom: 20,
}

export const placeSidebarCardStyle = (isActive) => {
    return {
        borderColor: !isActive ? globals.colors.borderColor : colorPalette.forestGreen,
        backgroundColor: white
    }

}

export const placeQueryStyle = {
    padding: [25, globals.style.layoutScalingValue, 10],
    paddingLeft: [25, globals.style.layoutScalingValue, 20],
    paddingRight: [25, globals.style.layoutScalingValue, 20],
    boxShadow: `-6px -2px 19px 0px #d5d5d5`
}

export const placeQueryHeadingStyle = {
    marginBottom: [10, .7, 10],
    size: [14, .7, 14],
    margin: '0 auto'
}

export const placesMapSidebarStyle = noResults => {
    return {
        position: relative,
        height: noResults ? auto : `calc(100vh - ${sv(100, .7)} - ${sv(28, .7)} - ${sv(55, .7)})`,
        // paddingBottom: [150, .7, 50],
        width: [500, globals.style.layoutScalingValue, '100%'],
        minWidth: [500, globals.style.layoutScalingValue, '100%'],
        mobile: {
            width: '100%',
            //padding: 0,
            //  maxHeight: 350
        }
    }

}

export const noResultsTextStyle = {
    color: colorPalette.seaGreen,
    marginLeft: [10, .7, 10]
}

export const placesMapStyle = {
    position: relative,
    top: 0,
    right: 0,
    height: `calc(100vh - ${sv(100, .7)} - ${sv(28, .7)} - ${sv(55, .7)})`,
    width: `calc(100vw - ${sv(500, globals.style.layoutScalingValue)})`,
    inner: {
        height: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: center
    },
    mobile: {
        maxHeight: 200,
        width: '100%'
        // display: none
    },
    child: [
        {
            selector: '.mapboxgl-popup-content',
            border: `1px solid ${globals.colors.borderColor}`,
            boxSizing: borderBox,
            padding: [30, .7, 30]
         },
        {
            selector: '.mapboxgl-popup-content h4',
            margin: 0,
            padding: 0
        },
        {
            selector: '.mapboxgl-popup-content a.place-name',
            size: [24, .7, 24],
            textDecoration: none,
            hover: {
                color: globals.colors.linkHoverColor
            }
        },
        {
            selector: '.title',
            hover: {
                cursor: pointer
            }
        }
    ]
}

export const mapSidebarFilterPanelInnerStyle = {
    padding: [30, .7, 30],
    paddingBottom: 150
}

export const mapSidebarFilterByTextStyle = {
    padding: [10, .7, 10],
    textAlign: center
}

export const mapSidebarFilterHeadingStyle = {
    size: [24, .7, 24],
    padding: [10, .7, 10],
    paddingLeft: [20, .7, 20],
    //  border: `1px solid #000`,
    borderRadius: [20, .7, 20],
    marginBottom: [5, .7, 5],
    backgroundColor: colorPalette.lightGray,
    hover: {
        cursor: pointer,
        color: colorPalette.forestGreen
    }
}

export const filterItemStyle = isActive => {
    return {
        border: `1px solid ${isActive ? colorPalette.honeyYellow : globals.colors.borderColor}`,
        size: [16, .7, 16],
        display: inlineFlex,
        alignSelf: flexStart,
        padding: [10, .7, 10],
        borderRadius: [10, .7, 10],
        marginRight: [5, .7, 5],
        marginBottom: [5, .7, 5],
        background: white,
        hover: {
            cursor: pointer,
            borderColor: colorPalette.forestGreen
        }
    }
}

export const filterItemWrapperStyle = isOpen => {
    return {
        display: flex,
        overflow: hidden,
        flexWrap: 'wrap',
        height: isOpen ? 'auto !important' : 0,
        paddingLeft: [20, .7, 20],
        paddingRight: [20, .7, 20]
    }
}
