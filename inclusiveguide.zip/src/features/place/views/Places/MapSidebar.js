import Div                     from 'shared/Basic/Div'
import MapSidebarListings      from './MapSidebarListings'
import Query                   from './Query'
import {placesMapSidebarStyle} from './styles'


const MapSidebar = ({noResults, mapFilterOpen, setMapFilterOpen,setSelectedFilters,
    selectedFilters,}) => {
    return (
        <MapSidebarListings
        mapFilterOpen={mapFilterOpen}
        setMapFilterOpen={setMapFilterOpen}
        noResults={noResults}
        setSelectedFilters={setSelectedFilters}
      selectedFilters={selectedFilters}
    />
    )
}

export default MapSidebar
