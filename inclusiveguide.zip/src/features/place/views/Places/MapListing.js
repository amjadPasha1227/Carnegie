import Div                     from 'shared/Basic/Div'
import MapListings      from './MapListings'
import Query                   from './Query'
import {placesMapSidebarStyle} from './styles'


const MapSidebar = ({noResults, mapFilterOpen, setMapFilterOpen,setSelectedFilters,
    selectedFilters,}) => {
    return (
        <MapListings
        mapFilterOpen={mapFilterOpen}
        setMapFilterOpen={setMapFilterOpen}
        noResults={noResults}
        setSelectedFilters={setSelectedFilters}
      selectedFilters={selectedFilters}
    />
    )
}

export default MapSidebar
