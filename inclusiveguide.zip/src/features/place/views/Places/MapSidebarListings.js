import { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import Div from 'shared/Basic/Div'
import { isEmpty } from 'utils/helpers'
import Panel from './Filters/Panel'
import MapSidebarListing from './MapSidebarListing'
import { placeSidebarListingsStyle } from './styles'
import Filter from '../../../../assets/filter.svg'
import FilterArrow from '../../../../assets/filter_arrow.svg'
const MapSidebarListings = ({ noResults, mapFilterOpen, setMapFilterOpen, setSelectedFilters,
  selectedFilters }) => {
  const { locationList } = useSelector(state => state.place)
  const [properties, setProperties] = useState([])
  const [sortedlocationList, setsortedlocationList] = useState([])

  const propertiesReducer = (previousValue, currentValue) => [...previousValue, currentValue.properties]
  const { slug } = useSelector(state => state.site)

  const calculateMatchScore = (name, keyword) => {
    const lowercaseName = name.toLowerCase();
    const lowercaseKeyword = keyword.toLowerCase();

    if (lowercaseName === lowercaseKeyword) {
      return 2; // Exact match has the highest score
    } else if (lowercaseName.includes(lowercaseKeyword)) {
      return 1; // Partial match has a lower score
    } else {
      return 0; // No match
    }
  };

  const findBestMatch = (data, keyword) => {
    const matches = data.map(item => ({
      ...item,
      score: calculateMatchScore(item.properties.name, keyword),
    }));

    const sortedMatches = matches.sort((a, b) => {
      if (b.score === a.score) {
        return b.properties.inclusiveScore - a.properties.inclusiveScore;
      }
      return b.score - a.score;
    });

    return sortedMatches;
  };

  const filtersClose = () => {    
    document.body.classList.add('filters_hide');
    
  };
  const filtersOpen = () => { 
    document.body.classList.remove('filters_hide');
  };

  useEffect(() => {
    if (window.innerWidth < 821) document.body.classList.add("filters_hide");
    if (window.innerWidth > 821) document.body.classList.remove("filters_hide");
    if (!isEmpty(locationList)) {
      var alocationList = findBestMatch(locationList, slug);
      setsortedlocationList(alocationList)
      setProperties(alocationList?.reduce(propertiesReducer, []))
    }
    document.body.classList.add('filters-layout')
    return () => {
      document.body.classList.remove('filters-layout')
    }

  }, [locationList])

  useEffect(() => {
    if (noResults) {
      setProperties([])
    }

  }, [noResults])

  return (
    <Div className='filter_sec'>
      <Div className="fliter_sec_inner_wrapper">
        <Div className="fliter_panel">
          <div className='filter_header'>
            <span className='filtericon'>
              <img onClick={filtersOpen} src={Filter} />
            </span>
            <span>Filters</span>
            <div className='filtermenu_collapse' onClick={filtersClose}>
              <img src={FilterArrow} />
            </div>
          </div>
          <Panel
            mapFilterOpen={mapFilterOpen}
            properties={properties}
            setProperties={setProperties}
            setSelectedFilters={setSelectedFilters}
            selectedFilters={selectedFilters}
          />


          <div className='filter_footer'>
            <span className='reset_btn'>RESET</span>
            <span className='apply_btn'>Apply</span>
          </div>

        </Div>

      </Div>
    </Div>
  )
}

export default MapSidebarListings
