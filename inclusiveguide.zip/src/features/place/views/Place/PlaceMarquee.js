import React               from 'react'
import {useState}                 from 'react';
import Div                 from 'shared/Basic/Div'
import {placeMarqueeStyle} from '../styles'
import Bookmark            from './Bookmark'
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper";
import "swiper/swiper-bundle.min.css";
import SwiperImg1 from '../../../../assets/swiper/slide1.png'
import SwiperImg2 from '../../../../assets/swiper/slide2.png'
import SwiperImg3 from '../../../../assets/swiper/slide3.png'
import MapImg from '../../../../assets/map.svg'
import StarImg from '../../../../assets/star.svg'
import { CDN } from 'config/variables'

const PlaceMarquee = ({place, isVerified, userSlug, _id, token}) => {
    const [isActive, setActive] = useState(1);

    const toggleClass = (value) => {
        setActive(value);
    };

    return (
        <Div theme={placeMarqueeStyle(place.photo)} className='placeMarqueeStyle'>
            {/* {isVerified && (
                <Bookmark
                    place={place}
                    _id={_id}
                    token={token}
                    userSlug={userSlug}
                />
            )} */}
            <div className='placesSwiperWrapper'>
                    <Swiper 
                        slidesPerView={'auto'}
                        spaceBetween={0}
                        navigation={{
                            clickable: true,
                        }}
                        modules={[Navigation]}
                        className="placesSwiper"
                    >
                        <SwiperSlide 
                            className={isActive == 1 ? 'active swiper_list': "swiper_list"} 
                            onClick={() =>toggleClass(1)} 
                        >
                                <div className='swiper_image'>
                                {place?.photo &&
                        <img src={CDN + place?.photo} />

                    }
                    {!place?.photo &&
                           <img src={SwiperImg1} />

                    }
                                </div>
                        </SwiperSlide>
                       
                    </Swiper>
            </div>
        </Div>
    )
}

export default PlaceMarquee
