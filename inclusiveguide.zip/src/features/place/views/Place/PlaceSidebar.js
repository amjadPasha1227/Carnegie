import Div                                                                    from 'shared/Basic/Div'
import Map                                                                    from 'shared/Map'
import {isEmpty}                                                              from 'utils/themer'
import {placeInnerRightInfoStyle, placeInnerRightWrapperStyle, placeMapStyle} from '../styles'
import Address                                                                from './Address'
import LeaveAReviewButton                                                     from './LeaveAReview'
import CreateAReportButton                                                     from './CreateAReport'
import Tags                                                                   from './Tags'
import Website                                                                from './Website'
import MapImg from '../../../../assets/maps-and-flags.svg'
import Phone from '../../../../assets/phone-receiver-silhouette.svg'
import Email from '../../../../assets/email.svg'

const PlaceSidebar = ({
                          mapboxPlace,
                          geojson,
                          hasNoReviews,
                          isAuthenticated,
                          isVerified,
                          placeCategory,
                          phonenumber,
                          emailaddr,
                          website,
                          hours
                      }) => {

    return (
        <Div theme={placeInnerRightWrapperStyle} className="mapsidebar">
            <Div theme={placeInnerRightInfoStyle} className="mapsidebar_innr">
                <Map
                    lon={geojson?.[0]?.geometry?.coordinates?.[0] || (!isEmpty(mapboxPlace) && mapboxPlace.longitude)}
                    lat={geojson?.[0]?.geometry?.coordinates?.[1] || (!isEmpty(mapboxPlace) && mapboxPlace.latitude)}
                    theme={placeMapStyle}
                    className="map"
                />
                <div className='address_sec'>
                    <Address
                        address1={geojson?.[0]?.properties?.address}
                        address2={geojson?.[0]?.properties?.address2}
                        mapboxPlace={mapboxPlace}
                        city={geojson?.[0]?.properties?.city}
                        state={geojson?.[0]?.properties?.state}
                        zip={geojson?.[0]?.properties?.postalCode}
                    />
               <div>
    {phonenumber && (
        <div className='addr_details'>
            <div className="addr_icons">
                <img src={Phone} alt="Phone Icon" />
            </div>
            <div className="addr_place">
                {phonenumber}
            </div>
        </div>
    )}

    {emailaddr && (
        <div className='addr_details'>
            <div className="addr_icons">
                <img src={Email} alt="Email Icon" />
            </div>
            <div className="addr_place">
                <a href={`mailto:${emailaddr}`}>{emailaddr}</a>
            </div>
        </div>
    )}

    {hours && Object.keys(hours).length > 0 && (
        <div className="open_hours_sec" style={{ display: 'none' }}>
            <h6>Open Hours:</h6>
            {Object.keys(hours).map((day, i) => (
                <div key={day}>
                    <span className="week_name">{`${day[0].toUpperCase()}${day.slice(1)}`}</span>
                    <span className="timing">{` ${hours[day]?.open} - ${hours[day]?.close}`}</span>
                </div>
            ))}
        </div>
    )}

    {website && <Website website={website} />}
</div>

                </div>
                {/* <Tags placeCategory={placeCategory}/>
                {((isAuthenticated && isVerified && hasNoReviews) && (
                    <LeaveAReviewButton/>
                )) || (
                    <>
                        {hasNoReviews && (
                            <LeaveAReviewButton isAuth={false}/>
                        )}
                    </>
                )}
                 {((isAuthenticated && isVerified) && (
                    <CreateAReportButton/>
                ))} */}
            </Div>
        </Div>
    )
}

export default PlaceSidebar
