import {globe}                                    from 'config/icons'
import Div                                        from 'shared/Basic/Div'
import Icon                                       from 'shared/Basic/Icon'
import LinkSwitch                                 from 'shared/Basic/LinkSwitch'
import {placeWebsiteIconStyle, placeWebsiteStyle} from '../styles'

const Website = ({website}) => {
    return (
        <Div theme={{display: 'flex', width: '100%'}}>
            {website && website !== 'undefined' && (
                <LinkSwitch
                    url={website}
                    children={'Website'}
                    theme={placeWebsiteStyle}
                    className="website_btn"
                >
                    {/* <Icon
                        icon={globe}
                        theme={placeWebsiteIconStyle}
                    /> */}
                    <Div>Visit Website</Div>
                </LinkSwitch>
            )}
        </Div>
    )
}

export default Website
