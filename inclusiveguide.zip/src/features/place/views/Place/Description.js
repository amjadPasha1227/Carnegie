import Div                                                   from 'shared/Basic/Div'
import RichText                                              from 'shared/Basic/RichText'
import {placeDescriptionStyle, placeDescriptionWrapperStyle} from './styles'

const Description = ({description}) => {
    return (
        <Div theme={placeDescriptionWrapperStyle} className="about_desc">
            <span className='sec_head'>About</span>
            {description && (
                <RichText
                    children={description}
                    theme={placeDescriptionStyle}
                />
            )}
        </Div>
    )
}

export default Description
