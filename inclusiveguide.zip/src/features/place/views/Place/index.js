import {arrowLeft, arrowRight}           from 'config/icons'
import {MAPBOX_PUBLIC}                   from 'config/variables'
import {push}                            from 'connected-react-router'
import {mobileFlag}                      from 'features/site/slice'
import {AnimatePresence}                 from 'framer-motion'
import {useContext, useEffect, useState} from 'react'
import {ScrollMenu, VisibilityContext}   from 'react-horizontal-scrolling-menu'
import {useDispatch, useSelector}        from 'react-redux'
import Anchor                            from 'shared/Basic/Anchor'
import Div                               from 'shared/Basic/Div'
import Icon                              from 'shared/Basic/Icon'
import MotionDiv                         from 'shared/Basic/MotionDiv'
import S3Img                             from 'shared/Basic/S3Img'
import {menuPanelContext}                from 'shared/Containers/MenuPanelController'
import {searchContext}                   from 'shared/Containers/SearchController'
import ContentWrapper                    from 'shared/Layout/ContentWrapper'
import {fadeIn, fadeOut, nOpacity}       from 'shared/Layout/styles/animations'
import Span                              from '../../../../shared/Basic/Span'
import PhotoDetailModal                  from 'shared/Menus/PhotoDetailModal'
import MapImgWhite from '../../../../assets/map_white.svg'
import {
    placeDefaultDescriptionStyle,
    placeInnerLeftWrapperInnerStyle,
    placeInnerLeftWrapperStyle,
    placeReviewArrowIconContainerStyle,
    placeReviewArrowIconStyle,
    placeReviewPhotoButtonsStyle,
    placeReviewPhotoSlideStyle,
    placeReviewStyle,
    placeReviewViewAllPHotosBtnStyle,
    placeWrapperStyle, reviewHeadingStyle, reviewsHeadingWrapperStyle,
    homeSignupWrapperStyle,
    newContainerStyle,
    recentlyViewedPlaceCardStyle
} from '../styles'
import Description                       from './Description'
import LeaveAReviewButton                from './LeaveAReview'
import PlaceMarquee                      from './PlaceMarquee'
import PlaceSidebar                      from './PlaceSidebar'
import Rating                            from './Rating'
import ReviewContainer                   from './ReviewContainer'
import TaxonomyContainer                 from './TaxonomyContainer'
import Title                             from './Title'
import SwiperImg1 from '../../../../assets/swiper/slide1.png'
import SwiperImg2 from '../../../../assets/swiper/slide2.png'
import SwiperImg3 from '../../../../assets/swiper/slide3.png'
import MapImg from '../../../../assets/map.svg'
import StarImg from '../../../../assets/star.svg'
import PlaceCard from 'shared/Cards/Place'

import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper";
import moment from 'moment'

const mapboxGeo = require('@mapbox/mapbox-sdk/services/geocoding');
const geocodingClient = mapboxGeo({accessToken: MAPBOX_PUBLIC});

const LeftArrow = () => {
    const {isFirstItemVisible, scrollPrev} = useContext(VisibilityContext);
    return (
        <Div
            disabled={isFirstItemVisible}
            theme={placeReviewArrowIconContainerStyle('left', isFirstItemVisible)}
            onClick={() => scrollPrev()}
        >
            <Icon icon={arrowLeft} theme={placeReviewArrowIconStyle}/>
        </Div>
    );
}

const RightArrow = () => {
    const {isLastItemVisible, scrollNext} = useContext(VisibilityContext);
    return (
        <Div
            disabled={isLastItemVisible}
            theme={placeReviewArrowIconContainerStyle('right', isLastItemVisible)}
            onClick={() => scrollNext()}
        >
            <Icon icon={arrowRight} theme={placeReviewArrowIconStyle}/>
        </Div>
    );
}

const Place = () => {
    const {setPanel, currentPanel} = useContext(menuPanelContext)
    const isMobile = useSelector(mobileFlag)
    const dispatch = useDispatch()
    const {placesIndex} = useContext(searchContext)
    const {
        addReviewSuccess,
        mapboxPlace,
        reviews,
        place,
        placeCategory,
    } = useSelector(state => state.place)

    const {isAuthenticated, isVerified, recentlyViewedPlaces, _id, token} = useSelector(state => state.user)
    const userSlug = useSelector(state => state.user.slug)
    const {
        description,
        geojson,
        name,
        website,
        phoneNumber,
        emailAddress,
        hours
    } = place
    const {slug} = useSelector(state => state.site)
    const [hasNoReviews, setHasNoReviews] = useState(true)
    const [photos, setPhotos] = useState([])
    const [selectedPhoto, setSelectedPhoto] = useState(null)
    // const [formattedHours, setFormattedHours] = useState([])

    // const getHoursArray = () => {
    //     let hoursArr = []
    //     console.log("hours   ",hours)
    //     if (!!hours && hours?.[0]) {
    //         let weekDaysArray = Object.keys(hours[0])
    //         for (let weekDay of weekDaysArray) {
    //             hoursArr.push([(moment().day(weekDay.split("_")[0])).format('dddd'), (hours["<default>"][weekDay][0]).split("-")])
    //         }
    //     }
    //     return hoursArr
    // }

    // useEffect(() => {
    //     setFormattedHours(getHoursArray())
    // }, [hours])

    useEffect(() => {
        dispatch({
            type: 'place/setCurrentPlaceId',
            payload: {
                placeId: place._id
            }
        })
        if(!!place._id){
            dispatch({type: 'place/getReviews', payload: { token, placeId: place._id}})
        }
    },[place._id])

    const loadPlace = () => {
        if (slug.includes(',')) {
            const s = slug?.split(',')
            geocodingClient.reverseGeocode({
                query: [parseFloat(s[0]), parseFloat(s[1])],
                mode: 'mapbox.places',
                types: ['poi']
            })
                .send()
                .then(response => {
                    const match = response.body;

                    if (isAuthenticated) {
                        dispatch({
                            type: 'place/createPlaceFromMapbox',
                            payload: {
                                mapboxPlace: match.features[0],
                                _id: _id,
                                token: token,
                                slug: slug
                            }
                        })
                    } else {
                        dispatch({
                            type: 'place/loadMapboxPlace',
                            payload: match.features[0]
                        })
                    }
                })
        } else {
            if (slug.length > 0)
                dispatch({
                    type: 'place/getPlace',
                    payload: {
                        slug: slug
                    }
                })
        }
    }
    const handlePageView = () => {
        const pageViewTimer = setTimeout(() => {
            /*
                Update Algolia Index with Page View Count
                TODO: See if its less expensive to do a partial object update
             */
            if (!!place._id) {
                placesIndex.saveObject(place)
                    .then(() => {
                    })
                    .catch(error =>
                        console.log('error', error)
                    )
            }


            if (!!place._id) {
                dispatch({
                    type: 'place/addToViewCount',
                    payload: {
                        placeId: place._id,
                        viewedAt: Date.now(),
                        _id,
                        token
                    }
                })
            }
        }, 5000)
        return () => clearTimeout(pageViewTimer);
    }

    const listAllPhotos = () => {
        setPanel('place-photos')
    }

    const handlePhotoSelect = (photo) => {
        setSelectedPhoto(photo)
    }

    const closeModal = () => {
        setSelectedPhoto(null)
    }

    useEffect(() => {
        /*
        * Handle Place load based on URL slug change
        * - if url is a lng,lat -- query mapbox
        *   -- if user is authenticated create place from mapbox
        *   ^ TODO: avoid Mapbox TOS violation by comparing against OSM.
        * - if url is a slug -- query mongodb
        *
        * */
        loadPlace()

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [slug])


    useEffect(() => {
        /* Check if a User has left a Review at this Place */
        setHasNoReviews(reviews.length === 0 || reviews?.filter(review => review?.user === _id).length === 0)

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [_id, reviews])

    useEffect(() => {
        if (addReviewSuccess) {
            setPanel(null)
            // dispatch({type: 'place/closeReviewPanel'})
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [addReviewSuccess])

    useEffect(() => {
        handlePageView()

        if (!place?._geoloc?.lng || !place?._geoloc?.lat) {
            if (
                !!place?.geojson?.[0]?.properties?.address
                && !!place?.geojson?.[0]?.properties?.city
                && !!place?.geojson?.[0]?.properties?.state
            ) {
                geocodingClient.forwardGeocode({
                    query: `${place?.name} ${place?.geojson?.[0]?.properties?.address} ${place?.geojson?.[0]?.properties?.city} ${place?.geojson?.[0]?.properties?.state}`,
                    mode: 'mapbox.places-permanent',
                    limit: 2
                })
                    .send()
                    .then(response => {
                        const match = response.body;
                        const long = match.features[0].center[0]
                        const lat = match.features[0].center[1]
                        dispatch({
                            type: 'place/updateLongLat',
                            payload: {
                                long,
                                lat
                            }
                        })
                    })
            }


        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [place])

    useEffect(() => {
        let reviewPhotos = []
        reviews?.forEach(review => {
            const photos = review?.photos
            if (photos?.length > 0) {
                reviewPhotos = [...reviewPhotos, ...photos]
            }
        })
        setPhotos([...reviewPhotos])
    }, [reviews])

    const [isActive, setActive] = useState(1);

    const toggleClass = (value) => {
       
        setActive(value);
    };

    return (
        <AnimatePresence>
            <MotionDiv initial={nOpacity} animate={fadeIn} exit={fadeOut}>
                <ContentWrapper theme={{width: '100%'}}>
                    <div className='placesratingwrapper'>
                    <PlaceMarquee
                        place={place}
                        isVerified={isVerified}
                        userSlug={userSlug}
                        _id={_id}
                        token={token}
                    />
                    {/* {isMobile && (
                        <LeaveAReviewButton/>
                    )} */}
                    {/* <Div theme={placeReviewPhotoSlideStyle}>
                        {photos.length > 0 && (
                            <ScrollMenu LeftArrow={LeftArrow} RightArrow={RightArrow}>
                                {photos.map((photo, index) => (
                                    <S3Img url={photo} onClick={() => handlePhotoSelect(photo)} itemId={`${photo}-${index}`} key={`${photo}-${index}`} theme={placeReviewStyle.image}/>
                                ))}
                            </ScrollMenu>
                        )}
                    </Div> */}
                    <MotionDiv theme={placeWrapperStyle} className='score_area'>
                        <Div theme={placeReviewPhotoButtonsStyle}  className='show_all'>
                            {/* <Button theme={placeReviewAddPhotoBtnStyle}>Add a Photo</Button> */}
                            {photos.length > 0 && (
                                // <Anchor
                                //     theme={placeReviewViewAllPHotosBtnStyle}
                                //     onClick={listAllPhotos}
                                // >View All photos</Anchor>
                                <Anchor
                                    theme={placeReviewViewAllPHotosBtnStyle}
                                    onClick={listAllPhotos}
                                >Show All Photos</Anchor>
                            )}
                        </Div>
                        <Div theme={placeInnerLeftWrapperStyle} className="placeNameMain">
                            <Div theme={placeInnerLeftWrapperInnerStyle} className="placeNameWrapper">
                                <Title
                                    mapboxPlace={mapboxPlace}
                                    name={name}
                                />
                                <div className='location'><img src={MapImgWhite} /> {place?.geojson?.[0]?.properties?.address}, {place?.geojson?.[0]?.properties?.city}, {place?.geojson?.[0]?.properties?.state}</div>
                                {/*<ClaimBusinessButton/>*/}
                                <div className='review_place_Sec'>
                                    <LeaveAReviewButton/>
                                </div>
                            </Div>

                            <div className='individual_score_sec'>
                            <Div theme={{display: 'flex', flexDirection: 'column'}}>
                                <Rating
                                    reviews={reviews}
                                    place={place}
                                />
                            </Div>
                            {((description || place?.geojson?.[0]?.properties?.description) && (
                                <Description
                                    description={description || place?.geojson?.[0]?.properties?.description}
                                />
                            )) || (
                                <Div theme={placeDefaultDescriptionStyle} className='default_msg'>
                                    Oops! Looks like this business has yet to receive a description.
                                    You can still
                                    <Span
                                        theme={placeDefaultDescriptionStyle.leaveAReview}
                                        onClick={isAuthenticated ? () => setPanel(
                                            !currentPanel
                                                ? 'leave-a-review'
                                                : null
                                        ) : () => dispatch(push('/dashboard'))}>
                                        Leave a Review
                                    </Span> or Click the
                                    bookmark above to save <strong>{place.name}</strong> to your “My Places”!
                                </Div>
                            )}
                            
                            <TaxonomyContainer place={place}/>
                            </div>
                            <div className='individual_score_sec'>
                                {((place?.reviews?.length > 0 && (
                                    <ReviewContainer
                                        // reviewIds={place.reviews}
                                    />
                                )) || (
                                    <Div>
                                        <Div theme={reviewsHeadingWrapperStyle}>
                                            <Div theme={reviewHeadingStyle}>Be the first to leave a review!</Div>
                                        </Div>
                                        <Div theme={placeDefaultDescriptionStyle.reviews}>
                                            Inclusive Guide wants our users to feel more empowered as consumers by rating
                                            their customer service experience. Were you greeted when you entered the space?
                                            How safe and welcome did you feel while you were there? Did you feel celebrated?
                                            Along with our comprehensive identity profile,
                                            these measurements provide helpful insights on where businesses
                                            do well and opportunities for improvement.
                                            At Inclusive Guide, user reviews go beyond the product to center the person.
                                        </Div>
                                    </Div>
                                ))}
                            </div>
                        </Div>
                        <PlaceSidebar
                            mapboxPlace={mapboxPlace}
                            geojson={geojson}
                            hasNoReviews={hasNoReviews}
                            isAuthenticated={isAuthenticated}
                            isVerified={isVerified}
                            phonenumber={phoneNumber}
                            emailaddr={emailAddress}
                            placeCategory={placeCategory}
                            website={website}
                            hours={!!hours ? hours : {}}
                        />
                    </MotionDiv>
                    </div>
                </ContentWrapper>
            </MotionDiv>
            {selectedPhoto && <PhotoDetailModal photo={selectedPhoto} close={closeModal} />}
            {<Div theme={homeSignupWrapperStyle}>


{recentlyViewedPlaces?.length > 0 && (

    <Div theme={newContainerStyle} className='recent_search'>
        <span className='header'>Recent Search</span>
        <Swiper
            autoHeight={true}
           slidesPerView={1}
           spaceBetween={10}
           breakpoints={{
               821: {
                    slidesPerView: 2,
                    spaceBetween: 20,
                },
                1024: {
                    slidesPerView: 3,
                    spaceBetween: 20,
                },
           }}
            navigation={{
                clickable: true,
            }}
            modules={[Navigation]}
            className="recentSearchSwiper"
        >
            {recentlyViewedPlaces?.map((p, i) => (
                <SwiperSlide
                    className={isActive == 1 ? 'active swiper_list' : "swiper_list"}
                    onClick={() => toggleClass(1)}
                >

                    <PlaceCard
                        place = {p}
                        key={p._id}
                        name={p.name}
                        address={p.address}
                        city={p?.geojson?.[0]?.properties.city}
                        state={p?.geojson?.[0]?.properties.state}
                        safe={p.averageSafe}
                        celebrated={p.averageCelebrated}
                        welcome={p.averageWelcome}
                        inclusiveScore={p.inclusiveScore}
                        url={`/places/${p.slug}`}
                        theme={recentlyViewedPlaceCardStyle}
                        linkCard={true}
                    />

                </SwiperSlide>
            ))}



        </Swiper>
    </Div>

)}
</Div>}

        </AnimatePresence>
    )
}

export default Place
