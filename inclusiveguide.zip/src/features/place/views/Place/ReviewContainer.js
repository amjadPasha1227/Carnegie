import {useEffect, useState}                            from 'react'
import {useDispatch, useSelector}                       from 'react-redux'
import Div                                              from 'shared/Basic/Div'
import Pagination                                       from 'shared/Pagination'
import {reviewHeadingStyle, reviewsHeadingWrapperStyle} from '../styles'
import Reviews                                          from './Reviews'
import LeaveAReviewButton                from './LeaveAReview'

const ReviewContainer = () => {
    const dispatch = useDispatch()
    const {reviews} = useSelector(state => state.place)
    const {_id, token} = useSelector(state => state.user)
    const [currentPage, setCurrentPage] = useState(1)
    const [pageReviews, setPageReviews] = useState([])
    const pageSize = 10;
    const [userFlaggedReviews, setUserFlaggedReviews] = useState([])
    const handleReviewPageChange = (page) => {
        setPageReviews(reviews.slice((page - 1) * pageSize, page * pageSize))
        setCurrentPage(page)
    }

    useEffect(() => {
        const flaggedReviews = reviews?.filter(review => review?.report?.length > 0)
        for (const flagged of flaggedReviews) {
            if (flagged?.report.filter(flag => flag.flaggedBy)) {
                setUserFlaggedReviews([...userFlaggedReviews, flagged.id])
            }
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [reviews])


    useEffect(() => {
        // dispatch({
        //     type: 'place/getReviews',
        //     payload: {
        //         _id,
        //         token,
        //         reviews
        //     }
        // })

        if (reviews?.length > 0) {
            setPageReviews(reviews.slice(0, 10))
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [reviews])


    return (
        <>
            {pageReviews?.length > 0 && (
                <Div id="review_container" theme={reviewsHeadingWrapperStyle} className="review_container">
                    {/* <Div theme={reviewHeadingStyle}>What {reviewIds?.length} people are
                        saying</Div> */}
                    <Div theme={reviewHeadingStyle} className="review_heading">
                        <span className='sec_head'>Reviews</span>
                        <div className='write_reveiw_sec'>
                            <div className='sort_by'>
                         
                            </div>
                            <LeaveAReviewButton/>
                        </div>
                    </Div>
                    <Reviews
                        reviews={pageReviews}
                        userFlaggedReviews={userFlaggedReviews}
                    />
                    <Pagination
                        onPageChange={handleReviewPageChange}
                        totalCount={reviews?.length}
                        currentPage={currentPage}
                        pageSize={pageSize}
                    />
                </Div>
            )}
        </>
    )
}

export default ReviewContainer
