import {useEffect, useState}             from 'react'
import {doorOpen, handHoldingHeart, spa} from 'config/icons'
import dayjs                             from 'dayjs'
import Gravatar                          from 'react-gravatar'
import {useDispatch, useSelector}        from 'react-redux'
import Div                               from 'shared/Basic/Div'
import Icon                              from 'shared/Basic/Icon'
import RichText                          from 'shared/Basic/RichText'
import S3Img                             from 'shared/Basic/S3Img'
import Img                                           from 'shared/Basic/Img'
import Safe                                          from '../../../../assets/safe.png'
import Welcome                                       from '../../../../assets/welcome.png'
import Celebrated                                    from '../../../../assets/celebrated.png'
import {
    placeLikertItemWrapperStyle,
    placeReviewDescriptionStyle,
    placeReviewDisclaimerStyle,
    placeReviewedByStyle,
    placeReviewIconWrapperStyle,
    placeReviewLikertStyle,
    placeReviewScaleInnerStyle,
    placeReviewScaleStyle,
    placeReviewStyle,
    placeReviewUserAvatarStyle,
    placeReviewUserInfoStyle,
    placeReviewUserNameStyle,
    reviewsWrapperStyle
}                                        from '../styles'
import Report                            from './Report'
import Span from 'shared/Basic/Span'
import ReplyAReviewButton       from './ReplyAReview'

const Reviews = ({reviews, userFlaggedReviews}) => {
    const dispatch = useDispatch()
    const {isAuthenticated, token, user} = useSelector(state => state.user)
    const { place} = useSelector(state => state.place)
    const {_id,businessAdmins} = useSelector(state => state.place.place)

    const [filteredArray, setFilteredArray] = useState()

    const [isOwned, setisOwned] = useState(false)

    useEffect(() => {
        // dispatch({type: 'place/getReviews', payload: {_id, token, reviewIds}})
        console.log("businessAdminsbusinessAdmin sss")
        console.log(businessAdmins)
        if (user.placesOwned && user.placesOwned.includes(_id)) {
            setisOwned(true)
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [reviews])

    useEffect(() => {
        if (!!reviews){
            let filteredRviews = [...reviews].sort((a, b) => (b.updated > a.updated) ? 1 : ((a.updated > b.updated) ? -1 : 0))
            setFilteredArray(filteredRviews)
            
            // let replies = []
            // let or = filteredRviews.filter((review) => {
            //     if(review.parentId == null){
            //         return true
            //     }
            //     replies.push(review)
            //     return false
            // })
    
            // let reviewsWithReplies = []
            // for (let rev of or){
            //     // reviewsWithReplies.push(rev)
            //     let revReplies = replies.filter((rep) => rep.parentId === rev._id)
            //     reviewsWithReplies.push({
            //         ...rev,
            //         ["replies"]: revReplies
            //     })
            // }
            
            // // console.log("reviewsWithReplies  ",reviewsWithReplies)
            // setFilteredArray(reviewsWithReplies)
        }
    }, [reviews])


    return (
        <Div theme={reviewsWrapperStyle} className='review_list'>
            {filteredArray && filteredArray.map((review) => {
                const isFlagged = userFlaggedReviews.filter(item => item === review?._id).length > 0
                const reviewPhotos = review?.photos || []

                return (
                    <Div key={review?._id} className="review_item">
                        {(!isFlagged && (
                            <Div
                                theme={placeReviewStyle} className="review_cnt"
                            >
                                <Div theme={placeReviewUserInfoStyle} className="review_left_cnt_wrapper">
                                    <div className="review_left_cnt">
                                    {((review?.reviewerAvatar && !review?.isAnon) && (
                                        <div className='reviewer_icon'>
                                            <S3Img url={review?.reviewerAvatar} theme={placeReviewUserAvatarStyle}/>
                                        </div>
                                    )) || (
                                        <Div theme={placeReviewUserAvatarStyle} className='reviewer_icon'>
                                            <Gravatar
                                                email={!review?.isAnon ? review?.reviewerEmail : ''} size={200}/>
                                        </Div>
                                    )}
                                    <div className='r_name_date'>
                                        {((review?.reviewerName && !review?.isAnon) && (
                                            <Div theme={placeReviewUserNameStyle} className='reviewer_name'>{review?.reviewerName}</Div>
                                        )) || (
                                            <Div theme={placeReviewUserNameStyle} className='reviewer_name'>Inclusive Guide Member</Div>
                                        )}
                                        <Div theme={placeReviewedByStyle}>
                                            <span className='reviewed_date'>
                                                {dayjs(review?.updated).format('MMMM DD, YYYY')}
                                            </span>
                                        </Div>
                                    </div> 
                                    </div>
                                </Div>
                                <Div theme={{width: '100%'}} className="review_right_cnt">
                                    <RichText theme={placeReviewDescriptionStyle} className="review_desc">{review?.review}</RichText>
                                   
                                    <div className='score-right'>
                                        {isOwned && (
                                            <div>  <ReplyAReviewButton review={review}></ReplyAReviewButton> </div>
                                        )}
                                        <ul>
                                            <li>
                                                <Img src={Safe}/>
                                                <label>{review?.safe?.[1]}</label>
                                                <em>Safe</em>
                                            </li>
                                            <li>
                                                <Img src={Welcome}/>
                                                <label>{review?.welcome?.[1]}</label>
                                                <em>Welcome</em>
                                            </li>
                                            <li>
                                                <Img src={Celebrated}/>
                                                <label>{review?.celebrated?.[1]}</label>
                                                <em>Celebrated</em>
                                            </li>
                                        </ul>
                                        {!isFlagged && isAuthenticated && (
                                            <Report review={review}/>
                                        )}
                                    </div>
                                  
                                    <Div className='blockeddiv'>
                                 
                                
                                    <div>
                                        {
                                            (review?.replies.length > 0) && <div>
                                                <h5 className='replies_heading'>Replies </h5>
                                                {
                                                    review.replies.map((reply) => {
                                                        // console.log("reply is ", reply)
                                                        return (<div>

                                    <Div theme={placeReviewUserInfoStyle} className="review_left_cnt">
                                    {((reply?.reviewerAvatar && !reply?.isAnon) && (
                                        <div className='reviewer_icon'>
                                            <S3Img url={reply?.reviewerAvatar} theme={placeReviewUserAvatarStyle}/>
                                        </div>
                                    )) || (
                                        <Div theme={placeReviewUserAvatarStyle} className='reviewer_icon'>
                                            <Gravatar
                                                email={!reply?.isAnon ? reply?.reviewerEmail : ''} size={200}/>
                                        </Div>
                                    )}
                                    <div className='r_name_date'>
                                        {((reply?.reviewerName && !reply?.isAnon) && (
                                            <Div theme={placeReviewUserNameStyle} className='reviewer_name'>{reply?.reviewerName}</Div>
                                        )) || (
                                            <Div theme={placeReviewUserNameStyle} className='reviewer_name'>Inclusive Guide Member</Div>
                                        )}
                                        <Div theme={placeReviewedByStyle}>
                                            <span className='reviewed_date'>
                                                {dayjs(reply?.updated).format('MMMM DD, YYYY')}
                                            </span>
                                        </Div>
                                    </div>
                                </Div>

                                <Div theme={{width: '100%'}} className="review_right_cnt review_right_cnt_v2">


                                                            <RichText theme={placeReviewDescriptionStyle} className="review_desc">{reply?.review}</RichText>
                                                       </Div>
                                                        </div>)

                                                    })
                                                }
                                            </div>
                                        }
                                    </div>
                                    </Div>
                                </Div>

                                
                                

                             
                            </Div>
                        )) || null}
                    </Div>
                )
            })}
        </Div>
    )
}

export default Reviews
