import {useContext}              from 'react'
import {useSelector}             from 'react-redux'
import Div                       from 'shared/Basic/Div'
import {menuPanelContext}        from 'shared/Containers/MenuPanelController'
import {LeaveAReviewButtonStyle} from './styles'
const CreateAReport = ({isAuth = true}) => {
    const {setPanel, currentPanel} = useContext(menuPanelContext)
    const {isAdmin} = useSelector(state => state.user)


    return (
        <Div>   
        { (isAdmin) &&
      <  Div
            theme={LeaveAReviewButtonStyle}
            onClick={ () => setPanel(
                !currentPanel
                    ? 'create-a-report'
                    : null) 
         }>
            {isAuth ? `Create A Report` : `Create A Report`}
        </Div>
        }
        </Div>

        
    )
}

export default CreateAReport
