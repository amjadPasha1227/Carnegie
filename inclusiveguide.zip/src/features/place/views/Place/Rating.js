import Div from 'shared/Basic/Div'
import {inclusiveScoreWrapperStyle, inclusiveScoreStyle, scoreBarStyle, scoreCircleStyle, scoreWrapperStyle} from './styles'
import Span from 'shared/Basic/Span'
import {mobileFlag}                      from 'features/site/slice'
import Img                                           from 'shared/Basic/Img'
import Safe                                          from '../../../../assets/safe_green.svg'
import Welcome                                       from '../../../../assets/welcome_green.svg'
import Celebrated                                    from '../../../../assets/celebrated_green.svg'
import RightArrow                                    from '../../../../assets/chevron_green_right.svg'
import { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import {CDN} from 'config/variables'
import LinkSwitch from 'shared/Basic/LinkSwitch'

const Rating = ({reviews, place}) => {
    const {averageSafe, averageCelebrated, averageWelcome, inclusiveScore} = place
    const isMobile = useSelector(mobileFlag)
    const dispatch = useDispatch()
    const { slug, _id, token, user, businesses } = useSelector(state => state.user)
    const [busines, setBusines] = useState([])
    const [scorecolor, setScorecolor] = useState([])
    const [imglist, setimglistList] = useState([]);

    useEffect(() => {

        dispatch({
            type: 'user/getUser',
            payload: {
                slug: slug,
                _id: _id,
                token: token
            }
        })
        
    }, [])

    useEffect(() => {
        setBusines(place)
        if (place?.inclusiveScore * 20 < 30) {
            setScorecolor('count low')
        }
        if (place?.inclusiveScore * 20 > 30 && busines.inclusiveScore < 60) {
            setScorecolor('count medium')
        }
        if (place?.inclusiveScore * 20 > 60) {
            setScorecolor('count high')
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps

    }, [place])
    const formatScore = (score) => {
        let formattedScore = parseFloat((score * 20).toFixed(2));
        if (isNaN(formattedScore)) return '0';
        return formattedScore % 1 === 0 ? formattedScore.toString() : formattedScore.toFixed(2);
    };
    function SemiCircleChart({value}){
        const angle = (value / 100) * 180; // Dividing by 100 since max is always 100
        const style = {'--angle': angle + 'deg'};
      
        return (
          <div className="sc-gauge">
            <div className="sc-background">
              <div className="sc-percentage" style={style}></div>
              <div className="sc-mask"></div>
              <span className="sc-value">{ value }</span>
            </div>
          </div>
        );
      }


    return (
        <Div theme={{display: 'flex'}}>
            {inclusiveScore > 0 && (
                <Div theme={scoreBarStyle} className="inclusiveScoreInfoStyle">

                    <Div theme={inclusiveScoreWrapperStyle} className="scoreBoxcard">
                        <Span theme={{maxWidth: '50%'}} className='inclusive_heading'>
                            Inclusive Score
                        </Span>
                        {/* <Div theme={{...scoreCircleStyle, ...inclusiveScoreStyle}}>{inclusiveScore}</Div> */}
                        {/* <div className='score-list'>
                            <div className='count'>
                                <svg id="scorecount"  xmlns="http://www.w3.org/2000/svg" height="200" width="200" viewBox="0 0 200 200" data-value="70"> 
                                    <path class="bg" stroke="#F0F0F0" d="M41 149.5a77 77 0 1 1 117.93 0"  fill="none"/>
                                    <path class="meter" stroke="#B2D876" d="M41 149.5a77 77 0 1 1 117.93 0" fill="none" stroke-dasharray="350" stroke-dashoffset="350"/>
                                </svg>
                                <div className='scorevalue'>
                                    <label>4.17</label>
                                </div>
                            </div>
                            <div className='score-right'>
                                <ul>
                                    <li>
                                        <Img src={Safe}/>
                                        <label>4.5</label>
                                        <em>Safe</em>
                                    </li>
                                    <li>
                                        <Img src={Welcome}/>
                                        <label>4.5</label>
                                        <em>Welcome</em>
                                    </li>
                                    <li>
                                        <Img src={Celebrated}/>
                                        <label>3.5</label>
                                        <em>Celebrated</em>
                                    </li>
                                </ul>
                                <span className='devider'></span>
                                <a className='all-reviews' href='#'>
                                    125 Reviews <Img src={RightArrow}/>
                                </a>
                            </div>
                        </div> */} 
                        <div className='score-list'>
                               { busines && busines?.inclusiveScore && <div className={scorecolor} >

                               <SemiCircleChart
    value={formatScore(busines?.inclusiveScore)}
  />

                                </div>
}
                                <div className='score-right'>
                                    <ul>
                                        <li>
                                            <Img src={Safe}/>
                                            <label>{busines?.averageSafe}</label>
                                            <em>Safe</em>
                                        </li>
                                        <li>
                                            <Img src={Welcome}/>
                                            <label>{busines?.averageWelcome}</label>
                                            <em>Welcome</em>
                                        </li>
                                        <li>
                                            <Img src={Celebrated}/>
                                            <label>{busines?.averageCelebrated}</label>
                                            <em>Celebrated</em>
                                        </li>
                                    </ul>
                                    <span className='devider'></span>

                                    <LinkSwitch url={`#review_container`} className='all-reviews'>
                                            {busines?.reviews?.length} Reviews <Img src={RightArrow}/>
                                    </LinkSwitch>
                                </div>
                            </div>
                    </Div>
                    {/* {!isMobile && (
                        <Span theme={{display: 'flex'}}>
                            <Div theme={scoreWrapperStyle} >
                        <Div theme={{...scoreCircleStyle, background: '#99C7A7'}}>{averageSafe}</Div>
                        Safe
                        <Icon icon={spa}/>
                    </Div>
                    <Div theme={scoreWrapperStyle}>
                        <Div theme={{...scoreCircleStyle, background: '#FFB40050'}}>{averageWelcome}</Div>
                        Welcome
                        <Icon icon={doorOpen}/>
                    </Div>
                    <Div theme={scoreWrapperStyle}>
                        <Div theme={{...scoreCircleStyle, background: '#540D6E30'}}>{averageCelebrated}</Div>
                        Celebrated
                        <Icon icon={handHoldingHeart}/>
                    </Div>
                            </Span>
                    )}
                     {isMobile && (
                        <Div theme={{display: 'flex'}}>
                            <Div theme={scoreWrapperStyle} className="scoreBox">
                        <Div theme={{...scoreCircleStyle, background: '#99C7A7'}}>{averageSafe}</Div>
                        Safe
                        <Icon icon={spa}/>
                    </Div>
                    <Div theme={scoreWrapperStyle} className="scoreBox">
                        <Div theme={{...scoreCircleStyle, background: '#FFB40050'}}>{averageWelcome}</Div>
                        Welcome
                        <Icon icon={doorOpen}/>
                    </Div>
                    <Div theme={scoreWrapperStyle} className="scoreBox">
                        <Div theme={{...scoreCircleStyle, background: '#540D6E30'}}>{averageCelebrated}</Div>
                        Celebrated
                        <Icon icon={handHoldingHeart}/>
                    </Div>
                            </Div>
                    )} */}
                    
                </Div>
            )}
        </Div>
    )
}

export default Rating
