import {push}                    from 'connected-react-router'
import {useContext}              from 'react'
import {useDispatch}             from 'react-redux'
import Div                       from 'shared/Basic/Div'
import {menuPanelContext}        from 'shared/Containers/MenuPanelController'
import {LeaveAReviewButtonStyle} from './styles'
import Icon              from 'shared/Basic/Icon'
import {receipt}            from 'config/icons'

import {
    placeReportPortalStyle,
    placeReviewReportIconStyle,
    placeReviewReportWrapperStyle2,
    placesReportFormStyle
}                        from '../styles'
import { relative } from 'utils/themer'
//TODO: create is isEmployee in backend
//TODO: pass in isEmplyee and isAdmin from parent component
const ReplyAReview = ({review}) => {
    const {setPanel, currentPanel} = useContext(menuPanelContext)
    const dispatch = useDispatch()

    const getReviewPanel = () => {
        console.log("in the get panel  ",review._id)
         setPanel(
            !currentPanel
                ? 'reply-a-review'
                : null
        )
        dispatch({
            type: 'place/setReplyReviewId',
            payload: {
                reviewId: review,
            }
        }) 
    }
    
    return (
        <Div style={{position: "relative"}}>
        <Div
           theme={placeReviewReportWrapperStyle2}
            className=""
            onClick={true == true ? getReviewPanel : () => dispatch(push('/dashboard'))}
        >
            <Icon
                        theme={placeReviewReportIconStyle}
                        icon={receipt}
                    />
                    <Div>Reply</Div>
        </Div>
 
        </Div>

        
    )
}

export default ReplyAReview
