import {push}                    from 'connected-react-router'
import {useContext}              from 'react'
import {useDispatch}             from 'react-redux'
import Div                       from 'shared/Basic/Div'
import {menuPanelContext}        from 'shared/Containers/MenuPanelController'
import {LeaveAReviewButtonStyle} from './styles'
//TODO: create is isEmployee in backend
//TODO: pass in isEmplyee and isAdmin from parent component
const LeaveAReview = ({isAuth = true}) => {
    const {setPanel, currentPanel} = useContext(menuPanelContext)
    const dispatch = useDispatch()
    return (
        <Div>
        <Div
            theme={LeaveAReviewButtonStyle}
            className="write_a_review_btn"
            onClick={isAuth ? () => setPanel(
                !currentPanel
                    ? 'leave-a-review'
                    : null
            ) : () => dispatch(push('/dashboard'))}
        >
            {isAuth ? `Write a Review` : `Write a Review`}
        </Div>
 
        </Div>

        
    )
}

export default LeaveAReview
