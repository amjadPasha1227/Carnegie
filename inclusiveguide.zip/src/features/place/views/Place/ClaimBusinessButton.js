import React                   from 'react'
import Div                     from 'shared/Basic/Div'
import Tooltip                 from 'shared/Controls/ToolTip'
import {placeClaimButtonStyle} from '../styles'

const ClaimBusinessButton = () => {
    return (
        <Div theme={placeClaimButtonStyle}>
            <span>Unclaimed</span>
            <Tooltip
                message={'This business has not yet been claimed by the owner or a representative.\n' +
                '\n' +
                'Claim this business to view business statistics, receive messages from prospective customers, and respond to reviews.'}/>
        </Div>
    )
}

export default ClaimBusinessButton
