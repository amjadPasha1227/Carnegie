import {mapMarker}         from 'config/icons'
import Div                 from 'shared/Basic/Div'
import Icon                from 'shared/Basic/Icon'
import {isEmpty}           from 'utils/themer'
import {placeAddressStyle} from '../styles'
import MapImg from '../../../../assets/maps-and-flags.svg'

const Address = ({address1, address2, mapboxPlace, city, state, zip}) => {
    return (
        <Div>
            <Div theme={placeAddressStyle} className="addr_details">
                <Div className="addr_icons">
                    <img src={MapImg} />
                </Div>
                <Div theme={placeAddressStyle.address} className="addr_place">
                    {(!!address1 && address1) || (!isEmpty(mapboxPlace) && mapboxPlace.address)}
                    {(!!address1 ? ', ' : '')}
                    {(!!address2 && address2 !== 'undefined') ? address2 : ''}
                    {(!!address2 && address2 !== 'undefined') ? ', ' : ''}
                    {(!!city && city) || (!isEmpty(mapboxPlace) && mapboxPlace.city)}
                    {(!!city ? ', ' : '')}
                    {(!!state && state) || (!isEmpty(mapboxPlace) && mapboxPlace.state)}
                    {' '}
                    {(!!zip && zip !== 'null' && zip) || (!isEmpty(mapboxPlace) && !!mapboxPlace ? mapboxPlace.zip : '')}
                    {' '}
                </Div>
            </Div>
        </Div>
    )
}

export default Address
