import React, {useEffect}                              from 'react'
import {useDispatch, useSelector}                      from 'react-redux'
import Div                                             from 'shared/Basic/Div'
import {placeTaxonomyStyle, placeTaxonomyWrapperStyle} from '../styles'
import {useState}                           from 'react'
import MotionDiv                            from 'shared/Basic/MotionDiv'

const TaxonomyContainer = () => {
    const dispatch = useDispatch()
    const {
        adaptiveEquipmentSolutions,
        bathrooms,
        communitiesServed,
        doorways,
        entryways,
        foodOptions,
        hearingImpairedSolutions,
        languageSpoken,
        place,
        placeLoaded,
        publicTransportationList,
        visualImpairedSolutions,
        ownerIdentity,
        
        
    } = useSelector(state => state.place)

    const {
        wheelchairElevator,
        wheelchairParking,
        wheelchairRamps,
        wheelchairRestroom,
    } = place

    useEffect(() => {
        if (placeLoaded) {
            place?.bathrooms?.forEach(_id => {
                dispatch({
                    type: 'site/getEntityById',
                    payload: {
                        entityId: _id,
                        path: 'bathroom',
                        feature: 'place'
                    }
                })
            })
            place?.businessOwner?.forEach(_id => {
                dispatch({
                    type: 'site/getEntityById',
                    payload: {
                        entityId: _id,
                        path: 'business-owner',
                        feature: 'place'
                    }
                })
            })
            place?.categories?.forEach(_id => {
                dispatch({
                    type: 'site/getEntityById',
                    payload: {
                        entityId: _id,
                        path: 'place-category',
                        feature: 'place'
                    }
                })
            })
            place?.communitiesServed?.forEach(_id => {
                dispatch({
                    type: 'site/getEntityById',
                    payload: {
                        entityId: _id,
                        path: 'communities-served',
                        feature: 'place'
                    }
                })
            })
            place?.foodOptions?.forEach(_id => {
                dispatch({
                    type: 'site/getEntityById',
                    payload: {
                        entityId: _id,
                        path: 'food-options',
                        feature: 'place'
                    }
                })
            })
            place?.languageSpoken?.forEach(_id => {
                dispatch({
                    type: 'site/getEntityById',
                    payload: {
                        entityId: _id,
                        path: 'language-spoken',
                        feature: 'place'
                    }
                })
            })
            place?.adaptiveEquipmentSolution?.forEach(_id => {
                dispatch({
                    type: 'site/getEntityById',
                    payload: {
                        entityId: _id,
                        path: 'adaptive-equipment-solution',
                        feature: 'place'
                    }
                })
            })
            place?.entryway?.forEach(_id => {
                dispatch({
                    type: 'site/getEntityById',
                    payload: {
                        entityId: _id,
                        path: 'entryway',
                        feature: 'place'
                    }
                })
            })
            place?.doorway?.forEach(_id => {
                dispatch({
                    type: 'site/getEntityById',
                    payload: {
                        entityId: _id,
                        path: 'doorway',
                        feature: 'place'
                    }
                })
            })
            place?.hearingImpairedSolution?.forEach(_id => {
                dispatch({
                    type: 'site/getEntityById',
                    payload: {
                        entityId: _id,
                        path: 'hearing-impaired-solution',
                        feature: 'place'
                    }
                })
            })
            place?.publicTransportation?.forEach(_id => {
                dispatch({
                    type: 'site/getEntityById',
                    payload: {
                        entityId: _id,
                        path: 'public-transportation',
                        feature: 'place'
                    }
                })
            })
            place?.visualImpairedSolution?.forEach(_id => {
                dispatch({
                    type: 'site/getEntityById',
                    payload: {
                        entityId: _id,
                        path: 'visual-impaired-solution',
                        feature: 'place'
                    }
                })
            })
            place?.ownerIdentity?.forEach(_id => {
                dispatch({
                    type: 'site/getEntityById',
                    payload: {
                        entityId: _id,
                        path: 'owner-identity',
                        feature: 'place'
                    }
                })
            })

            dispatch({type: 'place/taxonomyLoaded'})
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [placeLoaded])

    const [isOpen, setIsOpen] = useState(false)
    const variants = {
        initial: {
            height: 0,
            overflow: 'hidden'
        },
        animate: {
            height: 'auto'
        }
    }

    const [activeAccordion, setActiveAccordion] = useState(0);

    const toggleAccordion = (index) => {
      setActiveAccordion(index === activeAccordion ? -1 : index);
    };
    return (
        <Div theme={placeTaxonomyWrapperStyle} className="facilities_sec">
        <span className='sec_head'>Facilities</span>
        {adaptiveEquipmentSolutions.length > 0 && (
          <Div theme={placeTaxonomyStyle} className="facilities_item">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 0 ? "open" : ""}`}
              onClick={() => toggleAccordion(0)}
            >
              Adaptive Equipment Solutions
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 0 ? 'animate' : 'initial'}
              variants={variants}
            >
              <div className='facilities_cnt'>
                {adaptiveEquipmentSolutions.map((a, i) => (
                  <Div key={i} theme={placeTaxonomyStyle.name} className='facilities_name'>
                    {a.name}
                  </Div>
                ))}
              </div>
            </MotionDiv>
          </Div>
        )}
        {bathrooms.length > 0 && (
          <Div theme={placeTaxonomyStyle} className="facilities_item">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 1 ? "open" : ""}`}
              onClick={() => toggleAccordion(1)}
            >
              Bathrooms
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 1 ? 'animate' : 'initial'}
              variants={variants}
            >
            <div className='facilities_cnt'>
              {bathrooms.map((bathroom, i) => (
                <Div key={i} theme={placeTaxonomyStyle.name} className='facilities_name'>
                  {bathroom.name}
                </Div>
              ))}
            </div>
            </MotionDiv>
          </Div>
        )}
        {communitiesServed.length > 0 && (
          <Div theme={placeTaxonomyStyle} className="facilities_item">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 2 ? "open" : ""}`}
              onClick={() => toggleAccordion(2)}
            >
              Affinity Space
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 2 ? 'animate' : 'initial'}
              variants={variants}
            >
            <div className='facilities_cnt'>
              {communitiesServed.map((community, i) => (
                <Div key={i} theme={placeTaxonomyStyle.name} className='facilities_name'>{community.name}</Div>
              ))}
            </div>
            </MotionDiv>
          </Div>
        )}
        {ownerIdentity.length > 0 && (
          <Div theme={placeTaxonomyStyle} className="facilities_item">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 3 ? "open" : ""}`}
              onClick={() => toggleAccordion(3)}
            >
              Owner Identity
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 3 ? 'animate' : 'initial'}
              variants={variants}
            >
            <div className='facilities_cnt'>
              {ownerIdentity.map((identity, i) => (
                <Div key={i} theme={placeTaxonomyStyle.name} className='facilities_name'>{identity.name}</Div>
              ))}
            </div>
            </MotionDiv>
          </Div>
        )}
        {doorways.length > 0 && (
          <Div theme={placeTaxonomyStyle} className="facilities_item">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 4 ? "open" : ""}`}
              onClick={() => toggleAccordion(4)}
            >
              Doorways
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 4 ? 'animate' : 'initial'}
              variants={variants}
            >
            <div className='facilities_cnt'>
              {doorways.map((d, i) => (
                <Div key={i} theme={placeTaxonomyStyle.name} className='facilities_name'>
                  {d.name}
                </Div>
              ))}
            </div>
            </MotionDiv>
          </Div>
        )}
        {entryways.length > 0 && (
          <Div theme={placeTaxonomyStyle} className="facilities_item">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 5 ? "open" : ""}`}
              onClick={() => toggleAccordion(5)}
            >
              Entryways
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 5 ? 'animate' : 'initial'}
              variants={variants}
            >
            <div className='facilities_cnt'>
              {entryways.map((e, i) => (
                <Div key={i} theme={placeTaxonomyStyle.name} className='facilities_name'>
                  {e.name}
                </Div>
              ))}
            </div>
            </MotionDiv>
          </Div>
        )}
        {foodOptions.length > 0 && (
          <Div theme={placeTaxonomyStyle} className="facilities_item food_options">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 6 ? "open" : ""}`}
              onClick={() => toggleAccordion(6)}
            >
              Food Options
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 6 ? 'animate' : 'initial'}
              variants={variants}
            >
            <div className='facilities_cnt'>
              {foodOptions.map((food, i) => (
                <Div key={i} theme={placeTaxonomyStyle.name} className='facilities_name'>{food.name}</Div>
              ))}
            </div>
            </MotionDiv>
          </Div>
        )}
        {hearingImpairedSolutions.length > 0 && (
          <Div theme={placeTaxonomyStyle} className="facilities_item">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 7 ? "open" : ""}`}
              onClick={() => toggleAccordion(7)}
            >
              Hearing Impaired Solutions
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 7 ? 'animate' : 'initial'}
              variants={variants}
            >
            <div className='facilities_cnt'>
              {hearingImpairedSolutions.map((h, i) => (
                <Div key={i} theme={placeTaxonomyStyle.name} className='facilities_name'>
                  {h.name}
                </Div>
              ))}
            </div>
            </MotionDiv>
          </Div>
        )}
        {languageSpoken.length > 0 && (
          <Div theme={placeTaxonomyStyle} className="facilities_item food_options">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 8 ? "open" : ""}`}
              onClick={() => toggleAccordion(8)}
            >
              Languages Spoken in this Space
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 8 ? 'animate' : 'initial'}
              variants={variants}
            >
            <div className='facilities_cnt'>
              {languageSpoken.map((language, i) => (
                <Div key={i} theme={placeTaxonomyStyle.name} className='facilities_name'>{language.name}</Div>
              ))}
            </div>
            </MotionDiv>
          </Div>
        )}
        {publicTransportationList.length > 0 && (
          <Div theme={placeTaxonomyStyle} className="facilities_item">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 9 ? "open" : ""}`}
              onClick={() => toggleAccordion(9)}
            >
              Public Transportation
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 9 ? 'animate' : 'initial'}
              variants={variants}
            >
            <div className='facilities_cnt'>
              {publicTransportationList.map((list, i) => (
                <Div key={i} theme={placeTaxonomyStyle.name} className='facilities_name'>{list.name}</Div>
              ))}
            </div>
            </MotionDiv>
          </Div>
        )}
        {wheelchairElevator && (
          <Div theme={placeTaxonomyStyle} className="facilities_item">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 10 ? "open" : ""}`}
              onClick={() => toggleAccordion(10)}
            >
              Wheelchair Elevator
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 10 ? 'animate' : 'initial'}
              variants={variants}
            >
            <div className='facilities_cnt'>
              <Div theme={placeTaxonomyStyle.name} className='facilities_name'>A wheelchair elevator is accessible</Div>
            </div>
            </MotionDiv>
          </Div>
        )}
        {wheelchairParking && (
          <Div theme={placeTaxonomyStyle} className="facilities_item">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 11 ? "open" : ""}`}
              onClick={() => toggleAccordion(11)}
            >
              Wheelchair Parking
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 11 ? 'animate' : 'initial'}
              variants={variants}
            >
            <div className='facilities_cnt'>
              <Div theme={placeTaxonomyStyle.name} className='facilities_name'>A wheelchair parking space is available</Div>
            </div>
            </MotionDiv>
          </Div>
        )}
        {wheelchairRamps && (
          <Div theme={placeTaxonomyStyle} className="facilities_item">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 12 ? "open" : ""}`}
              onClick={() => toggleAccordion(12)}
            >
              Wheelchair Ramps
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 12 ? 'animate' : 'initial'}
              variants={variants}
            >
            <div className='facilities_cnt'>
              <Div theme={placeTaxonomyStyle.name} className='facilities_name'>A wheelchair ramp is available</Div>
            </div>
            </MotionDiv>
          </Div>
        )}
        {wheelchairRestroom && (
          <Div theme={placeTaxonomyStyle} className="facilities_item">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 13 ? "open" : ""}`}
              onClick={() => toggleAccordion(13)}
            >
              Wheelchair Restroom
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 13 ? 'animate' : 'initial'}
              variants={variants}
            >
            <div className='facilities_cnt'>
              <Div theme={placeTaxonomyStyle.name} className='facilities_name'>A wheelchair accessible restroom is available</Div>
            </div>
            </MotionDiv>
          </Div>
        )}
        {visualImpairedSolutions.length > 0 && (
          <Div theme={placeTaxonomyStyle} className="facilities_item">
            <Div
              theme={placeTaxonomyStyle.title}
              className={`facilities_heading ${activeAccordion === 14 ? "open" : ""}`}
              onClick={() => toggleAccordion(14)}
            >
              Visual Impaired Solution
            </Div>
            <MotionDiv
              initial={'initial'}
              animate={activeAccordion === 14 ? 'animate' : 'initial'}
              variants={variants}
            >
              <div className='facilities_cnt'>
                {visualImpairedSolutions.map((v, i) => (
                  <Div key={i} theme={placeTaxonomyStyle.name} className='facilities_name'>{v.name}</Div>
                ))}
              </div>
            </MotionDiv>
          </Div>
        )}
      </Div>

    )
}

export default TaxonomyContainer
