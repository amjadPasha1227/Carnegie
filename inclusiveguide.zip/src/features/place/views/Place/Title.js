import Div               from 'shared/Basic/Div'
import MotionDiv         from 'shared/Basic/MotionDiv'
import {placeTitleStyle} from '../styles'

const Title = ({mapboxPlace, name}) => {
    return (
        <Div theme={{display: 'flex', flexDirection: 'column'}}>
            {(name || mapboxPlace.name) && (
                <MotionDiv theme={placeTitleStyle} className='placeName'>
                    {name || mapboxPlace?.name}
                </MotionDiv>
            )}
        </Div>
    )
}

export default Title
