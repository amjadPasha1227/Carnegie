        <!-- footer_wrapper started -->
        <footer class="footer_wrapper">
            <div class="container">
                <h2>Book a call to learn more about our all inclusive, full stack sales tax solution</h2>
                <a  target="_blank" href="https://calendly.com/taxhero/demo" class="primary-btn">Book A Call</a>
                
                <div class="row">
                    <div class="copyrights wow fadeInUp">
                        <div id="logo" class="wow fadeInUp">
                            <a href="<?php echo home_url('/') ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/Footer_logo.png"></a>
                            <ul>
                                <li>© <?php echo date('Y') ?> All rights reserved.</li>
                                <li><a href="<?php echo home_url('/terms') ?>">Terms & Conditions</a></li>
                                <li><a href="<?php echo home_url('/privacy') ?>">Privacy Policy</a></li>
                            </ul>
                        </div>
                        <ul>
                            <li><a href="#"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fab fa-linkedin-in" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                            <li class="lst-child"><a href="#"><i class="fab fa-youtube" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <button class="btn btn-primary scroll-top" data-scroll="up" type="button">
				<i class="fa fa-angle-up" aria-hidden="true"></i>
			</button>
        </footer>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="<?php echo get_template_directory_uri(); ?>/js/slick.js"></script>	 
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/11.0.2/bootstrap-slider.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/11.0.2/bootstrap-slider.js"></script>
        <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.bundle.min.js"></script>     
        <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/global.js"></script>    
        
  

  <?php wp_footer(); ?>

</body>
</html>