
$(document).ready(function(){
   
  $('#nav-icon1').click(function(){ 
    $(this).toggleClass('open');
    $('nav').toggleClass('menu_open')
  });
  
  $('nav ul li a').click(function(){
    $('#nav-icon1').removeClass('open')
    $('nav').removeClass('menu_open')
  });

  $(document).on("scroll", function(){
    if ($(document).scrollTop() >1){
        $("#myHeader").addClass("fixed");
    }
    else {
    $("#myHeader").removeClass("fixed");
    }
}); 


 
  
  $('.testimonial-slider').slick({
    autoplay: false,
    autoplaySpeed: 1000,
    speed: 600,
    draggable: true,
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    dots: false,
    adaptiveHeight: true
    
});

  

   $(document).on('click','nav ul li a.features', function(event) {
    event.preventDefault();
    var target = this.getAttribute('href');
    if($(target).offset().top > 0){
      $('html, body').animate({ 
        scrollTop: $(target).offset().top - 70
      }, 100);
       
    }
  });
  

});

$(window).scroll(function () {
  if ($(this).scrollTop() > 100) {
    $('.scroll-top').fadeIn();
  } else {
    $('.scroll-top').fadeOut();
  }
});
$('.scroll-top').click(function () {
  $("html, body").animate({
    scrollTop: 0
  }, 100);
  return false;
});